#!/usr/bin/env python3
"""Fetch pinned dependencies and check the complete uploaded project entry point.

This driver records new logs separately from the historical theorem audits.
It never runs `lake update` and never builds every MathFin library target.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--zero-gravity', action='store_true',
                        help='Also build the five-module zero-gravity target.')
    parser.add_argument('--skip-download', action='store_true',
                        help='Use already installed pinned dependencies and Mathlib cache.')
    args = parser.parse_args()
    lake = shutil.which('lake')
    if lake is None:
        sys.exit('Lake was not found. Install Lean through the official Lean 4 VS Code extension,\n'
                 'then reopen the terminal and run this command from the extracted project.\n'
                 'See https://lean-lang.org/install/')
    if shutil.which('git') is None:
        sys.exit('Git was not found. Install Git, reopen the terminal, and rerun this command.\n'
                 'Lake uses Git to fetch the pinned dependency revisions.\n'
                 'See https://git-scm.com/downloads')
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    out = ROOT / 'verification' / 'live-runs' / stamp
    out.mkdir(parents=True)
    manifest = ROOT / 'lake-manifest.json'
    digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
    pinned_manifest_hash = digest(manifest)
    report = {
        'status': 'RUNNING', 'scope': 'Project startup and source compilation',
        'started_utc': stamp, 'lean_toolchain': (ROOT / 'lean-toolchain').read_text().strip(),
        'manifest_sha256': pinned_manifest_hash,
        'source_sha256': digest(ROOT / 'Chain_Fountain_Live.lean'),
        'zero_gravity_requested': args.zero_gravity,
        'new_transitive_axiom_audit': False,
        'historical_audits': 'Historical full-project audit reports are not bundled in this source-only package. Browser validation summaries are in verification/browser-compatibility/revision-2.'
    }
    report_path = out / 'summary.json'

    def save():
        report_path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')

    def run(name, command):
        print('\n' + name, flush=True)
        with (out / (name + '.log')).open('w', encoding='utf-8') as log:
            proc = subprocess.Popen(command, cwd=ROOT, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, text=True,
                                    encoding='utf-8', errors='replace')
            for line in proc.stdout:
                print(line, end='', flush=True)
                log.write(line)
            code = proc.wait()
        if digest(manifest) != pinned_manifest_hash:
            raise RuntimeError('The pinned dependency manifest changed. Restore the supplied file '
                               'before retrying; no successful check is being claimed.')
        if code:
            raise RuntimeError(name + ' failed. See ' + str(out / (name + '.log')))

    save()
    try:
        run('lean-version', [lake, 'env', 'lean', '--version'])
        if not args.skip_download:
            run('mathlib-cache', [lake, 'exe', 'cache', 'get'])
        run('external-dependencies', [sys.executable, str(ROOT / 'verification/build_dependencies.py')])
        run('unified-source', [lake, 'env', 'lean', '-j4',
                              '-Dbackward.isDefEq.respectTransparency=false',
                              'Chain_Fountain_Live.lean'])
        if args.zero_gravity:
            run('zero-gravity', [lake, 'build', 'ChainFountainZeroGravity'])
        report['status'] = 'PASS'
        report['result'] = 'The selected Lean source checks completed successfully.'
    except (OSError, RuntimeError) as error:
        report['status'] = 'FAIL'
        report['error'] = str(error)
        save()
        print(str(error), file=sys.stderr)
        return 1
    save()
    print('\nPASS. New compilation record: ' + str(report_path))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
