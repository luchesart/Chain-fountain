# Run from PowerShell after installing Lean 4 and Python 3.
# This script does not change PowerShell execution policy or install system software.
param(
    [switch]$ZeroGravity,
    [switch]$SkipDownload
)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$pythonCommand = Get-Command py -ErrorAction SilentlyContinue
$pythonPrefix = @('-3')
if (-not $pythonCommand) {
    $pythonCommand = Get-Command python -ErrorAction SilentlyContinue
    $pythonPrefix = @()
}
if (-not $pythonCommand) {
    throw 'Python 3 was not found. Install Python 3 and reopen PowerShell.'
}
$verifyArguments = @('verify.py')
if ($ZeroGravity) { $verifyArguments += '--zero-gravity' }
if ($SkipDownload) { $verifyArguments += '--skip-download' }
& $pythonCommand.Source @pythonPrefix @verifyArguments
exit $LASTEXITCODE
