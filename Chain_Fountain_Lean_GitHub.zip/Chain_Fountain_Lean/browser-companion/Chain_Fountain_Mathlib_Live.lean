import Mathlib.Analysis.Calculus.Deriv.Pow
import Mathlib.Analysis.ODE.Gronwall
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Convert
import Mathlib.MeasureTheory.Integral.IntervalIntegral.AbsolutelyContinuousFun
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap
import Mathlib.Analysis.Calculus.Deriv.Prod
import Mathlib.Analysis.Calculus.Deriv.Inv
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus
import Mathlib.Analysis.Calculus.ContDiff.Deriv
import Mathlib.Analysis.Calculus.ContDiff.RCLike
import Mathlib.Analysis.ODE.PicardLindelof
import Mathlib.Analysis.ODE.ExistUnique
import Mathlib.Analysis.Calculus.MeanValue
import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Probability.Martingale.Basic
import Mathlib.Topology.MetricSpace.Contracting
import Mathlib.MeasureTheory.Function.LpSpace.Complete
import Mathlib.MeasureTheory.Integral.IntegralEqImproper
import Mathlib.Topology.ContinuousMap.Compact
import Mathlib.MeasureTheory.Covering.OneDim
import Mathlib.MeasureTheory.Covering.Differentiation
import Mathlib.Tactic.FunProp
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.NormNum.RealSqrt
import Mathlib.Tactic.Continuity
import Mathlib.Tactic.Measurability
import Mathlib.Tactic.GCongr
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.IntervalCases
import Mathlib.Tactic.Choose
import Mathlib.Tactic.Ext
import Mathlib.Tactic.Push
import Mathlib.Tactic.SimpRw
import Mathlib.Tactic.ApplyFun
import Mathlib.Tactic.Abel
import Mathlib.Tactic.Tauto

set_option backward.isDefEq.respectTransparency false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false

/-!
# Chain fountain: Mathlib-only browser companion
Author: Latchezar Tomov. Browser revision: 2 (11 November 2026).

Compatibility targets, fixed at this revision:
- Stable Release: Lean 4.35.0, Mathlib 56a005855ea17e0b0958f73ec801ae140b0a1679.
- Latest Mathlib snapshot: Lean 4.36.0-rc2,
  Mathlib 10a613cca96c9b98c695eddf09c0b7b2a53b4b6b.
For reproducible use, select "Stable Release (v4.35.0 with mathlib, cslib)"
on https://live.lean-lang.org/#project=mathlib-stable and paste this ENTIRE file.
"Latest Mathlib" changes over time. Future revisions are not covered here.

All 350 theorem statements and their hypotheses are preserved. This revision
makes interval membership explicit, uses common-version mean-value lemmas,
updates deprecated syntax, and gives the GlobalL2 module an explicit finite
heartbeat budget. Required options are in this file, not command-line flags.

SCOPE: This file contains the deterministic and zero-gravity modules of the
formal companion, including measurable-input and absolutely continuous results.
It DOES NOT contain the mechanical stochastic SDE, Ito-integral or LIL proofs.
Those proofs require the separate full pinned project with MathFin and
BrownianMotion. This file is not the entire formalization of the paper.

The mathematical model is assumed. Formal checking proves the stated deductions
under their explicit hypotheses, not empirical adequacy or a numerical solver.
-/
/- BEGIN SOURCE MODULE: ChainFountain.ModelCore -/

/-!
# The reduced chain-fountain model
Paper: Boundary Actuation of a Chain Fountain, Latchezar Tomov.
All variables are real. The equations are assumed physical modelling laws;
the identities below are proved from those laws, not empirical validation.
-/

namespace ChainFountain

noncomputable section

def crownSq (v w : ℝ) : ℝ := ((v + w) / 2) ^ 2
def heightRate (v w : ℝ) : ℝ := (v - w) / 2
def rise (g α h v w u : ℝ) : ℝ :=
  (crownSq v w - (1 - α) * v ^ 2 - g * h - u) / h
def fall (H g β h v w : ℝ) : ℝ :=
  g + (-crownSq v w + β * w ^ 2) / (H + h)
def pickup (α v u : ℝ) : ℝ := (1 - α) * v ^ 2 + u
def energy (H g lam h v w : ℝ) : ℝ :=
  lam / 2 * (h * v ^ 2 + (H + h) * w ^ 2) + lam * g * h ^ 2

theorem crown_identity (v w : ℝ) :
    (v - w) * crownSq v w + (v - w) * (v ^ 2 + w ^ 2) / 4 =
      (v ^ 3 - w ^ 3) / 2 := by unfold crownSq; ring

/-- Proposition 3.1, the directional derivative of energy along the vector field. -/
theorem energy_balance (H g lam α β h v w u : ℝ)
    (hh : h ≠ 0) (hH : H + h ≠ 0) :
    lam / 2 * (heightRate v w * v ^ 2 + h * (2 * v * rise g α h v w u) +
      heightRate v w * w ^ 2 + (H + h) * (2 * w * fall H g β h v w)) +
      lam * g * (2 * h * heightRate v w) =
    lam * g * H * w - lam * (1 / 2 - α) * v ^ 3 -
      lam * (1 / 2 - β) * w ^ 3 - lam * u * v := by
  unfold heightRate rise fall crownSq
  field_simp <;> ring

/-- Proposition 3.1 with genuine derivatives, at every classical-solution time. -/
theorem energy_hasDerivAt {H g lam α β u t : ℝ} {h v w : ℝ → ℝ}
    (hh : h t ≠ 0) (hH : H + h t ≠ 0)
    (dh : HasDerivAt h (heightRate (v t) (w t)) t)
    (dv : HasDerivAt v (rise g α (h t) (v t) (w t) u) t)
    (dw : HasDerivAt w (fall H g β (h t) (v t) (w t)) t) :
    HasDerivAt (fun s => energy H g lam (h s) (v s) (w s))
      (lam * g * H * w t - lam * (1 / 2 - α) * v t ^ 3 -
       lam * (1 / 2 - β) * w t ^ 3 - lam * u * v t) t := by
  have hd := (((dh.mul (dv.pow 2)).add
    ((dh.const_add H).mul (dw.pow 2))).const_mul (lam / 2)).add
    ((dh.pow 2).const_mul (lam * g))
  convert! hd using 1
  convert! (energy_balance H g lam α β (h t) (v t) (w t) u hh hH).symm using 1 <;>
    simp only [Pi.pow_apply] <;> ring

def steadySpeedSq (H g β r : ℝ) : ℝ := g * (H + r) / (1 - β)
def steadyInput (H g α β r : ℝ) : ℝ :=
  g * (α * H - (1 - α - β) * r) / (1 - β)
def heightFromInput (H g α β u : ℝ) : ℝ :=
  (α * H - (1 - β) * u / g) / (1 - α - β)

theorem steady_input_balance (H g α β r : ℝ) (hβ : 1 - β ≠ 0) :
    steadyInput H g α β r = α * steadySpeedSq H g β r - g * r := by
  unfold steadyInput steadySpeedSq
  field_simp <;> ring

theorem steady_tension (H g α β r : ℝ) (hβ : 1 - β ≠ 0) :
    (1 - α) * steadySpeedSq H g β r + steadyInput H g α β r =
      g * (H + β * r) / (1 - β) := by
  unfold steadySpeedSq steadyInput
  field_simp <;> ring

theorem steady_tension_pos {H g β r : ℝ}
    (hH : 0 < H) (hg : 0 < g) (hβ : 0 ≤ β) (hβ1 : β < 1) (hr : 0 ≤ r) :
    0 < g * (H + β * r) / (1 - β) := by
  have hd : 0 < 1 - β := by linarith
  positivity

theorem steady_is_equilibrium {H g α β r v : ℝ}
    (_hr : r ≠ 0) (hH : H + r ≠ 0) (hβ : 1 - β ≠ 0)
    (hv : v ^ 2 = steadySpeedSq H g β r) :
    heightRate v v = 0 ∧
      rise g α r v v (steadyInput H g α β r) = 0 ∧
      fall H g β r v v = 0 := by
  have hc : crownSq v v = v ^ 2 := by unfold crownSq; ring
  have hb := steady_input_balance H g α β r hβ
  have hs : (1 - β) * v ^ 2 = g * (H + r) := by
    rw [hv, steadySpeedSq]; field_simp
  refine ⟨by simp [heightRate], ?_, ?_⟩
  · unfold rise; rw [hc]; rw [← hv] at hb
    have : v ^ 2 - (1 - α) * v ^ 2 - g * r - steadyInput H g α β r = 0 := by
      nlinarith
    rw [this]; simp
  · unfold fall; rw [hc]
    field_simp
    nlinarith [hs]

theorem input_height_inverse (H g α β r : ℝ)
    (hg : g ≠ 0) (hβ : 1 - β ≠ 0) (hαβ : 1 - α - β ≠ 0) :
    heightFromInput H g α β (steadyInput H g α β r) = r := by
  unfold heightFromInput steadyInput
  field_simp <;> ring

theorem passive_height_limit {H g α β r : ℝ}
    (hg : 0 < g) (hβ : 0 < 1 - β) (hαβ : 0 < 1 - α - β) :
    0 ≤ steadyInput H g α β r ↔ r ≤ α * H / (1 - α - β) := by
  unfold steadyInput
  rw [le_div_iff₀ hαβ, le_div_iff₀ hβ]
  constructor
  · intro hu; nlinarith
  · intro hr; nlinarith

theorem steady_state_iff {H g α β r v u : ℝ}
    (hr : r ≠ 0) (hH : H+r ≠ 0) (hβ : 1-β ≠ 0) :
    (rise g α r v v u=0 ∧ fall H g β r v v=0) ↔
      (v^2=steadySpeedSq H g β r ∧ u=steadyInput H g α β r) := by
  have hc : crownSq v v=v^2 := by unfold crownSq; ring
  constructor
  · rintro ⟨hu,hf⟩
    unfold fall at hf; rw [hc] at hf
    have heq : (1-β)*v^2=g*(H+r) := by
      field_simp at hf; nlinarith [hf]
    have hv : v^2=steadySpeedSq H g β r := by
      unfold steadySpeedSq; apply (eq_div_iff hβ).mpr; nlinarith [heq]
    refine ⟨hv,?_⟩
    unfold rise at hu; rw [hc] at hu
    have hnum := (div_eq_zero_iff.mp hu).resolve_right hr
    have hb := steady_input_balance H g α β r hβ
    rw [←hv] at hb; nlinarith
  · rintro ⟨hv,rfl⟩
    exact (steady_is_equilibrium hr hH hβ hv).2

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.ModelCore -/

/- BEGIN SOURCE MODULE: ChainFountain.Model -/

/-!
Compatibility entry point for the original v0.16.0 model.
All model definitions, theorem statements and proof bodies are unchanged in
`ModelCore`. This entry point preserves the original complete Mathlib re-export;
the new zero-gravity library imports `ModelCore` directly for a small dependency
closure. The byte-for-byte original source is retained in
`verification/zero-gravity/Model.v16.lean` and in the original project archive.
-/
/- END SOURCE MODULE: ChainFountain.Model -/

/- BEGIN SOURCE MODULE: ChainFountain.Tracking -/

namespace ChainFountain
noncomputable section

def errorEnergy (k₀ e z : ℝ) : ℝ := k₀ / 2 * e ^ 2 + z ^ 2 / 8
def errorRate (k₁ e z : ℝ) : ℝ := -k₁ * e + z / 2
def zRate (k₀ k₂ κd G d e z : ℝ) : ℝ :=
  -2 * k₀ * e - k₂ * z - κd * G ^ 2 * z + G * d
def acceleration (k₀ k₁ k₂ e q r₁ r₂ : ℝ) : ℝ :=
  r₂ - (k₁ + k₂) * (q - r₁) - (k₀ + k₁ * k₂) * e
def nominalInput (H g α β h v w A : ℝ) : ℝ :=
  (1 + h / (H + h)) * crownSq v w - (1 - α) * v ^ 2 -
    2 * g * h - β * h * w ^ 2 / (H + h) - 2 * h * A
def robustInput (H g α β h v w A κd z : ℝ) : ℝ :=
  nominalInput H g α β h v w A + κd * v ^ 4 / h * z

theorem nominal_acceleration (H g α β h v w A : ℝ)
    (hh : h ≠ 0) (hH : H + h ≠ 0) :
    (rise g α h v w (nominalInput H g α β h v w A) -
      fall H g β h v w) / 2 = A := by
  unfold rise fall nominalInput
  field_simp <;> ring

theorem robust_acceleration (H g α β h v w A κd z d : ℝ)
    (hh : h ≠ 0) (hH : H + h ≠ 0) :
    (rise g (α + d) h v w (robustInput H g α β h v w A κd z) -
      fall H g β h v w) / 2 =
        A - κd * (v ^ 2 / h) ^ 2 * z / 2 + (v ^ 2 / h) * d / 2 := by
  unfold robustInput rise fall nominalInput
  field_simp <;> ring

theorem transformed_error_rate (k₁ h r v w r₁ : ℝ) :
    heightRate v w - r₁ =
      errorRate k₁ (h-r) (v - w - 2 * r₁ + 2 * k₁ * (h-r)) := by
  unfold heightRate errorRate; ring

theorem transformed_z_rate (k₀ k₁ k₂ e q r₁ r₂ κd G d z : ℝ)
    (hz : z = 2 * (q - r₁ + k₁ * e)) :
    2 * (acceleration k₀ k₁ k₂ e q r₁ r₂ - κd * G ^ 2 * z / 2 + G * d / 2) -
      2 * r₂ + 2 * k₁ * (q - r₁) = zRate k₀ k₂ κd G d e z := by
  unfold acceleration zRate; rw [hz]; ring

theorem energy_nonneg {k₀ : ℝ} (hk₀ : 0 ≤ k₀) (e z : ℝ) :
    0 ≤ errorEnergy k₀ e z := by unfold errorEnergy; positivity

theorem energy_zero_iff {k₀ e z : ℝ} (hk₀ : 0 < k₀) :
    errorEnergy k₀ e z = 0 ↔ e = 0 ∧ z = 0 := by
  unfold errorEnergy
  constructor
  · intro h
    have he : e ^ 2 = 0 := by nlinarith [sq_nonneg z, sq_nonneg e]
    have hz : z ^ 2 = 0 := by nlinarith
    exact ⟨eq_zero_of_pow_eq_zero he, eq_zero_of_pow_eq_zero hz⟩
  · rintro ⟨rfl,rfl⟩; ring

/-- The exact Lyapunov identity, including bounded coefficient uncertainty. -/
theorem lyapunov_identity (k₀ k₁ k₂ κd G d e z : ℝ) :
    k₀ * e * errorRate k₁ e z + z / 4 * zRate k₀ k₂ κd G d e z =
      -k₀ * k₁ * e ^ 2 - k₂ * z ^ 2 / 4 - κd * G ^ 2 * z ^ 2 / 4 + G * z * d / 4 := by
  unfold errorRate zRate; ring

theorem energy_hasDerivAt_errors {e z : ℝ → ℝ} {k₀ k₁ k₂ κd G d t : ℝ}
    (he : HasDerivAt e (errorRate k₁ (e t) (z t)) t)
    (hz : HasDerivAt z (zRate k₀ k₂ κd G d (e t) (z t)) t) :
    HasDerivAt (fun s => errorEnergy k₀ (e s) (z s))
      (-k₀ * k₁ * e t ^ 2 - k₂ * z t ^ 2 / 4 -
        κd * G ^ 2 * z t ^ 2 / 4 + G * z t * d / 4) t := by
  have hd := ((he.pow 2).const_mul (k₀ / 2)).add ((hz.pow 2).div_const 8)
  convert! hd using 1
  unfold errorRate zRate; ring

theorem nominal_decay {k₀ k₁ k₂ κ e z : ℝ}
    (hk₀ : 0 ≤ k₀) (hκ₁ : κ ≤ k₁) (hκ₂ : κ ≤ k₂) :
    -k₀ * k₁ * e ^ 2 - k₂ * z ^ 2 / 4 ≤ -2 * κ * errorEnergy k₀ e z := by
  unfold errorEnergy
  have h₁ := mul_nonneg (sub_nonneg.mpr hκ₁) (mul_nonneg hk₀ (sq_nonneg e))
  have h₂ := mul_nonneg (sub_nonneg.mpr hκ₂) (sq_nonneg z)
  nlinarith

theorem weighted_young {κd G z d : ℝ} (hd : 0 < κd) :
    G * z * d / 4 ≤ κd * G ^ 2 * z ^ 2 / 8 + d ^ 2 / (8 * κd) := by
  apply (mul_le_mul_iff_right₀ (show 0 < 8 * κd by positivity)).mp
  have hsq := sq_nonneg (κd * G * z - d)
  have hc : (8 * κd) * (d ^ 2 / (8 * κd)) = d ^ 2 := by field_simp
  nlinarith

/-- Equation (7.2), proved directly from the weighted square identity. -/
theorem robust_decay {k₀ k₁ k₂ κ κd G d e z : ℝ}
    (hk₀ : 0 ≤ k₀) (hκ₁ : κ ≤ k₁) (hκ₂ : κ ≤ k₂) (hd : 0 < κd) :
    -k₀ * k₁ * e ^ 2 - k₂ * z ^ 2 / 4 - κd * G ^ 2 * z ^ 2 / 4 + G * z * d / 4 ≤
      -2 * κ * errorEnergy k₀ e z - κd * G ^ 2 * z ^ 2 / 8 + d ^ 2 / (8 * κd) := by
  have hn := nominal_decay (e:=e) (z:=z) hk₀ hκ₁ hκ₂
  have hy := weighted_young (G:=G) (z:=z) (d:=d) hd
  linarith

theorem robust_decay_uniform {k₀ k₁ k₂ κ κd G d dbar e z : ℝ}
    (hk₀ : 0 ≤ k₀) (hκ₁ : κ ≤ k₁) (hκ₂ : κ ≤ k₂)
    (hd : 0 < κd) (hbound : |d| ≤ dbar) :
    -k₀ * k₁ * e ^ 2 - k₂ * z ^ 2 / 4 - κd * G ^ 2 * z ^ 2 / 4 + G * z * d / 4 ≤
      -2 * κ * errorEnergy k₀ e z + dbar ^ 2 / (8 * κd) := by
  have h := robust_decay (e:=e) (z:=z) (G:=G) (d:=d) hk₀ hκ₁ hκ₂ hd
  have hs : d ^ 2 ≤ dbar ^ 2 := by
    have hsq := (sq_le_sq₀ (abs_nonneg d) (le_trans (abs_nonneg d) hbound)).mpr hbound
    simpa only [sq_abs] using hsq
  have hdiv := div_le_div_of_nonneg_right hs (by positivity : 0 ≤ 8 * κd)
  have hn : 0 ≤ κd * G ^ 2 * z ^ 2 / 8 := by positivity
  linarith

/-- Exact additional term caused by replacing the requested input. -/
theorem input_correction (z h u ur : ℝ) :
    z / 4 * (-(u - ur) / h) = -z / (4 * h) * (u - ur) := by ring

/-- The quadratic generator expression; no stochastic-process theorem is assumed. -/
theorem generator_identity (k₀ k₁ k₂ κd G σ e z : ℝ) :
    k₀ * e * errorRate k₁ e z + z / 4 * zRate k₀ k₂ κd G 0 e z +
      (1 / 2) * (σ * G) ^ 2 * (1 / 4) =
    -k₀ * k₁ * e ^ 2 - k₂ * z ^ 2 / 4 - κd * G ^ 2 * z ^ 2 / 4 + σ ^ 2 * G ^ 2 / 8 := by
  unfold errorRate zRate; ring

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.Tracking -/

/- BEGIN SOURCE MODULE: ChainFountain.Spectral -/

namespace ChainFountain
noncomputable section

def coeff₂ (ρ ω : ℝ) := (1 - ρ) * ω
def coeff₁ (α ρ ω : ℝ) := ((5 / 2) * α * (1 + ρ) - 4 * α ^ 2) * ω ^ 2
def coeff₀ (α ρ ω : ℝ) := α ^ 2 * (1 - ρ) * ω ^ 3
def cubic (α ρ ω p : ℝ) := p ^ 3 + coeff₂ ρ ω * p ^ 2 + coeff₁ α ρ ω * p + coeff₀ α ρ ω

theorem routh_factorization (α ρ ω : ℝ) :
    coeff₂ ρ ω * coeff₁ α ρ ω - coeff₀ α ρ ω =
      (5 / 2) * α * (1 - ρ) * (1 + ρ - 2 * α) * ω ^ 3 := by
  unfold coeff₂ coeff₁ coeff₀; ring

theorem hurwitz_conditions {α ρ ω : ℝ}
    (ha : 0 < α) (ha1 : α < 1 / 2) (hr : 0 < ρ) (hr1 : ρ < 1) (hw : 0 < ω) :
    0 < coeff₂ ρ ω ∧ 0 < coeff₁ α ρ ω ∧ 0 < coeff₀ α ρ ω ∧
      coeff₀ α ρ ω < coeff₂ ρ ω * coeff₁ α ρ ω := by
  have hr0 : 0 < 1 - ρ := by linarith
  have hb : 0 < (5 / 2) * (1 + ρ) - 4 * α := by linarith
  have hc : 0 < (5 / 2) * α * (1 + ρ) - 4 * α ^ 2 := by
    nlinarith [mul_pos ha hb]
  have hp : 0 < 1 + ρ - 2 * α := by linarith
  have hf : 0 < (5 / 2 : ℝ) * α * (1 - ρ) * (1 + ρ - 2 * α) * ω ^ 3 := by positivity
  refine ⟨by unfold coeff₂; positivity, by unfold coeff₁; positivity,
    by unfold coeff₀; positivity, ?_⟩
  rw [← routh_factorization] at hf; linarith

theorem rho_parameter_range {α β : ℝ}
    (ha : 0 < α) (hb : 0 ≤ β) (hab : α + β < 1 / 2) :
    0 < α / (1 - β) ∧ α / (1 - β) < 1 := by
  have hd : 0 < 1 - β := by linarith
  constructor
  · exact div_pos ha hd
  · rw [div_lt_one hd]; linarith

/-- A direct proof of the cubic Hurwitz criterion, rather than an assumed bridge. -/
theorem cubic_roots_left {a₂ a₁ a₀ : ℝ}
    (h₂ : 0 < a₂) (h₁ : 0 < a₁) (h₀ : 0 < a₀) (hH : a₀ < a₂ * a₁)
    (z : ℂ) (hz : z ^ 3 + (a₂ : ℂ) * z ^ 2 + (a₁ : ℂ) * z + (a₀ : ℂ) = 0) :
    z.re < 0 := by
  by_contra h
  have hx : 0 ≤ z.re := le_of_not_gt h
  have hre := congrArg Complex.re hz
  have him := congrArg Complex.im hz
  simp only [Complex.add_re, Complex.add_im, Complex.mul_re, Complex.mul_im,
    Complex.ofReal_re, Complex.ofReal_im, Complex.zero_re, Complex.zero_im,
    pow_succ, pow_zero, Complex.one_re, Complex.one_im] at hre him
  by_cases hy : z.im = 0
  · simp only [hy, mul_zero, zero_mul, add_zero, sub_zero] at hre
    have h3 : 0 ≤ z.re * z.re * z.re := by positivity
    have h2 : 0 ≤ a₂ * (z.re * z.re) := by positivity
    have h1 : 0 ≤ a₁ * z.re := by positivity
    nlinarith
  · have hi : z.im * (3 * z.re ^ 2 - z.im ^ 2 + 2 * a₂ * z.re + a₁) = 0 := by
      nlinarith [him]
    have hy2 : z.im ^ 2 - (3 * z.re ^ 2 + 2 * a₂ * z.re + a₁) = 0 := by
      have := (mul_eq_zero.mp hi).resolve_left hy; linarith
    have he : 8 * z.re ^ 3 + 8 * a₂ * z.re ^ 2 +
        2 * (a₁ + a₂ ^ 2) * z.re + (a₂ * a₁ - a₀) = 0 := by
      linear_combination -hre - (3 * z.re + a₂) * hy2
    have h3 : 0 ≤ z.re ^ 3 := by positivity
    have h2 : 0 ≤ a₂ * z.re ^ 2 := by positivity
    have h1 : 0 ≤ (a₁ + a₂ ^ 2) * z.re := by positivity
    linarith

theorem plant_cubic_roots_left {α ρ ω : ℝ}
    (ha : 0 < α) (ha1 : α < 1 / 2) (hr : 0 < ρ) (hr1 : ρ < 1) (hw : 0 < ω)
    (z : ℂ) (hz : z ^ 3 + (coeff₂ ρ ω : ℂ) * z ^ 2 +
      (coeff₁ α ρ ω : ℂ) * z + (coeff₀ α ρ ω : ℂ) = 0) : z.re < 0 := by
  obtain ⟨h₂,h₁,h₀,hH⟩ := hurwitz_conditions ha ha1 hr hr1 hw
  exact cubic_roots_left h₂ h₁ h₀ hH z hz

theorem no_pole_zero_cancellation (α ρ ω : ℝ) :
    cubic α ρ ω (-2 * α * ω) = -10 * α ^ 2 * ρ * ω ^ 3 := by
  unfold cubic coeff₂ coeff₁ coeff₀; ring

theorem transfer_zero_negative {α ω : ℝ} (ha : 0 < α) (hw : 0 < ω) :
    -2 * α * ω < 0 := by nlinarith [mul_pos ha hw]

theorem transfer_zero_not_root {α ρ ω : ℝ}
    (ha : 0 < α) (hr : 0 < ρ) (hw : 0 < ω) :
    cubic α ρ ω (-2 * α * ω) ≠ 0 := by
  rw [no_pole_zero_cancellation]
  have hp : 0 < 10 * α ^ 2 * ρ * ω ^ 3 := by positivity
  exact ne_of_lt (by nlinarith)

/-- Determinant of pI-J for the displayed Jacobian; J's differential identification
and nonlinear local exponential stability are separate analytic obligations. -/
theorem characteristic_determinant (α β ρ ω p : ℝ) (hrel : α = (1 - β) * ρ) :
    Matrix.det (!![p, -(1/2 : ℝ), (1/2 : ℝ);
      α * ω ^ 2, p + (1 - 2 * α) * ω, -ω;
      -α * ρ * ω ^ 2, ρ * ω, p + (1 - 2 * β) * ρ * ω]) = cubic α ρ ω p := by
  simp only [Matrix.det_fin_three]
  simp
  unfold cubic coeff₂ coeff₁ coeff₀
  rw [hrel]
  ring

/-- Resolvent input-output identity for the displayed Jacobian. The equations
are (pI-J)x=(0,-1/h,0); no inverse-matrix or transfer-function conclusion is
assumed. The identity is valid for complex p and state amplitudes. -/
theorem resolvent_output (α β ρ ω h : ℝ) (p x₀ x₁ x₂ : ℂ)
    (hrel : α = (1-β)*ρ)
    (he₀ : p*x₀-(1/2 : ℂ)*x₁+(1/2 : ℂ)*x₂=0)
    (he₁ : (α : ℂ)*ω^2*x₀+(p+(1-2*(α : ℂ))*ω)*x₁-(ω : ℂ)*x₂=-(1/(h : ℂ)))
    (he₂ : -(α : ℂ)*ρ*ω^2*x₀+(ρ : ℂ)*ω*x₁+(p+(1-2*(β : ℂ))*ρ*ω)*x₂=0) :
    (p^3+(coeff₂ ρ ω : ℂ)*p^2+(coeff₁ α ρ ω : ℂ)*p+(coeff₀ α ρ ω : ℂ))*x₀ =
      -(p+2*(α : ℂ)*ω)/(2*(h : ℂ)) := by
  have hr : (α : ℂ) = (1-(β : ℂ))*(ρ : ℂ) := by exact_mod_cast hrel
  unfold coeff₂ coeff₁ coeff₀
  push_cast
  rw [hr] at he₁ he₂ ⊢
  linear_combination
    ((p+(1-2*((1-(β : ℂ))*ρ))*ω)*(p+(1-2*(β : ℂ))*ρ*ω)+(ρ : ℂ)*ω^2)*he₀ +
    ((p+2*(1-(β : ℂ))*ρ*ω)/2)*he₁ +
    ((2*((1-(β : ℂ))*ρ)*ω-p)/2)*he₂

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.Spectral -/

/- BEGIN SOURCE MODULE: ChainFountain.Comparison -/

namespace ChainFountain
noncomputable section
open Set Real

def envelope (V₀ κ C t : ℝ) : ℝ :=
  exp (-2 * κ * t) * V₀ + C / (2 * κ) * (1 - exp (-2 * κ * t))

/-- Comparison for genuine derivatives; this does not assume its conclusion. -/
theorem scalar_comparison {V V' : ℝ → ℝ} {T κ C : ℝ} (hκ : 0 < κ)
    (hc : ContinuousOn V (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt V (V' t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, V' t ≤ -2 * κ * V t + C) :
    ∀ t ∈ Icc 0 T, V t ≤ envelope (V 0) κ C t := by
  have hG := le_gronwallBound_of_liminf_deriv_right_le hc
    (fun t ht _ hr => (hd t ht).liminf_right_slope_le hr) (le_refl (V 0)) hb
  intro t ht
  have h := hG t ht
  rw [gronwallBound, ite_eq_right (by nlinarith : -2 * κ ≠ 0), sub_zero] at h
  unfold envelope
  convert! h using 1; ring

theorem envelope_below_cap {V₀ κ C cap t : ℝ}
    (hκ : 0 < κ) (ht : 0 ≤ t) (hV : V₀ ≤ cap) (hC : C / (2 * κ) ≤ cap) :
    envelope V₀ κ C t ≤ cap := by
  have he0 : 0 ≤ exp (-2 * κ * t) := (exp_pos _).le
  have he1 : exp (-2 * κ * t) ≤ 1 := exp_le_one_iff.mpr (by nlinarith)
  have h₁ := mul_le_mul_of_nonneg_left hV he0
  have h₂ := mul_le_mul_of_nonneg_right hC (sub_nonneg.mpr he1)
  unfold envelope; nlinarith

/-- Theorem 7.1's finite-time estimate for existing classical error trajectories.
The measurable-disturbance Caratheodory extension is not hidden in this theorem. -/
theorem robust_error_estimate {e z G d : ℝ → ℝ} {T k₀ k₁ k₂ κ κd dbar : ℝ}
    (hk₀ : 0 ≤ k₀) (hκ : 0 < κ) (hκ₁ : κ ≤ k₁) (hκ₂ : κ ≤ k₂) (hκd : 0 < κd)
    (he : ∀ t ∈ Icc 0 T, HasDerivAt e (errorRate k₁ (e t) (z t)) t)
    (hz : ∀ t ∈ Icc 0 T, HasDerivAt z (zRate k₀ k₂ κd (G t) (d t) (e t) (z t)) t)
    (hb : ∀ t ∈ Ico 0 T, |d t| ≤ dbar) :
    ∀ t ∈ Icc 0 T, errorEnergy k₀ (e t) (z t) ≤
      exp (-2 * κ * t) * errorEnergy k₀ (e 0) (z 0) +
      dbar ^ 2 / (16 * κ * κd) * (1 - exp (-2 * κ * t)) := by
  have hd := fun t ht => energy_hasDerivAt_errors (he t ht) (hz t ht)
  have hc : ContinuousOn (fun t => errorEnergy k₀ (e t) (z t)) (Icc 0 T) :=
    fun t ht => (hd t ht).continuousAt.continuousWithinAt
  have hcomp := scalar_comparison hκ hc
    (fun t ht => (hd t (Ico_subset_Icc_self ht)).hasDerivWithinAt)
    (fun t ht => robust_decay_uniform hk₀ hκ₁ hκ₂ hκd (hb t ht))
  intro t ht
  have h := hcomp t ht
  unfold envelope at h
  convert! h using 1; ring

theorem nominal_error_estimate {e z : ℝ → ℝ} {T k₀ k₁ k₂ κ : ℝ}
    (hk₀ : 0 ≤ k₀) (hκ : 0 < κ) (hκ₁ : κ ≤ k₁) (hκ₂ : κ ≤ k₂)
    (he : ∀ t ∈ Icc 0 T, HasDerivAt e (errorRate k₁ (e t) (z t)) t)
    (hz : ∀ t ∈ Icc 0 T, HasDerivAt z (zRate k₀ k₂ 0 0 0 (e t) (z t)) t) :
    ∀ t ∈ Icc 0 T, errorEnergy k₀ (e t) (z t) ≤
      exp (-2 * κ * t) * errorEnergy k₀ (e 0) (z 0) := by
  have hd := fun t ht => energy_hasDerivAt_errors (he t ht) (hz t ht)
  have hc : ContinuousOn (fun t => errorEnergy k₀ (e t) (z t)) (Icc 0 T) :=
    fun t ht => (hd t ht).continuousAt.continuousWithinAt
  have hcomp := scalar_comparison (C:=0) hκ hc
    (fun t ht => (hd t (Ico_subset_Icc_self ht)).hasDerivWithinAt) (by
      intro t ht
      simpa using nominal_decay (e:=e t) (z:=z t) hk₀ hκ₁ hκ₂)
  simpa [envelope] using hcomp

/-- The energy-level part of the robust invariant-region theorem. -/
theorem robust_energy_invariant {V V' : ℝ → ℝ} {T κ κd dbar cap : ℝ}
    (hκ : 0 < κ) (_hκd : 0 < κd)
    (hc : ContinuousOn V (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt V (V' t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, V' t ≤ -2 * κ * V t + dbar ^ 2 / (8 * κd))
    (h₀ : V 0 ≤ cap) (hcap : dbar ^ 2 / (16 * κ * κd) ≤ cap) :
    ∀ t ∈ Icc 0 T, V t ≤ cap := by
  have hb' : (dbar ^ 2 / (8 * κd)) / (2 * κ) ≤ cap := by
    convert! hcap using 1; ring
  intro t ht
  exact (scalar_comparison hκ hc hd hb t ht).trans
    (envelope_below_cap hκ ht.1 h₀ hb')

/-- Conditional crown safety, obtained from derivatives and scalar comparison. -/
theorem crown_barrier_invariant {B B' : ℝ → ℝ} {T γ : ℝ}
    (hc : ContinuousOn B (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt B (B' t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, -γ * B t ≤ B' t) (h₀ : 0 ≤ B 0) :
    ∀ t ∈ Icc 0 T, 0 ≤ B t := by
  have hcomp := le_gronwallBound_of_liminf_deriv_right_le hc.neg
    (fun t ht _ hr => (hd t ht).neg.liminf_right_slope_le hr)
    (le_refl (-B 0)) (K := -γ) (ε := 0)
    (by intro t ht; simp only [Pi.neg_apply]; linarith [hb t ht])
  intro t ht
  have h := hcomp t ht
  rw [gronwallBound_ε0] at h
  simp only [Pi.neg_apply] at h
  have hp := exp_pos (-γ * (t - 0))
  nlinarith

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.Comparison -/

/- BEGIN SOURCE MODULE: ChainFountain.Barrier -/

namespace ChainFountain
noncomputable section

def barrierLower (αhi v : ℝ) := -(1 - αhi) * v ^ 2
def barrierUpper (H g β αlo h v w γ B : ℝ) :=
  crownSq v w - (1 - αlo) * v ^ 2 - g * h +
    h * (fall H g β h v w + 2 * γ * B)

theorem pickup_endpoint_iff {αlo αhi v u : ℝ} (hα : αlo ≤ αhi) :
    (∀ α ∈ Set.Icc αlo αhi, 0 ≤ pickup α v u) ↔ barrierLower αhi v ≤ u := by
  constructor
  · intro h
    have he := h αhi ⟨hα,le_rfl⟩
    unfold pickup at he; unfold barrierLower; linarith
  · intro h α ha
    have hs := mul_nonneg (sub_nonneg.mpr ha.2) (sq_nonneg v)
    unfold pickup; unfold barrierLower at h; nlinarith

theorem crown_input_iff {H g β α h v w γ B u : ℝ} (hh : 0 < h) :
    0 ≤ (rise g α h v w u + fall H g β h v w) / 2 + γ * B ↔
      u ≤ barrierUpper H g β α h v w γ B := by
  have hid : 2 * h * ((rise g α h v w u + fall H g β h v w) / 2 + γ * B) =
      barrierUpper H g β α h v w γ B - u := by
    unfold rise barrierUpper; field_simp <;> ring
  constructor
  · intro hb
    have := mul_nonneg (by positivity : 0 ≤ 2 * h) hb; rw [hid] at this; linarith
  · intro hu
    have hp : 0 < 2 * h := by positivity
    have : 0 ≤ 2 * h * ((rise g α h v w u + fall H g β h v w) / 2 + γ * B) := by
      rw [hid]; linarith
    exact nonneg_of_mul_nonneg_right this hp

theorem crown_endpoint_iff {H g β αlo αhi h v w γ B u : ℝ}
    (hh : 0 < h) (hα : αlo ≤ αhi) :
    (∀ α ∈ Set.Icc αlo αhi,
      0 ≤ (rise g α h v w u + fall H g β h v w) / 2 + γ * B) ↔
      u ≤ barrierUpper H g β αlo h v w γ B := by
  constructor
  · intro hb; exact (crown_input_iff hh).mp (hb αlo ⟨le_rfl,hα⟩)
  · intro hu α ha
    apply (crown_input_iff hh).mpr
    have hs := mul_nonneg (sub_nonneg.mpr ha.1) (sq_nonneg v)
    unfold barrierUpper at *; nlinarith

theorem barrier_width (H g β αlo αhi h v w γ B : ℝ) (hH : H + h ≠ 0) :
    barrierUpper H g β αlo h v w γ B - barrierLower αhi v =
      (H * crownSq v w + β * h * w ^ 2) / (H + h) +
        2 * h * γ * B - (αhi - αlo) * v ^ 2 := by
  unfold barrierUpper barrierLower fall
  field_simp <;> ring

/-- Proposition 8.1's exact pointwise feasibility equivalence. -/
theorem barrier_feasible_iff {H g β αlo αhi h v w γ B : ℝ}
    (hh : 0 < h) (hH : H + h ≠ 0) (hα : αlo ≤ αhi) :
    (∃ u, (∀ α ∈ Set.Icc αlo αhi, 0 ≤ pickup α v u) ∧
      (∀ α ∈ Set.Icc αlo αhi,
        0 ≤ (rise g α h v w u + fall H g β h v w) / 2 + γ * B)) ↔
    (αhi - αlo) * v ^ 2 ≤
      (H * crownSq v w + β * h * w ^ 2) / (H + h) + 2 * h * γ * B := by
  have hw := barrier_width H g β αlo αhi h v w γ B hH
  simp_rw [pickup_endpoint_iff hα, crown_endpoint_iff hh hα]
  constructor
  · rintro ⟨u,hl,hu⟩; linarith
  · intro h; exact ⟨barrierLower αhi v,le_rfl,by linarith⟩

theorem interval_intersection_iff (amin amax L U : ℝ) :
    (∃ u, amin ≤ u ∧ u ≤ amax ∧ L ≤ u ∧ u ≤ U) ↔ max amin L ≤ min amax U := by
  constructor
  · rintro ⟨u,ha,hb,hL,hU⟩
    exact (max_le ha hL).trans (le_min hb hU)
  · intro h
    exact ⟨max amin L,le_max_left _ _,h.trans (min_le_left _ _),
      le_max_right _ _,h.trans (min_le_right _ _)⟩

def clip (L U desired : ℝ) := min U (max L desired)

theorem clip_mem {L U desired : ℝ} (h : L ≤ U) : L ≤ clip L U desired ∧ clip L U desired ≤ U := by
  unfold clip
  exact ⟨le_min h (le_max_left _ _),min_le_left _ _⟩

theorem clip_nearest {L U desired u : ℝ} (h : L ≤ U) (hu : L ≤ u ∧ u ≤ U) :
    (clip L U desired - desired) ^ 2 ≤ (u - desired) ^ 2 := by
  unfold clip
  by_cases hl : desired ≤ L
  · rw [max_eq_left hl, min_eq_right h]
    nlinarith [sq_nonneg (u-L)]
  · have hld : L ≤ desired := (lt_of_not_ge hl).le
    rw [max_eq_right hld]
    by_cases hd : U ≤ desired
    · rw [min_eq_left hd]
      nlinarith [sq_nonneg (U-u)]
    · rw [min_eq_right (lt_of_not_ge hd).le]
      simp only [sub_self, zero_pow (by decide : 2 ≠ 0)]
      exact sq_nonneg _

theorem nominal_barrier_nonempty {H g h β v w γ B α : ℝ}
    (hH : 0 < H) (hh : 0 < h) (hβ : 0 ≤ β) (hγ : 0 ≤ γ) (hB : 0 ≤ B) :
    barrierLower α v ≤ barrierUpper H g β α h v w γ B := by
  have hw := barrier_width H g β α α h v w γ B (ne_of_gt (add_pos hH hh))
  have hp : 0 ≤ (H * crownSq v w + β * h * w ^ 2) / (H+h) + 2*h*γ*B := by
    unfold crownSq; positivity
  simp only [sub_self,zero_mul,sub_zero] at hw
  linarith

/-- Appendix A.1: positive crown margin does not give an inward falling-speed face. -/
theorem counterexample_falling_speed :
    (10 + (0 : ℝ)) / 2 - 16/5 > 0 ∧
    fall 2 (981/100) (1/50) (1/10) 10 0 < 0 := by
  norm_num [fall,crownSq]

/-- Appendix A.2: both velocities positive but the robust interval is empty. -/
theorem counterexample_empty_interval (γ : ℝ) :
    barrierUpper 2 (981/100) (1/50) (3/50) 3 (63/10) (1/10) γ 0 <
      barrierLower (9/50) (63/10) := by
  norm_num [barrierUpper,barrierLower,fall,crownSq]

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.Barrier -/

/- BEGIN SOURCE MODULE: ChainFountain.Region -/

namespace ChainFountain
noncomputable section
open Real Set

def internal (H g β h w q : ℝ) : ℝ :=
  (g * (H + h) - (1 - β) * w ^ 2 - 2 * q * w - q ^ 2) / (H + h)

theorem internal_identity (H g β h w q : ℝ) (hH : H + h ≠ 0) :
    fall H g β h (w + 2*q) w = internal H g β h w q := by
  unfold fall internal crownSq; field_simp <;> ring

theorem error_height_sq {k₀ e z cap : ℝ} (hk : 0 < k₀)
    (hV : errorEnergy k₀ e z ≤ cap) : e ^ 2 ≤ 2 * cap / k₀ := by
  rw [le_div_iff₀ hk]
  unfold errorEnergy at hV; nlinarith [sq_nonneg z]

theorem error_z_sq {k₀ e z cap : ℝ} (hk : 0 ≤ k₀)
    (hV : errorEnergy k₀ e z ≤ cap) : z ^ 2 ≤ 8 * cap := by
  unfold errorEnergy at hV
  nlinarith [mul_nonneg hk (sq_nonneg e)]

/-- The weighted Cauchy--Schwarz estimate used in (6.1). -/
theorem error_q_sq {k₀ k₁ e z cap : ℝ} (hk : 0 < k₀)
    (hV : errorEnergy k₀ e z ≤ cap) :
    (z / 2 - k₁ * e) ^ 2 ≤ 2 * cap * (1 + k₁ ^ 2 / k₀) := by
  have hid : (2 * errorEnergy k₀ e z * (1 + k₁ ^ 2 / k₀) -
      (z/2-k₁*e)^2) * k₀ = (k₀ * e + k₁ * z / 2) ^ 2 := by
    unfold errorEnergy; field_simp <;> ring
  have hnon : 0 ≤ (2 * errorEnergy k₀ e z * (1 + k₁ ^ 2 / k₀) -
      (z/2-k₁*e)^2) := by
    apply nonneg_of_mul_nonneg_left (b:=k₀)
    · rw [hid]; exact sq_nonneg _
    · exact hk
  have hp : 0 ≤ 1 + k₁ ^ 2 / k₀ := by positivity
  have hm := mul_le_mul_of_nonneg_right hV hp
  linarith

theorem error_enclosure {k₀ k₁ e z cap : ℝ} (hk : 0 < k₀)
    (hV : errorEnergy k₀ e z ≤ cap) :
    |e| ≤ sqrt (2 * cap / k₀) ∧ |z| ≤ sqrt (8 * cap) ∧
    |z / 2 - k₁ * e| ≤ sqrt (2 * cap) * sqrt (1 + k₁ ^ 2 / k₀) := by
  have hc : 0 ≤ cap := (energy_nonneg hk.le e z).trans hV
  refine ⟨abs_le_sqrt (error_height_sq hk hV), abs_le_sqrt (error_z_sq hk.le hV), ?_⟩
  have h := abs_le_sqrt (error_q_sq (k₁:=k₁) hk hV)
  rwa [sqrt_mul (by positivity : 0 ≤ 2 * cap)] at h

theorem transport_positive {w q Q wlo vmin : ℝ}
    (hw : wlo ≤ w) (hq : |q| ≤ Q) (hforward : 2 * Q < wlo)
    (hcrown : vmin ≤ wlo - Q) :
    0 < w + 2 * q ∧ vmin ≤ w + q := by
  have hq' := abs_le.mp hq
  constructor <;> linarith

theorem height_enclosure {h r rlo rhi ce : ℝ}
    (hr : rlo ≤ r ∧ r ≤ rhi) (he : |h-r| ≤ ce) :
    rlo-ce ≤ h ∧ h ≤ rhi+ce := by
  have he' := abs_le.mp he; constructor <;> linarith

theorem q_enclosure {q r₁ cq R₁ : ℝ}
    (hr : |r₁| ≤ R₁) (hq : |q-r₁| ≤ cq) : |q| ≤ R₁+cq := by
  have hh := abs_add_le (q-r₁) r₁
  rw [sub_add_cancel] at hh; linarith

theorem lower_face {H g β h hlo wlo Q q : ℝ}
    (hden : 0 < H + h) (hg : 0 ≤ g) (hh : hlo ≤ h)
    (hq : |q| ≤ Q) (hw : 2 * Q < wlo)
    (hface : (1-β) * wlo^2 + 2*Q*wlo + Q^2 ≤ g*(H+hlo)) :
    0 ≤ internal H g β h wlo q := by
  have hQ : 0 ≤ Q := (abs_nonneg q).trans hq
  have hq' := abs_le.mp hq
  have hs : (wlo+q)^2 ≤ (wlo+Q)^2 := by
    apply pow_le_pow_left₀ (by linarith) (by linarith)
  have hgh := mul_le_mul_of_nonneg_left hh hg
  unfold internal
  apply div_nonneg _ hden.le
  nlinarith

theorem upper_face {H g β h hhi whi Q q : ℝ}
    (hden : 0 < H + h) (hg : 0 ≤ g) (hh : h ≤ hhi)
    (hq : |q| ≤ Q) (hw : 2 * Q < whi)
    (hface : g*(H+hhi) ≤ (1-β) * whi^2 - 2*Q*whi + Q^2) :
    internal H g β h whi q ≤ 0 := by
  have hQ : 0 ≤ Q := (abs_nonneg q).trans hq
  have hq' := abs_le.mp hq
  have hs : (whi-Q)^2 ≤ (whi+q)^2 := by
    apply pow_le_pow_left₀ (by linarith) (by linarith)
  have hgh := mul_le_mul_of_nonneg_left hh hg
  unfold internal
  apply div_nonpos_of_nonpos_of_nonneg _ hden.le
  nlinarith

/-- Difference factorization needed to integrate the inward face inequalities. -/
theorem internal_difference (H g β h w b q : ℝ) :
    internal H g β h w q - internal H g β h b q =
      -(((1-β)*(w+b)+2*q)/(H+h))*(w-b) := by
  unfold internal; ring

theorem zero_dynamics_factor (H g β r w wr : ℝ)
    (hden : H+r ≠ 0) (heq : (1-β)*wr^2=g*(H+r)) :
    internal H g β r w 0 = -(1-β)/(H+r)*(w+wr)*(w-wr) := by
  unfold internal; field_simp <;> nlinarith [heq]

theorem fullstate_forcing_identity (H g β r e q w wr : ℝ)
    (hden : H+(r+e) ≠ 0) (heq : (1-β)*wr^2=g*(H+r)) :
    internal H g β (r+e) w q =
      -(1-β)*(w+wr)/(H+(r+e))*(w-wr) +
        (g*e-2*q*w-q^2)/(H+(r+e)) := by
  unfold internal; field_simp <;> nlinarith [heq]

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.Region -/

/- BEGIN SOURCE MODULE: ChainFountain.Invariance -/

namespace ChainFountain
noncomputable section
open Set Real MeasureTheory

/-- Sign preservation for a scalar differential inequality with a continuous,
time-dependent coefficient, proved using an integrating factor and the FTC. -/
theorem linear_sign_preservation {y y' K : ℝ → ℝ} {T : ℝ}
    (hK : Continuous K) (hy : ContinuousOn y (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt y (y' t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, y' t ≤ K t * y t) (h₀ : y 0 ≤ 0) :
    ∀ t ∈ Icc 0 T, y t ≤ 0 := by
  let A : ℝ → ℝ := fun t => ∫ s in (0 : ℝ)..t, K s
  have hA : ∀ t, HasDerivAt A (K t) t := fun t =>
    intervalIntegral.integral_hasDerivAt_right (hK.intervalIntegrable _ _)
      hK.aestronglyMeasurable.stronglyMeasurableAtFilter hK.continuousAt
  have hAc : Continuous A := continuous_iff_continuousAt.mpr (fun t => (hA t).continuousAt)
  have hc : ContinuousOn (fun t => y t * exp (-A t)) (Icc 0 T) :=
    hy.mul (Real.continuous_exp.comp hAc.neg).continuousOn
  have hder : ∀ t ∈ Ico 0 T, HasDerivWithinAt (fun t => y t * exp (-A t))
      ((y' t - K t * y t) * exp (-A t)) (Ici t) t := by
    intro t ht
    convert! (hd t ht).mul ((hA t).neg.exp.hasDerivWithinAt) using 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hin : y 0 * exp (-A 0) ≤ (0 : ℝ) := mul_nonpos_of_nonpos_of_nonneg h₀ (exp_pos _).le
  have hcmp := image_le_of_deriv_right_le_deriv_boundary hc hder hin continuousOn_const
    (fun t _ => hasDerivWithinAt_const t (Ici t) (0 : ℝ)) (by
      intro t ht
      exact mul_nonpos_of_nonpos_of_nonneg (sub_nonpos.mpr (hb t ht)) (exp_pos _).le)
  intro t ht
  exact nonpos_of_mul_nonpos_left (hcmp ht) (exp_pos _)

/-- The same comparison needs continuity only on the supplied time interval. -/
theorem linear_sign_preservation_on {y y' K : ℝ → ℝ} {T : ℝ}
    (hK : ContinuousOn K (Icc 0 T)) (hy : ContinuousOn y (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt y (y' t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, y' t ≤ K t * y t) (h₀ : y 0 ≤ 0) :
    ∀ t ∈ Icc 0 T, y t ≤ 0 := by
  by_cases hT : 0 ≤ T
  · let Kext : ℝ → ℝ := fun t => K (projIcc 0 T hT t)
    have hKe : Continuous Kext := hK.comp_continuous
      (continuous_subtype_val.comp continuous_projIcc) (fun t => (projIcc 0 T hT t).property)
    have hEq : ∀ t ∈ Icc 0 T, Kext t=K t := by
      intro t ht; simp [Kext,projIcc_of_mem hT ht]
    exact linear_sign_preservation hKe hy hd (by
      intro t ht; rw [hEq t (Ico_subset_Icc_self ht)]; exact hb t ht) h₀
  · intro t ht; exfalso; exact hT (ht.1.trans ht.2)

/-- Invariance of the falling-speed interval for an existing classical trajectory.
Unlike a boundary-only check this theorem proves the time-dependent conclusion.
The two continuous coefficients are the explicitly factored Riccati differences.
It does not assert construction or global continuation of a solution. -/
theorem speed_interval_invariant {h w q : ℝ → ℝ} {H g β T wlo whi : ℝ}
    (hw : ContinuousOn w (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt w (internal H g β (h t) (w t) (q t)) (Ici t) t)
    (hKl : ContinuousOn (fun t => -((1-β)*(w t+wlo)+2*q t)/(H+h t)) (Icc 0 T))
    (hKu : ContinuousOn (fun t => -((1-β)*(w t+whi)+2*q t)/(H+h t)) (Icc 0 T))
    (hl : ∀ t ∈ Ico 0 T, 0 ≤ internal H g β (h t) wlo (q t))
    (hu : ∀ t ∈ Ico 0 T, internal H g β (h t) whi (q t) ≤ 0)
    (h₀ : wlo ≤ w 0 ∧ w 0 ≤ whi) :
    ∀ t ∈ Icc 0 T, wlo ≤ w t ∧ w t ≤ whi := by
  have hlo := linear_sign_preservation_on hKl (continuousOn_const.sub hw)
    (fun t ht => (hd t ht).const_sub wlo) (by
      intro t ht
      have hi := internal_difference H g β (h t) (w t) wlo (q t)
      have hf := hl t ht
      simp only [neg_div]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hi]) (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [h₀.1] : wlo - w 0 ≤ 0)
  have hhi := linear_sign_preservation_on hKu (hw.sub continuousOn_const)
    (fun t ht => (hd t ht).sub_const whi) (by
      intro t ht
      have hi := internal_difference H g β (h t) (w t) whi (q t)
      have hf := hu t ht
      simp only [neg_div]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hi]) (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [h₀.2] : w 0 - whi ≤ 0)
  intro t ht; exact ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hlo t ht], by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hhi t ht]⟩

/-- The geometric part of Theorem 6.1 on any supplied existence interval.
The energy estimate supplies h and q bounds independently in Region/Comparison. -/
theorem physical_region_invariant {h w q : ℝ → ℝ} {H g β T hlo hhi Q wlo whi vmin : ℝ}
    (hH : 0 < H) (hg : 0 ≤ g) (hlo0 : 0 < hlo)
    (hw : ContinuousOn w (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt w (internal H g β (h t) (w t) (q t)) (Ici t) t)
    (hKl : ContinuousOn (fun t => -((1-β)*(w t+wlo)+2*q t)/(H+h t)) (Icc 0 T))
    (hKu : ContinuousOn (fun t => -((1-β)*(w t+whi)+2*q t)/(H+h t)) (Icc 0 T))
    (hh : ∀ t ∈ Icc 0 T, hlo ≤ h t ∧ h t ≤ hhi)
    (hq : ∀ t ∈ Icc 0 T, |q t| ≤ Q)
    (hforward : 2*Q < wlo) (horder : wlo ≤ whi) (hcrown : vmin ≤ wlo-Q)
    (hl : (1-β)*wlo^2 + 2*Q*wlo + Q^2 ≤ g*(H+hlo))
    (hu : g*(H+hhi) ≤ (1-β)*whi^2 - 2*Q*whi + Q^2)
    (h₀ : wlo ≤ w 0 ∧ w 0 ≤ whi) :
    ∀ t ∈ Icc 0 T, 0 < h t ∧ wlo ≤ w t ∧ w t ≤ whi ∧
      0 < w t + 2*q t ∧ vmin ≤ w t+q t := by
  have hb := speed_interval_invariant hw hd hKl hKu (by
    intro t ht
    have htt := Ico_subset_Icc_self ht
    exact lower_face (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hh t htt).1]) hg (hh t htt).1 (hq t htt) hforward hl)
    (by
      intro t ht
      have htt := Ico_subset_Icc_self ht
      exact upper_face (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hh t htt).1]) hg (hh t htt).2 (hq t htt)
        (lt_of_lt_of_le hforward horder) hu) h₀
  intro t ht
  have hv := transport_positive (hb t ht).1 (hq t ht) hforward hcrown
  exact ⟨lt_of_lt_of_le hlo0 (hh t ht).1,(hb t ht).1,(hb t ht).2,hv.1,hv.2⟩

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.Invariance -/

/- BEGIN SOURCE MODULE: ChainFountain.Forces -/

namespace ChainFountain
noncomputable section

theorem square_interval {x lo hi : ℝ} (hlo : 0 ≤ lo) (hx : lo ≤ x ∧ x ≤ hi) :
    lo^2 ≤ x^2 ∧ x^2 ≤ hi^2 := by
  exact ⟨pow_le_pow_left₀ hlo hx.1 2, pow_le_pow_left₀ (hlo.trans hx.1) hx.2 2⟩

theorem acceleration_bound {k₀ k₁ k₂ e q r₁ r₂ ce cq R₂ : ℝ}
    (hk₀ : 0 ≤ k₀) (hk₁ : 0 ≤ k₁) (hk₂ : 0 ≤ k₂)
    (he : |e| ≤ ce) (hq : |q-r₁| ≤ cq) (hr : |r₂| ≤ R₂) :
    |acceleration k₀ k₁ k₂ e q r₁ r₂| ≤
      R₂+(k₁+k₂)*cq+(k₀+k₁*k₂)*ce := by
  unfold acceleration
  have h₁ := abs_sub r₂ ((k₁+k₂)*(q-r₁))
  have h₂ := abs_sub (r₂-(k₁+k₂)*(q-r₁)) ((k₀+k₁*k₂)*e)
  rw [abs_mul, abs_of_nonneg (by positivity : 0 ≤ k₁+k₂)] at h₁
  rw [abs_mul, abs_of_nonneg (by positivity : 0 ≤ k₀+k₁*k₂)] at h₂
  have h₃ := mul_le_mul_of_nonneg_left hq (by positivity : 0 ≤ k₁+k₂)
  have h₄ := mul_le_mul_of_nonneg_left he (by positivity : 0 ≤ k₀+k₁*k₂)
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

theorem damping_bound {κd v vmax h hlo z cz : ℝ}
    (hκd : 0 ≤ κd) (hhlo : 0 < hlo) (hh : hlo ≤ h)
    (hv : v^2 ≤ vmax^2) (hz : |z| ≤ cz) :
    |κd * v^4/h*z| ≤ κd * vmax^4/hlo*cz := by
  have hh0 : 0 < h := hhlo.trans_le hh
  have hv4 : v^4 ≤ vmax^4 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [sq_nonneg (v^2-vmax^2),sq_nonneg v,sq_nonneg vmax]
  have hdiv := div_le_div₀ (pow_nonneg (sq_nonneg vmax) 2) (show (v^2)^2 ≤ (vmax^2)^2 by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hv4]) hhlo hh
  have hdiv' : v^4/h ≤ vmax^4/hlo := by simpa only [←pow_mul] using hdiv
  have hm := mul_le_mul_of_nonneg_left hdiv' hκd
  have hprod := mul_le_mul hm hz (abs_nonneg z) (by positivity : 0 ≤ κd*(vmax^4/hlo))
  rw [abs_mul,abs_of_nonneg (by positivity : 0 ≤ κd*v^4/h)]
  convert! hprod using 1 <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

def lowerInputBound (H g α β hlo hhi vhi slo whi A D : ℝ) :=
  slo^2-(1-α)*vhi^2-2*g*hhi-β*hhi*whi^2/(H+hlo)-2*hhi*A-D
def upperInputBound (H g α hlo hhi vlo shi A D : ℝ) :=
  (1+hhi/(H+hlo))*shi^2-(1-α)*vlo^2-2*g*hlo+2*hhi*A+D
def lowerTensionBound (H g β hlo hhi slo whi A : ℝ) :=
  slo^2-hhi*(2*g+β*whi^2/(H+hlo)+2*A)

/-- Proposition 6.3's input enclosure, with explicit state-box hypotheses. -/
theorem force_box_bounds {H g α β h hLo hHi v vLo vHi w wHi sLo sHi A Amax D damp : ℝ}
    (hH : 0 < H) (hg : 0 ≤ g) (ha : α ≤ 1) (hb : 0 ≤ β)
    (hhLo : 0 < hLo) (hh : hLo ≤ h ∧ h ≤ hHi)
    (hv : vLo^2 ≤ v^2 ∧ v^2 ≤ vHi^2)
    (hw : w^2 ≤ wHi^2) (hs : sLo^2 ≤ crownSq v w ∧ crownSq v w ≤ sHi^2)
    (hA : |A| ≤ Amax) (hd : |damp| ≤ D) :
    lowerInputBound H g α β hLo hHi vHi sLo wHi Amax D ≤
      nominalInput H g α β h v w A+damp ∧
    nominalInput H g α β h v w A+damp ≤
      upperInputBound H g α hLo hHi vLo sHi Amax D := by
  have hh0 : 0 < h := hhLo.trans_le hh.1
  have hhHi : 0 < hHi := hh0.trans_le hh.2
  have hden : 0 < H+hLo := add_pos hH hhLo
  have hden' : 0 < H+h := add_pos hH hh0
  have ha0 : 0 ≤ 1-α := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hS : 0 ≤ crownSq v w := by unfold crownSq; positivity
  have hr0 : 0 ≤ h/(H+h) := by positivity
  have hr : h/(H+h) ≤ hHi/(H+hLo) := div_le_div₀ hhHi.le hh.2 hden (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith)
  have hlS : sLo^2 ≤ (1+h/(H+h))*crownSq v w := by
    have hp := mul_nonneg hr0 hS; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hs.1]
  have huS : (1+h/(H+h))*crownSq v w ≤ (1+hHi/(H+hLo))*sHi^2 := by
    exact mul_le_mul (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) hs.2 hS (by positivity)
  have hvL := mul_le_mul_of_nonneg_left hv.1 ha0
  have hvU := mul_le_mul_of_nonneg_left hv.2 ha0
  have hgL := mul_le_mul_of_nonneg_left hh.1 hg
  have hgU := mul_le_mul_of_nonneg_left hh.2 hg
  have hbn : 0 ≤ β*h*w^2/(H+h) := by positivity
  have hbnum : β*h*w^2 ≤ β*hHi*wHi^2 :=
    mul_le_mul (mul_le_mul_of_nonneg_left hh.2 hb) hw (sq_nonneg w) (by positivity)
  have hbU := div_le_div₀ (by positivity : 0 ≤ β*hHi*wHi^2) hbnum hden (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith : H+hLo ≤ H+h)
  have hA0 : 0 ≤ Amax := (abs_nonneg A).trans hA
  have hAA : |2*h*A| ≤ 2*hHi*Amax := by
    rw [abs_mul,abs_of_nonneg (by positivity : 0 ≤ 2*h)]
    exact mul_le_mul (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) hA (abs_nonneg A) (by positivity)
  have hAA' := abs_le.mp hAA
  have hd' := abs_le.mp hd
  unfold lowerInputBound upperInputBound nominalInput
  constructor <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

/-- Pickup-tension enclosure, using the same interval estimates. -/
theorem tension_box_bound {H g α β h hLo hHi v vHi w wHi sLo A Amax D damp d dbar : ℝ}
    (hH : 0 < H) (hg : 0 ≤ g) (hb : 0 ≤ β)
    (hhLo : 0 < hLo) (hh : hLo ≤ h ∧ h ≤ hHi)
    (hv : v^2 ≤ vHi^2) (hw : w^2 ≤ wHi^2)
    (hs : sLo^2 ≤ crownSq v w) (hA : |A| ≤ Amax)
    (hd : |damp| ≤ D) (hdd : |d| ≤ dbar) :
    lowerTensionBound H g β hLo hHi sLo wHi Amax-D-dbar*vHi^2 ≤
      pickup (α+d) v (nominalInput H g α β h v w A+damp) := by
  have hh0 : 0 < h := hhLo.trans_le hh.1
  have hhHi : 0 < hHi := hh0.trans_le hh.2
  have hden : 0 < H+hLo := add_pos hH hhLo
  have hS : 0 ≤ crownSq v w := by unfold crownSq; positivity
  have hp := mul_nonneg (show 0 ≤ h/(H+h) by positivity) hS
  have hgU := mul_le_mul_of_nonneg_left hh.2 hg
  have hbnum : β*h*w^2 ≤ β*hHi*wHi^2 :=
    mul_le_mul (mul_le_mul_of_nonneg_left hh.2 hb) hw (sq_nonneg w) (by positivity)
  have hbU := div_le_div₀ (by positivity : 0 ≤ β*hHi*wHi^2) hbnum hden (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith : H+hLo ≤ H+h)
  have hAA : |2*h*A| ≤ 2*hHi*Amax := by
    rw [abs_mul,abs_of_nonneg (by positivity : 0 ≤ 2*h)]
    exact mul_le_mul (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) hA (abs_nonneg A) (by positivity)
  have hAA' := abs_le.mp hAA
  have hd' := abs_le.mp hd
  have hdd' := abs_le.mp hdd
  have hdb0 : 0 ≤ dbar := (abs_nonneg d).trans hdd
  have hdv : d*v^2 ≤ dbar*vHi^2 := mul_le_mul hdd'.2 hv (sq_nonneg v) hdb0
  unfold lowerTensionBound pickup nominalInput
  have hrearr : hHi*(β*wHi^2/(H+hLo)) = β*hHi*wHi^2/(H+hLo) := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hrearr]

/-- Proposition 6.3 assembled for the actual damped input and uncertain pickup. -/
theorem robust_force_feasibility
    {H g α β h hLo hHi v vLo vHi w wHi sLo sHi A Amax κd z cz d dbar uLo uHi : ℝ}
    (hH : 0 < H) (hg : 0 ≤ g) (ha : α ≤ 1) (hb : 0 ≤ β)
    (hhLo : 0 < hLo) (hh : hLo ≤ h ∧ h ≤ hHi)
    (hv : vLo^2 ≤ v^2 ∧ v^2 ≤ vHi^2) (hw : w^2 ≤ wHi^2)
    (hs : sLo^2 ≤ crownSq v w ∧ crownSq v w ≤ sHi^2)
    (hA : |A| ≤ Amax) (hκd : 0 ≤ κd) (hz : |z| ≤ cz) (hd : |d| ≤ dbar)
    (hL : uLo ≤ lowerInputBound H g α β hLo hHi vHi sLo wHi Amax (κd*vHi^4/hLo*cz))
    (hU : upperInputBound H g α hLo hHi vLo sHi Amax (κd*vHi^4/hLo*cz) ≤ uHi)
    (hT : 0 ≤ lowerTensionBound H g β hLo hHi sLo wHi Amax-κd*vHi^4/hLo*cz-dbar*vHi^2) :
    uLo ≤ robustInput H g α β h v w A κd z ∧
      robustInput H g α β h v w A κd z ≤ uHi ∧
      0 ≤ pickup (α+d) v (robustInput H g α β h v w A κd z) := by
  have hD := damping_bound hκd hhLo hh.1 hv.2 hz
  have hF := force_box_bounds hH hg ha hb hhLo hh hv hw hs hA hD
  have hP := tension_box_bound (α:=α) hH hg hb hhLo hh hv.2 hw hs.1 hA hD hd
  exact ⟨hL.trans hF.1,hF.2.trans hU,hT.trans hP⟩

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.Forces -/

/- BEGIN SOURCE MODULE: ChainFountain.Trajectories -/

namespace ChainFountain
noncomputable section
open Set Real

def heightError (h r : ℝ → ℝ) (t : ℝ) := h t-r t
def velocityError (k₁ : ℝ) (h v w r r₁ : ℝ → ℝ) (t : ℝ) :=
  v t-w t-2*r₁ t+2*k₁*(h t-r t)
def requestedInput (H g α β k₀ k₁ k₂ κd : ℝ)
    (h v w r r₁ r₂ : ℝ → ℝ) (t : ℝ) :=
  robustInput H g α β (h t) (v t) (w t)
    (acceleration k₀ k₁ k₂ (heightError h r t) (heightRate (v t) (w t)) (r₁ t) (r₂ t))
    κd (velocityError k₁ h v w r r₁ t)

/-- The coordinate change is proved using derivatives of the mechanical states,
not imposed as an independent error-system axiom. -/
theorem closed_loop_error_equations {H g α β k₀ k₁ k₂ κd d t : ℝ}
    {h v w r r₁ r₂ : ℝ → ℝ}
    (hh : h t ≠ 0) (hH : H+h t ≠ 0)
    (dh : HasDerivAt h (heightRate (v t) (w t)) t)
    (dv : HasDerivAt v (rise g (α+d) (h t) (v t) (w t)
      (requestedInput H g α β k₀ k₁ k₂ κd h v w r r₁ r₂ t)) t)
    (dw : HasDerivAt w (fall H g β (h t) (v t) (w t)) t)
    (dr : HasDerivAt r (r₁ t) t) (dr₁ : HasDerivAt r₁ (r₂ t) t) :
    HasDerivAt (heightError h r)
      (errorRate k₁ (heightError h r t) (velocityError k₁ h v w r r₁ t)) t ∧
    HasDerivAt (velocityError k₁ h v w r r₁)
      (zRate k₀ k₂ κd ((v t)^2/h t) d (heightError h r t)
        (velocityError k₁ h v w r r₁ t)) t := by
  have he : HasDerivAt (heightError h r) (heightRate (v t) (w t)-r₁ t) t := dh.sub dr
  refine ⟨?_, ?_⟩
  · convert! he using 1
    exact (transformed_error_rate k₁ (h t) (r t) (v t) (w t) (r₁ t)).symm
  · have hz := ((dv.sub dw).sub (dr₁.const_mul 2)).add (he.const_mul (2*k₁))
    have ha := robust_acceleration H g α β (h t) (v t) (w t)
      (acceleration k₀ k₁ k₂ (heightError h r t) (heightRate (v t) (w t)) (r₁ t) (r₂ t))
      κd (velocityError k₁ h v w r r₁ t) d hh hH
    have heq : velocityError k₁ h v w r r₁ t =
        2*(heightRate (v t) (w t)-r₁ t+k₁*heightError h r t) := by
      unfold velocityError heightRate heightError; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    have halg := transformed_z_rate k₀ k₁ k₂ (heightError h r t)
      (heightRate (v t) (w t)) (r₁ t) (r₂ t) κd ((v t)^2/h t) d
      (velocityError k₁ h v w r r₁ t) heq
    convert! hz using 1
    unfold requestedInput
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [ha,halg]

/-- Theorem 7.1's tracking estimate starting from the actual controlled ODE.
Existence and differentiability on the stated interval are explicit hypotheses. -/
theorem mechanical_tracking_estimate {H g α β k₀ k₁ k₂ κ κd dbar T : ℝ}
    {h v w r r₁ r₂ d : ℝ → ℝ}
    (hk₀ : 0 ≤ k₀) (hκ : 0 < κ) (hk₁ : κ ≤ k₁) (hk₂ : κ ≤ k₂) (hκd : 0 < κd)
    (hh : ∀ t ∈ Icc 0 T, h t ≠ 0) (hH : ∀ t ∈ Icc 0 T, H+h t ≠ 0)
    (dh : ∀ t ∈ Icc 0 T, HasDerivAt h (heightRate (v t) (w t)) t)
    (dv : ∀ t ∈ Icc 0 T, HasDerivAt v (rise g (α+d t) (h t) (v t) (w t)
      (requestedInput H g α β k₀ k₁ k₂ κd h v w r r₁ r₂ t)) t)
    (dw : ∀ t ∈ Icc 0 T, HasDerivAt w (fall H g β (h t) (v t) (w t)) t)
    (dr : ∀ t ∈ Icc 0 T, HasDerivAt r (r₁ t) t)
    (dr₁ : ∀ t ∈ Icc 0 T, HasDerivAt r₁ (r₂ t) t)
    (hdb : ∀ t ∈ Ico 0 T, |d t| ≤ dbar) :
    ∀ t ∈ Icc 0 T,
      errorEnergy k₀ (heightError h r t) (velocityError k₁ h v w r r₁ t) ≤
      exp (-2*κ*t) * errorEnergy k₀ (heightError h r 0) (velocityError k₁ h v w r r₁ 0) +
        dbar^2/(16*κ*κd)*(1-exp (-2*κ*t)) := by
  have heq := fun t ht => closed_loop_error_equations (hh t ht) (hH t ht)
    (dh t ht) (dv t ht) (dw t ht) (dr t ht) (dr₁ t ht)
  exact robust_error_estimate hk₀ hκ hk₁ hk₂ hκd
    (fun t ht => (heq t ht).1) (fun t ht => (heq t ht).2) hdb

/-- Converts the weighted error bound into the height and rate box used by the
invariance proof. No bounds on either transport velocity are assumed here. -/
theorem trajectory_enclosure {k₀ k₁ cap rlo rhi R₁ : ℝ}
    {h v w r r₁ : ℝ → ℝ} {t : ℝ}
    (hk₀ : 0 < k₀)
    (hV : errorEnergy k₀ (heightError h r t) (velocityError k₁ h v w r r₁ t) ≤ cap)
    (hr : rlo ≤ r t ∧ r t ≤ rhi) (hr₁ : |r₁ t| ≤ R₁) :
    rlo-sqrt (2*cap/k₀) ≤ h t ∧ h t ≤ rhi+sqrt (2*cap/k₀) ∧
      |heightRate (v t) (w t)| ≤ R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀) := by
  obtain ⟨he,_,hq⟩ := error_enclosure (k₁:=k₁) hk₀ hV
  have hhb := height_enclosure hr he
  have hid : velocityError k₁ h v w r r₁ t/2 - k₁*heightError h r t =
      heightRate (v t) (w t)-r₁ t := by unfold velocityError heightError heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [hid] at hq
  exact ⟨hhb.1,hhb.2,q_enclosure hr₁ hq⟩

/-- Connects the state speed to the internal Riccati equation without assuming v=w. -/
theorem mechanical_internal_equation {h v w : ℝ → ℝ} {H g β t : ℝ}
    (hden : H+h t ≠ 0)
    (hw : HasDerivAt w (fall H g β (h t) (v t) (w t)) t) :
    HasDerivAt w (internal H g β (h t) (w t) (heightRate (v t) (w t))) t := by
  have hcoord : w t+2*heightRate (v t) (w t) = v t := by unfold heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have heq := internal_identity H g β (h t) (w t) (heightRate (v t) (w t)) hden
  rw [hcoord] at heq
  rwa [←heq]

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.Trajectories -/

/- BEGIN SOURCE MODULE: ChainFountain.Certificate -/

namespace ChainFountain
noncomputable section
open Set Real

/-- Data of an existing classical solution. Fields are modelling/regularity
assumptions only; no tracking, safety, or convergence conclusion is a field. -/
structure ClassicalSolution (H g α β k₀ k₁ k₂ κd T : ℝ) where
  h : ℝ → ℝ
  v : ℝ → ℝ
  w : ℝ → ℝ
  r : ℝ → ℝ
  r₁ : ℝ → ℝ
  r₂ : ℝ → ℝ
  d : ℝ → ℝ
  h_ne : ∀ t ∈ Icc 0 T, h t ≠ 0
  Hh_ne : ∀ t ∈ Icc 0 T, H+h t ≠ 0
  dh : ∀ t ∈ Icc 0 T, HasDerivAt h (heightRate (v t) (w t)) t
  dv : ∀ t ∈ Icc 0 T, HasDerivAt v (rise g (α+d t) (h t) (v t) (w t)
    (requestedInput H g α β k₀ k₁ k₂ κd h v w r r₁ r₂ t)) t
  dw : ∀ t ∈ Icc 0 T, HasDerivAt w (fall H g β (h t) (v t) (w t)) t
  dr : ∀ t ∈ Icc 0 T, HasDerivAt r (r₁ t) t
  dr₁ : ∀ t ∈ Icc 0 T, HasDerivAt r₁ (r₂ t) t

def ClassicalSolution.V {H g α β k₀ k₁ k₂ κd T : ℝ}
    (sol : ClassicalSolution H g α β k₀ k₁ k₂ κd T) (t : ℝ) :=
  errorEnergy k₀ (heightError sol.h sol.r t) (velocityError k₁ sol.h sol.v sol.w sol.r sol.r₁ t)

theorem ClassicalSolution.energy_bound {H g α β k₀ k₁ k₂ κ κd dbar T : ℝ}
    (sol : ClassicalSolution H g α β k₀ k₁ k₂ κd T)
    (hk₀ : 0 ≤ k₀) (hκ : 0 < κ) (hk₁ : κ ≤ k₁) (hk₂ : κ ≤ k₂) (hκd : 0 < κd)
    (hdb : ∀ t ∈ Ico 0 T, |sol.d t| ≤ dbar) :
    ∀ t ∈ Icc 0 T, sol.V t ≤ exp (-2*κ*t)*sol.V 0+
      dbar^2/(16*κ*κd)*(1-exp (-2*κ*t)) :=
  mechanical_tracking_estimate hk₀ hκ hk₁ hk₂ hκd sol.h_ne sol.Hh_ne
    sol.dh sol.dv sol.dw sol.dr sol.dr₁ hdb

/-- Composed, finite-interval robust physical-region theorem. The energy cap is
derived from the controlled ODE rather than assumed along the trajectory.
Global existence, measurable-input extensions, and nonideal actuators are not
conclusions of this statement. -/
theorem ClassicalSolution.physical_region
    {H g α β k₀ k₁ k₂ κ κd dbar T cap rlo rhi R₁ wlo whi vmin : ℝ}
    (sol : ClassicalSolution H g α β k₀ k₁ k₂ κd T)
    (hH : 0 < H) (hg : 0 ≤ g) (hk₀ : 0 < k₀)
    (hκ : 0 < κ) (hk₁ : κ ≤ k₁) (hk₂ : κ ≤ k₂) (hκd : 0 < κd)
    (hdb : ∀ t ∈ Ico 0 T, |sol.d t| ≤ dbar)
    (hinit : sol.V 0 ≤ cap) (hcap : dbar^2/(16*κ*κd) ≤ cap)
    (hr : ∀ t ∈ Icc 0 T, rlo ≤ sol.r t ∧ sol.r t ≤ rhi)
    (hr₁ : ∀ t ∈ Icc 0 T, |sol.r₁ t| ≤ R₁)
    (hpositive : 0 < rlo-sqrt (2*cap/k₀))
    (hforward : 2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀)) < wlo)
    (horder : wlo ≤ whi)
    (hcrown : vmin ≤ wlo-(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀)))
    (hl : (1-β)*wlo^2+2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))*wlo+
      (R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))^2 ≤ g*(H+(rlo-sqrt (2*cap/k₀))))
    (hu : g*(H+(rhi+sqrt (2*cap/k₀))) ≤ (1-β)*whi^2-
      2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))*whi+(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))^2)
    (hw₀ : wlo ≤ sol.w 0 ∧ sol.w 0 ≤ whi) :
    ∀ t ∈ Icc 0 T, sol.V t ≤ cap ∧
      0 < sol.h t ∧ wlo ≤ sol.w t ∧ sol.w t ≤ whi ∧
      0 < sol.v t ∧ vmin ≤ (sol.v t+sol.w t)/2 := by
  have hE := sol.energy_bound hk₀.le hκ hk₁ hk₂ hκd hdb
  have hEC : ∀ t ∈ Icc 0 T, sol.V t ≤ cap := by
    intro t ht
    have henv := envelope_below_cap (C:=dbar^2/(8*κd)) hκ ht.1 hinit
      (by convert! hcap using 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring)
    have he : sol.V t ≤ envelope (sol.V 0) κ (dbar^2/(8*κd)) t := by
      convert! hE t ht using 1; unfold envelope; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    exact he.trans henv
  have hbox := fun t ht => trajectory_enclosure hk₀ (hEC t ht) (hr t ht) (hr₁ t ht)
  have hhc : ContinuousOn sol.h (Icc 0 T) := fun t ht => (sol.dh t ht).continuousAt.continuousWithinAt
  have hwc : ContinuousOn sol.w (Icc 0 T) := fun t ht => (sol.dw t ht).continuousAt.continuousWithinAt
  have hvc : ContinuousOn sol.v (Icc 0 T) := fun t ht => (sol.dv t ht).continuousAt.continuousWithinAt
  have hqc : ContinuousOn (fun t => heightRate (sol.v t) (sol.w t)) (Icc 0 T) :=
    (hvc.sub hwc).div_const 2
  have hK (b : ℝ) : ContinuousOn
      (fun t => -((1-β)*(sol.w t+b)+2*heightRate (sol.v t) (sol.w t))/(H+sol.h t)) (Icc 0 T) :=
    ((continuousOn_const.mul (hwc.add continuousOn_const)).add
      (continuousOn_const.mul hqc)).neg.div (continuousOn_const.add hhc) sol.Hh_ne
  have hphys := physical_region_invariant hH hg hpositive
    (fun t ht => (sol.dw t ht).continuousAt.continuousWithinAt)
    (fun t ht => (mechanical_internal_equation (sol.Hh_ne t (Ico_subset_Icc_self ht))
      (sol.dw t (Ico_subset_Icc_self ht))).hasDerivWithinAt)
    (hK wlo) (hK whi) (fun t ht => ⟨(hbox t ht).1,(hbox t ht).2.1⟩)
    (fun t ht => (hbox t ht).2.2) hforward horder hcrown hl hu hw₀
  intro t ht
  obtain ⟨hh,hwlo,hwhi,hv,hc⟩ := hphys t ht
  have hvId : sol.w t+2*heightRate (sol.v t) (sol.w t) = sol.v t := by unfold heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hsId : sol.w t+heightRate (sol.v t) (sol.w t) = (sol.v t+sol.w t)/2 := by unfold heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [hvId] at hv; rw [hsId] at hc
  exact ⟨hEC t ht,hh,hwlo,hwhi,hv,hc⟩

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.Certificate -/

/- BEGIN SOURCE MODULE: ChainFountain.IntegralEstimate -/

namespace ChainFountain
noncomputable section
open Set Real MeasureTheory

/-- Equation (7.5), integrated via the fundamental theorem of calculus.
Interval integrability and classical derivatives are explicit, not placeholders
for the estimate being proved. The weighted error norm squared equals 2V. -/
theorem weighted_integral_estimate {V V' d : ℝ → ℝ} {T κ κd : ℝ}
    (hT : 0 ≤ T) (hκ : 0 < κ) (hκd : 0 < κd)
    (hV : IntervalIntegrable V volume 0 T)
    (hVp : IntervalIntegrable V' volume 0 T)
    (hd : IntervalIntegrable (fun t => d t ^ 2) volume 0 T)
    (hder : ∀ t ∈ Icc 0 T, HasDerivAt V (V' t) t)
    (hbound : ∀ t ∈ Icc 0 T, V' t ≤ -2*κ*V t+d t^2/(8*κd))
    (hVT : 0 ≤ V T) :
    (∫ t in (0 : ℝ)..T, 2*V t) ≤
      V 0/κ + (1/(8*κ*κd))*(∫ t in (0 : ℝ)..T, d t^2) := by
  have hi := intervalIntegral.integral_mono_on hT hVp
    ((hV.const_mul (-2*κ)).add (hd.div_const (8*κd))) hbound
  have hFTC : (∫ t in (0 : ℝ)..T, V' t) = V T-V 0 := by
    apply intervalIntegral.integral_eq_sub_of_hasDerivAt _ hVp
    simpa only [uIcc_of_le hT] using hder
  rw [hFTC, intervalIntegral.integral_add (hV.const_mul (-2*κ)) (hd.div_const (8*κd)),
    intervalIntegral.integral_const_mul,intervalIntegral.integral_div] at hi
  rw [intervalIntegral.integral_const_mul]
  apply (mul_le_mul_iff_right₀ hκ).mp
  have hc₁ : κ*(V 0/κ) = V 0 := by field_simp
  have hc₂ : κ*(1/(8*κ*κd)) = 1/(8*κd) := by field_simp
  have hc₃ : κ*(1/(8*κ*κd)*(∫ t in (0 : ℝ)..T, d t^2)) =
      (∫ t in (0 : ℝ)..T, d t^2)/(8*κd) := by
    rw [←mul_assoc, hc₂]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [mul_add, hc₁, hc₃]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hi]

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.IntegralEstimate -/

/- BEGIN SOURCE MODULE: ChainFountain.Reference -/

namespace ChainFountain
noncomputable section
open Real

def quintic (x : ℝ) := 10*x^3-15*x^4+6*x^5
def quinticRate (x : ℝ) := 30*x^2*(1-x)^2
def quinticAcceleration (x : ℝ) := 60*x*(1-x)*(1-2*x)

theorem quintic_derivative (x : ℝ) : HasDerivAt quintic (quinticRate x) x := by
  convert! (((hasDerivAt_id x).pow 3).const_mul 10).sub
    (((hasDerivAt_id x).pow 4).const_mul 15) |>.add
    (((hasDerivAt_id x).pow 5).const_mul 6) using 1
  simp only [id_eq]; unfold quinticRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> ring

theorem quintic_second_derivative (x : ℝ) :
    HasDerivAt quinticRate (quinticAcceleration x) x := by
  convert! (((hasDerivAt_id x).pow 2).const_mul 30).mul
    (((hasDerivAt_id x).const_sub 1).pow 2) using 1
  simp only [id_eq]; unfold quinticAcceleration; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> ring

theorem quintic_endpoint_data :
    quintic 0=0 ∧ quintic 1=1 ∧ quinticRate 0=0 ∧ quinticRate 1=0 ∧
      quinticAcceleration 0=0 ∧ quinticAcceleration 1=0 := by
  norm_num [quintic,quinticRate,quinticAcceleration]

theorem quintic_rate_bound {x : ℝ} (hx : 0 ≤ x ∧ x ≤ 1) :
    |quinticRate x| ≤ 15/8 := by
  have hprod : 0 ≤ x*(1-x) := mul_nonneg hx.1 (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> linarith)
  have hprodU : x*(1-x) ≤ 1/4 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> nlinarith [sq_nonneg (x-1/2)]
  have hsq := pow_le_pow_left₀ hprod hprodU 2
  unfold quinticRate
  rw [abs_of_nonneg (by positivity)]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> nlinarith [hsq]

theorem quintic_acceleration_bound {x : ℝ} (hx : 0 ≤ x ∧ x ≤ 1) :
    |quinticAcceleration x| ≤ 10/sqrt 3 := by
  have hy : (1-2*x)^2 ≤ 1 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> nlinarith
  have hpos : 0 ≤ (4/3 : ℝ)-(1-2*x)^2 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> linarith
  have hp : 0 ≤ (225 : ℝ)*(4/3-(1-2*x)^2)*((1-2*x)^2-1/3)^2 := by positivity
  have hi : (100/3 : ℝ)-(quinticAcceleration x)^2 =
      225*(4/3-(1-2*x)^2)*((1-2*x)^2-1/3)^2 := by unfold quinticAcceleration; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> ring
  have hs : (quinticAcceleration x)^2 ≤ 100/3 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> linarith
  have hroot : sqrt (3 : ℝ)^2=3 := sq_sqrt (by norm_num)
  have hroot0 : 0 < sqrt (3 : ℝ) := sqrt_pos.mpr (by norm_num)
  apply (le_div_iff₀ hroot0).mpr
  have habs := sq_abs (quinticAcceleration x)
  have hm := mul_le_mul_of_nonneg_right hs (show 0 ≤ (3 : ℝ) by norm_num)
  have hneg := abs_nonneg (quinticAcceleration x)
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> nlinarith [sq_nonneg (|quinticAcceleration x| * sqrt 3-10)]

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.Reference -/

/- BEGIN SOURCE MODULE: ChainFountain.Convergence -/

namespace ChainFountain
noncomputable section
open Set Real

/-- A checked comparison for a stable scalar equation with exponentially
decaying forcing. The constant M is an explicit supersolution amplitude. -/
theorem scalar_exponential_decay {y a f : ℝ → ℝ} {T ρ δ M : ℝ}
    (ha : ContinuousOn a (Icc 0 T))
    (hy : ContinuousOn y (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt y (-a t*y t+f t) (Ici t) t)
    (hM : 0 ≤ M)
    (hdecay : ∀ t ∈ Ico 0 T, ρ+δ ≤ a t)
    (hforce : ∀ t ∈ Ico 0 T, |f t| ≤ δ*M*exp (-ρ*t))
    (hinit : |y 0| ≤ M) :
    ∀ t ∈ Icc 0 T, |y t| ≤ M*exp (-ρ*t) := by
  have hE (t : ℝ) : HasDerivAt (fun s => M*exp (-ρ*s))
      (-ρ*(M*exp (-ρ*t))) t := by
    convert! (((hasDerivAt_id t).const_mul (-ρ)).exp.const_mul M) using 1; simp only [id_eq]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hEc : Continuous (fun t => M*exp (-ρ*t)) := by fun_prop
  have hup := linear_sign_preservation_on ha.neg (hy.sub hEc.continuousOn)
    (fun t ht => (hd t ht).sub (hE t).hasDerivWithinAt) (by
      intro t ht
      have hp := mul_le_mul_of_nonneg_right (hdecay t ht)
        (mul_nonneg hM (exp_pos (-ρ*t)).le)
      have hf := (abs_le.mp (hforce t ht)).2
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith) (by simpa using (sub_nonpos.mpr (abs_le.mp hinit).2))
  have hlo := linear_sign_preservation_on ha.neg (hy.neg.sub hEc.continuousOn)
    (fun t ht => (hd t ht).neg.sub (hE t).hasDerivWithinAt) (by
      intro t ht
      have hp := mul_le_mul_of_nonneg_right (hdecay t ht)
        (mul_nonneg hM (exp_pos (-ρ*t)).le)
      have hf := (abs_le.mp (hforce t ht)).1
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith) (by simpa using (show -y 0-M ≤ 0 by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(abs_le.mp hinit).1]))
  intro t ht
  exact abs_le.mpr ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hlo t ht],by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hup t ht]⟩

/-- Explicit amplitude for every rate strictly below the damping and forcing
rates, including the equal-rate case without a singular convolution formula. -/
theorem forced_exponential_estimate {y a f : ℝ → ℝ} {T a₀ κ ρ F : ℝ}
    (ha : ContinuousOn a (Icc 0 T))
    (hy : ContinuousOn y (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt y (-a t*y t+f t) (Ici t) t)
    (hρ : ρ < a₀) (hκ : ρ ≤ κ) (hF : 0 ≤ F)
    (hdecay : ∀ t ∈ Ico 0 T, a₀ ≤ a t)
    (hforce : ∀ t ∈ Ico 0 T, |f t| ≤ F*exp (-κ*t)) :
    ∀ t ∈ Icc 0 T, |y t| ≤ (|y 0|+F/(a₀-ρ))*exp (-ρ*t) := by
  have hδ : 0 < a₀-ρ := sub_pos.mpr hρ
  have hamp : F ≤ (a₀-ρ)*(|y 0|+F/(a₀-ρ)) := by
    have hid : (a₀-ρ)*(F/(a₀-ρ))=F := by field_simp
    rw [mul_add,hid]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_nonneg hδ.le (abs_nonneg (y 0))]
  apply scalar_exponential_decay (δ:=a₀-ρ) ha hy hd (by positivity)
    (by intro t ht; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hdecay t ht])
    (by
      intro t ht
      have he : exp (-κ*t) ≤ exp (-ρ*t) := exp_le_exp.mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [ht.1])
      exact (hforce t ht).trans ((mul_le_mul_of_nonneg_left he hF).trans
        (mul_le_mul_of_nonneg_right hamp (exp_pos _).le)))
    (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [div_nonneg hF hδ.le])

/-- The forcing term in the internal-state equation inherits the tracking rate. -/
theorem internal_forcing_bound {g e q w D D₀ Ce Cq W κ t : ℝ}
    (hD₀ : 0 < D₀) (hD : D₀ ≤ D) (hCe : 0 ≤ Ce) (hCq : 0 ≤ Cq)
    (hW : 0 ≤ W) (hκ : 0 ≤ κ) (ht : 0 ≤ t)
    (he : |e| ≤ Ce*exp (-κ*t)) (hq : |q| ≤ Cq*exp (-κ*t))
    (hw : |w| ≤ W) :
    |(g*e-2*q*w-q^2)/D| ≤
      ((|g| *Ce+2*Cq*W+Cq^2)/D₀)*exp (-κ*t) := by
  have hE0 : 0 ≤ exp (-κ*t) := (exp_pos _).le
  have hE1 : exp (-κ*t) ≤ 1 := exp_le_one_iff.mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith)
  have he' := mul_le_mul_of_nonneg_left he (abs_nonneg g)
  have hq' := mul_le_mul hq hw (abs_nonneg w) (by positivity : 0 ≤ Cq*exp (-κ*t))
  have hq2 : q^2 ≤ Cq^2*exp (-κ*t) := by
    have hq0 : |q| ≤ Cq := hq.trans (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith)
    have hm := mul_le_mul hq hq0 (abs_nonneg q) (by positivity : 0 ≤ Cq*exp (-κ*t))
    rw [←sq, sq_abs] at hm
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
  have hn : |g*e-2*q*w-q^2| ≤ (|g| *Ce+2*Cq*W+Cq^2)*exp (-κ*t) := by
    have h₁ := abs_sub (g*e-2*q*w) (q^2)
    have h₂ := abs_sub (g*e) (2*q*w)
    simp only [abs_mul,abs_of_nonneg (sq_nonneg q),abs_of_nonneg (show (0:ℝ) ≤ 2 by norm_num)] at h₁ h₂
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
  have hDpos : 0 < D := hD₀.trans_le hD
  rw [abs_div,abs_of_pos hDpos]
  calc
    |g*e-2*q*w-q^2|/D ≤ ((|g| *Ce+2*Cq*W+Cq^2)*exp (-κ*t))/D :=
      div_le_div_of_nonneg_right hn hDpos.le
    _ ≤ ((|g| *Ce+2*Cq*W+Cq^2)*exp (-κ*t))/D₀ :=
      div_le_div_of_nonneg_left (by positivity) hD₀ hD
    _ = _ := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- Exponential energy decay yields exponential coordinate bounds, with exact
constants from the weighted energy ellipsoid. -/
theorem error_decay_enclosure {k₀ k₁ e z V₀ κ t : ℝ} (hk : 0 < k₀)
    (hV₀ : 0 ≤ V₀)
    (hV : errorEnergy k₀ e z ≤ exp (-2*κ*t)*V₀) :
    |e| ≤ sqrt (2*V₀/k₀)*exp (-κ*t) ∧
    |z/2-k₁*e| ≤ (sqrt (2*V₀)*sqrt (1+k₁^2/k₀))*exp (-κ*t) := by
  have he := error_height_sq hk hV
  have hq := error_q_sq (k₁:=k₁) hk hV
  have hexp : exp (-κ*t)^2=exp (-2*κ*t) := by rw [sq,←exp_add]; congr 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hs₁ : sqrt (2*V₀/k₀)^2=2*V₀/k₀ := sq_sqrt (by positivity)
  have hs₂ : sqrt (2*V₀)^2=2*V₀ := sq_sqrt (by positivity)
  have hs₃ : sqrt (1+k₁^2/k₀)^2=1+k₁^2/k₀ := sq_sqrt (by positivity)
  constructor
  · apply abs_le_of_sq_le_sq _ (by positivity)
    rw [mul_pow,hs₁,hexp]
    convert! he using 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  · apply abs_le_of_sq_le_sq _ (by positivity)
    rw [mul_pow,mul_pow,hs₂,hs₃,hexp]
    convert! hq using 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- Constant-reference internal-speed convergence on an existing classical
trajectory. Geometric bounds come from the physical-region theorem; e and q
decay bounds come from error_decay_enclosure and nominal tracking. -/
theorem internal_exponential_estimate {h w q : ℝ → ℝ}
    {H g β r wr T hlo hhi wlo whi Ce Cq κ ρ : ℝ}
    (hhc : ContinuousOn h (Icc 0 T)) (hwc : ContinuousOn w (Icc 0 T))
    (hHlo : 0 < H+hlo) (hβ : β < 1) (hwr : 0 ≤ wr) (hwlo : 0 < wlo)
    (hCe : 0 ≤ Ce) (hCq : 0 ≤ Cq) (hκ : 0 ≤ κ)
    (hh : ∀ t ∈ Icc 0 T, hlo ≤ h t ∧ h t ≤ hhi)
    (hw : ∀ t ∈ Icc 0 T, wlo ≤ w t ∧ w t ≤ whi)
    (heq : (1-β)*wr^2=g*(H+r))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt w (internal H g β (h t) (w t) (q t)) (Ici t) t)
    (he : ∀ t ∈ Ico 0 T, |h t-r| ≤ Ce*exp (-κ*t))
    (hq : ∀ t ∈ Ico 0 T, |q t| ≤ Cq*exp (-κ*t))
    (hρ : ρ < (1-β)*(wlo+wr)/(H+hhi)) (hρκ : ρ ≤ κ) :
    ∀ t ∈ Icc 0 T, |w t-wr| ≤
      (|w 0-wr|+((|g| *Ce+2*Cq*whi+Cq^2)/(H+hlo))/
        ((1-β)*(wlo+wr)/(H+hhi)-ρ))*exp (-ρ*t) := by
  by_cases hT : 0 ≤ T
  · have hb : 0 < 1-β := sub_pos.mpr hβ
    have hD (t) (ht : t ∈ Icc 0 T) : 0 < H+h t := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hh t ht).1]
    have hDhi : 0 < H+hhi := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hh 0 ⟨le_refl 0,hT⟩).1,(hh 0 ⟨le_refl 0,hT⟩).2]
    have hwhi : 0 ≤ whi := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hw 0 ⟨le_refl 0,hT⟩).1,(hw 0 ⟨le_refl 0,hT⟩).2]
    let a : ℝ → ℝ := fun t => (1-β)*(w t+wr)/(H+h t)
    let f : ℝ → ℝ := fun t => (g*(h t-r)-2*q t*w t-q t^2)/(H+h t)
    have ha : ContinuousOn a (Icc 0 T) :=
      (continuousOn_const.mul (hwc.add continuousOn_const)).div
        (continuousOn_const.add hhc) (fun t ht => (hD t ht).ne')
    have hder : ∀ t ∈ Ico 0 T, HasDerivWithinAt (fun t => w t-wr)
        (-a t*(w t-wr)+f t) (Ici t) t := by
      intro t ht
      have hi := fullstate_forcing_identity H g β r (h t-r) (q t) (w t) wr
        (by simpa only [add_sub_cancel] using (hD t (Ico_subset_Icc_self ht)).ne') heq
      simp only [add_sub_cancel] at hi
      convert! (hd t ht).sub_const wr using 1
      simpa only [sub_zero,a,f,neg_mul,neg_div] using hi.symm
    apply forced_exponential_estimate ha (hwc.sub continuousOn_const) hder hρ hρκ
      (by positivity)
    · intro t ht
      have htt := Ico_subset_Icc_self ht
      apply (div_le_div_iff₀ hDhi (hD t htt)).mpr
      have h₁ := mul_le_mul_of_nonneg_left (show H+h t ≤ H+hhi by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hh t htt).2])
        (show 0 ≤ (1-β)*(wlo+wr) by positivity)
      have h₂ := mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_left (show wlo+wr ≤ w t+wr by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hw t htt).1])
          (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith : 0 ≤ 1-β)) hDhi.le
      exact h₁.trans h₂
    · intro t ht
      have htt := Ico_subset_Icc_self ht
      exact internal_forcing_bound hHlo (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hh t htt).1]) hCe hCq hwhi hκ ht.1
        (he t ht) (hq t ht) (by rw [abs_of_pos (hwlo.trans_le (hw t htt).1)]; exact (hw t htt).2)
  · intro t ht; exact False.elim (hT (ht.1.trans ht.2))

/-- The rising speed inherits the slower internal/error decay rate. -/
theorem rising_speed_decay {w q wr M Cq κ ρ t : ℝ}
    (hCq : 0 ≤ Cq) (ht : 0 ≤ t) (hρκ : ρ ≤ κ)
    (hw : |w-wr| ≤ M*exp (-ρ*t)) (hq : |q| ≤ Cq*exp (-κ*t)) :
    |w+2*q-wr| ≤ (M+2*Cq)*exp (-ρ*t) := by
  have he : exp (-κ*t) ≤ exp (-ρ*t) := exp_le_exp.mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith)
  have hq' := hq.trans (mul_le_mul_of_nonneg_left he hCq)
  have ha := abs_add_le (w-wr) (2*q)
  simp only [abs_mul,abs_of_nonneg (show (0:ℝ) ≤ 2 by norm_num)] at ha
  have hid : w-wr+2*q=w+2*q-wr := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [hid] at ha
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith

/-- Full-state exponential convergence for a supplied global classical
trajectory. This composes the internal-speed estimate with the tracking bounds;
it does not assert that such a global trajectory has been constructed. -/
theorem constant_reference_fullstate_convergence {h w q : ℝ → ℝ}
    {H g β r wr hlo hhi wlo whi Ce Cq κ ρ : ℝ}
    (hhc : ContinuousOn h (Ici 0)) (hwc : ContinuousOn w (Ici 0))
    (hHlo : 0 < H+hlo) (hβ : β < 1) (hwr : 0 ≤ wr) (hwlo : 0 < wlo)
    (hCe : 0 ≤ Ce) (hCq : 0 ≤ Cq) (hρ0 : 0 < ρ)
    (hh : ∀ t ∈ Ici 0, hlo ≤ h t ∧ h t ≤ hhi)
    (hw : ∀ t ∈ Ici 0, wlo ≤ w t ∧ w t ≤ whi)
    (heq : (1-β)*wr^2=g*(H+r))
    (hd : ∀ t ∈ Ici 0, HasDerivAt w (internal H g β (h t) (w t) (q t)) t)
    (he : ∀ t ∈ Ici 0, |h t-r| ≤ Ce*exp (-κ*t))
    (hq : ∀ t ∈ Ici 0, |q t| ≤ Cq*exp (-κ*t))
    (hρ : ρ < (1-β)*(wlo+wr)/(H+hhi)) (hρκ : ρ ≤ κ) :
    let M := |w 0-wr|+((|g| * Ce+2*Cq*whi+Cq^2)/(H+hlo))/
      ((1-β)*(wlo+wr)/(H+hhi)-ρ)
    0 < ρ ∧ ∀ t ∈ Ici 0,
      |h t-r| ≤ Ce*exp (-ρ*t) ∧
      |w t-wr| ≤ M*exp (-ρ*t) ∧
      |w t+2*q t-wr| ≤ (M+2*Cq)*exp (-ρ*t) := by
  dsimp only
  refine ⟨hρ0,?_⟩
  intro t ht
  have hb := internal_exponential_estimate (T:=t)
    (hhc.mono (fun _ hx => hx.1)) (hwc.mono (fun _ hx => hx.1))
    hHlo hβ hwr hwlo hCe hCq (hρ0.le.trans hρκ)
    (fun s hs => hh s hs.1) (fun s hs => hw s hs.1) heq
    (fun s hs => (hd s hs.1).hasDerivWithinAt)
    (fun s hs => he s hs.1) (fun s hs => hq s hs.1) hρ hρκ t ⟨ht,le_refl t⟩
  have heE : exp (-κ*t) ≤ exp (-ρ*t) := exp_le_exp.mpr (by
    have ht0 : 0 ≤ t := ht
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith)
  exact ⟨(he t ht).trans (mul_le_mul_of_nonneg_left heE hCe),hb,
    rising_speed_decay hCq ht hρκ hb (hq t ht)⟩

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.Convergence -/

/- BEGIN SOURCE MODULE: ChainFountain.GlobalODE -/

namespace ChainFountain
noncomputable section
open Set Metric Filter
open scoped Topology NNReal

/-- Construct a global classical solution of a bounded vector field which is
uniformly Lipschitz in the state and continuous in time. Picard--Lindelof is
applied on every finite interval; uniqueness makes the resulting curves agree.
No solution is included among the hypotheses. -/
theorem bounded_lipschitz_global_exists
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    {F : ℝ → E → E} {L : ℝ≥0} {C : ℝ}
    (hL : ∀ t, LipschitzWith L (F t))
    (hcont : ∀ x, Continuous (fun t => F t x))
    (hC : ∀ t x, ‖F t x‖ ≤ C) (x₀ : E) :
    ∃ x : ℝ → E, x 0 = x₀ ∧ ∀ t, HasDerivAt x (F t (x t)) t := by
  have hC0 : 0 ≤ C := (norm_nonneg _).trans (hC 0 x₀)
  have hex (a : ℝ) : ∃ x : ℝ → E, x 0 = x₀ ∧
      ∀ t ∈ Ioo (-a) a, HasDerivAt x (F t (x t)) t := by
    by_cases ha : 0 < a
    · let t₀ : Icc (-a) a := ⟨0,by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith,ha.le⟩
      have hp : IsPicardLindelof F t₀ x₀ ⟨C*a,mul_nonneg hC0 ha.le⟩ 0 ⟨C,hC0⟩ L :=
        { lipschitzOnWith := fun t _ => (hL t).lipschitzOnWith
          continuousOn := fun x _ => (hcont x).continuousOn
          norm_le := fun t _ x _ => hC t x
          mul_max_le := by simp [t₀]; exact le_rfl }
      obtain ⟨x,hx,hd⟩ := hp.exists_eq_forall_mem_Icc_hasDerivWithinAt₀
      exact ⟨x,hx,fun t ht => (hd t (Ioo_subset_Icc_self ht)).hasDerivAt
        (Icc_mem_nhds ht.1 ht.2)⟩
    · exact ⟨fun _ => x₀,rfl,fun t ht => False.elim (ha (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [ht.1,ht.2]))⟩
  choose f hf hd using hex
  have agree {a b : ℝ} (ha : 0 < a) (hab : a ≤ b) :
      EqOn (f a) (f b) (Ioo (-a) a) := by
    apply ODE_solution_unique_of_mem_Ioo (s:=fun _ => univ)
      (fun t _ => (hL t).lipschitzOnWith) (t₀:=0) ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith,ha⟩
      (fun t ht => ⟨hd a t ht, mem_univ _⟩)
      (fun t ht => ⟨hd b t ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [ht.1],lt_of_lt_of_le ht.2 hab⟩,mem_univ _⟩)
    rw [hf a,hf b]
  let x : ℝ → E := fun t => f (|t|+1) t
  have heq (a : ℝ) : EqOn x (f a) (Ioo (-a) a) := by
    intro t ht
    by_cases hlt : |t|+1 < a
    · exact agree (by positivity) hlt.le (abs_lt.mp (lt_add_one _))
    · exact (agree (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [ht.1,ht.2]) (not_lt.mp hlt) ht).symm
  refine ⟨x,by simp [x,hf],?_⟩
  intro t
  have ht : t ∈ Ioo (-(|t|+1)) (|t|+1) := abs_lt.mp (lt_add_one _)
  have hevent : x =ᶠ[𝓝 t] f (|t|+1) :=
    Filter.eventuallyEq_iff_exists_mem.mpr
      ⟨Ioo (-(|t|+1)) (|t|+1),Ioo_mem_nhds ht.1 ht.2,heq _⟩
  rw [heq _ ht]
  exact (hd _ t ht).congr_of_eventuallyEq hevent

/-- A first-exit argument with a closed outer set and an interior target.
The supplied implication must be an a priori estimate on *every* finite
prefix, not an assumption that the constructed curve is safe. -/
theorem no_exit_of_prefix_bound
    {E : Type*} [TopologicalSpace E] {x : ℝ → E} {B K : Set E}
    (hx : Continuous x) (hB : IsClosed B) (hKB : K ⊆ interior B)
    (hx₀ : x 0 ∈ interior B)
    (hprefix : ∀ T ≥ 0, (∀ t ∈ Icc 0 T, x t ∈ B) → x T ∈ K) :
    ∀ t ≥ 0, x t ∈ K := by
  have hstay : ∀ T ≥ 0, ∀ t ∈ Icc 0 T, x t ∈ interior B := by
    intro T hT
    by_contra hn
    push Not at hn
    let S := Icc 0 T ∩ x ⁻¹' (interior B)ᶜ
    have hS : IsCompact S := isCompact_Icc.inter_right
      (isOpen_interior.isClosed_compl.preimage hx)
    have hSne : S.Nonempty := by
      obtain ⟨t,ht,hxt⟩ := hn
      exact ⟨t,ht,hxt⟩
    obtain ⟨a,ha,hle⟩ := hS.exists_isLeast hSne
    have ha0 : 0 < a := lt_of_le_of_ne ha.1.1 (by
      intro hh; subst a; exact ha.2 hx₀)
    have hbefore : ∀ t ∈ Ico 0 a, x t ∈ interior B := by
      intro t ht
      by_contra hnot
      have := hle (show t ∈ S from ⟨⟨ht.1,ht.2.le.trans ha.1.2⟩,hnot⟩)
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [ht.2]
    have hclosed : ∀ t ∈ Icc 0 a, x t ∈ B := by
      intro t ht
      have hsub : Ico 0 a ⊆ x ⁻¹' B := fun s hs => (interior_subset (s:=B)) (hbefore s hs)
      have hc := closure_minimal hsub (hB.preimage hx)
      rw [closure_Ico ha0.ne] at hc
      exact hc ht
    exact ha.2 (hKB (hprefix a ha.1.1 hclosed))
  intro t ht
  exact hprefix t ht (fun s hs => interior_subset (hstay t ht s hs))

/-- Global construction from a bounded Lipschitz extension and a proved
finite-prefix estimate. The retraction is only used in the construction;
the resulting forward trajectory solves the original vector field. -/
theorem global_exists_of_retraction_and_prefix
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    {F : ℝ → E → E} {B K : Set E} {P : E → E} {L : ℝ≥0} {C : ℝ}
    (hB : IsClosed B) (hKB : K ⊆ interior B)
    (hP : LipschitzWith 1 P) (hPB : ∀ x, P x ∈ B)
    (hPid : ∀ x ∈ B, P x = x)
    (hL : ∀ t, LipschitzOnWith L (F t) B)
    (hcont : ∀ x ∈ B, Continuous (fun t => F t x))
    (hC : ∀ t x, x ∈ B → ‖F t x‖ ≤ C)
    (x₀ : E) (hx₀ : x₀ ∈ interior B)
    (hprefix : ∀ (x : ℝ → E) T, 0 ≤ T → x 0 = x₀ →
      (∀ t ∈ Icc 0 T, x t ∈ B) →
      (∀ t ∈ Icc 0 T, HasDerivAt x (F t (x t)) t) → x T ∈ K) :
    ∃ x : ℝ → E, x 0 = x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (F t (x t)) t) ∧ ∀ t ≥ 0, x t ∈ K := by
  have hLp : ∀ t, LipschitzWith L (fun x => F t (P x)) := by
    intro t
    have hh := (hL t).comp (hP.lipschitzOnWith (s:=univ)) (fun x _ => hPB x)
    simpa only [mul_one, lipschitzOnWith_univ, Function.comp_def] using hh
  obtain ⟨x,hx₀',hd⟩ := bounded_lipschitz_global_exists hLp
    (fun x => hcont (P x) (hPB x)) (fun t x => hC t (P x) (hPB x)) x₀
  have hx : Continuous x := continuous_iff_continuousAt.mpr (fun t => (hd t).continuousAt)
  have hstay := no_exit_of_prefix_bound hx hB hKB (hx₀' ▸ hx₀) (by
    intro T hT hxb
    exact hprefix x T hT hx₀' hxb (fun t ht => by
      simpa only [hPid (x t) (hxb t ht)] using hd t))
  exact ⟨x,hx₀',fun t ht => by
    simpa only [hPid (x t) (interior_subset (hKB (hstay t ht)))] using hd t,hstay⟩

/-- Smoothness on an open domain supplies quantitative Lipschitz and size
bounds on a compact convex subset. This is used on state/parameter boxes. -/
theorem smooth_compact_convex_bounds
    {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    {f : E → F} {U S : Set E}
    (hU : IsOpen U) (hf : ContDiffOn ℝ 1 f U)
    (hS : IsCompact S) (hc : Convex ℝ S) (hSU : S ⊆ U) :
    ∃ L : ℝ≥0, ∃ C : ℝ, LipschitzOnWith L f S ∧ ∀ x ∈ S, ‖f x‖ ≤ C := by
  obtain ⟨C,hC⟩ := hS.exists_bound_of_continuousOn (hf.continuousOn.mono hSU)
  obtain ⟨D,hD⟩ := hS.exists_bound_of_continuousOn
    ((hf.continuousOn_fderiv_of_isOpen hU le_rfl).mono hSU)
  refine ⟨⟨max D 0,le_max_right _ _⟩,C,?_,hC⟩
  rw [lipschitzOnWith_iff_norm_sub_le]
  intro x hx y hy
  exact hc.norm_image_sub_le_of_norm_fderiv_le
    (fun z hz => ((hf z (hSU hz)).contDiffAt (hU.mem_nhds (hSU hz))).differentiableAt (by norm_num))
    (fun z hz => (hD z hz).trans (le_max_left D 0)) hy hx

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.GlobalODE -/

/- BEGIN SOURCE MODULE: ChainFountain.ExistenceBounds -/

namespace ChainFountain
noncomputable section
open Set Real

/-- The zero-disturbance estimate includes both the nominal controller and any
nonnegative additional damping. It is derived from the mechanical equations. -/
theorem ClassicalSolution.nominal_damped_energy_bound
    {H g α β k₀ k₁ k₂ κ κd T : ℝ}
    (sol : ClassicalSolution H g α β k₀ k₁ k₂ κd T)
    (hk₀ : 0 ≤ k₀) (hκ : 0 < κ) (hk₁ : κ ≤ k₁) (hk₂ : κ ≤ k₂)
    (hκd : 0 ≤ κd) (hdzero : ∀ t ∈ Ico 0 T, sol.d t = 0) :
    ∀ t ∈ Icc 0 T, sol.V t ≤ exp (-2*κ*t)*sol.V 0 := by
  have heq := fun t ht => closed_loop_error_equations (sol.h_ne t ht) (sol.Hh_ne t ht)
    (sol.dh t ht) (sol.dv t ht) (sol.dw t ht) (sol.dr t ht) (sol.dr₁ t ht)
  have hd := fun t ht => energy_hasDerivAt_errors (heq t ht).1 (heq t ht).2
  have hc : ContinuousOn sol.V (Icc 0 T) := fun t ht =>
    (hd t ht).continuousAt.continuousWithinAt
  have hb := scalar_comparison (C:=0) hκ hc
    (fun t ht => (hd t (Ico_subset_Icc_self ht)).hasDerivWithinAt) (by
      intro t ht
      rw [hdzero t ht]
      have hn := nominal_decay (e:=heightError sol.h sol.r t)
        (z:=velocityError k₁ sol.h sol.v sol.w sol.r sol.r₁ t) hk₀ hk₁ hk₂
      have hp : 0 ≤ κd * (sol.v t ^ 2 / sol.h t)^2 *
        (velocityError k₁ sol.h sol.v sol.w sol.r sol.r₁ t)^2 / 4 := by positivity
      dsimp [ClassicalSolution.V]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith)
  simpa [envelope] using hb

/-- The geometric argument requires only an already proved energy cap. This
factorization allows the same continuation construction for nominal and robust
controllers without assuming a strictly positive robust damping gain. -/
theorem ClassicalSolution.physical_region_of_cap
    {H g α β k₀ k₁ k₂ κd T cap rlo rhi R₁ wlo whi vmin : ℝ}
    (sol : ClassicalSolution H g α β k₀ k₁ k₂ κd T)
    (hH : 0 < H) (hg : 0 ≤ g) (hk₀ : 0 < k₀)
    (hEC : ∀ t ∈ Icc 0 T, sol.V t ≤ cap)
    (hr : ∀ t ∈ Icc 0 T, rlo ≤ sol.r t ∧ sol.r t ≤ rhi)
    (hr₁ : ∀ t ∈ Icc 0 T, |sol.r₁ t| ≤ R₁)
    (hpositive : 0 < rlo-sqrt (2*cap/k₀))
    (hforward : 2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀)) < wlo)
    (horder : wlo ≤ whi)
    (hcrown : vmin ≤ wlo-(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀)))
    (hl : (1-β)*wlo^2+2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))*wlo+
      (R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))^2 ≤ g*(H+(rlo-sqrt (2*cap/k₀))))
    (hu : g*(H+(rhi+sqrt (2*cap/k₀))) ≤ (1-β)*whi^2-
      2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))*whi+(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))^2)
    (hw₀ : wlo ≤ sol.w 0 ∧ sol.w 0 ≤ whi) :
    ∀ t ∈ Icc 0 T, sol.V t ≤ cap ∧
      0 < sol.h t ∧ wlo ≤ sol.w t ∧ sol.w t ≤ whi ∧
      0 < sol.v t ∧ vmin ≤ (sol.v t+sol.w t)/2 := by
  have hbox := fun t ht => trajectory_enclosure hk₀ (hEC t ht) (hr t ht) (hr₁ t ht)
  have hhc : ContinuousOn sol.h (Icc 0 T) := fun t ht => (sol.dh t ht).continuousAt.continuousWithinAt
  have hwc : ContinuousOn sol.w (Icc 0 T) := fun t ht => (sol.dw t ht).continuousAt.continuousWithinAt
  have hvc : ContinuousOn sol.v (Icc 0 T) := fun t ht => (sol.dv t ht).continuousAt.continuousWithinAt
  have hqc : ContinuousOn (fun t => heightRate (sol.v t) (sol.w t)) (Icc 0 T) :=
    (hvc.sub hwc).div_const 2
  have hK (b : ℝ) : ContinuousOn
      (fun t => -((1-β)*(sol.w t+b)+2*heightRate (sol.v t) (sol.w t))/(H+sol.h t)) (Icc 0 T) :=
    ((continuousOn_const.mul (hwc.add continuousOn_const)).add
      (continuousOn_const.mul hqc)).neg.div (continuousOn_const.add hhc) sol.Hh_ne
  have hphys := physical_region_invariant hH hg hpositive
    (fun t ht => (sol.dw t ht).continuousAt.continuousWithinAt)
    (fun t ht => (mechanical_internal_equation (sol.Hh_ne t (Ico_subset_Icc_self ht))
      (sol.dw t (Ico_subset_Icc_self ht))).hasDerivWithinAt)
    (hK wlo) (hK whi) (fun t ht => ⟨(hbox t ht).1,(hbox t ht).2.1⟩)
    (fun t ht => (hbox t ht).2.2) hforward horder hcrown hl hu hw₀
  intro t ht
  obtain ⟨hh,hwlo,hwhi,hv,hc⟩ := hphys t ht
  have hvId : sol.w t+2*heightRate (sol.v t) (sol.w t) = sol.v t := by unfold heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hsId : sol.w t+heightRate (sol.v t) (sol.w t) = (sol.v t+sol.w t)/2 := by unfold heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [hvId] at hv; rw [hsId] at hc
  exact ⟨hEC t ht,hh,hwlo,hwhi,hv,hc⟩

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.ExistenceBounds -/

/- BEGIN SOURCE MODULE: ChainFountain.GlobalExistence -/

namespace ChainFountain
noncomputable section
open Set Real Metric
open scoped Topology NNReal

abbrev MechanicalState := ℝ × ℝ × ℝ
abbrev ReferenceParameters := ℝ × ℝ × ℝ × ℝ

/-- Pure data and checkable inequalities. There is no trajectory field and no
existence, invariance, or convergence assumption in this structure. -/
structure GlobalTrackingData where
  H : ℝ
  g : ℝ
  α : ℝ
  β : ℝ
  k₀ : ℝ
  k₁ : ℝ
  k₂ : ℝ
  κ : ℝ
  κd : ℝ
  dbar : ℝ
  cap : ℝ
  rlo : ℝ
  rhi : ℝ
  R₁ : ℝ
  R₂ : ℝ
  wlo : ℝ
  whi : ℝ
  vmin : ℝ
  r : ℝ → ℝ
  r₁ : ℝ → ℝ
  r₂ : ℝ → ℝ
  d : ℝ → ℝ
  x₀ : MechanicalState
  H_pos : 0 < H
  g_nonneg : 0 ≤ g
  k₀_pos : 0 < k₀
  κ_pos : 0 < κ
  κ_le_k₁ : κ ≤ k₁
  κ_le_k₂ : κ ≤ k₂
  κd_nonneg : 0 ≤ κd
  regime : dbar = 0 ∨ 0 < κd
  vmin_pos : 0 < vmin
  dr : ∀ t ≥ 0, HasDerivAt r (r₁ t) t
  dr₁ : ∀ t ≥ 0, HasDerivAt r₁ (r₂ t) t
  r₂_cont : ContinuousOn r₂ (Ici 0)
  d_cont : ContinuousOn d (Ici 0)
  ref_bounds : ∀ t ≥ 0, rlo ≤ r t ∧ r t ≤ rhi
  rate_bound : ∀ t ≥ 0, |r₁ t| ≤ R₁
  accel_bound : ∀ t ≥ 0, |r₂ t| ≤ R₂
  disturbance_bound : ∀ t ≥ 0, |d t| ≤ dbar
  initial_energy : errorEnergy k₀ (x₀.1-r 0)
    (x₀.2.1-x₀.2.2-2*r₁ 0+2*k₁*(x₀.1-r 0)) ≤ cap
  disturbance_cap : dbar^2/(16*κ*κd) ≤ cap
  height_positive : 0 < rlo-sqrt (2*cap/k₀)
  forward : 2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀)) < wlo
  speed_order : wlo ≤ whi
  crown : vmin ≤ wlo-(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))
  lower_face_bound : (1-β)*wlo^2+2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))*wlo+
    (R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))^2 ≤ g*(H+(rlo-sqrt (2*cap/k₀)))
  upper_face_bound : g*(H+(rhi+sqrt (2*cap/k₀))) ≤ (1-β)*whi^2-
    2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))*whi+
    (R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))^2
  initial_speed : wlo ≤ x₀.2.2 ∧ x₀.2.2 ≤ whi

def GlobalTrackingData.hlo (c : GlobalTrackingData) := c.rlo-sqrt (2*c.cap/c.k₀)
def GlobalTrackingData.hhi (c : GlobalTrackingData) := c.rhi+sqrt (2*c.cap/c.k₀)
def GlobalTrackingData.Q (c : GlobalTrackingData) := c.R₁+sqrt (2*c.cap)*sqrt (1+c.k₁^2/c.k₀)
def GlobalTrackingData.vlo (c : GlobalTrackingData) := c.wlo-2*c.Q
def GlobalTrackingData.vhi (c : GlobalTrackingData) := c.whi+2*c.Q
def GlobalTrackingData.safeBox (c : GlobalTrackingData) : Set MechanicalState :=
  Icc c.hlo c.hhi ×ˢ (Icc c.vlo c.vhi ×ˢ Icc c.wlo c.whi)
def GlobalTrackingData.outerBox (c : GlobalTrackingData) : Set MechanicalState :=
  Icc (c.hlo/2) (c.hhi+1) ×ˢ (Icc (c.vlo-1) (c.vhi+1) ×ˢ Icc (c.wlo-1) (c.whi+1))
def GlobalTrackingData.parameterBox (c : GlobalTrackingData) : Set ReferenceParameters :=
  Icc c.rlo c.rhi ×ˢ (Icc (-c.R₁) c.R₁ ×ˢ (Icc (-c.R₂) c.R₂ ×ˢ Icc (-c.dbar) c.dbar))

def GlobalTrackingData.jointField (c : GlobalTrackingData)
    (y : ReferenceParameters × MechanicalState) : MechanicalState :=
  let p := y.1
  let x := y.2
  let u := robustInput c.H c.g c.α c.β x.1 x.2.1 x.2.2
    (acceleration c.k₀ c.k₁ c.k₂ (x.1-p.1) (heightRate x.2.1 x.2.2) p.2.1 p.2.2.1)
    c.κd (x.2.1-x.2.2-2*p.2.1+2*c.k₁*(x.1-p.1))
  (heightRate x.2.1 x.2.2,
    rise c.g (c.α+p.2.2.2) x.1 x.2.1 x.2.2 u,
    fall c.H c.g c.β x.1 x.2.1 x.2.2)

/-- Clamping time only defines harmless data before zero. Forward dynamics use
the given reference and disturbance without any input clipping. -/
def GlobalTrackingData.parameters (c : GlobalTrackingData) (t : ℝ) : ReferenceParameters :=
  (c.r (max 0 t), c.r₁ (max 0 t), c.r₂ (max 0 t), c.d (max 0 t))
def GlobalTrackingData.field (c : GlobalTrackingData) (t : ℝ) (x : MechanicalState) :=
  c.jointField (c.parameters t,x)

theorem GlobalTrackingData.parameters_mem (c : GlobalTrackingData) (t : ℝ) :
    c.parameters t ∈ c.parameterBox := by
  exact ⟨c.ref_bounds _ (le_max_left _ _), abs_le.mp (c.rate_bound _ (le_max_left _ _)),
    abs_le.mp (c.accel_bound _ (le_max_left _ _)),
    abs_le.mp (c.disturbance_bound _ (le_max_left _ _))⟩

theorem GlobalTrackingData.parameters_continuous (c : GlobalTrackingData) :
    Continuous c.parameters := by
  have hr : ContinuousOn c.r (Ici 0) := fun t ht =>
    (c.dr t ht).continuousAt.continuousWithinAt
  have hr₁ : ContinuousOn c.r₁ (Ici 0) := fun t ht =>
    (c.dr₁ t ht).continuousAt.continuousWithinAt
  have hm : Continuous (fun t : ℝ => max 0 t) := continuous_const.max continuous_id
  exact (hr.comp_continuous hm (fun t => (show max 0 t ∈ Ici 0 from (le_max_left (0 : ℝ) t)))).prodMk
    ((hr₁.comp_continuous hm (fun t => (show max 0 t ∈ Ici 0 from (le_max_left (0 : ℝ) t)))).prodMk
      ((c.r₂_cont.comp_continuous hm (fun t => (show max 0 t ∈ Ici 0 from (le_max_left (0 : ℝ) t)))).prodMk
        (c.d_cont.comp_continuous hm (fun t => (show max 0 t ∈ Ici 0 from (le_max_left (0 : ℝ) t))))))

theorem GlobalTrackingData.jointField_smooth (c : GlobalTrackingData) :
    ContDiffOn ℝ 1 c.jointField {y | 0 < y.2.1} := by
  intro y hy
  have hh : y.2.1 ≠ 0 := ne_of_gt hy
  have hH : c.H+y.2.1 ≠ 0 := ne_of_gt (add_pos c.H_pos hy)
  apply ContDiffAt.contDiffWithinAt
  unfold jointField robustInput nominalInput acceleration heightRate rise fall crownSq
  fun_prop (disch := first | assumption | norm_num)

theorem GlobalTrackingData.safeBox_interior (c : GlobalTrackingData) :
    c.safeBox ⊆ interior c.outerBox := by
  intro x hx
  rcases hx with ⟨hh,hv,hw⟩
  change x ∈ interior (Icc (c.hlo/2) (c.hhi+1) ×ˢ
    (Icc (c.vlo-1) (c.vhi+1) ×ˢ Icc (c.wlo-1) (c.whi+1)))
  simp only [interior_prod_eq,interior_Icc,mem_prod,mem_Ioo]
  have hpos : 0 < c.hlo := c.height_positive
  exact ⟨⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hh.1],by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hh.2]⟩,
    ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hv.1],by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hv.2]⟩,
    ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hw.1],by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hw.2]⟩⟩

theorem GlobalTrackingData.box_of_energy_speed (c : GlobalTrackingData)
    (t : ℝ) (ht : 0 ≤ t) (x : MechanicalState)
    (hE : errorEnergy c.k₀ (x.1-c.r t)
      (x.2.1-x.2.2-2*c.r₁ t+2*c.k₁*(x.1-c.r t)) ≤ c.cap)
    (hw : c.wlo ≤ x.2.2 ∧ x.2.2 ≤ c.whi) : x ∈ c.safeBox := by
  have hb := trajectory_enclosure (h:=fun _ => x.1) (v:=fun _ => x.2.1)
    (w:=fun _ => x.2.2) c.k₀_pos hE (c.ref_bounds t ht) (c.rate_bound t ht)
  have hq := abs_le.mp hb.2.2
  change (c.hlo ≤ x.1 ∧ x.1 ≤ c.hhi) ∧
    (c.vlo ≤ x.2.1 ∧ x.2.1 ≤ c.vhi) ∧ c.wlo ≤ x.2.2 ∧ x.2.2 ≤ c.whi
  refine ⟨⟨hb.1,hb.2.1⟩,⟨?_,?_⟩,hw.1,hw.2⟩ <;>
    dsimp [vlo,vhi,Q,heightRate] at * <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

def GlobalTrackingData.project (c : GlobalTrackingData) (x : MechanicalState) : MechanicalState :=
  (max (c.hlo/2) (min (c.hhi+1) x.1),
   max (c.vlo-1) (min (c.vhi+1) x.2.1),
   max (c.wlo-1) (min (c.whi+1) x.2.2))

theorem GlobalTrackingData.project_lipschitz (c : GlobalTrackingData) :
    LipschitzWith 1 c.project := by
  have hh : LipschitzWith 1 (fun x : MechanicalState =>
      max (c.hlo/2) (min (c.hhi+1) x.1)) :=
    (LipschitzWith.prod_fst.const_min _).const_max _
  have hv : LipschitzWith 1 (fun x : MechanicalState => x.2.1) := by
    simpa using! LipschitzWith.prod_fst.comp (LipschitzWith.prod_snd (α:=ℝ) (β:=ℝ×ℝ))
  have hw : LipschitzWith 1 (fun x : MechanicalState => x.2.2) := by
    simpa using! LipschitzWith.prod_snd.comp (LipschitzWith.prod_snd (α:=ℝ) (β:=ℝ×ℝ))
  simpa only [max_self] using! hh.prodMk
    (((hv.const_min (c.vhi+1)).const_max (c.vlo-1)).prodMk
      ((hw.const_min (c.whi+1)).const_max (c.wlo-1)))

theorem GlobalTrackingData.initial_mem (c : GlobalTrackingData) : c.x₀ ∈ c.safeBox :=
  c.box_of_energy_speed 0 le_rfl c.x₀ c.initial_energy c.initial_speed

theorem GlobalTrackingData.project_mem (c : GlobalTrackingData) (x : MechanicalState) :
    c.project x ∈ c.outerBox := by
  have hx := c.initial_mem
  rcases hx with ⟨hh,hv,hw⟩
  have hp : 0 < c.hlo := c.height_positive
  exact ⟨⟨le_max_left _ _,max_le (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hh.1,hh.2]) (min_le_left _ _)⟩,
    ⟨le_max_left _ _,max_le (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hv.1,hv.2]) (min_le_left _ _)⟩,
    ⟨le_max_left _ _,max_le (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hw.1,hw.2]) (min_le_left _ _)⟩⟩

theorem GlobalTrackingData.project_eq (c : GlobalTrackingData) (x : MechanicalState)
    (hx : x ∈ c.outerBox) : c.project x = x := by
  rcases hx with ⟨hh,hv,hw⟩
  simp only [project,min_eq_right hh.2,max_eq_right hh.1,
    min_eq_right hv.2,max_eq_right hv.1,min_eq_right hw.2,max_eq_right hw.1]

theorem GlobalTrackingData.field_bounds (c : GlobalTrackingData) :
    ∃ L : ℝ≥0, ∃ C : ℝ,
      (∀ t, LipschitzOnWith L (c.field t) c.outerBox) ∧
      (∀ x ∈ c.outerBox, Continuous (fun t => c.field t x)) ∧
      ∀ t x, x ∈ c.outerBox → ‖c.field t x‖ ≤ C := by
  have hP : IsCompact c.parameterBox := isCompact_Icc.prod
    (isCompact_Icc.prod (isCompact_Icc.prod isCompact_Icc))
  have hB : IsCompact c.outerBox := isCompact_Icc.prod (isCompact_Icc.prod isCompact_Icc)
  have hcP : Convex ℝ c.parameterBox := (convex_Icc _ _).prod
    ((convex_Icc _ _).prod ((convex_Icc _ _).prod (convex_Icc _ _)))
  have hcB : Convex ℝ c.outerBox := (convex_Icc _ _).prod
    ((convex_Icc _ _).prod (convex_Icc _ _))
  have hsub : c.parameterBox ×ˢ c.outerBox ⊆ {y | 0 < y.2.1} := by
    intro y hy
    have hp : 0 < c.hlo := c.height_positive
    have hl : c.hlo/2 ≤ y.2.1 := hy.2.1.1
    change 0 < y.2.1
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  obtain ⟨L,C,hL,hC⟩ := smooth_compact_convex_bounds
    (isOpen_lt continuous_const (continuous_snd.fst)) c.jointField_smooth
    (hP.prod hB) (hcP.prod hcB) hsub
  refine ⟨L,C,?_,?_,?_⟩
  · intro t
    have hl := hL.comp (LipschitzWith.prodMk_left (c.parameters t)).lipschitzOnWith
      (fun x hx => ⟨c.parameters_mem t,hx⟩)
    simpa only [mul_one,Function.comp_def] using! hl
  · intro x hx
    exact (hL.continuousOn.comp_continuous
      (c.parameters_continuous.prodMk continuous_const)
      (fun t => ⟨c.parameters_mem t,hx⟩))
  · intro t x hx
    exact hC _ ⟨c.parameters_mem t,hx⟩

/-- This packages a finite prefix of the constructed solution for reuse of the
existing mechanical tracking theorem. Only the outer box is assumed here. -/
def GlobalTrackingData.toClassical (c : GlobalTrackingData) {x : ℝ → MechanicalState} {T : ℝ}
    (hbox : ∀ t ∈ Icc 0 T, x t ∈ c.outerBox)
    (hd : ∀ t ∈ Icc 0 T, HasDerivAt x (c.field t (x t)) t) :
    ClassicalSolution c.H c.g c.α c.β c.k₀ c.k₁ c.k₂ c.κd T where
  h := fun t => (x t).1
  v := fun t => (x t).2.1
  w := fun t => (x t).2.2
  r := c.r
  r₁ := c.r₁
  r₂ := c.r₂
  d := c.d
  h_ne := by
    intro t ht
    have hp : 0 < c.hlo := c.height_positive
    exact ne_of_gt (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hbox t ht).1.1])
  Hh_ne := by
    intro t ht
    have hp : 0 < c.hlo := c.height_positive
    exact ne_of_gt (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hbox t ht).1.1,c.H_pos])
  dh := by
    intro t ht
    simpa [field,jointField] using! hasFDerivAt_fst.comp_hasDerivAt t (hd t ht)
  dv := by
    intro t ht
    have hv := hasFDerivAt_fst.comp_hasDerivAt t
      (hasFDerivAt_snd.comp_hasDerivAt t (hd t ht))
    simpa [field,jointField,parameters,max_eq_right ht.1,requestedInput,heightError,velocityError] using! hv
  dw := by
    intro t ht
    simpa [field,jointField] using! hasFDerivAt_snd.comp_hasDerivAt t
      (hasFDerivAt_snd.comp_hasDerivAt t (hd t ht))
  dr := fun t ht => c.dr t ht.1
  dr₁ := fun t ht => c.dr₁ t ht.1

theorem GlobalTrackingData.prefix_energy (c : GlobalTrackingData)
    {x : ℝ → MechanicalState} {T : ℝ} (hx₀ : x 0 = c.x₀)
    (hbox : ∀ t ∈ Icc 0 T, x t ∈ c.outerBox)
    (hd : ∀ t ∈ Icc 0 T, HasDerivAt x (c.field t (x t)) t) :
    ∀ t ∈ Icc 0 T, (c.toClassical hbox hd).V t ≤ c.cap := by
  let sol := c.toClassical hbox hd
  have hinit : sol.V 0 ≤ c.cap := by
    simpa [ClassicalSolution.V,sol,toClassical,heightError,velocityError,hx₀] using! c.initial_energy
  have hcap0 : 0 ≤ c.cap := (energy_nonneg c.k₀_pos.le _ _).trans c.initial_energy
  rcases c.regime with hzero | hpos
  · have hdz : ∀ t ∈ Ico 0 T, sol.d t = 0 := by
      intro t ht
      have hb := c.disturbance_bound t ht.1
      rw [hzero] at hb
      exact abs_eq_zero.mp (le_antisymm hb (abs_nonneg _))
    have he := sol.nominal_damped_energy_bound c.k₀_pos.le c.κ_pos c.κ_le_k₁ c.κ_le_k₂
      c.κd_nonneg hdz
    intro t ht
    have henv := envelope_below_cap (C:=0) c.κ_pos ht.1 hinit (by simpa using! hcap0)
    exact (he t ht).trans (by simpa [envelope] using! henv)
  · have he := sol.energy_bound c.k₀_pos.le c.κ_pos c.κ_le_k₁ c.κ_le_k₂ hpos
      (fun t ht => c.disturbance_bound t ht.1)
    intro t ht
    have henv := envelope_below_cap (C:=c.dbar^2/(8*c.κd)) c.κ_pos ht.1 hinit
      (by convert! c.disturbance_cap using 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring)
    exact (he t ht).trans (by convert! henv using 1; unfold envelope; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring)

theorem GlobalTrackingData.prefix_bound (c : GlobalTrackingData)
    (x : ℝ → MechanicalState) (T : ℝ) (hT : 0 ≤ T) (hx₀ : x 0 = c.x₀)
    (hbox : ∀ t ∈ Icc 0 T, x t ∈ c.outerBox)
    (hd : ∀ t ∈ Icc 0 T, HasDerivAt x (c.field t (x t)) t) : x T ∈ c.safeBox := by
  let sol := c.toClassical hbox hd
  have hs := sol.physical_region_of_cap c.H_pos c.g_nonneg c.k₀_pos
    (c.prefix_energy hx₀ hbox hd)
    (fun t ht => c.ref_bounds t ht.1) (fun t ht => c.rate_bound t ht.1)
    c.height_positive c.forward c.speed_order c.crown c.lower_face_bound c.upper_face_bound
    (by simpa [sol,toClassical,hx₀] using! c.initial_speed) T ⟨hT,le_rfl⟩
  exact c.box_of_energy_speed T hT (x T) hs.1 ⟨hs.2.2.1,hs.2.2.2.1⟩

/-- Global existence for the actual controlled mechanical system, with continuous
bounded coefficient uncertainty. The initial state and reference are inputs;
the trajectory is constructed and the physical box follows as a conclusion. -/
theorem GlobalTrackingData.exists_global (c : GlobalTrackingData) :
    ∃ x : ℝ → MechanicalState, x 0 = c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      ∀ t ≥ 0, x t ∈ c.safeBox := by
  obtain ⟨L,C,hL,hcont,hC⟩ := c.field_bounds
  exact global_exists_of_retraction_and_prefix
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    c.project_lipschitz c.project_mem c.project_eq hL hcont hC c.x₀
    (c.safeBox_interior c.initial_mem) c.prefix_bound

/-- Forward uniqueness on the certified box. Equality is asserted only for
nonnegative times; the arbitrary backward extension is not part of the model. -/
theorem GlobalTrackingData.unique_on_nonnegative (c : GlobalTrackingData)
    {x y : ℝ → MechanicalState} (hx₀ : x 0 = c.x₀) (hy₀ : y 0 = c.x₀)
    (hdx : ∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t)
    (hdy : ∀ t ≥ 0, HasDerivAt y (c.field t (y t)) t)
    (hbx : ∀ t ≥ 0, x t ∈ c.safeBox) (hby : ∀ t ≥ 0, y t ∈ c.safeBox) :
    EqOn x y (Ici 0) := by
  obtain ⟨L,C,hL,hcont,hC⟩ := c.field_bounds
  intro T hT
  have heq := ODE_solution_unique_of_mem_Icc_right (a:=0) (b:=T) (s:=fun _ => c.outerBox)
    (fun t _ => hL t)
    (fun t ht => (hdx t ht.1).continuousAt.continuousWithinAt)
    (fun t ht => (hdx t ht.1).hasDerivWithinAt)
    (fun t ht => interior_subset (c.safeBox_interior (hbx t ht.1)))
    (fun t ht => (hdy t ht.1).continuousAt.continuousWithinAt)
    (fun t ht => (hdy t ht.1).hasDerivWithinAt)
    (fun t ht => interior_subset (c.safeBox_interior (hby t ht.1)))
    (hx₀.trans hy₀.symm)
  exact heq ⟨hT,le_rfl⟩

/-- The constructed trajectory satisfies the mechanical equations, the energy
cap, positive transport, and the requested crown margin for every t >= 0. -/
theorem GlobalTrackingData.exists_global_physical (c : GlobalTrackingData) :
    ∃ x : ℝ → MechanicalState, x 0 = c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      (∀ t ≥ 0, x t ∈ c.safeBox) ∧
      ∀ t ≥ 0,
        errorEnergy c.k₀ ((x t).1-c.r t)
          ((x t).2.1-(x t).2.2-2*c.r₁ t+2*c.k₁*((x t).1-c.r t)) ≤ c.cap ∧
        0 < (x t).1 ∧ c.wlo ≤ (x t).2.2 ∧ (x t).2.2 ≤ c.whi ∧
        0 < (x t).2.1 ∧ c.vmin ≤ ((x t).2.1+(x t).2.2)/2 := by
  obtain ⟨x,hx₀,hd,hbox⟩ := c.exists_global
  refine ⟨x,hx₀,hd,hbox,?_⟩
  intro T hT
  have hB : ∀ t ∈ Icc 0 T, x t ∈ c.outerBox :=
    fun t ht => interior_subset (c.safeBox_interior (hbox t ht.1))
  have hD := fun t (ht : t ∈ Icc 0 T) => hd t ht.1
  let sol := c.toClassical hB hD
  exact sol.physical_region_of_cap c.H_pos c.g_nonneg c.k₀_pos
    (c.prefix_energy hx₀ hB hD)
    (fun t ht => c.ref_bounds t ht.1) (fun t ht => c.rate_bound t ht.1)
    c.height_positive c.forward c.speed_order c.crown c.lower_face_bound c.upper_face_bound
    (by simpa [sol,toClassical,hx₀] using! c.initial_speed) T ⟨hT,le_rfl⟩

def GlobalTrackingData.stateEnergy (c : GlobalTrackingData) (t : ℝ) (x : MechanicalState) : ℝ :=
  errorEnergy c.k₀ (x.1-c.r t) (x.2.1-x.2.2-2*c.r₁ t+2*c.k₁*(x.1-c.r t))

/-- Global tracking with a constructed trajectory. The two implications keep
the undamped nominal case separate from the robust expression with κd > 0. -/
theorem GlobalTrackingData.exists_global_tracking (c : GlobalTrackingData) :
    ∃ x : ℝ → MechanicalState, x 0 = c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      (∀ t ≥ 0, x t ∈ c.safeBox) ∧
      (c.dbar = 0 → ∀ t ≥ 0,
        c.stateEnergy t (x t) ≤ exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀) ∧
      (0 < c.κd → ∀ t ≥ 0,
        c.stateEnergy t (x t) ≤ exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-exp (-2*c.κ*t))) := by
  obtain ⟨x,hx₀,hd,hbox⟩ := c.exists_global
  have hB (T : ℝ) : ∀ t ∈ Icc 0 T, x t ∈ c.outerBox :=
    fun t ht => interior_subset (c.safeBox_interior (hbox t ht.1))
  have hD (T : ℝ) := fun t (ht : t ∈ Icc 0 T) => hd t ht.1
  let sol (T : ℝ) := c.toClassical (hB T) (hD T)
  refine ⟨x,hx₀,hd,hbox,?_,?_⟩
  · intro hz T hT
    have hdz : ∀ t ∈ Ico 0 T, (sol T).d t = 0 := by
      intro t ht
      have hb := c.disturbance_bound t ht.1
      rw [hz] at hb
      exact abs_eq_zero.mp (le_antisymm hb (abs_nonneg _))
    have he := (sol T).nominal_damped_energy_bound c.k₀_pos.le c.κ_pos
      c.κ_le_k₁ c.κ_le_k₂ c.κd_nonneg hdz T ⟨hT,le_rfl⟩
    simpa [stateEnergy,ClassicalSolution.V,sol,toClassical,heightError,velocityError,hx₀] using! he
  · intro hp T hT
    have he := (sol T).energy_bound c.k₀_pos.le c.κ_pos c.κ_le_k₁ c.κ_le_k₂ hp
      (fun t ht => c.disturbance_bound t ht.1) T ⟨hT,le_rfl⟩
    simpa [stateEnergy,ClassicalSolution.V,sol,toClassical,heightError,velocityError,hx₀] using! he

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.GlobalExistence -/

/- BEGIN SOURCE MODULE: ChainFountain.GlobalExample -/

namespace ChainFountain
noncomputable section
open Set Real

/-- An explicit, nonstationary nominal instance: height is initially exact,
while the initial transport speed 10 differs from the steady speed sqrt(101).
This checks that the global theorem's hypotheses are jointly satisfiable. -/
def nominalGlobalExample : GlobalTrackingData where
  H := 100
  g := 1
  α := 1/4
  β := 0
  k₀ := 1
  k₁ := 1
  k₂ := 1
  κ := 1
  κd := 0
  dbar := 0
  cap := 0
  rlo := 1
  rhi := 1
  R₁ := 0
  R₂ := 0
  wlo := 5
  whi := 20
  vmin := 1
  r := fun _ => 1
  r₁ := fun _ => 0
  r₂ := fun _ => 0
  d := fun _ => 0
  x₀ := (1,10,10)
  H_pos := by norm_num
  g_nonneg := by norm_num
  k₀_pos := by norm_num
  κ_pos := by norm_num
  κ_le_k₁ := by norm_num
  κ_le_k₂ := by norm_num
  κd_nonneg := by norm_num
  regime := Or.inl rfl
  vmin_pos := by norm_num
  dr := fun t _ => hasDerivAt_const t 1
  dr₁ := fun t _ => hasDerivAt_const t 0
  r₂_cont := continuousOn_const
  d_cont := continuousOn_const
  ref_bounds := by intro t ht; norm_num
  rate_bound := by intro t ht; norm_num
  accel_bound := by intro t ht; norm_num
  disturbance_bound := by intro t ht; norm_num
  initial_energy := by norm_num [errorEnergy]
  disturbance_cap := by norm_num
  height_positive := by norm_num
  forward := by norm_num
  speed_order := by norm_num
  crown := by norm_num
  lower_face_bound := by norm_num
  upper_face_bound := by norm_num
  initial_speed := by norm_num

theorem nominal_example_global_exists :
    ∃ x : ℝ → MechanicalState, x 0 = (1,10,10) ∧
      (∀ t ≥ 0, HasDerivAt x (nominalGlobalExample.field t (x t)) t) ∧
      ∀ t ≥ 0, x t ∈ nominalGlobalExample.safeBox :=
  nominalGlobalExample.exists_global

/-- A genuinely uncertain instance, with nonzero continuous disturbance and
positive error cap, for the same geometry. -/
def robustGlobalExample : GlobalTrackingData :=
  { nominalGlobalExample with
    κd := 1
    dbar := 1/1000
    cap := 1/20000
    d := fun _ => 1/1000
    κd_nonneg := by norm_num
    regime := Or.inr (by norm_num)
    d_cont := continuousOn_const
    disturbance_bound := by
      intro t ht
      change |(1:ℝ)/1000| ≤ 1/1000
      exact le_of_eq (abs_of_nonneg (by positivity))
    initial_energy := by norm_num [nominalGlobalExample,errorEnergy]
    disturbance_cap := by norm_num [nominalGlobalExample]
    height_positive := by norm_num [nominalGlobalExample]
    forward := by
      have hs : sqrt 2 ≤ 2 := (Real.sqrt_le_iff).2 ⟨by norm_num,by norm_num⟩
      norm_num [nominalGlobalExample]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
    crown := by
      have hs : sqrt 2 ≤ 2 := (Real.sqrt_le_iff).2 ⟨by norm_num,by norm_num⟩
      norm_num [nominalGlobalExample]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
    lower_face_bound := by
      have hs : sqrt 2 ≤ 2 := (Real.sqrt_le_iff).2 ⟨by norm_num,by norm_num⟩
      have hsq : (sqrt 2)^2=2 := Real.sq_sqrt (by norm_num)
      norm_num [nominalGlobalExample]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
    upper_face_bound := by
      have hs : sqrt 2 ≤ 2 := (Real.sqrt_le_iff).2 ⟨by norm_num,by norm_num⟩
      have hsq : (sqrt 2)^2=2 := Real.sq_sqrt (by norm_num)
      norm_num [nominalGlobalExample]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith }

theorem robust_example_global_exists :
    ∃ x : ℝ → MechanicalState, x 0 = (1,10,10) ∧
      (∀ t ≥ 0, HasDerivAt x (robustGlobalExample.field t (x t)) t) ∧
      ∀ t ≥ 0, x t ∈ robustGlobalExample.safeBox :=
  robustGlobalExample.exists_global

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.GlobalExample -/

/- BEGIN SOURCE MODULE: ChainFountain.SteadyCompletion -/

namespace ChainFountain
noncomputable section
open Set Real

/-- The reverse inverse identity completes the affine input/height bijection. -/
theorem height_input_inverse (H g α β u : ℝ)
    (hg : g ≠ 0) (hβ : 1-β ≠ 0) (hαβ : 1-α-β ≠ 0) :
    steadyInput H g α β (heightFromInput H g α β u) = u := by
  unfold steadyInput heightFromInput
  field_simp
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem steady_input_antitone {H g α β : ℝ}
    (hg : 0 < g) (hβ : 0 < 1-β) (hαβ : 0 < 1-α-β) :
    StrictAnti (steadyInput H g α β) := by
  intro a b hab
  unfold steadyInput
  apply (div_lt_div_iff_of_pos_right hβ).mpr
  exact mul_lt_mul_of_pos_left (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith) hg

/-- Exact actuator interval, with the reversed height endpoints. -/
theorem steady_actuator_interval {H g α β r uLo uHi : ℝ}
    (hg : 0 < g) (hβ : 0 < 1-β) (hαβ : 0 < 1-α-β) :
    steadyInput H g α β r ∈ Icc uLo uHi ↔
      r ∈ Icc (heightFromInput H g α β uHi) (heightFromInput H g α β uLo) := by
  have hanti := steady_input_antitone (H:=H) hg hβ hαβ
  have hinv := height_input_inverse H g α β
  constructor
  · intro h
    constructor
    · by_contra hn
      have hc := hanti (lt_of_not_ge hn)
      rw [hinv uHi hg.ne' hβ.ne' hαβ.ne'] at hc
      exact (not_lt_of_ge h.2) hc
    · by_contra hn
      have hc := hanti (lt_of_not_ge hn)
      rw [hinv uLo hg.ne' hβ.ne' hαβ.ne'] at hc
      exact (not_lt_of_ge h.1) hc
  · rintro ⟨hl,hu⟩
    constructor
    · have h := hanti.antitone hu
      rwa [hinv uLo hg.ne' hβ.ne' hαβ.ne'] at h
    · have h := hanti.antitone hl
      rwa [hinv uHi hg.ne' hβ.ne' hαβ.ne'] at h

/-- Positive equilibrium uniqueness includes unequal-speed candidate states. -/
theorem positive_equilibrium_iff {H g α β r v w u : ℝ}
    (hH : 0 < H) (hg : 0 < g) (hβ : β < 1) (hr : 0 < r) (hv : 0 < v) :
    (heightRate v w = 0 ∧ rise g α r v w u = 0 ∧ fall H g β r v w = 0) ↔
      (v = sqrt (steadySpeedSq H g β r) ∧ w = v ∧ u = steadyInput H g α β r) := by
  have hden : H+r ≠ 0 := (add_pos hH hr).ne'
  have hb : 1-β ≠ 0 := (sub_pos.mpr hβ).ne'
  have hbpos : 0 < 1-β := sub_pos.mpr hβ
  constructor
  · rintro ⟨hq,hu,hf⟩
    have hw : w=v := by unfold heightRate at hq; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
    rw [hw] at hu hf
    obtain ⟨hs,hi⟩ := (steady_state_iff hr.ne' hden hb).mp ⟨hu,hf⟩
    refine ⟨?_,hw,hi⟩
    rw [←hs, sqrt_sq_eq_abs,abs_of_pos hv]
  · rintro ⟨hs,rfl,rfl⟩
    apply steady_is_equilibrium hr.ne' hden hb
    rw [hs,sq_sqrt]
    unfold steadySpeedSq
    positivity

theorem steady_input_coefficient_monotone {H g β r : ℝ}
    (hg : 0 ≤ g) (hβ : 0 < 1-β) (hHr : 0 ≤ H+r) :
    Monotone (fun α => steadyInput H g α β r) := by
  intro a b hab
  unfold steadyInput
  apply (div_le_div_iff_of_pos_right hβ).mpr
  apply mul_le_mul_of_nonneg_left _ hg
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_nonneg (sub_nonneg.mpr hab) hHr]

/-- Both coefficient endpoints are necessary and sufficient for all coefficients. -/
theorem steady_uncertain_endpoints {H g β r aLo aHi uLo uHi : ℝ}
    (hg : 0 ≤ g) (hβ : 0 < 1-β) (hHr : 0 ≤ H+r) (ha : aLo ≤ aHi) :
    (∀ α ∈ Icc aLo aHi, steadyInput H g α β r ∈ Icc uLo uHi) ↔
      (uLo ≤ steadyInput H g aLo β r ∧ steadyInput H g aHi β r ≤ uHi) := by
  have hm := steady_input_coefficient_monotone hg hβ hHr
  constructor
  · intro h
    exact ⟨(h aLo ⟨le_rfl,ha⟩).1,(h aHi ⟨ha,le_rfl⟩).2⟩
  · rintro ⟨hl,hu⟩ a ⟨hal,hau⟩
    exact ⟨hl.trans (hm hal),(hm hau).trans hu⟩

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.SteadyCompletion -/

/- BEGIN SOURCE MODULE: ChainFountain.GlobalConvergence -/

namespace ChainFountain
noncomputable section
open Set Real

/-- Corollary 6.2 with the global trajectory constructed, not supplied.
Only data, a constant reference, zero disturbance bound and a decay rate are inputs. -/
theorem GlobalTrackingData.exists_global_convergent (c : GlobalTrackingData)
    (hd : c.dbar = 0) (hβ : c.β < 1) (r wr ρ : ℝ)
    (hr : ∀ t ≥ 0, c.r t = r) (hr₁ : ∀ t ≥ 0, c.r₁ t = 0)
    (hwr : 0 ≤ wr) (heq : (1-c.β)*wr^2=c.g*(c.H+r))
    (hρ0 : 0 < ρ) (hρ : ρ < (1-c.β)*(c.wlo+wr)/(c.H+c.hhi)) (hρκ : ρ ≤ c.κ) :
    let Ce := sqrt (2*c.stateEnergy 0 c.x₀/c.k₀)
    let Cq := sqrt (2*c.stateEnergy 0 c.x₀)*sqrt (1+c.k₁^2/c.k₀)
    let M := |c.x₀.2.2-wr|+((|c.g| *Ce+2*Cq*c.whi+Cq^2)/(c.H+c.hlo))/
      ((1-c.β)*(c.wlo+wr)/(c.H+c.hhi)-ρ)
    ∃ x : ℝ → MechanicalState, x 0 = c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      (∀ t ≥ 0, x t ∈ c.safeBox) ∧
      ∀ t ≥ 0, |(x t).1-r| ≤ Ce*exp (-ρ*t) ∧
        |(x t).2.2-wr| ≤ M*exp (-ρ*t) ∧
        |(x t).2.1-wr| ≤ (M+2*Cq)*exp (-ρ*t) := by
  dsimp only
  obtain ⟨x,hx,hdx,hbox,hdec,_⟩ := c.exists_global_tracking
  let Ce := sqrt (2*c.stateEnergy 0 c.x₀/c.k₀)
  let Cq := sqrt (2*c.stateEnergy 0 c.x₀)*sqrt (1+c.k₁^2/c.k₀)
  have he (t : ℝ) (ht : 0 ≤ t) :
      |(x t).1-r| ≤ Ce*exp (-c.κ*t) ∧
      |heightRate (x t).2.1 (x t).2.2| ≤ Cq*exp (-c.κ*t) := by
    have hh := error_decay_enclosure (k₁:=c.k₁) c.k₀_pos
      (energy_nonneg c.k₀_pos.le _ _) (hdec hd t ht)
    simp only [hr t ht,hr₁ t ht,mul_zero,sub_zero] at hh
    convert! hh using 2 <;> dsimp [Ce,Cq,heightRate] <;> congr 1 <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hc : ContinuousOn x (Ici 0) := fun t ht => (hdx t ht).continuousAt.continuousWithinAt
  have hR : 0 ≤ c.R₁ := (abs_nonneg _).trans (c.rate_bound 0 le_rfl)
  have hQ : 0 ≤ c.Q := by dsimp [Q]; positivity
  have hwlo : 0 < c.wlo := by have := c.forward; change 2*c.Q < c.wlo at this; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hwd (t : ℝ) (ht : 0 ≤ t) : HasDerivAt (fun s => (x s).2.2)
      (internal c.H c.g c.β (x t).1 (x t).2.2 (heightRate (x t).2.1 (x t).2.2)) t := by
    have hw := hasFDerivAt_snd.comp_hasDerivAt t
      (hasFDerivAt_snd.comp_hasDerivAt t (hdx t ht))
    convert! hw using 1
    dsimp [field,jointField,internal,fall,crownSq,heightRate]
    have hden : c.H+(x t).1 ≠ 0 := (add_pos c.H_pos (lt_of_lt_of_le c.height_positive (hbox t ht).1.1)).ne'
    field_simp
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have result := constant_reference_fullstate_convergence
    (hc.fst) (hc.snd.snd) (add_pos c.H_pos c.height_positive) hβ hwr hwlo
    (show 0 ≤ Ce by positivity) (show 0 ≤ Cq by positivity) hρ0
    (fun t ht => (hbox t ht).1) (fun t ht => (hbox t ht).2.2) heq
    hwd (fun t ht => (he t ht).1) (fun t ht => (he t ht).2) hρ hρκ
  refine ⟨x,hx,hdx,hbox,?_⟩
  intro t ht
  have h := result.2 t ht
  rw [hx] at h
  have hid : (x t).2.2+2*heightRate (x t).2.1 (x t).2.2-wr = (x t).2.1-wr := by
    unfold heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [hid] at h
  exact h

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.GlobalConvergence -/

/- BEGIN SOURCE MODULE: ChainFountain.ReferenceCompletion -/

namespace ChainFountain
noncomputable section
open Set Real Filter
open scoped Topology

/-- C1 gluing at a single junction, proved from the two one-sided derivatives. -/
theorem derivative_glue {f g f' g' : ℝ → ℝ} (a : ℝ)
    (hf : ∀ x, HasDerivAt f (f' x) x) (hg : ∀ x, HasDerivAt g (g' x) x)
    (hval : f a=g a) (hslope : f' a=g' a) (x : ℝ) :
    HasDerivAt (fun t => if t ≤ a then f t else g t)
      (if x ≤ a then f' x else g' x) x := by
  rcases lt_trichotomy x a with hlt | he | hgt
  · rw [ite_eq_left hlt.le]
    apply (hf x).congr_of_eventuallyEq
    filter_upwards [eventually_lt_nhds hlt] with t ht
    exact ite_eq_left ht.le
  · subst x
    rw [ite_eq_left le_rfl]
    have hl : HasDerivWithinAt (fun t => if t ≤ a then f t else g t) (f' a) (Iic a) a :=
      (hf a).hasDerivWithinAt.congr (fun t ht => ite_eq_left ht) (ite_eq_left le_rfl)
    have hr : HasDerivWithinAt (fun t => if t ≤ a then f t else g t) (f' a) (Ici a) a := by
      rw [hslope]
      apply (hg a).hasDerivWithinAt.congr
      · intro t ht
        by_cases h : t ≤ a
        · have : t=a := le_antisymm h ht
          simpa [this] using! hval
        · exact ite_eq_right h
      · simpa using! hval
    have hu := hl.union hr
    rw [Iic_union_Ici] at hu
    exact hu.hasDerivAt (by simp)
  · rw [ite_eq_right (not_le.mpr hgt)]
    apply (hg x).congr_of_eventuallyEq
    filter_upwards [eventually_gt_nhds hgt] with t ht
    exact ite_eq_right (not_le.mpr ht)

def cappedQuintic (x : ℝ) := if x ≤ 0 then 0 else if x ≤ 1 then quintic x else 1
def cappedRate (x : ℝ) := if x ≤ 0 then 0 else if x ≤ 1 then quinticRate x else 0
def cappedAcceleration (x : ℝ) := if x ≤ 0 then 0 else if x ≤ 1 then quinticAcceleration x else 0

theorem capped_quintic_derivative (x : ℝ) :
    HasDerivAt cappedQuintic (cappedRate x) x := by
  apply derivative_glue 0 (fun t => hasDerivAt_const t 0)
    (derivative_glue 1 quintic_derivative (fun t => hasDerivAt_const t 1)
      (by norm_num [quintic]) (by norm_num [quinticRate]))
    (by norm_num [quintic]) (by norm_num [quinticRate])

theorem capped_quintic_second_derivative (x : ℝ) :
    HasDerivAt cappedRate (cappedAcceleration x) x := by
  apply derivative_glue 0 (fun t => hasDerivAt_const t 0)
    (derivative_glue 1 quintic_second_derivative (fun t => hasDerivAt_const t 0)
      (by norm_num [quinticRate]) (by norm_num [quinticAcceleration]))
    (by norm_num [quinticRate]) (by norm_num [quinticAcceleration])

theorem capped_acceleration_continuous : Continuous cappedAcceleration := by
  have hp : Continuous quinticAcceleration := by unfold quinticAcceleration; fun_prop
  have hinner : Continuous (fun x : ℝ => if x ≤ 1 then quinticAcceleration x else 0) := by
    apply Continuous.if _ hp continuous_const
    intro x hx
    have : x=1 := by simpa only [show {x : ℝ | x ≤ 1}=Iic 1 from rfl,frontier_Iic,mem_singleton_iff] using! hx
    simp [this,quinticAcceleration]
  apply Continuous.if _ continuous_const hinner
  intro x hx
  have : x=0 := by simpa only [show {x : ℝ | x ≤ 0}=Iic 0 from rfl,frontier_Iic,mem_singleton_iff] using! hx
  simp [this,quinticAcceleration]

/-- The constant extension is genuinely C2 across both junctions. -/
theorem capped_quintic_C2 : ContDiff ℝ 2 cappedQuintic := by
  have hd : deriv cappedQuintic=cappedRate := funext (fun x => (capped_quintic_derivative x).deriv)
  have hdd : deriv cappedRate=cappedAcceleration := funext (fun x => (capped_quintic_second_derivative x).deriv)
  rw [show (2 : WithTop ℕ∞)=1+1 from rfl,contDiff_succ_iff_deriv]
  refine ⟨fun x => (capped_quintic_derivative x).differentiableAt,by norm_num,?_⟩
  rw [hd,contDiff_one_iff_deriv,hdd]
  exact ⟨fun x => (capped_quintic_second_derivative x).differentiableAt,capped_acceleration_continuous⟩

theorem capped_quintic_bounds (x : ℝ) :
    |cappedRate x| ≤ 15/8 ∧ |cappedAcceleration x| ≤ 10/sqrt 3 := by
  by_cases hx : x ≤ 0
  · norm_num [cappedRate,cappedAcceleration,hx]; positivity
  · by_cases hx1 : x ≤ 1
    · simpa [cappedRate,cappedAcceleration,hx,hx1] using!
        And.intro (quintic_rate_bound ⟨(lt_of_not_ge hx).le,hx1⟩)
          (quintic_acceleration_bound ⟨(lt_of_not_ge hx).le,hx1⟩)
    · norm_num [cappedRate,cappedAcceleration,hx,hx1]; positivity

def transition (r₀ r₁ T t : ℝ) := r₀+(r₁-r₀)*cappedQuintic (t/T)

theorem transition_C2 (r₀ r₁ T : ℝ) : ContDiff ℝ 2 (transition r₀ r₁ T) := by
  unfold transition
  exact contDiff_const.add (contDiff_const.mul (capped_quintic_C2.comp (contDiff_id.div_const T)))

theorem transition_derivatives (r₀ r₁ T t : ℝ) :
    HasDerivAt (transition r₀ r₁ T) ((r₁-r₀)*cappedRate (t/T)/T) t ∧
    HasDerivAt (fun s => (r₁-r₀)*cappedRate (s/T)/T)
      ((r₁-r₀)*cappedAcceleration (t/T)/T^2) t := by
  constructor
  · convert! (((capped_quintic_derivative (t/T)).comp t ((hasDerivAt_id t).div_const T)).const_mul (r₁-r₀)).const_add r₀ using 1 <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  · convert! (((capped_quintic_second_derivative (t/T)).comp t ((hasDerivAt_id t).div_const T)).const_mul (r₁-r₀)).div_const T using 1 <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem transition_rate_bounds {r₀ r₁ T : ℝ} (hT : 0 < T) (t : ℝ) :
    |(r₁-r₀)*cappedRate (t/T)/T| ≤ (15/8)*|r₁-r₀|/T ∧
    |(r₁-r₀)*cappedAcceleration (t/T)/T^2| ≤ (10/sqrt 3)*|r₁-r₀|/T^2 := by
  obtain ⟨h₁,h₂⟩ := capped_quintic_bounds (t/T)
  simp only [abs_div,abs_mul,abs_of_pos hT,abs_of_nonneg (sq_nonneg T)]
  constructor
  · apply div_le_div_of_nonneg_right _ hT.le
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_le_mul_of_nonneg_left h₁ (abs_nonneg (r₁-r₀))]
  · apply div_le_div_of_nonneg_right _ (sq_nonneg T)
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_le_mul_of_nonneg_left h₂ (abs_nonneg (r₁-r₀))]

theorem transition_endpoints {r₀ r₁ T t : ℝ} (hT : 0 < T) :
    (t ≤ 0 → transition r₀ r₁ T t=r₀) ∧ (T ≤ t → transition r₀ r₁ T t=r₁) := by
  constructor
  · intro ht
    simp [transition,cappedQuintic,div_nonpos_of_nonpos_of_nonneg ht hT.le]
  · intro ht
    have hq : 1 ≤ t/T := (le_div_iff₀ hT).mpr (by simpa using! ht)
    by_cases he : t/T=1
    · norm_num [transition,cappedQuintic,he,quintic]
    · have hgt : 1 < t/T := lt_of_le_of_ne hq (Ne.symm he)
      simp [transition,cappedQuintic,show ¬t/T ≤ 0 by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith,not_le.mpr hgt]

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.ReferenceCompletion -/

/- BEGIN SOURCE MODULE: ChainFountain.GlobalForces -/

namespace ChainFountain
noncomputable section
open Set Real

def GlobalTrackingData.accelCap (c : GlobalTrackingData) := c.R₂+
  (c.k₁+c.k₂)*(sqrt (2*c.cap)*sqrt (1+c.k₁^2/c.k₀))+
  (c.k₀+c.k₁*c.k₂)*sqrt (2*c.cap/c.k₀)
def GlobalTrackingData.dampingCap (c : GlobalTrackingData) :=
  c.κd*c.vhi^4/c.hlo*sqrt (8*c.cap)
def GlobalTrackingData.command (c : GlobalTrackingData) (t : ℝ) (x : MechanicalState) :=
  robustInput c.H c.g c.α c.β x.1 x.2.1 x.2.2
    (acceleration c.k₀ c.k₁ c.k₂ (x.1-c.r t) (heightRate x.2.1 x.2.2) (c.r₁ t) (c.r₂ t))
    c.κd (x.2.1-x.2.2-2*c.r₁ t+2*c.k₁*(x.1-c.r t))

/-- Algebraic actuator certificate, containing no unknown trajectory. -/
def GlobalTrackingData.forceCertificate (c : GlobalTrackingData) (uLo uHi : ℝ) : Prop :=
  uLo ≤ lowerInputBound c.H c.g c.α c.β c.hlo c.hhi c.vhi (c.wlo-c.Q) c.whi c.accelCap c.dampingCap ∧
  upperInputBound c.H c.g c.α c.hlo c.hhi c.vlo (c.whi+c.Q) c.accelCap c.dampingCap ≤ uHi ∧
  0 ≤ lowerTensionBound c.H c.g c.β c.hlo c.hhi (c.wlo-c.Q) c.whi c.accelCap-
    c.dampingCap-c.dbar*c.vhi^2

theorem GlobalTrackingData.force_of_energy_box (c : GlobalTrackingData)
    (ha : c.α ≤ 1) (hb : 0 ≤ c.β) {uLo uHi t : ℝ} {x : MechanicalState}
    (hc : c.forceCertificate uLo uHi) (ht : 0 ≤ t) (hbox : x ∈ c.safeBox)
    (hE : c.stateEnergy t x ≤ c.cap) :
    uLo ≤ c.command t x ∧ c.command t x ≤ uHi ∧
      0 ≤ pickup (c.α+c.d t) x.2.1 (c.command t x) := by
  have hR : 0 ≤ c.R₁ := (abs_nonneg _).trans (c.rate_bound 0 le_rfl)
  have hQ : 0 ≤ c.Q := by dsimp [Q]; positivity
  have hf : 2*c.Q < c.wlo := c.forward
  have hvlo : 0 ≤ c.vlo := by dsimp [vlo]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hwlo : 0 ≤ c.wlo := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hslo : 0 ≤ c.wlo-c.Q := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hS : c.wlo-c.Q ≤ (x.2.1+x.2.2)/2 ∧ (x.2.1+x.2.2)/2 ≤ c.whi+c.Q := by
    have hv := hbox.2.1
    have hw := hbox.2.2
    change c.wlo-2*c.Q ≤ x.2.1 ∧ x.2.1 ≤ c.whi+2*c.Q at hv
    constructor <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hv.1,hv.2,hw.1,hw.2]
  have he := error_enclosure (k₁:=c.k₁) c.k₀_pos hE
  have hq : |heightRate x.2.1 x.2.2-c.r₁ t| ≤ sqrt (2*c.cap)*sqrt (1+c.k₁^2/c.k₀) := by
    convert! he.2.2 using 1 <;> congr 1 <;> unfold heightRate <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hA := acceleration_bound c.k₀_pos.le (c.κ_pos.le.trans c.κ_le_k₁)
    (c.κ_pos.le.trans c.κ_le_k₂) he.1 hq (c.accel_bound t ht)
  exact robust_force_feasibility c.H_pos c.g_nonneg ha hb c.height_positive
    hbox.1 (square_interval hvlo hbox.2.1) (square_interval hwlo hbox.2.2).2
    (square_interval hslo hS) hA c.κd_nonneg he.2.1 (c.disturbance_bound t ht)
    hc.1 hc.2.1 hc.2.2

/-- Global physical actuation: construct the trajectory and then certify its
actual unfiltered command and pickup tension at every nonnegative time. -/
theorem GlobalTrackingData.exists_global_admissible (c : GlobalTrackingData)
    (ha : c.α ≤ 1) (hb : 0 ≤ c.β) (uLo uHi : ℝ)
    (hc : c.forceCertificate uLo uHi) :
    ∃ x : ℝ → MechanicalState, x 0=c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      (∀ t ≥ 0, x t ∈ c.safeBox) ∧
      ∀ t ≥ 0, c.stateEnergy t (x t) ≤ c.cap ∧ 0 < (x t).1 ∧
        0 < (x t).2.1 ∧ c.vmin ≤ ((x t).2.1+(x t).2.2)/2 ∧
        uLo ≤ c.command t (x t) ∧ c.command t (x t) ≤ uHi ∧
        0 ≤ pickup (c.α+c.d t) (x t).2.1 (c.command t (x t)) := by
  obtain ⟨x,hx,hd,hbnd,hphys⟩ := c.exists_global_physical
  refine ⟨x,hx,hd,hbnd,?_⟩
  intro t ht
  have hp := hphys t ht
  have hu := c.force_of_energy_box ha hb hc ht (hbnd t ht) hp.1
  exact ⟨hp.1,hp.2.1,hp.2.2.2.2.1,hp.2.2.2.2.2,hu⟩

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.GlobalForces -/

/- BEGIN SOURCE MODULE: ChainFountain.AdditionalClaims -/

namespace ChainFountain
noncomputable section
open MeasureTheory Filter Real

/-- Proposition 3.1 for equations holding almost everywhere. The coefficient and
input may be measurable: no time derivative of either one is needed. This is a
chain-rule conclusion for an a.e. solution, not a measurable-input existence theorem. -/
theorem energy_balance_ae {H g lam β : ℝ} {α u h v w : ℝ → ℝ}
    {μ : Measure ℝ}
    (hh : ∀ᵐ t ∂μ, h t ≠ 0) (hH : ∀ᵐ t ∂μ, H+h t ≠ 0)
    (dh : ∀ᵐ t ∂μ, HasDerivAt h (heightRate (v t) (w t)) t)
    (dv : ∀ᵐ t ∂μ, HasDerivAt v (rise g (α t) (h t) (v t) (w t) (u t)) t)
    (dw : ∀ᵐ t ∂μ, HasDerivAt w (fall H g β (h t) (v t) (w t)) t) :
    ∀ᵐ t ∂μ, HasDerivAt (fun s => energy H g lam (h s) (v s) (w s))
      (lam*g*H*w t-lam*(1/2-α t)*(v t)^3-lam*(1/2-β)*(w t)^3-lam*u t*v t) t := by
  filter_upwards [hh,hH,dh,dv,dw] with t ht hHt hdt hvt hwt
  exact energy_hasDerivAt ht hHt hdt hvt hwt

/-- The localized quadratic generator inequality is algebraic; Dynkin's formula
and the stopped-process expectation inequality remain separate obligations. -/
theorem localized_generator_bound {k₀ k₁ k₂ κ κd G Gmax σ e z : ℝ}
    (hk₀ : 0 ≤ k₀) (hk₁ : κ ≤ k₁) (hk₂ : κ ≤ k₂) (hκd : 0 ≤ κd)
    (hG : G^2 ≤ Gmax^2) :
    k₀*e*errorRate k₁ e z+z/4*zRate k₀ k₂ κd G 0 e z+
      (1/2)*(σ*G)^2*(1/4) ≤ -2*κ*errorEnergy k₀ e z+σ^2*Gmax^2/8 := by
  rw [generator_identity]
  have hn := nominal_decay (e:=e) (z:=z) hk₀ hk₁ hk₂
  have hg := mul_le_mul_of_nonneg_left hG (sq_nonneg σ)
  have hd : 0 ≤ κd*G^2*z^2 := by positivity
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

def fastReference (t : ℝ) := (1/5 : ℝ)+(1/10)*sin (100*t)
def fastRate (t : ℝ) := 10*cos (100*t)
def fastAcceleration (t : ℝ) := -1000*sin (100*t)

theorem fast_reference_derivatives (t : ℝ) :
    HasDerivAt fastReference (fastRate t) t ∧ HasDerivAt fastRate (fastAcceleration t) t := by
  constructor
  · convert! ((((hasDerivAt_id t).const_mul 100).sin).const_mul (1/10)).const_add (1/5) using 1 <;>
      dsimp [fastReference,fastRate] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  · convert! (((hasDerivAt_id t).const_mul 100).cos).const_mul 10 using 1 <;>
      dsimp [fastRate,fastAcceleration] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem fast_reference_bounds (t : ℝ) :
    (1/10 : ℝ) ≤ fastReference t ∧ fastReference t ≤ 3/10 ∧
      |fastRate t| ≤ 10 ∧ |fastAcceleration t| ≤ 1000 := by
  have hs := abs_le.mp (abs_sin_le_one (100*t))
  have hc := abs_cos_le_one (100*t)
  refine ⟨?_,?_,?_,?_⟩
  · dsimp [fastReference]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hs.1]
  · dsimp [fastReference]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hs.2]
  · norm_num [fastRate,abs_mul]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
  · norm_num [fastAcceleration,abs_mul]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [abs_sin_le_one (100*t)]

/-- Appendix A.3, linked to the actual smooth positive bounded-rate reference. -/
theorem counterexample_reference_rate :
    fastReference 0=1/5 ∧ fastRate 0=10 ∧
      internal 2 (981/100) (1/50) (fastReference 0) 0 (fastRate 0) < 0 := by
  norm_num [fastReference,fastRate,internal]

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.AdditionalClaims -/

/- BEGIN SOURCE MODULE: ChainFountain.Linearization -/

namespace ChainFountain
noncomputable section
set_option maxHeartbeats 1000000

abbrev State₃ := ℝ × ℝ × ℝ
def heightProjection : State₃ →L[ℝ] ℝ := ContinuousLinearMap.fst ℝ ℝ (ℝ×ℝ)
def riseProjection : State₃ →L[ℝ] ℝ :=
  (ContinuousLinearMap.fst ℝ ℝ ℝ).comp (ContinuousLinearMap.snd ℝ ℝ (ℝ×ℝ))
def fallProjection : State₃ →L[ℝ] ℝ :=
  (ContinuousLinearMap.snd ℝ ℝ ℝ).comp (ContinuousLinearMap.snd ℝ ℝ (ℝ×ℝ))

def openLoopField (H g α β : ℝ) (x : State₃) : State₃ :=
  (heightRate x.2.1 x.2.2,rise g α x.1 x.2.1 x.2.2 0,fall H g β x.1 x.2.1 x.2.2)

/-- The matrix in equation (4.4), as a continuous linear map on product coordinates. -/
def paperJacobian (α β ρ ω : ℝ) : State₃ →L[ℝ] State₃ :=
  ((1/2 : ℝ) • riseProjection - (1/2 : ℝ) • fallProjection).prod
    (((-α*ω^2) • heightProjection - ((1-2*α)*ω) • riseProjection + ω • fallProjection).prod
      ((α*ρ*ω^2) • heightProjection - (ρ*ω) • riseProjection -
        ((1-2*β)*ρ*ω) • fallProjection))

/-- A genuine Frechet derivative of the mechanical field, under the equilibrium
balances. No derivative-identification hypothesis is assumed. -/
theorem open_loop_frechet_derivative {H g α β h s : ℝ}
    (hh : h ≠ 0) (hH : H+h ≠ 0)
    (he₁ : α*s^2=g*h) (he₂ : (1-β)*s^2=g*(H+h)) :
    HasFDerivAt (openLoopField H g α β)
      (paperJacobian α β (h/(H+h)) (s/h)) (h,s,s) := by
  let x : State₃ := (h,s,s)
  have dh := heightProjection.hasFDerivAt (x:=x)
  have dv := riseProjection.hasFDerivAt (x:=x)
  have dw := fallProjection.hasFDerivAt (x:=x)
  have ds := (dv.add dw).mul_const (1/2 : ℝ)
  have dS := ds.mul ds
  have dr := (((dS.sub ((dv.mul dv).const_mul (1-α))).sub (dh.const_mul g)).sub_const 0).mul ((hasFDerivAt_inv hh).comp x dh)
  have df := ((dS.neg.add ((dw.mul dw).const_mul β)).mul ((hasFDerivAt_inv hH).comp x (dh.const_add H))).const_add g
  have dq := (dv.sub dw).mul_const (1/2 : ℝ)
  have dF := dq.prodMk (dr.prodMk df)
  refine (dF.congr_of_eventuallyEq ?_).congr_fderiv ?_
  · apply Filter.Eventually.of_forall
    intro y
    ext <;> simp [openLoopField,heightRate,rise,fall,crownSq,heightProjection,riseProjection,fallProjection] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  · apply ContinuousLinearMap.ext
    intro y
    apply Prod.ext
    · simp [paperJacobian,heightProjection,riseProjection,fallProjection]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    · apply Prod.ext <;>
        simp [paperJacobian,heightProjection,riseProjection,fallProjection,x,
          ContinuousLinearMap.prod_apply,ContinuousLinearMap.comp_apply] <;>
        field_simp
      · (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
      · linear_combination 4*y.1*h*he₂ - 4*y.1*(H+h)*he₁

theorem paper_jacobian_action (α β ρ ω : ℝ) (y : State₃) :
    paperJacobian α β ρ ω y =
      (y.2.1/2-y.2.2/2,
       -α*ω^2*y.1-(1-2*α)*ω*y.2.1+ω*y.2.2,
       α*ρ*ω^2*y.1-ρ*ω*y.2.1-(1-2*β)*ρ*ω*y.2.2) := by
  simp [paperJacobian,heightProjection,riseProjection,fallProjection]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- Genuine derivative with respect to the physical input u, at a fixed state. -/
theorem input_vector_derivative (H g α β h v w u : ℝ) :
    HasDerivAt (fun U => (heightRate v w,rise g α h v w U,fall H g β h v w))
      (0,-1/h,0) u := by
  have hu := ((hasDerivAt_const u (crownSq v w-(1-α)*v^2-g*h)).sub
    (hasDerivAt_id u)).div_const h
  simpa [rise] using! (hasDerivAt_const u (heightRate v w)).prodMk
    (hu.prodMk (hasDerivAt_const u (fall H g β h v w)))

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.Linearization -/

/- BEGIN SOURCE MODULE: ChainFountain.QuadraticLyapunov -/

namespace ChainFountain
noncomputable section
open Set Metric Real Filter
open scoped Topology

/-- Compactness turns a positive homogeneous quadratic function into a uniform
coercivity estimate. The minimum is proved to be positive, not assumed. -/
theorem quadratic_coercive {V : State₃ → ℝ}
    (hc : Continuous V) (hh : ∀ (a : ℝ) x, V (a • x) = a^2 * V x)
    (hp : ∀ x ≠ 0, 0 < V x) :
    ∃ m > 0, ∀ x, m * ‖x‖^2 ≤ V x := by
  have hne : (sphere (0 : State₃) 1).Nonempty := by
    refine ⟨(1,0,0), ?_⟩
    norm_num [mem_sphere, dist_eq_norm, Prod.norm_def]
  obtain ⟨u,hu,hmin⟩ := (isCompact_sphere (0 : State₃) 1).exists_isMinOn hne hc.continuousOn
  have hun : ‖u‖ = 1 := by simpa [mem_sphere,dist_zero_right] using! hu
  have hup : 0 < V u := hp u (by intro h; simp [h] at hun)
  refine ⟨V u,hup,fun x => ?_⟩
  by_cases hx : x = 0
  · have hz := hh 0 (0 : State₃)
    simpa [hx] using! hz.ge
  · have hn : 0 < ‖x‖ := norm_pos_iff.mpr hx
    have hs : ‖x‖⁻¹ • x ∈ sphere (0 : State₃) 1 := by
      simpa [mem_sphere,dist_zero_right] using! (norm_smul_inv_norm (𝕜:=ℝ) hx)
    have h := mul_le_mul_of_nonneg_left (hmin hs) (sq_nonneg ‖x‖)
    rw [hh] at h
    have he : ‖x‖^2 * (‖x‖⁻¹^2 * V x) = V x := by field_simp
    rw [he] at h
    simpa [mul_comm] using! h

abbrev QuadraticBilin := State₃ →L[ℝ] State₃ →L[ℝ] ℝ

theorem quadratic_bilin_bound (B : QuadraticBilin) (x y : State₃) :
    |B x y| ≤ ‖B‖ * ‖x‖ * ‖y‖ := by
  exact (B x).le_opNorm y |>.trans
    (mul_le_mul_of_nonneg_right (B.le_opNorm x) (norm_nonneg y))

/-- A strict quadratic certificate for the derivative survives the nonlinear
remainder. All constants are obtained from the actual Frechet derivative. -/
theorem nonlinear_quadratic_decay
    {F : State₃ → State₃} {A : State₃ →L[ℝ] State₃} (B : QuadraticBilin)
    (hF : HasFDerivAt F A 0) (hzero : F 0 = 0)
    (hpos : ∀ x ≠ 0, 0 < B x x)
    (hneg : ∀ x ≠ 0, B x (A x) + B (A x) x < 0) :
    ∃ m M κ r : ℝ, 0 < m ∧ 0 < M ∧ 0 < κ ∧ 0 < r ∧
      (∀ x, m*‖x‖^2 ≤ B x x ∧ B x x ≤ M*‖x‖^2) ∧
      ∀ x, ‖x‖ < r → B x (F x)+B (F x) x ≤ -2*κ*(B x x) := by
  obtain ⟨m,hm,hml⟩ := quadratic_coercive
    (B.continuous.clm_apply continuous_id)
    (by intro a x; simp [map_smul,smul_eq_mul]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring) hpos
  obtain ⟨q,hq,hql⟩ := quadratic_coercive
    ((B.continuous.clm_apply A.continuous).add
      ((B.continuous.comp A.continuous).clm_apply continuous_id)).neg
    (by intro a x; simp [map_smul,smul_eq_mul]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring)
    (fun x hx => neg_pos.mpr (hneg x hx))
  let M : ℝ := ‖B‖+1
  have hM : 0 < M := by dsimp [M]; positivity
  have hMv (x : State₃) : B x x ≤ M*‖x‖^2 := by
    have hb := quadratic_bilin_bound B x x
    have hba := le_abs_self (B x x)
    dsimp [M]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [sq_nonneg ‖x‖]
  have heps : 0 < q/(4*M) := by positivity
  obtain ⟨r,hr,hrem⟩ := Metric.eventually_nhds_iff.mp (hF.isLittleO.bound heps)
  refine ⟨m,M,q/(8*M),r,hm,hM,by positivity,hr,
    fun x => ⟨hml x,hMv x⟩,fun x hx => ?_⟩
  have he : ‖F x-A x‖ ≤ q/(4*M)*‖x‖ := by
    simpa [hzero,dist_zero_right] using! hrem (by simpa [dist_zero_right] using! hx)
  have b₁ := quadratic_bilin_bound B x (F x-A x)
  have b₂ := quadratic_bilin_bound B (F x-A x) x
  have hh₁ := mul_le_mul_of_nonneg_left he (mul_nonneg (norm_nonneg B) (norm_nonneg x))
  have hh₂ := mul_le_mul_of_nonneg_right
    (mul_le_mul_of_nonneg_left he (norm_nonneg B)) (norm_nonneg x)
  have hl := hql x
  dsimp only [Function.comp_apply,id_eq] at hl
  have heq : B x (F x)+B (F x) x = B x (A x)+B (A x) x +
      B x (F x-A x)+B (F x-A x) x := by simp [map_sub]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hlin : B x (F x)+B (F x) x ≤ -q/2*‖x‖^2 := by
    have hnM : ‖B‖ ≤ M := by dsimp [M]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
    have hcoef : 2*‖B‖*(q/(4*M)) ≤ q/2 := by
      calc
        2*‖B‖*(q/(4*M)) ≤ 2*M*(q/(4*M)) := by gcongr
        _ = q/2 := by field_simp <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    have hcs := mul_le_mul_of_nonneg_right hcoef (sq_nonneg ‖x‖)
    rw [heq]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [le_abs_self (B x (F x-A x)),le_abs_self (B (F x-A x) x)]
  have hc := mul_le_mul_of_nonneg_left (hMv x) (show 0 ≤ q/(4*M) by positivity)
  have hc' : q/(4*M)*(M*‖x‖^2) = q/4*‖x‖^2 := by field_simp
  rw [hc'] at hc
  have heκ : 2*(q/(8*M)) = q/(4*M) := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring_nf
  rw [neg_mul,heκ]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_nonneg hq.le (sq_nonneg ‖x‖)]

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.QuadraticLyapunov -/

/- BEGIN SOURCE MODULE: ChainFountain.CubicLyapunov -/

namespace ChainFountain
noncomputable section
set_option maxHeartbeats 800000

def linearSquare (L : State₃ →L[ℝ] ℝ) : QuadraticBilin := L.smulRight L

/-- An explicit sum-of-squares solution of the strict cubic Lyapunov problem.
No spectral-to-Lyapunov existence theorem is assumed. -/
def cubicBilin (a b c : ℝ) : QuadraticBilin :=
  linearSquare (a • fallProjection + (a^2) • riseProjection + (a*b-c) • heightProjection) +
  (a*c) • linearSquare (riseProjection + a • heightProjection) +
  (2*c*(a*b-c)) • linearSquare heightProjection +
  b • linearSquare (fallProjection + a • riseProjection) +
  (1+b) • linearSquare (b • riseProjection + c • heightProjection) +
  linearSquare (b • fallProjection + c • riseProjection) +
  (c*(a*b-c)) • linearSquare riseProjection

theorem cubic_bilin_squares (a b c : ℝ) (x : State₃) :
    cubicBilin a b c x x =
      (a*x.2.2+a^2*x.2.1+(a*b-c)*x.1)^2 + a*c*(x.2.1+a*x.1)^2 +
      2*c*(a*b-c)*x.1^2 + b*(x.2.2+a*x.2.1)^2 +
      (1+b)*(b*x.2.1+c*x.1)^2 + (b*x.2.2+c*x.2.1)^2 +
      c*(a*b-c)*x.2.1^2 := by
  simp [cubicBilin,linearSquare,heightProjection,riseProjection,fallProjection]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem cubic_bilin_positive {a b c : ℝ} (ha : 0<a) (hb : 0<b)
    (hc : 0<c) (hD : c<a*b) (x : State₃) (hx : x≠0) :
    0 < cubicBilin a b c x x := by
  rw [cubic_bilin_squares]
  have hD' : 0<a*b-c := sub_pos.mpr hD
  have h₁ : 0≤(a*x.2.2+a^2*x.2.1+(a*b-c)*x.1)^2 := sq_nonneg _
  have h₂ : 0≤ a*c*(x.2.1+a*x.1)^2 := by positivity
  have h₃ : 0≤2*c*(a*b-c)*x.1^2 := by positivity
  have h₄ : 0≤ b*(x.2.2+a*x.2.1)^2 := by positivity
  have h₅ : 0≤(1+b)*(b*x.2.1+c*x.1)^2 := by positivity
  have h₆ : 0≤(b*x.2.2+c*x.2.1)^2 := sq_nonneg _
  have h₇ : 0≤ c*(a*b-c)*x.2.1^2 := by positivity
  by_cases hx₁ : x.1=0
  · by_cases hx₂ : x.2.1=0
    · have hx₃ : x.2.2≠0 := by
        intro hh; apply hx; exact Prod.ext hx₁ (Prod.ext hx₂ hh)
      have h : 0 < (a*x.2.2+a^2*x.2.1+(a*b-c)*x.1)^2 := by
        simp only [hx₁,hx₂,mul_zero,add_zero]
        exact sq_pos_of_ne_zero (mul_ne_zero ha.ne' hx₃)
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
    · have h : 0 < c*(a*b-c)*x.2.1^2 := mul_pos (mul_pos hc hD') (sq_pos_of_ne_zero hx₂)
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  · have h : 0 < 2*c*(a*b-c)*x.1^2 := by positivity
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

def companionField (a b c : ℝ) (x : State₃) : State₃ :=
  (x.2.1,x.2.2,-c*x.1-b*x.2.1-a*x.2.2)

theorem cubic_bilin_dissipation (a b c : ℝ) (x : State₃) :
    cubicBilin a b c x (companionField a b c x) +
      cubicBilin a b c (companionField a b c x) x =
      -2*(a*b-c)*(a*c*x.1^2+b*x.2.1^2+b*x.2.2^2) := by
  simp [cubicBilin,linearSquare,companionField,heightProjection,riseProjection,fallProjection]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem cubic_bilin_strict_decay {a b c : ℝ} (ha : 0<a) (hb : 0<b)
    (hc : 0<c) (hD : c<a*b) (x : State₃) (hx : x≠0) :
    cubicBilin a b c x (companionField a b c x) +
      cubicBilin a b c (companionField a b c x) x < 0 := by
  rw [cubic_bilin_dissipation]
  have hn : 0 < a*c*x.1^2+b*x.2.1^2+b*x.2.2^2 := by
    have h₁ : 0≤ a*c*x.1^2 := by positivity
    have h₂ : 0≤ b*x.2.1^2 := by positivity
    have h₃ : 0≤ b*x.2.2^2 := by positivity
    by_cases hx₁ : x.1=0
    · by_cases hx₂ : x.2.1=0
      · have hx₃ : x.2.2≠0 := by intro hh; exact hx (Prod.ext hx₁ (Prod.ext hx₂ hh))
        have h : 0<b*x.2.2^2 := by positivity
        (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
      · have h : 0<b*x.2.1^2 := by positivity
        (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
    · have h : 0<a*c*x.1^2 := by positivity
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  exact mul_neg_of_neg_of_pos (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) hn

/-- The observability coordinates (height, its linearized first and second
derivatives) put the actual Jacobian into cubic companion form. -/
def observabilityMap (α β ρ ω : ℝ) : State₃ →L[ℝ] State₃ :=
  heightProjection.prod
    ((heightProjection.comp (paperJacobian α β ρ ω)).prod
      ((heightProjection.comp (paperJacobian α β ρ ω)).comp (paperJacobian α β ρ ω)))

theorem observability_intertwines (α β ρ ω : ℝ) (hrel : α=(1-β)*ρ) (x : State₃) :
    observabilityMap α β ρ ω (paperJacobian α β ρ ω x) =
      companionField (coeff₂ ρ ω) (coeff₁ α ρ ω) (coeff₀ α ρ ω)
        (observabilityMap α β ρ ω x) := by
  simp [observabilityMap,paperJacobian,heightProjection,riseProjection,fallProjection,
    companionField,coeff₂,coeff₁,coeff₀]
  rw [hrel]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem observability_injective {α β ρ ω : ℝ} (ha : 0<α) (hw : 0<ω)
    (hrel : α=(1-β)*ρ) : Function.Injective (observabilityMap α β ρ ω) := by
  apply (injective_iff_map_eq_zero _).mpr
  intro x hx
  have h₁ := congrArg Prod.fst hx
  have h₂ := congrArg (fun z : State₃ => z.2.1) hx
  have h₃ := congrArg (fun z : State₃ => z.2.2) hx
  simp [observabilityMap,paperJacobian,heightProjection,riseProjection,fallProjection] at h₁ h₂ h₃
  have hvw : x.2.1=x.2.2 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have he : 2*α*ω*x.2.2=0 := by
    rw [hrel] at h₃ ⊢
    rw [h₁,hvw] at h₃
    linear_combination h₃
  have hz : x.2.2=0 := (mul_eq_zero.mp he).resolve_left (by positivity)
  exact Prod.ext h₁ (Prod.ext (hvw.trans hz) hz)

def plantBilin (α β ρ ω : ℝ) : QuadraticBilin :=
  (cubicBilin (coeff₂ ρ ω) (coeff₁ α ρ ω) (coeff₀ α ρ ω)).bilinearComp
    (observabilityMap α β ρ ω) (observabilityMap α β ρ ω)

theorem plant_strict_lyapunov {α β ρ ω : ℝ}
    (ha : 0<α) (ha1 : α<1/2) (hr : 0<ρ) (hr1 : ρ<1) (hw : 0<ω)
    (hrel : α=(1-β)*ρ) :
    (∀ x≠0, 0<plantBilin α β ρ ω x x) ∧
    ∀ x≠0, plantBilin α β ρ ω x (paperJacobian α β ρ ω x) +
      plantBilin α β ρ ω (paperJacobian α β ρ ω x) x < 0 := by
  obtain ⟨h₂,h₁,h₀,hH⟩ := hurwitz_conditions ha ha1 hr hr1 hw
  have hinj := observability_injective ha hw hrel
  have hne (x : State₃) (hx : x≠0) : observabilityMap α β ρ ω x ≠ 0 := by
    intro h; apply hx; apply hinj; simpa using! h
  constructor
  · intro x hx
    simp only [plantBilin,ContinuousLinearMap.bilinearComp_apply]
    exact cubic_bilin_positive h₂ h₁ h₀ hH _ (hne x hx)
  · intro x hx
    simp only [plantBilin,ContinuousLinearMap.bilinearComp_apply]
    rw [observability_intertwines α β ρ ω hrel]
    exact cubic_bilin_strict_decay h₂ h₁ h₀ hH _ (hne x hx)

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.CubicLyapunov -/

/- BEGIN SOURCE MODULE: ChainFountain.PrefixUniqueness -/

namespace ChainFountain
noncomputable section
open Set Metric Real
open scoped Topology NNReal

/-- A finite-interval first-exit principle. Only continuity on the interval is
required; the curve is neither assumed to be safe nor defined by the ODE later. -/
theorem no_exit_on_Icc_of_prefix_bound
    {E : Type*} [TopologicalSpace E] {x : ℝ → E} {B K : Set E} {T : ℝ}
    (hT : 0 ≤ T) (hx : ContinuousOn x (Icc 0 T))
    (hB : IsClosed B) (hKB : K ⊆ interior B) (hx₀ : x 0 ∈ interior B)
    (hprefix : ∀ S ∈ Icc 0 T, (∀ t ∈ Icc 0 S, x t ∈ B) → x S ∈ K) :
    ∀ t ∈ Icc 0 T, x t ∈ K := by
  let p : ℝ → ℝ := fun t => max 0 (min T t)
  have hp : Continuous p := continuous_const.max (continuous_const.min continuous_id)
  have hpm (t : ℝ) : p t ∈ Icc 0 T :=
    ⟨le_max_left _ _, max_le hT (min_le_left _ _)⟩
  have hpeq (t : ℝ) (ht : t ∈ Icc 0 T) : p t = t := by
    simp only [p, min_eq_right ht.2, max_eq_right ht.1]
  have hstay := no_exit_of_prefix_bound (hx.comp_continuous hp hpm) hB hKB
    (show x (p 0) ∈ interior B by simpa [hpeq 0 ⟨le_rfl,hT⟩] using hx₀) (by
      intro S hS hb
      have hST : min S T ∈ Icc (0:ℝ) T := ⟨le_min hS hT, min_le_right _ _⟩
      have hh := hprefix (min S T) hST (by
        intro t ht
        have htT : t ≤ T := ht.2.trans (min_le_right _ _)
        have htS : t ≤ S := ht.2.trans (min_le_left _ _)
        simpa only [Function.comp_apply, hpeq t ⟨ht.1,htT⟩] using hb t ⟨ht.1,htS⟩)
      simpa only [Function.comp_apply, p, min_comm T S, max_eq_right (le_min hS hT)] using hh)
  intro t ht
  simpa only [Function.comp_apply, hpeq t ht] using hstay t ht.1

/-- An a priori prefix bound turns box-wise Lipschitz uniqueness into
uniqueness against arbitrary classical competitors on every finite interval. -/
theorem unique_on_Icc_of_prefix_bound
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    {F : ℝ → E → E} {B K : Set E} {L : ℝ≥0} {x₀ : E} {T : ℝ}
    (hB : IsClosed B) (hKB : K ⊆ interior B) (hx₀ : x₀ ∈ interior B)
    (hL : ∀ t, LipschitzOnWith L (F t) B)
    (hprefix : ∀ (z : ℝ → E) S, 0 ≤ S → z 0 = x₀ →
      (∀ t ∈ Icc 0 S, z t ∈ B) →
      (∀ t ∈ Icc 0 S, HasDerivAt z (F t (z t)) t) → z S ∈ K)
    {x y : ℝ → E} (hT : 0 ≤ T) (hx : x 0 = x₀) (hy : y 0 = x₀)
    (hdx : ∀ t ∈ Icc 0 T, HasDerivAt x (F t (x t)) t)
    (hdy : ∀ t ∈ Icc 0 T, HasDerivAt y (F t (y t)) t) :
    EqOn x y (Icc 0 T) := by
  have stay (z : ℝ → E) (hz : z 0 = x₀)
      (hd : ∀ t ∈ Icc 0 T, HasDerivAt z (F t (z t)) t) :
      ∀ t ∈ Icc 0 T, z t ∈ B := by
    have hc : ContinuousOn z (Icc 0 T) :=
      fun t ht => (hd t ht).continuousAt.continuousWithinAt
    have hs := no_exit_on_Icc_of_prefix_bound hT hc hB hKB (hz ▸ hx₀) (by
      intro S hS hb
      exact hprefix z S hS.1 hz hb (fun t ht => hd t ⟨ht.1,ht.2.trans hS.2⟩))
    exact fun t ht => interior_subset (hKB (hs t ht))
  exact ODE_solution_unique_of_mem_Icc_right (s := fun _ => B)
    (fun t _ => hL t)
    (fun t ht => (hdx t ht).continuousAt.continuousWithinAt)
    (fun t ht => (hdx t (Ico_subset_Icc_self ht)).hasDerivWithinAt)
    (fun t ht => stay x hx hdx t (Ico_subset_Icc_self ht))
    (fun t ht => (hdy t ht).continuousAt.continuousWithinAt)
    (fun t ht => (hdy t (Ico_subset_Icc_self ht)).hasDerivWithinAt)
    (fun t ht => stay y hy hdy t (Ico_subset_Icc_self ht)) (hx.trans hy.symm)

/-- Every classical mechanical solution from the certified initial data is
safe for its whole supplied interval; no box or positive-height premise. -/
theorem GlobalTrackingData.classical_safe_on_Icc (c : GlobalTrackingData)
    {x : ℝ → MechanicalState} {T : ℝ} (hT : 0 ≤ T) (hx : x 0 = c.x₀)
    (hd : ∀ t ∈ Icc 0 T, HasDerivAt x (c.field t (x t)) t) :
    ∀ t ∈ Icc 0 T, x t ∈ c.safeBox := by
  apply no_exit_on_Icc_of_prefix_bound hT
    (fun t ht => (hd t ht).continuousAt.continuousWithinAt)
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    (hx ▸ c.safeBox_interior c.initial_mem)
  intro S hS hb
  exact c.prefix_bound x S hS.1 hx hb (fun t ht => hd t ⟨ht.1,ht.2.trans hS.2⟩)

/-- Unrestricted finite-interval classical uniqueness, including the nominal
kappa_d = 0 regime. Competitors may have any arbitrary extension outside [0,T]. -/
theorem GlobalTrackingData.classical_unique_on_Icc (c : GlobalTrackingData)
    {x y : ℝ → MechanicalState} {T : ℝ} (hT : 0 ≤ T)
    (hx : x 0 = c.x₀) (hy : y 0 = c.x₀)
    (hdx : ∀ t ∈ Icc 0 T, HasDerivAt x (c.field t (x t)) t)
    (hdy : ∀ t ∈ Icc 0 T, HasDerivAt y (c.field t (y t)) t) :
    EqOn x y (Icc 0 T) := by
  obtain ⟨L,C,hL,hcont,hC⟩ := c.field_bounds
  exact unique_on_Icc_of_prefix_bound
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    (c.safeBox_interior c.initial_mem) hL c.prefix_bound hT hx hy hdx hdy

/-- Global tracking with uniqueness against every classical solution on any
finite forward interval, for both robust and undamped nominal gains. -/
theorem GlobalTrackingData.exists_unique_global_tracking (c : GlobalTrackingData) :
    ∃ x : ℝ → MechanicalState, x 0 = c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      (∀ t ≥ 0, x t ∈ c.safeBox) ∧
      (c.dbar = 0 → ∀ t ≥ 0,
        c.stateEnergy t (x t) ≤ exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀) ∧
      (0 < c.κd → ∀ t ≥ 0,
        c.stateEnergy t (x t) ≤ exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-exp (-2*c.κ*t))) ∧
      ∀ T ≥ 0, ∀ y : ℝ → MechanicalState, y 0 = c.x₀ →
        (∀ t ∈ Icc 0 T, HasDerivAt y (c.field t (y t)) t) → EqOn x y (Icc 0 T) := by
  obtain ⟨x,hx,hd,hb,hn,hr⟩ := c.exists_global_tracking
  refine ⟨x,hx,hd,hb,hn,hr,?_⟩
  intro T hT y hy hdy
  exact c.classical_unique_on_Icc hT hx hy (fun t ht => hd t ht.1) hdy

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.PrefixUniqueness -/

/- BEGIN SOURCE MODULE: ChainFountain.LocalStability -/

namespace ChainFountain
noncomputable section
open Set Metric Real Filter
open scoped Topology NNReal
set_option maxHeartbeats 800000

def clipState (r : ℝ) (x : State₃) : State₃ :=
  (max (-r) (min r x.1),max (-r) (min r x.2.1),max (-r) (min r x.2.2))

theorem clip_state_lipschitz (r : ℝ) : LipschitzWith 1 (clipState r) := by
  have hh : LipschitzWith 1 (fun x : State₃ => max (-r) (min r x.1)) :=
    (LipschitzWith.prod_fst.const_min _).const_max _
  have hv : LipschitzWith 1 (fun x : State₃ => x.2.1) := by
    simpa using! LipschitzWith.prod_fst.comp (LipschitzWith.prod_snd (α:=ℝ) (β:=ℝ×ℝ))
  have hw : LipschitzWith 1 (fun x : State₃ => x.2.2) := by
    simpa using! LipschitzWith.prod_snd.comp (LipschitzWith.prod_snd (α:=ℝ) (β:=ℝ×ℝ))
  simpa only [max_self] using! hh.prodMk
    (((hv.const_min r).const_max (-r)).prodMk ((hw.const_min r).const_max (-r)))

theorem clip_state_mem {r : ℝ} (hr : 0≤ r) (x : State₃) :
    clipState r x ∈ closedBall 0 r := by
  have hc (s : ℝ) : |max (-r) (min r s)|≤ r :=
    abs_le.mpr ⟨le_max_left _ _,max_le (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) (min_le_left _ _)⟩
  simpa only [mem_closedBall,dist_zero_right,Prod.norm_def,Real.norm_eq_abs,clipState]
    using max_le (hc x.1) (max_le (hc x.2.1) (hc x.2.2))

theorem clip_state_eq {r : ℝ} {x : State₃} (hx : x ∈ closedBall 0 r) :
    clipState r x = x := by
  simp only [mem_closedBall,dist_zero_right,Prod.norm_def,Real.norm_eq_abs,max_le_iff,abs_le] at hx
  simp [clipState,min_eq_right hx.1.2,max_eq_right hx.1.1,
    min_eq_right hx.2.1.2,max_eq_right hx.2.1.1,
    min_eq_right hx.2.2.2,max_eq_right hx.2.2.1]

theorem quadratic_trajectory_estimate (B : QuadraticBilin)
    {F : State₃ → State₃} {κ T : ℝ} {x : ℝ → State₃} (hκ : 0<κ)
    (hd : ∀ t ∈ Icc 0 T, HasDerivAt x (F (x t)) t)
    (hdec : ∀ t ∈ Icc 0 T, B (x t) (F (x t))+B (F (x t)) (x t) ≤ -2*κ*(B (x t) (x t))) :
    ∀ t ∈ Icc 0 T, B (x t) (x t) ≤ exp (-2*κ*t)*(B (x 0) (x 0)) := by
  have hder (t : ℝ) (ht : t∈Icc 0 T) :
      HasDerivAt (fun s => B (x s) (x s)) (B (x t) (F (x t))+B (F (x t)) (x t)) t := by
    convert! (B.hasFDerivAt.comp_hasDerivAt t (hd t ht)).clm_apply (hd t ht) using 1
    exact add_comm _ _
  have he := scalar_comparison (C:=0) hκ
    (fun t ht => (hder t ht).continuousAt.continuousWithinAt)
    (fun t ht => (hder t (Ico_subset_Icc_self ht)).hasDerivWithinAt)
    (fun t ht => by simpa using! hdec t (Ico_subset_Icc_self ht))
  simpa [envelope] using! he

/-- Full nonlinear forward existence and exponential decay near an equilibrium.
The hypotheses are a C1 field and a strict quadratic certificate for its genuine
derivative. The solution, invariant neighbourhood and decay constants are built. -/
theorem local_exponential_exists_unique_of_quadratic
    {F : State₃ → State₃} {A : State₃ →L[ℝ] State₃} {R : ℝ}
    (hR : 0<R) (hsmooth : ContDiffOn ℝ 1 F (ball 0 R))
    (hF : HasFDerivAt F A 0) (hzero : F 0=0) (B : QuadraticBilin)
    (hpos : ∀ x≠0, 0<B x x)
    (hneg : ∀ x≠0, B x (A x)+B (A x) x<0) :
    ∃ δ C κ : ℝ, 0<δ ∧ 0<C ∧ 0<κ ∧
      ∀ x₀ : State₃, ‖x₀‖<δ → ∃ x : ℝ → State₃,
        x 0=x₀ ∧ (∀ t≥0, HasDerivAt x (F (x t)) t) ∧
        (∀ t≥0, x t∈ball 0 R ∧ ‖x t‖≤ C*exp (-κ*t)*‖x₀‖) ∧
        ∀ T ≥ 0, ∀ y : ℝ → State₃, y 0 = x₀ →
          (∀ t ∈ Icc 0 T, HasDerivAt y (F (y t)) t) → EqOn x y (Icc 0 T) := by
  obtain ⟨m,M,κ,r,hm,hM,hκ,hr,hbounds,hdec⟩ :=
    nonlinear_quadratic_decay B hF hzero hpos hneg
  let C := sqrt (M/m)
  have hC : 0<C := sqrt_pos.2 (div_pos hM hm)
  have hCsq : C^2=M/m := sq_sqrt (div_nonneg hM.le hm.le)
  have hMC : m*C^2=M := by rw [hCsq]; field_simp
  let ρ := min r R / 2
  have hρ : 0<ρ := by dsimp [ρ]; positivity
  have hρr : ρ<r := by dsimp [ρ]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [min_le_left r R]
  have hρR : ρ<R := by dsimp [ρ]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [min_le_right r R]
  let δ := min (ρ/2) (ρ/(2*C))
  have hδ : 0<δ := by dsimp [δ]; positivity
  refine ⟨δ,C,κ,hδ,hC,hκ,fun x₀ hx₀ => ?_⟩
  have hxρ : ‖x₀‖<ρ/2 := lt_of_lt_of_le hx₀ (min_le_left _ _)
  have hxC : C*‖x₀‖≤ρ/2 := by
    have hh := lt_of_lt_of_le hx₀ (min_le_right _ _)
    have := (lt_div_iff₀ (show 0<2*C by positivity)).mp hh
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hsub : closedBall (0:State₃) ρ ⊆ ball 0 R :=
    closedBall_subset_ball hρR
  obtain ⟨L,N,hL,hN⟩ := smooth_compact_convex_bounds isOpen_ball hsmooth
    (isCompact_closedBall (0:State₃) ρ) (convex_closedBall (0:State₃) ρ) hsub
  have hKsub : closedBall (0:State₃) (ρ/2) ⊆ interior (closedBall 0 ρ) := by
    rw [interior_closedBall (0:State₃) hρ.ne']
    exact closedBall_subset_ball (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith)
  have hinit : x₀ ∈ interior (closedBall (0:State₃) ρ) :=
    hKsub (by simpa [mem_closedBall,dist_zero_right] using! hxρ.le)
  have hprefix (x : ℝ → State₃) (T : ℝ) (_hT : 0≤ T) (h₀ : x 0=x₀)
      (hbox : ∀ t∈Icc 0 T, x t∈closedBall 0 ρ)
      (hd : ∀ t∈Icc 0 T, HasDerivAt x (F (x t)) t) : x T∈closedBall 0 (ρ/2) := by
    have he := quadratic_trajectory_estimate B hκ hd (fun t ht =>
      hdec _ (lt_of_le_of_lt (by simpa [mem_closedBall,dist_zero_right] using! hbox t ht) hρr))
    have ht : T∈Icc (0:ℝ) T := ⟨_hT,le_rfl⟩
    have hE := he T ht
    rw [h₀] at hE
    have e0 : 0≤ B x₀ x₀ := (mul_nonneg hm.le (sq_nonneg ‖x₀‖)).trans (hbounds x₀).1
    have ee : exp (-2*κ*T)≤1 := exp_le_one_iff.mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith)
    have hcap : B (x T) (x T) ≤ M*‖x₀‖^2 :=
      hE.trans ((mul_le_of_le_one_left e0 ee).trans (hbounds x₀).2)
    have hs : (C*‖x₀‖)^2 ≤ (ρ/2)^2 := sq_le_sq₀ (by positivity) (by positivity) |>.2 hxC
    have hs' := mul_le_mul_of_nonneg_left hs hm.le
    rw [mul_pow,← mul_assoc,hMC] at hs'
    have hmineq := (hbounds (x T)).1.trans hcap
    have hsmall : ‖x T‖≤ρ/2 := (sq_le_sq₀ (norm_nonneg _) (by positivity)).mp
      ((mul_le_mul_iff_right₀ hm).mp (hmineq.trans hs'))
    simpa [mem_closedBall,dist_zero_right] using! hsmall
  obtain ⟨x,h₀,hd,hstay⟩ := global_exists_of_retraction_and_prefix
    (F:=fun _ x => F x) isClosed_closedBall hKsub (clip_state_lipschitz ρ)
    (clip_state_mem hρ.le) (fun _ hx => clip_state_eq hx) (fun _ => hL)
    (fun _ _ => continuous_const) (fun _ x hx => hN x hx) x₀ hinit hprefix
  have hu : ∀ T ≥ 0, ∀ y : ℝ → State₃, y 0 = x₀ →
      (∀ t ∈ Icc 0 T, HasDerivAt y (F (y t)) t) → EqOn x y (Icc 0 T) := by
    intro T hT y hy hdy
    exact unique_on_Icc_of_prefix_bound (F := fun _ z => F z)
      isClosed_closedBall hKsub hinit (fun _ => hL) hprefix hT h₀ hy
      (fun t ht => hd t ht.1) hdy
  refine ⟨x,h₀,hd,(fun t ht => ⟨?_,?_⟩),hu⟩
  · exact hsub (closedBall_subset_closedBall (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) (hstay t ht))
  · have he := quadratic_trajectory_estimate B hκ
      (fun s hs => hd s hs.1) (fun s hs => hdec _ (by
        have hb : ‖x s‖≤ρ/2 := by simpa [mem_closedBall,dist_zero_right] using! hstay s hs.1
        (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith)) t ⟨ht,le_rfl⟩
    rw [h₀] at he
    have hV := (hbounds (x t)).1.trans (he.trans
      (mul_le_mul_of_nonneg_left (hbounds x₀).2 (exp_pos _).le))
    have heexp : exp (-2*κ*t)=(exp (-κ*t))^2 := by rw [pow_two,← exp_add]; congr 1 <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    rw [heexp] at hV
    have hprod : m*(C*exp (-κ*t)*‖x₀‖)^2 = (exp (-κ*t))^2*(M*‖x₀‖^2) := by
      calc
        _ = (m*C^2)*(exp (-κ*t))^2*‖x₀‖^2 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
        _ = _ := by rw [hMC]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    have hs : ‖x t‖^2 ≤ (C*exp (-κ*t)*‖x₀‖)^2 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
    exact (sq_le_sq₀ (norm_nonneg _) (by positivity)).mp hs

/-- Compatibility form of the nonlinear existence and decay theorem. -/
theorem local_exponential_exists_of_quadratic
    {F : State₃ → State₃} {A : State₃ →L[ℝ] State₃} {R : ℝ}
    (hR : 0<R) (hsmooth : ContDiffOn ℝ 1 F (ball 0 R))
    (hF : HasFDerivAt F A 0) (hzero : F 0=0) (B : QuadraticBilin)
    (hpos : ∀ x≠0, 0<B x x)
    (hneg : ∀ x≠0, B x (A x)+B (A x) x<0) :
    ∃ δ C κ : ℝ, 0<δ ∧ 0<C ∧ 0<κ ∧
      ∀ x₀ : State₃, ‖x₀‖<δ → ∃ x : ℝ → State₃,
        x 0=x₀ ∧ (∀ t≥0, HasDerivAt x (F (x t)) t) ∧
        ∀ t≥0, x t∈ball 0 R ∧ ‖x t‖≤ C*exp (-κ*t)*‖x₀‖ := by
  obtain ⟨δ,C,κ,hδ,hC,hκ,hsol⟩ :=
    local_exponential_exists_unique_of_quadratic hR hsmooth hF hzero B hpos hneg
  refine ⟨δ,C,κ,hδ,hC,hκ,?_⟩
  intro x₀ hx₀
  obtain ⟨x,hx,hd,hb,hu⟩ := hsol x₀ hx₀
  exact ⟨x,hx,hd,hb⟩

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.LocalStability -/

/- BEGIN SOURCE MODULE: ChainFountain.PlantStability -/

namespace ChainFountain
noncomputable section
open Set Metric Real
set_option maxHeartbeats 800000

theorem open_loop_equilibrium_of_balances {H g α β h s : ℝ}
    (hh : h≠0) (hH : H+h≠0)
    (he₁ : α*s^2=g*h) (he₂ : (1-β)*s^2=g*(H+h)) :
    openLoopField H g α β (h,s,s)=0 := by
  have _hh := hh
  apply Prod.ext
  · simp [openLoopField,heightRate]
  · apply Prod.ext
    · change (crownSq s s-(1-α)*s^2-g*h-0)/h=0
      apply (div_eq_zero_iff).mpr
      left
      unfold crownSq
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [he₁]
    · simp [openLoopField,fall,crownSq]
      field_simp
      linear_combination -he₂

/-- Theorem 4.1's nonlinear conclusion. For each sufficiently close initial
state an actual forward-global solution is constructed, remains in h>0, and
converges exponentially to the positive uncontrolled equilibrium. -/
theorem open_loop_local_exponential_unique {H g α β h s : ℝ}
    (hH : 0<H) (hh : 0<h) (hs : 0<s) (ha : 0<α) (hb : 0≤β)
    (hab : α+β<1/2)
    (he₁ : α*s^2=g*h) (he₂ : (1-β)*s^2=g*(H+h)) :
    ∃ δ C κ : ℝ, 0<δ ∧ 0<C ∧ 0<κ ∧
      ∀ x₀ : State₃, ‖x₀-(h,s,s)‖<δ → ∃ x : ℝ → State₃,
        x 0=x₀ ∧ (∀ t≥0, HasDerivAt x (openLoopField H g α β (x t)) t) ∧
        (∀ t≥0, 0<(x t).1 ∧ ‖x t-(h,s,s)‖≤ C*exp (-κ*t)*‖x₀-(h,s,s)‖) ∧
        ∀ T ≥ 0, ∀ z : ℝ → State₃, z 0 = x₀ →
          (∀ t ∈ Icc 0 T, HasDerivAt z (openLoopField H g α β (z t)) t) →
          EqOn x z (Icc 0 T) := by
  have hHp : 0<H+h := add_pos hH hh
  have hρ : 0<h/(H+h) := div_pos hh hHp
  have hρ1 : h/(H+h)<1 := (div_lt_one hHp).mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith)
  have hω : 0<s/h := div_pos hs hh
  have hrel : α=(1-β)*(h/(H+h)) := by
    rw [← mul_div_assoc]
    apply (eq_div_iff hHp.ne').mpr
    apply mul_right_cancel₀ (sq_pos_of_pos hs).ne'
    linear_combination (H+h)*he₁-h*he₂
  let A := paperJacobian α β (h/(H+h)) (s/h)
  let B := plantBilin α β (h/(H+h)) (s/h)
  let F : State₃ → State₃ := fun y => openLoopField H g α β ((h,s,s)+y)
  have hder : HasFDerivAt F A 0 := by
    have hc := (hasFDerivAt_id (𝕜:=ℝ) (0:State₃)).const_add (h,s,s)
    have hd := open_loop_frechet_derivative hh.ne' hHp.ne' he₁ he₂
    have hd' : HasFDerivAt (openLoopField H g α β) A ((h,s,s)+(0:State₃)) := by
      simpa [A] using! hd
    simpa [F,A] using! hd'.comp (0:State₃) hc
  have hz : F 0=0 := by
    simpa [F] using! open_loop_equilibrium_of_balances hh.ne' hHp.ne' he₁ he₂
  have hcoord (x : State₃) : |x.1|≤‖x‖ := by
    simp [Prod.norm_def,Real.norm_eq_abs]
  have hpositive (y : State₃) (hy : y∈ball 0 (h/2)) : 0<h+y.1 := by
    have hn : ‖y‖<h/2 := by simpa [mem_ball,dist_zero_right] using! hy
    have hc := (abs_le.mp (hcoord y)).1
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hsm : ContDiffOn ℝ 1 F (ball 0 (h/2)) := by
    intro y hy
    have hp := hpositive y hy
    have hpH : 0<H+(h+y.1) := add_pos hH hp
    apply ContDiffAt.contDiffWithinAt
    dsimp [F,openLoopField,heightRate,rise,fall,crownSq]
    fun_prop (disch := first | exact hp.ne' | exact hpH.ne' | norm_num)
  have hly := plant_strict_lyapunov ha (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) hρ hρ1 hω hrel
  obtain ⟨δ,C,κ,hδ,hC,hκ,hsol⟩ := local_exponential_exists_unique_of_quadratic
    (by positivity : 0<h/2) hsm hder hz B hly.1 hly.2
  refine ⟨δ,C,κ,hδ,hC,hκ,fun x₀ hx₀ => ?_⟩
  obtain ⟨y,hy₀,hyD,hyB,hyU⟩ := hsol (x₀-(h,s,s)) hx₀
  refine ⟨fun t => (h,s,s)+y t,by simp [hy₀],(fun t ht => ?_),(fun t ht => ?_),?_⟩
  · simpa [F] using! (hyD t ht).const_add (h,s,s)
  · exact ⟨hpositive (y t) (hyB t ht).1,by simpa using! (hyB t ht).2⟩

  · intro T hT z hz hzD
    have heq := hyU T hT (fun t => z t-(h,s,s)) (by simp [hz]) (by
      intro t ht
      simpa [F] using (hzD t ht).sub_const (h,s,s))
    intro t ht
    have hh := heq ht
    dsimp only at hh
    change (h,s,s)+y t=z t
    rw [hh]
    abel

/-- The nonlinear existence and exponential decay statement, with uniqueness
available in `open_loop_local_exponential_unique`. -/
theorem open_loop_local_exponential {H g α β h s : ℝ}
    (hH : 0<H) (hh : 0<h) (hs : 0<s) (ha : 0<α) (hb : 0≤β)
    (hab : α+β<1/2)
    (he₁ : α*s^2=g*h) (he₂ : (1-β)*s^2=g*(H+h)) :
    ∃ δ C κ : ℝ, 0<δ ∧ 0<C ∧ 0<κ ∧
      ∀ x₀ : State₃, ‖x₀-(h,s,s)‖<δ → ∃ x : ℝ → State₃,
        x 0=x₀ ∧ (∀ t≥0, HasDerivAt x (openLoopField H g α β (x t)) t) ∧
        ∀ t≥0, 0<(x t).1 ∧ ‖x t-(h,s,s)‖≤ C*exp (-κ*t)*‖x₀-(h,s,s)‖ := by
  obtain ⟨δ,C,κ,hδ,hC,hκ,hsol⟩ :=
    open_loop_local_exponential_unique hH hh hs ha hb hab he₁ he₂
  refine ⟨δ,C,κ,hδ,hC,hκ,?_⟩
  intro x₀ hx₀
  obtain ⟨x,hx,hd,hb,hu⟩ := hsol x₀ hx₀
  exact ⟨x,hx,hd,hb⟩

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.PlantStability -/

/- BEGIN SOURCE MODULE: ChainFountain.MeasurablePicard -/
/-
Adapted from mathlib's PicardLindelof.lean (pinned v4.19.0).
Copyright (c) 2021 Yury Kudryashov. All rights reserved.
Released under Apache 2.0 license as described in LICENSE.
Original authors: Yury Kudryashov, Winston Yin.
Changes: measurable time dependence; Lebesgue integral fixed points.
-/

namespace ChainFountain
open Filter Function Set Metric TopologicalSpace intervalIntegral MeasureTheory
open MeasureTheory.MeasureSpace (volume)
open scoped Filter Topology NNReal ENNReal Nat Interval
noncomputable section
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- Bounded, uniformly state-Lipschitz Caratheodory data. The measurability
condition is on every continuous test curve and contains no solution assumption. -/
structure IntegralPicard (E : Type*) [NormedAddCommGroup E] [NormedSpace ℝ E] where
  toFun : ℝ → E → E
  tMin : ℝ
  tMax : ℝ
  t₀ : Icc tMin tMax
  x₀ : E
  C : ℝ≥0
  L : ℝ≥0
  lipschitz_all : ∀ t, LipschitzWith L (toFun t)
  measurable_curve : ∀ f : ℝ → E, Continuous f →
    AEStronglyMeasurable (fun t => toFun t (f t)) volume
  bound_all : ∀ t x, ‖toFun t x‖ ≤ C

namespace IntegralPicard
variable (v : IntegralPicard E)
instance : CoeFun (IntegralPicard E) fun _ => ℝ → E → E := ⟨toFun⟩

theorem tMin_le_tMax : v.tMin ≤ v.tMax :=
  v.t₀.2.1.trans v.t₀.2.2

protected theorem nonempty_Icc : (Icc v.tMin v.tMax).Nonempty :=
  nonempty_Icc.2 v.tMin_le_tMax

/-- The maximum of distances from `t₀` to the endpoints of `[tMin, tMax]`. -/
def tDist : ℝ :=
  max (v.tMax - v.t₀) (v.t₀ - v.tMin)

theorem tDist_nonneg : 0 ≤ v.tDist :=
  le_max_iff.2 <| Or.inl <| sub_nonneg.2 v.t₀.2.2

theorem dist_t₀_le (t : Icc v.tMin v.tMax) : dist t v.t₀ ≤ v.tDist := by
  rw [Subtype.dist_eq, Real.dist_eq]
  rcases le_total t v.t₀ with ht | ht
  · rw [abs_of_nonpos (sub_nonpos.2 <| Subtype.coe_le_coe.2 ht), neg_sub]
    exact (sub_le_sub_left t.2.1 _).trans (le_max_right _ _)
  · rw [abs_of_nonneg (sub_nonneg.2 <| Subtype.coe_le_coe.2 ht)]
    exact (sub_le_sub_right t.2.2 _).trans (le_max_left _ _)

/-- Projection $ℝ → [t_{\min}, t_{\max}]$ sending $(-∞, t_{\min}]$ to $t_{\min}$ and $[t_{\max}, ∞)$
to $t_{\max}$. -/
def proj : ℝ → Icc v.tMin v.tMax :=
  projIcc v.tMin v.tMax v.tMin_le_tMax

theorem proj_coe (t : Icc v.tMin v.tMax) : v.proj t = t :=
  projIcc_val _ _

theorem proj_of_mem {t : ℝ} (ht : t ∈ Icc v.tMin v.tMax) : ↑(v.proj t) = t := by
  simp only [proj, projIcc_of_mem v.tMin_le_tMax ht]

@[continuity, fun_prop]
theorem continuous_proj : Continuous v.proj :=
  continuous_projIcc

/-- The space of curves $γ \colon [t_{\min}, t_{\max}] \to E$ such that $γ(t₀) = x₀$ and $γ$ is
Lipschitz continuous with constant $C$. The map sending $γ$ to
$\mathbf Pγ(t)=x₀ + ∫_{t₀}^{t} v(τ, γ(τ))\,dτ$ is a contracting map on this space, and its fixed
point is a solution of the ODE $\dot x=v(t, x)$. -/
structure FunSpace where
  /-- The particular curve represented by this object. -/
  toFun : Icc v.tMin v.tMax → E
  map_t₀' : toFun v.t₀ = v.x₀
  lipschitz' : LipschitzWith v.C toFun

namespace FunSpace

variable {v}
variable (f : FunSpace v)

instance : CoeFun (FunSpace v) fun _ => Icc v.tMin v.tMax → E :=
  ⟨toFun⟩

instance : Inhabited v.FunSpace :=
  ⟨⟨fun _ => v.x₀, rfl, (LipschitzWith.const _).weaken (zero_le)⟩⟩

protected theorem lipschitz : LipschitzWith v.C f :=
  f.lipschitz'

protected theorem continuous : Continuous f :=
  f.lipschitz.continuous

/-- Each curve in `IntegralPicard.FunSpace` is continuous. -/
def toContinuousMap : v.FunSpace ↪ C(Icc v.tMin v.tMax, E) :=
  ⟨fun f => ⟨f, f.continuous⟩, fun f g h => by cases f; cases g; simpa using! h⟩

instance : MetricSpace v.FunSpace :=
  MetricSpace.induced toContinuousMap toContinuousMap.injective inferInstance

theorem isUniformInducing_toContinuousMap : IsUniformInducing (@toContinuousMap _ _ _ v) :=
  ⟨rfl⟩

theorem range_toContinuousMap :
    range toContinuousMap =
      {f : C(Icc v.tMin v.tMax, E) | f v.t₀ = v.x₀ ∧ LipschitzWith v.C f} := by
  ext f; constructor
  · rintro ⟨⟨f, hf₀, hf_lip⟩, rfl⟩; exact ⟨hf₀, hf_lip⟩
  · rcases f with ⟨f, hf⟩; rintro ⟨hf₀, hf_lip⟩; exact ⟨⟨f, hf₀, hf_lip⟩, rfl⟩

theorem map_t₀ : f v.t₀ = v.x₀ :=
  f.map_t₀'

/-- Only the continuous test curve is extended by projection. Time in the
measurable vector field is left untouched. -/
def vComp (t : ℝ) : E := v t (f (v.proj t))

theorem vComp_apply_coe (t : Icc v.tMin v.tMax) : f.vComp t = v t (f t) := by
  simp only [vComp, proj_coe]

theorem measurable_vComp : AEStronglyMeasurable f.vComp volume :=
  v.measurable_curve _ (f.continuous.comp v.continuous_proj)

theorem norm_vComp_le (t : ℝ) : ‖f.vComp t‖ ≤ v.C := v.bound_all _ _

theorem dist_apply_le_dist (f₁ f₂ : FunSpace v) (t : Icc v.tMin v.tMax) :
    dist (f₁ t) (f₂ t) ≤ dist f₁ f₂ :=
  @ContinuousMap.dist_apply_le_dist _ _ _ _ _ (toContinuousMap f₁) (toContinuousMap f₂) _

theorem dist_le_of_forall {f₁ f₂ : FunSpace v} {d : ℝ} (h : ∀ t, dist (f₁ t) (f₂ t) ≤ d) :
    dist f₁ f₂ ≤ d :=
  (@ContinuousMap.dist_le_iff_of_nonempty _ _ _ _ _ (toContinuousMap f₁) (toContinuousMap f₂) _
    v.nonempty_Icc.to_subtype).2 h

instance [CompleteSpace E] : CompleteSpace v.FunSpace := by
  refine (completeSpace_iff_isComplete_range isUniformInducing_toContinuousMap).2
      (IsClosed.isComplete ?_)
  rw [range_toContinuousMap, ofPred_and]
  refine (isClosed_eq (continuous_eval_const _) continuous_const).inter ?_
  have : IsClosed {f : Icc v.tMin v.tMax → E | LipschitzWith v.C f} :=
    isClosed_setOfPred_lipschitzWith v.C
  exact this.preimage continuous_coeFun

theorem intervalIntegrable_vComp (t₁ t₂ : ℝ) : IntervalIntegrable f.vComp volume t₁ t₂ := by
  rw [intervalIntegrable_iff]
  exact Measure.integrableOn_of_bounded measure_Ioc_lt_top.ne f.measurable_vComp
    (Filter.Eventually.of_forall f.norm_vComp_le)

/-- The Picard-Lindelöf operator. This is a contracting map on `IntegralPicard.FunSpace v` such
that the fixed point of this map is the solution of the corresponding ODE.

More precisely, some iteration of this map is a contracting map. -/
def next (f : FunSpace v) : FunSpace v where
  toFun t := v.x₀ + ∫ τ : ℝ in v.t₀..t, f.vComp τ
  map_t₀' := by simp only [integral_same, add_zero]
  lipschitz' := LipschitzWith.of_dist_le_mul fun t₁ t₂ => by
    rw [dist_add_left, dist_eq_norm,
      integral_interval_sub_left (f.intervalIntegrable_vComp _ _) (f.intervalIntegrable_vComp _ _)]
    exact norm_integral_le_of_norm_le_const fun t _ => f.norm_vComp_le _

theorem next_apply (t : Icc v.tMin v.tMax) : f.next t = v.x₀ + ∫ τ : ℝ in v.t₀..t, f.vComp τ :=
  rfl

theorem dist_next_apply_le_of_le {f₁ f₂ : FunSpace v} {n : ℕ} {d : ℝ}
    (h : ∀ t, dist (f₁ t) (f₂ t) ≤ (v.L * |t.1 - v.t₀|) ^ n / n ! * d) (t : Icc v.tMin v.tMax) :
    dist (next f₁ t) (next f₂ t) ≤ (v.L * |t.1 - v.t₀|) ^ (n + 1) / (n + 1)! * d := by
  simp only [dist_eq_norm, next_apply, add_sub_add_left_eq_sub, ←
    intervalIntegral.integral_sub (intervalIntegrable_vComp _ _ _)
      (intervalIntegrable_vComp _ _ _),
    norm_integral_eq_norm_integral_uIoc] at *
  calc
    ‖∫ τ in Ι (v.t₀ : ℝ) t, f₁.vComp τ - f₂.vComp τ‖ ≤
        ∫ τ in Ι (v.t₀ : ℝ) t, v.L * ((v.L * |τ - v.t₀|) ^ n / n ! * d) := by
      refine norm_integral_le_of_norm_le (Continuous.integrableOn_uIoc (by fun_prop)) ?_
      refine (ae_restrict_mem measurableSet_Ioc).mono fun τ hτ ↦ ?_
      refine (v.lipschitz_all τ).norm_sub_le_of_le ((h _).trans_eq ?_)
      rw [v.proj_of_mem]
      exact uIcc_subset_Icc v.t₀.2 t.2 <| Ioc_subset_Icc_self hτ
    _ = (v.L * |t.1 - v.t₀|) ^ (n + 1) / (n + 1)! * d := by
      simp_rw [mul_pow, div_eq_mul_inv, mul_assoc, MeasureTheory.integral_const_mul,
        MeasureTheory.integral_mul_const, integral_pow_abs_sub_uIoc, div_eq_mul_inv,
        pow_succ' (v.L : ℝ), Nat.factorial_succ, Nat.cast_mul, Nat.cast_succ, mul_inv, mul_assoc]

theorem dist_iterate_next_apply_le (f₁ f₂ : FunSpace v) (n : ℕ) (t : Icc v.tMin v.tMax) :
    dist (next^[n] f₁ t) (next^[n] f₂ t) ≤ (v.L * |t.1 - v.t₀|) ^ n / n ! * dist f₁ f₂ := by
  induction n generalizing t with
  | zero =>
    rw [pow_zero, Nat.factorial_zero, Nat.cast_one, div_one, one_mul]
    exact dist_apply_le_dist f₁ f₂ t
  | succ n ihn =>
    rw [iterate_succ_apply', iterate_succ_apply']
    exact dist_next_apply_le_of_le ihn _

theorem dist_iterate_next_le (f₁ f₂ : FunSpace v) (n : ℕ) :
    dist (next^[n] f₁) (next^[n] f₂) ≤ (v.L * v.tDist) ^ n / n ! * dist f₁ f₂ := by
  refine dist_le_of_forall fun t => (dist_iterate_next_apply_le _ _ _ _).trans ?_
  have : |(t - v.t₀ : ℝ)| ≤ v.tDist := v.dist_t₀_le t
  gcongr

end FunSpace

theorem exists_contracting_iterate :
    ∃ (N : ℕ) (K : _), ContractingWith K (FunSpace.next : v.FunSpace → v.FunSpace)^[N] := by
  rcases ((FloorSemiring.tendsto_pow_div_factorial_atTop (v.L * v.tDist)).eventually
    (gt_mem_nhds zero_lt_one)).exists with ⟨N, hN⟩
  have : (0 : ℝ) ≤ (v.L * v.tDist) ^ N / N ! :=
    div_nonneg (pow_nonneg (mul_nonneg v.L.2 v.tDist_nonneg) _) (Nat.cast_nonneg _)
  exact ⟨N, ⟨_, this⟩, hN, LipschitzWith.of_dist_le_mul fun f g =>
    FunSpace.dist_iterate_next_le f g N⟩

theorem exists_fixed [CompleteSpace E] : ∃ f : v.FunSpace, f.next = f :=
  let ⟨_N, _K, hK⟩ := exists_contracting_iterate v
  ⟨_, hK.isFixedPt_fixedPoint_iterate⟩


/-- A true finite-horizon construction for measurable time dependence, in
Lebesgue integral form. No existing trajectory is supplied. -/
theorem exists_integral_solution [CompleteSpace E] :
    ∃ x : ℝ → E, LipschitzWith v.C x ∧ x v.t₀=v.x₀ ∧
      ∀ t∈Icc v.tMin v.tMax, x t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (x s) := by
  obtain ⟨f,hf⟩ := v.exists_fixed
  refine ⟨fun t => f (v.proj t), ?_, ?_, ?_⟩
  · simpa only [mul_one,Function.comp_def,IntegralPicard.proj] using!
      f.lipschitz.comp (LipschitzWith.projIcc v.tMin_le_tMax)
  · simpa only [v.proj_coe] using! f.map_t₀
  · intro t ht
    have hproj : v.proj t = ⟨t,ht⟩ := by apply Subtype.ext; exact v.proj_of_mem ht
    have hn := congrArg (fun f : v.FunSpace => f ⟨t,ht⟩) hf
    simpa [FunSpace.next_apply,FunSpace.vComp,hproj] using! hn.symm

end IntegralPicard
end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.MeasurablePicard -/

/- BEGIN SOURCE MODULE: ChainFountain.MeasurableGlobal -/

namespace ChainFountain
noncomputable section
open Set Metric Filter Function MeasureTheory intervalIntegral
open scoped Topology NNReal
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

theorem IntegralPicard.fixed_unique (v : IntegralPicard E) (f g : v.FunSpace)
    (hf : f.next=f) (hg : g.next=g) : f=g := by
  have _complete := ‹CompleteSpace E›
  obtain ⟨N,K,hK⟩ := v.exists_contracting_iterate
  have hfN : (IntegralPicard.FunSpace.next^[N]) f=f := IsFixedPt.iterate hf N
  have hgN : (IntegralPicard.FunSpace.next^[N]) g=g := IsFixedPt.iterate hg N
  have hi := hK.2.dist_le_mul f g
  rw [hfN,hgN] at hi
  apply dist_le_zero.mp
  have hlt : (K:ℝ)<1 := hK.1
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [dist_nonneg (x:=f) (y:=g)]

/-- Uniqueness on a finite interval for the Lipschitz integral solutions just
constructed. This is proved by the factorial Picard estimate. -/
theorem IntegralPicard.integral_unique (v : IntegralPicard E) {x y : ℝ → E}
    (hxL : LipschitzWith v.C x) (hyL : LipschitzWith v.C y)
    (hx₀ : x v.t₀=v.x₀) (hy₀ : y v.t₀=v.x₀)
    (hx : ∀ t∈Icc v.tMin v.tMax, x t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (x s))
    (hy : ∀ t∈Icc v.tMin v.tMax, y t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (y s)) :
    EqOn x y (Icc v.tMin v.tMax) := by
  let f : v.FunSpace := ⟨fun t => x t,hx₀,by simpa using! hxL.comp (LipschitzWith.subtype_val _)⟩
  let g : v.FunSpace := ⟨fun t => y t,hy₀,by simpa using! hyL.comp (LipschitzWith.subtype_val _)⟩
  have hf : f.next=f := by
    apply IntegralPicard.FunSpace.toContinuousMap.injective
    apply ContinuousMap.ext
    intro t
    change v.x₀+∫ s in (v.t₀:ℝ)..(t:ℝ), v s (x (v.proj s)) = x t
    rw [hx t t.property]
    congr 1
    apply intervalIntegral.integral_congr
    intro s hs
    dsimp only
    rw [v.proj_of_mem (uIcc_subset_Icc v.t₀.property t.property hs)]
  have hg : g.next=g := by
    apply IntegralPicard.FunSpace.toContinuousMap.injective
    apply ContinuousMap.ext
    intro t
    change v.x₀+∫ s in (v.t₀:ℝ)..(t:ℝ), v s (y (v.proj s)) = y t
    rw [hy t t.property]
    congr 1
    apply intervalIntegral.integral_congr
    intro s hs
    dsimp only
    rw [v.proj_of_mem (uIcc_subset_Icc v.t₀.property t.property hs)]
  have he := v.fixed_unique f g hf hg
  intro t ht
  exact congrArg (fun z : v.FunSpace => z ⟨t,ht⟩) he

/-- Arbitrary measurable time dependence is allowed. The hypotheses contain
only the field and its global bounds; the Lipschitz integral solution is built
on the entire real line by gluing unique finite-horizon fixed points. -/
theorem bounded_measurable_global_integral_exists
    {F : ℝ → E → E} {L C : ℝ≥0}
    (hL : ∀ t, LipschitzWith L (F t))
    (hMeas : ∀ f : ℝ → E, Continuous f → AEStronglyMeasurable (fun t => F t (f t)) volume)
    (hC : ∀ t x, ‖F t x‖≤ C) (x₀ : E) :
    ∃ x : ℝ → E, LipschitzWith C x ∧ x 0=x₀ ∧
      ∀ t, x t=x₀+∫ s in (0:ℝ)..t, F s (x s) := by
  let data (a : ℝ) : IntegralPicard E :=
    { toFun := F, tMin := -|a|, tMax := |a|,
      t₀ := ⟨0,by constructor <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [abs_nonneg a]⟩,
      x₀ := x₀, C := C, L := L,
      lipschitz_all := hL, measurable_curve := hMeas, bound_all := hC }
  have hex (a : ℝ) := (data a).exists_integral_solution
  choose f hfL hf₀ hfI using hex
  have agree {a b : ℝ} (ha : 0≤ a) (hab : a≤ b) : EqOn (f a) (f b) (Icc (-a) a) := by
    have hb : 0≤ b := ha.trans hab
    have hfa : ∀ t∈Icc (data a).tMin (data a).tMax,
        f a t=(data a).x₀+∫ s in ((data a).t₀:ℝ)..t, (data a) s (f a s) := hfI a
    have hfb : ∀ t∈Icc (data a).tMin (data a).tMax,
        f b t=(data a).x₀+∫ s in ((data a).t₀:ℝ)..t, (data a) s (f b s) := by
      intro t ht
      apply hfI b
      dsimp [data] at ht ⊢
      rw [abs_of_nonneg ha] at ht
      rw [abs_of_nonneg hb]
      exact ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [ht.1],ht.2.trans hab⟩
    simpa [data,abs_of_nonneg ha] using! (data a).integral_unique
      (hfL a) (hfL b) (hf₀ a) (hf₀ b) hfa hfb
  let x : ℝ → E := fun t => f (|t|+1) t
  have heq {a : ℝ} (ha : 0≤ a) : EqOn x (f a) (Icc (-a) a) := by
    intro t ht
    by_cases hab : |t|+1≤ a
    · exact agree (by positivity) hab (abs_le.mp (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith : |t|≤|t|+1))
    · exact (agree ha (le_of_not_ge hab) ht).symm
  have hxL : LipschitzWith C x := by
    apply LipschitzWith.of_dist_le_mul
    intro t s
    let a := |t|+|s|+1
    have ha : 0≤ a := by dsimp [a]; positivity
    have ht : t∈Icc (-a) a := abs_le.mp (by dsimp [a]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [abs_nonneg s])
    have hs : s∈Icc (-a) a := abs_le.mp (by dsimp [a]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [abs_nonneg t])
    rw [heq ha ht,heq ha hs]
    exact (hfL a).dist_le_mul t s
  refine ⟨x,hxL,by simpa [x,data] using! hf₀ 1,fun t => ?_⟩
  let a := |t|+1
  have ha : 0≤ a := by dsimp [a]; positivity
  have ht : t∈Icc (-a) a := abs_le.mp (by dsimp [a]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith)
  have hzero : (0:ℝ)∈Icc (-a) a := ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith,ha⟩
  rw [heq ha ht]
  have hi := hfI a t (by simpa [data,abs_of_nonneg ha] using! ht)
  dsimp [data] at hi
  rw [hi]
  congr 1
  apply intervalIntegral.integral_congr
  intro s hs
  dsimp only
  rw [heq ha (uIcc_subset_Icc hzero ht hs)]

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.MeasurableGlobal -/

/- BEGIN SOURCE MODULE: ChainFountain.LebesgueFTC -/

namespace ChainFountain
noncomputable section
open Set Metric Filter MeasureTheory intervalIntegral
open scoped Topology NNReal ENNReal
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

/-- The almost-everywhere fundamental theorem for the Lebesgue primitive,
derived from the one-dimensional Vitali differentiation theorem. -/
theorem locally_integrable_primitive_ae_derivative {f : ℝ → E}
    (hf : LocallyIntegrable f volume) (a : ℝ) :
    ∀ᵐ t ∂volume, HasDerivAt (fun t => ∫ s in a..t, f s) (f t) t := by
  have hi (u v : ℝ) : IntervalIntegrable f volume u v := by
    rw [intervalIntegrable_iff]
    exact (hf.integrableOn_isCompact isCompact_uIcc).mono_set uIoc_subset_uIcc
  filter_upwards [(IsUnifLocDoublingMeasure.vitaliFamily (volume:Measure ℝ) 1).ae_tendsto_average hf]
    with t ht
  rw [hasDerivAt_iff_tendsto_slope,← nhdsLT_sup_nhdsGT,tendsto_sup]
  constructor
  · have hl := ht.comp (Real.tendsto_Icc_vitaliFamily_left t)
    apply hl.congr'
    filter_upwards [self_mem_nhdsWithin] with y (hy : y<t)
    simp only [Function.comp_apply,slope_def_module]
    rw [integral_interval_sub_left (hi a y) (hi a t),integral_symm y t]
    rw [setAverage_eq,Real.volume_real_Icc_of_le hy.le,integral_Icc_eq_integral_Ioc,
      ← integral_of_le hy.le]
    rw [show y-t=-(t-y) by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring,inv_neg,neg_smul,smul_neg,neg_neg]
  · have hr := ht.comp (Real.tendsto_Icc_vitaliFamily_right t)
    apply hr.congr'
    filter_upwards [self_mem_nhdsWithin] with y (hy : t<y)
    simp only [Function.comp_apply,slope_def_module]
    rw [integral_interval_sub_left (hi a y) (hi a t),setAverage_eq,
      Real.volume_real_Icc_of_le hy.le,integral_Icc_eq_integral_Ioc,← integral_of_le hy.le]

/-- Global Caratheodory existence in both integral and a.e. differential form
for bounded measurable-time, uniformly state-Lipschitz fields. -/
theorem bounded_measurable_global_ae_exists
    {F : ℝ → E → E} {L C : ℝ≥0}
    (hL : ∀ t, LipschitzWith L (F t))
    (hMeas : ∀ f : ℝ → E, Continuous f → AEStronglyMeasurable (fun t => F t (f t)) volume)
    (hC : ∀ t x, ‖F t x‖≤ C) (x₀ : E) :
    ∃ x : ℝ → E, LipschitzWith C x ∧ x 0=x₀ ∧
      (∀ t, x t=x₀+∫ s in (0:ℝ)..t, F s (x s)) ∧
      ∀ᵐ t ∂volume, HasDerivAt x (F t (x t)) t := by
  obtain ⟨x,hxL,hx₀,hxI⟩ := bounded_measurable_global_integral_exists hL hMeas hC x₀
  have hloc : LocallyIntegrable (fun t => F t (x t)) volume :=
    (memLp_top_of_bound (hMeas x hxL.continuous) C
      (Filter.Eventually.of_forall (fun t => hC t (x t)))).locallyIntegrable le_top
  refine ⟨x,hxL,hx₀,hxI,?_⟩
  filter_upwards [locally_integrable_primitive_ae_derivative hloc 0] with t ht
  convert! ht.const_add x₀ using 1
  exact funext hxI

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.LebesgueFTC -/

/- BEGIN SOURCE MODULE: ChainFountain.LipschitzFTC -/

namespace ChainFountain
noncomputable section
open Set Filter MeasureTheory intervalIntegral
open scoped Topology NNReal

/-- Reverse FTC for a Lipschitz real function, proved by dominated convergence
of difference quotients. This excludes singular continuous counterexamples to
an a.e.-derivative-only comparison argument. -/
theorem lipschitz_integral_deriv {f : ℝ → ℝ} {L : ℝ≥0}
    (hf : LipschitzWith L f) {a b : ℝ} (hab : a≤ b) :
    ∫ t in a..b, deriv f t = f b-f a := by
  let q (ε t : ℝ) := ε⁻¹*(f (t+ε)-f t)
  have hbound {ε : ℝ} (hε : 0<ε) (t : ℝ) : ‖q ε t‖≤ L := by
    have hl := hf.norm_sub_le (t+ε) t
    simp only [add_sub_cancel_left,Real.norm_eq_abs,abs_of_pos hε] at hl
    dsimp [q]
    rw [abs_mul,abs_inv,abs_of_pos hε]
    calc
      ε⁻¹*‖f (t+ε)-f t‖ ≤ ε⁻¹*((L:ℝ)*ε) := mul_le_mul_of_nonneg_left hl (by positivity)
      _ = L := by field_simp
  have hlim : Tendsto (fun ε => ∫ t in Ioc a b, q ε t) (𝓝[>] 0)
      (𝓝 (∫ t in Ioc a b, deriv f t)) := by
    apply MeasureTheory.tendsto_integral_filter_of_dominated_convergence (fun _ => (L:ℝ))
    · apply Filter.Eventually.of_forall
      intro ε
      have hc : Continuous (q ε) := by
        dsimp [q]
        exact continuous_const.mul ((hf.continuous.comp (continuous_id.add continuous_const)).sub hf.continuous)
      exact hc.aestronglyMeasurable
    · filter_upwards [self_mem_nhdsWithin] with ε (hε:0<ε)
      exact Filter.Eventually.of_forall (hbound hε)
    · exact integrable_const _
    · filter_upwards [ae_restrict_of_ae hf.ae_differentiableAt_real] with t ht
      simpa [q,smul_eq_mul] using! ht.hasDerivAt.tendsto_slope_zero_right
  let P : ℝ → ℝ := fun t => ∫ s in (0:ℝ)..t, f s
  have hP (t : ℝ) : HasDerivAt P (f t) t :=
    integral_hasDerivAt_right (hf.continuous.intervalIntegrable _ _)
      hf.continuous.aestronglyMeasurable.stronglyMeasurableAtFilter hf.continuous.continuousAt
  have hboundary := (hP b).tendsto_slope_zero_right.sub (hP a).tendsto_slope_zero_right
  have heq (ε : ℝ) : (∫ t in Ioc a b, q ε t) =
      ε⁻¹*(P (b+ε)-P b)-ε⁻¹*(P (a+ε)-P a) := by
    rw [← integral_of_le hab]
    change (∫ t in a..b, ε⁻¹*(f (t+ε)-f t)) = _
    have hshift : IntervalIntegrable (fun t => f (t+ε)) volume a b :=
      (hf.continuous.comp (continuous_id.add continuous_const)).intervalIntegrable _ _
    rw [intervalIntegral.integral_const_mul,intervalIntegral.integral_sub
      hshift
      (hf.continuous.intervalIntegrable _ _),integral_comp_add_right]
    have hi (u v : ℝ) : IntervalIntegrable f volume u v := hf.continuous.intervalIntegrable u v
    rw [integral_interval_sub_interval_comm' (hi (a+ε) (b+ε)) (hi a b) (hi (a+ε) a)]
    dsimp [P]
    rw [integral_interval_sub_left (hi 0 (b+ε)) (hi 0 b),
      integral_interval_sub_left (hi 0 (a+ε)) (hi 0 a)]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hother : Tendsto (fun ε => ∫ t in Ioc a b, q ε t) (𝓝[>] 0) (𝓝 (f b-f a)) := by
    simpa only [heq,smul_eq_mul] using! hboundary
  rw [integral_of_le hab]
  exact tendsto_nhds_unique hlim hother

/-- A.e. derivative comparison for Lipschitz curves, with an actual integral
proof rather than an assumption that an a.e. inequality implies monotonicity. -/
theorem lipschitz_nonincreasing_of_ae_derivative {f f' : ℝ → ℝ} {L : ℝ≥0}
    (hf : LipschitzWith L f) {a b : ℝ} (hab : a≤ b)
    (hd : ∀ᵐ t ∂volume, t∈Icc a b → HasDerivAt f (f' t) t)
    (hneg : ∀ᵐ t ∂volume, t∈Icc a b → f' t≤0) : f b≤ f a := by
  have hle : ∫ t in a..b, deriv f t ≤ 0 := by
    rw [intervalIntegral.integral_of_le hab]
    apply integral_nonpos_of_ae
    filter_upwards [ae_restrict_of_ae hd,ae_restrict_of_ae hneg,ae_restrict_mem measurableSet_Ioc]
      with t ht hn hmem
    rw [(ht (Ioc_subset_Icc_self hmem)).deriv]
    exact hn (Ioc_subset_Icc_self hmem)
  rw [lipschitz_integral_deriv hf hab] at hle
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

theorem lipschitzOn_nonincreasing_of_ae_derivative {f f' : ℝ → ℝ} {L : ℝ≥0}
    {a b : ℝ} (hab : a≤ b) (hf : LipschitzOnWith L f (Icc a b))
    (hd : ∀ᵐ t ∂volume, t∈Ioo a b → HasDerivAt f (f' t) t)
    (hneg : ∀ᵐ t ∂volume, t∈Ioo a b → f' t≤0) : f b≤ f a := by
  by_cases heq : a=b
  · simp [heq]
  have hab' : a<b := lt_of_le_of_ne hab heq
  let g : ℝ → ℝ := fun t => f (projIcc a b hab t)
  have hgl : LipschitzWith L g := by
    simpa only [mul_one,Function.comp_def,Set.domRestrict_apply] using!
      hf.to_restrict.comp (LipschitzWith.projIcc hab)
  have he (t : ℝ) (ht : t∈Ioo a b) : g =ᶠ[𝓝 t] f := by
    filter_upwards [Ioo_mem_nhds ht.1 ht.2] with s hs
    simp [g,projIcc_of_mem hab (Ioo_subset_Icc_self hs)]
  have hneq (c : ℝ) : ∀ᵐ t ∂volume, t≠c := by
    simp [ae_iff,measure_singleton]
  have hgd : ∀ᵐ t ∂volume, t∈Icc a b → HasDerivAt g (f' t) t := by
    filter_upwards [hd,hneq a,hneq b] with t ht hta htb hmem
    have ho : t∈Ioo a b := ⟨lt_of_le_of_ne hmem.1 (Ne.symm hta),lt_of_le_of_ne hmem.2 htb⟩
    exact (ht ho).congr_of_eventuallyEq (he t ho)
  have hgn : ∀ᵐ t ∂volume, t∈Icc a b → f' t≤0 := by
    filter_upwards [hneg,hneq a,hneq b] with t ht hta htb hmem
    exact ht ⟨lt_of_le_of_ne hmem.1 (Ne.symm hta),lt_of_le_of_ne hmem.2 htb⟩
  have h := lipschitz_nonincreasing_of_ae_derivative hgl hab hgd hgn
  simpa [g,projIcc_of_mem hab (left_mem_Icc.mpr hab),projIcc_of_mem hab (right_mem_Icc.mpr hab)] using! h

/-- A Lipschitz curve with a continuous a.e. derivative is classical. This is
used for the height/falling components, which have no direct disturbance term. -/
theorem lipschitz_ae_continuous_derivative {f g : ℝ → ℝ} {L : ℝ≥0}
    (hf : LipschitzWith L f) (hg : Continuous g)
    (hd : ∀ᵐ t ∂volume, HasDerivAt f (g t) t) :
    ∀ t, HasDerivAt f (g t) t := by
  have hie (a b : ℝ) : ∫ t in a..b, deriv f t = f b-f a := by
    rcases le_total a b with hab | hba
    · exact lipschitz_integral_deriv hf hab
    · rw [integral_symm,lipschitz_integral_deriv hf hba]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have heq (t : ℝ) : f t=f 0+∫ s in (0:ℝ)..t, g s := by
    have he : (∫ s in (0:ℝ)..t, deriv f s) = ∫ s in (0:ℝ)..t, g s := by
      apply intervalIntegral.integral_congr_ae
      filter_upwards [hd] with s hs _
      exact hs.deriv
    rw [hie] at he
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  intro t
  have hp := intervalIntegral.integral_hasDerivAt_right (hg.intervalIntegrable 0 t)
    hg.aestronglyMeasurable.stronglyMeasurableAtFilter hg.continuousAt
  convert! hp.const_add (f 0) using 1
  exact funext heq

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.LipschitzFTC -/

/- BEGIN SOURCE MODULE: ChainFountain.AEComparison -/

namespace ChainFountain
noncomputable section
open Set Metric Real Filter MeasureTheory
open scoped Topology NNReal

/-- A smooth function of a Lipschitz curve is Lipschitz on a compact interval.
The bound is obtained on a compact convex ball containing the curve. -/
theorem smooth_comp_lipschitzOn
    {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [ProperSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    {f : E → F} {x : ℝ → E} {K : ℝ≥0} {a b : ℝ}
    (hf : ContDiff ℝ 1 f) (hx : LipschitzOnWith K x (Icc a b)) :
    ∃ L : ℝ≥0, LipschitzOnWith L (fun t => f (x t)) (Icc a b) := by
  obtain ⟨N,hN⟩ := isCompact_Icc.exists_bound_of_continuousOn hx.continuousOn
  obtain ⟨L,C,hL,_⟩ := smooth_compact_convex_bounds isOpen_univ hf.contDiffOn
    (isCompact_closedBall (0:E) (max N 0)) (convex_closedBall (0:E) (max N 0)) (subset_univ _)
  refine ⟨L*K,hL.comp hx (fun t ht => ?_)⟩
  simpa only [mem_closedBall,dist_zero_right] using! (hN t ht).trans (le_max_left N 0)

/-- Scalar Gronwall comparison for Lipschitz curves whose differential inequality
holds only almost everywhere. The integrating-factor monotonicity is derived
from the proved Lipschitz FTC. -/
theorem scalar_comparison_ae {V V' : ℝ → ℝ} {T κ C : ℝ} {L : ℝ≥0}
    (hκ : 0<κ) (hV : LipschitzOnWith L V (Icc 0 T))
    (hd : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt V (V' t) t)
    (hb : ∀ᵐ t ∂volume, t∈Ioo 0 T → V' t≤ -2*κ*V t+C) :
    ∀ t∈Icc 0 T, V t≤ envelope (V 0) κ C t := by
  let W (t : ℝ) := (V t-C/(2*κ))*exp (2*κ*t)
  let W' (t : ℝ) := (V' t+2*κ*(V t-C/(2*κ)))*exp (2*κ*t)
  have hsm : ContDiff ℝ 1 (fun p : ℝ×ℝ => (p.2-C/(2*κ))*exp (2*κ*p.1)) := by fun_prop
  obtain ⟨LW,hLW⟩ := smooth_comp_lipschitzOn hsm (LipschitzWith.id.lipschitzOnWith.prodMk hV)
  have hWd : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt W (W' t) t := by
    filter_upwards [hd] with t ht hmem
    convert! ((ht hmem).sub_const (C/(2*κ))).mul
      (((hasDerivAt_id t).const_mul (2*κ)).exp) using 1 <;> dsimp [W,W'] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hWn : ∀ᵐ t ∂volume, t∈Ioo 0 T → W' t≤0 := by
    filter_upwards [hb] with t ht hmem
    have heq : 2*κ*(C/(2*κ))=C := by field_simp
    dsimp [W']
    apply mul_nonpos_of_nonpos_of_nonneg _ (exp_pos _).le
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [ht hmem]
  intro t ht
  have hsub : Icc (0:ℝ) t ⊆ Icc 0 T := Icc_subset_Icc le_rfl ht.2
  have hw := lipschitzOn_nonincreasing_of_ae_derivative ht.1 (hLW.mono hsub)
    (hWd.mono (fun s hs hmem => hs ⟨hmem.1,hmem.2.trans_le ht.2⟩))
    (hWn.mono (fun s hs hmem => hs ⟨hmem.1,hmem.2.trans_le ht.2⟩))
  change W t≤ W 0 at hw
  dsimp [W] at hw
  simp only [mul_zero,exp_zero,mul_one] at hw
  have hdiv : V t-C/(2*κ) ≤ (V 0-C/(2*κ))/exp (2*κ*t) :=
    (le_div_iff₀ (exp_pos _)).mpr hw
  have heq : envelope (V 0) κ C t = C/(2*κ)+(V 0-C/(2*κ))/exp (2*κ*t) := by
    unfold envelope
    rw [show -2*κ*t=-(2*κ*t) by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring,exp_neg]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [heq]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

/-- The robust energy envelope for genuinely a.e. error equations. -/
theorem robust_error_estimate_ae {e z G d : ℝ → ℝ} {T k₀ k₁ k₂ κ κd dbar : ℝ}
    {Le Lz : ℝ≥0} (hk₀ : 0≤ k₀) (hκ : 0<κ) (hk₁ : κ≤ k₁) (hk₂ : κ≤ k₂) (hκd : 0<κd)
    (hel : LipschitzOnWith Le e (Icc 0 T)) (hzl : LipschitzOnWith Lz z (Icc 0 T))
    (he : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt e (errorRate k₁ (e t) (z t)) t)
    (hz : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt z (zRate k₀ k₂ κd (G t) (d t) (e t) (z t)) t)
    (hb : ∀ᵐ t ∂volume, t∈Ioo 0 T → |d t|≤ dbar) :
    ∀ t∈Icc 0 T, errorEnergy k₀ (e t) (z t)≤
      exp (-2*κ*t)*errorEnergy k₀ (e 0) (z 0)+dbar^2/(16*κ*κd)*(1-exp (-2*κ*t)) := by
  have hsm : ContDiff ℝ 1 (fun p : ℝ×ℝ => errorEnergy k₀ p.1 p.2) := by
    unfold errorEnergy
    fun_prop (disch := norm_num)
  obtain ⟨L,hL⟩ := smooth_comp_lipschitzOn hsm (hel.prodMk hzl)
  have hd : ∀ᵐ t ∂volume, t∈Ioo 0 T →
      HasDerivAt (fun s => errorEnergy k₀ (e s) (z s))
        (-k₀*k₁*(e t)^2-k₂*(z t)^2/4-κd*(G t)^2*(z t)^2/4+G t*z t*d t/4) t := by
    filter_upwards [he,hz] with t het hzt hmem
    exact energy_hasDerivAt_errors (het hmem) (hzt hmem)
  have hi := scalar_comparison_ae hκ hL hd (by
    filter_upwards [hb] with t ht hmem
    exact robust_decay_uniform hk₀ hk₁ hk₂ hκd (ht hmem))
  intro t ht
  convert! hi t ht using 1
  unfold envelope
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.AEComparison -/

/- BEGIN SOURCE MODULE: ChainFountain.StochasticEstimates -/

namespace ChainFountain
noncomputable section
open Set Filter MeasureTheory Real
open scoped Topology

/-- Actual second derivative in the noise direction: this identifies the
Hessian term, separately from the semimartingale Ito formula. -/
theorem energy_noise_second_derivative (k₀ e z σ G : ℝ) :
    (∀ a : ℝ, HasDerivAt (fun b => errorEnergy k₀ e (z+σ*G*b))
      ((z+σ*G*a)*σ*G/4) a) ∧
    ∀ a : ℝ, HasDerivAt (fun b => (z+σ*G*b)*σ*G/4) ((σ*G)^2/4) a := by
  constructor
  · intro a
    have hd := (((hasDerivAt_id a).const_mul (σ*G)).const_add z).pow 2
    convert! (hd.div_const 8).const_add (k₀*e^2/2) using 1 <;>
      dsimp [errorEnergy] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring_nf
  · intro a
    convert! (((((hasDerivAt_id a).const_mul (σ*G)).const_add z).mul_const σ).mul_const G).div_const 4 using 1 <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- Exact finite-partition square identity underlying the quadratic Ito rule. -/
theorem quadratic_partition_identity (z : ℕ → ℝ) (n : ℕ) :
    z n^2-z 0^2 = ∑ i∈Finset.range n,
      (2*z i*(z (i+1)-z i)+(z (i+1)-z i)^2) := by
  induction n with
  | zero => simp
  | succ n ih => rw [Finset.sum_range_succ,← ih]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- The quadratic change-of-variable identity follows from convergence of left
Riemann sums and squared increments. These convergence hypotheses are explicit;
this theorem does not assert that Brownian-driven solutions satisfy them. -/
theorem quadratic_ito_of_partition_limits {z : ℕ → ℕ → ℝ} {z₀ zT I Q : ℝ}
    (hstart : ∀ n, z n 0=z₀) (hend : ∀ n, z n n=zT)
    (hI : Tendsto (fun n => ∑ i∈Finset.range n, z n i*(z n (i+1)-z n i)) atTop (𝓝 I))
    (hQ : Tendsto (fun n => ∑ i∈Finset.range n, (z n (i+1)-z n i)^2) atTop (𝓝 Q)) :
    zT^2-z₀^2=2*I+Q := by
  have hid (n : ℕ) : zT^2-z₀^2 =
      2*(∑ i∈Finset.range n, z n i*(z n (i+1)-z n i))+
        ∑ i∈Finset.range n, (z n (i+1)-z n i)^2 := by
    have h := quadratic_partition_identity (z n) n
    rw [hstart,hend] at h
    simpa only [Finset.sum_add_distrib,← Finset.mul_sum,mul_assoc] using! h
  have hlim := (hI.const_mul 2).add hQ
  have hc : Tendsto (fun _ : ℕ => zT^2-z₀^2) atTop (𝓝 (2*I+Q)) :=
    hlim.congr (fun n => (hid n).symm)
  exact tendsto_nhds_unique tendsto_const_nhds hc

/-- Expectation of a genuine integrable martingale remains its initial value. -/
theorem martingale_zero_mean {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    [IsProbabilityMeasure μ] {ℱ : Filtration ℝ ‹MeasurableSpace Ω›}
    {M : ℝ → Ω → ℝ} (hM : Martingale M ℱ μ) (h₀ : ∀ ω, M 0 ω=0)
    {t : ℝ} (ht : 0≤ t) : ∫ ω, M t ω ∂μ = 0 := by
  have h := hM.setIntegral_eq ht (s:=univ) MeasurableSet.univ
  simpa [h₀] using! h.symm

/-- The stopped expectation estimate from an explicit Ito/martingale
decomposition. The martingale mean-zero property is proved from conditional
expectations. The decomposition and its stopped integrability are hypotheses;
construction of a Brownian stochastic integral is not hidden in this statement. -/
theorem stopped_energy_expectation {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    [IsProbabilityMeasure μ] {ℱ : Filtration ℝ ‹MeasurableSpace Ω›}
    {M : ℝ → Ω → ℝ} {W I S D : Ω → ℝ} {t V₀ κ C : ℝ}
    (ht : 0≤ t) (hM : Martingale M ℱ μ) (h₀ : ∀ ω, M 0 ω=0)
    (hW : Integrable W μ) (hI : Integrable I μ) (hS : Integrable S μ)
    (hdecomp : ∀ᵐ ω ∂μ, W ω=V₀+D ω+M t ω)
    (hbound : ∀ᵐ ω ∂μ, D ω≤ -2*κ*I ω+C*S ω) :
    (∫ ω, W ω ∂μ)+2*κ*(∫ ω, I ω ∂μ) ≤ V₀+C*(∫ ω, S ω ∂μ) := by
  have hpt : ∀ᵐ ω ∂μ, W ω+2*κ*I ω≤ V₀+C*S ω+M t ω := by
    filter_upwards [hdecomp,hbound] with ω hd hb
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have he := integral_mono_ae (hW.add (hI.const_mul (2*κ)))
    ((integrable_const V₀ |>.add (hS.const_mul C)).add (hM.integrable t)) hpt
  simp only [Pi.add_apply] at he
  rw [integral_add hW (hI.const_mul (2*κ)),
    integral_add (f:=fun ω => V₀+C*S ω) ((integrable_const V₀).add (hS.const_mul C)) (hM.integrable t),
    integral_add (integrable_const V₀) (hS.const_mul C),
    integral_const_mul,integral_const_mul,martingale_zero_mean hM h₀ ht] at he
  simpa using! he

/-- The crown diffusion is nonzero only when the noise intensity is nonzero.
This repairs the omitted sigma assumption in the prose boundary argument. -/
theorem crown_normal_diffusion_nonzero {σ v h : ℝ}
    (hσ : σ≠0) (hv : 0<v) (hh : 0<h) : (1/2:ℝ)*σ*(v^2/h)≠0 := by
  exact mul_ne_zero (mul_ne_zero (by norm_num) hσ)
    (div_ne_zero (pow_ne_zero 2 hv.ne') hh.ne')

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.StochasticEstimates -/

/- BEGIN SOURCE MODULE: ChainFountain.MeasurablePlant -/

namespace ChainFountain
noncomputable section
open Set Metric Real Filter MeasureTheory
open scoped Topology NNReal

/-- Replace only the disturbance component of the reference/parameter signal.
The existing certificate supplies geometric and reference data; its original
continuous disturbance is irrelevant to the field defined here. -/
def GlobalTrackingData.measurableParameters (c : GlobalTrackingData) (d : ℝ → ℝ) (t : ℝ) :
    ReferenceParameters := ((c.parameters t).1,(c.parameters t).2.1,(c.parameters t).2.2.1,d t)

def GlobalTrackingData.measurableField (c : GlobalTrackingData) (d : ℝ → ℝ)
    (t : ℝ) (x : MechanicalState) : MechanicalState :=
  c.jointField (c.measurableParameters d t,x)

theorem GlobalTrackingData.joint_bounds (c : GlobalTrackingData) :
    ∃ L : ℝ≥0, ∃ N : ℝ, LipschitzOnWith L c.jointField (c.parameterBox ×ˢ c.outerBox) ∧
      ∀ y∈c.parameterBox ×ˢ c.outerBox, ‖c.jointField y‖≤ N := by
  have hP : IsCompact c.parameterBox := isCompact_Icc.prod
    (isCompact_Icc.prod (isCompact_Icc.prod isCompact_Icc))
  have hB : IsCompact c.outerBox := isCompact_Icc.prod (isCompact_Icc.prod isCompact_Icc)
  have hcP : Convex ℝ c.parameterBox := (convex_Icc _ _).prod
    ((convex_Icc _ _).prod ((convex_Icc _ _).prod (convex_Icc _ _)))
  have hcB : Convex ℝ c.outerBox := (convex_Icc _ _).prod
    ((convex_Icc _ _).prod (convex_Icc _ _))
  apply smooth_compact_convex_bounds
    (isOpen_lt continuous_const continuous_snd.fst) c.jointField_smooth
    (hP.prod hB) (hcP.prod hcB)
  intro y hy
  have hp : 0<c.hlo := c.height_positive
  have hl : c.hlo/2≤ y.2.1 := hy.2.1.1
  change 0<y.2.1
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

theorem GlobalTrackingData.measurable_parameters_mem (c : GlobalTrackingData) {d : ℝ → ℝ}
    (hb : ∀ t, |d t|≤ c.dbar) (t : ℝ) : c.measurableParameters d t∈c.parameterBox := by
  have hp := c.parameters_mem t
  exact ⟨hp.1,hp.2.1,hp.2.2.1,abs_le.mp (hb t)⟩

/-- The measured input enters the actual mechanical field. A globally bounded
extension constructs a global integral/a.e. curve. On a positive time interval
the extension is inactive, so this also proves local Caratheodory existence for
the original equations. Global inactivity still needs the a.e. region proof. -/
theorem GlobalTrackingData.exists_measurable_local (c : GlobalTrackingData) {d : ℝ → ℝ}
    (hdm : Measurable d) (hdb : ∀ t, |d t|≤ c.dbar) :
    ∃ x : ℝ → MechanicalState, ∃ C : ℝ≥0, ∃ ε : ℝ, 0<ε ∧
      LipschitzWith C x ∧ x 0=c.x₀ ∧
      (∀ t, x t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (c.project (x s))) ∧
      (∀ᵐ t ∂volume, HasDerivAt x (c.measurableField d t (c.project (x t))) t) ∧
      (∀ t∈Icc 0 ε, x t∈c.outerBox) ∧
      ∀ᵐ t ∂volume, t∈Icc 0 ε → HasDerivAt x (c.measurableField d t (x t)) t := by
  obtain ⟨L,N,hL,hN⟩ := c.joint_bounds
  let F := fun t x => c.measurableField d t (c.project x)
  have hfl : ∀ t, LipschitzWith L (F t) := by
    intro t
    have hh := hL.comp
      ((LipschitzWith.prodMk_left (c.measurableParameters d t)).comp c.project_lipschitz).lipschitzOnWith (s:=univ)
      (fun x _ => ⟨c.measurable_parameters_mem hdb t,c.project_mem x⟩)
    simpa [F,measurableField,lipschitzOnWith_univ] using! hh
  have hpm : Measurable (c.measurableParameters d) :=
    c.parameters_continuous.fst.measurable.prodMk
      (c.parameters_continuous.snd.fst.measurable.prodMk
        (c.parameters_continuous.snd.snd.fst.measurable.prodMk hdm))
  have hfm : ∀ f : ℝ → MechanicalState, Continuous f →
      AEStronglyMeasurable (fun t => F t (f t)) volume := by
    intro f hf
    let y (t : ℝ) : c.parameterBox ×ˢ c.outerBox :=
      ⟨(c.measurableParameters d t,c.project (f t)),
        c.measurable_parameters_mem hdb t,c.project_mem (f t)⟩
    have hy : Measurable y :=
      (hpm.prodMk (c.project_lipschitz.continuous.comp hf).measurable).subtype_mk
    have hc : Continuous (fun z : c.parameterBox ×ˢ c.outerBox => c.jointField z) :=
      hL.continuousOn.domRestrict
    exact (hc.measurable.comp hy).aestronglyMeasurable
  let C : ℝ≥0 := ⟨max N 0,le_max_right _ _⟩
  have hfc : ∀ t x, ‖F t x‖≤ C := fun t x =>
    (hN _ ⟨c.measurable_parameters_mem hdb t,c.project_mem x⟩).trans (le_max_left _ _)
  obtain ⟨x,hxL,hx₀,hxI,hxD⟩ := bounded_measurable_global_ae_exists hfl hfm hfc c.x₀
  have hi : c.x₀∈interior c.outerBox := c.safeBox_interior c.initial_mem
  obtain ⟨ρ,hρ,hρB⟩ := Metric.mem_nhds_iff.mp (mem_interior_iff_mem_nhds.mp hi)
  let ε := ρ/(2*(C+1))
  have hε : 0<ε := by dsimp [ε]; positivity
  have hstay (t : ℝ) (ht : t∈Icc 0 ε) : x t∈c.outerBox := by
    apply hρB
    rw [mem_ball,← hx₀]
    have hl := hxL.dist_le_mul t 0
    rw [Real.dist_eq,sub_zero,abs_of_nonneg ht.1] at hl
    have he : (C:ℝ)*ε<ρ := by
      dsimp [ε]
      rw [← mul_div_assoc]
      apply (div_lt_iff₀ (by positivity : 0<2*((C:ℝ)+1))).mpr
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [NNReal.coe_nonneg C]
    exact hl.trans_lt ((mul_le_mul_of_nonneg_left ht.2 C.property).trans_lt he)
  refine ⟨x,C,ε,hε,hxL,hx₀,hxI,hxD,hstay,?_⟩
  filter_upwards [hxD] with t ht hte
  simpa [F,c.project_eq (x t) (hstay t hte)] using! ht

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.MeasurablePlant -/

/- BEGIN SOURCE MODULE: ChainFountain.MeasurableTracking -/

namespace ChainFountain
noncomputable section
open Set Metric Real Filter MeasureTheory
open scoped Topology NNReal
set_option maxHeartbeats 800000

theorem GlobalTrackingData.reference_lipschitz (c : GlobalTrackingData) (T : ℝ) :
    ∃ L₁ L₂ : ℝ≥0, LipschitzOnWith L₁ c.r (Icc 0 T) ∧
      LipschitzOnWith L₂ c.r₁ (Icc 0 T) := by
  have hR₁ : 0≤ c.R₁ := (abs_nonneg _).trans (c.rate_bound 0 le_rfl)
  have hR₂ : 0≤ c.R₂ := (abs_nonneg _).trans (c.accel_bound 0 le_rfl)
  refine ⟨⟨c.R₁,hR₁⟩,⟨c.R₂,hR₂⟩,?_,?_⟩
  · rw [lipschitzOnWith_iff_norm_sub_le]
    intro s hs t ht
    refine (convex_Icc (0:ℝ) T).norm_image_sub_le_of_norm_deriv_le
      (fun u (hu : u ∈ Icc 0 T) => (c.dr u hu.1).differentiableAt) ?_ ht hs
    intro u hu
    rw [(c.dr u hu.1).deriv, Real.norm_eq_abs]
    exact c.rate_bound u hu.1
  · rw [lipschitzOnWith_iff_norm_sub_le]
    intro s hs t ht
    refine (convex_Icc (0:ℝ) T).norm_image_sub_le_of_norm_deriv_le
      (fun u (hu : u ∈ Icc 0 T) => (c.dr₁ u hu.1).differentiableAt) ?_ ht hs
    intro u hu
    rw [(c.dr₁ u hu.1).deriv, Real.norm_eq_abs]
    exact c.accel_bound u hu.1

theorem GlobalTrackingData.errors_lipschitz (c : GlobalTrackingData)
    {x : ℝ → MechanicalState} {K : ℝ≥0} (hx : LipschitzWith K x) (T : ℝ) :
    ∃ Le Lz : ℝ≥0,
      LipschitzOnWith Le (heightError (fun t => (x t).1) c.r) (Icc 0 T) ∧
      LipschitzOnWith Lz (velocityError c.k₁ (fun t => (x t).1)
        (fun t => (x t).2.1) (fun t => (x t).2.2) c.r c.r₁) (Icc 0 T) := by
  obtain ⟨L₁,L₂,hr,hr₁⟩ := c.reference_lipschitz T
  have hp := hx.lipschitzOnWith.prodMk (hr.prodMk hr₁)
  have hse : ContDiff ℝ 1 (fun p : MechanicalState × (ℝ×ℝ) => p.1.1-p.2.1) := by fun_prop
  have hsz : ContDiff ℝ 1 (fun p : MechanicalState × (ℝ×ℝ) =>
      p.1.2.1-p.1.2.2-2*p.2.2+2*c.k₁*(p.1.1-p.2.1)) := by fun_prop
  obtain ⟨Le,he⟩ := smooth_comp_lipschitzOn hse hp
  obtain ⟨Lz,hz⟩ := smooth_comp_lipschitzOn hsz hp
  exact ⟨Le,Lz,he,hz⟩

theorem GlobalTrackingData.measurable_prefix_energy (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdb : ∀ t, |d t|≤ c.dbar)
    {x : ℝ → MechanicalState} {K : ℝ≥0} {T : ℝ} (hxL : LipschitzWith K x)
    (hx₀ : x 0=c.x₀) (hbox : ∀ t∈Icc 0 T, x t∈c.outerBox)
    (hxD : ∀ᵐ t ∂volume, HasDerivAt x (c.measurableField d t (c.project (x t))) t) :
    ∀ t∈Icc 0 T, c.stateEnergy t (x t)≤
      exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+c.dbar^2/(16*c.κ*c.κd)*(1-exp (-2*c.κ*t)) ∧
      c.stateEnergy t (x t)≤ c.cap := by
  let h := fun t => (x t).1
  let v := fun t => (x t).2.1
  let w := fun t => (x t).2.2
  obtain ⟨Le,Lz,hel,hzl⟩ := c.errors_lipschitz hxL T
  have heq : ∀ᵐ t ∂volume, t∈Ioo 0 T →
      HasDerivAt (heightError h c.r) (errorRate c.k₁ (heightError h c.r t)
        (velocityError c.k₁ h v w c.r c.r₁ t)) t ∧
      HasDerivAt (velocityError c.k₁ h v w c.r c.r₁)
        (zRate c.k₀ c.k₂ c.κd ((v t)^2/h t) (d t) (heightError h c.r t)
          (velocityError c.k₁ h v w c.r c.r₁ t)) t := by
    filter_upwards [hxD] with t hdt ht
    have hB := hbox t (Ioo_subset_Icc_self ht)
    rw [c.project_eq (x t) hB] at hdt
    have hp : 0<(x t).1 := by have hl := hB.1.1; have := c.height_positive; change 0<c.hlo at this; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
    have hHp : 0<c.H+(x t).1 := add_pos c.H_pos hp
    have dh : HasDerivAt h (heightRate (v t) (w t)) t := by
      simpa [h,v,w,measurableField,jointField] using! hasFDerivAt_fst.comp_hasDerivAt t hdt
    have dv : HasDerivAt v (rise c.g (c.α+d t) (h t) (v t) (w t)
        (requestedInput c.H c.g c.α c.β c.k₀ c.k₁ c.k₂ c.κd h v w c.r c.r₁ c.r₂ t)) t := by
      simpa [h,v,w,measurableField,measurableParameters,jointField,parameters,max_eq_right ht.1.le,
        requestedInput,heightError,velocityError] using!
        hasFDerivAt_fst.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t hdt)
    have dw : HasDerivAt w (fall c.H c.g c.β (h t) (v t) (w t)) t := by
      simpa [h,v,w,measurableField,jointField] using!
        hasFDerivAt_snd.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t hdt)
    exact closed_loop_error_equations hp.ne' hHp.ne' dh dv dw (c.dr t ht.1.le) (c.dr₁ t ht.1.le)
  have he := robust_error_estimate_ae c.k₀_pos.le c.κ_pos c.κ_le_k₁ c.κ_le_k₂ hκd
    hel hzl (heq.mono (fun t ht hmem => (ht hmem).1))
    (heq.mono (fun t ht hmem => (ht hmem).2)) (Filter.Eventually.of_forall (fun t _ => hdb t))
  intro t ht
  have he' : c.stateEnergy t (x t)≤
      exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+c.dbar^2/(16*c.κ*c.κd)*(1-exp (-2*c.κ*t)) := by
    simpa [stateEnergy,heightError,velocityError,h,v,w,hx₀] using! he t ht
  refine ⟨he',he'.trans ?_⟩
  have hcap : (c.dbar^2/(8*c.κd))/(2*c.κ)≤ c.cap := by
    convert! c.disturbance_cap using 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  convert! envelope_below_cap c.κ_pos ht.1 c.initial_energy hcap using 1
  unfold envelope stateEnergy
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- The falling speed is classical even under measurable pickup disturbances,
because its a.e. right hand side is a continuous function of the state. -/
theorem GlobalTrackingData.measurable_fall_classical (c : GlobalTrackingData)
    {d : ℝ → ℝ} {x : ℝ → MechanicalState} {K : ℝ≥0} (hxL : LipschitzWith K x)
    (hxD : ∀ᵐ t ∂volume, HasDerivAt x (c.measurableField d t (c.project (x t))) t) :
    ∀ t, HasDerivAt (fun s => (x s).2.2)
      (fall c.H c.g c.β (c.project (x t)).1 (c.project (x t)).2.1 (c.project (x t)).2.2) t := by
  have hwL : LipschitzWith K (fun t => (x t).2.2) := by
    simpa using! LipschitzWith.prod_snd.comp (LipschitzWith.prod_snd.comp hxL)
  have hpc : Continuous (fun t => c.project (x t)) := c.project_lipschitz.continuous.comp hxL.continuous
  have hden (t : ℝ) : c.H+(c.project (x t)).1≠0 := by
    have hl := (c.project_mem (x t)).1.1
    have hp : 0<c.hlo := c.height_positive
    exact ne_of_gt (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [c.H_pos])
  have hcont : Continuous (fun t =>
      fall c.H c.g c.β (c.project (x t)).1 (c.project (x t)).2.1 (c.project (x t)).2.2) := by
    unfold fall crownSq
    exact continuous_const.add
      (((((hpc.snd.fst.add hpc.snd.snd).div_const 2).pow 2).neg.add
        (continuous_const.mul (hpc.snd.snd.pow 2))).div
          (continuous_const.add hpc.fst) hden)
  apply lipschitz_ae_continuous_derivative hwL hcont
  filter_upwards [hxD] with t ht
  simpa [measurableField,jointField] using!
    hasFDerivAt_snd.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t ht)

theorem GlobalTrackingData.measurable_prefix_bound (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdb : ∀ t, |d t|≤ c.dbar)
    {x : ℝ → MechanicalState} {K : ℝ≥0} {T : ℝ} (hxL : LipschitzWith K x)
    (hT : 0≤ T) (hx₀ : x 0=c.x₀) (hbox : ∀ t∈Icc 0 T, x t∈c.outerBox)
    (hxD : ∀ᵐ t ∂volume, HasDerivAt x (c.measurableField d t (c.project (x t))) t) :
    x T∈c.safeBox := by
  have henergy := c.measurable_prefix_energy hκd hdb hxL hx₀ hbox hxD
  have he (t : ℝ) (ht : t∈Icc 0 T) := trajectory_enclosure
    (h:=fun s => (x s).1) (v:=fun s => (x s).2.1) (w:=fun s => (x s).2.2)
    (r:=c.r) (r₁:=c.r₁) (k₁:=c.k₁) (cap:=c.cap)
    (rlo:=c.rlo) (rhi:=c.rhi) (R₁:=c.R₁)
    c.k₀_pos (henergy t ht).2 (c.ref_bounds t ht.1) (c.rate_bound t ht.1)
  have hhc : ContinuousOn (fun t => (x t).1) (Icc 0 T) := hxL.continuous.fst.continuousOn
  have hwc : ContinuousOn (fun t => (x t).2.2) (Icc 0 T) := hxL.continuous.snd.snd.continuousOn
  have hvc : ContinuousOn (fun t => (x t).2.1) (Icc 0 T) := hxL.continuous.snd.fst.continuousOn
  have hqc : ContinuousOn (fun t => heightRate (x t).2.1 (x t).2.2) (Icc 0 T) :=
    (hvc.sub hwc).div_const 2
  have hden (t : ℝ) (ht : t∈Icc 0 T) : c.H+(x t).1≠0 := by
    have hl := (hbox t ht).1.1
    have hp : 0<c.hlo := c.height_positive
    exact ne_of_gt (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [c.H_pos])
  have hK (b : ℝ) : ContinuousOn
      (fun t => -((1-c.β)*((x t).2.2+b)+2*heightRate (x t).2.1 (x t).2.2)/(c.H+(x t).1))
      (Icc 0 T) :=
    ((continuousOn_const.mul (hwc.add continuousOn_const)).add
      (continuousOn_const.mul hqc)).neg.div (continuousOn_const.add hhc) hden
  have hwd := c.measurable_fall_classical hxL hxD
  have hwdActual (t : ℝ) (ht : t∈Icc 0 T) :
      HasDerivAt (fun s => (x s).2.2)
        (fall c.H c.g c.β (x t).1 (x t).2.1 (x t).2.2) t := by
    simpa only [c.project_eq (x t) (hbox t ht)] using! hwd t
  have hi (t : ℝ) (ht : t∈Ico 0 T) :
      HasDerivWithinAt (fun s => (x s).2.2)
        (internal c.H c.g c.β (x t).1 (x t).2.2
          (heightRate (x t).2.1 (x t).2.2)) (Ici t) t := by
    exact (mechanical_internal_equation
      (h:=fun s => (x s).1) (v:=fun s => (x s).2.1) (w:=fun s => (x s).2.2)
      (H:=c.H) (g:=c.g) (β:=c.β) (t:=t)
      (hden t (Ico_subset_Icc_self ht)) (hwdActual t (Ico_subset_Icc_self ht))).hasDerivWithinAt
  have hwinv := physical_region_invariant
    (h:=fun t => (x t).1) (w:=fun t => (x t).2.2)
    (q:=fun t => heightRate (x t).2.1 (x t).2.2)
    (H:=c.H) (g:=c.g) (β:=c.β) (T:=T) (hlo:=c.hlo) (hhi:=c.hhi)
    (Q:=c.Q) (wlo:=c.wlo) (whi:=c.whi) (vmin:=c.vmin)
    c.H_pos c.g_nonneg c.height_positive hwc
    hi
    (hK c.wlo) (hK c.whi) (fun t ht => ⟨(he t ht).1,(he t ht).2.1⟩)
    (fun t ht => (he t ht).2.2) c.forward c.speed_order c.crown
    c.lower_face_bound c.upper_face_bound (by simpa [hx₀] using! c.initial_speed) T ⟨hT,le_rfl⟩
  exact c.box_of_energy_speed T hT (x T) (henergy T ⟨hT,le_rfl⟩).2 ⟨hwinv.2.1,hwinv.2.2.1⟩

/-- Global physical existence and tracking for bounded measurable disturbances.
The trajectory is constructed from data, the projection is proved inactive for
all nonnegative times, and the original equations hold almost everywhere. -/
theorem GlobalTrackingData.exists_global_measurable_tracking (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : Measurable d) (hdb : ∀ t, |d t|≤ c.dbar) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      ∀ t≥0, c.stateEnergy t (x t)≤ c.cap ∧
        c.stateEnergy t (x t)≤ exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-exp (-2*c.κ*t)) := by
  obtain ⟨x,K,ε,hε,hxL,hx₀,hxI,hxD,hlocal,hlocalD⟩ := c.exists_measurable_local hdm hdb
  have hstay := no_exit_of_prefix_bound hxL.continuous
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    (hx₀ ▸ c.safeBox_interior c.initial_mem) (fun T hT hbox =>
      c.measurable_prefix_bound hκd hdb hxL hT hx₀ hbox hxD)
  refine ⟨x,K,hxL,hx₀,?_,hstay,?_⟩
  · filter_upwards [hxD] with t ht ht0
    simpa [c.project_eq (x t) (interior_subset (c.safeBox_interior (hstay t ht0)))] using! ht
  · intro t ht
    have he := c.measurable_prefix_energy hκd hdb hxL hx₀
      (fun s (hs : s∈Icc 0 t) => interior_subset (c.safeBox_interior (hstay s hs.1))) hxD t ⟨ht,le_rfl⟩
    exact ⟨he.2,he.1⟩

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.MeasurableTracking -/

/- BEGIN SOURCE MODULE: ChainFountain.MeasurableForces -/

namespace ChainFountain
noncomputable section
open Set Real MeasureTheory
open scoped NNReal

theorem GlobalTrackingData.force_of_energy_box_disturbance (c : GlobalTrackingData)
    (ha : c.α ≤ 1) (hb : 0 ≤ c.β) {uLo uHi t δ : ℝ} {x : MechanicalState}
    (hc : c.forceCertificate uLo uHi) (ht : 0 ≤ t) (hbox : x ∈ c.safeBox)
    (hE : c.stateEnergy t x ≤ c.cap) (hδ : |δ|≤ c.dbar) :
    uLo ≤ c.command t x ∧ c.command t x ≤ uHi ∧
      0 ≤ pickup (c.α+δ) x.2.1 (c.command t x) := by
  have hR : 0 ≤ c.R₁ := (abs_nonneg _).trans (c.rate_bound 0 le_rfl)
  have hQ : 0 ≤ c.Q := by dsimp [Q]; positivity
  have hf : 2*c.Q < c.wlo := c.forward
  have hvlo : 0 ≤ c.vlo := by dsimp [vlo]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hwlo : 0 ≤ c.wlo := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hslo : 0 ≤ c.wlo-c.Q := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hS : c.wlo-c.Q ≤ (x.2.1+x.2.2)/2 ∧ (x.2.1+x.2.2)/2 ≤ c.whi+c.Q := by
    have hv := hbox.2.1
    have hw := hbox.2.2
    change c.wlo-2*c.Q ≤ x.2.1 ∧ x.2.1 ≤ c.whi+2*c.Q at hv
    constructor <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hv.1,hv.2,hw.1,hw.2]
  have he := error_enclosure (k₁:=c.k₁) c.k₀_pos hE
  have hq : |heightRate x.2.1 x.2.2-c.r₁ t| ≤ sqrt (2*c.cap)*sqrt (1+c.k₁^2/c.k₀) := by
    convert! he.2.2 using 1 <;> congr 1 <;> unfold heightRate <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hA := acceleration_bound c.k₀_pos.le (c.κ_pos.le.trans c.κ_le_k₁)
    (c.κ_pos.le.trans c.κ_le_k₂) he.1 hq (c.accel_bound t ht)
  exact robust_force_feasibility c.H_pos c.g_nonneg ha hb c.height_positive
    hbox.1 (square_interval hvlo hbox.2.1) (square_interval hwlo hbox.2.2).2
    (square_interval hslo hS) hA c.κd_nonneg he.2.1 hδ
    hc.1 hc.2.1 hc.2.2

/-- The global actuator and physical-domain certificate now allows a bounded
measurable disturbance. A solution is constructed, and no trajectory is an input. -/
theorem GlobalTrackingData.exists_global_measurable_admissible (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : Measurable d) (hdb : ∀ t, |d t|≤ c.dbar)
    (ha : c.α≤1) (hb : 0≤ c.β) (uLo uHi : ℝ) (hc : c.forceCertificate uLo uHi) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      ∀ t≥0, c.stateEnergy t (x t)≤ c.cap ∧ 0<(x t).1 ∧ 0<(x t).2.1 ∧
        c.vmin≤((x t).2.1+(x t).2.2)/2 ∧
        uLo≤ c.command t (x t) ∧ c.command t (x t)≤ uHi ∧
        0≤ pickup (c.α+d t) (x t).2.1 (c.command t (x t)) := by
  obtain ⟨x,K,hxL,hx₀,hxD,hbox,hE⟩ := c.exists_global_measurable_tracking hκd hdm hdb
  refine ⟨x,K,hxL,hx₀,hxD,hbox,fun t ht => ?_⟩
  have hB := hbox t ht
  have hEn := (hE t ht).1
  have hforce := c.force_of_energy_box_disturbance ha hb hc ht hB hEn (hdb t)
  have hh : 0<(x t).1 := lt_of_lt_of_le c.height_positive hB.1.1
  have hv : 0<(x t).2.1 := by
    have hvl := hB.2.1.1
    change c.wlo-2*c.Q≤(x t).2.1 at hvl
    have hf : 2*c.Q<c.wlo := c.forward
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hs : c.vmin≤((x t).2.1+(x t).2.2)/2 := by
    have hvl := hB.2.1.1
    change c.wlo-2*c.Q≤(x t).2.1 at hvl
    have hwl := hB.2.2.1
    have hcr : c.vmin≤ c.wlo-c.Q := c.crown
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  exact ⟨hEn,hh,hv,hs,hforce⟩

/-- The physical certificate also admits Lebesgue-a.e. measurable inputs. A
bounded Borel representative constructs the solution; the original disturbance
is recovered in the a.e. ODE, and its pointwise bound certifies pickup tension. -/
theorem GlobalTrackingData.exists_global_aemeasurable_admissible (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : AEMeasurable d volume) (hdb : ∀ t, |d t|≤ c.dbar)
    (ha : c.α≤1) (hb : 0≤ c.β) (uLo uHi : ℝ) (hc : c.forceCertificate uLo uHi) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      ∀ t≥0, c.stateEnergy t (x t)≤ c.cap ∧ 0<(x t).1 ∧ 0<(x t).2.1 ∧
        c.vmin≤((x t).2.1+(x t).2.2)/2 ∧
        uLo≤ c.command t (x t) ∧ c.command t (x t)≤ uHi ∧
        0≤ pickup (c.α+d t) (x t).2.1 (c.command t (x t)) := by
  have hb0 : 0≤ c.dbar := (abs_nonneg (d 0)).trans (hdb 0)
  have horder : -c.dbar≤ c.dbar := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  let b : ℝ → ℝ := fun t => max (-c.dbar) (min c.dbar (hdm.mk d t))
  have hbm : Measurable b := measurable_const.max (measurable_const.min hdm.measurable_mk)
  have hbb (t : ℝ) : |b t|≤ c.dbar := by
    apply abs_le.mpr
    exact ⟨le_max_left _ _,max_le horder (min_le_left _ _)⟩
  have heq : d =ᵐ[volume] b := by
    filter_upwards [hdm.ae_eq_mk] with t ht
    have hb := abs_le.mp (hdb t)
    simp only [b,← ht,min_eq_right hb.2,max_eq_right hb.1]
  obtain ⟨x,K,hxL,hx₀,hxD,hbox,hrest⟩ :=
    c.exists_global_measurable_admissible hκd hbm hbb ha hb uLo uHi hc
  refine ⟨x,K,hxL,hx₀,?_,hbox,fun t ht => ?_⟩
  · filter_upwards [hxD,heq] with t hdt he ht
    simpa only [measurableField,measurableParameters,← he] using! hdt ht
  · have hr := hrest t ht
    have hf := c.force_of_energy_box_disturbance ha hb hc ht (hbox t ht) hr.1 (hdb t)
    exact ⟨hr.1,hr.2.1,hr.2.2.1,hr.2.2.2.1,hf⟩

/-- The full robust envelope for a.e.-measurable pointwise-bounded disturbances. -/
theorem GlobalTrackingData.exists_global_aemeasurable_tracking (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : AEMeasurable d volume) (hdb : ∀ t, |d t|≤ c.dbar)
    :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      ∀ t≥0, c.stateEnergy t (x t)≤ c.cap ∧
        c.stateEnergy t (x t)≤ exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-exp (-2*c.κ*t)) := by
  have hb0 : 0≤ c.dbar := (abs_nonneg (d 0)).trans (hdb 0)
  have horder : -c.dbar≤ c.dbar := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  let b : ℝ → ℝ := fun t => max (-c.dbar) (min c.dbar (hdm.mk d t))
  have hbm : Measurable b := measurable_const.max (measurable_const.min hdm.measurable_mk)
  have hbb (t : ℝ) : |b t|≤ c.dbar := by
    apply abs_le.mpr
    exact ⟨le_max_left _ _,max_le horder (min_le_left _ _)⟩
  have heq : d =ᵐ[volume] b := by
    filter_upwards [hdm.ae_eq_mk] with t ht
    have hb := abs_le.mp (hdb t)
    simp only [b,← ht,min_eq_right hb.2,max_eq_right hb.1]
  obtain ⟨x,K,hxL,hx₀,hxD,hbox,hrest⟩ :=
    c.exists_global_measurable_tracking hκd hbm hbb
  refine ⟨x,K,hxL,hx₀,?_,hbox,hrest⟩
  filter_upwards [hxD,heq] with t hdt he ht
  simpa only [measurableField,measurableParameters,← he] using! hdt ht

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.MeasurableForces -/

/- BEGIN SOURCE MODULE: ChainFountain.ZeroDynamics -/

namespace ChainFountain
noncomputable section
open Set Real

/-- Explicit positive-branch solution of `w' = a (s²-w²)`. The formula is
defined on all real times; the theorem only asserts regularity for `t ≥ 0`. -/
def zeroFlow (a s w₀ t : ℝ) : ℝ :=
  s * (1 + ((w₀-s)/(w₀+s))*exp (-2*a*s*t)) /
    (1 - ((w₀-s)/(w₀+s))*exp (-2*a*s*t))

theorem zero_ratio_abs_lt_one {s w₀ : ℝ} (hs : 0<s) (hw : 0<w₀) :
    |(w₀-s)/(w₀+s)|<1 := by
  rw [abs_div,abs_of_pos (add_pos hw hs),div_lt_one (add_pos hw hs)]
  exact abs_lt.mpr ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith,by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith⟩

theorem zero_flow_den_pos {a s w₀ t : ℝ}
    (ha : 0<a) (hs : 0<s) (hw : 0<w₀) (ht : 0≤ t) :
    0<1-((w₀-s)/(w₀+s))*exp (-2*a*s*t) := by
  have he : exp (-2*a*s*t)≤1 := exp_le_one_iff.mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_nonneg (mul_nonneg ha.le hs.le) ht])
  have hq := zero_ratio_abs_lt_one hs hw
  have hprod : |((w₀-s)/(w₀+s))*exp (-2*a*s*t)|<1 := by
    rw [abs_mul,abs_of_pos (exp_pos _)]
    exact (mul_le_mul_of_nonneg_left he (abs_nonneg _)).trans_lt (by simpa using! hq)
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(abs_lt.mp hprod).2]

theorem zero_flow_pos {a s w₀ t : ℝ}
    (ha : 0<a) (hs : 0<s) (hw : 0<w₀) (ht : 0≤ t) :
    0<zeroFlow a s w₀ t := by
  have he : exp (-2*a*s*t)≤1 := exp_le_one_iff.mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_nonneg (mul_nonneg ha.le hs.le) ht])
  have hq := zero_ratio_abs_lt_one hs hw
  have hp : |((w₀-s)/(w₀+s))*exp (-2*a*s*t)|<1 := by
    rw [abs_mul,abs_of_pos (exp_pos _)]
    exact (mul_le_mul_of_nonneg_left he (abs_nonneg _)).trans_lt (by simpa using! hq)
  exact div_pos (mul_pos hs (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(abs_lt.mp hp).1]))
    (zero_flow_den_pos ha hs hw ht)

theorem zero_flow_initial {a s w₀ : ℝ} (hs : 0<s) (hw : 0<w₀) :
    zeroFlow a s w₀ 0=w₀ := by
  have hd : w₀+s≠0 := (add_pos hw hs).ne'
  have hq : 1-(w₀-s)/(w₀+s)≠0 := by
    have hh := (abs_lt.mp (zero_ratio_abs_lt_one hs hw)).2
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  dsimp [zeroFlow]
  simp only [mul_zero,exp_zero,mul_one]
  field_simp [hs.ne']
  <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem zero_flow_derivative {a s w₀ t : ℝ}
    (ha : 0<a) (hs : 0<s) (hw : 0<w₀) (ht : 0≤ t) :
    HasDerivAt (zeroFlow a s w₀) (a*(s^2-(zeroFlow a s w₀ t)^2)) t := by
  have hd := (zero_flow_den_pos ha hs hw ht).ne'
  have de := (((hasDerivAt_id t).const_mul (-2*a*s)).exp).const_mul ((w₀-s)/(w₀+s))
  have dh := ((de.const_add 1).const_mul s).div (de.const_sub 1) hd
  convert! dh using 1
  dsimp only [zeroFlow, id_eq]
  generalize (w₀-s)/(w₀+s) = q at hd ⊢
  generalize exp (-2*a*s*t) = E at hd ⊢
  field_simp [hd]
  <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- Global positive solution and the paper's exact exponential estimate, for
every positive initial speed. Existence is supplied by `zeroFlow`, not assumed. -/
theorem exists_global_zero_dynamics {H g β r s w₀ : ℝ}
    (hD : 0<H+r) (hβ : β<1) (hs : 0<s) (hw : 0<w₀)
    (heq : (1-β)*s^2=g*(H+r)) :
    ∃ w : ℝ → ℝ, w 0=w₀ ∧ ∀ t≥0,
      0<w t ∧ HasDerivAt w (internal H g β r (w t) 0) t ∧
      |w t-s|≤|w₀-s| *exp (-((1-β)*s/(H+r))*t) := by
  let a := (1-β)/(H+r)
  have ha : 0<a := div_pos (sub_pos.mpr hβ) hD
  let w := zeroFlow a s w₀
  have hd (t : ℝ) (ht : 0≤ t) := zero_flow_derivative ha hs hw ht
  have hp (t : ℝ) (ht : 0≤ t) : 0<w t := zero_flow_pos ha hs hw ht
  have hinit : w 0=w₀ := zero_flow_initial hs hw
  refine ⟨w,hinit,?_⟩
  intro t ht
  have hc : ContinuousOn w (Icc 0 t) :=
    fun u hu => (hd u hu.1).continuousAt.continuousWithinAt
  refine ⟨hp t ht,?_,?_⟩
  · convert! hd t ht using 1
    dsimp [internal,a]
    field_simp
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [heq]
  · have hdec := scalar_exponential_decay (y:=fun u => w u-s)
      (a:=fun u => a*(s+w u)) (f:=fun _ => 0) (T:=t)
      (ρ:=a*s) (δ:=0) (M:=|w₀-s|)
      (continuousOn_const.mul (continuousOn_const.add hc))
      (hc.sub continuousOn_const)
      (fun u hu => by
        convert! ((hd u hu.1).sub_const s).hasDerivWithinAt using 1 <;> dsimp [w] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring)
      (abs_nonneg _) (fun u hu => by
        change a*s+0≤ a*(s+w u)
        (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_pos ha (hp u hu.1)])
      (by intro u hu; simp) (by simpa only [hinit] using! le_refl |w₀-s|) t ⟨ht,le_rfl⟩
    convert! hdec using 1 <;> dsimp [a] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring_nf

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.ZeroDynamics -/

/- BEGIN SOURCE MODULE: ChainFountain.TransferCompletion -/

namespace ChainFountain
noncomputable section
open Polynomial

def transferNumerator (α ω h : ℝ) : ℝ[X] := C (-(1/(2*h))) * (X+C (2*α*ω))
def transferDenominator (α ρ ω : ℝ) : ℝ[X] :=
  X^3+C (coeff₂ ρ ω)*X^2+C (coeff₁ α ρ ω)*X+C (coeff₀ α ρ ω)

theorem transfer_denominator_eval (α ρ ω p : ℝ) :
    (transferDenominator α ρ ω).eval p=cubic α ρ ω p := by
  simp [transferDenominator,cubic]

theorem transfer_numerator_eval (α ω h p : ℝ) :
    (transferNumerator α ω h).eval p= -(p+2*α*ω)/(2*h) := by
  simp [transferNumerator]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem transfer_polynomial_degrees {α ρ ω h : ℝ} (hh : h≠0) :
    (transferNumerator α ω h).natDegree=1 ∧
    (transferDenominator α ρ ω).natDegree=3 := by
  constructor
  · unfold transferNumerator
    rw [natDegree_C_mul (by exact neg_ne_zero.mpr (one_div_ne_zero (mul_ne_zero (by norm_num) hh))),
      natDegree_X_add_C]
  · unfold transferDenominator
    compute_degree!

theorem transfer_relative_degree_two {α ρ ω h : ℝ} (hh : h≠0) :
    (transferDenominator α ρ ω).natDegree-(transferNumerator α ω h).natDegree=2 := by
  rw [(transfer_polynomial_degrees (α:=α) (ρ:=ρ) (ω:=ω) hh).1,(transfer_polynomial_degrees (α:=α) (ρ:=ρ) (ω:=ω) hh).2]

theorem transfer_static_gain_negative {α ρ ω h : ℝ}
    (ha : 0<α) (hr : ρ<1) (hw : 0<ω) (hh : 0<h) :
    (transferNumerator α ω h).eval 0/(transferDenominator α ρ ω).eval 0 < 0 := by
  rw [transfer_numerator_eval,transfer_denominator_eval]
  simp only [cubic,zero_pow (by decide : 3≠0),zero_pow (by decide : 2≠0),
    mul_zero,zero_add,add_zero]
  have hrp : 0<1-ρ := sub_pos.mpr hr
  have hc : 0<coeff₀ α ρ ω := by unfold coeff₀; positivity
  exact div_neg_of_neg_of_pos (div_neg_of_neg_of_pos (neg_neg_of_pos (by positivity)) (by positivity)) hc

theorem transfer_physical_zero {α g h s : ℝ} (hh : h≠0) (hs : s≠0)
    (heq : α*s^2=g*h) : -2*α*(s/h) = -2*g/s := by
  field_simp
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [heq]

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.TransferCompletion -/

/- BEGIN SOURCE MODULE: ChainFountain.AEIntegralEstimate -/

namespace ChainFountain
noncomputable section
open Set Real Filter MeasureTheory intervalIntegral
open scoped Topology NNReal

/-- A Lipschitz restriction has an integrable derivative and satisfies FTC.
The proof uses the constant extension outside the interval. -/
theorem lipschitzOn_integral_deriv {f : ℝ → ℝ} {L : ℝ≥0} {a b : ℝ}
    (hab : a≤ b) (hf : LipschitzOnWith L f (Icc a b)) :
    IntervalIntegrable (deriv f) volume a b ∧
      (∫ t in a..b, deriv f t)=f b-f a := by
  by_cases heq : a=b
  · subst b
    simp
  have hab' : a<b := lt_of_le_of_ne hab heq
  let g : ℝ → ℝ := fun t => f (projIcc a b hab t)
  have hgl : LipschitzWith L g := by
    simpa only [mul_one,Function.comp_def,Set.domRestrict_apply] using!
      hf.to_restrict.comp (LipschitzWith.projIcc hab)
  have he (t : ℝ) (ht : t∈Ioo a b) : g =ᶠ[𝓝 t] f := by
    filter_upwards [Ioo_mem_nhds ht.1 ht.2] with s hs
    simp [g,projIcc_of_mem hab (Ioo_subset_Icc_self hs)]
  have hne : ∀ᵐ t ∂volume, t≠b := by
    simp [ae_iff,measure_singleton]
  have hde : deriv f =ᵐ[volume.restrict (Ioc a b)] deriv g := by
    filter_upwards [ae_restrict_of_ae hne,ae_restrict_mem measurableSet_Ioc] with t htb ht
    exact ((he t ⟨ht.1,lt_of_le_of_ne ht.2 htb⟩).deriv_eq).symm
  have hgi : IntegrableOn (deriv g) (Ioc a b) := by
    apply (integrable_const (L:ℝ)).mono' (aestronglyMeasurable_deriv _ _)
    exact Eventually.of_forall (fun _ => norm_deriv_le_of_lipschitz hgl)
  have hi : IntervalIntegrable (deriv f) volume a b :=
    (intervalIntegrable_iff_integrableOn_Ioc_of_le hab).mpr (hgi.congr hde.symm)
  refine ⟨hi,?_⟩
  have hInt : (∫ t in a..b, deriv f t)=(∫ t in a..b, deriv g t) := by
    rw [integral_of_le hab,integral_of_le hab]
    exact integral_congr_ae hde
  rw [hInt,lipschitz_integral_deriv hgl hab]
  simp [g]

/-- Dissipation integrated for a.e. derivatives; the FTC and derivative
integrability are proved from Lipschitz regularity, not assumed. -/
theorem weighted_integral_estimate_ae {V d : ℝ → ℝ} {L : ℝ≥0} {T κ κd : ℝ}
    (hT : 0≤ T) (hκ : 0<κ) (hκd : 0<κd)
    (hV : LipschitzOnWith L V (Icc 0 T))
    (hd : IntervalIntegrable (fun t => d t^2) volume 0 T)
    (hb : ∀ᵐ t ∂volume, t∈Ioo 0 T → deriv V t≤ -2*κ*V t+d t^2/(8*κd))
    (hVT : 0≤ V T) :
    (∫ t in (0:ℝ)..T, 2*V t)≤ V 0/κ+(1/(8*κ*κd))*(∫ t in (0:ℝ)..T, d t^2) := by
  obtain ⟨hVp,hFTC⟩ := lipschitzOn_integral_deriv hT hV
  have hVi : IntervalIntegrable V volume 0 T := hV.continuousOn.intervalIntegrable_of_Icc hT
  have hne : ∀ᵐ t ∂volume, t≠T := by
    simp [ae_iff,measure_singleton]
  have hi : (∫ t in (0:ℝ)..T, deriv V t)≤
      ∫ t in (0:ℝ)..T, -2*κ*V t+d t^2/(8*κd) := by
    rw [integral_of_le hT,integral_of_le hT]
    apply integral_mono_ae hVp.1 (((hVi.const_mul (-2*κ)).add (hd.div_const (8*κd))).1)
    filter_upwards [ae_restrict_of_ae hb,ae_restrict_of_ae hne,
      ae_restrict_mem measurableSet_Ioc] with t ht hn hm
    exact ht ⟨hm.1,lt_of_le_of_ne hm.2 hn⟩
  rw [hFTC,intervalIntegral.integral_add (hVi.const_mul (-2*κ)) (hd.div_const (8*κd)),
    intervalIntegral.integral_const_mul,intervalIntegral.integral_div] at hi
  rw [intervalIntegral.integral_const_mul]
  apply (mul_le_mul_iff_right₀ hκ).mp
  have hc₁ : κ*(V 0/κ)=V 0 := by field_simp
  have hc₂ : κ*(1/(8*κ*κd))=1/(8*κd) := by field_simp
  have hc₃ : κ*(1/(8*κ*κd)*(∫ t in (0:ℝ)..T, d t^2))=
      (∫ t in (0:ℝ)..T, d t^2)/(8*κd) := by
    rw [←mul_assoc,hc₂]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [mul_add,hc₁,hc₃]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hi]

theorem robust_error_integral_ae {e z G d : ℝ → ℝ} {T k₀ k₁ k₂ κ κd : ℝ}
    {Le Lz : ℝ≥0} (hT : 0≤ T) (hk₀ : 0≤ k₀) (hκ : 0<κ)
    (hk₁ : κ≤ k₁) (hk₂ : κ≤ k₂) (hκd : 0<κd)
    (hel : LipschitzOnWith Le e (Icc 0 T)) (hzl : LipschitzOnWith Lz z (Icc 0 T))
    (he : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt e (errorRate k₁ (e t) (z t)) t)
    (hz : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt z (zRate k₀ k₂ κd (G t) (d t) (e t) (z t)) t)
    (hd : IntervalIntegrable (fun t => d t^2) volume 0 T) :
    (∫ t in (0:ℝ)..T, 2*errorEnergy k₀ (e t) (z t))≤
      errorEnergy k₀ (e 0) (z 0)/κ+(1/(8*κ*κd))*(∫ t in (0:ℝ)..T, d t^2) := by
  have hsm : ContDiff ℝ 1 (fun p : ℝ×ℝ => errorEnergy k₀ p.1 p.2) := by
    unfold errorEnergy
    fun_prop (disch := norm_num)
  obtain ⟨L,hL⟩ := smooth_comp_lipschitzOn hsm (hel.prodMk hzl)
  apply weighted_integral_estimate_ae hT hκ hκd hL hd _ (energy_nonneg hk₀ _ _)
  filter_upwards [he,hz] with t het hzt ht
  rw [(energy_hasDerivAt_errors (het ht) (hzt ht)).deriv]
  simpa only [sq_abs] using! robust_decay_uniform (G:=G t) (e:=e t) (z:=z t)
    hk₀ hk₁ hk₂ hκd (le_rfl : |d t|≤|d t|)

/-- Passing finite-horizon dissipation bounds to the entire half-line also
proves output integrability. It cannot be bypassed by a nonintegrable Bochner
integral evaluating to zero. -/
theorem halfline_integral_estimate {V d : ℝ → ℝ} {A B : ℝ}
    (hV : ContinuousOn V (Ici 0)) (hn : ∀ t≥0, 0≤ V t) (hB : 0≤ B)
    (hd : IntegrableOn (fun t => d t^2) (Ioi 0))
    (hbound : ∀ T≥0, (∫ t in (0:ℝ)..T, V t)≤ A+B*(∫ t in (0:ℝ)..T, d t^2)) :
    IntegrableOn V (Ioi 0) ∧ (∫ t in Ioi 0, V t)≤ A+B*(∫ t in Ioi 0, d t^2) := by
  have hfi (T : ℝ) : IntegrableOn V (Ioc 0 T) := by
    exact (hV.mono (fun t (ht : t ∈ Icc (0 : ℝ) T) => ht.1)).integrableOn_Icc.mono_set Ioc_subset_Icc_self
  have hle (T : ℝ) (hT : 0≤ T) : (∫ t in (0:ℝ)..T, d t^2)≤∫ t in Ioi 0, d t^2 := by
    rw [integral_of_le hT]
    exact setIntegral_mono_set hd (Eventually.of_forall (fun t => sq_nonneg (d t)))
      (Filter.Eventually.of_forall (fun t (ht : t∈Ioc (0:ℝ) T) => ht.1))
  have hVi : IntegrableOn V (Ioi 0) := by
    apply integrableOn_Ioi_of_intervalIntegral_norm_bounded
      (A+B*(∫ t in Ioi 0, d t^2)) 0 hfi tendsto_id
    filter_upwards [eventually_ge_atTop (0:ℝ)] with T hT
    have he : (∫ t in (0:ℝ)..T, ‖V t‖)=(∫ t in (0:ℝ)..T, V t) := by
      apply intervalIntegral.integral_congr
      intro t ht
      rw [uIcc_of_le hT] at ht
      exact Real.norm_of_nonneg (hn t ht.1)
    rw [he]
    exact (hbound T hT).trans (add_le_add (le_refl A) (mul_le_mul_of_nonneg_left (hle T hT) hB))
  refine ⟨hVi,?_⟩
  exact le_of_tendsto_of_tendsto
    (intervalIntegral_tendsto_integral_Ioi 0 hVi tendsto_id)
    (tendsto_const_nhds.add ((intervalIntegral_tendsto_integral_Ioi 0 hd tendsto_id).const_mul B))
    ((eventually_ge_atTop (0:ℝ)).mono (fun T hT => hbound T hT))

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.AEIntegralEstimate -/

/- BEGIN SOURCE MODULE: ChainFountain.AEBarrier -/

namespace ChainFountain
noncomputable section
open Set Real Filter MeasureTheory
open scoped NNReal

def filteredCommand (H g β αlo αhi γ vmin uLo uHi : ℝ)
    (h v w desired : ℝ → ℝ) (t : ℝ) :=
  clip (max uLo (barrierLower αhi (v t)))
    (min uHi (barrierUpper H g β αlo (h t) (v t) (w t) γ ((v t+w t)/2-vmin)))
    (desired t)

/-- The robust least-change filter implies the crown comparison along an a.e.
mechanical trajectory on a regular interval. It does not assert existence of
the filtered trajectory or positivity of either leg separately. -/
theorem filtered_mechanical_crown_ae
    {H g β αlo αhi γ vmin uLo uHi T : ℝ}
    {h v w α desired : ℝ → ℝ} {Lv Lw : ℝ≥0}
    (hγ : 0<γ) (hα : αlo≤αhi)
    (hvL : LipschitzOnWith Lv v (Icc 0 T)) (hwL : LipschitzOnWith Lw w (Icc 0 T))
    (hh : ∀ t∈Icc 0 T, 0<h t)
    (hcoef : ∀ t∈Icc 0 T, α t∈Icc αlo αhi)
    (hfeas : ∀ t∈Icc 0 T, max uLo (barrierLower αhi (v t))≤
      min uHi (barrierUpper H g β αlo (h t) (v t) (w t) γ ((v t+w t)/2-vmin)))
    (dv : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt v
      (rise g (α t) (h t) (v t) (w t)
        (filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t)) t)
    (dw : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt w (fall H g β (h t) (v t) (w t)) t) :
    ∀ t∈Icc 0 T,
      ((v 0+w 0)/2-vmin)*exp (-γ*t)≤(v t+w t)/2-vmin ∧
      uLo≤ filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t ∧
      filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t≤ uHi ∧
      0≤ pickup (α t) (v t) (filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t) := by
  let u := filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired
  let B := fun t => (v t+w t)/2-vmin
  have hclip (t : ℝ) (ht : t∈Icc 0 T) := clip_mem (desired:=desired t) (hfeas t ht)
  have hupper (t : ℝ) (ht : t∈Icc 0 T) :
      u t≤ barrierUpper H g β αlo (h t) (v t) (w t) γ (B t) :=
    (hclip t ht).2.trans (min_le_right _ _)
  have hcrown (t : ℝ) (ht : t∈Icc 0 T) :
      0≤(rise g (α t) (h t) (v t) (w t) (u t)+fall H g β (h t) (v t) (w t))/2+γ*B t :=
    ((crown_endpoint_iff (hh t ht) hα).mpr (hupper t ht)) (α t) (hcoef t ht)
  have hsm : ContDiff ℝ 1 (fun p : ℝ×ℝ => -((p.1+p.2)/2-vmin)) := by fun_prop (disch := norm_num)
  obtain ⟨L,hL⟩ := smooth_comp_lipschitzOn hsm (hvL.prodMk hwL)
  have hd : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt (fun s => -B s)
      (-((rise g (α t) (h t) (v t) (w t) (u t)+fall H g β (h t) (v t) (w t))/2)) t := by
    filter_upwards [dv,dw] with t ht hv hmem
    exact ((((ht hmem).add (hv hmem)).div_const 2).sub_const vmin).neg
  have hi := scalar_comparison_ae (κ:=γ/2) (C:=0) (by positivity) hL hd (by
    apply Eventually.of_forall
    intro t ht
    have hh := hcrown t (Ioo_subset_Icc_self ht)
    dsimp [B] at hh ⊢
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith)
  intro t ht
  refine ⟨?_,(le_max_left _ _).trans (hclip t ht).1,
    (hclip t ht).2.trans (min_le_left _ _),?_⟩
  · have hb := hi t ht
    dsimp [envelope] at hb
    have heq : -2*(γ/2)*t= -γ*t := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    rw [heq] at hb
    simp only [zero_div,zero_mul,add_zero] at hb
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
  · exact ((pickup_endpoint_iff hα).mpr ((le_max_right _ _).trans (hclip t ht).1))
      (α t) (hcoef t ht)

theorem filtered_command_least_change
    {H g β αlo αhi γ vmin uLo uHi t : ℝ} {h v w desired : ℝ → ℝ}
    (hfeas : max uLo (barrierLower αhi (v t))≤
      min uHi (barrierUpper H g β αlo (h t) (v t) (w t) γ ((v t+w t)/2-vmin)))
    {u : ℝ} (hu : uLo≤ u ∧ u≤ uHi ∧ barrierLower αhi (v t)≤ u ∧
      u≤ barrierUpper H g β αlo (h t) (v t) (w t) γ ((v t+w t)/2-vmin)) :
    (filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t-desired t)^2≤
      (u-desired t)^2 :=
  clip_nearest hfeas ⟨max_le hu.1 hu.2.2.1,le_min hu.2.1 hu.2.2.2⟩

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.AEBarrier -/

/- BEGIN SOURCE MODULE: ChainFountain.ExplicitBounds -/

namespace ChainFountain
noncomputable section
open Set Real MeasureTheory Filter
open scoped NNReal

def fallingRateBound (H g β hlo shi whi : ℝ) := g+(shi^2+β*whi^2)/(H+hlo)
def risingRateBound (Mw A κd Gmax cz dbar : ℝ) := Mw+2*A+κd*Gmax^2*cz+Gmax*dbar

theorem falling_rate_bound {H g β h v w hlo shi whi : ℝ}
    (hg : 0≤ g) (hb : 0≤β) (hD : 0<H+hlo) (hh : hlo≤ h)
    (hs : |(v+w)/2|≤ shi) (hw : |w|≤ whi) :
    |fall H g β h v w|≤ fallingRateBound H g β hlo shi whi := by
  have hDp : 0<H+h := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hsq : crownSq v w≤ shi^2 := by
    dsimp [crownSq]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [sq_le_sq₀ (abs_nonneg ((v+w)/2)) ((abs_nonneg _).trans hs) |>.mpr hs,
      sq_abs ((v+w)/2)]
  have hwq : w^2≤ whi^2 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [sq_le_sq₀ (abs_nonneg w) ((abs_nonneg _).trans hw) |>.mpr hw,sq_abs w]
  have hnum : |-crownSq v w+β*w^2|≤ shi^2+β*whi^2 := by
    have h := abs_add_le (-crownSq v w) (β*w^2)
    have hcn : 0≤ crownSq v w := by dsimp [crownSq]; positivity
    rw [abs_neg,abs_of_nonneg hcn,abs_of_nonneg (mul_nonneg hb (sq_nonneg w))] at h
    have hm := mul_le_mul_of_nonneg_left hwq hb
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hdiv : |(-crownSq v w+β*w^2)/(H+h)|≤(shi^2+β*whi^2)/(H+hlo) := by
    rw [abs_div,abs_of_pos hDp]
    exact (div_le_div_of_nonneg_right hnum hDp.le).trans
      (div_le_div_of_nonneg_left (by positivity) hD (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith))
  have h := abs_add_le g ((-crownSq v w+β*w^2)/(H+h))
  rw [abs_of_nonneg hg] at h
  exact h.trans (add_le_add (le_refl g) hdiv)

theorem rising_rate_bound {H g α β h v w A κd z d Mw Amax Gmax cz dbar : ℝ}
    (hh : h≠0) (hH : H+h≠0) (hκd : 0≤κd)
    (hw : |fall H g β h v w|≤ Mw) (hA : |A|≤ Amax)
    (hG : |v^2/h|≤ Gmax) (hz : |z|≤ cz) (hd : |d|≤ dbar) :
    |rise g (α+d) h v w (robustInput H g α β h v w A κd z)|≤
      risingRateBound Mw Amax κd Gmax cz dbar := by
  have hid := robust_acceleration H g α β h v w A κd z d hh hH
  have heq : rise g (α+d) h v w (robustInput H g α β h v w A κd z)=
      fall H g β h v w+2*A-κd*(v^2/h)^2*z+(v^2/h)*d := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hG0 : 0≤ Gmax := (abs_nonneg _).trans hG
  have hz0 : 0≤ cz := (abs_nonneg _).trans hz
  have hGq : (v^2/h)^2≤ Gmax^2 := by
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [sq_le_sq₀ (abs_nonneg (v^2/h)) hG0 |>.mpr hG,sq_abs (v^2/h)]
  have hz' := mul_le_mul (mul_le_mul_of_nonneg_left hGq hκd) hz (abs_nonneg z) (by positivity : 0≤κd*Gmax^2)
  have hd' := mul_le_mul hG hd (abs_nonneg d) hG0
  have h₁ := abs_add_le (fall H g β h v w) (2*A)
  have h₂ := abs_sub (fall H g β h v w+2*A) (κd*(v^2/h)^2*z)
  have h₃ := abs_add_le (fall H g β h v w+2*A-κd*(v^2/h)^2*z) ((v^2/h)*d)
  simp only [abs_mul,abs_of_nonneg hκd,abs_of_nonneg (sq_nonneg (v^2/h)),
    abs_of_pos (by norm_num : (0:ℝ)<2)] at h₁ h₂ h₃
  rw [heq]
  dsimp [risingRateBound]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

/-- The product norm is exactly the sup norm used in the paper. -/
theorem mechanical_sup_norm_bound {h' v' w' Q Mw Mv : ℝ}
    (hh : |h'|≤ Q) (hv : |v'|≤ Mv) (hw : |w'|≤ Mw) :
    ‖(h',v',w')‖ ≤ max Q (max Mw Mv) := by
  rw [Prod.norm_def,Prod.norm_def,Real.norm_eq_abs,Real.norm_eq_abs,Real.norm_eq_abs]
  exact max_le (hh.trans (le_max_left _ _))
    (max_le (hv.trans ((le_max_right Mw Mv).trans (le_max_right Q _)))
      (hw.trans ((le_max_left Mw Mv).trans (le_max_right Q _))))

/-- The displayed M bounds the actual closed-loop mechanical vector, including
both uncertainty and additional damping. -/
theorem mechanical_explicit_bound
    {H g α β h v w A κd z d hlo shi vhi whi Q Amax cz dbar : ℝ}
    (hg : 0≤ g) (hb : 0≤β) (hhlo : 0<hlo) (hD : 0<H+hlo) (hh : hlo≤ h)
    (hκd : 0≤κd) (hq : |heightRate v w|≤ Q) (hs : |(v+w)/2|≤ shi)
    (hv : |v|≤ vhi) (hw : |w|≤ whi) (hA : |A|≤ Amax) (hz : |z|≤ cz) (hd : |d|≤ dbar) :
    let Mw := fallingRateBound H g β hlo shi whi
    let Mv := risingRateBound Mw Amax κd (vhi^2/hlo) cz dbar
    ‖(heightRate v w,rise g (α+d) h v w (robustInput H g α β h v w A κd z),
      fall H g β h v w)‖ ≤ max Q (max Mw Mv) := by
  have hp : 0<h := hhlo.trans_le hh
  have hHp : 0<H+h := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hvsq : v^2≤ vhi^2 := by
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [sq_le_sq₀ (abs_nonneg v) ((abs_nonneg v).trans hv) |>.mpr hv,sq_abs v]
  have hG : |v^2/h|≤ vhi^2/hlo := by
    rw [abs_of_nonneg (div_nonneg (sq_nonneg v) hp.le)]
    exact (div_le_div_of_nonneg_right hvsq hp.le).trans
      (div_le_div_of_nonneg_left (sq_nonneg _) hhlo hh)
  have hfw := falling_rate_bound hg hb hD hh hs hw
  exact mechanical_sup_norm_bound hq
    (rising_rate_bound hp.ne' hHp.ne' hκd hfw hA hG hz hd) hfw

/-- An a.e. derivative bound sharpens any prior local Lipschitz constant to M.
This is the integral justification of the paper's time-Lipschitz estimate. -/
theorem time_lipschitz_of_ae_bound {f : ℝ → ℝ} {L M : ℝ≥0} {a b : ℝ}
    (hf : LipschitzOnWith L f (Icc a b))
    (hb : ∀ᵐ t ∂volume, t∈Ioo a b → |deriv f t|≤ M) :
    LipschitzOnWith M f (Icc a b) := by
  apply LipschitzOnWith.of_dist_le_mul
  intro s hs t ht
  wlog hst : s≤ t generalizing s t
  · rw [dist_comm (f s),dist_comm s]
    exact this t ht s hs (le_of_not_ge hst)
  have hsub : Icc s t⊆Icc a b := Icc_subset_Icc hs.1 ht.2
  obtain ⟨hi,hFTC⟩ := lipschitzOn_integral_deriv hst (hf.mono hsub)
  have hne : ∀ᵐ u ∂volume, u≠t := by simp [ae_iff,measure_singleton]
  have hnorm : ‖∫ u in s..t, deriv f u‖≤(M:ℝ)*(t-s) := by
    rw [←abs_of_nonneg (sub_nonneg.mpr hst)]
    apply intervalIntegral.norm_integral_le_of_norm_le_const_ae
    filter_upwards [hb,hne] with u hu hnt hmem
    rw [uIoc_of_le hst] at hmem
    exact hu ⟨hs.1.trans_lt hmem.1,(lt_of_le_of_ne hmem.2 hnt).trans_le ht.2⟩
  rw [hFTC] at hnorm
  simpa [dist_eq_norm,Real.norm_eq_abs,abs_sub_comm (f s),abs_of_nonpos (sub_nonpos.mpr hst),
    neg_sub] using hnorm

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.ExplicitBounds -/

/- BEGIN SOURCE MODULE: ChainFountain.GlobalL2 -/

namespace ChainFountain
noncomputable section
-- A finite budget for the global integral and L² estimates in the editor.
set_option maxHeartbeats 1000000
open Set Real MeasureTheory Filter
open scoped NNReal

theorem GlobalTrackingData.measurable_energy_dissipation (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) {x : ℝ → MechanicalState}
    (hh : ∀ t≥0, 0<(x t).1)
    (hxD : ∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) :
    ∀ᵐ t ∂volume, 0≤ t →
      deriv (fun s => c.stateEnergy s (x s)) t≤
        -2*c.κ*c.stateEnergy t (x t)+d t^2/(8*c.κd) := by
  let h := fun t => (x t).1
  let v := fun t => (x t).2.1
  let w := fun t => (x t).2.2
  filter_upwards [hxD] with t hdt ht
  have dh : HasDerivAt h (heightRate (v t) (w t)) t := by
    simpa [h,v,w,measurableField,jointField] using! hasFDerivAt_fst.comp_hasDerivAt t (hdt ht)
  have dv : HasDerivAt v (rise c.g (c.α+d t) (h t) (v t) (w t)
      (requestedInput c.H c.g c.α c.β c.k₀ c.k₁ c.k₂ c.κd h v w c.r c.r₁ c.r₂ t)) t := by
    simpa [h,v,w,measurableField,measurableParameters,jointField,parameters,max_eq_right ht,
      requestedInput,heightError,velocityError] using!
      hasFDerivAt_fst.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t (hdt ht))
  have dw : HasDerivAt w (fall c.H c.g c.β (h t) (v t) (w t)) t := by
    simpa [h,v,w,measurableField,jointField] using!
      hasFDerivAt_snd.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t (hdt ht))
  obtain ⟨he,hz⟩ := closed_loop_error_equations (hh t ht).ne'
    (add_pos c.H_pos (hh t ht)).ne' dh dv dw (c.dr t ht) (c.dr₁ t ht)
  have hV := energy_hasDerivAt_errors he hz
  have heq : (fun s => c.stateEnergy s (x s))=
      fun s => errorEnergy c.k₀ (heightError h c.r s) (velocityError c.k₁ h v w c.r c.r₁ s) := rfl
  rw [heq,hV.deriv]
  simpa only [sq_abs] using! robust_decay_uniform
    (e:=heightError h c.r t) (z:=velocityError c.k₁ h v w c.r c.r₁ t) (G:=(v t)^2/h t)
    c.k₀_pos.le c.κ_le_k₁ c.κ_le_k₂ hκd (le_rfl : |d t|≤|d t|)

theorem GlobalTrackingData.measurable_energy_integral (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) {x : ℝ → MechanicalState} {K : ℝ≥0}
    (hxL : LipschitzWith K x) (hh : ∀ t≥0, 0<(x t).1)
    (hxD : ∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t)
    {T : ℝ} (hT : 0≤ T) (hd : IntervalIntegrable (fun t => d t^2) volume 0 T) :
    (∫ t in (0:ℝ)..T, 2*c.stateEnergy t (x t))≤
      c.stateEnergy 0 (x 0)/c.κ+(1/(8*c.κ*c.κd))*(∫ t in (0:ℝ)..T, d t^2) := by
  obtain ⟨Le,Lz,he,hz⟩ := c.errors_lipschitz hxL T
  have hsm : ContDiff ℝ 1 (fun p : ℝ×ℝ => errorEnergy c.k₀ p.1 p.2) := by
    unfold errorEnergy
    fun_prop (disch := norm_num)
  obtain ⟨L,hL⟩ := smooth_comp_lipschitzOn hsm (he.prodMk hz)
  exact weighted_integral_estimate_ae hT c.κ_pos hκd hL hd
    ((c.measurable_energy_dissipation hκd hh hxD).mono (fun t ht hmem => ht hmem.1.le))
    (energy_nonneg c.k₀_pos.le _ _)

/-- A global physical trajectory is constructed for the finite-energy bounded
measurable disturbance, and its entire weighted output energy is finite. -/
theorem GlobalTrackingData.exists_global_L2_tracking (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : AEMeasurable d volume)
    (hdb : ∀ t, |d t|≤ c.dbar) (hd : IntegrableOn (fun t => d t^2) (Ioi 0)) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      IntegrableOn (fun t => 2*c.stateEnergy t (x t)) (Ioi 0) ∧
      (∫ t in Ioi 0, 2*c.stateEnergy t (x t))≤
        c.stateEnergy 0 c.x₀/c.κ+(1/(8*c.κ*c.κd))*(∫ t in Ioi 0, d t^2) := by
  obtain ⟨x,K,hxL,hx₀,hxD,hbox,hE⟩ := c.exists_global_aemeasurable_tracking hκd hdm hdb
  have hh (t : ℝ) (ht : 0≤ t) : 0<(x t).1 :=
    c.height_positive.trans_le (hbox t ht).1.1
  have hcont : ContinuousOn (fun t => 2*c.stateEnergy t (x t)) (Ici 0) := by
    have hr : ContinuousOn c.r (Ici 0) := fun t ht => (c.dr t ht).continuousAt.continuousWithinAt
    have hr₁ : ContinuousOn c.r₁ (Ici 0) := fun t ht => (c.dr₁ t ht).continuousAt.continuousWithinAt
    have hc := hxL.continuous.continuousOn (s:=Ici (0:ℝ))
    unfold stateEnergy errorEnergy
    fun_prop
  have hbound (T : ℝ) (hT : 0≤ T) := c.measurable_energy_integral hκd hxL hh hxD hT
    ((intervalIntegrable_iff_integrableOn_Ioc_of_le hT).mpr (hd.mono_set Ioc_subset_Ioi_self))
  have hglobal := halfline_integral_estimate hcont
    (fun t _ => mul_nonneg (by norm_num) (energy_nonneg c.k₀_pos.le _ _))
    (div_nonneg zero_le_one (mul_nonneg (mul_nonneg (by norm_num) c.κ_pos.le) hκd.le))
    hd hbound
  exact ⟨x,K,hxL,hx₀,hxD,hbox,hglobal.1,by simpa [hx₀] using! hglobal.2⟩

/-- The half-line square-integral estimate is the usual L² norm gain. Both
signals are proved members of `MemLp 2`, so no nonintegrable zero-integral
convention can make this assertion vacuous. -/
theorem weighted_L2_gain {V d : ℝ → ℝ} {μ : Measure ℝ} {B : ℝ}
    (hV : AEStronglyMeasurable V μ) (hd : AEStronglyMeasurable d μ)
    (hn : ∀ᵐ t ∂μ, 0≤ V t) (hVi : Integrable V μ)
    (hdi : Integrable (fun t => d t^2) μ) (hB : 0≤ B)
    (hbound : (∫ t, V t ∂μ)≤ B*(∫ t, d t^2 ∂μ)) :
    MemLp (fun t => sqrt (V t)) 2 μ ∧ MemLp d 2 μ ∧
      sqrt (∫ t, (sqrt (V t))^2 ∂μ)≤ sqrt B*sqrt (∫ t, d t^2 ∂μ) := by
  have heq : (fun t => (sqrt (V t))^2)=ᵐ[μ] V := hn.mono (fun t ht => sq_sqrt ht)
  have hsq : Integrable (fun t => (sqrt (V t))^2) μ := hVi.congr heq.symm
  refine ⟨(memLp_two_iff_integrable_sq (Real.continuous_sqrt.comp_aestronglyMeasurable hV)).mpr hsq,
    (memLp_two_iff_integrable_sq hd).mpr hdi,?_⟩
  rw [integral_congr_ae heq,←sqrt_mul hB]
  exact sqrt_le_sqrt hbound

/-- Zero-initial-error L² gain for the actual globally constructed physical
trajectory, with the exact paper constant. -/
theorem GlobalTrackingData.exists_global_L2_gain (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : AEMeasurable d volume)
    (hdb : ∀ t, |d t|≤ c.dbar) (hd : IntegrableOn (fun t => d t^2) (Ioi 0))
    (hzero : c.stateEnergy 0 c.x₀=0) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      MemLp (fun t => sqrt (2*c.stateEnergy t (x t))) 2 (volume.restrict (Ioi 0)) ∧
      MemLp d 2 (volume.restrict (Ioi 0)) ∧
      sqrt (∫ t in Ioi 0, (sqrt (2*c.stateEnergy t (x t)))^2)≤
        sqrt (1/(8*c.κ*c.κd))*sqrt (∫ t in Ioi 0, d t^2) := by
  obtain ⟨x,K,hL,h₀,hD,hbox,hVi,hbound⟩ := c.exists_global_L2_tracking hκd hdm hdb hd
  have hn : ∀ᵐ t ∂(volume.restrict (Ioi 0)), 0≤2*c.stateEnergy t (x t) :=
    Eventually.of_forall (fun _ => mul_nonneg (by norm_num) (energy_nonneg c.k₀_pos.le _ _))
  have hB : 0≤1/(8*c.κ*c.κd) :=
    div_nonneg zero_le_one (mul_nonneg (mul_nonneg (by norm_num) c.κ_pos.le) hκd.le)
  have hb : (∫ t in Ioi 0, 2*c.stateEnergy t (x t))≤
      (1/(8*c.κ*c.κd))*(∫ t in Ioi 0, d t^2) := by simpa [hzero] using! hbound
  exact ⟨x,K,hL,h₀,hD,hbox,weighted_L2_gain hVi.aestronglyMeasurable
    hdm.aestronglyMeasurable.restrict hn hVi hd hB hb⟩

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.GlobalL2 -/

/- BEGIN SOURCE MODULE: ChainFountain.IntegralUniqueness -/

namespace ChainFountain
noncomputable section
open Set Filter MeasureTheory Function Metric
open scoped NNReal Topology

/-- Uniqueness of integral solutions does not assume a Lipschitz trajectory.
The bounded integral equation itself supplies the required regularity. -/
theorem IntegralPicard.continuous_integral_unique
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    (v : IntegralPicard E) {x y : ℝ → E} (hx : Continuous x) (hy : Continuous y)
    (hxi : ∀ t∈Icc v.tMin v.tMax, x t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (x s))
    (hyi : ∀ t∈Icc v.tMin v.tMax, y t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (y s)) :
    ∀ t∈Icc v.tMin v.tMax, x t=y t := by
  have mk (z : ℝ → E) (hz : Continuous z)
      (hi : ∀ t∈Icc v.tMin v.tMax, z t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (z s)) :
      ∃ f : v.FunSpace, f.next=f ∧ ∀ t : Icc v.tMin v.tMax, f t=z t := by
    have hInt (a b : ℝ) : IntervalIntegrable (fun s => v s (z s)) volume a b := by
      rw [intervalIntegrable_iff]
      exact Measure.integrableOn_of_bounded measure_Ioc_lt_top.ne
        (v.measurable_curve z hz) (Eventually.of_forall (fun s => v.bound_all s (z s)))
    let f : v.FunSpace := {
      toFun := fun t => z t
      map_t₀' := by simpa using! hi v.t₀ v.t₀.2
      lipschitz' := LipschitzWith.of_dist_le_mul (fun a b => by
        rw [hi a a.2, hi b b.2, dist_add_left, dist_eq_norm,
          intervalIntegral.integral_interval_sub_left (hInt _ _) (hInt _ _)]
        exact intervalIntegral.norm_integral_le_of_norm_le_const
          (fun s _ => v.bound_all s (z s))) }
    refine ⟨f,?_,fun _ => rfl⟩
    apply IntegralPicard.FunSpace.toContinuousMap.injective
    apply ContinuousMap.ext
    intro t
    change v.x₀+∫ s in (v.t₀:ℝ)..(t:ℝ), v s (z (v.proj s))=z t
    rw [hi t t.2]
    congr 1
    apply intervalIntegral.integral_congr
    intro s hs
    have hmem : s∈Icc v.tMin v.tMax := (uIcc_subset_Icc v.t₀.2 t.2) hs
    dsimp only
    rw [v.proj_of_mem hmem]
  obtain ⟨f,hf,hfx⟩ := mk x hx hxi
  obtain ⟨g,hg,hgy⟩ := mk y hy hyi
  obtain ⟨n,K,hK⟩ := v.exists_contracting_iterate
  have hfg : f=g := hK.fixedPoint_unique' (IsFixedPt.iterate hf n) (IsFixedPt.iterate hg n)
  intro t ht
  rw [←hfx ⟨t,ht⟩,←hgy ⟨t,ht⟩,hfg]

/-- The actual projected mechanical field supplies bounded measurable Picard
 data uniformly on every finite interval. -/
theorem GlobalTrackingData.measurable_picard_data (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hd : Measurable d) (hb : ∀ t, |d t|≤ c.dbar) {T : ℝ} (hT : 0≤ T) :
    ∃ v : IntegralPicard MechanicalState,
      v.tMin=0 ∧ v.tMax=T ∧ (v.t₀:ℝ)=0 ∧ v.x₀=c.x₀ ∧
      ∀ t x, v t x=c.measurableField d t (c.project x) := by
  obtain ⟨L,N,hL,hN⟩ := c.joint_bounds
  let F := fun t x => c.measurableField d t (c.project x)
  have hfl : ∀ t, LipschitzWith L (F t) := by
    intro t
    have hh := hL.comp
      ((LipschitzWith.prodMk_left (c.measurableParameters d t)).comp c.project_lipschitz).lipschitzOnWith (s:=univ)
      (fun x _ => ⟨c.measurable_parameters_mem hb t,c.project_mem x⟩)
    simpa [F,GlobalTrackingData.measurableField,lipschitzOnWith_univ] using! hh
  have hpm : Measurable (c.measurableParameters d) :=
    c.parameters_continuous.fst.measurable.prodMk
      (c.parameters_continuous.snd.fst.measurable.prodMk
        (c.parameters_continuous.snd.snd.fst.measurable.prodMk hd))
  have hfm : ∀ f : ℝ → MechanicalState, Continuous f →
      AEStronglyMeasurable (fun t => F t (f t)) volume := by
    intro f hf
    let y (t : ℝ) : c.parameterBox ×ˢ c.outerBox :=
      ⟨(c.measurableParameters d t,c.project (f t)),c.measurable_parameters_mem hb t,c.project_mem _⟩
    have hy : Measurable y := (hpm.prodMk (c.project_lipschitz.continuous.comp hf).measurable).subtype_mk
    exact (hL.continuousOn.domRestrict.measurable.comp hy).aestronglyMeasurable
  let v : IntegralPicard MechanicalState := {
    toFun := F
    tMin := 0
    tMax := T
    t₀ := ⟨0,le_rfl,hT⟩
    x₀ := c.x₀
    C := ⟨max N 0,le_max_right _ _⟩
    L := L
    lipschitz_all := hfl
    measurable_curve := hfm
    bound_all := fun t x => (hN _ ⟨c.measurable_parameters_mem hb t,c.project_mem x⟩).trans
      (le_max_left _ _) }
  exact ⟨v,rfl,rfl,rfl,rfl,fun _ _ => rfl⟩

/-- A globally constructed physical solution is unique among all continuous
integral solutions of the ORIGINAL field. No safe-box, Lipschitz, or existence
hypothesis is imposed on the competing solution. This is the integral
Caratheodory formulation; the AC/a.e. equivalence is a separate FTC bridge. -/
theorem GlobalTrackingData.exists_unique_global_integral (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hd : Measurable d) (hb : ∀ t, |d t|≤ c.dbar) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      (∀ t≥0, x t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (x s)) ∧
      ∀ y : ℝ → MechanicalState, Continuous y →
        (∀ t≥0, y t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (y s)) →
        ∀ t≥0, y t=x t := by
  obtain ⟨x,K,ε,hε,hxL,hx₀,hxI,hxD,hlocal,hlocalD⟩ := c.exists_measurable_local hd hb
  have hstay := no_exit_of_prefix_bound hxL.continuous
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    (hx₀ ▸ c.safeBox_interior c.initial_mem) (fun T hT hbox =>
      c.measurable_prefix_bound hκd hb hxL hT hx₀ hbox hxD)
  have hxi (t : ℝ) (ht : 0≤ t) : x t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (x s) := by
    rw [hxI t]
    congr 1
    apply intervalIntegral.integral_congr
    intro s hs
    rw [uIcc_of_le ht] at hs
    dsimp only
    rw [c.project_eq (x s) (interior_subset (c.safeBox_interior (hstay s hs.1)))]
  refine ⟨x,K,hxL,hx₀,hstay,hxi,?_⟩
  intro y hy hyi
  have hprefix (T : ℝ) (hT : 0≤ T) (hyB : ∀ t∈Icc 0 T, y t∈c.outerBox) :
      ∀ t∈Icc 0 T, y t=x t := by
    obtain ⟨v,hmin,hmax,hzero,hinit,hfield⟩ := c.measurable_picard_data hd hb hT
    have hi (t : ℝ) (ht : t∈Icc v.tMin v.tMax) :
        y t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (y s) := by
      rw [hmin,hmax] at ht
      rw [hinit,hzero,hyi t ht.1]
      congr 1
      apply intervalIntegral.integral_congr
      intro s hs
      rw [uIcc_of_le ht.1] at hs
      dsimp only
      rw [hfield,c.project_eq (y s) (hyB s ⟨hs.1,hs.2.trans ht.2⟩)]
    have hj (t : ℝ) (ht : t∈Icc v.tMin v.tMax) :
        x t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (x s) := by
      simpa only [hinit,hzero,hfield] using! hxI t
    simpa only [hmin,hmax] using! v.continuous_integral_unique hy hxL.continuous hi hj
  have hy₀ : y 0=c.x₀ := by simpa using! hyi 0 le_rfl
  have hystay := no_exit_of_prefix_bound hy
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    (hy₀ ▸ c.safeBox_interior c.initial_mem) (fun T hT hbox => by
      rw [hprefix T hT hbox T ⟨hT,le_rfl⟩]; exact hstay T hT)
  intro t ht
  exact hprefix t ht (fun s hs => interior_subset (c.safeBox_interior (hystay s hs.1))) t ⟨ht,le_rfl⟩

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.IntegralUniqueness -/

/- BEGIN SOURCE MODULE: ChainFountain.AbsoluteContinuity -/

namespace ChainFountain
noncomputable section
open Set Filter MeasureTheory Function
open scoped Topology NNReal

/-- Lipschitz composition preserves genuine metric absolute continuity. -/
theorem ac_lipschitz_comp {E F : Type*} [PseudoMetricSpace E] [PseudoMetricSpace F]
    {f : ℝ → E} {g : E → F} {a b : ℝ} {K : ℝ≥0}
    (hf : AbsolutelyContinuousOnInterval f a b) (hg : LipschitzWith K g) :
    AbsolutelyContinuousOnInterval (g ∘ f) a b := by
  apply squeeze_zero (fun _ => Finset.sum_nonneg (fun _ _ => dist_nonneg))
    (fun _ => ?_) (by simpa using Tendsto.const_mul (K:ℝ) hf)
  rw [Finset.mul_sum]
  exact Finset.sum_le_sum (fun i _ => hg.dist_le_mul _ _)

/-- Absolute continuity is invariant under equality on the interval. -/
theorem ac_congr {E : Type*} [PseudoMetricSpace E] {f g : ℝ → E} {a b : ℝ}
    (hf : AbsolutelyContinuousOnInterval f a b) (he : EqOn g f (uIcc a b)) :
    AbsolutelyContinuousOnInterval g a b := by
  apply (absolutelyContinuousOnInterval_iff g a b).mpr
  intro ε hε
  obtain ⟨δ,hδ,hfδ⟩ := (absolutelyContinuousOnInterval_iff f a b).mp hf ε hε
  refine ⟨δ,hδ,?_⟩
  intro E hE hlen
  have hends := hE.1
  have heq : (∑ i ∈ Finset.range E.1, dist (g (E.2 i).1) (g (E.2 i).2)) =
      ∑ i ∈ Finset.range E.1, dist (f (E.2 i).1) (f (E.2 i).2) := by
    apply Finset.sum_congr rfl
    intro i hi
    rw [he (hends i hi).1,he (hends i hi).2]
  rw [heq]
  exact hfδ E hE hlen

/-- Product absolute continuity, using the product metric. -/
theorem ac_prod {E F : Type*} [PseudoMetricSpace E] [PseudoMetricSpace F]
    {f : ℝ → E} {g : ℝ → F} {a b : ℝ}
    (hf : AbsolutelyContinuousOnInterval f a b) (hg : AbsolutelyContinuousOnInterval g a b) :
    AbsolutelyContinuousOnInterval (fun t => (f t,g t)) a b := by
  apply squeeze_zero (fun _ => Finset.sum_nonneg (fun _ _ => dist_nonneg))
    (fun _ => ?_) (by simpa using Tendsto.add hf hg)
  rw [←Finset.sum_add_distrib]
  exact Finset.sum_le_sum (fun i _ => by
    rw [Prod.dist_eq]
    exact max_le_add_of_nonneg (dist_nonneg) (dist_nonneg))

/-- Reverse FTC for every real absolutely continuous curve, with its a.e.
derivative supplied by an equation. No Lipschitz regularity is assumed. -/
theorem ac_integral_eq_sub {f g : ℝ → ℝ} {a b : ℝ}
    (hf : AbsolutelyContinuousOnInterval f a b)
    (hd : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt f (g t) t) :
    IntervalIntegrable g volume a b ∧ (∫ t in a..b, g t)=f b-f a := by
  have he : deriv f =ᵐ[volume.restrict (uIoc a b)] g := by
    filter_upwards [ae_restrict_of_ae hd,ae_restrict_mem measurableSet_uIoc] with t ht hmem
    exact (ht (uIoc_subset_uIcc hmem)).deriv
  refine ⟨hf.intervalIntegrable_deriv.congr_ae he,?_⟩
  rw [←intervalIntegral.integral_congr_ae_restrict he,hf.integral_deriv_eq_sub]

/-- The complete scalar Caratheodory equivalence on a compact interval. -/
theorem ac_ae_iff_integral {f g : ℝ → ℝ} {a b : ℝ} (hab : a≤ b) :
    (AbsolutelyContinuousOnInterval f a b ∧
      ∀ᵐ t ∂volume, t∈Icc a b → HasDerivAt f (g t) t) ↔
    (IntervalIntegrable g volume a b ∧
      ∀ t∈Icc a b, f t=f a+∫ s in a..t, g s) := by
  constructor
  · rintro ⟨hf,hd⟩
    have hd' : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt f (g t) t := by
      simpa only [uIcc_of_le hab] using hd
    refine ⟨(ac_integral_eq_sub hf hd').1,?_⟩
    intro t ht
    have hsub : uIcc a t ⊆ uIcc a b := by
      rw [uIcc_of_le ht.1,uIcc_of_le hab]
      exact Icc_subset_Icc le_rfl ht.2
    have hd'' : ∀ᵐ s ∂volume, s∈uIcc a t → HasDerivAt f (g s) s := by
      filter_upwards [hd'] with s hs hmem using hs (hsub hmem)
    have hi := (ac_integral_eq_sub (hf.mono hsub) hd'').2
    linarith
  · rintro ⟨hg,he⟩
    have hprim := hg.absolutelyContinuousOnInterval_intervalIntegral (c:=a) (by simp)
    have hc : AbsolutelyContinuousOnInterval (fun _ : ℝ => f a) a b :=
      (LipschitzWith.const (f a)).lipschitzOnWith.absolutelyContinuousOnInterval
    refine ⟨ac_congr (hc.fun_add hprim) (by intro t ht; exact he t (by simpa only [uIcc_of_le hab] using ht)),?_⟩
    have hne (c : ℝ) : ∀ᵐ t ∂volume, t≠c := by
      simp [ae_iff, measure_singleton]
    filter_upwards [hg.ae_hasDerivAt_integral,hne a,hne b] with t ht hta htb hmem
    have hto : t∈Ioo a b := ⟨lt_of_le_of_ne hmem.1 (Ne.symm hta),lt_of_le_of_ne hmem.2 htb⟩
    have hp := (ht (by simpa [uIcc_of_le hab] using hmem) a (by simp)).const_add (f a)
    apply hp.congr_of_eventuallyEq
    filter_upwards [Ioo_mem_nhds hto.1 hto.2] with s hs
    exact he s (Ioo_subset_Icc_self hs)

/-- Reverse FTC in the three mechanical coordinates. This is an actual vector
integral, not three unrelated scalar conclusions. -/
theorem ac_state_integral_eq_sub {f g : ℝ → ℝ × (ℝ × ℝ)} {a b : ℝ}
    (hf : AbsolutelyContinuousOnInterval f a b)
    (hd : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt f (g t) t) :
    IntervalIntegrable g volume a b ∧ (∫ t in a..b, g t)=f b-f a := by
  have h₁ := ac_lipschitz_comp hf LipschitzWith.prod_fst
  have h₂ := ac_lipschitz_comp (ac_lipschitz_comp hf LipschitzWith.prod_snd) LipschitzWith.prod_fst
  have h₃ := ac_lipschitz_comp (ac_lipschitz_comp hf LipschitzWith.prod_snd) LipschitzWith.prod_snd
  have hd₁ : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt (fun s => (f s).1) (g t).1 t := by
    filter_upwards [hd] with t ht hmem
    exact hasFDerivAt_fst.comp_hasDerivAt t (ht hmem)
  have hd₂ : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt (fun s => (f s).2.1) (g t).2.1 t := by
    filter_upwards [hd] with t ht hmem
    exact hasFDerivAt_fst.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t (ht hmem))
  have hd₃ : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt (fun s => (f s).2.2) (g t).2.2 t := by
    filter_upwards [hd] with t ht hmem
    exact hasFDerivAt_snd.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t (ht hmem))
  obtain ⟨hi₁,he₁⟩ := ac_integral_eq_sub h₁ hd₁
  obtain ⟨hi₂,he₂⟩ := ac_integral_eq_sub h₂ hd₂
  obtain ⟨hi₃,he₃⟩ := ac_integral_eq_sub h₃ hd₃
  have hi : IntervalIntegrable g volume a b :=
    ⟨hi₁.1.prodMk (hi₂.1.prodMk hi₃.1),hi₁.2.prodMk (hi₂.2.prodMk hi₃.2)⟩
  refine ⟨hi,?_⟩
  have hp₁ := (ContinuousLinearMap.fst ℝ ℝ (ℝ×ℝ)).intervalIntegral_comp_comm hi
  have hp₂ := ((ContinuousLinearMap.fst ℝ ℝ ℝ).comp
    (ContinuousLinearMap.snd ℝ ℝ (ℝ×ℝ))).intervalIntegral_comp_comm hi
  have hp₃ := ((ContinuousLinearMap.snd ℝ ℝ ℝ).comp
    (ContinuousLinearMap.snd ℝ ℝ (ℝ×ℝ))).intervalIntegral_comp_comm hi
  apply Prod.ext
  · exact hp₁.symm.trans he₁
  · exact Prod.ext (hp₂.symm.trans he₂) (hp₃.symm.trans he₃)

/-- Vector integral primitives are absolutely continuous in the mechanical
state space, including merely integrable right-hand sides. -/
theorem state_integral_ac {g : ℝ → ℝ × (ℝ × ℝ)} {a b : ℝ}
    (hg : IntervalIntegrable g volume a b) :
    AbsolutelyContinuousOnInterval (fun t => ∫ s in a..t, g s) a b := by
  have hi₁ : IntervalIntegrable (fun s => (g s).1) volume a b := ⟨hg.1.fst,hg.2.fst⟩
  have hi₂ : IntervalIntegrable (fun s => (g s).2.1) volume a b := ⟨hg.1.snd.fst,hg.2.snd.fst⟩
  have hi₃ : IntervalIntegrable (fun s => (g s).2.2) volume a b := ⟨hg.1.snd.snd,hg.2.snd.snd⟩
  apply ac_congr (ac_prod
    (hi₁.absolutelyContinuousOnInterval_intervalIntegral (c:=a) (by simp))
    (ac_prod (hi₂.absolutelyContinuousOnInterval_intervalIntegral (c:=a) (by simp))
      (hi₃.absolutelyContinuousOnInterval_intervalIntegral (c:=a) (by simp))))
  intro t ht
  have hit := hg.mono_set (uIcc_subset_uIcc_left ht)
  exact Prod.ext
    ((ContinuousLinearMap.fst ℝ ℝ (ℝ×ℝ)).intervalIntegral_comp_comm hit).symm
    (Prod.ext (((ContinuousLinearMap.fst ℝ ℝ ℝ).comp
      (ContinuousLinearMap.snd ℝ ℝ (ℝ×ℝ))).intervalIntegral_comp_comm hit).symm
      (((ContinuousLinearMap.snd ℝ ℝ ℝ).comp
      (ContinuousLinearMap.snd ℝ ℝ (ℝ×ℝ))).intervalIntegral_comp_comm hit).symm)

/-- The full AC/a.e.-integral equivalence for the mechanical state space.
There is no Lipschitz, continuity-of-the-field, or pre-existing FTC hypothesis. -/
theorem ac_state_ae_iff_integral {f g : ℝ → ℝ × (ℝ × ℝ)} {a b : ℝ} (hab : a≤ b) :
    (AbsolutelyContinuousOnInterval f a b ∧
      ∀ᵐ t ∂volume, t∈Icc a b → HasDerivAt f (g t) t) ↔
    (IntervalIntegrable g volume a b ∧
      ∀ t∈Icc a b, f t=f a+∫ s in a..t, g s) := by
  constructor
  · rintro ⟨hf,hd⟩
    have hd' : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt f (g t) t := by
      simpa only [uIcc_of_le hab] using hd
    refine ⟨(ac_state_integral_eq_sub hf hd').1,?_⟩
    intro t ht
    have hsub : uIcc a t ⊆ uIcc a b := by
      rw [uIcc_of_le ht.1,uIcc_of_le hab]
      exact Icc_subset_Icc le_rfl ht.2
    have hd'' : ∀ᵐ s ∂volume, s∈uIcc a t → HasDerivAt f (g s) s := by
      filter_upwards [hd'] with s hs hmem using hs (hsub hmem)
    rw [(ac_state_integral_eq_sub (hf.mono hsub) hd'').2]
    abel
  · rintro ⟨hg,he⟩
    have hc : AbsolutelyContinuousOnInterval (fun _ : ℝ => f a) a b :=
      (LipschitzWith.const (f a)).lipschitzOnWith.absolutelyContinuousOnInterval
    refine ⟨ac_congr (hc.fun_add (state_integral_ac hg)) ?_,?_⟩
    · intro t ht
      exact he t (by simpa only [uIcc_of_le hab] using ht)
    · have hne (c : ℝ) : ∀ᵐ t ∂volume, t≠c := by simp [ae_iff,measure_singleton]
      filter_upwards [hg.ae_hasDerivAt_integral,hne a,hne b] with t ht hta htb hmem
      have hto : t∈Ioo a b := ⟨lt_of_le_of_ne hmem.1 (Ne.symm hta),lt_of_le_of_ne hmem.2 htb⟩
      have hp := (ht (by simpa [uIcc_of_le hab] using hmem) a (by simp)).const_add (f a)
      apply hp.congr_of_eventuallyEq
      filter_upwards [Ioo_mem_nhds hto.1 hto.2] with s hs
      exact he s (Ioo_subset_Icc_self hs)

/-- A forward locally AC curve has a continuous extension to all real times,
constant before zero. No regularity at negative times is required of the curve. -/
theorem locally_ac_forward_extension {E : Type*} [NormedAddCommGroup E] {f : ℝ → E}
    (hf : ∀ T≥0, AbsolutelyContinuousOnInterval f 0 T) :
    Continuous (fun t => f (max 0 t)) := by
  rw [continuous_iff_continuousAt]
  intro t
  let N : ℝ := max 0 t+1
  have hN : 0≤ N := by dsimp [N]; positivity
  have hfc : ContinuousOn f (Icc 0 N) := by
    simpa only [uIcc_of_le hN] using AbsolutelyContinuousOnInterval.continuousOn (hf N hN)
  have hc : Continuous (fun s => f (projIcc 0 N hN s)) :=
    hfc.comp_continuous (continuous_subtype_val.comp continuous_projIcc)
      (fun s => (projIcc 0 N hN s).property)
  have htN : t<N := by dsimp [N]; linarith [le_max_right (0:ℝ) t]
  apply hc.continuousAt.congr_of_eventuallyEq
  filter_upwards [Iio_mem_nhds htN] with s hs
  by_cases hs0 : s≤0
  · rw [max_eq_left hs0,projIcc_of_le_left hN hs0]
  · have hs0' : 0≤ s := (not_le.mp hs0).le
    rw [max_eq_right hs0',projIcc_of_mem hN ⟨hs0',hs.le⟩]

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.AbsoluteContinuity -/

/- BEGIN SOURCE MODULE: ChainFountain.CaratheodoryCompletion -/

namespace ChainFountain
noncomputable section
open Set Filter MeasureTheory
open scoped NNReal Topology

/-- A forward locally absolutely continuous a.e. mechanical solution satisfies
the integral equation on every finite horizon, with integrability derived. -/
theorem forward_ac_integral {F : ℝ → MechanicalState → MechanicalState}
    {x : ℝ → MechanicalState} {x₀ : MechanicalState} (hx₀ : x 0=x₀)
    (hx : ∀ T≥0, AbsolutelyContinuousOnInterval x 0 T)
    (hd : ∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (F t (x t)) t) :
    ∀ t≥0, IntervalIntegrable (fun s => F s (x s)) volume 0 t ∧
      x t=x₀+∫ s in (0:ℝ)..t, F s (x s) := by
  intro t ht
  have hd' : ∀ᵐ s ∂volume, s∈uIcc 0 t → HasDerivAt x (F s (x s)) s := by
    filter_upwards [hd] with s hs hmem
    rw [uIcc_of_le ht] at hmem
    exact hs hmem.1
  obtain ⟨hi,he⟩ := ac_state_integral_eq_sub (hx t ht) hd'
  refine ⟨hi,?_⟩
  rw [he,hx₀]
  abel

/-- Global physical existence and unrestricted forward Caratheodory uniqueness
for every bounded measurable disturbance. Competing curves need only be locally
absolutely continuous for nonnegative times; no safe-box, Lipschitz, positive
height, or pre-given trajectory hypothesis is imposed on them. -/
theorem GlobalTrackingData.exists_unique_global_caratheodory (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : Measurable d) (hdb : ∀ t, |d t|≤ c.dbar) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ T≥0, AbsolutelyContinuousOnInterval x 0 T) ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      (∀ t≥0, x t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (x s)) ∧
      (∀ t≥0, c.stateEnergy t (x t)≤ c.cap ∧
        c.stateEnergy t (x t)≤ Real.exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-Real.exp (-2*c.κ*t))) ∧
      ∀ y : ℝ → MechanicalState, y 0=c.x₀ →
        (∀ T≥0, AbsolutelyContinuousOnInterval y 0 T) →
        (∀ᵐ t ∂volume, 0≤ t → HasDerivAt y (c.measurableField d t (y t)) t) →
        ∀ t≥0, y t=x t := by
  obtain ⟨u,Ku,huL,hu₀,huB,huI,huUnique⟩ := c.exists_unique_global_integral hκd hdm hdb
  obtain ⟨x,K,hxL,hx₀,hxD,hxB,hxE⟩ := c.exists_global_measurable_tracking hκd hdm hdb
  have hxAC : ∀ T≥0, AbsolutelyContinuousOnInterval x 0 T :=
    fun _ _ => hxL.lipschitzOnWith.absolutelyContinuousOnInterval
  have hxI := forward_ac_integral hx₀ hxAC hxD
  have hxu := huUnique x hxL.continuous (fun t ht => (hxI t ht).2)
  refine ⟨x,K,hxL,hx₀,hxAC,hxD,hxB,fun t ht => (hxI t ht).2,hxE,?_⟩
  intro y hy₀ hyAC hyD
  have hyI := forward_ac_integral hy₀ hyAC hyD
  let yext : ℝ → MechanicalState := fun t => y (max 0 t)
  have hyext : Continuous yext := locally_ac_forward_extension hyAC
  have hext (t : ℝ) (ht : 0≤ t) : yext t=y t := by simp [yext,max_eq_right ht]
  have hyextI (t : ℝ) (ht : 0≤ t) :
      yext t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (yext s) := by
    rw [hext t ht,(hyI t ht).2]
    congr 1
    apply intervalIntegral.integral_congr
    intro s hs
    rw [uIcc_of_le ht] at hs
    dsimp only
    rw [hext s hs.1]
  have hyu := huUnique yext hyext hyextI
  intro t ht
  rw [←hext t ht,hyu t ht,hxu t ht]

/-- The same unrestricted Caratheodory uniqueness for Lebesgue-a.e. measurable
inputs, retaining their original values in the a.e. ODE. -/
theorem GlobalTrackingData.exists_unique_global_aemeasurable_caratheodory (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : AEMeasurable d volume) (hdb : ∀ t, |d t|≤ c.dbar) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ T≥0, AbsolutelyContinuousOnInterval x 0 T) ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      (∀ t≥0, x t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (x s)) ∧
      (∀ t≥0, c.stateEnergy t (x t)≤ c.cap ∧
        c.stateEnergy t (x t)≤ Real.exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-Real.exp (-2*c.κ*t))) ∧
      ∀ y : ℝ → MechanicalState, y 0=c.x₀ →
        (∀ T≥0, AbsolutelyContinuousOnInterval y 0 T) →
        (∀ᵐ t ∂volume, 0≤ t → HasDerivAt y (c.measurableField d t (y t)) t) →
        ∀ t≥0, y t=x t := by
  have hb0 : 0≤ c.dbar := (abs_nonneg (d 0)).trans (hdb 0)
  have horder : -c.dbar≤ c.dbar := by linarith
  let b : ℝ → ℝ := fun t => max (-c.dbar) (min c.dbar (hdm.mk d t))
  have hbm : Measurable b := measurable_const.max (measurable_const.min hdm.measurable_mk)
  have hbb (t : ℝ) : |b t|≤ c.dbar := by
    apply abs_le.mpr
    exact ⟨le_max_left _ _,max_le horder (min_le_left _ _)⟩
  have heq : d =ᵐ[volume] b := by
    filter_upwards [hdm.ae_eq_mk] with t ht
    have hb := abs_le.mp (hdb t)
    simp only [b,← ht,min_eq_right hb.2,max_eq_right hb.1]
  obtain ⟨x,K,hxL,hx₀,hxAC,hxD,hxB,hxI,hxE,hunique⟩ :=
    c.exists_unique_global_caratheodory hκd hbm hbb
  have hxD' : ∀ᵐ t ∂volume, 0≤t → HasDerivAt x (c.measurableField d t (x t)) t := by
    filter_upwards [hxD,heq] with t ht he ht0
    simpa only [measurableField,measurableParameters,←he] using! ht ht0
  have hxI' := forward_ac_integral hx₀ hxAC hxD'
  refine ⟨x,K,hxL,hx₀,hxAC,hxD',hxB,fun t ht => (hxI' t ht).2,hxE,?_⟩
  intro y hy₀ hyAC hyD
  apply hunique y hy₀ hyAC
  filter_upwards [hyD,heq] with t ht he ht0
  simpa only [measurableField,measurableParameters,he] using! ht ht0

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.CaratheodoryCompletion -/

/- BEGIN SOURCE MODULE: ChainFountain.ACBarrier -/

namespace ChainFountain
noncomputable section
open Set Real Filter MeasureTheory
open scoped NNReal

/-- Scalar comparison for genuine absolutely continuous curves with an a.e.
differential inequality. Integrability and the reverse FTC are derived. -/
theorem scalar_comparison_ac {V V' : ℝ → ℝ} {T κ C : ℝ}
    (hκ : 0<κ) (hV : AbsolutelyContinuousOnInterval V 0 T)
    (hd : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt V (V' t) t)
    (hb : ∀ᵐ t ∂volume, t∈Ioo 0 T → V' t≤ -2*κ*V t+C) :
    ∀ t∈Icc 0 T, V t≤ envelope (V 0) κ C t := by
  by_cases hT : 0≤T
  swap
  · intro t ht
    linarith [ht.1,ht.2]
  let W (t : ℝ) := (V t-C/(2*κ))*exp (2*κ*t)
  let W' (t : ℝ) := (V' t+2*κ*(V t-C/(2*κ)))*exp (2*κ*t)
  have hWAC : AbsolutelyContinuousOnInterval W 0 T := by
    have he : ContDiff ℝ 1 (fun t : ℝ => exp (2*κ*t)) := by fun_prop
    obtain ⟨L,hL⟩ := smooth_comp_lipschitzOn he
      (LipschitzWith.id.lipschitzOnWith : LipschitzOnWith 1 (fun t : ℝ => t) (Icc 0 T))
    exact (hV.fun_sub ((LipschitzWith.const (C/(2*κ))).lipschitzOnWith.absolutelyContinuousOnInterval)).fun_mul
      (by rw [←uIcc_of_le hT] at hL; exact hL.absolutelyContinuousOnInterval)
  have hWd : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt W (W' t) t := by
    filter_upwards [hd] with t ht hmem
    convert! ((ht hmem).sub_const (C/(2*κ))).mul
      (((hasDerivAt_id t).const_mul (2*κ)).exp) using 1 <;> dsimp [W,W'] <;> ring
  have hWn : ∀ᵐ t ∂volume, t∈Ioo 0 T → W' t≤0 := by
    filter_upwards [hb] with t ht hmem
    have heq : 2*κ*(C/(2*κ))=C := by field_simp
    dsimp [W']
    apply mul_nonpos_of_nonpos_of_nonneg _ (exp_pos _).le
    nlinarith [ht hmem]
  intro t ht
  have hsub : Icc (0:ℝ) t ⊆ Icc 0 T := Icc_subset_Icc le_rfl ht.2
  have hsub' : uIcc (0:ℝ) t ⊆ uIcc 0 T := by
    rw [uIcc_of_le ht.1,uIcc_of_le (ht.1.trans ht.2)]
    exact hsub
  have hne (c : ℝ) : ∀ᵐ s ∂volume, s≠c := by simp [ae_iff,measure_singleton]
  have hWd' : ∀ᵐ s ∂volume, s∈uIcc 0 t → HasDerivAt W (W' s) s := by
    filter_upwards [hWd,hne 0,hne t] with s hs hs0 hst hmem
    rw [uIcc_of_le ht.1] at hmem
    exact hs ⟨lt_of_le_of_ne hmem.1 (Ne.symm hs0),(lt_of_le_of_ne hmem.2 hst).trans_le ht.2⟩
  obtain ⟨hi,hFTC⟩ := ac_integral_eq_sub (hWAC.mono hsub') hWd'
  have hint : (∫ s in (0:ℝ)..t, W' s)≤0 := by
    rw [intervalIntegral.integral_of_le ht.1]
    apply integral_nonpos_of_ae
    filter_upwards [ae_restrict_of_ae hWn,ae_restrict_of_ae (hne t),ae_restrict_mem measurableSet_Ioc] with s hs hst hmem
    exact hs ⟨hmem.1,(lt_of_le_of_ne hmem.2 hst).trans_le ht.2⟩
  have hw : W t≤W 0 := by linarith
  change W t≤ W 0 at hw
  dsimp [W] at hw
  simp only [mul_zero,exp_zero,mul_one] at hw
  have hdiv : V t-C/(2*κ) ≤ (V 0-C/(2*κ))/exp (2*κ*t) :=
    (le_div_iff₀ (exp_pos _)).mpr hw
  have heq : envelope (V 0) κ C t = C/(2*κ)+(V 0-C/(2*κ))/exp (2*κ*t) := by
    unfold envelope
    rw [show -2*κ*t=-(2*κ*t) by ring,exp_neg]
    ring
  rw [heq]
  linarith

/-- The feasible mechanical crown filter for arbitrary absolutely continuous
speed curves. This is a trajectory theorem, not filtered-loop existence. -/
theorem filtered_mechanical_crown_ac
    {H g β αlo αhi γ vmin uLo uHi T : ℝ}
    {h v w α desired : ℝ → ℝ}
    (hγ : 0<γ) (hα : αlo≤αhi)
    (hvL : AbsolutelyContinuousOnInterval v 0 T) (hwL : AbsolutelyContinuousOnInterval w 0 T)
    (hh : ∀ t∈Icc 0 T, 0<h t)
    (hcoef : ∀ t∈Icc 0 T, α t∈Icc αlo αhi)
    (hfeas : ∀ t∈Icc 0 T, max uLo (barrierLower αhi (v t))≤
      min uHi (barrierUpper H g β αlo (h t) (v t) (w t) γ ((v t+w t)/2-vmin)))
    (dv : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt v
      (rise g (α t) (h t) (v t) (w t)
        (filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t)) t)
    (dw : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt w (fall H g β (h t) (v t) (w t)) t) :
    ∀ t∈Icc 0 T,
      ((v 0+w 0)/2-vmin)*exp (-γ*t)≤(v t+w t)/2-vmin ∧
      uLo≤ filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t ∧
      filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t≤ uHi ∧
      0≤ pickup (α t) (v t) (filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t) := by
  let u := filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired
  let B := fun t => (v t+w t)/2-vmin
  have hclip (t : ℝ) (ht : t∈Icc 0 T) := clip_mem (desired:=desired t) (hfeas t ht)
  have hupper (t : ℝ) (ht : t∈Icc 0 T) :
      u t≤ barrierUpper H g β αlo (h t) (v t) (w t) γ (B t) :=
    (hclip t ht).2.trans (min_le_right _ _)
  have hcrown (t : ℝ) (ht : t∈Icc 0 T) :
      0≤(rise g (α t) (h t) (v t) (w t) (u t)+fall H g β (h t) (v t) (w t))/2+γ*B t :=
    ((crown_endpoint_iff (hh t ht) hα).mpr (hupper t ht)) (α t) (hcoef t ht)
  have hL : AbsolutelyContinuousOnInterval (fun t => -B t) 0 T := by
    have hc := (LipschitzWith.const vmin).lipschitzOnWith.absolutelyContinuousOnInterval (a:=0) (b:=T)
    have hm := AbsolutelyContinuousOnInterval.const_mul (1/2:ℝ) (hvL.fun_add hwL)
    simpa only [B,div_eq_mul_inv,mul_comm,one_mul,Pi.neg_apply] using! (hm.fun_sub hc).neg
  have hd : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt (fun s => -B s)
      (-((rise g (α t) (h t) (v t) (w t) (u t)+fall H g β (h t) (v t) (w t))/2)) t := by
    filter_upwards [dv,dw] with t ht hv hmem
    exact ((((ht hmem).add (hv hmem)).div_const 2).sub_const vmin).neg
  have hi := scalar_comparison_ac (κ:=γ/2) (C:=0) (by positivity) hL hd (by
    apply Eventually.of_forall
    intro t ht
    have hh := hcrown t (Ioo_subset_Icc_self ht)
    dsimp [B] at hh ⊢
    linarith)
  intro t ht
  refine ⟨?_,(le_max_left _ _).trans (hclip t ht).1,
    (hclip t ht).2.trans (min_le_left _ _),?_⟩
  · have hb := hi t ht
    dsimp [envelope] at hb
    have heq : -2*(γ/2)*t= -γ*t := by ring
    rw [heq] at hb
    simp only [zero_div,zero_mul,add_zero] at hb
    dsimp [B] at hb
    nlinarith
  · exact ((pickup_endpoint_iff hα).mpr ((le_max_right _ _).trans (hclip t ht).1))
      (α t) (hcoef t ht)

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.ACBarrier -/

/- BEGIN SOURCE MODULE: ChainFountain.ClassicalCaratheodory -/

namespace ChainFountain
noncomputable section
open Set Filter MeasureTheory
open scoped Topology NNReal

/-- Classical solutions from certified data are locally absolutely continuous.
The bound on the original vector field and first-exit safety supply regularity. -/
theorem GlobalTrackingData.classical_forward_ac (c : GlobalTrackingData)
    {x : ℝ → MechanicalState} (hx : x 0 = c.x₀)
    (hd : ∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) :
    ∀ T ≥ 0, AbsolutelyContinuousOnInterval x 0 T := by
  obtain ⟨L,C,hL,hcont,hC⟩ := c.field_bounds
  intro T hT
  have hb := c.classical_safe_on_Icc hT hx (fun t ht => hd t ht.1)
  have hl : LipschitzOnWith ⟨max C 0,le_max_right _ _⟩ x (Icc 0 T) := by
    rw [lipschitzOnWith_iff_norm_sub_le]
    intro s hs t ht
    refine (convex_Icc (0:ℝ) T).norm_image_sub_le_of_norm_hasDerivWithin_le
      (fun u (hu : u ∈ Icc 0 T) => (hd u hu.1).hasDerivWithinAt) ?_ ht hs
    intro u hu
    exact (hC u (x u) (interior_subset (c.safeBox_interior (hb u hu)))).trans
      (le_max_left C 0)
  rw [← uIcc_of_le hT] at hl
  exact hl.absolutelyContinuousOnInterval

/-- Unrestricted uniqueness of the continuous-data integral equation. The
nominal gain may vanish; the proof uses a safe reference solution, not robust
division by kappa_d and not safety assumed of the competitor. -/
theorem GlobalTrackingData.classical_integral_unique (c : GlobalTrackingData)
    {x y : ℝ → MechanicalState} (hx : Continuous x) (hy : Continuous y)
    (hxb : ∀ t ≥ 0, x t ∈ c.safeBox)
    (hxi : ∀ t ≥ 0, x t = c.x₀ + ∫ s in (0:ℝ)..t, c.field s (x s))
    (hyi : ∀ t ≥ 0, y t = c.x₀ + ∫ s in (0:ℝ)..t, c.field s (y s)) :
    ∀ t ≥ 0, y t = x t := by
  let d : ℝ → ℝ := fun t => c.d (max 0 t)
  have hdm : Measurable d := c.parameters_continuous.snd.snd.snd.measurable
  have hdb : ∀ t, |d t| ≤ c.dbar := fun t => c.disturbance_bound _ (le_max_left _ _)
  have hfield (t : ℝ) (z : MechanicalState) : c.measurableField d t z = c.field t z := rfl
  have hprefix (T : ℝ) (hT : 0 ≤ T) (hyB : ∀ t ∈ Icc 0 T, y t ∈ c.outerBox) :
      ∀ t ∈ Icc 0 T, y t = x t := by
    obtain ⟨v,hmin,hmax,hzero,hinit,hv⟩ := c.measurable_picard_data hdm hdb hT
    have mk (z : ℝ → MechanicalState)
        (hi : ∀ t ≥ 0, z t = c.x₀ + ∫ s in (0:ℝ)..t, c.field s (z s))
        (hb : ∀ t ∈ Icc 0 T, z t ∈ c.outerBox) :
        ∀ t ∈ Icc v.tMin v.tMax, z t = v.x₀ + ∫ s in (v.t₀:ℝ)..t, v s (z s) := by
      intro t ht
      rw [hmin,hmax] at ht
      rw [hinit,hzero,hi t ht.1]
      congr 1
      apply intervalIntegral.integral_congr
      intro s hs
      rw [uIcc_of_le ht.1] at hs
      dsimp only
      rw [hv,c.project_eq (z s) (hb s ⟨hs.1,hs.2.trans ht.2⟩),hfield]
    have hh := v.continuous_integral_unique hy hx (mk y hyi hyB)
      (mk x hxi (fun t ht => interior_subset (c.safeBox_interior (hxb t ht.1))))
    simpa only [hmin,hmax] using hh
  have hy₀ : y 0 = c.x₀ := by simpa using hyi 0 le_rfl
  have hystay := no_exit_of_prefix_bound hy
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    (hy₀ ▸ c.safeBox_interior c.initial_mem) (by
      intro T hT hb
      rw [hprefix T hT hb T ⟨hT,le_rfl⟩]
      exact hxb T hT)
  intro t ht
  exact hprefix t ht (fun s hs => interior_subset (c.safeBox_interior (hystay s hs.1)))
    t ⟨ht,le_rfl⟩

/-- The continuous-data tracking theorem, including kappa_d = 0, is unique
among all forward locally absolutely continuous a.e. mechanical solutions.
No prior existence, competitor state bounds, or negative-time regularity. -/
theorem GlobalTrackingData.exists_unique_classical_caratheodory (c : GlobalTrackingData) :
    ∃ x : ℝ → MechanicalState, x 0 = c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      (∀ T ≥ 0, AbsolutelyContinuousOnInterval x 0 T) ∧
      (∀ t ≥ 0, x t ∈ c.safeBox) ∧
      (c.dbar = 0 → ∀ t ≥ 0,
        c.stateEnergy t (x t) ≤ Real.exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀) ∧
      (0 < c.κd → ∀ t ≥ 0,
        c.stateEnergy t (x t) ≤ Real.exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-Real.exp (-2*c.κ*t))) ∧
      ∀ y : ℝ → MechanicalState, y 0 = c.x₀ →
        (∀ T ≥ 0, AbsolutelyContinuousOnInterval y 0 T) →
        (∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt y (c.field t (y t)) t) →
        ∀ t ≥ 0, y t = x t := by
  obtain ⟨x,hx,hd,hb,hn,hr⟩ := c.exists_global_tracking
  have hac := c.classical_forward_ac hx hd
  have hxi := forward_ac_integral hx hac (Eventually.of_forall hd)
  refine ⟨x,hx,hd,hac,hb,hn,hr,?_⟩
  intro y hy hyAC hyD
  have hyi := forward_ac_integral hy hyAC hyD
  have ext (z : ℝ → MechanicalState)
      (hi : ∀ t ≥ 0, z t = c.x₀ + ∫ s in (0:ℝ)..t, c.field s (z s)) :
      ∀ t ≥ 0, z (max 0 t) = c.x₀ + ∫ s in (0:ℝ)..t, c.field s (z (max 0 s)) := by
    intro t ht
    rw [max_eq_right ht,hi t ht]
    congr 1
    apply intervalIntegral.integral_congr
    intro s hs
    rw [uIcc_of_le ht] at hs
    simp only [max_eq_right hs.1]
  have heq := c.classical_integral_unique
    (locally_ac_forward_extension hac) (locally_ac_forward_extension hyAC)
    (fun t ht => by simpa [max_eq_right ht] using hb t ht)
    (ext x (fun t ht => (hxi t ht).2)) (ext y (fun t ht => (hyi t ht).2))
  intro t ht
  simpa only [max_eq_right ht] using heq t ht

end
end ChainFountain
/- END SOURCE MODULE: ChainFountain.ClassicalCaratheodory -/

/- BEGIN SOURCE MODULE: ChainFountain.ZeroGravityOpen -/

/-!
# The zero-gravity open-chain obstruction

These results concern the existing two-leg, fixed-height-offset model with g = 0.
They are statements about that model, not a model of an arbitrary free chain.
The physical interval hypotheses are explicit: the momentum obstruction does
not assert a particular exit time or an extension through zero leg length.
-/
namespace ChainFountain
namespace ZeroGravity
noncomputable section
open Set Real

/-- Falling-leg momentum divided by the constant linear density. -/
def fallingMomentum (H h w : ℝ) : ℝ := (H + h) * w

/-- The old positive-speed lower-face condition cannot hold at zero gravity. -/
theorem lower_face_impossible {β w Q : ℝ}
    (hβ : β < 1) (hw : 0 < w) (hQ : 0 ≤ Q) :
    ¬ (0 ≥ (1 - β) * w ^ 2 + 2 * Q * w + Q ^ 2) := by
  have h1 : 0 < (1 - β) * w ^ 2 := mul_pos (by linarith) (sq_pos_of_pos hw)
  have h2 : 0 ≤ 2 * Q * w := by positivity
  nlinarith [sq_nonneg Q]

/-- Exact cancellation of the controlled rising-leg acceleration from P'. -/
theorem falling_momentum_rate (H β h v w : ℝ) (hden : H + h ≠ 0) :
    heightRate v w * w + (H + h) * fall H 0 β h v w =
      -(v ^ 2) / 4 - (3 / 4 - β) * w ^ 2 := by
  unfold heightRate fall crownSq
  field_simp
  <;> ring

/-- Genuine derivative of falling-leg momentum along a classical trajectory. -/
theorem falling_momentum_hasDerivAt {H β t : ℝ} {h v w : ℝ → ℝ}
    (hden : H + h t ≠ 0)
    (dh : HasDerivAt h (heightRate (v t) (w t)) t)
    (dw : HasDerivAt w (fall H 0 β (h t) (v t) (w t)) t) :
    HasDerivAt (fun τ => fallingMomentum H (h τ) (w τ))
      (-(v t ^ 2) / 4 - (3 / 4 - β) * w t ^ 2) t := by
  have hd := (dh.const_add H).mul dw
  convert! hd using 1
  exact (falling_momentum_rate H β (h t) (v t) (w t) hden).symm

/-- Dissipation dominates one half of the squared crown speed. -/
theorem falling_momentum_rate_le {β v w : ℝ} (hβ : β ≤ 1 / 2) :
    -(v ^ 2) / 4 - (3 / 4 - β) * w ^ 2 ≤ -crownSq v w / 2 := by
  have hb := mul_nonneg (sub_nonneg.mpr hβ) (sq_nonneg w)
  unfold crownSq
  nlinarith [sq_nonneg (v - w)]

/-- A classical derivative inequality gives the affine momentum bound. -/
theorem momentum_affine_bound {P P' : ℝ → ℝ} {T a : ℝ}
    (hc : ContinuousOn P (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt P (P' t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, P' t ≤ -a) :
    ∀ t ∈ Icc 0 T, P t ≤ P 0 - a * t := by
  have hg := le_gronwallBound_of_liminf_deriv_right_le hc
    (fun t ht _ hr => (hd t ht).liminf_right_slope_le hr)
    (le_refl (P 0)) (K := 0) (ε := -a)
    (by intro t ht; simpa using hb t ht)
  intro t ht
  have h := hg t ht
  simp [gronwallBound] at h
  linarith

/-- Positive momentum and a positive crown-speed margin bound the interval.
The conclusion is a strict upper bound, not a claimed exact exit time. -/
theorem positive_margin_time_bound {H β T smin : ℝ} {h v w : ℝ → ℝ}
    (hT : 0 ≤ T) (hβ : β ≤ 1 / 2) (hs : 0 < smin)
    (dh : ∀ t ∈ Icc 0 T, HasDerivAt h (heightRate (v t) (w t)) t)
    (dw : ∀ t ∈ Icc 0 T, HasDerivAt w (fall H 0 β (h t) (v t) (w t)) t)
    (hden : ∀ t ∈ Icc 0 T, 0 < H + h t)
    (hw : ∀ t ∈ Icc 0 T, 0 < w t)
    (hmargin : ∀ t ∈ Icc 0 T, smin ≤ (v t + w t) / 2) :
    T < 2 * fallingMomentum H (h 0) (w 0) / smin ^ 2 := by
  let P := fun t => fallingMomentum H (h t) (w t)
  let D := fun t => -(v t ^ 2) / 4 - (3 / 4 - β) * w t ^ 2
  have hd : ∀ t ∈ Icc 0 T, HasDerivAt P (D t) t := by
    intro t ht
    exact falling_momentum_hasDerivAt (ne_of_gt (hden t ht)) (dh t ht) (dw t ht)
  have hc : ContinuousOn P (Icc 0 T) := fun t ht => (hd t ht).continuousAt.continuousWithinAt
  have hb : ∀ t ∈ Ico 0 T, D t ≤ -(smin ^ 2 / 2) := by
    intro t ht
    have hr := falling_momentum_rate_le (v := v t) (w := w t) hβ
    have hm := hmargin t (Ico_subset_Icc_self ht)
    have hsq : smin ^ 2 ≤ crownSq (v t) (w t) := by
      unfold crownSq
      nlinarith
    dsimp [D]
    linarith
  have ht := momentum_affine_bound hc
    (fun t ht => (hd t (Ico_subset_Icc_self ht)).hasDerivWithinAt) hb T ⟨hT, le_rfl⟩
  have hp : 0 < P T := mul_pos (hden T ⟨hT, le_rfl⟩) (hw T ⟨hT, le_rfl⟩)
  have hsq : 0 < smin ^ 2 := sq_pos_of_pos hs
  apply (lt_div_iff₀ hsq).mpr
  dsimp [P] at ht hp ⊢
  nlinarith

/-- No global classical trajectory can retain the positive crown margin and
positive falling-leg momentum in the same open geometry. -/
theorem global_positive_margin_impossible {H β smin : ℝ} {h v w : ℝ → ℝ}
    (hβ : β ≤ 1 / 2) (hs : 0 < smin)
    (dh : ∀ t, 0 ≤ t → HasDerivAt h (heightRate (v t) (w t)) t)
    (dw : ∀ t, 0 ≤ t → HasDerivAt w (fall H 0 β (h t) (v t) (w t)) t)
    (hden : ∀ t, 0 ≤ t → 0 < H + h t)
    (hw : ∀ t, 0 ≤ t → 0 < w t)
    (hmargin : ∀ t, 0 ≤ t → smin ≤ (v t + w t) / 2) : False := by
  let T := 2 * fallingMomentum H (h 0) (w 0) / smin ^ 2
  have hP : 0 < fallingMomentum H (h 0) (w 0) :=
    mul_pos (hden 0 le_rfl) (hw 0 le_rfl)
  have hT : 0 ≤ T := by dsimp [T]; positivity
  have hb := positive_margin_time_bound hT hβ hs
    (fun t ht => dh t ht.1) (fun t ht => dw t ht.1)
    (fun t ht => hden t ht.1) (fun t ht => hw t ht.1)
    (fun t ht => hmargin t ht.1)
  exact (lt_irrefl T) hb

/-- The open two-leg model has no equilibrium with positive transport speed. -/
theorem no_positive_flow_equilibrium {H β h v w : ℝ}
    (hden : H + h ≠ 0) (hβ : β < 1) (hw : 0 < w)
    (hh : heightRate v w = 0) : fall H 0 β h v w ≠ 0 := by
  have hv : v = w := by unfold heightRate at hh; linarith
  subst v
  have hc : crownSq w w = w ^ 2 := by unfold crownSq; ring
  unfold fall
  rw [hc, zero_add]
  apply div_ne_zero _ hden
  have hp := mul_pos (show 0 < 1 - β by linarith) (sq_pos_of_pos hw)
  nlinarith

/-- Constant-height decay coefficient. -/
def decayRate (H β r : ℝ) : ℝ := (1 - β) / (H + r)

def decaySpeed (c w₀ t : ℝ) : ℝ := w₀ / (1 + c * w₀ * t)

theorem decayRate_pos {H β r : ℝ} (hden : 0 < H + r) (hβ : β < 1) :
    0 < decayRate H β r := div_pos (by linarith) hden

theorem decaySpeed_pos {c w₀ t : ℝ} (hc : 0 < c) (hw : 0 < w₀) (ht : 0 ≤ t) :
    0 < decaySpeed c w₀ t := by
  unfold decaySpeed
  positivity

theorem decaySpeed_initial (c w₀ : ℝ) : decaySpeed c w₀ 0 = w₀ := by
  simp [decaySpeed]

/-- The rational decay formula solves the quadratic scalar decay equation. -/
theorem decaySpeed_hasDerivAt {c w₀ t : ℝ} (hden : 1 + c * w₀ * t ≠ 0) :
    HasDerivAt (decaySpeed c w₀) (-c * decaySpeed c w₀ t ^ 2) t := by
  have hd := (hasDerivAt_const t w₀).div
    (((hasDerivAt_id t).const_mul (c * w₀)).const_add 1) hden
  convert! hd using 1 <;> dsimp [decaySpeed]
  field_simp
  <;> ring

/-- A compatible input makes both leg accelerations equal to quadratic decay. -/
theorem constant_height_vector_field (H α β r w : ℝ)
    (hr : r ≠ 0) (hden : H + r ≠ 0) :
    heightRate w w = 0 ∧
    rise 0 α r w w ((α + r * decayRate H β r) * w ^ 2) =
      -decayRate H β r * w ^ 2 ∧
    fall H 0 β r w w = -decayRate H β r * w ^ 2 := by
  refine ⟨by simp [heightRate], ?_, ?_⟩
  · unfold rise crownSq decayRate
    field_simp
    <;> ring
  · unfold fall crownSq decayRate
    field_simp
    <;> ring

/-- The explicit rational speed and compatible input solve all three original
zero-gravity plant equations at every nonsingular time. -/
theorem constant_height_solution {H α β r w₀ t : ℝ}
    (hr : r ≠ 0) (hden : H + r ≠ 0)
    (hdec : 1 + decayRate H β r * w₀ * t ≠ 0) :
    let c := decayRate H β r
    let speed := decaySpeed c w₀
    let input := (α + r * c) * speed t ^ 2
    HasDerivAt (fun _ : ℝ => r) (heightRate (speed t) (speed t)) t ∧
    HasDerivAt speed (rise 0 α r (speed t) (speed t) input) t ∧
    HasDerivAt speed (fall H 0 β r (speed t) (speed t)) t := by
  dsimp only
  have hv := constant_height_vector_field H α β r (decaySpeed (decayRate H β r) w₀ t) hr hden
  refine ⟨?_, ?_, ?_⟩
  · rw [hv.1]
    exact hasDerivAt_const t r
  · rw [hv.2.1]
    exact decaySpeed_hasDerivAt hdec
  · rw [hv.2.2]
    exact decaySpeed_hasDerivAt hdec

/-- Zero gravity removes the positive gravitational power supply exactly. -/
theorem energy_balance_zeroGravity (H lam α β h v w u : ℝ)
    (hh : h ≠ 0) (hH : H + h ≠ 0) :
    lam / 2 * (heightRate v w * v ^ 2 + h * (2 * v * rise 0 α h v w u) +
      heightRate v w * w ^ 2 + (H + h) * (2 * w * fall H 0 β h v w)) =
      -lam * (1 / 2 - α) * v ^ 3 - lam * (1 / 2 - β) * w ^ 3 - lam * u * v := by
  simpa using energy_balance H 0 lam α β h v w u hh hH

end
end ZeroGravity
end ChainFountain
/- END SOURCE MODULE: ChainFountain.ZeroGravityOpen -/

/- BEGIN SOURCE MODULE: ChainFountain.ZeroGravityCirculation -/

/-!
# Driven circulation of a closed chain in zero gravity

The scalar plant describes distributed tangential actuation and homogeneous
linear tangential drag. It is a different geometry from the open fountain.
The results below concern circulation speed; no transverse shape stability is
asserted. Classical derivative hypotheses are explicit.
-/

namespace ChainFountain.ZeroGravity
noncomputable section
open Set Real

/-- Signed scalar Gronwall envelope used only by this zero-gravity module. -/
def scalarEnvelope (V0 κ C t : ℝ) : ℝ :=
  exp (-2 * κ * t) * V0 + C / (2 * κ) * (1 - exp (-2 * κ * t))

/-- Genuine-derivative scalar comparison, proved directly from Gronwall. -/
theorem scalarComparison {V V' : ℝ → ℝ} {T κ C : ℝ} (hκ : 0 < κ)
    (hc : ContinuousOn V (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt V (V' t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, V' t ≤ -2 * κ * V t + C) :
    ∀ t ∈ Icc 0 T, V t ≤ scalarEnvelope (V 0) κ C t := by
  have hG := le_gronwallBound_of_liminf_deriv_right_le hc
    (fun t ht _ hr => (hd t ht).liminf_right_slope_le hr) (le_refl (V 0)) hb
  intro t ht
  have h := hG t ht
  rw [gronwallBound, ite_eq_right (by nlinarith : -2 * κ ≠ 0), sub_zero] at h
  unfold scalarEnvelope
  convert! h using 1
  ring

/-- The scalar envelope stays below a common cap on its endpoint amplitudes. -/
theorem scalarEnvelope_below_cap {V0 κ C cap t : ℝ}
    (hκ : 0 < κ) (ht : 0 ≤ t) (hV : V0 ≤ cap) (hC : C / (2 * κ) ≤ cap) :
    scalarEnvelope V0 κ C t ≤ cap := by
  have he0 : 0 ≤ exp (-2 * κ * t) := (exp_pos _).le
  have he1 : exp (-2 * κ * t) ≤ 1 := exp_le_one_iff.mpr (by nlinarith)
  have h1 := mul_le_mul_of_nonneg_left hV he0
  have h2 := mul_le_mul_of_nonneg_right hC (sub_nonneg.mpr he1)
  unfold scalarEnvelope
  nlinarith

/-- Tangential acceleration command, including reference feedforward. -/
def circulationCommand (γ k r rdot c : ℝ) : ℝ :=
  rdot + γ * r - k * (c - r)

/-- Exact cancellation for the tangential scalar plant. -/
theorem circulation_error_identity (γ k r rdot c d : ℝ) :
    circulationCommand γ k r rdot c - γ * c + d - rdot =
      -(γ + k) * (c - r) + d := by
  unfold circulationCommand
  ring

/-!
The feedback in the user's proposed command cancels drag at the reference,
so its actual error damping is γ+k. Using γ*c instead would give damping k.
Both forms have the same reference-tracking objective but different error
rates; the theorem records the actual rate rather than silently changing it.
-/

/-- Exact drag cancellation, when feedback compensation uses measured speed. -/
def circulationCompensatedCommand (γ k r rdot c : ℝ) : ℝ :=
  rdot + γ * c - k * (c - r)

theorem circulation_compensated_error_identity (γ k r rdot c d : ℝ) :
    circulationCompensatedCommand γ k r rdot c - γ * c + d - rdot =
      -k * (c - r) + d := by
  unfold circulationCompensatedCommand
  ring

/-- The reference-drag feedforward controller yields damping γ+k. -/
theorem circulation_error_hasDerivAt {c r : ℝ → ℝ} {γ k rdot d t : ℝ}
    (hc : HasDerivAt c
      (circulationCommand γ k (r t) rdot (c t) - γ * c t + d) t)
    (hr : HasDerivAt r rdot t) :
    HasDerivAt (fun s => c s - r s) (-(γ + k) * (c t - r t) + d) t := by
  convert! hc.sub hr using 1
  exact (circulation_error_identity γ k (r t) rdot (c t) d).symm

/-- Exponential envelope of a scalar stable equation with bounded forcing. -/
def circulationEnvelope (e0 a D t : ℝ) : ℝ :=
  exp (-a * t) * |e0| + D / a * (1 - exp (-a * t))

/-- Sharp scalar comparison, without differentiating the absolute value. -/
theorem circulation_error_bound {e d : ℝ → ℝ} {a D T : ℝ}
    (ha : 0 < a)
    (hc : ContinuousOn e (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T,
      HasDerivWithinAt e (-a * e t + d t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, |d t| ≤ D) :
    ∀ t ∈ Icc 0 T, |e t| ≤ circulationEnvelope (e 0) a D t := by
  have hu := scalarComparison (κ := a / 2) (C := D) (by linarith) hc hd
    (by intro t ht; linarith [(abs_le.mp (hb t ht)).2])
  have hl := scalarComparison (V := fun t => -e t)
    (V' := fun t => -(-a * e t + d t))
    (κ := a / 2) (C := D) (by linarith) hc.neg
    (fun t ht => (hd t ht).neg)
    (by intro t ht; nlinarith [(abs_le.mp (hb t ht)).1])
  intro t ht
  have hup := hu t ht
  have hlo := hl t ht
  have hpos := exp_pos (-a * t)
  have he1 : e 0 ≤ |e 0| := le_abs_self _
  have he2 : -e 0 ≤ |e 0| := neg_le_abs _
  have hup0 := mul_le_mul_of_nonneg_left he1 hpos.le
  have hlo0 := mul_le_mul_of_nonneg_left he2 hpos.le
  have hhalf : 2 * (a / 2) = a := by ring
  have hneg : -2 * (a / 2) * t = -a * t := by ring
  simp only [scalarEnvelope, hhalf, hneg] at hup hlo
  try dsimp only [Pi.neg_apply, Pi.sub_apply, Pi.add_apply, Pi.mul_apply, Pi.pow_apply] at hlo
  unfold circulationEnvelope
  exact abs_le.mpr ⟨by nlinarith, by nlinarith⟩

/-- The envelope is a convex combination of the initial error and D/a. -/
theorem circulation_envelope_below_max {e0 a D t : ℝ}
    (ha : 0 < a) (ht : 0 ≤ t) :
    circulationEnvelope e0 a D t ≤ max |e0| (D / a) := by
  have hhalf : 2 * (a / 2) = a := by ring
  have hneg : -2 * (a / 2) * t = -a * t := by ring
  have h := scalarEnvelope_below_cap (κ := a / 2) (V0 := |e0|) (C := D)
    (cap := max |e0| (D / a)) (by linarith) ht (le_max_left _ _)
    (by rw [hhalf]; exact le_max_right _ _)
  simpa only [circulationEnvelope, scalarEnvelope, hhalf, hneg] using h

/-- Exact exponential decay, including its sign, for the unforced equation. -/
theorem circulation_nominal_solution {e : ℝ → ℝ} {a T : ℝ}
    (ha : 0 < a)
    (hc : ContinuousOn e (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T,
      HasDerivWithinAt e (-a * e t) (Ici t) t) :
    ∀ t ∈ Icc 0 T, e t = exp (-a * t) * e 0 := by
  have hu := scalarComparison (κ := a / 2) (C := 0) (by linarith) hc hd
    (by intro t ht; ring_nf; exact le_rfl)
  have hl := scalarComparison (V := fun t => -e t)
    (V' := fun t => -(-a * e t))
    (κ := a / 2) (C := 0) (by linarith) hc.neg
    (fun t ht => (hd t ht).neg)
    (by intro t ht; nlinarith)
  intro t ht
  have hup := hu t ht
  have hlo := hl t ht
  have hneg : -2 * (a / 2) * t = -a * t := by ring
  simp only [scalarEnvelope, hneg, zero_div, zero_mul, add_zero] at hup hlo
  try dsimp only [Pi.neg_apply, Pi.sub_apply, Pi.add_apply, Pi.mul_apply, Pi.pow_apply] at hlo
  linarith

/-- A speed reference uniformly above the worst tracking error keeps circulation
strictly positive throughout every interval where the scalar equation holds. -/
theorem circulation_positive {c r d : ℝ → ℝ} {a D T rmin : ℝ}
    (ha : 0 < a)
    (hc : ContinuousOn (fun t => c t - r t) (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt (fun s => c s - r s)
      (-a * (c t - r t) + d t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, |d t| ≤ D)
    (hr : ∀ t ∈ Icc 0 T, rmin ≤ r t)
    (hmargin : max |c 0 - r 0| (D / a) < rmin) :
    ∀ t ∈ Icc 0 T, 0 < c t := by
  intro t ht
  have herr := (circulation_error_bound ha hc hd hb t ht).trans
    (circulation_envelope_below_max ha ht.1)
  have hlo := (abs_le.mp herr).1
  have href := hr t ht
  try dsimp only [Pi.neg_apply, Pi.sub_apply, Pi.add_apply, Pi.mul_apply, Pi.pow_apply] at hlo
  linarith

/-- Closed-loop robust estimate connected directly to plant derivatives. -/
theorem circulation_closedLoop_bound {c r rdot d : ℝ → ℝ} {γ k D T : ℝ}
    (ha : 0 < γ + k)
    (hc : ∀ t ∈ Icc 0 T, HasDerivAt c
      (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) t)
    (hr : ∀ t ∈ Icc 0 T, HasDerivAt r (rdot t) t)
    (hb : ∀ t ∈ Ico 0 T, |d t| ≤ D) :
    ∀ t ∈ Icc 0 T,
      |c t - r t| ≤ circulationEnvelope (c 0 - r 0) (γ + k) D t := by
  have hd := fun t ht => circulation_error_hasDerivAt (hc t ht) (hr t ht)
  exact circulation_error_bound ha
    (fun t ht => (hd t ht).continuousAt.continuousWithinAt)
    (fun t ht => (hd t (Ico_subset_Icc_self ht)).hasDerivWithinAt) hb

/-- Explicit global nominal closed-loop speed, with arbitrary smooth reference. -/
def circulationNominalPath (r : ℝ → ℝ) (a e0 t : ℝ) : ℝ :=
  r t + e0 * exp (-a * t)

theorem circulation_nominal_path_hasDerivAt {r : ℝ → ℝ}
    {γ k e0 rdot t : ℝ} (hr : HasDerivAt r rdot t) :
    HasDerivAt (circulationNominalPath r (γ + k) e0)
      (circulationCommand γ k (r t) rdot
        (circulationNominalPath r (γ + k) e0 t) -
        γ * circulationNominalPath r (γ + k) e0 t) t := by
  have hd := hr.add ((((hasDerivAt_id t).const_mul (-(γ + k))).exp).const_mul e0)
  convert! hd using 1
  simp only [circulationNominalPath, circulationCommand, id_eq]
  ring

/-- Constructive global nominal existence for every differentiable reference.
This conclusion is not conditional on a previously supplied speed trajectory. -/
theorem circulation_nominal_global_exists {r rdot : ℝ → ℝ} {γ k c0 : ℝ}
    (hr : ∀ t ∈ Ici 0, HasDerivAt r (rdot t) t) :
    ∃ c : ℝ → ℝ, c 0 = c0 ∧ ∀ t ∈ Ici 0,
      HasDerivAt c (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t) t := by
  refine ⟨circulationNominalPath r (γ + k) (c0 - r 0), ?_, ?_⟩
  · simp [circulationNominalPath]
  · intro t ht
    exact circulation_nominal_path_hasDerivAt (hr t ht)

/-- Variation-of-constants solution for continuous distributed disturbances. -/
def circulationForcedError (d : ℝ → ℝ) (a e0 t : ℝ) : ℝ :=
  exp (-a * t) * (e0 + ∫ s in (0 : ℝ)..t, exp (a * s) * d s)

theorem circulation_forced_error_hasDerivAt {d : ℝ → ℝ} {a e0 t : ℝ}
    (hd : Continuous d) :
    HasDerivAt (circulationForcedError d a e0)
      (-a * circulationForcedError d a e0 t + d t) t := by
  have hf : Continuous (fun s => exp (a * s) * d s) :=
    (Real.continuous_exp.comp (continuous_const.mul continuous_id)).mul hd
  have hI := intervalIntegral.integral_hasDerivAt_right
    (hf.intervalIntegrable 0 t) hf.aestronglyMeasurable.stronglyMeasurableAtFilter
    hf.continuousAt
  have hE := (((hasDerivAt_id t).const_mul (-a)).exp).mul (hI.const_add e0)
  have hexp : exp (-a * t) * exp (a * t) = 1 := by
    rw [← exp_add]
    rw [show -a * t + a * t = 0 by ring, exp_zero]
  have hcancel := congrArg (fun x : ℝ => x * d t) hexp
  convert! hE using 1
  unfold circulationForcedError
  simp only [id_eq] at *
  nlinarith

/-- Constructive global existence under continuous disturbance; no trajectory
is assumed. For merely measurable forcing the classical conclusion here is
not asserted. -/
theorem circulation_forced_global_exists {r rdot d : ℝ → ℝ} {γ k c0 : ℝ}
    (hr : ∀ t ∈ Ici 0, HasDerivAt r (rdot t) t) (hd : Continuous d) :
    ∃ c : ℝ → ℝ, c 0 = c0 ∧ ∀ t ∈ Ici 0,
      HasDerivAt c
        (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) t := by
  let e := circulationForcedError d (γ + k) (c0 - r 0)
  refine ⟨fun t => r t + e t, ?_, ?_⟩
  · simp [e, circulationForcedError]
  · intro t ht
    have he := circulation_forced_error_hasDerivAt
      (a := γ + k) (e0 := c0 - r 0) (t := t) hd
    convert! (hr t ht).add he using 1
    simp only [e, circulationCommand]
    ring

/-- Uniqueness for the forced scalar equation, proved by exact decay of the
difference. Continuity of the forcing is not required once derivatives exist. -/
theorem circulation_scalar_unique {c1 c2 f : ℝ → ℝ} {a T : ℝ}
    (ha : 0 < a) (hinit : c1 0 = c2 0)
    (h1 : ∀ t ∈ Icc 0 T, HasDerivAt c1 (-a * c1 t + f t) t)
    (h2 : ∀ t ∈ Icc 0 T, HasDerivAt c2 (-a * c2 t + f t) t) :
    ∀ t ∈ Icc 0 T, c1 t = c2 t := by
  have hd : ∀ t ∈ Icc 0 T,
      HasDerivAt (fun s => c1 s - c2 s) (-a * (c1 t - c2 t)) t := by
    intro t ht
    convert! (h1 t ht).sub (h2 t ht) using 1
    ring
  have hb := circulation_nominal_solution ha
    (fun t ht => (hd t ht).continuousAt.continuousWithinAt)
    (fun t ht => (hd t (Ico_subset_Icc_self ht)).hasDerivWithinAt)
  intro t ht
  have he := hb t ht
  try dsimp only [Pi.neg_apply, Pi.sub_apply, Pi.add_apply, Pi.mul_apply, Pi.pow_apply] at he
  rw [hinit, sub_self, mul_zero] at he
  exact sub_eq_zero.mp he

/-- A two-sided reference bound and the tracking error bound control tension. -/
theorem circulation_tension_upper {lam c r rmax ρ : ℝ}
    (hlam : 0 ≤ lam) (hc : 0 ≤ c) (hr : r ≤ rmax)
    (he : |c - r| ≤ ρ) :
    lam * c^2 ≤ lam * (rmax + ρ)^2 := by
  have hb : c ≤ rmax + ρ := by linarith [(abs_le.mp he).2]
  have hs : c^2 ≤ (rmax + ρ)^2 := by
    nlinarith [mul_nonneg (sub_nonneg.mpr hb) (show 0 ≤ rmax + ρ + c by linarith)]
  exact mul_le_mul_of_nonneg_left hs hlam

/-- A sufficient command magnitude bound for an unsaturated actuator. -/
theorem circulation_command_bound {γ k r rdot c A rmax ρ : ℝ}
    (hγ : 0 ≤ γ) (hk : 0 ≤ k) (hr0 : 0 ≤ r) (hr : r ≤ rmax)
    (hrdot : |rdot| ≤ A) (he : |c - r| ≤ ρ) :
    |circulationCommand γ k r rdot c| ≤ A + γ * rmax + k * ρ := by
  have htri := (abs_sub (rdot + γ * r) (k * (c - r))).trans
    (add_le_add (abs_add_le rdot (γ * r)) (le_refl _))
  have hdrag := mul_le_mul_of_nonneg_left hr hγ
  have hfeedback := mul_le_mul_of_nonneg_left he hk
  rw [abs_of_nonneg (mul_nonneg hγ hr0), abs_mul, abs_of_nonneg hk] at htri
  unfold circulationCommand
  linarith

/-! ## Reconstruction of the moving closed string

The following chain rules are valid in any real normed vector space. A periodic
unit-speed curve gives a closed inextensible chain. The balance is exact for
uniform tension lam c² and distributed tangential acceleration u−γc+d. The
result does not assert stability to perturbations outside this ansatz.
-/

section StringReconstruction
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- Material velocity of the traveling-shape ansatz. -/
theorem loop_position_hasDerivAt {R : ℝ → E} {θ : ℝ → ℝ}
    {R1 : E} {c a t : ℝ}
    (hR : HasDerivAt R R1 (a + θ t)) (hθ : HasDerivAt θ c t) :
    HasDerivAt (fun s => R (a + θ s)) (c • R1) t := by
  simpa only [Function.comp_def] using! hR.scomp t (hθ.const_add a)

/-- Material acceleration: curvature acceleration plus tangential acceleration. -/
theorem loop_velocity_hasDerivAt {R1 : ℝ → E} {θ c : ℝ → ℝ}
    {R2 : E} {cdot a t : ℝ}
    (hR1 : HasDerivAt R1 R2 (a + θ t))
    (hθ : HasDerivAt θ (c t) t) (hc : HasDerivAt c cdot t) :
    HasDerivAt (fun s => c s • R1 (a + θ s))
      ((c t)^2 • R2 + cdot • R1 (a + θ t)) t := by
  have h := hc.smul (hR1.scomp t (hθ.const_add a))
  simpa only [Function.comp_def, Pi.smul_apply, smul_smul, pow_two] using! h

/-- Spatial derivative of a uniform tension field times the tangent. -/
theorem loop_stress_hasDerivAt {R1 : ℝ → E} {θ c : ℝ → ℝ}
    {R2 : E} {lam a t : ℝ}
    (hR1 : HasDerivAt R1 R2 (a + θ t)) :
    HasDerivAt (fun b => (lam * (c t)^2) • R1 (b + θ t))
      ((lam * (c t)^2) • R2) a := by
  have h := (hR1.scomp a ((hasDerivAt_id a).add_const (θ t))).const_smul
    (lam * (c t)^2)
  simpa only [Function.comp_def, id_eq, Pi.smul_apply, one_smul] using! h

/-- Exact continuum momentum balance, using actual second time derivatives
and actual spatial derivatives. Uniform tension is lam*c². -/
theorem loop_continuum_balance {R R1 : ℝ → E} {θ c : ℝ → ℝ}
    {R2 : E} {lam γ u d a t : ℝ} (hlam : lam ≠ 0)
    (hR : ∀ x, HasDerivAt R (R1 x) x)
    (hR1 : HasDerivAt R1 R2 (a + θ t))
    (hθ : ∀ s, HasDerivAt θ (c s) s)
    (hc : HasDerivAt c (u - γ * c t + d) t) :
    deriv (fun τ => deriv (fun s => R (a + θ s)) τ) t =
      (1 / lam) • deriv
        (fun b => (lam * (c t)^2) • deriv (fun z => R (z + θ t)) b) a +
      (u - γ * c t + d) • deriv (fun z => R (z + θ t)) a := by
  have htime : (fun τ => deriv (fun s => R (a + θ s)) τ) =
      (fun τ => c τ • R1 (a + θ τ)) := by
    funext τ
    exact (loop_position_hasDerivAt (hR _) (hθ τ)).deriv
  have hspace : deriv (fun z => R (z + θ t)) =
      (fun b => R1 (b + θ t)) := by
    funext b
    have h := (hR (b + θ t)).scomp b ((hasDerivAt_id b).add_const (θ t))
    simpa only [Function.comp_def, id_eq, one_smul] using! h.deriv
  rw [htime, hspace,
    (loop_velocity_hasDerivAt hR1 (hθ t) hc).deriv,
    (loop_stress_hasDerivAt (lam := lam) hR1).deriv]
  have hscalar : 1 / lam * (lam * (c t)^2) = (c t)^2 := by field_simp
  rw [smul_smul, hscalar]

/-- Unit-speed shape parameterization implies material inextensibility. -/
theorem loop_inextensible {R R1 : ℝ → E} {θ : ℝ → ℝ} {a t : ℝ}
    (hR : HasDerivAt R (R1 (a + θ t)) (a + θ t))
    (hunit : ‖R1 (a + θ t)‖ = 1) :
    ‖deriv (fun z => R (z + θ t)) a‖ = 1 := by
  have h := hR.scomp a ((hasDerivAt_id a).add_const (θ t))
  have hd : deriv (fun z => R (z + θ t)) a = R1 (a + θ t) := by
    simpa only [Function.comp_def, id_eq, one_smul] using! h.deriv
  rw [hd, hunit]

omit [NormedAddCommGroup E] [NormedSpace ℝ E] in
/-- A periodic shape remains closed under every phase shift. -/
theorem loop_periodic {R : ℝ → E} {θ : ℝ → ℝ} {L t : ℝ}
    (hR : Function.Periodic R L) :
    Function.Periodic (fun a => R (a + θ t)) L := by
  intro a
  change R (a + L + θ t) = R (a + θ t)
  rw [show a + L + θ t = (a + θ t) + L by ring]
  exact hR (a + θ t)

/-- Positive density and positive circulation produce positive tension. -/
theorem loop_tension_positive {lam c : ℝ} (hlam : 0 < lam) (hc : 0 < c) :
    0 < lam * c^2 := by positivity

end StringReconstruction

end
end ChainFountain.ZeroGravity
/- END SOURCE MODULE: ChainFountain.ZeroGravityCirculation -/

/- BEGIN SOURCE MODULE: ChainFountain.ZeroGravityAC -/

/-!
# Carathéodory circulation under measurable disturbances

The integrating-factor formula constructs the trajectory from its initial value
and a disturbance that is integrable on every forward compact interval. Genuine
absolute continuity, the scalar plant almost everywhere, and its integral form
are conclusions. No candidate solution or regularity before time zero is assumed.
-/

namespace ChainFountain.ZeroGravity
noncomputable section
open Set Filter MeasureTheory Real
open scoped Topology

/-- An a.e. bounded, a.e. measurable forcing is integrable on each forward
compact interval. The bound is imposed only for nonnegative times. -/
theorem forward_intervalIntegrable_of_aebounded {d : ℝ → ℝ} {D : ℝ}
    (hd : AEMeasurable d volume)
    (hb : ∀ᵐ t ∂volume, 0 ≤ t → |d t| ≤ D) :
    ∀ T : ℝ, 0 ≤ T → IntervalIntegrable d volume 0 T := by
  intro T hT
  rw [intervalIntegrable_iff_integrableOn_Ioc_of_le hT]
  apply Measure.integrableOn_of_bounded (by simp) hd.aestronglyMeasurable
  filter_upwards [ae_restrict_of_ae hb, ae_restrict_mem measurableSet_Ioc] with t ht hm
  simpa only [Real.norm_eq_abs] using ht hm.1.le

/-- Only measurability on the forward half-line is needed for local
integrability. Arbitrary negative-time values are immaterial. -/
theorem forward_intervalIntegrable_of_aebounded_restrict {d : ℝ → ℝ} {D : ℝ}
    (hd : AEMeasurable d (volume.restrict (Ici 0)))
    (hb : ∀ᵐ t ∂volume, 0 ≤ t → |d t| ≤ D) :
    ∀ T : ℝ, 0 ≤ T → IntervalIntegrable d volume 0 T := by
  intro T hT
  rw [intervalIntegrable_iff_integrableOn_Ioc_of_le hT]
  have hm : AEStronglyMeasurable d (volume.restrict (Ioc 0 T)) :=
    (hd.mono_measure (Measure.restrict_mono_set volume (by
      intro t ht; exact ht.1.le))).aestronglyMeasurable
  have hconst : Integrable (fun _ : ℝ => D) (volume.restrict (Ioc 0 T)) :=
    integrable_const D
  apply hconst.mono' hm
  filter_upwards [ae_restrict_of_ae hb, ae_restrict_mem measurableSet_Ioc] with t ht hm
  simpa only [Real.norm_eq_abs] using ht hm.1.le

/-- Interior derivatives give the forward a.e. derivative equation, without
requiring a two-sided derivative at the initial time. -/
theorem forward_ae_hasDerivAt_of_pos {r rdot : ℝ → ℝ}
    (hr : ∀ t : ℝ, 0 < t → HasDerivAt r (rdot t) t) :
    ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt r (rdot t) t := by
  filter_upwards [show ∀ᵐ t : ℝ ∂volume, t ≠ 0 from volume.ae_ne 0] with t ht ht0
  exact hr t (lt_of_le_of_ne ht0 (Ne.symm ht))

/-- The explicit integrating-factor solution is genuinely absolutely continuous
on every forward compact interval, even for merely locally integrable forcing. -/
theorem circulation_forcedError_locallyAC {d : ℝ → ℝ} {a e0 : ℝ}
    (hdi : ∀ T : ℝ, 0 ≤ T → IntervalIntegrable d volume 0 T) :
    ∀ T : ℝ, 0 ≤ T →
      AbsolutelyContinuousOnInterval (circulationForcedError d a e0) 0 T := by
  intro T hT
  have hw : IntervalIntegrable (fun s => exp (a * s) * d s) volume 0 T :=
    (hdi T hT).continuousOn_mul (by fun_prop)
  have hI := hw.absolutelyContinuousOnInterval_intervalIntegral (c := 0)
    (by simp)
  have hC : AbsolutelyContinuousOnInterval (fun _ : ℝ => e0) 0 T :=
    (contDiff_const : ContDiff ℝ 1 (fun _ : ℝ => e0)).contDiffOn.absolutelyContinuousOnInterval
  have hE : AbsolutelyContinuousOnInterval (fun t : ℝ => exp (-a * t)) 0 T :=
    (show ContDiff ℝ 1 (fun t : ℝ => exp (-a * t)) by fun_prop).contDiffOn.absolutelyContinuousOnInterval
  exact hE.fun_mul (hC.fun_add hI)

/-- There is one common full-measure set of times on which the explicit
integrating-factor trajectory satisfies its differential equation. -/
theorem circulation_forcedError_ae {d : ℝ → ℝ} {a e0 : ℝ}
    (hdi : ∀ T : ℝ, 0 ≤ T → IntervalIntegrable d volume 0 T) :
    ∀ᵐ t ∂volume, 0 ≤ t →
      HasDerivAt (circulationForcedError d a e0)
        (-a * circulationForcedError d a e0 t + d t) t := by
  have hN : ∀ n : ℕ, ∀ᵐ t ∂volume, t ∈ Icc (0 : ℝ) n →
      HasDerivAt (fun t => ∫ s in (0 : ℝ)..t, exp (a * s) * d s)
        (exp (a * t) * d t) t := by
    intro n
    have hw : IntervalIntegrable (fun s => exp (a * s) * d s) volume 0 (n : ℝ) :=
      (hdi n (Nat.cast_nonneg n)).continuousOn_mul (by fun_prop)
    filter_upwards [hw.ae_hasDerivAt_integral] with t ht hmem
    exact ht (by simpa only [uIcc_of_le (Nat.cast_nonneg n)] using hmem) 0 (by simp)
  have hAll : ∀ᵐ t ∂volume, ∀ n : ℕ, t ∈ Icc (0 : ℝ) n →
      HasDerivAt (fun t => ∫ s in (0 : ℝ)..t, exp (a * s) * d s)
        (exp (a * t) * d t) t := ae_all_iff.mpr hN
  filter_upwards [hAll] with t ht ht0
  obtain ⟨n, hn⟩ := exists_nat_gt t
  have hI := ht n ⟨ht0, hn.le⟩
  have hE := (((hasDerivAt_id t).const_mul (-a)).exp).mul (hI.const_add e0)
  have hexp : exp (-a * t) * exp (a * t) = 1 := by
    rw [← exp_add, show -a * t + a * t = 0 by ring, exp_zero]
  have hcancel := congrArg (fun x : ℝ => x * d t) hexp
  convert! hE using 1
  unfold circulationForcedError
  simp only [id_eq] at *
  nlinarith

/-- The speed constructed from the reference, forcing, and initial speed. -/
def circulationACSolution (r d : ℝ → ℝ) (γ k c0 t : ℝ) : ℝ :=
  r t + circulationForcedError d (γ + k) (c0 - r 0) t

@[simp] theorem circulationACSolution_initial (r d : ℝ → ℝ) (γ k c0 : ℝ) :
    circulationACSolution r d γ k c0 0 = c0 := by
  simp [circulationACSolution, circulationForcedError]

/-- A forward locally absolutely continuous reference yields a constructed
forward locally absolutely continuous speed. -/
theorem circulationACSolution_locallyAC {r d : ℝ → ℝ} {γ k c0 : ℝ}
    (hr : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval r 0 T)
    (hdi : ∀ T : ℝ, 0 ≤ T → IntervalIntegrable d volume 0 T) :
    ∀ T : ℝ, 0 ≤ T →
      AbsolutelyContinuousOnInterval (circulationACSolution r d γ k c0) 0 T := by
  intro T hT
  exact (hr T hT).fun_add (circulation_forcedError_locallyAC hdi T hT)

/-- The constructed speed satisfies the actual feedback-controlled plant a.e.,
with reference feedforward and damping γ+k. -/
theorem circulationACSolution_ae {r rdot d : ℝ → ℝ} {γ k c0 : ℝ}
    (hr : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt r (rdot t) t)
    (hdi : ∀ T : ℝ, 0 ≤ T → IntervalIntegrable d volume 0 T) :
    ∀ᵐ t ∂volume, 0 ≤ t →
      HasDerivAt (circulationACSolution r d γ k c0)
        (circulationCommand γ k (r t) (rdot t) (circulationACSolution r d γ k c0 t)
          - γ * circulationACSolution r d γ k c0 t + d t) t := by
  filter_upwards [hr, circulation_forcedError_ae (a := γ + k) (e0 := c0 - r 0) hdi]
    with t hrt het ht
  convert! (hrt ht).add (het ht) using 1
  simp only [circulationACSolution, circulationCommand]
  ring

/-- The constructed speed obeys the integral plant equation at every forward
time. This is derived from absolute continuity and the a.e. equation. -/
theorem circulationACSolution_integral {r rdot d : ℝ → ℝ} {γ k c0 : ℝ}
    (hrAC : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval r 0 T)
    (hr : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt r (rdot t) t)
    (hdi : ∀ T : ℝ, 0 ≤ T → IntervalIntegrable d volume 0 T) :
    ∀ t : ℝ, 0 ≤ t →
      IntervalIntegrable (fun s =>
        circulationCommand γ k (r s) (rdot s) (circulationACSolution r d γ k c0 s)
          - γ * circulationACSolution r d γ k c0 s + d s) volume 0 t ∧
      circulationACSolution r d γ k c0 t = c0 + ∫ s in (0 : ℝ)..t,
        circulationCommand γ k (r s) (rdot s) (circulationACSolution r d γ k c0 s)
          - γ * circulationACSolution r d γ k c0 s + d s := by
  intro t ht
  have hd : ∀ᵐ s ∂volume, s ∈ uIcc 0 t →
      HasDerivAt (circulationACSolution r d γ k c0)
        (circulationCommand γ k (r s) (rdot s) (circulationACSolution r d γ k c0 s)
          - γ * circulationACSolution r d γ k c0 s + d s) s := by
    filter_upwards [circulationACSolution_ae hr hdi] with s hs hmem
    exact hs ((uIcc_of_le ht ▸ hmem).1)
  obtain ⟨hi, he⟩ := ac_integral_eq_sub (circulationACSolution_locallyAC hrAC hdi t ht) hd
  refine ⟨hi, ?_⟩
  rw [he, circulationACSolution_initial]
  ring

/-- C¹ regularity on the forward half-line supplies the reference AC hypothesis;
no regularity on negative times is required. -/
theorem forward_locallyAC_of_contDiffOn {r : ℝ → ℝ}
    (hr : ContDiffOn ℝ 1 r (Ici 0)) :
    ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval r 0 T := by
  intro T hT
  apply ContDiffOn.absolutelyContinuousOnInterval
  exact hr.mono (by intro t ht; exact (uIcc_of_le hT ▸ ht).1)

/-- Unconditional global-forward construction for the paper's C¹ reference and
an a.e. measurable disturbance bounded only almost everywhere for t≥0. The
trajectory, its AC regularity, and its actual plant equation are all conclusions. -/
theorem circulation_forward_measurable_global_exists {r rdot d : ℝ → ℝ} {γ k c0 D : ℝ}
    (hrC1 : ContDiffOn ℝ 1 r (Ici 0))
    (hr : ∀ t : ℝ, 0 < t → HasDerivAt r (rdot t) t)
    (hd : AEMeasurable d (volume.restrict (Ici 0)))
    (hb : ∀ᵐ t ∂volume, 0 ≤ t → |d t| ≤ D) :
    ∃ c : ℝ → ℝ, c 0 = c0 ∧
      (∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval c 0 T) ∧
      (∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c
        (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) t) ∧
      (∀ t : ℝ, 0 ≤ t →
        IntervalIntegrable (fun s =>
          circulationCommand γ k (r s) (rdot s) (c s) - γ * c s + d s) volume 0 t ∧
        c t = c0 + ∫ s in (0 : ℝ)..t,
          circulationCommand γ k (r s) (rdot s) (c s) - γ * c s + d s) := by
  have hdi := forward_intervalIntegrable_of_aebounded_restrict hd hb
  have hrAC := forward_locallyAC_of_contDiffOn hrC1
  have hrAE : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt r (rdot t) t :=
    forward_ae_hasDerivAt_of_pos hr
  exact ⟨circulationACSolution r d γ k c0, circulationACSolution_initial r d γ k c0,
    circulationACSolution_locallyAC hrAC hdi, circulationACSolution_ae hrAE hdi,
    circulationACSolution_integral hrAC hrAE hdi⟩

/-- Convenience form for a disturbance supplied as an a.e. measurable function
on all real times. Only its forward values affect the solution. -/
theorem circulation_measurable_global_exists {r rdot d : ℝ → ℝ} {γ k c0 D : ℝ}
    (hrC1 : ContDiffOn ℝ 1 r (Ici 0))
    (hr : ∀ t : ℝ, 0 < t → HasDerivAt r (rdot t) t)
    (hd : AEMeasurable d volume)
    (hb : ∀ᵐ t ∂volume, 0 ≤ t → |d t| ≤ D) :
    ∃ c : ℝ → ℝ, c 0 = c0 ∧
      (∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval c 0 T) ∧
      (∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c
        (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) t) ∧
      (∀ t : ℝ, 0 ≤ t →
        IntervalIntegrable (fun s =>
          circulationCommand γ k (r s) (rdot s) (c s) - γ * c s + d s) volume 0 t ∧
        c t = c0 + ∫ s in (0 : ℝ)..t,
          circulationCommand γ k (r s) (rdot s) (c s) - γ * c s + d s) := by
  exact circulation_forward_measurable_global_exists hrC1 hr hd.restrict hb

end
end ChainFountain.ZeroGravity
/- END SOURCE MODULE: ChainFountain.ZeroGravityAC -/

/- BEGIN SOURCE MODULE: ChainFountain.ZeroGravityACBounds -/

/-!
# Almost-everywhere circulation estimates and unrestricted AC uniqueness

The hypotheses are genuine metric absolute continuity and an almost-everywhere
ODE. Neither an integral representation nor an assumed Lipschitz bound is
required of a competing solution.
-/
namespace ChainFountain.ZeroGravity
noncomputable section
open Set Filter MeasureTheory Real
open scoped Topology NNReal

/-- Every locally AC scalar solution has the integrating-factor representation.
Integrability of the weighted forcing is a consequence, not a hypothesis. -/
theorem circulation_ac_variation_of_constants {e d : ℝ → ℝ} {a t : ℝ}
    (ht : 0 ≤ t)
    (he : AbsolutelyContinuousOnInterval e 0 t)
    (hd : ∀ᵐ s ∂volume, 0 ≤ s → HasDerivAt e (-a * e s + d s) s) :
    IntervalIntegrable (fun s => exp (a * s) * d s) volume 0 t ∧
      e t = circulationForcedError d a (e 0) t := by
  have hexp : ContDiff ℝ 1 (fun s : ℝ => exp (a * s)) := by fun_prop
  have hW : AbsolutelyContinuousOnInterval (fun s => exp (a * s) * e s) 0 t :=
    hexp.contDiffOn.absolutelyContinuousOnInterval.fun_mul he
  have hWd : ∀ᵐ s ∂volume, s ∈ uIcc 0 t →
      HasDerivAt (fun z => exp (a * z) * e z) (exp (a * s) * d s) s := by
    filter_upwards [hd] with s hs hmem
    rw [uIcc_of_le ht] at hmem
    have h := ((((hasDerivAt_id s).const_mul a).exp).mul (hs hmem.1))
    convert! h using 1
    simp only [id_eq]
    ring
  obtain ⟨hi,hI⟩ := ChainFountain.ac_integral_eq_sub hW hWd
  refine ⟨hi,?_⟩
  have hcancel : exp (-a * t) * exp (a * t) = 1 := by
    rw [← exp_add, show -a * t + a * t = 0 by ring, exp_zero]
  unfold circulationForcedError
  rw [hI]
  simp only [mul_zero,exp_zero,one_mul]
  calc
    e t = (exp (-a * t) * exp (a * t)) * e t := by rw [hcancel,one_mul]
    _ = exp (-a * t) * (e 0 + (exp (a * t) * e t - e 0)) := by ring

/-- Uniqueness among all forward locally absolutely continuous solutions of
an a.e. scalar equation. No safe box or Lipschitz hypothesis is imposed. -/
theorem circulation_ac_unique {e₁ e₂ d : ℝ → ℝ} {a : ℝ}
    (hinit : e₁ 0 = e₂ 0)
    (h₁ : ∀ T ≥ 0, AbsolutelyContinuousOnInterval e₁ 0 T)
    (h₂ : ∀ T ≥ 0, AbsolutelyContinuousOnInterval e₂ 0 T)
    (hd₁ : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt e₁ (-a * e₁ t + d t) t)
    (hd₂ : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt e₂ (-a * e₂ t + d t) t) :
    ∀ t ≥ 0, e₁ t = e₂ t := by
  intro t ht
  rw [(circulation_ac_variation_of_constants ht (h₁ t ht) hd₁).2,
    (circulation_ac_variation_of_constants ht (h₂ t ht) hd₂).2,hinit]

/-- Explicit integral of the positive exponential comparison kernel. -/
theorem circulation_exp_integral {a D t : ℝ} (ha : a ≠ 0) :
    (∫ s in (0 : ℝ)..t, exp (a * s) * D) = D / a * (exp (a * t) - 1) := by
  have hint : IntervalIntegrable (fun s : ℝ => exp (a * s) * D) volume 0 t :=
    (by fun_prop : Continuous (fun s : ℝ => exp (a * s) * D)).intervalIntegrable 0 t
  have hd : ∀ s ∈ uIcc 0 t,
      HasDerivAt (fun z : ℝ => D / a * exp (a * z)) (exp (a * s) * D) s := by
    intro s _
    convert! ((((hasDerivAt_id s).const_mul a).exp).const_mul (D / a)) using 1
    simp only [id_eq]
    field_simp
  rw [intervalIntegral.integral_eq_sub_of_hasDerivAt hd hint]
  simp only [mul_zero,exp_zero,mul_one]
  ring

/-- The sharp weighted forcing estimate uses only an almost-everywhere bound. -/
theorem circulation_weighted_integral_bound {d : ℝ → ℝ} {a D t : ℝ}
    (ha : 0 < a) (ht : 0 ≤ t)
    (hb : ∀ᵐ s ∂volume, 0 ≤ s → |d s| ≤ D) :
    |∫ s in (0 : ℝ)..t, exp (a * s) * d s| ≤ D / a * (exp (a * t) - 1) := by
  have hint : IntervalIntegrable (fun s : ℝ => exp (a * s) * D) volume 0 t :=
    (by fun_prop : Continuous (fun s : ℝ => exp (a * s) * D)).intervalIntegrable 0 t
  have hnorm : ∀ᵐ s ∂volume, s ∈ Ioc (0 : ℝ) t →
      ‖exp (a * s) * d s‖ ≤ exp (a * s) * D := by
    filter_upwards [hb] with s hs hmem
    simp only [Real.norm_eq_abs,abs_mul,abs_of_pos (exp_pos _)]
    exact mul_le_mul_of_nonneg_left (hs hmem.1.le) (exp_pos _).le
  have h := intervalIntegral.norm_integral_le_of_norm_le ht hnorm hint
  rw [Real.norm_eq_abs,circulation_exp_integral (ne_of_gt ha)] at h
  exact h

/-- Sharp global error envelope for genuinely locally AC/a.e. solutions. -/
theorem circulation_ac_error_bound {e d : ℝ → ℝ} {a D : ℝ}
    (ha : 0 < a)
    (he : ∀ T ≥ 0, AbsolutelyContinuousOnInterval e 0 T)
    (hd : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt e (-a * e t + d t) t)
    (hb : ∀ᵐ t ∂volume, 0 ≤ t → |d t| ≤ D) :
    ∀ t ≥ 0, |e t| ≤ circulationEnvelope (e 0) a D t := by
  intro t ht
  have hrep := (circulation_ac_variation_of_constants ht (he t ht) hd).2
  have hI := circulation_weighted_integral_bound ha ht hb
  rw [hrep]
  unfold circulationForcedError
  rw [abs_mul,abs_of_pos (exp_pos _)]
  calc
    exp (-a * t) * |e 0 + ∫ s in (0 : ℝ)..t, exp (a * s) * d s| ≤
      exp (-a * t) * (|e 0| + D / a * (exp (a * t) - 1)) := by
      apply mul_le_mul_of_nonneg_left _ (exp_pos _).le
      exact (abs_add_le _ _).trans (add_le_add le_rfl hI)
    _ = circulationEnvelope (e 0) a D t := by
      have hcancel : exp (-a * t) * exp (a * t) = 1 := by
        rw [← exp_add, show -a * t + a * t = 0 by ring, exp_zero]
      unfold circulationEnvelope
      have hh := congrArg (fun x : ℝ => x * (D / a)) hcancel
      nlinarith


/-- The a.e. closed-loop equation induces the same a.e. stable error equation. -/
theorem circulation_ac_closedLoop_error {c r rdot d : ℝ → ℝ} {γ k : ℝ}
    (hc : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c
      (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) t)
    (hr : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt r (rdot t) t) :
    ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt (fun s => c s - r s)
      (-(γ + k) * (c t - r t) + d t) t := by
  filter_upwards [hc, hr] with t ht hrt hpos
  exact circulation_error_hasDerivAt (ht hpos) (hrt hpos)

/-- The sharp estimate applies to every locally AC closed-loop speed. -/
theorem circulation_ac_closedLoop_bound {c r rdot d : ℝ → ℝ} {γ k D : ℝ}
    (ha : 0 < γ + k)
    (hcAC : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T)
    (hrAC : ∀ T ≥ 0, AbsolutelyContinuousOnInterval r 0 T)
    (hc : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c
      (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) t)
    (hr : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt r (rdot t) t)
    (hb : ∀ᵐ t ∂volume, 0 ≤ t → |d t| ≤ D) :
    ∀ t ≥ 0, |c t - r t| ≤ circulationEnvelope (c 0 - r 0) (γ + k) D t := by
  exact circulation_ac_error_bound ha (fun T hT => (hcAC T hT).fun_sub (hrAC T hT))
    (circulation_ac_closedLoop_error hc hr) hb

/-- Uniqueness is forward in time and covers every locally AC competitor. -/
theorem circulation_ac_closedLoop_unique {c₁ c₂ r rdot d : ℝ → ℝ} {γ k : ℝ}
    (hinit : c₁ 0 = c₂ 0)
    (h₁ : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c₁ 0 T)
    (h₂ : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c₂ 0 T)
    (hrAC : ∀ T ≥ 0, AbsolutelyContinuousOnInterval r 0 T)
    (hd₁ : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c₁
      (circulationCommand γ k (r t) (rdot t) (c₁ t) - γ * c₁ t + d t) t)
    (hd₂ : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c₂
      (circulationCommand γ k (r t) (rdot t) (c₂ t) - γ * c₂ t + d t) t)
    (hr : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt r (rdot t) t) :
    ∀ t ≥ 0, c₁ t = c₂ t := by
  have hu := circulation_ac_unique (by rw [hinit] : c₁ 0 - r 0 = c₂ 0 - r 0)
    (fun T hT => (h₁ T hT).fun_sub (hrAC T hT))
    (fun T hT => (h₂ T hT).fun_sub (hrAC T hT))
    (circulation_ac_closedLoop_error hd₁ hr) (circulation_ac_closedLoop_error hd₂ hr)
  intro t ht
  have h := hu t ht
  linarith

/-- The pointwise lower tension estimate complements the existing upper bound. -/
theorem circulation_tension_lower {lam c rmin ρ : ℝ}
    (hlam : 0 ≤ lam) (hmargin : ρ ≤ rmin) (hc : rmin - ρ ≤ c) :
    lam * (rmin - ρ)^2 ≤ lam * c^2 := by
  apply mul_le_mul_of_nonneg_left _ hlam
  have hlo : 0 ≤ rmin - ρ := sub_nonneg.mpr hmargin
  nlinarith [mul_nonneg (sub_nonneg.mpr hc) (show 0 ≤ c + (rmin - ρ) by linarith)]

/-- All forward-time physical bounds hold pointwise, although the disturbance
bound and differential equation hold only almost everywhere. -/
theorem circulation_ac_physical_bounds {c r rdot d : ℝ → ℝ}
    {γ k D lam rmin rmax A : ℝ}
    (hγ : 0 ≤ γ) (hk : 0 ≤ k) (ha : 0 < γ + k) (hlam : 0 < lam)
    (hcAC : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T)
    (hrAC : ∀ T ≥ 0, AbsolutelyContinuousOnInterval r 0 T)
    (hc : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c
      (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) t)
    (hr : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt r (rdot t) t)
    (hb : ∀ᵐ t ∂volume, 0 ≤ t → |d t| ≤ D)
    (href : ∀ t ≥ 0, rmin ≤ r t ∧ r t ≤ rmax)
    (hrdot : ∀ t ≥ 0, |rdot t| ≤ A)
    (hmargin : max |c 0 - r 0| (D / (γ + k)) < rmin) :
    ∀ t ≥ 0, let ρ := max |c 0 - r 0| (D / (γ + k))
      |c t - r t| ≤ circulationEnvelope (c 0 - r 0) (γ + k) D t ∧
      |c t - r t| ≤ ρ ∧
      rmin - ρ ≤ c t ∧ c t ≤ rmax + ρ ∧ 0 < c t ∧
      lam * (rmin - ρ)^2 ≤ lam * (c t)^2 ∧
      lam * (c t)^2 ≤ lam * (rmax + ρ)^2 ∧ 0 < lam * (c t)^2 ∧
      |circulationCommand γ k (r t) (rdot t) (c t)| ≤ A + γ * rmax + k * ρ := by
  intro t ht
  let ρ := max |c 0 - r 0| (D / (γ + k))
  have hρ : 0 ≤ ρ := (abs_nonneg _).trans (le_max_left _ _)
  have herr := circulation_ac_closedLoop_bound ha hcAC hrAC hc hr hb t ht
  have hcap : |c t - r t| ≤ ρ := herr.trans (circulation_envelope_below_max ha ht)
  have hrl := (href t ht).1
  have hru := (href t ht).2
  have hl : rmin - ρ ≤ c t := by linarith [(abs_le.mp hcap).1]
  have hu : c t ≤ rmax + ρ := by linarith [(abs_le.mp hcap).2]
  have hpos : 0 < c t := by change ρ < rmin at hmargin; linarith
  refine ⟨herr, hcap, hl, hu, hpos, ?_, ?_, loop_tension_positive hlam hpos, ?_⟩
  · exact circulation_tension_lower hlam.le hmargin.le hl
  · exact circulation_tension_upper hlam.le hpos.le hru hcap
  · exact circulation_command_bound hγ hk (by change ρ < rmin at hmargin; linarith)
      hru (hrdot t ht) hcap


/-- Global well-posedness and physical admissibility with merely measurable,
essentially bounded forcing. The speed is constructed, uniqueness includes every
forward locally AC competitor, and every physical bound holds at every t≥0. -/
theorem circulation_measurable_global_wellposed {r rdot d : ℝ → ℝ}
    {γ k c0 D lam rmin rmax A : ℝ}
    (hγ : 0 ≤ γ) (hk : 0 ≤ k) (ha : 0 < γ + k) (hlam : 0 < lam)
    (hrC1 : ContDiffOn ℝ 1 r (Ici 0))
    (hr : ∀ t > 0, HasDerivAt r (rdot t) t)
    (hd : AEMeasurable d (volume.restrict (Ici 0)))
    (hb : ∀ᵐ t ∂volume, 0 ≤ t → |d t| ≤ D)
    (href : ∀ t ≥ 0, rmin ≤ r t ∧ r t ≤ rmax)
    (hrdot : ∀ t ≥ 0, |rdot t| ≤ A)
    (hmargin : max |c0 - r 0| (D / (γ + k)) < rmin) :
    let ρ := max |c0 - r 0| (D / (γ + k))
    ∃ c : ℝ → ℝ, c 0 = c0 ∧
      (∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T) ∧
      (∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c
        (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) t) ∧
      (∀ t ≥ 0,
        IntervalIntegrable (fun s => circulationCommand γ k (r s) (rdot s) (c s)
          - γ * c s + d s) volume 0 t ∧
        c t = c0 + ∫ s in (0 : ℝ)..t,
          circulationCommand γ k (r s) (rdot s) (c s) - γ * c s + d s) ∧
      (∀ c₂ : ℝ → ℝ, c₂ 0 = c0 →
        (∀ T ≥ 0, AbsolutelyContinuousOnInterval c₂ 0 T) →
        (∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c₂
          (circulationCommand γ k (r t) (rdot t) (c₂ t) - γ * c₂ t + d t) t) →
        ∀ t ≥ 0, c₂ t = c t) ∧
      (∀ t ≥ 0,
        |c t - r t| ≤ circulationEnvelope (c0 - r 0) (γ + k) D t ∧
        |c t - r t| ≤ ρ ∧
        rmin - ρ ≤ c t ∧ c t ≤ rmax + ρ ∧ 0 < c t ∧
        lam * (rmin - ρ)^2 ≤ lam * (c t)^2 ∧
        lam * (c t)^2 ≤ lam * (rmax + ρ)^2 ∧ 0 < lam * (c t)^2 ∧
        |circulationCommand γ k (r t) (rdot t) (c t)| ≤ A + γ * rmax + k * ρ) := by
  have hdi := forward_intervalIntegrable_of_aebounded_restrict hd hb
  have hrAE := forward_ae_hasDerivAt_of_pos hr
  have hrAC := forward_locallyAC_of_contDiffOn hrC1
  let c := circulationACSolution r d γ k c0
  have hc0 : c 0 = c0 := circulationACSolution_initial r d γ k c0
  have hcAC : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T :=
    circulationACSolution_locallyAC hrAC hdi
  have hc : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c
      (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) t :=
    circulationACSolution_ae hrAE hdi
  have hI := circulationACSolution_integral (γ := γ) (k := k) (c0 := c0) hrAC hrAE hdi
  refine ⟨c, hc0, hcAC, hc, hI, ?_, ?_⟩
  · intro c₂ hc₂0 hc₂AC hc₂
    exact circulation_ac_closedLoop_unique (hc₂0.trans hc0.symm) hc₂AC hcAC hrAC hc₂ hc hrAE
  · have hm : max |c 0 - r 0| (D / (γ + k)) < rmin := by simpa only [hc0] using hmargin
    simpa only [hc0] using
      circulation_ac_physical_bounds hγ hk ha hlam hcAC hrAC hc hrAE hb href hrdot hm

end
end ChainFountain.ZeroGravity
/- END SOURCE MODULE: ChainFountain.ZeroGravityACBounds -/

/- BEGIN SOURCE MODULE: ChainFountain.ZeroGravityAEReconstruction -/

/-!
# Absolutely continuous circulation and the actual string equation

The phase is constructed from the speed, using a constant extension before time
zero. The common null set in the acceleration equation is independent of the
material label. Spatial shape remains prescribed; no shape-attraction theorem
is asserted.
-/
namespace ChainFountain.ZeroGravity
noncomputable section
open Set Filter MeasureTheory Real
open scoped Topology NNReal

/-- Constant extension of a forward speed to negative time. -/
def forwardSpeed (c : ℝ → ℝ) (t : ℝ) : ℝ := c (max 0 t)

/-- Material phase constructed by integrating the continuous extended speed. -/
def circulationPhase (c : ℝ → ℝ) (θ0 t : ℝ) : ℝ :=
  θ0 + ∫ s in (0 : ℝ)..t, forwardSpeed c s

theorem forwardSpeed_eq {c : ℝ → ℝ} {t : ℝ} (ht : 0 ≤ t) :
    forwardSpeed c t = c t := by simp [forwardSpeed, max_eq_right ht]

theorem forwardSpeed_continuous {c : ℝ → ℝ}
    (hc : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T) :
    Continuous (forwardSpeed c) := locally_ac_forward_extension hc

theorem forwardSpeed_hasDerivAt {c : ℝ → ℝ} {t z : ℝ}
    (ht : 0 < t) (hc : HasDerivAt c z t) :
    HasDerivAt (forwardSpeed c) z t := by
  apply hc.congr_of_eventuallyEq
  filter_upwards [Ioi_mem_nhds ht] with s hs
  exact forwardSpeed_eq hs.le

theorem circulationPhase_initial (c : ℝ → ℝ) (θ0 : ℝ) :
    circulationPhase c θ0 0 = θ0 := by simp [circulationPhase]

/-- The phase has a classical derivative at every real time, including zero. -/
theorem circulationPhase_hasDerivAt {c : ℝ → ℝ} {θ0 t : ℝ}
    (hc : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T) :
    HasDerivAt (circulationPhase c θ0) (forwardSpeed c t) t := by
  have h := forwardSpeed_continuous hc
  exact (intervalIntegral.integral_hasDerivAt_right
    (h.intervalIntegrable 0 t) h.aestronglyMeasurable.stronglyMeasurableAtFilter
    h.continuousAt).const_add θ0

/-- The phase is continuously differentiable, not merely differentiable a.e. -/
theorem circulationPhase_contDiff {c : ℝ → ℝ} {θ0 : ℝ}
    (hc : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T) :
    ContDiff ℝ 1 (circulationPhase c θ0) := by
  apply contDiff_one_iff_deriv.mpr
  refine ⟨fun t => (circulationPhase_hasDerivAt hc).differentiableAt, ?_⟩
  have he : deriv (circulationPhase c θ0) = forwardSpeed c := by
    funext t
    exact (circulationPhase_hasDerivAt hc).deriv
  rw [he]
  exact forwardSpeed_continuous hc

/-- On forward times the phase is exactly the integral of the original speed. -/
theorem circulationPhase_forward_integral {c : ℝ → ℝ} {θ0 t : ℝ} (ht : 0 ≤ t) :
    circulationPhase c θ0 t = θ0 + ∫ s in (0 : ℝ)..t, c s := by
  unfold circulationPhase
  congr 1
  apply intervalIntegral.integral_congr
  intro s hs
  rw [uIcc_of_le ht] at hs
  exact forwardSpeed_eq hs.1

section Vector
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- Material velocity is the actual time derivative of the reconstructed position
at every forward time and every material label. -/
theorem loop_ac_material_velocity {R R1 : ℝ → E} {c : ℝ → ℝ} {θ0 t a : ℝ}
    (hc : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T)
    (hR : ∀ x, HasDerivAt R (R1 x) x) (ht : 0 ≤ t) :
    deriv (fun s => R (a + circulationPhase c θ0 s)) t =
      c t • R1 (a + circulationPhase c θ0 t) := by
  simpa only [forwardSpeed_eq ht] using
    (loop_position_hasDerivAt (a := a) (t := t) (hR _)
      (circulationPhase_hasDerivAt (θ0 := θ0) hc)).deriv

/-- The actual second time derivative obeys momentum balance on one common
full-measure time set, simultaneously for all material labels. -/
theorem loop_continuum_balance_ae {R R1 R2 : ℝ → E} {c u d : ℝ → ℝ}
    {lam γ θ0 : ℝ} (hlam : lam ≠ 0)
    (hR : ∀ x, HasDerivAt R (R1 x) x)
    (hR1 : ∀ x, HasDerivAt R1 (R2 x) x)
    (hc : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T)
    (hd : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c (u t - γ * c t + d t) t) :
    ∀ᵐ t ∂volume, 0 ≤ t → ∀ a : ℝ,
      deriv (fun τ => deriv (fun s => R (a + circulationPhase c θ0 s)) τ) t =
        (1 / lam) • deriv
          (fun b => (lam * (c t)^2) •
            deriv (fun z => R (z + circulationPhase c θ0 t)) b) a +
        (u t - γ * c t + d t) •
          deriv (fun z => R (z + circulationPhase c θ0 t)) a := by
  have hne : ∀ᵐ t : ℝ ∂volume, t ≠ 0 := by simp [ae_iff, measure_singleton]
  filter_upwards [hd,hne] with t hdt hnt ht a
  have htp : 0 < t := lt_of_le_of_ne ht (Ne.symm hnt)
  have hce := forwardSpeed_hasDerivAt htp (hdt ht)
  rw [←forwardSpeed_eq (c := c) ht] at hce
  have he := loop_continuum_balance (c := forwardSpeed c)
    (θ := circulationPhase c θ0) (a := a) hlam hR (hR1 _)
    (fun s => circulationPhase_hasDerivAt hc) hce
  simpa only [forwardSpeed_eq ht] using he

/-- The material velocity itself is forward locally absolutely continuous.
The C¹ tangent hypothesis is supplied by a C² reference curve. -/
theorem loop_material_velocity_ac {R1 : ℝ → E} {c : ℝ → ℝ} {θ0 a T : ℝ}
    (hc : ∀ S ≥ 0, AbsolutelyContinuousOnInterval c 0 S)
    (hR1 : ContDiff ℝ 1 R1) (hT : 0 ≤ T) :
    AbsolutelyContinuousOnInterval
      (fun t => c t • R1 (a + circulationPhase c θ0 t)) 0 T := by
  have htan : ContDiff ℝ 1 (fun t => R1 (a + circulationPhase c θ0 t)) :=
    hR1.comp (contDiff_const.add (circulationPhase_contDiff hc))
  obtain ⟨K,hK⟩ := htan.contDiffOn.exists_lipschitzOnWith (by norm_num)
    (convex_Icc (0 : ℝ) T) isCompact_Icc
  have hAC : AbsolutelyContinuousOnInterval
      (fun t => R1 (a + circulationPhase c θ0 t)) 0 T := by
    apply LipschitzOnWith.absolutelyContinuousOnInterval
    simpa only [uIcc_of_le hT] using hK
  exact (hc T hT).fun_smul hAC

/-- A.e. acceleration of the AC material velocity; the exceptional time set is
again common to all material labels. -/
theorem loop_material_acceleration_ae {R1 R2 : ℝ → E} {c u d : ℝ → ℝ}
    {γ θ0 : ℝ}
    (hR1 : ∀ x, HasDerivAt R1 (R2 x) x)
    (hc : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T)
    (hd : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c (u t - γ * c t + d t) t) :
    ∀ᵐ t ∂volume, 0 ≤ t → ∀ a : ℝ,
      HasDerivAt (fun s => c s • R1 (a + circulationPhase c θ0 s))
        ((c t)^2 • R2 (a + circulationPhase c θ0 t) +
          (u t - γ * c t + d t) • R1 (a + circulationPhase c θ0 t)) t := by
  filter_upwards [hd] with t hdt ht a
  exact loop_velocity_hasDerivAt (hR1 _)
    (by simpa only [forwardSpeed_eq ht] using circulationPhase_hasDerivAt (θ0 := θ0) (t := t) hc)
    (hdt ht)

/-- The reconstructed loop inherits closure and inextensibility at all times. -/
theorem loop_ac_geometry {R R1 : ℝ → E} {c : ℝ → ℝ} {θ0 L : ℝ}
    (hR : ∀ x, HasDerivAt R (R1 x) x)
    (hunit : ∀ x, ‖R1 x‖ = 1) (hperiod : Function.Periodic R L) :
    (∀ t, Function.Periodic (fun a => R (a + circulationPhase c θ0 t)) L) ∧
    (∀ a t, ‖deriv (fun z => R (z + circulationPhase c θ0 t)) a‖ = 1) := by
  exact ⟨fun t => loop_periodic hperiod,
    fun a t => loop_inextensible (hR _) (hunit _)⟩

/-- Spatial stress divergence is the curvature term, with the actual spatial
first and second derivatives. This identity needs no temporal differentiability. -/
theorem loop_spatial_force {R R1 R2 : ℝ → E} {θ c u d : ℝ → ℝ}
    {lam γ a t : ℝ} (hlam : lam ≠ 0)
    (hR : ∀ x, HasDerivAt R (R1 x) x)
    (hR1 : ∀ x, HasDerivAt R1 (R2 x) x) :
    (1 / lam) • deriv
        (fun b => (lam * (c t)^2) • deriv (fun z => R (z + θ t)) b) a +
      (u t - γ * c t + d t) • deriv (fun z => R (z + θ t)) a =
    (c t)^2 • R2 (a + θ t) + (u t - γ * c t + d t) • R1 (a + θ t) := by
  have hspace : deriv (fun z => R (z + θ t)) = (fun b => R1 (b + θ t)) := by
    funext b
    have h := (hR (b + θ t)).scomp b ((hasDerivAt_id b).add_const (θ t))
    simpa only [Function.comp_def, id_eq, one_smul] using! h.deriv
  rw [hspace, (loop_stress_hasDerivAt (lam := lam) (hR1 _)).deriv]
  have hscalar : 1 / lam * (lam * (c t)^2) = (c t)^2 := by field_simp
  rw [smul_smul, hscalar]

end Vector

/-- Actual vector integral momentum equation in three real coordinates for each
material label. Integrability follows from genuine AC and the a.e. equation.
This coordinate bridge makes no unit-speed claim for the product norm; the
physical geometry below uses an inner-product-space norm. -/
theorem loop_ac_integral_momentum
    {R1 R2 : ℝ → ℝ × (ℝ × ℝ)} {c u d : ℝ → ℝ} {γ θ0 T a : ℝ}
    (hT : 0 ≤ T) (hc : ∀ S ≥ 0, AbsolutelyContinuousOnInterval c 0 S)
    (hR1 : ContDiff ℝ 1 R1) (hR1d : ∀ x, HasDerivAt R1 (R2 x) x)
    (hd : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c (u t - γ * c t + d t) t) :
    let V := fun t => c t • R1 (a + circulationPhase c θ0 t)
    let A := fun t => (c t)^2 • R2 (a + circulationPhase c θ0 t) +
      (u t - γ * c t + d t) • R1 (a + circulationPhase c θ0 t)
    IntervalIntegrable A volume 0 T ∧ V T = V 0 + ∫ t in (0 : ℝ)..T, A t := by
  dsimp only
  have hacc := loop_material_acceleration_ae (θ0 := θ0) hR1d hc hd
  have hD : ∀ᵐ t ∂volume, t ∈ uIcc 0 T →
      HasDerivAt (fun t => c t • R1 (a + circulationPhase c θ0 t))
        ((c t)^2 • R2 (a + circulationPhase c θ0 t) +
          (u t - γ * c t + d t) • R1 (a + circulationPhase c θ0 t)) t := by
    filter_upwards [hacc] with t ht hmem
    rw [uIcc_of_le hT] at hmem
    exact ht hmem.1 a
  obtain ⟨hi,he⟩ := ac_state_integral_eq_sub (loop_material_velocity_ac hc hR1 hT) hD
  exact ⟨hi, by rw [he]; abel⟩

/-- The coordinate integral momentum theorem written entirely with actual
position derivatives and spatial stress divergence. It does not assert a
unit-speed constraint for the coordinate product norm. -/
theorem loop_ac_integral_balance
    {R R1 R2 : ℝ → ℝ × (ℝ × ℝ)} {c u d : ℝ → ℝ} {lam γ θ0 T a : ℝ}
    (hlam : lam ≠ 0) (hT : 0 ≤ T)
    (hc : ∀ S ≥ 0, AbsolutelyContinuousOnInterval c 0 S)
    (hR : ∀ x, HasDerivAt R (R1 x) x)
    (hR1 : ContDiff ℝ 1 R1) (hR1d : ∀ x, HasDerivAt R1 (R2 x) x)
    (hd : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c (u t - γ * c t + d t) t) :
    let V := fun t => deriv (fun s => R (a + circulationPhase c θ0 s)) t
    let F := fun t => (1 / lam) • deriv
        (fun b => (lam * (c t)^2) •
          deriv (fun z => R (z + circulationPhase c θ0 t)) b) a +
      (u t - γ * c t + d t) • deriv (fun z => R (z + circulationPhase c θ0 t)) a
    IntervalIntegrable F volume 0 T ∧ V T = V 0 + ∫ t in (0 : ℝ)..T, F t := by
  dsimp only
  simpa only [loop_spatial_force hlam hR hR1d,
    loop_ac_material_velocity hc hR hT,
    loop_ac_material_velocity hc hR (le_refl (0 : ℝ))] using
    loop_ac_integral_momentum (θ0 := θ0) (a := a) hT hc hR1 hR1d hd

section InnerProduct
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

/-- The reconstructed zero-gravity loop, with its actual derivatives and a.e.
closed-loop mechanics. The norm is the inner-product norm (for example the
Euclidean norm on `EuclideanSpace ℝ (Fin 3)`), and the material period is positive.
This proposition describes the prescribed-shape circulation family; it makes
no assertion of stability with respect to arbitrary shape perturbations. -/
structure AECirculatingLoop (R : ℝ → E) (r rdot d : ℝ → ℝ)
    (γ k lam L c0 θ0 : ℝ) (c : ℝ → ℝ) : Prop where
  positive_period : 0 < L
  positive_density : 0 < lam
  speed_initial : c 0 = c0
  speed_locallyAC : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T
  phase_initial : circulationPhase c θ0 0 = θ0
  phase_contDiff : ContDiff ℝ 1 (circulationPhase c θ0)
  phase_integral : ∀ t ≥ 0,
    circulationPhase c θ0 t = θ0 + ∫ s in (0 : ℝ)..t, c s
  closed : ∀ t, Function.Periodic (fun a => R (a + circulationPhase c θ0 t)) L
  inextensible : ∀ a t, ‖deriv (fun z => R (z + circulationPhase c θ0 t)) a‖ = 1
  tension_nonnegative : ∀ t, 0 ≤ lam * (c t)^2
  material_velocity : ∀ a t, 0 ≤ t →
    deriv (fun s => R (a + circulationPhase c θ0 s)) t =
      c t • deriv R (a + circulationPhase c θ0 t)
  material_velocity_locallyAC : ∀ a T, 0 ≤ T →
    AbsolutelyContinuousOnInterval
      (fun t => c t • deriv R (a + circulationPhase c θ0 t)) 0 T
  plant_ae : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c
    (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) t
  plant_integral : ∀ t ≥ 0,
    IntervalIntegrable (fun s =>
      circulationCommand γ k (r s) (rdot s) (c s) - γ * c s + d s) volume 0 t ∧
    c t = c0 + ∫ s in (0 : ℝ)..t,
      circulationCommand γ k (r s) (rdot s) (c s) - γ * c s + d s
  momentum_ae : ∀ᵐ t ∂volume, 0 ≤ t → ∀ a : ℝ,
    deriv (fun τ => deriv (fun s => R (a + circulationPhase c θ0 s)) τ) t =
      (1 / lam) • deriv
        (fun b => (lam * (c t)^2) •
          deriv (fun z => R (z + circulationPhase c θ0 t)) b) a +
      (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) •
        deriv (fun z => R (z + circulationPhase c θ0 t)) a

/-- Global construction from a C² unit-speed closed reference curve and a
forward a.e. measurable, essentially bounded disturbance. The scalar speed,
phase, and actual continuum solution are all constructed; no candidate speed
or phase trajectory is assumed. No regularity of the disturbance before zero
is required. -/
theorem measurable_closed_loop_exists {R : ℝ → E} {r rdot d : ℝ → ℝ}
    {γ k lam L c0 θ0 D : ℝ}
    (hL : 0 < L) (hlam : 0 < lam)
    (hR : ContDiff ℝ 2 R) (hunit : ∀ x, ‖deriv R x‖ = 1)
    (hperiod : Function.Periodic R L)
    (hrC1 : ContDiffOn ℝ 1 r (Ici 0))
    (hr : ∀ t : ℝ, 0 < t → HasDerivAt r (rdot t) t)
    (hd : AEMeasurable d (volume.restrict (Ici 0)))
    (hb : ∀ᵐ t ∂volume, 0 ≤ t → |d t| ≤ D) :
    ∃ c : ℝ → ℝ, AECirculatingLoop R r rdot d γ k lam L c0 θ0 c := by
  obtain ⟨c,hc0,hc,hplant,hint⟩ := circulation_forward_measurable_global_exists
    (γ := γ) (k := k) (c0 := c0) hrC1 hr hd hb
  have hR1 : ContDiff ℝ 1 (deriv R) := hR.deriv'
  have hRd : ∀ x, HasDerivAt R (deriv R x) x :=
    fun x => (hR.differentiable (by norm_num) x).hasDerivAt
  have hR1d : ∀ x, HasDerivAt (deriv R) (deriv (deriv R) x) x :=
    fun x => (hR1.differentiable (by norm_num) x).hasDerivAt
  have hgeo := loop_ac_geometry (c := c) (θ0 := θ0) hRd hunit hperiod
  refine ⟨c, {
    positive_period := hL
    positive_density := hlam
    speed_initial := hc0
    speed_locallyAC := hc
    phase_initial := circulationPhase_initial c θ0
    phase_contDiff := circulationPhase_contDiff hc
    phase_integral := fun t ht => circulationPhase_forward_integral ht
    closed := hgeo.1
    inextensible := hgeo.2
    tension_nonnegative := fun t => mul_nonneg hlam.le (sq_nonneg (c t))
    material_velocity := fun a t ht => loop_ac_material_velocity hc hRd ht
    material_velocity_locallyAC := fun a T hT => loop_material_velocity_ac hc hR1 hT
    plant_ae := hplant
    plant_integral := hint
    momentum_ae := loop_continuum_balance_ae hlam.ne' hRd hR1d hc hplant }⟩

end InnerProduct

end
end ChainFountain.ZeroGravity
/- END SOURCE MODULE: ChainFountain.ZeroGravityAEReconstruction -/
