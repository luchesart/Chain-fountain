# Chain fountain — Lean formalization

**Author: Latchezar Tomov**

Lean source code for the control-theoretic chain-fountain model and its
zero-gravity extension. The repository contains the deterministic and
stochastic developments, the pinned Lake project and a separate Mathlib-only
browser companion. The mathematical source files are unchanged from the
corresponding validated releases.

## Check the full project

Install Lean 4 (the official VS Code extension is suitable), Git and Python 3.
Open this repository directory in VS Code and run:

```console
python verify.py --zero-gravity
```

On Windows, `py -3 verify.py --zero-gravity` is also supported. The supplied
`Check-ChainFountain.ps1 -ZeroGravity` starts the same check from PowerShell.
The first run downloads the pinned dependencies and requires internet access
and several gigabytes of disk space. Later runs can use `--skip-download`
once these dependencies are available.

The script checks the unified entry point and builds the zero-gravity target.
It writes fresh logs and a summary under `verification/live-runs/`. It does
not repeat the complete transitive axiom audit. The `Audit.lean` and
`verification/` Lean files provide the source audit and export tools.

Keep `lean-toolchain` and `lake-manifest.json` as supplied. The full project
uses **Lean 4.33.0-rc1**, including pinned MathFin, BrownianMotion and Mathlib
dependencies. The single-file project entry point also needs those
dependencies. The browser companion below has a separate environment.

## Use Live Lean

Open [Live Lean, Stable Release](https://live.lean-lang.org/#project=mathlib-stable),
select **Stable Release (v4.35.0 with mathlib, cslib)** and paste the entire
[`browser-companion/Chain_Fountain_Mathlib_Live.lean`](browser-companion/Chain_Fountain_Mathlib_Live.lean).
This is the revision that successfully passed the user's public Live Lean check.

The browser file contains **350 theorems**, including all **78 zero-gravity
theorems**. It covers deterministic, measurable-input and absolutely continuous
results. The mechanical SDE, actual stochastic integrals and LIL proofs are
in the full project and are not included in this browser file.

The same browser source passed local compiler and language-server checks with
zero errors and warnings in both exact environments:

| Lean | Mathlib commit |
| --- | --- |
| 4.35.0 | `56a005855ea17e0b0958f73ec801ae140b0a1679` |
| 4.36.0-rc2 | `10a613cca96c9b98c695eddf09c0b7b2a53b4b6b` |

All 350 theorem statements and hypotheses are preserved. The transitive axiom
audits passed with only `propext`, `Classical.choice` and `Quot.sound`.
Future versions of the moving Latest Mathlib environment are not covered.
The exact source hashes and validation summaries are in
[`verification/browser-compatibility/revision-2/`](verification/browser-compatibility/revision-2/).

## Repository contents

| Path | Purpose |
| --- | --- |
| `ChainFountain/` | Deterministic model, control results and zero-gravity extension |
| `ChainFountainStochastic/` | Stochastic development, mechanical SDE and LIL |
| `ChainFountain.lean` | Deterministic entry point |
| `ChainFountainStochastic.lean` | Stochastic entry point |
| `ChainFountainZeroGravity.lean` | Zero-gravity entry point |
| `Chain_Fountain_Live.lean` | Unified 557-theorem full-project entry point |
| `browser-companion/` | Separate 350-theorem Mathlib-only browser file |
| `verification/` | Build helper, Lean audit/export tools and current browser summaries |

The zero-gravity entry point supplies 78 additional theorems. The browser
file overlaps with the full project; its theorem count must not be added to
the full-project count.

This archive was checked for source preservation, internal imports and package
integrity. The full stochastic project was not rebuilt for this packaging
step. The browser validation summaries describe the earlier completed checks
of the identical source bytes. Generated documentation, the preprint,
simulator, dependency caches and historical build logs are outside this package.

## Upload to GitHub

Extract the ZIP and upload the **contents** of `Chain_Fountain_Lean/` to the
repository or chosen branch, so that `lakefile.toml` and `lean-toolchain` are
at the repository root. The `.gitignore` excludes dependency caches and local
build outputs. No GitHub Actions workflow or repository settings are added.

The existing `LICENSE` and source attribution notices are preserved. The
license file describes the adapted third-party sources; this packaging step
does not assign a new license to the remaining author code.
