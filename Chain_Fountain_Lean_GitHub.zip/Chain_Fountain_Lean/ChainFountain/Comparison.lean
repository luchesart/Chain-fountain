import ChainFountain.Tracking

namespace ChainFountain
noncomputable section
open Set Real

def envelope (V₀ κ C t : ℝ) : ℝ :=
  exp (-2 * κ * t) * V₀ + C / (2 * κ) * (1 - exp (-2 * κ * t))

/-- Comparison for genuine derivatives; this does not assume its conclusion. -/
theorem scalar_comparison {V V' : ℝ → ℝ} {T κ C : ℝ} (hκ : 0 < κ)
    (hc : ContinuousOn V (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt V (V' t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, V' t ≤ -2 * κ * V t + C) :
    ∀ t ∈ Icc 0 T, V t ≤ envelope (V 0) κ C t := by
  have hG := le_gronwallBound_of_liminf_deriv_right_le hc
    (fun t ht _ hr => (hd t ht).liminf_right_slope_le hr) (le_refl (V 0)) hb
  intro t ht
  have h := hG t ht
  rw [gronwallBound, if_neg (by nlinarith : -2 * κ ≠ 0), sub_zero] at h
  unfold envelope
  convert! h using 1; ring

theorem envelope_below_cap {V₀ κ C cap t : ℝ}
    (hκ : 0 < κ) (ht : 0 ≤ t) (hV : V₀ ≤ cap) (hC : C / (2 * κ) ≤ cap) :
    envelope V₀ κ C t ≤ cap := by
  have he0 : 0 ≤ exp (-2 * κ * t) := (exp_pos _).le
  have he1 : exp (-2 * κ * t) ≤ 1 := exp_le_one_iff.mpr (by nlinarith)
  have h₁ := mul_le_mul_of_nonneg_left hV he0
  have h₂ := mul_le_mul_of_nonneg_right hC (sub_nonneg.mpr he1)
  unfold envelope; nlinarith

/-- Theorem 7.1's finite-time estimate for existing classical error trajectories.
The measurable-disturbance Caratheodory extension is not hidden in this theorem. -/
theorem robust_error_estimate {e z G d : ℝ → ℝ} {T k₀ k₁ k₂ κ κd dbar : ℝ}
    (hk₀ : 0 ≤ k₀) (hκ : 0 < κ) (hκ₁ : κ ≤ k₁) (hκ₂ : κ ≤ k₂) (hκd : 0 < κd)
    (he : ∀ t ∈ Icc 0 T, HasDerivAt e (errorRate k₁ (e t) (z t)) t)
    (hz : ∀ t ∈ Icc 0 T, HasDerivAt z (zRate k₀ k₂ κd (G t) (d t) (e t) (z t)) t)
    (hb : ∀ t ∈ Ico 0 T, |d t| ≤ dbar) :
    ∀ t ∈ Icc 0 T, errorEnergy k₀ (e t) (z t) ≤
      exp (-2 * κ * t) * errorEnergy k₀ (e 0) (z 0) +
      dbar ^ 2 / (16 * κ * κd) * (1 - exp (-2 * κ * t)) := by
  have hd := fun t ht => energy_hasDerivAt_errors (he t ht) (hz t ht)
  have hc : ContinuousOn (fun t => errorEnergy k₀ (e t) (z t)) (Icc 0 T) :=
    fun t ht => (hd t ht).continuousAt.continuousWithinAt
  have hcomp := scalar_comparison hκ hc
    (fun t ht => (hd t (Ico_subset_Icc_self ht)).hasDerivWithinAt)
    (fun t ht => robust_decay_uniform hk₀ hκ₁ hκ₂ hκd (hb t ht))
  intro t ht
  have h := hcomp t ht
  unfold envelope at h
  convert! h using 1; ring

theorem nominal_error_estimate {e z : ℝ → ℝ} {T k₀ k₁ k₂ κ : ℝ}
    (hk₀ : 0 ≤ k₀) (hκ : 0 < κ) (hκ₁ : κ ≤ k₁) (hκ₂ : κ ≤ k₂)
    (he : ∀ t ∈ Icc 0 T, HasDerivAt e (errorRate k₁ (e t) (z t)) t)
    (hz : ∀ t ∈ Icc 0 T, HasDerivAt z (zRate k₀ k₂ 0 0 0 (e t) (z t)) t) :
    ∀ t ∈ Icc 0 T, errorEnergy k₀ (e t) (z t) ≤
      exp (-2 * κ * t) * errorEnergy k₀ (e 0) (z 0) := by
  have hd := fun t ht => energy_hasDerivAt_errors (he t ht) (hz t ht)
  have hc : ContinuousOn (fun t => errorEnergy k₀ (e t) (z t)) (Icc 0 T) :=
    fun t ht => (hd t ht).continuousAt.continuousWithinAt
  have hcomp := scalar_comparison (C:=0) hκ hc
    (fun t ht => (hd t (Ico_subset_Icc_self ht)).hasDerivWithinAt) (by
      intro t ht
      simpa using nominal_decay (e:=e t) (z:=z t) hk₀ hκ₁ hκ₂)
  simpa [envelope] using hcomp

/-- The energy-level part of the robust invariant-region theorem. -/
theorem robust_energy_invariant {V V' : ℝ → ℝ} {T κ κd dbar cap : ℝ}
    (hκ : 0 < κ) (_hκd : 0 < κd)
    (hc : ContinuousOn V (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt V (V' t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, V' t ≤ -2 * κ * V t + dbar ^ 2 / (8 * κd))
    (h₀ : V 0 ≤ cap) (hcap : dbar ^ 2 / (16 * κ * κd) ≤ cap) :
    ∀ t ∈ Icc 0 T, V t ≤ cap := by
  have hb' : (dbar ^ 2 / (8 * κd)) / (2 * κ) ≤ cap := by
    convert! hcap using 1; ring
  intro t ht
  exact (scalar_comparison hκ hc hd hb t ht).trans
    (envelope_below_cap hκ ht.1 h₀ hb')

/-- Conditional crown safety, obtained from derivatives and scalar comparison. -/
theorem crown_barrier_invariant {B B' : ℝ → ℝ} {T γ : ℝ}
    (hc : ContinuousOn B (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt B (B' t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, -γ * B t ≤ B' t) (h₀ : 0 ≤ B 0) :
    ∀ t ∈ Icc 0 T, 0 ≤ B t := by
  have hcomp := le_gronwallBound_of_liminf_deriv_right_le hc.neg
    (fun t ht _ hr => (hd t ht).neg.liminf_right_slope_le hr)
    (le_refl (-B 0)) (K := -γ) (ε := 0)
    (by intro t ht; simp only [Pi.neg_apply]; linarith [hb t ht])
  intro t ht
  have h := hcomp t ht
  rw [gronwallBound_ε0] at h
  simp only [Pi.neg_apply] at h
  have hp := exp_pos (-γ * (t - 0))
  nlinarith

end
end ChainFountain
