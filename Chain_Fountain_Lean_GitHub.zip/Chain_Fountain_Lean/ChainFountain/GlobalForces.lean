import ChainFountain.GlobalExistence
import ChainFountain.Forces

namespace ChainFountain
noncomputable section
open Set Real

def GlobalTrackingData.accelCap (c : GlobalTrackingData) := c.R₂+
  (c.k₁+c.k₂)*(sqrt (2*c.cap)*sqrt (1+c.k₁^2/c.k₀))+
  (c.k₀+c.k₁*c.k₂)*sqrt (2*c.cap/c.k₀)
def GlobalTrackingData.dampingCap (c : GlobalTrackingData) :=
  c.κd*c.vhi^4/c.hlo*sqrt (8*c.cap)
def GlobalTrackingData.command (c : GlobalTrackingData) (t : ℝ) (x : MechanicalState) :=
  robustInput c.H c.g c.α c.β x.1 x.2.1 x.2.2
    (acceleration c.k₀ c.k₁ c.k₂ (x.1-c.r t) (heightRate x.2.1 x.2.2) (c.r₁ t) (c.r₂ t))
    c.κd (x.2.1-x.2.2-2*c.r₁ t+2*c.k₁*(x.1-c.r t))

/-- Algebraic actuator certificate, containing no unknown trajectory. -/
def GlobalTrackingData.forceCertificate (c : GlobalTrackingData) (uLo uHi : ℝ) : Prop :=
  uLo ≤ lowerInputBound c.H c.g c.α c.β c.hlo c.hhi c.vhi (c.wlo-c.Q) c.whi c.accelCap c.dampingCap ∧
  upperInputBound c.H c.g c.α c.hlo c.hhi c.vlo (c.whi+c.Q) c.accelCap c.dampingCap ≤ uHi ∧
  0 ≤ lowerTensionBound c.H c.g c.β c.hlo c.hhi (c.wlo-c.Q) c.whi c.accelCap-
    c.dampingCap-c.dbar*c.vhi^2

theorem GlobalTrackingData.force_of_energy_box (c : GlobalTrackingData)
    (ha : c.α ≤ 1) (hb : 0 ≤ c.β) {uLo uHi t : ℝ} {x : MechanicalState}
    (hc : c.forceCertificate uLo uHi) (ht : 0 ≤ t) (hbox : x ∈ c.safeBox)
    (hE : c.stateEnergy t x ≤ c.cap) :
    uLo ≤ c.command t x ∧ c.command t x ≤ uHi ∧
      0 ≤ pickup (c.α+c.d t) x.2.1 (c.command t x) := by
  have hR : 0 ≤ c.R₁ := (abs_nonneg _).trans (c.rate_bound 0 le_rfl)
  have hQ : 0 ≤ c.Q := by dsimp [Q]; positivity
  have hf : 2*c.Q < c.wlo := c.forward
  have hvlo : 0 ≤ c.vlo := by dsimp [vlo]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hwlo : 0 ≤ c.wlo := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hslo : 0 ≤ c.wlo-c.Q := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hS : c.wlo-c.Q ≤ (x.2.1+x.2.2)/2 ∧ (x.2.1+x.2.2)/2 ≤ c.whi+c.Q := by
    have hv := hbox.2.1
    have hw := hbox.2.2
    change c.wlo-2*c.Q ≤ x.2.1 ∧ x.2.1 ≤ c.whi+2*c.Q at hv
    constructor <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hv.1,hv.2,hw.1,hw.2]
  have he := error_enclosure (k₁:=c.k₁) c.k₀_pos hE
  have hq : |heightRate x.2.1 x.2.2-c.r₁ t| ≤ sqrt (2*c.cap)*sqrt (1+c.k₁^2/c.k₀) := by
    convert! he.2.2 using 1 <;> congr 1 <;> unfold heightRate <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hA := acceleration_bound c.k₀_pos.le (c.κ_pos.le.trans c.κ_le_k₁)
    (c.κ_pos.le.trans c.κ_le_k₂) he.1 hq (c.accel_bound t ht)
  exact robust_force_feasibility c.H_pos c.g_nonneg ha hb c.height_positive
    hbox.1 (square_interval hvlo hbox.2.1) (square_interval hwlo hbox.2.2).2
    (square_interval hslo hS) hA c.κd_nonneg he.2.1 (c.disturbance_bound t ht)
    hc.1 hc.2.1 hc.2.2

/-- Global physical actuation: construct the trajectory and then certify its
actual unfiltered command and pickup tension at every nonnegative time. -/
theorem GlobalTrackingData.exists_global_admissible (c : GlobalTrackingData)
    (ha : c.α ≤ 1) (hb : 0 ≤ c.β) (uLo uHi : ℝ)
    (hc : c.forceCertificate uLo uHi) :
    ∃ x : ℝ → MechanicalState, x 0=c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      (∀ t ≥ 0, x t ∈ c.safeBox) ∧
      ∀ t ≥ 0, c.stateEnergy t (x t) ≤ c.cap ∧ 0 < (x t).1 ∧
        0 < (x t).2.1 ∧ c.vmin ≤ ((x t).2.1+(x t).2.2)/2 ∧
        uLo ≤ c.command t (x t) ∧ c.command t (x t) ≤ uHi ∧
        0 ≤ pickup (c.α+c.d t) (x t).2.1 (c.command t (x t)) := by
  obtain ⟨x,hx,hd,hbnd,hphys⟩ := c.exists_global_physical
  refine ⟨x,hx,hd,hbnd,?_⟩
  intro t ht
  have hp := hphys t ht
  have hu := c.force_of_energy_box ha hb hc ht (hbnd t ht) hp.1
  exact ⟨hp.1,hp.2.1,hp.2.2.2.2.1,hp.2.2.2.2.2,hu⟩

end
end ChainFountain
