import ChainFountain.LocalStability

namespace ChainFountain
noncomputable section
open Set Metric Real
set_option maxHeartbeats 800000

theorem open_loop_equilibrium_of_balances {H g α β h s : ℝ}
    (hh : h≠0) (hH : H+h≠0)
    (he₁ : α*s^2=g*h) (he₂ : (1-β)*s^2=g*(H+h)) :
    openLoopField H g α β (h,s,s)=0 := by
  apply Prod.ext
  · simp [openLoopField,heightRate]
  · apply Prod.ext
    · change (crownSq s s-(1-α)*s^2-g*h-0)/h=0
      apply (div_eq_zero_iff).mpr
      left
      unfold crownSq
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [he₁]
    · simp [openLoopField,fall,crownSq]
      field_simp
      linear_combination -he₂

/-- Theorem 4.1's nonlinear conclusion. For each sufficiently close initial
state an actual forward-global solution is constructed, remains in h>0, and
converges exponentially to the positive uncontrolled equilibrium. -/
theorem open_loop_local_exponential_unique {H g α β h s : ℝ}
    (hH : 0<H) (hh : 0<h) (hs : 0<s) (ha : 0<α) (hb : 0≤β)
    (hab : α+β<1/2)
    (he₁ : α*s^2=g*h) (he₂ : (1-β)*s^2=g*(H+h)) :
    ∃ δ C κ : ℝ, 0<δ ∧ 0<C ∧ 0<κ ∧
      ∀ x₀ : State₃, ‖x₀-(h,s,s)‖<δ → ∃ x : ℝ → State₃,
        x 0=x₀ ∧ (∀ t≥0, HasDerivAt x (openLoopField H g α β (x t)) t) ∧
        (∀ t≥0, 0<(x t).1 ∧ ‖x t-(h,s,s)‖≤ C*exp (-κ*t)*‖x₀-(h,s,s)‖) ∧
        ∀ T ≥ 0, ∀ z : ℝ → State₃, z 0 = x₀ →
          (∀ t ∈ Icc 0 T, HasDerivAt z (openLoopField H g α β (z t)) t) →
          EqOn x z (Icc 0 T) := by
  have hHp : 0<H+h := add_pos hH hh
  have hρ : 0<h/(H+h) := div_pos hh hHp
  have hρ1 : h/(H+h)<1 := (div_lt_one hHp).mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith)
  have hω : 0<s/h := div_pos hs hh
  have hrel : α=(1-β)*(h/(H+h)) := by
    rw [← mul_div_assoc]
    apply (eq_div_iff hHp.ne').mpr
    apply mul_right_cancel₀ (sq_pos_of_pos hs).ne'
    linear_combination (H+h)*he₁-h*he₂
  let A := paperJacobian α β (h/(H+h)) (s/h)
  let B := plantBilin α β (h/(H+h)) (s/h)
  let F : State₃ → State₃ := fun y => openLoopField H g α β ((h,s,s)+y)
  have hder : HasFDerivAt F A 0 := by
    have hc := (hasFDerivAt_id (𝕜:=ℝ) (0:State₃)).const_add (h,s,s)
    have hd := open_loop_frechet_derivative hh.ne' hHp.ne' he₁ he₂
    have hd' : HasFDerivAt (openLoopField H g α β) A ((h,s,s)+(0:State₃)) := by
      simpa [A] using! hd
    simpa [F,A] using! hd'.comp (0:State₃) hc
  have hz : F 0=0 := by
    simpa [F] using! open_loop_equilibrium_of_balances hh.ne' hHp.ne' he₁ he₂
  have hcoord (x : State₃) : |x.1|≤‖x‖ := by
    simpa [Prod.norm_def,Real.norm_eq_abs] using! (le_max_left |x.1| (max |x.2.1| |x.2.2|))
  have hpositive (y : State₃) (hy : y∈ball 0 (h/2)) : 0<h+y.1 := by
    have hn : ‖y‖<h/2 := by simpa [mem_ball,dist_zero_right] using! hy
    have hc := (abs_le.mp (hcoord y)).1
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hsm : ContDiffOn ℝ 1 F (ball 0 (h/2)) := by
    intro y hy
    have hp := hpositive y hy
    have hpH : 0<H+(h+y.1) := add_pos hH hp
    apply ContDiffAt.contDiffWithinAt
    dsimp [F,openLoopField,heightRate,rise,fall,crownSq]
    fun_prop (disch := first | exact hp.ne' | exact hpH.ne' | norm_num)
  have hly := plant_strict_lyapunov ha (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) hρ hρ1 hω hrel
  obtain ⟨δ,C,κ,hδ,hC,hκ,hsol⟩ := local_exponential_exists_unique_of_quadratic
    (by positivity : 0<h/2) hsm hder hz B hly.1 hly.2
  refine ⟨δ,C,κ,hδ,hC,hκ,fun x₀ hx₀ => ?_⟩
  obtain ⟨y,hy₀,hyD,hyB,hyU⟩ := hsol (x₀-(h,s,s)) hx₀
  refine ⟨fun t => (h,s,s)+y t,by simp [hy₀],(fun t ht => ?_),(fun t ht => ?_),?_⟩
  · simpa [F] using! (hyD t ht).const_add (h,s,s)
  · exact ⟨hpositive (y t) (hyB t ht).1,by simpa using! (hyB t ht).2⟩

  · intro T hT z hz hzD
    have heq := hyU T hT (fun t => z t-(h,s,s)) (by simp [hz]) (by
      intro t ht
      simpa [F] using (hzD t ht).sub_const (h,s,s))
    intro t ht
    have hh := heq ht
    dsimp only at hh
    change (h,s,s)+y t=z t
    rw [hh]
    abel

/-- The nonlinear existence and exponential decay statement, with uniqueness
available in `open_loop_local_exponential_unique`. -/
theorem open_loop_local_exponential {H g α β h s : ℝ}
    (hH : 0<H) (hh : 0<h) (hs : 0<s) (ha : 0<α) (hb : 0≤β)
    (hab : α+β<1/2)
    (he₁ : α*s^2=g*h) (he₂ : (1-β)*s^2=g*(H+h)) :
    ∃ δ C κ : ℝ, 0<δ ∧ 0<C ∧ 0<κ ∧
      ∀ x₀ : State₃, ‖x₀-(h,s,s)‖<δ → ∃ x : ℝ → State₃,
        x 0=x₀ ∧ (∀ t≥0, HasDerivAt x (openLoopField H g α β (x t)) t) ∧
        ∀ t≥0, 0<(x t).1 ∧ ‖x t-(h,s,s)‖≤ C*exp (-κ*t)*‖x₀-(h,s,s)‖ := by
  obtain ⟨δ,C,κ,hδ,hC,hκ,hsol⟩ :=
    open_loop_local_exponential_unique hH hh hs ha hb hab he₁ he₂
  refine ⟨δ,C,κ,hδ,hC,hκ,?_⟩
  intro x₀ hx₀
  obtain ⟨x,hx,hd,hb,hu⟩ := hsol x₀ hx₀
  exact ⟨x,hx,hd,hb⟩

end
end ChainFountain
