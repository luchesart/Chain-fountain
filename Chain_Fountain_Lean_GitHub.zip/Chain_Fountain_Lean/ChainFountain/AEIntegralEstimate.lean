import ChainFountain.AEComparison
import ChainFountain.IntegralEstimate

namespace ChainFountain
noncomputable section
open Set Real Filter MeasureTheory intervalIntegral
open scoped Topology NNReal

/-- A Lipschitz restriction has an integrable derivative and satisfies FTC.
The proof uses the constant extension outside the interval. -/
theorem lipschitzOn_integral_deriv {f : ℝ → ℝ} {L : ℝ≥0} {a b : ℝ}
    (hab : a≤ b) (hf : LipschitzOnWith L f (Icc a b)) :
    IntervalIntegrable (deriv f) volume a b ∧
      (∫ t in a..b, deriv f t)=f b-f a := by
  by_cases heq : a=b
  · subst b
    simp
  have hab' : a<b := lt_of_le_of_ne hab heq
  let g : ℝ → ℝ := fun t => f (projIcc a b hab t)
  have hgl : LipschitzWith L g := by
    simpa only [mul_one,Function.comp_def,Set.restrict_apply] using!
      hf.to_restrict.comp (LipschitzWith.projIcc hab)
  have he (t : ℝ) (ht : t∈Ioo a b) : g =ᶠ[𝓝 t] f := by
    filter_upwards [Ioo_mem_nhds ht.1 ht.2] with s hs
    simp [g,projIcc_of_mem hab (Ioo_subset_Icc_self hs)]
  have hne : ∀ᵐ t ∂volume, t≠b := by
    simp [ae_iff,measure_singleton]
  have hde : deriv f =ᵐ[volume.restrict (Ioc a b)] deriv g := by
    filter_upwards [ae_restrict_of_ae hne,ae_restrict_mem measurableSet_Ioc] with t htb ht
    exact ((he t ⟨ht.1,lt_of_le_of_ne ht.2 htb⟩).deriv_eq).symm
  have hgi : IntegrableOn (deriv g) (Ioc a b) := by
    apply (integrable_const (L:ℝ)).mono' (aestronglyMeasurable_deriv _ _)
    exact Eventually.of_forall (fun _ => norm_deriv_le_of_lipschitz hgl)
  have hi : IntervalIntegrable (deriv f) volume a b :=
    (intervalIntegrable_iff_integrableOn_Ioc_of_le hab).mpr (hgi.congr hde.symm)
  refine ⟨hi,?_⟩
  have hInt : (∫ t in a..b, deriv f t)=(∫ t in a..b, deriv g t) := by
    rw [integral_of_le hab,integral_of_le hab]
    exact integral_congr_ae hde
  rw [hInt,lipschitz_integral_deriv hgl hab]
  simp [g,projIcc_of_mem hab (left_mem_Icc.mpr hab),projIcc_of_mem hab (right_mem_Icc.mpr hab)]

/-- Dissipation integrated for a.e. derivatives; the FTC and derivative
integrability are proved from Lipschitz regularity, not assumed. -/
theorem weighted_integral_estimate_ae {V d : ℝ → ℝ} {L : ℝ≥0} {T κ κd : ℝ}
    (hT : 0≤ T) (hκ : 0<κ) (hκd : 0<κd)
    (hV : LipschitzOnWith L V (Icc 0 T))
    (hd : IntervalIntegrable (fun t => d t^2) volume 0 T)
    (hb : ∀ᵐ t ∂volume, t∈Ioo 0 T → deriv V t≤ -2*κ*V t+d t^2/(8*κd))
    (hVT : 0≤ V T) :
    (∫ t in (0:ℝ)..T, 2*V t)≤ V 0/κ+(1/(8*κ*κd))*(∫ t in (0:ℝ)..T, d t^2) := by
  obtain ⟨hVp,hFTC⟩ := lipschitzOn_integral_deriv hT hV
  have hVi : IntervalIntegrable V volume 0 T := hV.continuousOn.intervalIntegrable_of_Icc hT
  have hne : ∀ᵐ t ∂volume, t≠T := by
    simp [ae_iff,measure_singleton]
  have hi : (∫ t in (0:ℝ)..T, deriv V t)≤
      ∫ t in (0:ℝ)..T, -2*κ*V t+d t^2/(8*κd) := by
    rw [integral_of_le hT,integral_of_le hT]
    apply integral_mono_ae hVp.1 (((hVi.const_mul (-2*κ)).add (hd.div_const (8*κd))).1)
    filter_upwards [ae_restrict_of_ae hb,ae_restrict_of_ae hne,
      ae_restrict_mem measurableSet_Ioc] with t ht hn hm
    exact ht ⟨hm.1,lt_of_le_of_ne hm.2 hn⟩
  rw [hFTC,intervalIntegral.integral_add (hVi.const_mul (-2*κ)) (hd.div_const (8*κd)),
    intervalIntegral.integral_const_mul,intervalIntegral.integral_div] at hi
  rw [intervalIntegral.integral_const_mul]
  apply (mul_le_mul_iff_right₀ hκ).mp
  have hc₁ : κ*(V 0/κ)=V 0 := by field_simp
  have hc₂ : κ*(1/(8*κ*κd))=1/(8*κd) := by field_simp <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hc₃ : κ*(1/(8*κ*κd)*(∫ t in (0:ℝ)..T, d t^2))=
      (∫ t in (0:ℝ)..T, d t^2)/(8*κd) := by
    rw [←mul_assoc,hc₂]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [mul_add,hc₁,hc₃]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hi]

theorem robust_error_integral_ae {e z G d : ℝ → ℝ} {T k₀ k₁ k₂ κ κd : ℝ}
    {Le Lz : ℝ≥0} (hT : 0≤ T) (hk₀ : 0≤ k₀) (hκ : 0<κ)
    (hk₁ : κ≤ k₁) (hk₂ : κ≤ k₂) (hκd : 0<κd)
    (hel : LipschitzOnWith Le e (Icc 0 T)) (hzl : LipschitzOnWith Lz z (Icc 0 T))
    (he : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt e (errorRate k₁ (e t) (z t)) t)
    (hz : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt z (zRate k₀ k₂ κd (G t) (d t) (e t) (z t)) t)
    (hd : IntervalIntegrable (fun t => d t^2) volume 0 T) :
    (∫ t in (0:ℝ)..T, 2*errorEnergy k₀ (e t) (z t))≤
      errorEnergy k₀ (e 0) (z 0)/κ+(1/(8*κ*κd))*(∫ t in (0:ℝ)..T, d t^2) := by
  have hsm : ContDiff ℝ 1 (fun p : ℝ×ℝ => errorEnergy k₀ p.1 p.2) := by
    unfold errorEnergy
    fun_prop (disch := norm_num)
  obtain ⟨L,hL⟩ := smooth_comp_lipschitzOn hsm (hel.prodMk hzl)
  apply weighted_integral_estimate_ae hT hκ hκd hL hd _ (energy_nonneg hk₀ _ _)
  filter_upwards [he,hz] with t het hzt ht
  rw [(energy_hasDerivAt_errors (het ht) (hzt ht)).deriv]
  simpa only [sq_abs] using! robust_decay_uniform (G:=G t) (e:=e t) (z:=z t)
    hk₀ hk₁ hk₂ hκd (le_rfl : |d t|≤|d t|)

/-- Passing finite-horizon dissipation bounds to the entire half-line also
proves output integrability. It cannot be bypassed by a nonintegrable Bochner
integral evaluating to zero. -/
theorem halfline_integral_estimate {V d : ℝ → ℝ} {A B : ℝ}
    (hV : ContinuousOn V (Ici 0)) (hn : ∀ t≥0, 0≤ V t) (hB : 0≤ B)
    (hd : IntegrableOn (fun t => d t^2) (Ioi 0))
    (hbound : ∀ T≥0, (∫ t in (0:ℝ)..T, V t)≤ A+B*(∫ t in (0:ℝ)..T, d t^2)) :
    IntegrableOn V (Ioi 0) ∧ (∫ t in Ioi 0, V t)≤ A+B*(∫ t in Ioi 0, d t^2) := by
  have hfi (T : ℝ) : IntegrableOn V (Ioc 0 T) := by
    exact (hV.mono (fun _ ht => ht.1)).integrableOn_Icc.mono_set Ioc_subset_Icc_self
  have hle (T : ℝ) (hT : 0≤ T) : (∫ t in (0:ℝ)..T, d t^2)≤∫ t in Ioi 0, d t^2 := by
    rw [integral_of_le hT]
    exact setIntegral_mono_set hd (Eventually.of_forall (fun t => sq_nonneg (d t)))
      (Filter.Eventually.of_forall (fun t (ht : t∈Ioc (0:ℝ) T) => ht.1))
  have hVi : IntegrableOn V (Ioi 0) := by
    apply integrableOn_Ioi_of_intervalIntegral_norm_bounded
      (A+B*(∫ t in Ioi 0, d t^2)) 0 hfi tendsto_id
    filter_upwards [eventually_ge_atTop (0:ℝ)] with T hT
    have he : (∫ t in (0:ℝ)..T, ‖V t‖)=(∫ t in (0:ℝ)..T, V t) := by
      apply intervalIntegral.integral_congr
      intro t ht
      rw [uIcc_of_le hT] at ht
      exact Real.norm_of_nonneg (hn t ht.1)
    rw [he]
    exact (hbound T hT).trans (add_le_add (le_refl A) (mul_le_mul_of_nonneg_left (hle T hT) hB))
  refine ⟨hVi,?_⟩
  exact le_of_tendsto_of_tendsto
    (intervalIntegral_tendsto_integral_Ioi 0 hVi tendsto_id)
    (tendsto_const_nhds.add ((intervalIntegral_tendsto_integral_Ioi 0 hd tendsto_id).const_mul B))
    ((eventually_ge_atTop (0:ℝ)).mono (fun T hT => hbound T hT))

end
end ChainFountain
