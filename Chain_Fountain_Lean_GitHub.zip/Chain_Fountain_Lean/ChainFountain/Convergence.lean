import ChainFountain.Invariance

namespace ChainFountain
noncomputable section
open Set Real

/-- A checked comparison for a stable scalar equation with exponentially
decaying forcing. The constant M is an explicit supersolution amplitude. -/
theorem scalar_exponential_decay {y a f : ℝ → ℝ} {T ρ δ M : ℝ}
    (ha : ContinuousOn a (Icc 0 T))
    (hy : ContinuousOn y (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt y (-a t*y t+f t) (Ici t) t)
    (hM : 0 ≤ M)
    (hdecay : ∀ t ∈ Ico 0 T, ρ+δ ≤ a t)
    (hforce : ∀ t ∈ Ico 0 T, |f t| ≤ δ*M*exp (-ρ*t))
    (hinit : |y 0| ≤ M) :
    ∀ t ∈ Icc 0 T, |y t| ≤ M*exp (-ρ*t) := by
  have hE (t : ℝ) : HasDerivAt (fun s => M*exp (-ρ*s))
      (-ρ*(M*exp (-ρ*t))) t := by
    convert! (((hasDerivAt_id t).const_mul (-ρ)).exp.const_mul M) using 1; simp only [id_eq]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hEc : Continuous (fun t => M*exp (-ρ*t)) := by fun_prop
  have hup := linear_sign_preservation_on ha.neg (hy.sub hEc.continuousOn)
    (fun t ht => (hd t ht).sub (hE t).hasDerivWithinAt) (by
      intro t ht
      have hp := mul_le_mul_of_nonneg_right (hdecay t ht)
        (mul_nonneg hM (exp_pos (-ρ*t)).le)
      have hf := (abs_le.mp (hforce t ht)).2
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith) (by simpa using (sub_nonpos.mpr (abs_le.mp hinit).2))
  have hlo := linear_sign_preservation_on ha.neg (hy.neg.sub hEc.continuousOn)
    (fun t ht => (hd t ht).neg.sub (hE t).hasDerivWithinAt) (by
      intro t ht
      have hp := mul_le_mul_of_nonneg_right (hdecay t ht)
        (mul_nonneg hM (exp_pos (-ρ*t)).le)
      have hf := (abs_le.mp (hforce t ht)).1
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith) (by simpa using (show -y 0-M ≤ 0 by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(abs_le.mp hinit).1]))
  intro t ht
  exact abs_le.mpr ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hlo t ht],by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hup t ht]⟩

/-- Explicit amplitude for every rate strictly below the damping and forcing
rates, including the equal-rate case without a singular convolution formula. -/
theorem forced_exponential_estimate {y a f : ℝ → ℝ} {T a₀ κ ρ F : ℝ}
    (ha : ContinuousOn a (Icc 0 T))
    (hy : ContinuousOn y (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt y (-a t*y t+f t) (Ici t) t)
    (hρ : ρ < a₀) (hκ : ρ ≤ κ) (hF : 0 ≤ F)
    (hdecay : ∀ t ∈ Ico 0 T, a₀ ≤ a t)
    (hforce : ∀ t ∈ Ico 0 T, |f t| ≤ F*exp (-κ*t)) :
    ∀ t ∈ Icc 0 T, |y t| ≤ (|y 0|+F/(a₀-ρ))*exp (-ρ*t) := by
  have hδ : 0 < a₀-ρ := sub_pos.mpr hρ
  have hamp : F ≤ (a₀-ρ)*(|y 0|+F/(a₀-ρ)) := by
    have hid : (a₀-ρ)*(F/(a₀-ρ))=F := by field_simp
    rw [mul_add,hid]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_nonneg hδ.le (abs_nonneg (y 0))]
  apply scalar_exponential_decay (δ:=a₀-ρ) ha hy hd (by positivity)
    (by intro t ht; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hdecay t ht])
    (by
      intro t ht
      have he : exp (-κ*t) ≤ exp (-ρ*t) := exp_le_exp.mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [ht.1])
      exact (hforce t ht).trans ((mul_le_mul_of_nonneg_left he hF).trans
        (mul_le_mul_of_nonneg_right hamp (exp_pos _).le)))
    (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [div_nonneg hF hδ.le])

/-- The forcing term in the internal-state equation inherits the tracking rate. -/
theorem internal_forcing_bound {g e q w D D₀ Ce Cq W κ t : ℝ}
    (hD₀ : 0 < D₀) (hD : D₀ ≤ D) (hCe : 0 ≤ Ce) (hCq : 0 ≤ Cq)
    (hW : 0 ≤ W) (hκ : 0 ≤ κ) (ht : 0 ≤ t)
    (he : |e| ≤ Ce*exp (-κ*t)) (hq : |q| ≤ Cq*exp (-κ*t))
    (hw : |w| ≤ W) :
    |(g*e-2*q*w-q^2)/D| ≤
      ((|g| *Ce+2*Cq*W+Cq^2)/D₀)*exp (-κ*t) := by
  have hE0 : 0 ≤ exp (-κ*t) := (exp_pos _).le
  have hE1 : exp (-κ*t) ≤ 1 := exp_le_one_iff.mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith)
  have he' := mul_le_mul_of_nonneg_left he (abs_nonneg g)
  have hq' := mul_le_mul hq hw (abs_nonneg w) (by positivity : 0 ≤ Cq*exp (-κ*t))
  have hq2 : q^2 ≤ Cq^2*exp (-κ*t) := by
    have hq0 : |q| ≤ Cq := hq.trans (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith)
    have hm := mul_le_mul hq hq0 (abs_nonneg q) (by positivity : 0 ≤ Cq*exp (-κ*t))
    rw [←sq, sq_abs] at hm
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
  have hn : |g*e-2*q*w-q^2| ≤ (|g| *Ce+2*Cq*W+Cq^2)*exp (-κ*t) := by
    have h₁ := abs_sub (g*e-2*q*w) (q^2)
    have h₂ := abs_sub (g*e) (2*q*w)
    simp only [abs_mul,abs_of_nonneg (sq_nonneg q),abs_of_nonneg (show (0:ℝ) ≤ 2 by norm_num)] at h₁ h₂
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
  have hDpos : 0 < D := hD₀.trans_le hD
  rw [abs_div,abs_of_pos hDpos]
  calc
    |g*e-2*q*w-q^2|/D ≤ ((|g| *Ce+2*Cq*W+Cq^2)*exp (-κ*t))/D :=
      div_le_div_of_nonneg_right hn hDpos.le
    _ ≤ ((|g| *Ce+2*Cq*W+Cq^2)*exp (-κ*t))/D₀ :=
      div_le_div_of_nonneg_left (by positivity) hD₀ hD
    _ = _ := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- Exponential energy decay yields exponential coordinate bounds, with exact
constants from the weighted energy ellipsoid. -/
theorem error_decay_enclosure {k₀ k₁ e z V₀ κ t : ℝ} (hk : 0 < k₀)
    (hV₀ : 0 ≤ V₀)
    (hV : errorEnergy k₀ e z ≤ exp (-2*κ*t)*V₀) :
    |e| ≤ sqrt (2*V₀/k₀)*exp (-κ*t) ∧
    |z/2-k₁*e| ≤ (sqrt (2*V₀)*sqrt (1+k₁^2/k₀))*exp (-κ*t) := by
  have he := error_height_sq hk hV
  have hq := error_q_sq (k₁:=k₁) hk hV
  have hexp : exp (-κ*t)^2=exp (-2*κ*t) := by rw [sq,←exp_add]; congr 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hs₁ : sqrt (2*V₀/k₀)^2=2*V₀/k₀ := sq_sqrt (by positivity)
  have hs₂ : sqrt (2*V₀)^2=2*V₀ := sq_sqrt (by positivity)
  have hs₃ : sqrt (1+k₁^2/k₀)^2=1+k₁^2/k₀ := sq_sqrt (by positivity)
  constructor
  · apply abs_le_of_sq_le_sq _ (by positivity)
    rw [mul_pow,hs₁,hexp]
    convert! he using 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  · apply abs_le_of_sq_le_sq _ (by positivity)
    rw [mul_pow,mul_pow,hs₂,hs₃,hexp]
    convert! hq using 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- Constant-reference internal-speed convergence on an existing classical
trajectory. Geometric bounds come from the physical-region theorem; e and q
decay bounds come from error_decay_enclosure and nominal tracking. -/
theorem internal_exponential_estimate {h w q : ℝ → ℝ}
    {H g β r wr T hlo hhi wlo whi Ce Cq κ ρ : ℝ}
    (hhc : ContinuousOn h (Icc 0 T)) (hwc : ContinuousOn w (Icc 0 T))
    (hHlo : 0 < H+hlo) (hβ : β < 1) (hwr : 0 ≤ wr) (hwlo : 0 < wlo)
    (hCe : 0 ≤ Ce) (hCq : 0 ≤ Cq) (hκ : 0 ≤ κ)
    (hh : ∀ t ∈ Icc 0 T, hlo ≤ h t ∧ h t ≤ hhi)
    (hw : ∀ t ∈ Icc 0 T, wlo ≤ w t ∧ w t ≤ whi)
    (heq : (1-β)*wr^2=g*(H+r))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt w (internal H g β (h t) (w t) (q t)) (Ici t) t)
    (he : ∀ t ∈ Ico 0 T, |h t-r| ≤ Ce*exp (-κ*t))
    (hq : ∀ t ∈ Ico 0 T, |q t| ≤ Cq*exp (-κ*t))
    (hρ : ρ < (1-β)*(wlo+wr)/(H+hhi)) (hρκ : ρ ≤ κ) :
    ∀ t ∈ Icc 0 T, |w t-wr| ≤
      (|w 0-wr|+((|g| *Ce+2*Cq*whi+Cq^2)/(H+hlo))/
        ((1-β)*(wlo+wr)/(H+hhi)-ρ))*exp (-ρ*t) := by
  by_cases hT : 0 ≤ T
  · have hb : 0 < 1-β := sub_pos.mpr hβ
    have hD (t) (ht : t ∈ Icc 0 T) : 0 < H+h t := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hh t ht).1]
    have hDhi : 0 < H+hhi := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hh 0 ⟨le_refl 0,hT⟩).1,(hh 0 ⟨le_refl 0,hT⟩).2]
    have hwhi : 0 ≤ whi := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hw 0 ⟨le_refl 0,hT⟩).1,(hw 0 ⟨le_refl 0,hT⟩).2]
    let a : ℝ → ℝ := fun t => (1-β)*(w t+wr)/(H+h t)
    let f : ℝ → ℝ := fun t => (g*(h t-r)-2*q t*w t-q t^2)/(H+h t)
    have ha : ContinuousOn a (Icc 0 T) :=
      (continuousOn_const.mul (hwc.add continuousOn_const)).div
        (continuousOn_const.add hhc) (fun t ht => (hD t ht).ne')
    have hder : ∀ t ∈ Ico 0 T, HasDerivWithinAt (fun t => w t-wr)
        (-a t*(w t-wr)+f t) (Ici t) t := by
      intro t ht
      have hi := fullstate_forcing_identity H g β r (h t-r) (q t) (w t) wr
        (by simpa only [add_sub_cancel] using (hD t (Ico_subset_Icc_self ht)).ne') heq
      simp only [add_sub_cancel] at hi
      convert! (hd t ht).sub_const wr using 1
      simpa only [sub_zero,a,f,neg_mul,neg_div] using hi.symm
    apply forced_exponential_estimate ha (hwc.sub continuousOn_const) hder hρ hρκ
      (by positivity)
    · intro t ht
      have htt := Ico_subset_Icc_self ht
      apply (div_le_div_iff₀ hDhi (hD t htt)).mpr
      have h₁ := mul_le_mul_of_nonneg_left (show H+h t ≤ H+hhi by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hh t htt).2])
        (show 0 ≤ (1-β)*(wlo+wr) by positivity)
      have h₂ := mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_left (show wlo+wr ≤ w t+wr by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hw t htt).1])
          (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith : 0 ≤ 1-β)) hDhi.le
      exact h₁.trans h₂
    · intro t ht
      have htt := Ico_subset_Icc_self ht
      exact internal_forcing_bound hHlo (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hh t htt).1]) hCe hCq hwhi hκ ht.1
        (he t ht) (hq t ht) (by rw [abs_of_pos (hwlo.trans_le (hw t htt).1)]; exact (hw t htt).2)
  · intro t ht; exact False.elim (hT (ht.1.trans ht.2))

/-- The rising speed inherits the slower internal/error decay rate. -/
theorem rising_speed_decay {w q wr M Cq κ ρ t : ℝ}
    (hCq : 0 ≤ Cq) (ht : 0 ≤ t) (hρκ : ρ ≤ κ)
    (hw : |w-wr| ≤ M*exp (-ρ*t)) (hq : |q| ≤ Cq*exp (-κ*t)) :
    |w+2*q-wr| ≤ (M+2*Cq)*exp (-ρ*t) := by
  have he : exp (-κ*t) ≤ exp (-ρ*t) := exp_le_exp.mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith)
  have hq' := hq.trans (mul_le_mul_of_nonneg_left he hCq)
  have ha := abs_add_le (w-wr) (2*q)
  simp only [abs_mul,abs_of_nonneg (show (0:ℝ) ≤ 2 by norm_num)] at ha
  have hid : w-wr+2*q=w+2*q-wr := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [hid] at ha
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith

/-- Full-state exponential convergence for a supplied global classical
trajectory. This composes the internal-speed estimate with the tracking bounds;
it does not assert that such a global trajectory has been constructed. -/
theorem constant_reference_fullstate_convergence {h w q : ℝ → ℝ}
    {H g β r wr hlo hhi wlo whi Ce Cq κ ρ : ℝ}
    (hhc : ContinuousOn h (Ici 0)) (hwc : ContinuousOn w (Ici 0))
    (hHlo : 0 < H+hlo) (hβ : β < 1) (hwr : 0 ≤ wr) (hwlo : 0 < wlo)
    (hCe : 0 ≤ Ce) (hCq : 0 ≤ Cq) (hρ0 : 0 < ρ)
    (hh : ∀ t ∈ Ici 0, hlo ≤ h t ∧ h t ≤ hhi)
    (hw : ∀ t ∈ Ici 0, wlo ≤ w t ∧ w t ≤ whi)
    (heq : (1-β)*wr^2=g*(H+r))
    (hd : ∀ t ∈ Ici 0, HasDerivAt w (internal H g β (h t) (w t) (q t)) t)
    (he : ∀ t ∈ Ici 0, |h t-r| ≤ Ce*exp (-κ*t))
    (hq : ∀ t ∈ Ici 0, |q t| ≤ Cq*exp (-κ*t))
    (hρ : ρ < (1-β)*(wlo+wr)/(H+hhi)) (hρκ : ρ ≤ κ) :
    let M := |w 0-wr|+((|g| * Ce+2*Cq*whi+Cq^2)/(H+hlo))/
      ((1-β)*(wlo+wr)/(H+hhi)-ρ)
    0 < ρ ∧ ∀ t ∈ Ici 0,
      |h t-r| ≤ Ce*exp (-ρ*t) ∧
      |w t-wr| ≤ M*exp (-ρ*t) ∧
      |w t+2*q t-wr| ≤ (M+2*Cq)*exp (-ρ*t) := by
  dsimp only
  refine ⟨hρ0,?_⟩
  intro t ht
  have hb := internal_exponential_estimate (T:=t)
    (hhc.mono (fun _ hx => hx.1)) (hwc.mono (fun _ hx => hx.1))
    hHlo hβ hwr hwlo hCe hCq (hρ0.le.trans hρκ)
    (fun s hs => hh s hs.1) (fun s hs => hw s hs.1) heq
    (fun s hs => (hd s hs.1).hasDerivWithinAt)
    (fun s hs => he s hs.1) (fun s hs => hq s hs.1) hρ hρκ t ⟨ht,le_refl t⟩
  have heE : exp (-κ*t) ≤ exp (-ρ*t) := exp_le_exp.mpr (by
    have ht0 : 0 ≤ t := ht
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith)
  exact ⟨(he t ht).trans (mul_le_mul_of_nonneg_left heE hCe),hb,
    rising_speed_decay hCq ht hρκ hb (hq t ht)⟩

end
end ChainFountain
