import ChainFountain.GlobalExistence

namespace ChainFountain
noncomputable section
open Set Real

/-- An explicit, nonstationary nominal instance: height is initially exact,
while the initial transport speed 10 differs from the steady speed sqrt(101).
This checks that the global theorem's hypotheses are jointly satisfiable. -/
def nominalGlobalExample : GlobalTrackingData where
  H := 100
  g := 1
  α := 1/4
  β := 0
  k₀ := 1
  k₁ := 1
  k₂ := 1
  κ := 1
  κd := 0
  dbar := 0
  cap := 0
  rlo := 1
  rhi := 1
  R₁ := 0
  R₂ := 0
  wlo := 5
  whi := 20
  vmin := 1
  r := fun _ => 1
  r₁ := fun _ => 0
  r₂ := fun _ => 0
  d := fun _ => 0
  x₀ := (1,10,10)
  H_pos := by norm_num
  g_nonneg := by norm_num
  k₀_pos := by norm_num
  κ_pos := by norm_num
  κ_le_k₁ := by norm_num
  κ_le_k₂ := by norm_num
  κd_nonneg := by norm_num
  regime := Or.inl rfl
  vmin_pos := by norm_num
  dr := fun t _ => hasDerivAt_const t 1
  dr₁ := fun t _ => hasDerivAt_const t 0
  r₂_cont := continuousOn_const
  d_cont := continuousOn_const
  ref_bounds := by intro t ht; norm_num
  rate_bound := by intro t ht; norm_num
  accel_bound := by intro t ht; norm_num
  disturbance_bound := by intro t ht; norm_num
  initial_energy := by norm_num [errorEnergy]
  disturbance_cap := by norm_num
  height_positive := by norm_num
  forward := by norm_num
  speed_order := by norm_num
  crown := by norm_num
  lower_face_bound := by norm_num
  upper_face_bound := by norm_num
  initial_speed := by norm_num

theorem nominal_example_global_exists :
    ∃ x : ℝ → MechanicalState, x 0 = (1,10,10) ∧
      (∀ t ≥ 0, HasDerivAt x (nominalGlobalExample.field t (x t)) t) ∧
      ∀ t ≥ 0, x t ∈ nominalGlobalExample.safeBox :=
  nominalGlobalExample.exists_global

/-- A genuinely uncertain instance, with nonzero continuous disturbance and
positive error cap, for the same geometry. -/
def robustGlobalExample : GlobalTrackingData :=
  { nominalGlobalExample with
    κd := 1
    dbar := 1/1000
    cap := 1/20000
    d := fun _ => 1/1000
    κd_nonneg := by norm_num
    regime := Or.inr (by norm_num)
    d_cont := continuousOn_const
    disturbance_bound := by
      intro t ht
      change |(1:ℝ)/1000| ≤ 1/1000
      exact le_of_eq (abs_of_nonneg (by positivity))
    initial_energy := by norm_num [nominalGlobalExample,errorEnergy]
    disturbance_cap := by norm_num [nominalGlobalExample]
    height_positive := by norm_num [nominalGlobalExample]
    forward := by
      have hs : sqrt 2 ≤ 2 := (Real.sqrt_le_iff).2 ⟨by norm_num,by norm_num⟩
      norm_num [nominalGlobalExample]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
    crown := by
      have hs : sqrt 2 ≤ 2 := (Real.sqrt_le_iff).2 ⟨by norm_num,by norm_num⟩
      norm_num [nominalGlobalExample]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
    lower_face_bound := by
      have hs : sqrt 2 ≤ 2 := (Real.sqrt_le_iff).2 ⟨by norm_num,by norm_num⟩
      have hsq : (sqrt 2)^2=2 := Real.sq_sqrt (by norm_num)
      norm_num [nominalGlobalExample]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
    upper_face_bound := by
      have hs : sqrt 2 ≤ 2 := (Real.sqrt_le_iff).2 ⟨by norm_num,by norm_num⟩
      have hsq : (sqrt 2)^2=2 := Real.sq_sqrt (by norm_num)
      norm_num [nominalGlobalExample]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith }

theorem robust_example_global_exists :
    ∃ x : ℝ → MechanicalState, x 0 = (1,10,10) ∧
      (∀ t ≥ 0, HasDerivAt x (robustGlobalExample.field t (x t)) t) ∧
      ∀ t ≥ 0, x t ∈ robustGlobalExample.safeBox :=
  robustGlobalExample.exists_global

end
end ChainFountain
