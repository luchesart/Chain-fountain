import ChainFountain.MeasurableForces
import ChainFountain.AEIntegralEstimate

namespace ChainFountain
noncomputable section
open Set Real MeasureTheory Filter
open scoped NNReal

theorem GlobalTrackingData.measurable_energy_dissipation (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) {x : ℝ → MechanicalState}
    (hh : ∀ t≥0, 0<(x t).1)
    (hxD : ∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) :
    ∀ᵐ t ∂volume, 0≤ t →
      deriv (fun s => c.stateEnergy s (x s)) t≤
        -2*c.κ*c.stateEnergy t (x t)+d t^2/(8*c.κd) := by
  let h := fun t => (x t).1
  let v := fun t => (x t).2.1
  let w := fun t => (x t).2.2
  filter_upwards [hxD] with t hdt ht
  have dh : HasDerivAt h (heightRate (v t) (w t)) t := by
    simpa [h,v,w,measurableField,jointField] using! hasFDerivAt_fst.comp_hasDerivAt t (hdt ht)
  have dv : HasDerivAt v (rise c.g (c.α+d t) (h t) (v t) (w t)
      (requestedInput c.H c.g c.α c.β c.k₀ c.k₁ c.k₂ c.κd h v w c.r c.r₁ c.r₂ t)) t := by
    simpa [h,v,w,measurableField,measurableParameters,jointField,parameters,max_eq_right ht,
      requestedInput,heightError,velocityError] using!
      hasFDerivAt_fst.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t (hdt ht))
  have dw : HasDerivAt w (fall c.H c.g c.β (h t) (v t) (w t)) t := by
    simpa [h,v,w,measurableField,jointField] using!
      hasFDerivAt_snd.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t (hdt ht))
  obtain ⟨he,hz⟩ := closed_loop_error_equations (hh t ht).ne'
    (add_pos c.H_pos (hh t ht)).ne' dh dv dw (c.dr t ht) (c.dr₁ t ht)
  have hV := energy_hasDerivAt_errors he hz
  have heq : (fun s => c.stateEnergy s (x s))=
      fun s => errorEnergy c.k₀ (heightError h c.r s) (velocityError c.k₁ h v w c.r c.r₁ s) := rfl
  rw [heq,hV.deriv]
  simpa only [sq_abs] using! robust_decay_uniform
    (e:=heightError h c.r t) (z:=velocityError c.k₁ h v w c.r c.r₁ t) (G:=(v t)^2/h t)
    c.k₀_pos.le c.κ_le_k₁ c.κ_le_k₂ hκd (le_rfl : |d t|≤|d t|)

theorem GlobalTrackingData.measurable_energy_integral (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) {x : ℝ → MechanicalState} {K : ℝ≥0}
    (hxL : LipschitzWith K x) (hh : ∀ t≥0, 0<(x t).1)
    (hxD : ∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t)
    {T : ℝ} (hT : 0≤ T) (hd : IntervalIntegrable (fun t => d t^2) volume 0 T) :
    (∫ t in (0:ℝ)..T, 2*c.stateEnergy t (x t))≤
      c.stateEnergy 0 (x 0)/c.κ+(1/(8*c.κ*c.κd))*(∫ t in (0:ℝ)..T, d t^2) := by
  obtain ⟨Le,Lz,he,hz⟩ := c.errors_lipschitz hxL T
  have hsm : ContDiff ℝ 1 (fun p : ℝ×ℝ => errorEnergy c.k₀ p.1 p.2) := by
    unfold errorEnergy
    fun_prop (disch := norm_num)
  obtain ⟨L,hL⟩ := smooth_comp_lipschitzOn hsm (he.prodMk hz)
  exact weighted_integral_estimate_ae hT c.κ_pos hκd hL hd
    ((c.measurable_energy_dissipation hκd hh hxD).mono (fun t ht hmem => ht hmem.1.le))
    (energy_nonneg c.k₀_pos.le _ _)

/-- A global physical trajectory is constructed for the finite-energy bounded
measurable disturbance, and its entire weighted output energy is finite. -/
theorem GlobalTrackingData.exists_global_L2_tracking (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : AEMeasurable d volume)
    (hdb : ∀ t, |d t|≤ c.dbar) (hd : IntegrableOn (fun t => d t^2) (Ioi 0)) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      IntegrableOn (fun t => 2*c.stateEnergy t (x t)) (Ioi 0) ∧
      (∫ t in Ioi 0, 2*c.stateEnergy t (x t))≤
        c.stateEnergy 0 c.x₀/c.κ+(1/(8*c.κ*c.κd))*(∫ t in Ioi 0, d t^2) := by
  obtain ⟨x,K,hxL,hx₀,hxD,hbox,hE⟩ := c.exists_global_aemeasurable_tracking hκd hdm hdb
  have hh (t : ℝ) (ht : 0≤ t) : 0<(x t).1 :=
    c.height_positive.trans_le (hbox t ht).1.1
  have hcont : ContinuousOn (fun t => 2*c.stateEnergy t (x t)) (Ici 0) := by
    have hr : ContinuousOn c.r (Ici 0) := fun t ht => (c.dr t ht).continuousAt.continuousWithinAt
    have hr₁ : ContinuousOn c.r₁ (Ici 0) := fun t ht => (c.dr₁ t ht).continuousAt.continuousWithinAt
    have hc := hxL.continuous.continuousOn (s:=Ici (0:ℝ))
    unfold stateEnergy errorEnergy
    fun_prop
  have hbound (T : ℝ) (hT : 0≤ T) := c.measurable_energy_integral hκd hxL hh hxD hT
    ((intervalIntegrable_iff_integrableOn_Ioc_of_le hT).mpr (hd.mono_set Ioc_subset_Ioi_self))
  have hglobal := halfline_integral_estimate hcont
    (fun t _ => mul_nonneg (by norm_num) (energy_nonneg c.k₀_pos.le _ _))
    (div_nonneg zero_le_one (mul_nonneg (mul_nonneg (by norm_num) c.κ_pos.le) hκd.le))
    hd hbound
  exact ⟨x,K,hxL,hx₀,hxD,hbox,hglobal.1,by simpa [hx₀] using! hglobal.2⟩

/-- The half-line square-integral estimate is the usual L² norm gain. Both
signals are proved members of `MemLp 2`, so no nonintegrable zero-integral
convention can make this assertion vacuous. -/
theorem weighted_L2_gain {V d : ℝ → ℝ} {μ : Measure ℝ} {B : ℝ}
    (hV : AEStronglyMeasurable V μ) (hd : AEStronglyMeasurable d μ)
    (hn : ∀ᵐ t ∂μ, 0≤ V t) (hVi : Integrable V μ)
    (hdi : Integrable (fun t => d t^2) μ) (hB : 0≤ B)
    (hbound : (∫ t, V t ∂μ)≤ B*(∫ t, d t^2 ∂μ)) :
    MemLp (fun t => sqrt (V t)) 2 μ ∧ MemLp d 2 μ ∧
      sqrt (∫ t, (sqrt (V t))^2 ∂μ)≤ sqrt B*sqrt (∫ t, d t^2 ∂μ) := by
  have heq : (fun t => (sqrt (V t))^2)=ᵐ[μ] V := hn.mono (fun t ht => sq_sqrt ht)
  have hsq : Integrable (fun t => (sqrt (V t))^2) μ := hVi.congr heq.symm
  refine ⟨(memLp_two_iff_integrable_sq (Real.continuous_sqrt.comp_aestronglyMeasurable hV)).mpr hsq,
    (memLp_two_iff_integrable_sq hd).mpr hdi,?_⟩
  rw [integral_congr_ae heq,←sqrt_mul hB]
  exact sqrt_le_sqrt hbound

/-- Zero-initial-error L² gain for the actual globally constructed physical
trajectory, with the exact paper constant. -/
theorem GlobalTrackingData.exists_global_L2_gain (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : AEMeasurable d volume)
    (hdb : ∀ t, |d t|≤ c.dbar) (hd : IntegrableOn (fun t => d t^2) (Ioi 0))
    (hzero : c.stateEnergy 0 c.x₀=0) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      MemLp (fun t => sqrt (2*c.stateEnergy t (x t))) 2 (volume.restrict (Ioi 0)) ∧
      MemLp d 2 (volume.restrict (Ioi 0)) ∧
      sqrt (∫ t in Ioi 0, (sqrt (2*c.stateEnergy t (x t)))^2)≤
        sqrt (1/(8*c.κ*c.κd))*sqrt (∫ t in Ioi 0, d t^2) := by
  obtain ⟨x,K,hL,h₀,hD,hbox,hVi,hbound⟩ := c.exists_global_L2_tracking hκd hdm hdb hd
  have hn : ∀ᵐ t ∂(volume.restrict (Ioi 0)), 0≤2*c.stateEnergy t (x t) :=
    Eventually.of_forall (fun _ => mul_nonneg (by norm_num) (energy_nonneg c.k₀_pos.le _ _))
  have hB : 0≤1/(8*c.κ*c.κd) :=
    div_nonneg zero_le_one (mul_nonneg (mul_nonneg (by norm_num) c.κ_pos.le) hκd.le)
  have hb : (∫ t in Ioi 0, 2*c.stateEnergy t (x t))≤
      (1/(8*c.κ*c.κd))*(∫ t in Ioi 0, d t^2) := by simpa [hzero] using! hbound
  exact ⟨x,K,hL,h₀,hD,hbox,weighted_L2_gain hVi.aestronglyMeasurable
    hdm.aestronglyMeasurable.restrict hn hVi hd hB hb⟩

end
end ChainFountain
