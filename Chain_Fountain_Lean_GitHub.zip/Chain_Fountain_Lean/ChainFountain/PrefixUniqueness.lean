import ChainFountain.GlobalExistence

namespace ChainFountain
noncomputable section
open Set Metric Real
open scoped Topology NNReal

/-- A finite-interval first-exit principle. Only continuity on the interval is
required; the curve is neither assumed to be safe nor defined by the ODE later. -/
theorem no_exit_on_Icc_of_prefix_bound
    {E : Type*} [TopologicalSpace E] {x : ℝ → E} {B K : Set E} {T : ℝ}
    (hT : 0 ≤ T) (hx : ContinuousOn x (Icc 0 T))
    (hB : IsClosed B) (hKB : K ⊆ interior B) (hx₀ : x 0 ∈ interior B)
    (hprefix : ∀ S ∈ Icc 0 T, (∀ t ∈ Icc 0 S, x t ∈ B) → x S ∈ K) :
    ∀ t ∈ Icc 0 T, x t ∈ K := by
  let p : ℝ → ℝ := fun t => max 0 (min T t)
  have hp : Continuous p := continuous_const.max (continuous_const.min continuous_id)
  have hpm (t : ℝ) : p t ∈ Icc 0 T :=
    ⟨le_max_left _ _, max_le hT (min_le_left _ _)⟩
  have hpeq (t : ℝ) (ht : t ∈ Icc 0 T) : p t = t := by
    simp only [p, min_eq_right ht.2, max_eq_right ht.1]
  have hstay := no_exit_of_prefix_bound (hx.comp_continuous hp hpm) hB hKB
    (show x (p 0) ∈ interior B by simpa [hpeq 0 ⟨le_rfl,hT⟩] using hx₀) (by
      intro S hS hb
      have hST : min S T ∈ Icc (0:ℝ) T := ⟨le_min hS hT, min_le_right _ _⟩
      have hh := hprefix (min S T) hST (by
        intro t ht
        have htT : t ≤ T := ht.2.trans (min_le_right _ _)
        have htS : t ≤ S := ht.2.trans (min_le_left _ _)
        simpa only [Function.comp_apply, hpeq t ⟨ht.1,htT⟩] using hb t ⟨ht.1,htS⟩)
      simpa only [Function.comp_apply, p, min_comm T S, max_eq_right (le_min hS hT)] using hh)
  intro t ht
  simpa only [Function.comp_apply, hpeq t ht] using hstay t ht.1

/-- An a priori prefix bound turns box-wise Lipschitz uniqueness into
uniqueness against arbitrary classical competitors on every finite interval. -/
theorem unique_on_Icc_of_prefix_bound
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    {F : ℝ → E → E} {B K : Set E} {L : ℝ≥0} {x₀ : E} {T : ℝ}
    (hB : IsClosed B) (hKB : K ⊆ interior B) (hx₀ : x₀ ∈ interior B)
    (hL : ∀ t, LipschitzOnWith L (F t) B)
    (hprefix : ∀ (z : ℝ → E) S, 0 ≤ S → z 0 = x₀ →
      (∀ t ∈ Icc 0 S, z t ∈ B) →
      (∀ t ∈ Icc 0 S, HasDerivAt z (F t (z t)) t) → z S ∈ K)
    {x y : ℝ → E} (hT : 0 ≤ T) (hx : x 0 = x₀) (hy : y 0 = x₀)
    (hdx : ∀ t ∈ Icc 0 T, HasDerivAt x (F t (x t)) t)
    (hdy : ∀ t ∈ Icc 0 T, HasDerivAt y (F t (y t)) t) :
    EqOn x y (Icc 0 T) := by
  have stay (z : ℝ → E) (hz : z 0 = x₀)
      (hd : ∀ t ∈ Icc 0 T, HasDerivAt z (F t (z t)) t) :
      ∀ t ∈ Icc 0 T, z t ∈ B := by
    have hc : ContinuousOn z (Icc 0 T) :=
      fun t ht => (hd t ht).continuousAt.continuousWithinAt
    have hs := no_exit_on_Icc_of_prefix_bound hT hc hB hKB (hz ▸ hx₀) (by
      intro S hS hb
      exact hprefix z S hS.1 hz hb (fun t ht => hd t ⟨ht.1,ht.2.trans hS.2⟩))
    exact fun t ht => interior_subset (hKB (hs t ht))
  exact ODE_solution_unique_of_mem_Icc_right (s := fun _ => B)
    (fun t _ => hL t)
    (fun t ht => (hdx t ht).continuousAt.continuousWithinAt)
    (fun t ht => (hdx t (Ico_subset_Icc_self ht)).hasDerivWithinAt)
    (fun t ht => stay x hx hdx t (Ico_subset_Icc_self ht))
    (fun t ht => (hdy t ht).continuousAt.continuousWithinAt)
    (fun t ht => (hdy t (Ico_subset_Icc_self ht)).hasDerivWithinAt)
    (fun t ht => stay y hy hdy t (Ico_subset_Icc_self ht)) (hx.trans hy.symm)

/-- Every classical mechanical solution from the certified initial data is
safe for its whole supplied interval; no box or positive-height premise. -/
theorem GlobalTrackingData.classical_safe_on_Icc (c : GlobalTrackingData)
    {x : ℝ → MechanicalState} {T : ℝ} (hT : 0 ≤ T) (hx : x 0 = c.x₀)
    (hd : ∀ t ∈ Icc 0 T, HasDerivAt x (c.field t (x t)) t) :
    ∀ t ∈ Icc 0 T, x t ∈ c.safeBox := by
  apply no_exit_on_Icc_of_prefix_bound hT
    (fun t ht => (hd t ht).continuousAt.continuousWithinAt)
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    (hx ▸ c.safeBox_interior c.initial_mem)
  intro S hS hb
  exact c.prefix_bound x S hS.1 hx hb (fun t ht => hd t ⟨ht.1,ht.2.trans hS.2⟩)

/-- Unrestricted finite-interval classical uniqueness, including the nominal
kappa_d = 0 regime. Competitors may have any arbitrary extension outside [0,T]. -/
theorem GlobalTrackingData.classical_unique_on_Icc (c : GlobalTrackingData)
    {x y : ℝ → MechanicalState} {T : ℝ} (hT : 0 ≤ T)
    (hx : x 0 = c.x₀) (hy : y 0 = c.x₀)
    (hdx : ∀ t ∈ Icc 0 T, HasDerivAt x (c.field t (x t)) t)
    (hdy : ∀ t ∈ Icc 0 T, HasDerivAt y (c.field t (y t)) t) :
    EqOn x y (Icc 0 T) := by
  obtain ⟨L,C,hL,hcont,hC⟩ := c.field_bounds
  exact unique_on_Icc_of_prefix_bound
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    (c.safeBox_interior c.initial_mem) hL c.prefix_bound hT hx hy hdx hdy

/-- Global tracking with uniqueness against every classical solution on any
finite forward interval, for both robust and undamped nominal gains. -/
theorem GlobalTrackingData.exists_unique_global_tracking (c : GlobalTrackingData) :
    ∃ x : ℝ → MechanicalState, x 0 = c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      (∀ t ≥ 0, x t ∈ c.safeBox) ∧
      (c.dbar = 0 → ∀ t ≥ 0,
        c.stateEnergy t (x t) ≤ exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀) ∧
      (0 < c.κd → ∀ t ≥ 0,
        c.stateEnergy t (x t) ≤ exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-exp (-2*c.κ*t))) ∧
      ∀ T ≥ 0, ∀ y : ℝ → MechanicalState, y 0 = c.x₀ →
        (∀ t ∈ Icc 0 T, HasDerivAt y (c.field t (y t)) t) → EqOn x y (Icc 0 T) := by
  obtain ⟨x,hx,hd,hb,hn,hr⟩ := c.exists_global_tracking
  refine ⟨x,hx,hd,hb,hn,hr,?_⟩
  intro T hT y hy hdy
  exact c.classical_unique_on_Icc hT hx hy (fun t ht => hd t ht.1) hdy

end
end ChainFountain
