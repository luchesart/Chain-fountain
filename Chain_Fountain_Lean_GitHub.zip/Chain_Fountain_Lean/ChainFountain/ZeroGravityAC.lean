import ChainFountain.AbsoluteContinuity
import ChainFountain.ZeroGravityCirculation

/-!
# Carathéodory circulation under measurable disturbances

The integrating-factor formula constructs the trajectory from its initial value
and a disturbance that is integrable on every forward compact interval. Genuine
absolute continuity, the scalar plant almost everywhere, and its integral form
are conclusions. No candidate solution or regularity before time zero is assumed.
-/

namespace ChainFountain.ZeroGravity
noncomputable section
open Set Filter MeasureTheory Real
open scoped Topology

/-- An a.e. bounded, a.e. measurable forcing is integrable on each forward
compact interval. The bound is imposed only for nonnegative times. -/
theorem forward_intervalIntegrable_of_aebounded {d : ℝ → ℝ} {D : ℝ}
    (hd : AEMeasurable d volume)
    (hb : ∀ᵐ t ∂volume, 0 ≤ t → |d t| ≤ D) :
    ∀ T : ℝ, 0 ≤ T → IntervalIntegrable d volume 0 T := by
  intro T hT
  rw [intervalIntegrable_iff_integrableOn_Ioc_of_le hT]
  apply Measure.integrableOn_of_bounded (by simp) hd.aestronglyMeasurable
  filter_upwards [ae_restrict_of_ae hb, ae_restrict_mem measurableSet_Ioc] with t ht hm
  simpa only [Real.norm_eq_abs] using ht hm.1.le

/-- Only measurability on the forward half-line is needed for local
integrability. Arbitrary negative-time values are immaterial. -/
theorem forward_intervalIntegrable_of_aebounded_restrict {d : ℝ → ℝ} {D : ℝ}
    (hd : AEMeasurable d (volume.restrict (Ici 0)))
    (hb : ∀ᵐ t ∂volume, 0 ≤ t → |d t| ≤ D) :
    ∀ T : ℝ, 0 ≤ T → IntervalIntegrable d volume 0 T := by
  intro T hT
  rw [intervalIntegrable_iff_integrableOn_Ioc_of_le hT]
  have hm : AEStronglyMeasurable d (volume.restrict (Ioc 0 T)) :=
    (hd.mono_measure (Measure.restrict_mono_set volume (by
      intro t ht; exact ht.1.le))).aestronglyMeasurable
  have hconst : Integrable (fun _ : ℝ => D) (volume.restrict (Ioc 0 T)) :=
    integrable_const D
  apply hconst.mono' hm
  filter_upwards [ae_restrict_of_ae hb, ae_restrict_mem measurableSet_Ioc] with t ht hm
  simpa only [Real.norm_eq_abs] using ht hm.1.le

/-- Interior derivatives give the forward a.e. derivative equation, without
requiring a two-sided derivative at the initial time. -/
theorem forward_ae_hasDerivAt_of_pos {r rdot : ℝ → ℝ}
    (hr : ∀ t : ℝ, 0 < t → HasDerivAt r (rdot t) t) :
    ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt r (rdot t) t := by
  filter_upwards [show ∀ᵐ t : ℝ ∂volume, t ≠ 0 from volume.ae_ne 0] with t ht ht0
  exact hr t (lt_of_le_of_ne ht0 (Ne.symm ht))

/-- The explicit integrating-factor solution is genuinely absolutely continuous
on every forward compact interval, even for merely locally integrable forcing. -/
theorem circulation_forcedError_locallyAC {d : ℝ → ℝ} {a e0 : ℝ}
    (hdi : ∀ T : ℝ, 0 ≤ T → IntervalIntegrable d volume 0 T) :
    ∀ T : ℝ, 0 ≤ T →
      AbsolutelyContinuousOnInterval (circulationForcedError d a e0) 0 T := by
  intro T hT
  have hw : IntervalIntegrable (fun s => exp (a * s) * d s) volume 0 T :=
    (hdi T hT).continuousOn_mul (by fun_prop)
  have hI := hw.absolutelyContinuousOnInterval_intervalIntegral (c := 0)
    (by simp)
  have hC : AbsolutelyContinuousOnInterval (fun _ : ℝ => e0) 0 T :=
    (contDiff_const : ContDiff ℝ 1 (fun _ : ℝ => e0)).contDiffOn.absolutelyContinuousOnInterval
  have hE : AbsolutelyContinuousOnInterval (fun t : ℝ => exp (-a * t)) 0 T :=
    (show ContDiff ℝ 1 (fun t : ℝ => exp (-a * t)) by fun_prop).contDiffOn.absolutelyContinuousOnInterval
  exact hE.fun_mul (hC.fun_add hI)

/-- There is one common full-measure set of times on which the explicit
integrating-factor trajectory satisfies its differential equation. -/
theorem circulation_forcedError_ae {d : ℝ → ℝ} {a e0 : ℝ}
    (hdi : ∀ T : ℝ, 0 ≤ T → IntervalIntegrable d volume 0 T) :
    ∀ᵐ t ∂volume, 0 ≤ t →
      HasDerivAt (circulationForcedError d a e0)
        (-a * circulationForcedError d a e0 t + d t) t := by
  have hN : ∀ n : ℕ, ∀ᵐ t ∂volume, t ∈ Icc (0 : ℝ) n →
      HasDerivAt (fun t => ∫ s in (0 : ℝ)..t, exp (a * s) * d s)
        (exp (a * t) * d t) t := by
    intro n
    have hw : IntervalIntegrable (fun s => exp (a * s) * d s) volume 0 (n : ℝ) :=
      (hdi n (Nat.cast_nonneg n)).continuousOn_mul (by fun_prop)
    filter_upwards [hw.ae_hasDerivAt_integral] with t ht hmem
    exact ht (by simpa only [uIcc_of_le (Nat.cast_nonneg n)] using hmem) 0 (by simp)
  have hAll : ∀ᵐ t ∂volume, ∀ n : ℕ, t ∈ Icc (0 : ℝ) n →
      HasDerivAt (fun t => ∫ s in (0 : ℝ)..t, exp (a * s) * d s)
        (exp (a * t) * d t) t := ae_all_iff.mpr hN
  filter_upwards [hAll] with t ht ht0
  obtain ⟨n, hn⟩ := exists_nat_gt t
  have hI := ht n ⟨ht0, hn.le⟩
  have hE := (((hasDerivAt_id t).const_mul (-a)).exp).mul (hI.const_add e0)
  have hexp : exp (-a * t) * exp (a * t) = 1 := by
    rw [← exp_add, show -a * t + a * t = 0 by ring, exp_zero]
  have hcancel := congrArg (fun x : ℝ => x * d t) hexp
  convert! hE using 1
  unfold circulationForcedError
  simp only [id_eq] at *
  nlinarith

/-- The speed constructed from the reference, forcing, and initial speed. -/
def circulationACSolution (r d : ℝ → ℝ) (γ k c0 t : ℝ) : ℝ :=
  r t + circulationForcedError d (γ + k) (c0 - r 0) t

@[simp] theorem circulationACSolution_initial (r d : ℝ → ℝ) (γ k c0 : ℝ) :
    circulationACSolution r d γ k c0 0 = c0 := by
  simp [circulationACSolution, circulationForcedError]

/-- A forward locally absolutely continuous reference yields a constructed
forward locally absolutely continuous speed. -/
theorem circulationACSolution_locallyAC {r d : ℝ → ℝ} {γ k c0 : ℝ}
    (hr : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval r 0 T)
    (hdi : ∀ T : ℝ, 0 ≤ T → IntervalIntegrable d volume 0 T) :
    ∀ T : ℝ, 0 ≤ T →
      AbsolutelyContinuousOnInterval (circulationACSolution r d γ k c0) 0 T := by
  intro T hT
  exact (hr T hT).fun_add (circulation_forcedError_locallyAC hdi T hT)

/-- The constructed speed satisfies the actual feedback-controlled plant a.e.,
with reference feedforward and damping γ+k. -/
theorem circulationACSolution_ae {r rdot d : ℝ → ℝ} {γ k c0 : ℝ}
    (hr : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt r (rdot t) t)
    (hdi : ∀ T : ℝ, 0 ≤ T → IntervalIntegrable d volume 0 T) :
    ∀ᵐ t ∂volume, 0 ≤ t →
      HasDerivAt (circulationACSolution r d γ k c0)
        (circulationCommand γ k (r t) (rdot t) (circulationACSolution r d γ k c0 t)
          - γ * circulationACSolution r d γ k c0 t + d t) t := by
  filter_upwards [hr, circulation_forcedError_ae (a := γ + k) (e0 := c0 - r 0) hdi]
    with t hrt het ht
  convert! (hrt ht).add (het ht) using 1
  simp only [circulationACSolution, circulationCommand]
  ring

/-- The constructed speed obeys the integral plant equation at every forward
time. This is derived from absolute continuity and the a.e. equation. -/
theorem circulationACSolution_integral {r rdot d : ℝ → ℝ} {γ k c0 : ℝ}
    (hrAC : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval r 0 T)
    (hr : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt r (rdot t) t)
    (hdi : ∀ T : ℝ, 0 ≤ T → IntervalIntegrable d volume 0 T) :
    ∀ t : ℝ, 0 ≤ t →
      IntervalIntegrable (fun s =>
        circulationCommand γ k (r s) (rdot s) (circulationACSolution r d γ k c0 s)
          - γ * circulationACSolution r d γ k c0 s + d s) volume 0 t ∧
      circulationACSolution r d γ k c0 t = c0 + ∫ s in (0 : ℝ)..t,
        circulationCommand γ k (r s) (rdot s) (circulationACSolution r d γ k c0 s)
          - γ * circulationACSolution r d γ k c0 s + d s := by
  intro t ht
  have hd : ∀ᵐ s ∂volume, s ∈ uIcc 0 t →
      HasDerivAt (circulationACSolution r d γ k c0)
        (circulationCommand γ k (r s) (rdot s) (circulationACSolution r d γ k c0 s)
          - γ * circulationACSolution r d γ k c0 s + d s) s := by
    filter_upwards [circulationACSolution_ae hr hdi] with s hs hmem
    exact hs ((uIcc_of_le ht ▸ hmem).1)
  obtain ⟨hi, he⟩ := ac_integral_eq_sub (circulationACSolution_locallyAC hrAC hdi t ht) hd
  refine ⟨hi, ?_⟩
  rw [he, circulationACSolution_initial]
  ring

/-- C¹ regularity on the forward half-line supplies the reference AC hypothesis;
no regularity on negative times is required. -/
theorem forward_locallyAC_of_contDiffOn {r : ℝ → ℝ}
    (hr : ContDiffOn ℝ 1 r (Ici 0)) :
    ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval r 0 T := by
  intro T hT
  apply ContDiffOn.absolutelyContinuousOnInterval
  exact hr.mono (by intro t ht; exact (uIcc_of_le hT ▸ ht).1)

/-- Unconditional global-forward construction for the paper's C¹ reference and
an a.e. measurable disturbance bounded only almost everywhere for t≥0. The
trajectory, its AC regularity, and its actual plant equation are all conclusions. -/
theorem circulation_forward_measurable_global_exists {r rdot d : ℝ → ℝ} {γ k c0 D : ℝ}
    (hrC1 : ContDiffOn ℝ 1 r (Ici 0))
    (hr : ∀ t : ℝ, 0 < t → HasDerivAt r (rdot t) t)
    (hd : AEMeasurable d (volume.restrict (Ici 0)))
    (hb : ∀ᵐ t ∂volume, 0 ≤ t → |d t| ≤ D) :
    ∃ c : ℝ → ℝ, c 0 = c0 ∧
      (∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval c 0 T) ∧
      (∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c
        (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) t) ∧
      (∀ t : ℝ, 0 ≤ t →
        IntervalIntegrable (fun s =>
          circulationCommand γ k (r s) (rdot s) (c s) - γ * c s + d s) volume 0 t ∧
        c t = c0 + ∫ s in (0 : ℝ)..t,
          circulationCommand γ k (r s) (rdot s) (c s) - γ * c s + d s) := by
  have hdi := forward_intervalIntegrable_of_aebounded_restrict hd hb
  have hrAC := forward_locallyAC_of_contDiffOn hrC1
  have hrAE : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt r (rdot t) t :=
    forward_ae_hasDerivAt_of_pos hr
  exact ⟨circulationACSolution r d γ k c0, circulationACSolution_initial r d γ k c0,
    circulationACSolution_locallyAC hrAC hdi, circulationACSolution_ae hrAE hdi,
    circulationACSolution_integral hrAC hrAE hdi⟩

/-- Convenience form for a disturbance supplied as an a.e. measurable function
on all real times. Only its forward values affect the solution. -/
theorem circulation_measurable_global_exists {r rdot d : ℝ → ℝ} {γ k c0 D : ℝ}
    (hrC1 : ContDiffOn ℝ 1 r (Ici 0))
    (hr : ∀ t : ℝ, 0 < t → HasDerivAt r (rdot t) t)
    (hd : AEMeasurable d volume)
    (hb : ∀ᵐ t ∂volume, 0 ≤ t → |d t| ≤ D) :
    ∃ c : ℝ → ℝ, c 0 = c0 ∧
      (∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval c 0 T) ∧
      (∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c
        (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) t) ∧
      (∀ t : ℝ, 0 ≤ t →
        IntervalIntegrable (fun s =>
          circulationCommand γ k (r s) (rdot s) (c s) - γ * c s + d s) volume 0 t ∧
        c t = c0 + ∫ s in (0 : ℝ)..t,
          circulationCommand γ k (r s) (rdot s) (c s) - γ * c s + d s) := by
  exact circulation_forward_measurable_global_exists hrC1 hr hd.restrict hb

end
end ChainFountain.ZeroGravity
