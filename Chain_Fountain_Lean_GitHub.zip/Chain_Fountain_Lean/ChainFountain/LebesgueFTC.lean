import ChainFountain.MeasurableGlobal

namespace ChainFountain
noncomputable section
open Set Metric Filter MeasureTheory intervalIntegral
open scoped Topology NNReal ENNReal
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

/-- The almost-everywhere fundamental theorem for the Lebesgue primitive,
derived from the one-dimensional Vitali differentiation theorem. -/
theorem locally_integrable_primitive_ae_derivative {f : ℝ → E}
    (hf : LocallyIntegrable f volume) (a : ℝ) :
    ∀ᵐ t ∂volume, HasDerivAt (fun t => ∫ s in a..t, f s) (f t) t := by
  have hi (u v : ℝ) : IntervalIntegrable f volume u v := by
    rw [intervalIntegrable_iff]
    exact (hf.integrableOn_isCompact isCompact_uIcc).mono_set uIoc_subset_uIcc
  filter_upwards [(IsUnifLocDoublingMeasure.vitaliFamily (volume:Measure ℝ) 1).ae_tendsto_average hf]
    with t ht
  rw [hasDerivAt_iff_tendsto_slope,← nhdsLT_sup_nhdsGT,tendsto_sup]
  constructor
  · have hl := ht.comp (Real.tendsto_Icc_vitaliFamily_left t)
    apply hl.congr'
    filter_upwards [self_mem_nhdsWithin] with y (hy : y<t)
    simp only [Function.comp_apply,slope_def_module]
    rw [integral_interval_sub_left (hi a y) (hi a t),integral_symm y t]
    rw [setAverage_eq,Real.volume_real_Icc_of_le hy.le,integral_Icc_eq_integral_Ioc,
      ← integral_of_le hy.le]
    rw [show y-t=-(t-y) by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring,inv_neg,neg_smul,smul_neg,neg_neg]
  · have hr := ht.comp (Real.tendsto_Icc_vitaliFamily_right t)
    apply hr.congr'
    filter_upwards [self_mem_nhdsWithin] with y (hy : t<y)
    simp only [Function.comp_apply,slope_def_module]
    rw [integral_interval_sub_left (hi a y) (hi a t),setAverage_eq,
      Real.volume_real_Icc_of_le hy.le,integral_Icc_eq_integral_Ioc,← integral_of_le hy.le]

/-- Global Caratheodory existence in both integral and a.e. differential form
for bounded measurable-time, uniformly state-Lipschitz fields. -/
theorem bounded_measurable_global_ae_exists
    {F : ℝ → E → E} {L C : ℝ≥0}
    (hL : ∀ t, LipschitzWith L (F t))
    (hMeas : ∀ f : ℝ → E, Continuous f → AEStronglyMeasurable (fun t => F t (f t)) volume)
    (hC : ∀ t x, ‖F t x‖≤ C) (x₀ : E) :
    ∃ x : ℝ → E, LipschitzWith C x ∧ x 0=x₀ ∧
      (∀ t, x t=x₀+∫ s in (0:ℝ)..t, F s (x s)) ∧
      ∀ᵐ t ∂volume, HasDerivAt x (F t (x t)) t := by
  obtain ⟨x,hxL,hx₀,hxI⟩ := bounded_measurable_global_integral_exists hL hMeas hC x₀
  have hloc : LocallyIntegrable (fun t => F t (x t)) volume :=
    (memLp_top_of_bound (hMeas x hxL.continuous) C
      (Filter.Eventually.of_forall (fun t => hC t (x t)))).locallyIntegrable le_top
  refine ⟨x,hxL,hx₀,hxI,?_⟩
  filter_upwards [locally_integrable_primitive_ae_derivative hloc 0] with t ht
  convert! ht.const_add x₀ using 1
  exact funext hxI

end
end ChainFountain
