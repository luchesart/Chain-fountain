import Mathlib
import ChainFountain.ModelCore

/-!
Compatibility entry point for the original v0.16.0 model.
All model definitions, theorem statements and proof bodies are unchanged in
`ModelCore`. This entry point preserves the original complete Mathlib re-export;
the new zero-gravity library imports `ModelCore` directly for a small dependency
closure. The byte-for-byte original source is retained in
`verification/zero-gravity/Model.v16.lean` and in the original project archive.
-/
