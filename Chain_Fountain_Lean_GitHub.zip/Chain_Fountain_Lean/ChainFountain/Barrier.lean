import ChainFountain.Comparison

namespace ChainFountain
noncomputable section

def barrierLower (αhi v : ℝ) := -(1 - αhi) * v ^ 2
def barrierUpper (H g β αlo h v w γ B : ℝ) :=
  crownSq v w - (1 - αlo) * v ^ 2 - g * h +
    h * (fall H g β h v w + 2 * γ * B)

theorem pickup_endpoint_iff {αlo αhi v u : ℝ} (hα : αlo ≤ αhi) :
    (∀ α ∈ Set.Icc αlo αhi, 0 ≤ pickup α v u) ↔ barrierLower αhi v ≤ u := by
  constructor
  · intro h
    have he := h αhi ⟨hα,le_rfl⟩
    unfold pickup at he; unfold barrierLower; linarith
  · intro h α ha
    have hs := mul_nonneg (sub_nonneg.mpr ha.2) (sq_nonneg v)
    unfold pickup; unfold barrierLower at h; nlinarith

theorem crown_input_iff {H g β α h v w γ B u : ℝ} (hh : 0 < h) :
    0 ≤ (rise g α h v w u + fall H g β h v w) / 2 + γ * B ↔
      u ≤ barrierUpper H g β α h v w γ B := by
  have hid : 2 * h * ((rise g α h v w u + fall H g β h v w) / 2 + γ * B) =
      barrierUpper H g β α h v w γ B - u := by
    unfold rise barrierUpper; field_simp <;> ring
  constructor
  · intro hb
    have := mul_nonneg (by positivity : 0 ≤ 2 * h) hb; rw [hid] at this; linarith
  · intro hu
    have hp : 0 < 2 * h := by positivity
    have : 0 ≤ 2 * h * ((rise g α h v w u + fall H g β h v w) / 2 + γ * B) := by
      rw [hid]; linarith
    exact nonneg_of_mul_nonneg_right this hp

theorem crown_endpoint_iff {H g β αlo αhi h v w γ B u : ℝ}
    (hh : 0 < h) (hα : αlo ≤ αhi) :
    (∀ α ∈ Set.Icc αlo αhi,
      0 ≤ (rise g α h v w u + fall H g β h v w) / 2 + γ * B) ↔
      u ≤ barrierUpper H g β αlo h v w γ B := by
  constructor
  · intro hb; exact (crown_input_iff hh).mp (hb αlo ⟨le_rfl,hα⟩)
  · intro hu α ha
    apply (crown_input_iff hh).mpr
    have hs := mul_nonneg (sub_nonneg.mpr ha.1) (sq_nonneg v)
    unfold barrierUpper at *; nlinarith

theorem barrier_width (H g β αlo αhi h v w γ B : ℝ) (hH : H + h ≠ 0) :
    barrierUpper H g β αlo h v w γ B - barrierLower αhi v =
      (H * crownSq v w + β * h * w ^ 2) / (H + h) +
        2 * h * γ * B - (αhi - αlo) * v ^ 2 := by
  unfold barrierUpper barrierLower fall
  field_simp <;> ring

/-- Proposition 8.1's exact pointwise feasibility equivalence. -/
theorem barrier_feasible_iff {H g β αlo αhi h v w γ B : ℝ}
    (hh : 0 < h) (hH : H + h ≠ 0) (hα : αlo ≤ αhi) :
    (∃ u, (∀ α ∈ Set.Icc αlo αhi, 0 ≤ pickup α v u) ∧
      (∀ α ∈ Set.Icc αlo αhi,
        0 ≤ (rise g α h v w u + fall H g β h v w) / 2 + γ * B)) ↔
    (αhi - αlo) * v ^ 2 ≤
      (H * crownSq v w + β * h * w ^ 2) / (H + h) + 2 * h * γ * B := by
  have hw := barrier_width H g β αlo αhi h v w γ B hH
  simp_rw [pickup_endpoint_iff hα, crown_endpoint_iff hh hα]
  constructor
  · rintro ⟨u,hl,hu⟩; linarith
  · intro h; exact ⟨barrierLower αhi v,le_rfl,by linarith⟩

theorem interval_intersection_iff (amin amax L U : ℝ) :
    (∃ u, amin ≤ u ∧ u ≤ amax ∧ L ≤ u ∧ u ≤ U) ↔ max amin L ≤ min amax U := by
  constructor
  · rintro ⟨u,ha,hb,hL,hU⟩
    exact (max_le ha hL).trans (le_min hb hU)
  · intro h
    exact ⟨max amin L,le_max_left _ _,h.trans (min_le_left _ _),
      le_max_right _ _,h.trans (min_le_right _ _)⟩

def clip (L U desired : ℝ) := min U (max L desired)

theorem clip_mem {L U desired : ℝ} (h : L ≤ U) : L ≤ clip L U desired ∧ clip L U desired ≤ U := by
  unfold clip
  exact ⟨le_min h (le_max_left _ _),min_le_left _ _⟩

theorem clip_nearest {L U desired u : ℝ} (h : L ≤ U) (hu : L ≤ u ∧ u ≤ U) :
    (clip L U desired - desired) ^ 2 ≤ (u - desired) ^ 2 := by
  unfold clip
  by_cases hl : desired ≤ L
  · rw [max_eq_left hl, min_eq_right h]
    nlinarith [sq_nonneg (u-L)]
  · have hld : L ≤ desired := (lt_of_not_ge hl).le
    rw [max_eq_right hld]
    by_cases hd : U ≤ desired
    · rw [min_eq_left hd]
      nlinarith [sq_nonneg (U-u)]
    · rw [min_eq_right (lt_of_not_ge hd).le]
      simp only [sub_self, zero_pow (by decide : 2 ≠ 0)]
      exact sq_nonneg _

theorem nominal_barrier_nonempty {H g h β v w γ B α : ℝ}
    (hH : 0 < H) (hh : 0 < h) (hβ : 0 ≤ β) (hγ : 0 ≤ γ) (hB : 0 ≤ B) :
    barrierLower α v ≤ barrierUpper H g β α h v w γ B := by
  have hw := barrier_width H g β α α h v w γ B (ne_of_gt (add_pos hH hh))
  have hp : 0 ≤ (H * crownSq v w + β * h * w ^ 2) / (H+h) + 2*h*γ*B := by
    unfold crownSq; positivity
  simp only [sub_self,zero_mul,sub_zero] at hw
  linarith

/-- Appendix A.1: positive crown margin does not give an inward falling-speed face. -/
theorem counterexample_falling_speed :
    (10 + (0 : ℝ)) / 2 - 16/5 > 0 ∧
    fall 2 (981/100) (1/50) (1/10) 10 0 < 0 := by
  norm_num [fall,crownSq]

/-- Appendix A.2: both velocities positive but the robust interval is empty. -/
theorem counterexample_empty_interval (γ : ℝ) :
    barrierUpper 2 (981/100) (1/50) (3/50) 3 (63/10) (1/10) γ 0 <
      barrierLower (9/50) (63/10) := by
  norm_num [barrierUpper,barrierLower,fall,crownSq]

end
end ChainFountain
