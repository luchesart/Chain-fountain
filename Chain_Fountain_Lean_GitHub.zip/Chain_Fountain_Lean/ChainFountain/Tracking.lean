import ChainFountain.Model

namespace ChainFountain
noncomputable section

def errorEnergy (k₀ e z : ℝ) : ℝ := k₀ / 2 * e ^ 2 + z ^ 2 / 8
def errorRate (k₁ e z : ℝ) : ℝ := -k₁ * e + z / 2
def zRate (k₀ k₂ κd G d e z : ℝ) : ℝ :=
  -2 * k₀ * e - k₂ * z - κd * G ^ 2 * z + G * d
def acceleration (k₀ k₁ k₂ e q r₁ r₂ : ℝ) : ℝ :=
  r₂ - (k₁ + k₂) * (q - r₁) - (k₀ + k₁ * k₂) * e
def nominalInput (H g α β h v w A : ℝ) : ℝ :=
  (1 + h / (H + h)) * crownSq v w - (1 - α) * v ^ 2 -
    2 * g * h - β * h * w ^ 2 / (H + h) - 2 * h * A
def robustInput (H g α β h v w A κd z : ℝ) : ℝ :=
  nominalInput H g α β h v w A + κd * v ^ 4 / h * z

theorem nominal_acceleration (H g α β h v w A : ℝ)
    (hh : h ≠ 0) (hH : H + h ≠ 0) :
    (rise g α h v w (nominalInput H g α β h v w A) -
      fall H g β h v w) / 2 = A := by
  unfold rise fall nominalInput
  field_simp <;> ring

theorem robust_acceleration (H g α β h v w A κd z d : ℝ)
    (hh : h ≠ 0) (hH : H + h ≠ 0) :
    (rise g (α + d) h v w (robustInput H g α β h v w A κd z) -
      fall H g β h v w) / 2 =
        A - κd * (v ^ 2 / h) ^ 2 * z / 2 + (v ^ 2 / h) * d / 2 := by
  unfold robustInput rise fall nominalInput
  field_simp <;> ring

theorem transformed_error_rate (k₁ h r v w r₁ : ℝ) :
    heightRate v w - r₁ =
      errorRate k₁ (h-r) (v - w - 2 * r₁ + 2 * k₁ * (h-r)) := by
  unfold heightRate errorRate; ring

theorem transformed_z_rate (k₀ k₁ k₂ e q r₁ r₂ κd G d z : ℝ)
    (hz : z = 2 * (q - r₁ + k₁ * e)) :
    2 * (acceleration k₀ k₁ k₂ e q r₁ r₂ - κd * G ^ 2 * z / 2 + G * d / 2) -
      2 * r₂ + 2 * k₁ * (q - r₁) = zRate k₀ k₂ κd G d e z := by
  unfold acceleration zRate; rw [hz]; ring

theorem energy_nonneg {k₀ : ℝ} (hk₀ : 0 ≤ k₀) (e z : ℝ) :
    0 ≤ errorEnergy k₀ e z := by unfold errorEnergy; positivity

theorem energy_zero_iff {k₀ e z : ℝ} (hk₀ : 0 < k₀) :
    errorEnergy k₀ e z = 0 ↔ e = 0 ∧ z = 0 := by
  unfold errorEnergy
  constructor
  · intro h
    have he : e ^ 2 = 0 := by nlinarith [sq_nonneg z, sq_nonneg e]
    have hz : z ^ 2 = 0 := by nlinarith
    exact ⟨eq_zero_of_pow_eq_zero he, eq_zero_of_pow_eq_zero hz⟩
  · rintro ⟨rfl,rfl⟩; ring

/-- The exact Lyapunov identity, including bounded coefficient uncertainty. -/
theorem lyapunov_identity (k₀ k₁ k₂ κd G d e z : ℝ) :
    k₀ * e * errorRate k₁ e z + z / 4 * zRate k₀ k₂ κd G d e z =
      -k₀ * k₁ * e ^ 2 - k₂ * z ^ 2 / 4 - κd * G ^ 2 * z ^ 2 / 4 + G * z * d / 4 := by
  unfold errorRate zRate; ring

theorem energy_hasDerivAt_errors {e z : ℝ → ℝ} {k₀ k₁ k₂ κd G d t : ℝ}
    (he : HasDerivAt e (errorRate k₁ (e t) (z t)) t)
    (hz : HasDerivAt z (zRate k₀ k₂ κd G d (e t) (z t)) t) :
    HasDerivAt (fun s => errorEnergy k₀ (e s) (z s))
      (-k₀ * k₁ * e t ^ 2 - k₂ * z t ^ 2 / 4 -
        κd * G ^ 2 * z t ^ 2 / 4 + G * z t * d / 4) t := by
  have hd := ((he.pow 2).const_mul (k₀ / 2)).add ((hz.pow 2).div_const 8)
  convert! hd using 1
  unfold errorRate zRate; ring

theorem nominal_decay {k₀ k₁ k₂ κ e z : ℝ}
    (hk₀ : 0 ≤ k₀) (hκ₁ : κ ≤ k₁) (hκ₂ : κ ≤ k₂) :
    -k₀ * k₁ * e ^ 2 - k₂ * z ^ 2 / 4 ≤ -2 * κ * errorEnergy k₀ e z := by
  unfold errorEnergy
  have h₁ := mul_nonneg (sub_nonneg.mpr hκ₁) (mul_nonneg hk₀ (sq_nonneg e))
  have h₂ := mul_nonneg (sub_nonneg.mpr hκ₂) (sq_nonneg z)
  nlinarith

theorem weighted_young {κd G z d : ℝ} (hd : 0 < κd) :
    G * z * d / 4 ≤ κd * G ^ 2 * z ^ 2 / 8 + d ^ 2 / (8 * κd) := by
  apply (mul_le_mul_iff_right₀ (show 0 < 8 * κd by positivity)).mp
  have hsq := sq_nonneg (κd * G * z - d)
  have hc : (8 * κd) * (d ^ 2 / (8 * κd)) = d ^ 2 := by field_simp
  nlinarith

/-- Equation (7.2), proved directly from the weighted square identity. -/
theorem robust_decay {k₀ k₁ k₂ κ κd G d e z : ℝ}
    (hk₀ : 0 ≤ k₀) (hκ₁ : κ ≤ k₁) (hκ₂ : κ ≤ k₂) (hd : 0 < κd) :
    -k₀ * k₁ * e ^ 2 - k₂ * z ^ 2 / 4 - κd * G ^ 2 * z ^ 2 / 4 + G * z * d / 4 ≤
      -2 * κ * errorEnergy k₀ e z - κd * G ^ 2 * z ^ 2 / 8 + d ^ 2 / (8 * κd) := by
  have hn := nominal_decay (e:=e) (z:=z) hk₀ hκ₁ hκ₂
  have hy := weighted_young (G:=G) (z:=z) (d:=d) hd
  linarith

theorem robust_decay_uniform {k₀ k₁ k₂ κ κd G d dbar e z : ℝ}
    (hk₀ : 0 ≤ k₀) (hκ₁ : κ ≤ k₁) (hκ₂ : κ ≤ k₂)
    (hd : 0 < κd) (hbound : |d| ≤ dbar) :
    -k₀ * k₁ * e ^ 2 - k₂ * z ^ 2 / 4 - κd * G ^ 2 * z ^ 2 / 4 + G * z * d / 4 ≤
      -2 * κ * errorEnergy k₀ e z + dbar ^ 2 / (8 * κd) := by
  have h := robust_decay (e:=e) (z:=z) (G:=G) (d:=d) hk₀ hκ₁ hκ₂ hd
  have hs : d ^ 2 ≤ dbar ^ 2 := by
    have hsq := (sq_le_sq₀ (abs_nonneg d) (le_trans (abs_nonneg d) hbound)).mpr hbound
    simpa only [sq_abs] using hsq
  have hdiv := div_le_div_of_nonneg_right hs (by positivity : 0 ≤ 8 * κd)
  have hn : 0 ≤ κd * G ^ 2 * z ^ 2 / 8 := by positivity
  linarith

/-- Exact additional term caused by replacing the requested input. -/
theorem input_correction (z h u ur : ℝ) :
    z / 4 * (-(u - ur) / h) = -z / (4 * h) * (u - ur) := by ring

/-- The quadratic generator expression; no stochastic-process theorem is assumed. -/
theorem generator_identity (k₀ k₁ k₂ κd G σ e z : ℝ) :
    k₀ * e * errorRate k₁ e z + z / 4 * zRate k₀ k₂ κd G 0 e z +
      (1 / 2) * (σ * G) ^ 2 * (1 / 4) =
    -k₀ * k₁ * e ^ 2 - k₂ * z ^ 2 / 4 - κd * G ^ 2 * z ^ 2 / 4 + σ ^ 2 * G ^ 2 / 8 := by
  unfold errorRate zRate; ring

end
end ChainFountain
