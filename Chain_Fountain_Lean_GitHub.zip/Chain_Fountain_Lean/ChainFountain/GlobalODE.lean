import Mathlib

namespace ChainFountain
noncomputable section
open Set Metric Filter
open scoped Topology NNReal

/-- Construct a global classical solution of a bounded vector field which is
uniformly Lipschitz in the state and continuous in time. Picard--Lindelof is
applied on every finite interval; uniqueness makes the resulting curves agree.
No solution is included among the hypotheses. -/
theorem bounded_lipschitz_global_exists
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    {F : ℝ → E → E} {L : ℝ≥0} {C : ℝ}
    (hL : ∀ t, LipschitzWith L (F t))
    (hcont : ∀ x, Continuous (fun t => F t x))
    (hC : ∀ t x, ‖F t x‖ ≤ C) (x₀ : E) :
    ∃ x : ℝ → E, x 0 = x₀ ∧ ∀ t, HasDerivAt x (F t (x t)) t := by
  have hC0 : 0 ≤ C := (norm_nonneg _).trans (hC 0 x₀)
  have hex (a : ℝ) : ∃ x : ℝ → E, x 0 = x₀ ∧
      ∀ t ∈ Ioo (-a) a, HasDerivAt x (F t (x t)) t := by
    by_cases ha : 0 < a
    · let t₀ : Icc (-a) a := ⟨0,by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith,ha.le⟩
      have hp : IsPicardLindelof F t₀ x₀ ⟨C*a,mul_nonneg hC0 ha.le⟩ 0 ⟨C,hC0⟩ L :=
        { lipschitzOnWith := fun t _ => (hL t).lipschitzOnWith
          continuousOn := fun x _ => (hcont x).continuousOn
          norm_le := fun t _ x _ => hC t x
          mul_max_le := by simp [t₀]; exact le_rfl }
      obtain ⟨x,hx,hd⟩ := hp.exists_eq_forall_mem_Icc_hasDerivWithinAt₀
      exact ⟨x,hx,fun t ht => (hd t (Ioo_subset_Icc_self ht)).hasDerivAt
        (Icc_mem_nhds ht.1 ht.2)⟩
    · exact ⟨fun _ => x₀,rfl,fun t ht => False.elim (ha (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [ht.1,ht.2]))⟩
  choose f hf hd using hex
  have agree {a b : ℝ} (ha : 0 < a) (hab : a ≤ b) :
      EqOn (f a) (f b) (Ioo (-a) a) := by
    apply ODE_solution_unique_of_mem_Ioo (s:=fun _ => univ)
      (fun t _ => (hL t).lipschitzOnWith) (t₀:=0) ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith,ha⟩
      (fun t ht => ⟨hd a t ht, mem_univ _⟩)
      (fun t ht => ⟨hd b t ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [ht.1],lt_of_lt_of_le ht.2 hab⟩,mem_univ _⟩)
    rw [hf a,hf b]
  let x : ℝ → E := fun t => f (|t|+1) t
  have heq (a : ℝ) : EqOn x (f a) (Ioo (-a) a) := by
    intro t ht
    by_cases hlt : |t|+1 < a
    · exact agree (by positivity) hlt.le (abs_lt.mp (lt_add_one _))
    · exact (agree (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [ht.1,ht.2]) (not_lt.mp hlt) ht).symm
  refine ⟨x,by simp [x,hf],?_⟩
  intro t
  have ht : t ∈ Ioo (-(|t|+1)) (|t|+1) := abs_lt.mp (lt_add_one _)
  have hevent : x =ᶠ[𝓝 t] f (|t|+1) :=
    Filter.eventuallyEq_iff_exists_mem.mpr
      ⟨Ioo (-(|t|+1)) (|t|+1),Ioo_mem_nhds ht.1 ht.2,heq _⟩
  rw [heq _ ht]
  exact (hd _ t ht).congr_of_eventuallyEq hevent

/-- A first-exit argument with a closed outer set and an interior target.
The supplied implication must be an a priori estimate on *every* finite
prefix, not an assumption that the constructed curve is safe. -/
theorem no_exit_of_prefix_bound
    {E : Type*} [TopologicalSpace E] {x : ℝ → E} {B K : Set E}
    (hx : Continuous x) (hB : IsClosed B) (hKB : K ⊆ interior B)
    (hx₀ : x 0 ∈ interior B)
    (hprefix : ∀ T ≥ 0, (∀ t ∈ Icc 0 T, x t ∈ B) → x T ∈ K) :
    ∀ t ≥ 0, x t ∈ K := by
  have hstay : ∀ T ≥ 0, ∀ t ∈ Icc 0 T, x t ∈ interior B := by
    intro T hT
    by_contra hn
    push_neg at hn
    let S := Icc 0 T ∩ x ⁻¹' (interior B)ᶜ
    have hS : IsCompact S := isCompact_Icc.inter_right
      (isOpen_interior.isClosed_compl.preimage hx)
    have hSne : S.Nonempty := by
      obtain ⟨t,ht,hxt⟩ := hn
      exact ⟨t,ht,hxt⟩
    obtain ⟨a,ha,hle⟩ := hS.exists_isLeast hSne
    have ha0 : 0 < a := lt_of_le_of_ne ha.1.1 (by
      intro hh; subst a; exact ha.2 hx₀)
    have hbefore : ∀ t ∈ Ico 0 a, x t ∈ interior B := by
      intro t ht
      by_contra hnot
      have := hle (show t ∈ S from ⟨⟨ht.1,ht.2.le.trans ha.1.2⟩,hnot⟩)
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [ht.2]
    have hclosed : ∀ t ∈ Icc 0 a, x t ∈ B := by
      intro t ht
      have hsub : Ico 0 a ⊆ x ⁻¹' B := fun s hs => (interior_subset (s:=B)) (hbefore s hs)
      have hc := closure_minimal hsub (hB.preimage hx)
      rw [closure_Ico ha0.ne] at hc
      exact hc ht
    exact ha.2 (hKB (hprefix a ha.1.1 hclosed))
  intro t ht
  exact hprefix t ht (fun s hs => interior_subset (hstay t ht s hs))

/-- Global construction from a bounded Lipschitz extension and a proved
finite-prefix estimate. The retraction is only used in the construction;
the resulting forward trajectory solves the original vector field. -/
theorem global_exists_of_retraction_and_prefix
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    {F : ℝ → E → E} {B K : Set E} {P : E → E} {L : ℝ≥0} {C : ℝ}
    (hB : IsClosed B) (hKB : K ⊆ interior B)
    (hP : LipschitzWith 1 P) (hPB : ∀ x, P x ∈ B)
    (hPid : ∀ x ∈ B, P x = x)
    (hL : ∀ t, LipschitzOnWith L (F t) B)
    (hcont : ∀ x ∈ B, Continuous (fun t => F t x))
    (hC : ∀ t x, x ∈ B → ‖F t x‖ ≤ C)
    (x₀ : E) (hx₀ : x₀ ∈ interior B)
    (hprefix : ∀ (x : ℝ → E) T, 0 ≤ T → x 0 = x₀ →
      (∀ t ∈ Icc 0 T, x t ∈ B) →
      (∀ t ∈ Icc 0 T, HasDerivAt x (F t (x t)) t) → x T ∈ K) :
    ∃ x : ℝ → E, x 0 = x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (F t (x t)) t) ∧ ∀ t ≥ 0, x t ∈ K := by
  have hLp : ∀ t, LipschitzWith L (fun x => F t (P x)) := by
    intro t
    have hh := (hL t).comp (hP.lipschitzOnWith (s:=univ)) (fun x _ => hPB x)
    simpa only [mul_one, lipschitzOnWith_univ, Function.comp_def] using hh
  obtain ⟨x,hx₀',hd⟩ := bounded_lipschitz_global_exists hLp
    (fun x => hcont (P x) (hPB x)) (fun t x => hC t (P x) (hPB x)) x₀
  have hx : Continuous x := continuous_iff_continuousAt.mpr (fun t => (hd t).continuousAt)
  have hstay := no_exit_of_prefix_bound hx hB hKB (hx₀' ▸ hx₀) (by
    intro T hT hxb
    exact hprefix x T hT hx₀' hxb (fun t ht => by
      simpa only [hPid (x t) (hxb t ht)] using hd t))
  exact ⟨x,hx₀',fun t ht => by
    simpa only [hPid (x t) (interior_subset (hKB (hstay t ht)))] using hd t,hstay⟩

/-- Smoothness on an open domain supplies quantitative Lipschitz and size
bounds on a compact convex subset. This is used on state/parameter boxes. -/
theorem smooth_compact_convex_bounds
    {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    {f : E → F} {U S : Set E}
    (hU : IsOpen U) (hf : ContDiffOn ℝ 1 f U)
    (hS : IsCompact S) (hc : Convex ℝ S) (hSU : S ⊆ U) :
    ∃ L : ℝ≥0, ∃ C : ℝ, LipschitzOnWith L f S ∧ ∀ x ∈ S, ‖f x‖ ≤ C := by
  obtain ⟨C,hC⟩ := hS.exists_bound_of_continuousOn (hf.continuousOn.mono hSU)
  obtain ⟨D,hD⟩ := hS.exists_bound_of_continuousOn
    ((hf.continuousOn_fderiv_of_isOpen hU le_rfl).mono hSU)
  refine ⟨⟨max D 0,le_max_right _ _⟩,C,?_,hC⟩
  apply hc.lipschitzOnWith_of_nnnorm_fderiv_le
    (fun x hx => ((hf x (hSU hx)).contDiffAt (hU.mem_nhds (hSU hx))).differentiableAt (by norm_num))
  intro x hx
  exact_mod_cast (hD x hx).trans (le_max_left D 0)

end
end ChainFountain
