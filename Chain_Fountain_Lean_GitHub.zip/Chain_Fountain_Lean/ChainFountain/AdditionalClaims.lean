import ChainFountain.Barrier
import ChainFountain.Region

namespace ChainFountain
noncomputable section
open MeasureTheory Filter Real

/-- Proposition 3.1 for equations holding almost everywhere. The coefficient and
input may be measurable: no time derivative of either one is needed. This is a
chain-rule conclusion for an a.e. solution, not a measurable-input existence theorem. -/
theorem energy_balance_ae {H g lam β : ℝ} {α u h v w : ℝ → ℝ}
    {μ : Measure ℝ}
    (hh : ∀ᵐ t ∂μ, h t ≠ 0) (hH : ∀ᵐ t ∂μ, H+h t ≠ 0)
    (dh : ∀ᵐ t ∂μ, HasDerivAt h (heightRate (v t) (w t)) t)
    (dv : ∀ᵐ t ∂μ, HasDerivAt v (rise g (α t) (h t) (v t) (w t) (u t)) t)
    (dw : ∀ᵐ t ∂μ, HasDerivAt w (fall H g β (h t) (v t) (w t)) t) :
    ∀ᵐ t ∂μ, HasDerivAt (fun s => energy H g lam (h s) (v s) (w s))
      (lam*g*H*w t-lam*(1/2-α t)*(v t)^3-lam*(1/2-β)*(w t)^3-lam*u t*v t) t := by
  filter_upwards [hh,hH,dh,dv,dw] with t ht hHt hdt hvt hwt
  exact energy_hasDerivAt ht hHt hdt hvt hwt

/-- The localized quadratic generator inequality is algebraic; Dynkin's formula
and the stopped-process expectation inequality remain separate obligations. -/
theorem localized_generator_bound {k₀ k₁ k₂ κ κd G Gmax σ e z : ℝ}
    (hk₀ : 0 ≤ k₀) (hk₁ : κ ≤ k₁) (hk₂ : κ ≤ k₂) (hκd : 0 ≤ κd)
    (hG : G^2 ≤ Gmax^2) :
    k₀*e*errorRate k₁ e z+z/4*zRate k₀ k₂ κd G 0 e z+
      (1/2)*(σ*G)^2*(1/4) ≤ -2*κ*errorEnergy k₀ e z+σ^2*Gmax^2/8 := by
  rw [generator_identity]
  have hn := nominal_decay (e:=e) (z:=z) hk₀ hk₁ hk₂
  have hg := mul_le_mul_of_nonneg_left hG (sq_nonneg σ)
  have hd : 0 ≤ κd*G^2*z^2 := by positivity
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

def fastReference (t : ℝ) := (1/5 : ℝ)+(1/10)*sin (100*t)
def fastRate (t : ℝ) := 10*cos (100*t)
def fastAcceleration (t : ℝ) := -1000*sin (100*t)

theorem fast_reference_derivatives (t : ℝ) :
    HasDerivAt fastReference (fastRate t) t ∧ HasDerivAt fastRate (fastAcceleration t) t := by
  constructor
  · convert! ((((hasDerivAt_id t).const_mul 100).sin).const_mul (1/10)).const_add (1/5) using 1 <;>
      dsimp [fastReference,fastRate] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  · convert! (((hasDerivAt_id t).const_mul 100).cos).const_mul 10 using 1 <;>
      dsimp [fastRate,fastAcceleration] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem fast_reference_bounds (t : ℝ) :
    (1/10 : ℝ) ≤ fastReference t ∧ fastReference t ≤ 3/10 ∧
      |fastRate t| ≤ 10 ∧ |fastAcceleration t| ≤ 1000 := by
  have hs := abs_le.mp (abs_sin_le_one (100*t))
  have hc := abs_cos_le_one (100*t)
  refine ⟨?_,?_,?_,?_⟩
  · dsimp [fastReference]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hs.1]
  · dsimp [fastReference]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hs.2]
  · norm_num [fastRate,abs_mul]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
  · norm_num [fastAcceleration,abs_mul]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [abs_sin_le_one (100*t)]

/-- Appendix A.3, linked to the actual smooth positive bounded-rate reference. -/
theorem counterexample_reference_rate :
    fastReference 0=1/5 ∧ fastRate 0=10 ∧
      internal 2 (981/100) (1/50) (fastReference 0) 0 (fastRate 0) < 0 := by
  norm_num [fastReference,fastRate,internal]

end
end ChainFountain
