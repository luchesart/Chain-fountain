import ChainFountain.GlobalODE
import ChainFountain.ExistenceBounds

namespace ChainFountain
noncomputable section
open Set Real Metric
open scoped Topology NNReal

abbrev MechanicalState := ℝ × ℝ × ℝ
abbrev ReferenceParameters := ℝ × ℝ × ℝ × ℝ

/-- Pure data and checkable inequalities. There is no trajectory field and no
existence, invariance, or convergence assumption in this structure. -/
structure GlobalTrackingData where
  H : ℝ
  g : ℝ
  α : ℝ
  β : ℝ
  k₀ : ℝ
  k₁ : ℝ
  k₂ : ℝ
  κ : ℝ
  κd : ℝ
  dbar : ℝ
  cap : ℝ
  rlo : ℝ
  rhi : ℝ
  R₁ : ℝ
  R₂ : ℝ
  wlo : ℝ
  whi : ℝ
  vmin : ℝ
  r : ℝ → ℝ
  r₁ : ℝ → ℝ
  r₂ : ℝ → ℝ
  d : ℝ → ℝ
  x₀ : MechanicalState
  H_pos : 0 < H
  g_nonneg : 0 ≤ g
  k₀_pos : 0 < k₀
  κ_pos : 0 < κ
  κ_le_k₁ : κ ≤ k₁
  κ_le_k₂ : κ ≤ k₂
  κd_nonneg : 0 ≤ κd
  regime : dbar = 0 ∨ 0 < κd
  vmin_pos : 0 < vmin
  dr : ∀ t ≥ 0, HasDerivAt r (r₁ t) t
  dr₁ : ∀ t ≥ 0, HasDerivAt r₁ (r₂ t) t
  r₂_cont : ContinuousOn r₂ (Ici 0)
  d_cont : ContinuousOn d (Ici 0)
  ref_bounds : ∀ t ≥ 0, rlo ≤ r t ∧ r t ≤ rhi
  rate_bound : ∀ t ≥ 0, |r₁ t| ≤ R₁
  accel_bound : ∀ t ≥ 0, |r₂ t| ≤ R₂
  disturbance_bound : ∀ t ≥ 0, |d t| ≤ dbar
  initial_energy : errorEnergy k₀ (x₀.1-r 0)
    (x₀.2.1-x₀.2.2-2*r₁ 0+2*k₁*(x₀.1-r 0)) ≤ cap
  disturbance_cap : dbar^2/(16*κ*κd) ≤ cap
  height_positive : 0 < rlo-sqrt (2*cap/k₀)
  forward : 2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀)) < wlo
  speed_order : wlo ≤ whi
  crown : vmin ≤ wlo-(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))
  lower_face_bound : (1-β)*wlo^2+2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))*wlo+
    (R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))^2 ≤ g*(H+(rlo-sqrt (2*cap/k₀)))
  upper_face_bound : g*(H+(rhi+sqrt (2*cap/k₀))) ≤ (1-β)*whi^2-
    2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))*whi+
    (R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))^2
  initial_speed : wlo ≤ x₀.2.2 ∧ x₀.2.2 ≤ whi

def GlobalTrackingData.hlo (c : GlobalTrackingData) := c.rlo-sqrt (2*c.cap/c.k₀)
def GlobalTrackingData.hhi (c : GlobalTrackingData) := c.rhi+sqrt (2*c.cap/c.k₀)
def GlobalTrackingData.Q (c : GlobalTrackingData) := c.R₁+sqrt (2*c.cap)*sqrt (1+c.k₁^2/c.k₀)
def GlobalTrackingData.vlo (c : GlobalTrackingData) := c.wlo-2*c.Q
def GlobalTrackingData.vhi (c : GlobalTrackingData) := c.whi+2*c.Q
def GlobalTrackingData.safeBox (c : GlobalTrackingData) : Set MechanicalState :=
  Icc c.hlo c.hhi ×ˢ (Icc c.vlo c.vhi ×ˢ Icc c.wlo c.whi)
def GlobalTrackingData.outerBox (c : GlobalTrackingData) : Set MechanicalState :=
  Icc (c.hlo/2) (c.hhi+1) ×ˢ (Icc (c.vlo-1) (c.vhi+1) ×ˢ Icc (c.wlo-1) (c.whi+1))
def GlobalTrackingData.parameterBox (c : GlobalTrackingData) : Set ReferenceParameters :=
  Icc c.rlo c.rhi ×ˢ (Icc (-c.R₁) c.R₁ ×ˢ (Icc (-c.R₂) c.R₂ ×ˢ Icc (-c.dbar) c.dbar))

def GlobalTrackingData.jointField (c : GlobalTrackingData)
    (y : ReferenceParameters × MechanicalState) : MechanicalState :=
  let p := y.1
  let x := y.2
  let u := robustInput c.H c.g c.α c.β x.1 x.2.1 x.2.2
    (acceleration c.k₀ c.k₁ c.k₂ (x.1-p.1) (heightRate x.2.1 x.2.2) p.2.1 p.2.2.1)
    c.κd (x.2.1-x.2.2-2*p.2.1+2*c.k₁*(x.1-p.1))
  (heightRate x.2.1 x.2.2,
    rise c.g (c.α+p.2.2.2) x.1 x.2.1 x.2.2 u,
    fall c.H c.g c.β x.1 x.2.1 x.2.2)

/-- Clamping time only defines harmless data before zero. Forward dynamics use
the given reference and disturbance without any input clipping. -/
def GlobalTrackingData.parameters (c : GlobalTrackingData) (t : ℝ) : ReferenceParameters :=
  (c.r (max 0 t), c.r₁ (max 0 t), c.r₂ (max 0 t), c.d (max 0 t))
def GlobalTrackingData.field (c : GlobalTrackingData) (t : ℝ) (x : MechanicalState) :=
  c.jointField (c.parameters t,x)

theorem GlobalTrackingData.parameters_mem (c : GlobalTrackingData) (t : ℝ) :
    c.parameters t ∈ c.parameterBox := by
  exact ⟨c.ref_bounds _ (le_max_left _ _), abs_le.mp (c.rate_bound _ (le_max_left _ _)),
    abs_le.mp (c.accel_bound _ (le_max_left _ _)),
    abs_le.mp (c.disturbance_bound _ (le_max_left _ _))⟩

theorem GlobalTrackingData.parameters_continuous (c : GlobalTrackingData) :
    Continuous c.parameters := by
  have hr : ContinuousOn c.r (Ici 0) := fun t ht =>
    (c.dr t ht).continuousAt.continuousWithinAt
  have hr₁ : ContinuousOn c.r₁ (Ici 0) := fun t ht =>
    (c.dr₁ t ht).continuousAt.continuousWithinAt
  have hm : Continuous (fun t : ℝ => max 0 t) := continuous_const.max continuous_id
  exact (hr.comp_continuous hm (fun t => (show max 0 t ∈ Ici 0 from (le_max_left (0 : ℝ) t)))).prodMk
    ((hr₁.comp_continuous hm (fun t => (show max 0 t ∈ Ici 0 from (le_max_left (0 : ℝ) t)))).prodMk
      ((c.r₂_cont.comp_continuous hm (fun t => (show max 0 t ∈ Ici 0 from (le_max_left (0 : ℝ) t)))).prodMk
        (c.d_cont.comp_continuous hm (fun t => (show max 0 t ∈ Ici 0 from (le_max_left (0 : ℝ) t))))))

theorem GlobalTrackingData.jointField_smooth (c : GlobalTrackingData) :
    ContDiffOn ℝ 1 c.jointField {y | 0 < y.2.1} := by
  intro y hy
  have hh : y.2.1 ≠ 0 := ne_of_gt hy
  have hH : c.H+y.2.1 ≠ 0 := ne_of_gt (add_pos c.H_pos hy)
  apply ContDiffAt.contDiffWithinAt
  unfold jointField robustInput nominalInput acceleration heightRate rise fall crownSq
  fun_prop (disch := first | assumption | norm_num)

theorem GlobalTrackingData.safeBox_interior (c : GlobalTrackingData) :
    c.safeBox ⊆ interior c.outerBox := by
  intro x hx
  rcases hx with ⟨hh,hv,hw⟩
  change x ∈ interior (Icc (c.hlo/2) (c.hhi+1) ×ˢ
    (Icc (c.vlo-1) (c.vhi+1) ×ˢ Icc (c.wlo-1) (c.whi+1)))
  simp only [interior_prod_eq,interior_Icc,mem_prod,mem_Ioo]
  have hpos : 0 < c.hlo := c.height_positive
  exact ⟨⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hh.1],by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hh.2]⟩,
    ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hv.1],by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hv.2]⟩,
    ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hw.1],by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hw.2]⟩⟩

theorem GlobalTrackingData.box_of_energy_speed (c : GlobalTrackingData)
    (t : ℝ) (ht : 0 ≤ t) (x : MechanicalState)
    (hE : errorEnergy c.k₀ (x.1-c.r t)
      (x.2.1-x.2.2-2*c.r₁ t+2*c.k₁*(x.1-c.r t)) ≤ c.cap)
    (hw : c.wlo ≤ x.2.2 ∧ x.2.2 ≤ c.whi) : x ∈ c.safeBox := by
  have hb := trajectory_enclosure (h:=fun _ => x.1) (v:=fun _ => x.2.1)
    (w:=fun _ => x.2.2) c.k₀_pos hE (c.ref_bounds t ht) (c.rate_bound t ht)
  have hq := abs_le.mp hb.2.2
  change (c.hlo ≤ x.1 ∧ x.1 ≤ c.hhi) ∧
    (c.vlo ≤ x.2.1 ∧ x.2.1 ≤ c.vhi) ∧ c.wlo ≤ x.2.2 ∧ x.2.2 ≤ c.whi
  refine ⟨⟨hb.1,hb.2.1⟩,⟨?_,?_⟩,hw.1,hw.2⟩ <;>
    dsimp [vlo,vhi,Q,heightRate] at * <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

def GlobalTrackingData.project (c : GlobalTrackingData) (x : MechanicalState) : MechanicalState :=
  (max (c.hlo/2) (min (c.hhi+1) x.1),
   max (c.vlo-1) (min (c.vhi+1) x.2.1),
   max (c.wlo-1) (min (c.whi+1) x.2.2))

theorem GlobalTrackingData.project_lipschitz (c : GlobalTrackingData) :
    LipschitzWith 1 c.project := by
  have hh : LipschitzWith 1 (fun x : MechanicalState =>
      max (c.hlo/2) (min (c.hhi+1) x.1)) :=
    (LipschitzWith.prod_fst.const_min _).const_max _
  have hv : LipschitzWith 1 (fun x : MechanicalState => x.2.1) := by
    simpa using! LipschitzWith.prod_fst.comp (LipschitzWith.prod_snd (α:=ℝ) (β:=ℝ×ℝ))
  have hw : LipschitzWith 1 (fun x : MechanicalState => x.2.2) := by
    simpa using! LipschitzWith.prod_snd.comp (LipschitzWith.prod_snd (α:=ℝ) (β:=ℝ×ℝ))
  simpa only [max_self] using! hh.prodMk
    (((hv.const_min (c.vhi+1)).const_max (c.vlo-1)).prodMk
      ((hw.const_min (c.whi+1)).const_max (c.wlo-1)))

theorem GlobalTrackingData.initial_mem (c : GlobalTrackingData) : c.x₀ ∈ c.safeBox :=
  c.box_of_energy_speed 0 le_rfl c.x₀ c.initial_energy c.initial_speed

theorem GlobalTrackingData.project_mem (c : GlobalTrackingData) (x : MechanicalState) :
    c.project x ∈ c.outerBox := by
  have hx := c.initial_mem
  rcases hx with ⟨hh,hv,hw⟩
  have hp : 0 < c.hlo := c.height_positive
  exact ⟨⟨le_max_left _ _,max_le (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hh.1,hh.2]) (min_le_left _ _)⟩,
    ⟨le_max_left _ _,max_le (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hv.1,hv.2]) (min_le_left _ _)⟩,
    ⟨le_max_left _ _,max_le (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hw.1,hw.2]) (min_le_left _ _)⟩⟩

theorem GlobalTrackingData.project_eq (c : GlobalTrackingData) (x : MechanicalState)
    (hx : x ∈ c.outerBox) : c.project x = x := by
  rcases hx with ⟨hh,hv,hw⟩
  simp only [project,min_eq_right hh.2,max_eq_right hh.1,
    min_eq_right hv.2,max_eq_right hv.1,min_eq_right hw.2,max_eq_right hw.1]

theorem GlobalTrackingData.field_bounds (c : GlobalTrackingData) :
    ∃ L : ℝ≥0, ∃ C : ℝ,
      (∀ t, LipschitzOnWith L (c.field t) c.outerBox) ∧
      (∀ x ∈ c.outerBox, Continuous (fun t => c.field t x)) ∧
      ∀ t x, x ∈ c.outerBox → ‖c.field t x‖ ≤ C := by
  have hP : IsCompact c.parameterBox := isCompact_Icc.prod
    (isCompact_Icc.prod (isCompact_Icc.prod isCompact_Icc))
  have hB : IsCompact c.outerBox := isCompact_Icc.prod (isCompact_Icc.prod isCompact_Icc)
  have hcP : Convex ℝ c.parameterBox := (convex_Icc _ _).prod
    ((convex_Icc _ _).prod ((convex_Icc _ _).prod (convex_Icc _ _)))
  have hcB : Convex ℝ c.outerBox := (convex_Icc _ _).prod
    ((convex_Icc _ _).prod (convex_Icc _ _))
  have hsub : c.parameterBox ×ˢ c.outerBox ⊆ {y | 0 < y.2.1} := by
    intro y hy
    have hp : 0 < c.hlo := c.height_positive
    have hl : c.hlo/2 ≤ y.2.1 := hy.2.1.1
    change 0 < y.2.1
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  obtain ⟨L,C,hL,hC⟩ := smooth_compact_convex_bounds
    (isOpen_lt continuous_const (continuous_snd.fst)) c.jointField_smooth
    (hP.prod hB) (hcP.prod hcB) hsub
  refine ⟨L,C,?_,?_,?_⟩
  · intro t
    have hl := hL.comp (LipschitzWith.prodMk_left (c.parameters t)).lipschitzOnWith
      (fun x hx => ⟨c.parameters_mem t,hx⟩)
    simpa only [mul_one,Function.comp_def] using! hl
  · intro x hx
    exact (hL.continuousOn.comp_continuous
      (c.parameters_continuous.prodMk continuous_const)
      (fun t => ⟨c.parameters_mem t,hx⟩))
  · intro t x hx
    exact hC _ ⟨c.parameters_mem t,hx⟩

/-- This packages a finite prefix of the constructed solution for reuse of the
existing mechanical tracking theorem. Only the outer box is assumed here. -/
def GlobalTrackingData.toClassical (c : GlobalTrackingData) {x : ℝ → MechanicalState} {T : ℝ}
    (hbox : ∀ t ∈ Icc 0 T, x t ∈ c.outerBox)
    (hd : ∀ t ∈ Icc 0 T, HasDerivAt x (c.field t (x t)) t) :
    ClassicalSolution c.H c.g c.α c.β c.k₀ c.k₁ c.k₂ c.κd T where
  h := fun t => (x t).1
  v := fun t => (x t).2.1
  w := fun t => (x t).2.2
  r := c.r
  r₁ := c.r₁
  r₂ := c.r₂
  d := c.d
  h_ne := by
    intro t ht
    have hp : 0 < c.hlo := c.height_positive
    exact ne_of_gt (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hbox t ht).1.1])
  Hh_ne := by
    intro t ht
    have hp : 0 < c.hlo := c.height_positive
    exact ne_of_gt (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hbox t ht).1.1,c.H_pos])
  dh := by
    intro t ht
    simpa [field,jointField] using! hasFDerivAt_fst.comp_hasDerivAt t (hd t ht)
  dv := by
    intro t ht
    have hv := hasFDerivAt_fst.comp_hasDerivAt t
      (hasFDerivAt_snd.comp_hasDerivAt t (hd t ht))
    simpa [field,jointField,parameters,max_eq_right ht.1,requestedInput,heightError,velocityError] using! hv
  dw := by
    intro t ht
    simpa [field,jointField] using! hasFDerivAt_snd.comp_hasDerivAt t
      (hasFDerivAt_snd.comp_hasDerivAt t (hd t ht))
  dr := fun t ht => c.dr t ht.1
  dr₁ := fun t ht => c.dr₁ t ht.1

theorem GlobalTrackingData.prefix_energy (c : GlobalTrackingData)
    {x : ℝ → MechanicalState} {T : ℝ} (hx₀ : x 0 = c.x₀)
    (hbox : ∀ t ∈ Icc 0 T, x t ∈ c.outerBox)
    (hd : ∀ t ∈ Icc 0 T, HasDerivAt x (c.field t (x t)) t) :
    ∀ t ∈ Icc 0 T, (c.toClassical hbox hd).V t ≤ c.cap := by
  let sol := c.toClassical hbox hd
  have hinit : sol.V 0 ≤ c.cap := by
    simpa [ClassicalSolution.V,sol,toClassical,heightError,velocityError,hx₀] using! c.initial_energy
  have hcap0 : 0 ≤ c.cap := (energy_nonneg c.k₀_pos.le _ _).trans c.initial_energy
  rcases c.regime with hzero | hpos
  · have hdz : ∀ t ∈ Ico 0 T, sol.d t = 0 := by
      intro t ht
      have hb := c.disturbance_bound t ht.1
      rw [hzero] at hb
      exact abs_eq_zero.mp (le_antisymm hb (abs_nonneg _))
    have he := sol.nominal_damped_energy_bound c.k₀_pos.le c.κ_pos c.κ_le_k₁ c.κ_le_k₂
      c.κd_nonneg hdz
    intro t ht
    have henv := envelope_below_cap (C:=0) c.κ_pos ht.1 hinit (by simpa using! hcap0)
    exact (he t ht).trans (by simpa [envelope] using! henv)
  · have he := sol.energy_bound c.k₀_pos.le c.κ_pos c.κ_le_k₁ c.κ_le_k₂ hpos
      (fun t ht => c.disturbance_bound t ht.1)
    intro t ht
    have henv := envelope_below_cap (C:=c.dbar^2/(8*c.κd)) c.κ_pos ht.1 hinit
      (by convert! c.disturbance_cap using 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring)
    exact (he t ht).trans (by convert! henv using 1; unfold envelope; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring)

theorem GlobalTrackingData.prefix_bound (c : GlobalTrackingData)
    (x : ℝ → MechanicalState) (T : ℝ) (hT : 0 ≤ T) (hx₀ : x 0 = c.x₀)
    (hbox : ∀ t ∈ Icc 0 T, x t ∈ c.outerBox)
    (hd : ∀ t ∈ Icc 0 T, HasDerivAt x (c.field t (x t)) t) : x T ∈ c.safeBox := by
  let sol := c.toClassical hbox hd
  have hs := sol.physical_region_of_cap c.H_pos c.g_nonneg c.k₀_pos
    (c.prefix_energy hx₀ hbox hd)
    (fun t ht => c.ref_bounds t ht.1) (fun t ht => c.rate_bound t ht.1)
    c.height_positive c.forward c.speed_order c.crown c.lower_face_bound c.upper_face_bound
    (by simpa [sol,toClassical,hx₀] using! c.initial_speed) T ⟨hT,le_rfl⟩
  exact c.box_of_energy_speed T hT (x T) hs.1 ⟨hs.2.2.1,hs.2.2.2.1⟩

/-- Global existence for the actual controlled mechanical system, with continuous
bounded coefficient uncertainty. The initial state and reference are inputs;
the trajectory is constructed and the physical box follows as a conclusion. -/
theorem GlobalTrackingData.exists_global (c : GlobalTrackingData) :
    ∃ x : ℝ → MechanicalState, x 0 = c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      ∀ t ≥ 0, x t ∈ c.safeBox := by
  obtain ⟨L,C,hL,hcont,hC⟩ := c.field_bounds
  exact global_exists_of_retraction_and_prefix
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    c.project_lipschitz c.project_mem c.project_eq hL hcont hC c.x₀
    (c.safeBox_interior c.initial_mem) c.prefix_bound

/-- Forward uniqueness on the certified box. Equality is asserted only for
nonnegative times; the arbitrary backward extension is not part of the model. -/
theorem GlobalTrackingData.unique_on_nonnegative (c : GlobalTrackingData)
    {x y : ℝ → MechanicalState} (hx₀ : x 0 = c.x₀) (hy₀ : y 0 = c.x₀)
    (hdx : ∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t)
    (hdy : ∀ t ≥ 0, HasDerivAt y (c.field t (y t)) t)
    (hbx : ∀ t ≥ 0, x t ∈ c.safeBox) (hby : ∀ t ≥ 0, y t ∈ c.safeBox) :
    EqOn x y (Ici 0) := by
  obtain ⟨L,C,hL,hcont,hC⟩ := c.field_bounds
  intro T hT
  have heq := ODE_solution_unique_of_mem_Icc_right (a:=0) (b:=T) (s:=fun _ => c.outerBox)
    (fun t _ => hL t)
    (fun t ht => (hdx t ht.1).continuousAt.continuousWithinAt)
    (fun t ht => (hdx t ht.1).hasDerivWithinAt)
    (fun t ht => interior_subset (c.safeBox_interior (hbx t ht.1)))
    (fun t ht => (hdy t ht.1).continuousAt.continuousWithinAt)
    (fun t ht => (hdy t ht.1).hasDerivWithinAt)
    (fun t ht => interior_subset (c.safeBox_interior (hby t ht.1)))
    (hx₀.trans hy₀.symm)
  exact heq ⟨hT,le_rfl⟩

/-- The constructed trajectory satisfies the mechanical equations, the energy
cap, positive transport, and the requested crown margin for every t >= 0. -/
theorem GlobalTrackingData.exists_global_physical (c : GlobalTrackingData) :
    ∃ x : ℝ → MechanicalState, x 0 = c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      (∀ t ≥ 0, x t ∈ c.safeBox) ∧
      ∀ t ≥ 0,
        errorEnergy c.k₀ ((x t).1-c.r t)
          ((x t).2.1-(x t).2.2-2*c.r₁ t+2*c.k₁*((x t).1-c.r t)) ≤ c.cap ∧
        0 < (x t).1 ∧ c.wlo ≤ (x t).2.2 ∧ (x t).2.2 ≤ c.whi ∧
        0 < (x t).2.1 ∧ c.vmin ≤ ((x t).2.1+(x t).2.2)/2 := by
  obtain ⟨x,hx₀,hd,hbox⟩ := c.exists_global
  refine ⟨x,hx₀,hd,hbox,?_⟩
  intro T hT
  have hB : ∀ t ∈ Icc 0 T, x t ∈ c.outerBox :=
    fun t ht => interior_subset (c.safeBox_interior (hbox t ht.1))
  have hD := fun t (ht : t ∈ Icc 0 T) => hd t ht.1
  let sol := c.toClassical hB hD
  exact sol.physical_region_of_cap c.H_pos c.g_nonneg c.k₀_pos
    (c.prefix_energy hx₀ hB hD)
    (fun t ht => c.ref_bounds t ht.1) (fun t ht => c.rate_bound t ht.1)
    c.height_positive c.forward c.speed_order c.crown c.lower_face_bound c.upper_face_bound
    (by simpa [sol,toClassical,hx₀] using! c.initial_speed) T ⟨hT,le_rfl⟩

def GlobalTrackingData.stateEnergy (c : GlobalTrackingData) (t : ℝ) (x : MechanicalState) : ℝ :=
  errorEnergy c.k₀ (x.1-c.r t) (x.2.1-x.2.2-2*c.r₁ t+2*c.k₁*(x.1-c.r t))

/-- Global tracking with a constructed trajectory. The two implications keep
the undamped nominal case separate from the robust expression with κd > 0. -/
theorem GlobalTrackingData.exists_global_tracking (c : GlobalTrackingData) :
    ∃ x : ℝ → MechanicalState, x 0 = c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      (∀ t ≥ 0, x t ∈ c.safeBox) ∧
      (c.dbar = 0 → ∀ t ≥ 0,
        c.stateEnergy t (x t) ≤ exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀) ∧
      (0 < c.κd → ∀ t ≥ 0,
        c.stateEnergy t (x t) ≤ exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-exp (-2*c.κ*t))) := by
  obtain ⟨x,hx₀,hd,hbox⟩ := c.exists_global
  have hB (T : ℝ) : ∀ t ∈ Icc 0 T, x t ∈ c.outerBox :=
    fun t ht => interior_subset (c.safeBox_interior (hbox t ht.1))
  have hD (T : ℝ) := fun t (ht : t ∈ Icc 0 T) => hd t ht.1
  let sol (T : ℝ) := c.toClassical (hB T) (hD T)
  refine ⟨x,hx₀,hd,hbox,?_,?_⟩
  · intro hz T hT
    have hdz : ∀ t ∈ Ico 0 T, (sol T).d t = 0 := by
      intro t ht
      have hb := c.disturbance_bound t ht.1
      rw [hz] at hb
      exact abs_eq_zero.mp (le_antisymm hb (abs_nonneg _))
    have he := (sol T).nominal_damped_energy_bound c.k₀_pos.le c.κ_pos
      c.κ_le_k₁ c.κ_le_k₂ c.κd_nonneg hdz T ⟨hT,le_rfl⟩
    simpa [stateEnergy,ClassicalSolution.V,sol,toClassical,heightError,velocityError,hx₀] using! he
  · intro hp T hT
    have he := (sol T).energy_bound c.k₀_pos.le c.κ_pos c.κ_le_k₁ c.κ_le_k₂ hp
      (fun t ht => c.disturbance_bound t ht.1) T ⟨hT,le_rfl⟩
    simpa [stateEnergy,ClassicalSolution.V,sol,toClassical,heightError,velocityError,hx₀] using! he

end
end ChainFountain
