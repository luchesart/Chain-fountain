import ChainFountain.GlobalExistence
import ChainFountain.LebesgueFTC

namespace ChainFountain
noncomputable section
open Set Metric Real Filter MeasureTheory
open scoped Topology NNReal

/-- Replace only the disturbance component of the reference/parameter signal.
The existing certificate supplies geometric and reference data; its original
continuous disturbance is irrelevant to the field defined here. -/
def GlobalTrackingData.measurableParameters (c : GlobalTrackingData) (d : ℝ → ℝ) (t : ℝ) :
    ReferenceParameters := ((c.parameters t).1,(c.parameters t).2.1,(c.parameters t).2.2.1,d t)

def GlobalTrackingData.measurableField (c : GlobalTrackingData) (d : ℝ → ℝ)
    (t : ℝ) (x : MechanicalState) : MechanicalState :=
  c.jointField (c.measurableParameters d t,x)

theorem GlobalTrackingData.joint_bounds (c : GlobalTrackingData) :
    ∃ L : ℝ≥0, ∃ N : ℝ, LipschitzOnWith L c.jointField (c.parameterBox ×ˢ c.outerBox) ∧
      ∀ y∈c.parameterBox ×ˢ c.outerBox, ‖c.jointField y‖≤ N := by
  have hP : IsCompact c.parameterBox := isCompact_Icc.prod
    (isCompact_Icc.prod (isCompact_Icc.prod isCompact_Icc))
  have hB : IsCompact c.outerBox := isCompact_Icc.prod (isCompact_Icc.prod isCompact_Icc)
  have hcP : Convex ℝ c.parameterBox := (convex_Icc _ _).prod
    ((convex_Icc _ _).prod ((convex_Icc _ _).prod (convex_Icc _ _)))
  have hcB : Convex ℝ c.outerBox := (convex_Icc _ _).prod
    ((convex_Icc _ _).prod (convex_Icc _ _))
  apply smooth_compact_convex_bounds
    (isOpen_lt continuous_const continuous_snd.fst) c.jointField_smooth
    (hP.prod hB) (hcP.prod hcB)
  intro y hy
  have hp : 0<c.hlo := c.height_positive
  have hl : c.hlo/2≤ y.2.1 := hy.2.1.1
  change 0<y.2.1
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

theorem GlobalTrackingData.measurable_parameters_mem (c : GlobalTrackingData) {d : ℝ → ℝ}
    (hb : ∀ t, |d t|≤ c.dbar) (t : ℝ) : c.measurableParameters d t∈c.parameterBox := by
  have hp := c.parameters_mem t
  exact ⟨hp.1,hp.2.1,hp.2.2.1,abs_le.mp (hb t)⟩

/-- The measured input enters the actual mechanical field. A globally bounded
extension constructs a global integral/a.e. curve. On a positive time interval
the extension is inactive, so this also proves local Caratheodory existence for
the original equations. Global inactivity still needs the a.e. region proof. -/
theorem GlobalTrackingData.exists_measurable_local (c : GlobalTrackingData) {d : ℝ → ℝ}
    (hdm : Measurable d) (hdb : ∀ t, |d t|≤ c.dbar) :
    ∃ x : ℝ → MechanicalState, ∃ C : ℝ≥0, ∃ ε : ℝ, 0<ε ∧
      LipschitzWith C x ∧ x 0=c.x₀ ∧
      (∀ t, x t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (c.project (x s))) ∧
      (∀ᵐ t ∂volume, HasDerivAt x (c.measurableField d t (c.project (x t))) t) ∧
      (∀ t∈Icc 0 ε, x t∈c.outerBox) ∧
      ∀ᵐ t ∂volume, t∈Icc 0 ε → HasDerivAt x (c.measurableField d t (x t)) t := by
  obtain ⟨L,N,hL,hN⟩ := c.joint_bounds
  let F := fun t x => c.measurableField d t (c.project x)
  have hfl : ∀ t, LipschitzWith L (F t) := by
    intro t
    have hh := hL.comp
      ((LipschitzWith.prodMk_left (c.measurableParameters d t)).comp c.project_lipschitz).lipschitzOnWith (s:=univ)
      (fun x _ => ⟨c.measurable_parameters_mem hdb t,c.project_mem x⟩)
    simpa [F,measurableField,lipschitzOnWith_univ] using! hh
  have hpm : Measurable (c.measurableParameters d) :=
    c.parameters_continuous.fst.measurable.prodMk
      (c.parameters_continuous.snd.fst.measurable.prodMk
        (c.parameters_continuous.snd.snd.fst.measurable.prodMk hdm))
  have hfm : ∀ f : ℝ → MechanicalState, Continuous f →
      AEStronglyMeasurable (fun t => F t (f t)) volume := by
    intro f hf
    let y (t : ℝ) : c.parameterBox ×ˢ c.outerBox :=
      ⟨(c.measurableParameters d t,c.project (f t)),
        c.measurable_parameters_mem hdb t,c.project_mem (f t)⟩
    have hy : Measurable y :=
      (hpm.prodMk (c.project_lipschitz.continuous.comp hf).measurable).subtype_mk
    have hc : Continuous (fun z : c.parameterBox ×ˢ c.outerBox => c.jointField z) :=
      hL.continuousOn.restrict
    exact (hc.measurable.comp hy).aestronglyMeasurable
  let C : ℝ≥0 := ⟨max N 0,le_max_right _ _⟩
  have hfc : ∀ t x, ‖F t x‖≤ C := fun t x =>
    (hN _ ⟨c.measurable_parameters_mem hdb t,c.project_mem x⟩).trans (le_max_left _ _)
  obtain ⟨x,hxL,hx₀,hxI,hxD⟩ := bounded_measurable_global_ae_exists hfl hfm hfc c.x₀
  have hi : c.x₀∈interior c.outerBox := c.safeBox_interior c.initial_mem
  obtain ⟨ρ,hρ,hρB⟩ := Metric.mem_nhds_iff.mp (mem_interior_iff_mem_nhds.mp hi)
  let ε := ρ/(2*(C+1))
  have hε : 0<ε := by dsimp [ε]; positivity
  have hstay (t : ℝ) (ht : t∈Icc 0 ε) : x t∈c.outerBox := by
    apply hρB
    rw [mem_ball,← hx₀]
    have hl := hxL.dist_le_mul t 0
    rw [Real.dist_eq,sub_zero,abs_of_nonneg ht.1] at hl
    have he : (C:ℝ)*ε<ρ := by
      dsimp [ε]
      rw [← mul_div_assoc]
      apply (div_lt_iff₀ (by positivity : 0<2*((C:ℝ)+1))).mpr
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [NNReal.coe_nonneg C]
    exact hl.trans_lt ((mul_le_mul_of_nonneg_left ht.2 C.property).trans_lt he)
  refine ⟨x,C,ε,hε,hxL,hx₀,hxI,hxD,hstay,?_⟩
  filter_upwards [hxD] with t ht hte
  simpa [F,c.project_eq (x t) (hstay t hte)] using! ht

end
end ChainFountain
