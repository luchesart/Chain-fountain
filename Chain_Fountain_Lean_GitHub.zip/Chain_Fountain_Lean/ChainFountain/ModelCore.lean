import Mathlib.Analysis.Calculus.Deriv.Pow
import Mathlib.Analysis.ODE.Gronwall
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Convert

/-!
# The reduced chain-fountain model
Paper: Boundary Actuation of a Chain Fountain, Latchezar Tomov.
All variables are real. The equations are assumed physical modelling laws;
the identities below are proved from those laws, not empirical validation.
-/

namespace ChainFountain

noncomputable section

def crownSq (v w : ℝ) : ℝ := ((v + w) / 2) ^ 2
def heightRate (v w : ℝ) : ℝ := (v - w) / 2
def rise (g α h v w u : ℝ) : ℝ :=
  (crownSq v w - (1 - α) * v ^ 2 - g * h - u) / h
def fall (H g β h v w : ℝ) : ℝ :=
  g + (-crownSq v w + β * w ^ 2) / (H + h)
def pickup (α v u : ℝ) : ℝ := (1 - α) * v ^ 2 + u
def energy (H g lam h v w : ℝ) : ℝ :=
  lam / 2 * (h * v ^ 2 + (H + h) * w ^ 2) + lam * g * h ^ 2

theorem crown_identity (v w : ℝ) :
    (v - w) * crownSq v w + (v - w) * (v ^ 2 + w ^ 2) / 4 =
      (v ^ 3 - w ^ 3) / 2 := by unfold crownSq; ring

/-- Proposition 3.1, the directional derivative of energy along the vector field. -/
theorem energy_balance (H g lam α β h v w u : ℝ)
    (hh : h ≠ 0) (hH : H + h ≠ 0) :
    lam / 2 * (heightRate v w * v ^ 2 + h * (2 * v * rise g α h v w u) +
      heightRate v w * w ^ 2 + (H + h) * (2 * w * fall H g β h v w)) +
      lam * g * (2 * h * heightRate v w) =
    lam * g * H * w - lam * (1 / 2 - α) * v ^ 3 -
      lam * (1 / 2 - β) * w ^ 3 - lam * u * v := by
  unfold heightRate rise fall crownSq
  field_simp <;> ring

/-- Proposition 3.1 with genuine derivatives, at every classical-solution time. -/
theorem energy_hasDerivAt {H g lam α β u t : ℝ} {h v w : ℝ → ℝ}
    (hh : h t ≠ 0) (hH : H + h t ≠ 0)
    (dh : HasDerivAt h (heightRate (v t) (w t)) t)
    (dv : HasDerivAt v (rise g α (h t) (v t) (w t) u) t)
    (dw : HasDerivAt w (fall H g β (h t) (v t) (w t)) t) :
    HasDerivAt (fun s => energy H g lam (h s) (v s) (w s))
      (lam * g * H * w t - lam * (1 / 2 - α) * v t ^ 3 -
       lam * (1 / 2 - β) * w t ^ 3 - lam * u * v t) t := by
  have hd := (((dh.mul (dv.pow 2)).add
    ((dh.const_add H).mul (dw.pow 2))).const_mul (lam / 2)).add
    ((dh.pow 2).const_mul (lam * g))
  convert! hd using 1
  convert! (energy_balance H g lam α β (h t) (v t) (w t) u hh hH).symm using 1 <;>
    simp only [Pi.pow_apply] <;> ring

def steadySpeedSq (H g β r : ℝ) : ℝ := g * (H + r) / (1 - β)
def steadyInput (H g α β r : ℝ) : ℝ :=
  g * (α * H - (1 - α - β) * r) / (1 - β)
def heightFromInput (H g α β u : ℝ) : ℝ :=
  (α * H - (1 - β) * u / g) / (1 - α - β)

theorem steady_input_balance (H g α β r : ℝ) (hβ : 1 - β ≠ 0) :
    steadyInput H g α β r = α * steadySpeedSq H g β r - g * r := by
  unfold steadyInput steadySpeedSq
  field_simp <;> ring

theorem steady_tension (H g α β r : ℝ) (hβ : 1 - β ≠ 0) :
    (1 - α) * steadySpeedSq H g β r + steadyInput H g α β r =
      g * (H + β * r) / (1 - β) := by
  unfold steadySpeedSq steadyInput
  field_simp <;> ring

theorem steady_tension_pos {H g β r : ℝ}
    (hH : 0 < H) (hg : 0 < g) (hβ : 0 ≤ β) (hβ1 : β < 1) (hr : 0 ≤ r) :
    0 < g * (H + β * r) / (1 - β) := by
  have hd : 0 < 1 - β := by linarith
  positivity

theorem steady_is_equilibrium {H g α β r v : ℝ}
    (_hr : r ≠ 0) (hH : H + r ≠ 0) (hβ : 1 - β ≠ 0)
    (hv : v ^ 2 = steadySpeedSq H g β r) :
    heightRate v v = 0 ∧
      rise g α r v v (steadyInput H g α β r) = 0 ∧
      fall H g β r v v = 0 := by
  have hc : crownSq v v = v ^ 2 := by unfold crownSq; ring
  have hb := steady_input_balance H g α β r hβ
  have hs : (1 - β) * v ^ 2 = g * (H + r) := by
    rw [hv, steadySpeedSq]; field_simp
  refine ⟨by simp [heightRate], ?_, ?_⟩
  · unfold rise; rw [hc]; rw [← hv] at hb
    have : v ^ 2 - (1 - α) * v ^ 2 - g * r - steadyInput H g α β r = 0 := by
      nlinarith
    rw [this]; simp
  · unfold fall; rw [hc]
    field_simp
    nlinarith [hs]

theorem input_height_inverse (H g α β r : ℝ)
    (hg : g ≠ 0) (hβ : 1 - β ≠ 0) (hαβ : 1 - α - β ≠ 0) :
    heightFromInput H g α β (steadyInput H g α β r) = r := by
  unfold heightFromInput steadyInput
  field_simp <;> ring

theorem passive_height_limit {H g α β r : ℝ}
    (hg : 0 < g) (hβ : 0 < 1 - β) (hαβ : 0 < 1 - α - β) :
    0 ≤ steadyInput H g α β r ↔ r ≤ α * H / (1 - α - β) := by
  unfold steadyInput
  rw [le_div_iff₀ hαβ, le_div_iff₀ hβ]
  constructor
  · intro hu; nlinarith
  · intro hr; nlinarith

theorem steady_state_iff {H g α β r v u : ℝ}
    (hr : r ≠ 0) (hH : H+r ≠ 0) (hβ : 1-β ≠ 0) :
    (rise g α r v v u=0 ∧ fall H g β r v v=0) ↔
      (v^2=steadySpeedSq H g β r ∧ u=steadyInput H g α β r) := by
  have hc : crownSq v v=v^2 := by unfold crownSq; ring
  constructor
  · rintro ⟨hu,hf⟩
    unfold fall at hf; rw [hc] at hf
    have heq : (1-β)*v^2=g*(H+r) := by
      field_simp at hf; nlinarith [hf]
    have hv : v^2=steadySpeedSq H g β r := by
      unfold steadySpeedSq; apply (eq_div_iff hβ).mpr; nlinarith [heq]
    refine ⟨hv,?_⟩
    unfold rise at hu; rw [hc] at hu
    have hnum := (div_eq_zero_iff.mp hu).resolve_right hr
    have hb := steady_input_balance H g α β r hβ
    rw [←hv] at hb; nlinarith
  · rintro ⟨hv,rfl⟩
    exact (steady_is_equilibrium hr hH hβ hv).2

end
end ChainFountain
