import ChainFountain.Region

namespace ChainFountain
noncomputable section
open Set Real MeasureTheory

/-- Sign preservation for a scalar differential inequality with a continuous,
time-dependent coefficient, proved using an integrating factor and the FTC. -/
theorem linear_sign_preservation {y y' K : ℝ → ℝ} {T : ℝ}
    (hK : Continuous K) (hy : ContinuousOn y (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt y (y' t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, y' t ≤ K t * y t) (h₀ : y 0 ≤ 0) :
    ∀ t ∈ Icc 0 T, y t ≤ 0 := by
  let A : ℝ → ℝ := fun t => ∫ s in (0 : ℝ)..t, K s
  have hA : ∀ t, HasDerivAt A (K t) t := fun t =>
    intervalIntegral.integral_hasDerivAt_right (hK.intervalIntegrable _ _)
      hK.aestronglyMeasurable.stronglyMeasurableAtFilter hK.continuousAt
  have hAc : Continuous A := continuous_iff_continuousAt.mpr (fun t => (hA t).continuousAt)
  have hc : ContinuousOn (fun t => y t * exp (-A t)) (Icc 0 T) :=
    hy.mul (Real.continuous_exp.comp hAc.neg).continuousOn
  have hder : ∀ t ∈ Ico 0 T, HasDerivWithinAt (fun t => y t * exp (-A t))
      ((y' t - K t * y t) * exp (-A t)) (Ici t) t := by
    intro t ht
    convert! (hd t ht).mul ((hA t).neg.exp.hasDerivWithinAt) using 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hin : y 0 * exp (-A 0) ≤ (0 : ℝ) := mul_nonpos_of_nonpos_of_nonneg h₀ (exp_pos _).le
  have hcmp := image_le_of_deriv_right_le_deriv_boundary hc hder hin continuousOn_const
    (fun t _ => hasDerivWithinAt_const t (Ici t) (0 : ℝ)) (by
      intro t ht
      exact mul_nonpos_of_nonpos_of_nonneg (sub_nonpos.mpr (hb t ht)) (exp_pos _).le)
  intro t ht
  exact nonpos_of_mul_nonpos_left (hcmp ht) (exp_pos _)

/-- The same comparison needs continuity only on the supplied time interval. -/
theorem linear_sign_preservation_on {y y' K : ℝ → ℝ} {T : ℝ}
    (hK : ContinuousOn K (Icc 0 T)) (hy : ContinuousOn y (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt y (y' t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, y' t ≤ K t * y t) (h₀ : y 0 ≤ 0) :
    ∀ t ∈ Icc 0 T, y t ≤ 0 := by
  by_cases hT : 0 ≤ T
  · let Kext : ℝ → ℝ := fun t => K (projIcc 0 T hT t)
    have hKe : Continuous Kext := hK.comp_continuous
      (continuous_subtype_val.comp continuous_projIcc) (fun t => (projIcc 0 T hT t).property)
    have hEq : ∀ t ∈ Icc 0 T, Kext t=K t := by
      intro t ht; simp [Kext,projIcc_of_mem hT ht]
    exact linear_sign_preservation hKe hy hd (by
      intro t ht; rw [hEq t (Ico_subset_Icc_self ht)]; exact hb t ht) h₀
  · intro t ht; exfalso; exact hT (ht.1.trans ht.2)

/-- Invariance of the falling-speed interval for an existing classical trajectory.
Unlike a boundary-only check this theorem proves the time-dependent conclusion.
The two continuous coefficients are the explicitly factored Riccati differences.
It does not assert construction or global continuation of a solution. -/
theorem speed_interval_invariant {h w q : ℝ → ℝ} {H g β T wlo whi : ℝ}
    (hw : ContinuousOn w (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt w (internal H g β (h t) (w t) (q t)) (Ici t) t)
    (hKl : ContinuousOn (fun t => -((1-β)*(w t+wlo)+2*q t)/(H+h t)) (Icc 0 T))
    (hKu : ContinuousOn (fun t => -((1-β)*(w t+whi)+2*q t)/(H+h t)) (Icc 0 T))
    (hl : ∀ t ∈ Ico 0 T, 0 ≤ internal H g β (h t) wlo (q t))
    (hu : ∀ t ∈ Ico 0 T, internal H g β (h t) whi (q t) ≤ 0)
    (h₀ : wlo ≤ w 0 ∧ w 0 ≤ whi) :
    ∀ t ∈ Icc 0 T, wlo ≤ w t ∧ w t ≤ whi := by
  have hlo := linear_sign_preservation_on hKl (continuousOn_const.sub hw)
    (fun t ht => (hd t ht).const_sub wlo) (by
      intro t ht
      have hi := internal_difference H g β (h t) (w t) wlo (q t)
      have hf := hl t ht
      simp only [neg_div]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hi]) (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [h₀.1] : wlo - w 0 ≤ 0)
  have hhi := linear_sign_preservation_on hKu (hw.sub continuousOn_const)
    (fun t ht => (hd t ht).sub_const whi) (by
      intro t ht
      have hi := internal_difference H g β (h t) (w t) whi (q t)
      have hf := hu t ht
      simp only [neg_div]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hi]) (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [h₀.2] : w 0 - whi ≤ 0)
  intro t ht; exact ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hlo t ht], by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hhi t ht]⟩

/-- The geometric part of Theorem 6.1 on any supplied existence interval.
The energy estimate supplies h and q bounds independently in Region/Comparison. -/
theorem physical_region_invariant {h w q : ℝ → ℝ} {H g β T hlo hhi Q wlo whi vmin : ℝ}
    (hH : 0 < H) (hg : 0 ≤ g) (hlo0 : 0 < hlo)
    (hw : ContinuousOn w (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt w (internal H g β (h t) (w t) (q t)) (Ici t) t)
    (hKl : ContinuousOn (fun t => -((1-β)*(w t+wlo)+2*q t)/(H+h t)) (Icc 0 T))
    (hKu : ContinuousOn (fun t => -((1-β)*(w t+whi)+2*q t)/(H+h t)) (Icc 0 T))
    (hh : ∀ t ∈ Icc 0 T, hlo ≤ h t ∧ h t ≤ hhi)
    (hq : ∀ t ∈ Icc 0 T, |q t| ≤ Q)
    (hforward : 2*Q < wlo) (horder : wlo ≤ whi) (hcrown : vmin ≤ wlo-Q)
    (hl : (1-β)*wlo^2 + 2*Q*wlo + Q^2 ≤ g*(H+hlo))
    (hu : g*(H+hhi) ≤ (1-β)*whi^2 - 2*Q*whi + Q^2)
    (h₀ : wlo ≤ w 0 ∧ w 0 ≤ whi) :
    ∀ t ∈ Icc 0 T, 0 < h t ∧ wlo ≤ w t ∧ w t ≤ whi ∧
      0 < w t + 2*q t ∧ vmin ≤ w t+q t := by
  have hb := speed_interval_invariant hw hd hKl hKu (by
    intro t ht
    have htt := Ico_subset_Icc_self ht
    exact lower_face (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hh t htt).1]) hg (hh t htt).1 (hq t htt) hforward hl)
    (by
      intro t ht
      have htt := Ico_subset_Icc_self ht
      exact upper_face (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hh t htt).1]) hg (hh t htt).2 (hq t htt)
        (lt_of_lt_of_le hforward horder) hu) h₀
  intro t ht
  have hv := transport_positive (hb t ht).1 (hq t ht) hforward hcrown
  exact ⟨lt_of_lt_of_le hlo0 (hh t ht).1,(hb t ht).1,(hb t ht).2,hv.1,hv.2⟩

end
end ChainFountain
