import ChainFountain.CubicLyapunov
import ChainFountain.PrefixUniqueness

namespace ChainFountain
noncomputable section
open Set Metric Real Filter
open scoped Topology NNReal
set_option maxHeartbeats 800000

def clipState (r : ℝ) (x : State₃) : State₃ :=
  (max (-r) (min r x.1),max (-r) (min r x.2.1),max (-r) (min r x.2.2))

theorem clip_state_lipschitz (r : ℝ) : LipschitzWith 1 (clipState r) := by
  have hh : LipschitzWith 1 (fun x : State₃ => max (-r) (min r x.1)) :=
    (LipschitzWith.prod_fst.const_min _).const_max _
  have hv : LipschitzWith 1 (fun x : State₃ => x.2.1) := by
    simpa using! LipschitzWith.prod_fst.comp (LipschitzWith.prod_snd (α:=ℝ) (β:=ℝ×ℝ))
  have hw : LipschitzWith 1 (fun x : State₃ => x.2.2) := by
    simpa using! LipschitzWith.prod_snd.comp (LipschitzWith.prod_snd (α:=ℝ) (β:=ℝ×ℝ))
  simpa only [max_self] using! hh.prodMk
    (((hv.const_min r).const_max (-r)).prodMk ((hw.const_min r).const_max (-r)))

theorem clip_state_mem {r : ℝ} (hr : 0≤ r) (x : State₃) :
    clipState r x ∈ closedBall 0 r := by
  have hc (s : ℝ) : |max (-r) (min r s)|≤ r :=
    abs_le.mpr ⟨le_max_left _ _,max_le (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) (min_le_left _ _)⟩
  simpa only [mem_closedBall,dist_zero_right,Prod.norm_def,Real.norm_eq_abs,clipState]
    using max_le (hc x.1) (max_le (hc x.2.1) (hc x.2.2))

theorem clip_state_eq {r : ℝ} {x : State₃} (hx : x ∈ closedBall 0 r) :
    clipState r x = x := by
  simp only [mem_closedBall,dist_zero_right,Prod.norm_def,Real.norm_eq_abs,max_le_iff,abs_le] at hx
  simp [clipState,min_eq_right hx.1.2,max_eq_right hx.1.1,
    min_eq_right hx.2.1.2,max_eq_right hx.2.1.1,
    min_eq_right hx.2.2.2,max_eq_right hx.2.2.1]

theorem quadratic_trajectory_estimate (B : QuadraticBilin)
    {F : State₃ → State₃} {κ T : ℝ} {x : ℝ → State₃} (hκ : 0<κ)
    (hd : ∀ t ∈ Icc 0 T, HasDerivAt x (F (x t)) t)
    (hdec : ∀ t ∈ Icc 0 T, B (x t) (F (x t))+B (F (x t)) (x t) ≤ -2*κ*(B (x t) (x t))) :
    ∀ t ∈ Icc 0 T, B (x t) (x t) ≤ exp (-2*κ*t)*(B (x 0) (x 0)) := by
  have hder (t : ℝ) (ht : t∈Icc 0 T) :
      HasDerivAt (fun s => B (x s) (x s)) (B (x t) (F (x t))+B (F (x t)) (x t)) t := by
    convert! (B.hasFDerivAt.comp_hasDerivAt t (hd t ht)).clm_apply (hd t ht) using 1
    exact add_comm _ _
  have he := scalar_comparison (C:=0) hκ
    (fun t ht => (hder t ht).continuousAt.continuousWithinAt)
    (fun t ht => (hder t (Ico_subset_Icc_self ht)).hasDerivWithinAt)
    (fun t ht => by simpa using! hdec t (Ico_subset_Icc_self ht))
  simpa [envelope] using! he

/-- Full nonlinear forward existence and exponential decay near an equilibrium.
The hypotheses are a C1 field and a strict quadratic certificate for its genuine
derivative. The solution, invariant neighbourhood and decay constants are built. -/
theorem local_exponential_exists_unique_of_quadratic
    {F : State₃ → State₃} {A : State₃ →L[ℝ] State₃} {R : ℝ}
    (hR : 0<R) (hsmooth : ContDiffOn ℝ 1 F (ball 0 R))
    (hF : HasFDerivAt F A 0) (hzero : F 0=0) (B : QuadraticBilin)
    (hpos : ∀ x≠0, 0<B x x)
    (hneg : ∀ x≠0, B x (A x)+B (A x) x<0) :
    ∃ δ C κ : ℝ, 0<δ ∧ 0<C ∧ 0<κ ∧
      ∀ x₀ : State₃, ‖x₀‖<δ → ∃ x : ℝ → State₃,
        x 0=x₀ ∧ (∀ t≥0, HasDerivAt x (F (x t)) t) ∧
        (∀ t≥0, x t∈ball 0 R ∧ ‖x t‖≤ C*exp (-κ*t)*‖x₀‖) ∧
        ∀ T ≥ 0, ∀ y : ℝ → State₃, y 0 = x₀ →
          (∀ t ∈ Icc 0 T, HasDerivAt y (F (y t)) t) → EqOn x y (Icc 0 T) := by
  obtain ⟨m,M,κ,r,hm,hM,hκ,hr,hbounds,hdec⟩ :=
    nonlinear_quadratic_decay B hF hzero hpos hneg
  let C := sqrt (M/m)
  have hC : 0<C := sqrt_pos.2 (div_pos hM hm)
  have hCsq : C^2=M/m := sq_sqrt (div_nonneg hM.le hm.le)
  have hMC : m*C^2=M := by rw [hCsq]; field_simp
  let ρ := min r R / 2
  have hρ : 0<ρ := by dsimp [ρ]; positivity
  have hρr : ρ<r := by dsimp [ρ]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [min_le_left r R]
  have hρR : ρ<R := by dsimp [ρ]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [min_le_right r R]
  let δ := min (ρ/2) (ρ/(2*C))
  have hδ : 0<δ := by dsimp [δ]; positivity
  refine ⟨δ,C,κ,hδ,hC,hκ,fun x₀ hx₀ => ?_⟩
  have hxρ : ‖x₀‖<ρ/2 := lt_of_lt_of_le hx₀ (min_le_left _ _)
  have hxC : C*‖x₀‖≤ρ/2 := by
    have hh := lt_of_lt_of_le hx₀ (min_le_right _ _)
    have := (lt_div_iff₀ (show 0<2*C by positivity)).mp hh
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hsub : closedBall (0:State₃) ρ ⊆ ball 0 R :=
    closedBall_subset_ball hρR
  obtain ⟨L,N,hL,hN⟩ := smooth_compact_convex_bounds isOpen_ball hsmooth
    (isCompact_closedBall (0:State₃) ρ) (convex_closedBall (0:State₃) ρ) hsub
  have hKsub : closedBall (0:State₃) (ρ/2) ⊆ interior (closedBall 0 ρ) := by
    rw [interior_closedBall (0:State₃) hρ.ne']
    exact closedBall_subset_ball (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith)
  have hinit : x₀ ∈ interior (closedBall (0:State₃) ρ) :=
    hKsub (by simpa [mem_closedBall,dist_zero_right] using! hxρ.le)
  have hprefix (x : ℝ → State₃) (T : ℝ) (_hT : 0≤ T) (h₀ : x 0=x₀)
      (hbox : ∀ t∈Icc 0 T, x t∈closedBall 0 ρ)
      (hd : ∀ t∈Icc 0 T, HasDerivAt x (F (x t)) t) : x T∈closedBall 0 (ρ/2) := by
    have he := quadratic_trajectory_estimate B hκ hd (fun t ht =>
      hdec _ (lt_of_le_of_lt (by simpa [mem_closedBall,dist_zero_right] using! hbox t ht) hρr))
    have ht : T∈Icc (0:ℝ) T := ⟨_hT,le_rfl⟩
    have hE := he T ht
    rw [h₀] at hE
    have e0 : 0≤ B x₀ x₀ := (mul_nonneg hm.le (sq_nonneg ‖x₀‖)).trans (hbounds x₀).1
    have ee : exp (-2*κ*T)≤1 := exp_le_one_iff.mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith)
    have hcap : B (x T) (x T) ≤ M*‖x₀‖^2 :=
      hE.trans ((mul_le_of_le_one_left e0 ee).trans (hbounds x₀).2)
    have hs : (C*‖x₀‖)^2 ≤ (ρ/2)^2 := sq_le_sq₀ (by positivity) (by positivity) |>.2 hxC
    have hs' := mul_le_mul_of_nonneg_left hs hm.le
    rw [mul_pow,← mul_assoc,hMC] at hs'
    have hmineq := (hbounds (x T)).1.trans hcap
    have hsmall : ‖x T‖≤ρ/2 := (sq_le_sq₀ (norm_nonneg _) (by positivity)).mp
      ((mul_le_mul_iff_right₀ hm).mp (hmineq.trans hs'))
    simpa [mem_closedBall,dist_zero_right] using! hsmall
  obtain ⟨x,h₀,hd,hstay⟩ := global_exists_of_retraction_and_prefix
    (F:=fun _ x => F x) isClosed_closedBall hKsub (clip_state_lipschitz ρ)
    (clip_state_mem hρ.le) (fun _ hx => clip_state_eq hx) (fun _ => hL)
    (fun _ _ => continuous_const) (fun _ x hx => hN x hx) x₀ hinit hprefix
  have hu : ∀ T ≥ 0, ∀ y : ℝ → State₃, y 0 = x₀ →
      (∀ t ∈ Icc 0 T, HasDerivAt y (F (y t)) t) → EqOn x y (Icc 0 T) := by
    intro T hT y hy hdy
    exact unique_on_Icc_of_prefix_bound (F := fun _ z => F z)
      isClosed_closedBall hKsub hinit (fun _ => hL) hprefix hT h₀ hy
      (fun t ht => hd t ht.1) hdy
  refine ⟨x,h₀,hd,(fun t ht => ⟨?_,?_⟩),hu⟩
  · exact hsub (closedBall_subset_closedBall (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) (hstay t ht))
  · have he := quadratic_trajectory_estimate B hκ
      (fun s hs => hd s hs.1) (fun s hs => hdec _ (by
        have hb : ‖x s‖≤ρ/2 := by simpa [mem_closedBall,dist_zero_right] using! hstay s hs.1
        (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith)) t ⟨ht,le_rfl⟩
    rw [h₀] at he
    have hV := (hbounds (x t)).1.trans (he.trans
      (mul_le_mul_of_nonneg_left (hbounds x₀).2 (exp_pos _).le))
    have heexp : exp (-2*κ*t)=(exp (-κ*t))^2 := by rw [pow_two,← exp_add]; congr 1 <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    rw [heexp] at hV
    have hprod : m*(C*exp (-κ*t)*‖x₀‖)^2 = (exp (-κ*t))^2*(M*‖x₀‖^2) := by
      calc
        _ = (m*C^2)*(exp (-κ*t))^2*‖x₀‖^2 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
        _ = _ := by rw [hMC]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    have hs : ‖x t‖^2 ≤ (C*exp (-κ*t)*‖x₀‖)^2 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
    exact (sq_le_sq₀ (norm_nonneg _) (by positivity)).mp hs

/-- Compatibility form of the nonlinear existence and decay theorem. -/
theorem local_exponential_exists_of_quadratic
    {F : State₃ → State₃} {A : State₃ →L[ℝ] State₃} {R : ℝ}
    (hR : 0<R) (hsmooth : ContDiffOn ℝ 1 F (ball 0 R))
    (hF : HasFDerivAt F A 0) (hzero : F 0=0) (B : QuadraticBilin)
    (hpos : ∀ x≠0, 0<B x x)
    (hneg : ∀ x≠0, B x (A x)+B (A x) x<0) :
    ∃ δ C κ : ℝ, 0<δ ∧ 0<C ∧ 0<κ ∧
      ∀ x₀ : State₃, ‖x₀‖<δ → ∃ x : ℝ → State₃,
        x 0=x₀ ∧ (∀ t≥0, HasDerivAt x (F (x t)) t) ∧
        ∀ t≥0, x t∈ball 0 R ∧ ‖x t‖≤ C*exp (-κ*t)*‖x₀‖ := by
  obtain ⟨δ,C,κ,hδ,hC,hκ,hsol⟩ :=
    local_exponential_exists_unique_of_quadratic hR hsmooth hF hzero B hpos hneg
  refine ⟨δ,C,κ,hδ,hC,hκ,?_⟩
  intro x₀ hx₀
  obtain ⟨x,hx,hd,hb,hu⟩ := hsol x₀ hx₀
  exact ⟨x,hx,hd,hb⟩

end
end ChainFountain
