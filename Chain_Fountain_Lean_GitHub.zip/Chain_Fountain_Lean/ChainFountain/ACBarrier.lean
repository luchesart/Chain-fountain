import ChainFountain.AEBarrier
import ChainFountain.AbsoluteContinuity

namespace ChainFountain
noncomputable section
open Set Real Filter MeasureTheory
open scoped NNReal

/-- Scalar comparison for genuine absolutely continuous curves with an a.e.
differential inequality. Integrability and the reverse FTC are derived. -/
theorem scalar_comparison_ac {V V' : ℝ → ℝ} {T κ C : ℝ}
    (hκ : 0<κ) (hV : AbsolutelyContinuousOnInterval V 0 T)
    (hd : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt V (V' t) t)
    (hb : ∀ᵐ t ∂volume, t∈Ioo 0 T → V' t≤ -2*κ*V t+C) :
    ∀ t∈Icc 0 T, V t≤ envelope (V 0) κ C t := by
  by_cases hT : 0≤T
  swap
  · intro t ht
    linarith [ht.1,ht.2]
  let W (t : ℝ) := (V t-C/(2*κ))*exp (2*κ*t)
  let W' (t : ℝ) := (V' t+2*κ*(V t-C/(2*κ)))*exp (2*κ*t)
  have hWAC : AbsolutelyContinuousOnInterval W 0 T := by
    have he : ContDiff ℝ 1 (fun t : ℝ => exp (2*κ*t)) := by fun_prop
    obtain ⟨L,hL⟩ := smooth_comp_lipschitzOn he
      (LipschitzWith.id.lipschitzOnWith : LipschitzOnWith 1 (fun t : ℝ => t) (Icc 0 T))
    exact (hV.fun_sub ((LipschitzWith.const (C/(2*κ))).lipschitzOnWith.absolutelyContinuousOnInterval)).fun_mul
      (by rw [←uIcc_of_le hT] at hL; exact hL.absolutelyContinuousOnInterval)
  have hWd : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt W (W' t) t := by
    filter_upwards [hd] with t ht hmem
    convert! ((ht hmem).sub_const (C/(2*κ))).mul
      (((hasDerivAt_id t).const_mul (2*κ)).exp) using 1 <;> dsimp [W,W'] <;> ring
  have hWn : ∀ᵐ t ∂volume, t∈Ioo 0 T → W' t≤0 := by
    filter_upwards [hb] with t ht hmem
    have heq : 2*κ*(C/(2*κ))=C := by field_simp
    dsimp [W']
    apply mul_nonpos_of_nonpos_of_nonneg _ (exp_pos _).le
    nlinarith [ht hmem]
  intro t ht
  have hsub : Icc (0:ℝ) t ⊆ Icc 0 T := Icc_subset_Icc le_rfl ht.2
  have hsub' : uIcc (0:ℝ) t ⊆ uIcc 0 T := by
    rw [uIcc_of_le ht.1,uIcc_of_le (ht.1.trans ht.2)]
    exact hsub
  have hne (c : ℝ) : ∀ᵐ s ∂volume, s≠c := by simp [ae_iff,measure_singleton]
  have hWd' : ∀ᵐ s ∂volume, s∈uIcc 0 t → HasDerivAt W (W' s) s := by
    filter_upwards [hWd,hne 0,hne t] with s hs hs0 hst hmem
    rw [uIcc_of_le ht.1] at hmem
    exact hs ⟨lt_of_le_of_ne hmem.1 (Ne.symm hs0),(lt_of_le_of_ne hmem.2 hst).trans_le ht.2⟩
  obtain ⟨hi,hFTC⟩ := ac_integral_eq_sub (hWAC.mono hsub') hWd'
  have hint : (∫ s in (0:ℝ)..t, W' s)≤0 := by
    rw [intervalIntegral.integral_of_le ht.1]
    apply integral_nonpos_of_ae
    filter_upwards [ae_restrict_of_ae hWn,ae_restrict_of_ae (hne t),ae_restrict_mem measurableSet_Ioc] with s hs hst hmem
    exact hs ⟨hmem.1,(lt_of_le_of_ne hmem.2 hst).trans_le ht.2⟩
  have hw : W t≤W 0 := by linarith
  change W t≤ W 0 at hw
  dsimp [W] at hw
  simp only [mul_zero,exp_zero,mul_one] at hw
  have hdiv : V t-C/(2*κ) ≤ (V 0-C/(2*κ))/exp (2*κ*t) :=
    (le_div_iff₀ (exp_pos _)).mpr hw
  have heq : envelope (V 0) κ C t = C/(2*κ)+(V 0-C/(2*κ))/exp (2*κ*t) := by
    unfold envelope
    rw [show -2*κ*t=-(2*κ*t) by ring,exp_neg]
    ring
  rw [heq]
  linarith

/-- The feasible mechanical crown filter for arbitrary absolutely continuous
speed curves. This is a trajectory theorem, not filtered-loop existence. -/
theorem filtered_mechanical_crown_ac
    {H g β αlo αhi γ vmin uLo uHi T : ℝ}
    {h v w α desired : ℝ → ℝ}
    (hγ : 0<γ) (hα : αlo≤αhi)
    (hvL : AbsolutelyContinuousOnInterval v 0 T) (hwL : AbsolutelyContinuousOnInterval w 0 T)
    (hh : ∀ t∈Icc 0 T, 0<h t)
    (hcoef : ∀ t∈Icc 0 T, α t∈Icc αlo αhi)
    (hfeas : ∀ t∈Icc 0 T, max uLo (barrierLower αhi (v t))≤
      min uHi (barrierUpper H g β αlo (h t) (v t) (w t) γ ((v t+w t)/2-vmin)))
    (dv : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt v
      (rise g (α t) (h t) (v t) (w t)
        (filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t)) t)
    (dw : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt w (fall H g β (h t) (v t) (w t)) t) :
    ∀ t∈Icc 0 T,
      ((v 0+w 0)/2-vmin)*exp (-γ*t)≤(v t+w t)/2-vmin ∧
      uLo≤ filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t ∧
      filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t≤ uHi ∧
      0≤ pickup (α t) (v t) (filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t) := by
  let u := filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired
  let B := fun t => (v t+w t)/2-vmin
  have hclip (t : ℝ) (ht : t∈Icc 0 T) := clip_mem (desired:=desired t) (hfeas t ht)
  have hupper (t : ℝ) (ht : t∈Icc 0 T) :
      u t≤ barrierUpper H g β αlo (h t) (v t) (w t) γ (B t) :=
    (hclip t ht).2.trans (min_le_right _ _)
  have hcrown (t : ℝ) (ht : t∈Icc 0 T) :
      0≤(rise g (α t) (h t) (v t) (w t) (u t)+fall H g β (h t) (v t) (w t))/2+γ*B t :=
    ((crown_endpoint_iff (hh t ht) hα).mpr (hupper t ht)) (α t) (hcoef t ht)
  have hL : AbsolutelyContinuousOnInterval (fun t => -B t) 0 T := by
    have hc := (LipschitzWith.const vmin).lipschitzOnWith.absolutelyContinuousOnInterval (a:=0) (b:=T)
    have hm := AbsolutelyContinuousOnInterval.const_mul (1/2:ℝ) (hvL.fun_add hwL)
    simpa only [B,div_eq_mul_inv,mul_comm,one_mul,Pi.neg_apply] using! (hm.fun_sub hc).neg
  have hd : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt (fun s => -B s)
      (-((rise g (α t) (h t) (v t) (w t) (u t)+fall H g β (h t) (v t) (w t))/2)) t := by
    filter_upwards [dv,dw] with t ht hv hmem
    exact ((((ht hmem).add (hv hmem)).div_const 2).sub_const vmin).neg
  have hi := scalar_comparison_ac (κ:=γ/2) (C:=0) (by positivity) hL hd (by
    apply Eventually.of_forall
    intro t ht
    have hh := hcrown t (Ioo_subset_Icc_self ht)
    dsimp [B] at hh ⊢
    linarith)
  intro t ht
  refine ⟨?_,(le_max_left _ _).trans (hclip t ht).1,
    (hclip t ht).2.trans (min_le_left _ _),?_⟩
  · have hb := hi t ht
    dsimp [envelope] at hb
    have heq : -2*(γ/2)*t= -γ*t := by ring
    rw [heq] at hb
    simp only [zero_div,zero_mul,add_zero] at hb
    dsimp [B] at hb
    nlinarith
  · exact ((pickup_endpoint_iff hα).mpr ((le_max_right _ _).trans (hclip t ht).1))
      (α t) (hcoef t ht)

end
end ChainFountain
