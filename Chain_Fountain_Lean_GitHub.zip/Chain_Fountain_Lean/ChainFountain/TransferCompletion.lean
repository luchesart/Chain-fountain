import ChainFountain.Spectral

namespace ChainFountain
noncomputable section
open Polynomial

def transferNumerator (α ω h : ℝ) : ℝ[X] := C (-(1/(2*h))) * (X+C (2*α*ω))
def transferDenominator (α ρ ω : ℝ) : ℝ[X] :=
  X^3+C (coeff₂ ρ ω)*X^2+C (coeff₁ α ρ ω)*X+C (coeff₀ α ρ ω)

theorem transfer_denominator_eval (α ρ ω p : ℝ) :
    (transferDenominator α ρ ω).eval p=cubic α ρ ω p := by
  simp [transferDenominator,cubic]

theorem transfer_numerator_eval (α ω h p : ℝ) :
    (transferNumerator α ω h).eval p= -(p+2*α*ω)/(2*h) := by
  simp [transferNumerator]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem transfer_polynomial_degrees {α ρ ω h : ℝ} (hh : h≠0) :
    (transferNumerator α ω h).natDegree=1 ∧
    (transferDenominator α ρ ω).natDegree=3 := by
  constructor
  · unfold transferNumerator
    rw [natDegree_C_mul (by exact neg_ne_zero.mpr (one_div_ne_zero (mul_ne_zero (by norm_num) hh))),
      natDegree_X_add_C]
  · unfold transferDenominator
    compute_degree!

theorem transfer_relative_degree_two {α ρ ω h : ℝ} (hh : h≠0) :
    (transferDenominator α ρ ω).natDegree-(transferNumerator α ω h).natDegree=2 := by
  rw [(transfer_polynomial_degrees (α:=α) (ρ:=ρ) (ω:=ω) hh).1,(transfer_polynomial_degrees (α:=α) (ρ:=ρ) (ω:=ω) hh).2]

theorem transfer_static_gain_negative {α ρ ω h : ℝ}
    (ha : 0<α) (hr : ρ<1) (hw : 0<ω) (hh : 0<h) :
    (transferNumerator α ω h).eval 0/(transferDenominator α ρ ω).eval 0 < 0 := by
  rw [transfer_numerator_eval,transfer_denominator_eval]
  simp only [cubic,zero_pow (by decide : 3≠0),zero_pow (by decide : 2≠0),
    mul_zero,zero_add,add_zero]
  have hrp : 0<1-ρ := sub_pos.mpr hr
  have hc : 0<coeff₀ α ρ ω := by unfold coeff₀; positivity
  exact div_neg_of_neg_of_pos (div_neg_of_neg_of_pos (neg_neg_of_pos (by positivity)) (by positivity)) hc

theorem transfer_physical_zero {α g h s : ℝ} (hh : h≠0) (hs : s≠0)
    (heq : α*s^2=g*h) : -2*α*(s/h) = -2*g/s := by
  field_simp
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [heq]

end
end ChainFountain
