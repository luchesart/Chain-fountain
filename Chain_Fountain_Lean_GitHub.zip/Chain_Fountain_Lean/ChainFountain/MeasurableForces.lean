import ChainFountain.MeasurableTracking
import ChainFountain.GlobalForces

namespace ChainFountain
noncomputable section
open Set Real MeasureTheory
open scoped NNReal

theorem GlobalTrackingData.force_of_energy_box_disturbance (c : GlobalTrackingData)
    (ha : c.α ≤ 1) (hb : 0 ≤ c.β) {uLo uHi t δ : ℝ} {x : MechanicalState}
    (hc : c.forceCertificate uLo uHi) (ht : 0 ≤ t) (hbox : x ∈ c.safeBox)
    (hE : c.stateEnergy t x ≤ c.cap) (hδ : |δ|≤ c.dbar) :
    uLo ≤ c.command t x ∧ c.command t x ≤ uHi ∧
      0 ≤ pickup (c.α+δ) x.2.1 (c.command t x) := by
  have hR : 0 ≤ c.R₁ := (abs_nonneg _).trans (c.rate_bound 0 le_rfl)
  have hQ : 0 ≤ c.Q := by dsimp [Q]; positivity
  have hf : 2*c.Q < c.wlo := c.forward
  have hvlo : 0 ≤ c.vlo := by dsimp [vlo]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hwlo : 0 ≤ c.wlo := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hslo : 0 ≤ c.wlo-c.Q := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hS : c.wlo-c.Q ≤ (x.2.1+x.2.2)/2 ∧ (x.2.1+x.2.2)/2 ≤ c.whi+c.Q := by
    have hv := hbox.2.1
    have hw := hbox.2.2
    change c.wlo-2*c.Q ≤ x.2.1 ∧ x.2.1 ≤ c.whi+2*c.Q at hv
    constructor <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hv.1,hv.2,hw.1,hw.2]
  have he := error_enclosure (k₁:=c.k₁) c.k₀_pos hE
  have hq : |heightRate x.2.1 x.2.2-c.r₁ t| ≤ sqrt (2*c.cap)*sqrt (1+c.k₁^2/c.k₀) := by
    convert! he.2.2 using 1 <;> congr 1 <;> unfold heightRate <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hA := acceleration_bound c.k₀_pos.le (c.κ_pos.le.trans c.κ_le_k₁)
    (c.κ_pos.le.trans c.κ_le_k₂) he.1 hq (c.accel_bound t ht)
  exact robust_force_feasibility c.H_pos c.g_nonneg ha hb c.height_positive
    hbox.1 (square_interval hvlo hbox.2.1) (square_interval hwlo hbox.2.2).2
    (square_interval hslo hS) hA c.κd_nonneg he.2.1 hδ
    hc.1 hc.2.1 hc.2.2

/-- The global actuator and physical-domain certificate now allows a bounded
measurable disturbance. A solution is constructed, and no trajectory is an input. -/
theorem GlobalTrackingData.exists_global_measurable_admissible (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : Measurable d) (hdb : ∀ t, |d t|≤ c.dbar)
    (ha : c.α≤1) (hb : 0≤ c.β) (uLo uHi : ℝ) (hc : c.forceCertificate uLo uHi) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      ∀ t≥0, c.stateEnergy t (x t)≤ c.cap ∧ 0<(x t).1 ∧ 0<(x t).2.1 ∧
        c.vmin≤((x t).2.1+(x t).2.2)/2 ∧
        uLo≤ c.command t (x t) ∧ c.command t (x t)≤ uHi ∧
        0≤ pickup (c.α+d t) (x t).2.1 (c.command t (x t)) := by
  obtain ⟨x,K,hxL,hx₀,hxD,hbox,hE⟩ := c.exists_global_measurable_tracking hκd hdm hdb
  refine ⟨x,K,hxL,hx₀,hxD,hbox,fun t ht => ?_⟩
  have hB := hbox t ht
  have hEn := (hE t ht).1
  have hforce := c.force_of_energy_box_disturbance ha hb hc ht hB hEn (hdb t)
  have hh : 0<(x t).1 := lt_of_lt_of_le c.height_positive hB.1.1
  have hv : 0<(x t).2.1 := by
    have hvl := hB.2.1.1
    change c.wlo-2*c.Q≤(x t).2.1 at hvl
    have hf : 2*c.Q<c.wlo := c.forward
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hs : c.vmin≤((x t).2.1+(x t).2.2)/2 := by
    have hvl := hB.2.1.1
    change c.wlo-2*c.Q≤(x t).2.1 at hvl
    have hwl := hB.2.2.1
    have hcr : c.vmin≤ c.wlo-c.Q := c.crown
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  exact ⟨hEn,hh,hv,hs,hforce⟩

/-- The physical certificate also admits Lebesgue-a.e. measurable inputs. A
bounded Borel representative constructs the solution; the original disturbance
is recovered in the a.e. ODE, and its pointwise bound certifies pickup tension. -/
theorem GlobalTrackingData.exists_global_aemeasurable_admissible (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : AEMeasurable d volume) (hdb : ∀ t, |d t|≤ c.dbar)
    (ha : c.α≤1) (hb : 0≤ c.β) (uLo uHi : ℝ) (hc : c.forceCertificate uLo uHi) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      ∀ t≥0, c.stateEnergy t (x t)≤ c.cap ∧ 0<(x t).1 ∧ 0<(x t).2.1 ∧
        c.vmin≤((x t).2.1+(x t).2.2)/2 ∧
        uLo≤ c.command t (x t) ∧ c.command t (x t)≤ uHi ∧
        0≤ pickup (c.α+d t) (x t).2.1 (c.command t (x t)) := by
  have hb0 : 0≤ c.dbar := (abs_nonneg (d 0)).trans (hdb 0)
  have horder : -c.dbar≤ c.dbar := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  let b : ℝ → ℝ := fun t => max (-c.dbar) (min c.dbar (hdm.mk d t))
  have hbm : Measurable b := measurable_const.max (measurable_const.min hdm.measurable_mk)
  have hbb (t : ℝ) : |b t|≤ c.dbar := by
    apply abs_le.mpr
    exact ⟨le_max_left _ _,max_le horder (min_le_left _ _)⟩
  have heq : d =ᵐ[volume] b := by
    filter_upwards [hdm.ae_eq_mk] with t ht
    have hb := abs_le.mp (hdb t)
    simp only [b,← ht,min_eq_right hb.2,max_eq_right hb.1]
  obtain ⟨x,K,hxL,hx₀,hxD,hbox,hrest⟩ :=
    c.exists_global_measurable_admissible hκd hbm hbb ha hb uLo uHi hc
  refine ⟨x,K,hxL,hx₀,?_,hbox,fun t ht => ?_⟩
  · filter_upwards [hxD,heq] with t hdt he ht
    simpa only [measurableField,measurableParameters,← he] using! hdt ht
  · have hr := hrest t ht
    have hf := c.force_of_energy_box_disturbance ha hb hc ht (hbox t ht) hr.1 (hdb t)
    exact ⟨hr.1,hr.2.1,hr.2.2.1,hr.2.2.2.1,hf⟩

/-- The full robust envelope for a.e.-measurable pointwise-bounded disturbances. -/
theorem GlobalTrackingData.exists_global_aemeasurable_tracking (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : AEMeasurable d volume) (hdb : ∀ t, |d t|≤ c.dbar)
    :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      ∀ t≥0, c.stateEnergy t (x t)≤ c.cap ∧
        c.stateEnergy t (x t)≤ exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-exp (-2*c.κ*t)) := by
  have hb0 : 0≤ c.dbar := (abs_nonneg (d 0)).trans (hdb 0)
  have horder : -c.dbar≤ c.dbar := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  let b : ℝ → ℝ := fun t => max (-c.dbar) (min c.dbar (hdm.mk d t))
  have hbm : Measurable b := measurable_const.max (measurable_const.min hdm.measurable_mk)
  have hbb (t : ℝ) : |b t|≤ c.dbar := by
    apply abs_le.mpr
    exact ⟨le_max_left _ _,max_le horder (min_le_left _ _)⟩
  have heq : d =ᵐ[volume] b := by
    filter_upwards [hdm.ae_eq_mk] with t ht
    have hb := abs_le.mp (hdb t)
    simp only [b,← ht,min_eq_right hb.2,max_eq_right hb.1]
  obtain ⟨x,K,hxL,hx₀,hxD,hbox,hrest⟩ :=
    c.exists_global_measurable_tracking hκd hbm hbb
  refine ⟨x,K,hxL,hx₀,?_,hbox,hrest⟩
  filter_upwards [hxD,heq] with t hdt he ht
  simpa only [measurableField,measurableParameters,← he] using! hdt ht

end
end ChainFountain
