import ChainFountain.QuadraticLyapunov

namespace ChainFountain
noncomputable section
set_option maxHeartbeats 800000

def linearSquare (L : State₃ →L[ℝ] ℝ) : QuadraticBilin := L.smulRight L

/-- An explicit sum-of-squares solution of the strict cubic Lyapunov problem.
No spectral-to-Lyapunov existence theorem is assumed. -/
def cubicBilin (a b c : ℝ) : QuadraticBilin :=
  linearSquare (a • fallProjection + (a^2) • riseProjection + (a*b-c) • heightProjection) +
  (a*c) • linearSquare (riseProjection + a • heightProjection) +
  (2*c*(a*b-c)) • linearSquare heightProjection +
  b • linearSquare (fallProjection + a • riseProjection) +
  (1+b) • linearSquare (b • riseProjection + c • heightProjection) +
  linearSquare (b • fallProjection + c • riseProjection) +
  (c*(a*b-c)) • linearSquare riseProjection

theorem cubic_bilin_squares (a b c : ℝ) (x : State₃) :
    cubicBilin a b c x x =
      (a*x.2.2+a^2*x.2.1+(a*b-c)*x.1)^2 + a*c*(x.2.1+a*x.1)^2 +
      2*c*(a*b-c)*x.1^2 + b*(x.2.2+a*x.2.1)^2 +
      (1+b)*(b*x.2.1+c*x.1)^2 + (b*x.2.2+c*x.2.1)^2 +
      c*(a*b-c)*x.2.1^2 := by
  simp [cubicBilin,linearSquare,heightProjection,riseProjection,fallProjection]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem cubic_bilin_positive {a b c : ℝ} (ha : 0<a) (hb : 0<b)
    (hc : 0<c) (hD : c<a*b) (x : State₃) (hx : x≠0) :
    0 < cubicBilin a b c x x := by
  rw [cubic_bilin_squares]
  have hD' : 0<a*b-c := sub_pos.mpr hD
  have h₁ : 0≤(a*x.2.2+a^2*x.2.1+(a*b-c)*x.1)^2 := sq_nonneg _
  have h₂ : 0≤ a*c*(x.2.1+a*x.1)^2 := by positivity
  have h₃ : 0≤2*c*(a*b-c)*x.1^2 := by positivity
  have h₄ : 0≤ b*(x.2.2+a*x.2.1)^2 := by positivity
  have h₅ : 0≤(1+b)*(b*x.2.1+c*x.1)^2 := by positivity
  have h₆ : 0≤(b*x.2.2+c*x.2.1)^2 := sq_nonneg _
  have h₇ : 0≤ c*(a*b-c)*x.2.1^2 := by positivity
  by_cases hx₁ : x.1=0
  · by_cases hx₂ : x.2.1=0
    · have hx₃ : x.2.2≠0 := by
        intro hh; apply hx; exact Prod.ext hx₁ (Prod.ext hx₂ hh)
      have h : 0 < (a*x.2.2+a^2*x.2.1+(a*b-c)*x.1)^2 := by
        simp only [hx₁,hx₂,mul_zero,add_zero]
        exact sq_pos_of_ne_zero (mul_ne_zero ha.ne' hx₃)
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
    · have h : 0 < c*(a*b-c)*x.2.1^2 := mul_pos (mul_pos hc hD') (sq_pos_of_ne_zero hx₂)
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  · have h : 0 < 2*c*(a*b-c)*x.1^2 := by positivity
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

def companionField (a b c : ℝ) (x : State₃) : State₃ :=
  (x.2.1,x.2.2,-c*x.1-b*x.2.1-a*x.2.2)

theorem cubic_bilin_dissipation (a b c : ℝ) (x : State₃) :
    cubicBilin a b c x (companionField a b c x) +
      cubicBilin a b c (companionField a b c x) x =
      -2*(a*b-c)*(a*c*x.1^2+b*x.2.1^2+b*x.2.2^2) := by
  simp [cubicBilin,linearSquare,companionField,heightProjection,riseProjection,fallProjection]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem cubic_bilin_strict_decay {a b c : ℝ} (ha : 0<a) (hb : 0<b)
    (hc : 0<c) (hD : c<a*b) (x : State₃) (hx : x≠0) :
    cubicBilin a b c x (companionField a b c x) +
      cubicBilin a b c (companionField a b c x) x < 0 := by
  rw [cubic_bilin_dissipation]
  have hn : 0 < a*c*x.1^2+b*x.2.1^2+b*x.2.2^2 := by
    have h₁ : 0≤ a*c*x.1^2 := by positivity
    have h₂ : 0≤ b*x.2.1^2 := by positivity
    have h₃ : 0≤ b*x.2.2^2 := by positivity
    by_cases hx₁ : x.1=0
    · by_cases hx₂ : x.2.1=0
      · have hx₃ : x.2.2≠0 := by intro hh; exact hx (Prod.ext hx₁ (Prod.ext hx₂ hh))
        have h : 0<b*x.2.2^2 := by positivity
        (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
      · have h : 0<b*x.2.1^2 := by positivity
        (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
    · have h : 0<a*c*x.1^2 := by positivity
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  exact mul_neg_of_neg_of_pos (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) hn

/-- The observability coordinates (height, its linearized first and second
derivatives) put the actual Jacobian into cubic companion form. -/
def observabilityMap (α β ρ ω : ℝ) : State₃ →L[ℝ] State₃ :=
  heightProjection.prod
    ((heightProjection.comp (paperJacobian α β ρ ω)).prod
      ((heightProjection.comp (paperJacobian α β ρ ω)).comp (paperJacobian α β ρ ω)))

theorem observability_intertwines (α β ρ ω : ℝ) (hrel : α=(1-β)*ρ) (x : State₃) :
    observabilityMap α β ρ ω (paperJacobian α β ρ ω x) =
      companionField (coeff₂ ρ ω) (coeff₁ α ρ ω) (coeff₀ α ρ ω)
        (observabilityMap α β ρ ω x) := by
  simp [observabilityMap,paperJacobian,heightProjection,riseProjection,fallProjection,
    companionField,coeff₂,coeff₁,coeff₀]
  rw [hrel]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem observability_injective {α β ρ ω : ℝ} (ha : 0<α) (hw : 0<ω)
    (hrel : α=(1-β)*ρ) : Function.Injective (observabilityMap α β ρ ω) := by
  apply (injective_iff_map_eq_zero _).mpr
  intro x hx
  have h₁ := congrArg Prod.fst hx
  have h₂ := congrArg (fun z : State₃ => z.2.1) hx
  have h₃ := congrArg (fun z : State₃ => z.2.2) hx
  simp [observabilityMap,paperJacobian,heightProjection,riseProjection,fallProjection] at h₁ h₂ h₃
  have hvw : x.2.1=x.2.2 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have he : 2*α*ω*x.2.2=0 := by
    rw [hrel] at h₃ ⊢
    rw [h₁,hvw] at h₃
    linear_combination h₃
  have hz : x.2.2=0 := (mul_eq_zero.mp he).resolve_left (by positivity)
  exact Prod.ext h₁ (Prod.ext (hvw.trans hz) hz)

def plantBilin (α β ρ ω : ℝ) : QuadraticBilin :=
  (cubicBilin (coeff₂ ρ ω) (coeff₁ α ρ ω) (coeff₀ α ρ ω)).bilinearComp
    (observabilityMap α β ρ ω) (observabilityMap α β ρ ω)

theorem plant_strict_lyapunov {α β ρ ω : ℝ}
    (ha : 0<α) (ha1 : α<1/2) (hr : 0<ρ) (hr1 : ρ<1) (hw : 0<ω)
    (hrel : α=(1-β)*ρ) :
    (∀ x≠0, 0<plantBilin α β ρ ω x x) ∧
    ∀ x≠0, plantBilin α β ρ ω x (paperJacobian α β ρ ω x) +
      plantBilin α β ρ ω (paperJacobian α β ρ ω x) x < 0 := by
  obtain ⟨h₂,h₁,h₀,hH⟩ := hurwitz_conditions ha ha1 hr hr1 hw
  have hinj := observability_injective ha hw hrel
  have hne (x : State₃) (hx : x≠0) : observabilityMap α β ρ ω x ≠ 0 := by
    intro h; apply hx; apply hinj; simpa using! h
  constructor
  · intro x hx
    simp only [plantBilin,ContinuousLinearMap.bilinearComp_apply]
    exact cubic_bilin_positive h₂ h₁ h₀ hH _ (hne x hx)
  · intro x hx
    simp only [plantBilin,ContinuousLinearMap.bilinearComp_apply]
    rw [observability_intertwines α β ρ ω hrel]
    exact cubic_bilin_strict_decay h₂ h₁ h₀ hH _ (hne x hx)

end
end ChainFountain
