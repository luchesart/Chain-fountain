import ChainFountain.AdditionalClaims

namespace ChainFountain
noncomputable section
open Set Filter MeasureTheory Real
open scoped Topology

/-- Actual second derivative in the noise direction: this identifies the
Hessian term, separately from the semimartingale Ito formula. -/
theorem energy_noise_second_derivative (k₀ e z σ G : ℝ) :
    (∀ a : ℝ, HasDerivAt (fun b => errorEnergy k₀ e (z+σ*G*b))
      ((z+σ*G*a)*σ*G/4) a) ∧
    ∀ a : ℝ, HasDerivAt (fun b => (z+σ*G*b)*σ*G/4) ((σ*G)^2/4) a := by
  constructor
  · intro a
    have hd := (((hasDerivAt_id a).const_mul (σ*G)).const_add z).pow 2
    convert! (hd.div_const 8).const_add (k₀*e^2/2) using 1 <;>
      dsimp [errorEnergy] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  · intro a
    convert! (((((hasDerivAt_id a).const_mul (σ*G)).const_add z).mul_const σ).mul_const G).div_const 4 using 1 <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- Exact finite-partition square identity underlying the quadratic Ito rule. -/
theorem quadratic_partition_identity (z : ℕ → ℝ) (n : ℕ) :
    z n^2-z 0^2 = ∑ i∈Finset.range n,
      (2*z i*(z (i+1)-z i)+(z (i+1)-z i)^2) := by
  induction n with
  | zero => simp
  | succ n ih => rw [Finset.sum_range_succ,← ih]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- The quadratic change-of-variable identity follows from convergence of left
Riemann sums and squared increments. These convergence hypotheses are explicit;
this theorem does not assert that Brownian-driven solutions satisfy them. -/
theorem quadratic_ito_of_partition_limits {z : ℕ → ℕ → ℝ} {z₀ zT I Q : ℝ}
    (hstart : ∀ n, z n 0=z₀) (hend : ∀ n, z n n=zT)
    (hI : Tendsto (fun n => ∑ i∈Finset.range n, z n i*(z n (i+1)-z n i)) atTop (𝓝 I))
    (hQ : Tendsto (fun n => ∑ i∈Finset.range n, (z n (i+1)-z n i)^2) atTop (𝓝 Q)) :
    zT^2-z₀^2=2*I+Q := by
  have hid (n : ℕ) : zT^2-z₀^2 =
      2*(∑ i∈Finset.range n, z n i*(z n (i+1)-z n i))+
        ∑ i∈Finset.range n, (z n (i+1)-z n i)^2 := by
    have h := quadratic_partition_identity (z n) n
    rw [hstart,hend] at h
    simpa only [Finset.sum_add_distrib,← Finset.mul_sum,mul_assoc] using! h
  have hlim := (hI.const_mul 2).add hQ
  have hc : Tendsto (fun _ : ℕ => zT^2-z₀^2) atTop (𝓝 (2*I+Q)) :=
    hlim.congr (fun n => (hid n).symm)
  exact tendsto_nhds_unique tendsto_const_nhds hc

/-- Expectation of a genuine integrable martingale remains its initial value. -/
theorem martingale_zero_mean {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    [IsProbabilityMeasure μ] {ℱ : Filtration ℝ ‹MeasurableSpace Ω›}
    {M : ℝ → Ω → ℝ} (hM : Martingale M ℱ μ) (h₀ : ∀ ω, M 0 ω=0)
    {t : ℝ} (ht : 0≤ t) : ∫ ω, M t ω ∂μ = 0 := by
  have h := hM.setIntegral_eq ht (s:=univ) MeasurableSet.univ
  simpa [h₀] using! h.symm

/-- The stopped expectation estimate from an explicit Ito/martingale
decomposition. The martingale mean-zero property is proved from conditional
expectations. The decomposition and its stopped integrability are hypotheses;
construction of a Brownian stochastic integral is not hidden in this statement. -/
theorem stopped_energy_expectation {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    [IsProbabilityMeasure μ] {ℱ : Filtration ℝ ‹MeasurableSpace Ω›}
    {M : ℝ → Ω → ℝ} {W I S D : Ω → ℝ} {t V₀ κ C : ℝ}
    (ht : 0≤ t) (hM : Martingale M ℱ μ) (h₀ : ∀ ω, M 0 ω=0)
    (hW : Integrable W μ) (hI : Integrable I μ) (hS : Integrable S μ)
    (hdecomp : ∀ᵐ ω ∂μ, W ω=V₀+D ω+M t ω)
    (hbound : ∀ᵐ ω ∂μ, D ω≤ -2*κ*I ω+C*S ω) :
    (∫ ω, W ω ∂μ)+2*κ*(∫ ω, I ω ∂μ) ≤ V₀+C*(∫ ω, S ω ∂μ) := by
  have hpt : ∀ᵐ ω ∂μ, W ω+2*κ*I ω≤ V₀+C*S ω+M t ω := by
    filter_upwards [hdecomp,hbound] with ω hd hb
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have he := integral_mono_ae (hW.add (hI.const_mul (2*κ)))
    ((integrable_const V₀ |>.add (hS.const_mul C)).add (hM.integrable t)) hpt
  simp only [Pi.add_apply] at he
  rw [integral_add hW (hI.const_mul (2*κ)),
    integral_add (f:=fun ω => V₀+C*S ω) ((integrable_const V₀).add (hS.const_mul C)) (hM.integrable t),
    integral_add (integrable_const V₀) (hS.const_mul C),
    integral_const_mul,integral_const_mul,martingale_zero_mean hM h₀ ht] at he
  simpa using! he

/-- The crown diffusion is nonzero only when the noise intensity is nonzero.
This repairs the omitted sigma assumption in the prose boundary argument. -/
theorem crown_normal_diffusion_nonzero {σ v h : ℝ}
    (hσ : σ≠0) (hv : 0<v) (hh : 0<h) : (1/2:ℝ)*σ*(v^2/h)≠0 := by
  exact mul_ne_zero (mul_ne_zero (by norm_num) hσ)
    (div_ne_zero (pow_ne_zero 2 hv.ne') hh.ne')

end
end ChainFountain
