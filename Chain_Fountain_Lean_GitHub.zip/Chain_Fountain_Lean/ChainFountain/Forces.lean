import ChainFountain.Region

namespace ChainFountain
noncomputable section

theorem square_interval {x lo hi : ℝ} (hlo : 0 ≤ lo) (hx : lo ≤ x ∧ x ≤ hi) :
    lo^2 ≤ x^2 ∧ x^2 ≤ hi^2 := by
  exact ⟨pow_le_pow_left₀ hlo hx.1 2, pow_le_pow_left₀ (hlo.trans hx.1) hx.2 2⟩

theorem acceleration_bound {k₀ k₁ k₂ e q r₁ r₂ ce cq R₂ : ℝ}
    (hk₀ : 0 ≤ k₀) (hk₁ : 0 ≤ k₁) (hk₂ : 0 ≤ k₂)
    (he : |e| ≤ ce) (hq : |q-r₁| ≤ cq) (hr : |r₂| ≤ R₂) :
    |acceleration k₀ k₁ k₂ e q r₁ r₂| ≤
      R₂+(k₁+k₂)*cq+(k₀+k₁*k₂)*ce := by
  unfold acceleration
  have h₁ := abs_sub r₂ ((k₁+k₂)*(q-r₁))
  have h₂ := abs_sub (r₂-(k₁+k₂)*(q-r₁)) ((k₀+k₁*k₂)*e)
  rw [abs_mul, abs_of_nonneg (by positivity : 0 ≤ k₁+k₂)] at h₁
  rw [abs_mul, abs_of_nonneg (by positivity : 0 ≤ k₀+k₁*k₂)] at h₂
  have h₃ := mul_le_mul_of_nonneg_left hq (by positivity : 0 ≤ k₁+k₂)
  have h₄ := mul_le_mul_of_nonneg_left he (by positivity : 0 ≤ k₀+k₁*k₂)
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

theorem damping_bound {κd v vmax h hlo z cz : ℝ}
    (hκd : 0 ≤ κd) (hhlo : 0 < hlo) (hh : hlo ≤ h)
    (hv : v^2 ≤ vmax^2) (hz : |z| ≤ cz) :
    |κd * v^4/h*z| ≤ κd * vmax^4/hlo*cz := by
  have hh0 : 0 < h := hhlo.trans_le hh
  have hv4 : v^4 ≤ vmax^4 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [sq_nonneg (v^2-vmax^2),sq_nonneg v,sq_nonneg vmax]
  have hdiv := div_le_div₀ (pow_nonneg (sq_nonneg vmax) 2) (show (v^2)^2 ≤ (vmax^2)^2 by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hv4]) hhlo hh
  have hdiv' : v^4/h ≤ vmax^4/hlo := by simpa only [←pow_mul] using hdiv
  have hm := mul_le_mul_of_nonneg_left hdiv' hκd
  have hprod := mul_le_mul hm hz (abs_nonneg z) (by positivity : 0 ≤ κd*(vmax^4/hlo))
  rw [abs_mul,abs_of_nonneg (by positivity : 0 ≤ κd*v^4/h)]
  convert! hprod using 1 <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

def lowerInputBound (H g α β hlo hhi vhi slo whi A D : ℝ) :=
  slo^2-(1-α)*vhi^2-2*g*hhi-β*hhi*whi^2/(H+hlo)-2*hhi*A-D
def upperInputBound (H g α hlo hhi vlo shi A D : ℝ) :=
  (1+hhi/(H+hlo))*shi^2-(1-α)*vlo^2-2*g*hlo+2*hhi*A+D
def lowerTensionBound (H g β hlo hhi slo whi A : ℝ) :=
  slo^2-hhi*(2*g+β*whi^2/(H+hlo)+2*A)

/-- Proposition 6.3's input enclosure, with explicit state-box hypotheses. -/
theorem force_box_bounds {H g α β h hLo hHi v vLo vHi w wHi sLo sHi A Amax D damp : ℝ}
    (hH : 0 < H) (hg : 0 ≤ g) (ha : α ≤ 1) (hb : 0 ≤ β)
    (hhLo : 0 < hLo) (hh : hLo ≤ h ∧ h ≤ hHi)
    (hv : vLo^2 ≤ v^2 ∧ v^2 ≤ vHi^2)
    (hw : w^2 ≤ wHi^2) (hs : sLo^2 ≤ crownSq v w ∧ crownSq v w ≤ sHi^2)
    (hA : |A| ≤ Amax) (hd : |damp| ≤ D) :
    lowerInputBound H g α β hLo hHi vHi sLo wHi Amax D ≤
      nominalInput H g α β h v w A+damp ∧
    nominalInput H g α β h v w A+damp ≤
      upperInputBound H g α hLo hHi vLo sHi Amax D := by
  have hh0 : 0 < h := hhLo.trans_le hh.1
  have hhHi : 0 < hHi := hh0.trans_le hh.2
  have hden : 0 < H+hLo := add_pos hH hhLo
  have hden' : 0 < H+h := add_pos hH hh0
  have ha0 : 0 ≤ 1-α := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hS : 0 ≤ crownSq v w := by unfold crownSq; positivity
  have hr0 : 0 ≤ h/(H+h) := by positivity
  have hr : h/(H+h) ≤ hHi/(H+hLo) := div_le_div₀ hhHi.le hh.2 hden (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith)
  have hlS : sLo^2 ≤ (1+h/(H+h))*crownSq v w := by
    have hp := mul_nonneg hr0 hS; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hs.1]
  have huS : (1+h/(H+h))*crownSq v w ≤ (1+hHi/(H+hLo))*sHi^2 := by
    exact mul_le_mul (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) hs.2 hS (by positivity)
  have hvL := mul_le_mul_of_nonneg_left hv.1 ha0
  have hvU := mul_le_mul_of_nonneg_left hv.2 ha0
  have hgL := mul_le_mul_of_nonneg_left hh.1 hg
  have hgU := mul_le_mul_of_nonneg_left hh.2 hg
  have hbn : 0 ≤ β*h*w^2/(H+h) := by positivity
  have hbnum : β*h*w^2 ≤ β*hHi*wHi^2 :=
    mul_le_mul (mul_le_mul_of_nonneg_left hh.2 hb) hw (sq_nonneg w) (by positivity)
  have hbU := div_le_div₀ (by positivity : 0 ≤ β*hHi*wHi^2) hbnum hden (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith : H+hLo ≤ H+h)
  have hA0 : 0 ≤ Amax := (abs_nonneg A).trans hA
  have hAA : |2*h*A| ≤ 2*hHi*Amax := by
    rw [abs_mul,abs_of_nonneg (by positivity : 0 ≤ 2*h)]
    exact mul_le_mul (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) hA (abs_nonneg A) (by positivity)
  have hAA' := abs_le.mp hAA
  have hd' := abs_le.mp hd
  unfold lowerInputBound upperInputBound nominalInput
  constructor <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

/-- Pickup-tension enclosure, using the same interval estimates. -/
theorem tension_box_bound {H g α β h hLo hHi v vHi w wHi sLo A Amax D damp d dbar : ℝ}
    (hH : 0 < H) (hg : 0 ≤ g) (hb : 0 ≤ β)
    (hhLo : 0 < hLo) (hh : hLo ≤ h ∧ h ≤ hHi)
    (hv : v^2 ≤ vHi^2) (hw : w^2 ≤ wHi^2)
    (hs : sLo^2 ≤ crownSq v w) (hA : |A| ≤ Amax)
    (hd : |damp| ≤ D) (hdd : |d| ≤ dbar) :
    lowerTensionBound H g β hLo hHi sLo wHi Amax-D-dbar*vHi^2 ≤
      pickup (α+d) v (nominalInput H g α β h v w A+damp) := by
  have hh0 : 0 < h := hhLo.trans_le hh.1
  have hhHi : 0 < hHi := hh0.trans_le hh.2
  have hden : 0 < H+hLo := add_pos hH hhLo
  have hS : 0 ≤ crownSq v w := by unfold crownSq; positivity
  have hp := mul_nonneg (show 0 ≤ h/(H+h) by positivity) hS
  have hgU := mul_le_mul_of_nonneg_left hh.2 hg
  have hbnum : β*h*w^2 ≤ β*hHi*wHi^2 :=
    mul_le_mul (mul_le_mul_of_nonneg_left hh.2 hb) hw (sq_nonneg w) (by positivity)
  have hbU := div_le_div₀ (by positivity : 0 ≤ β*hHi*wHi^2) hbnum hden (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith : H+hLo ≤ H+h)
  have hAA : |2*h*A| ≤ 2*hHi*Amax := by
    rw [abs_mul,abs_of_nonneg (by positivity : 0 ≤ 2*h)]
    exact mul_le_mul (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) hA (abs_nonneg A) (by positivity)
  have hAA' := abs_le.mp hAA
  have hd' := abs_le.mp hd
  have hdd' := abs_le.mp hdd
  have hdb0 : 0 ≤ dbar := (abs_nonneg d).trans hdd
  have hdv : d*v^2 ≤ dbar*vHi^2 := mul_le_mul hdd'.2 hv (sq_nonneg v) hdb0
  unfold lowerTensionBound pickup nominalInput
  have hrearr : hHi*(β*wHi^2/(H+hLo)) = β*hHi*wHi^2/(H+hLo) := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hrearr]

/-- Proposition 6.3 assembled for the actual damped input and uncertain pickup. -/
theorem robust_force_feasibility
    {H g α β h hLo hHi v vLo vHi w wHi sLo sHi A Amax κd z cz d dbar uLo uHi : ℝ}
    (hH : 0 < H) (hg : 0 ≤ g) (ha : α ≤ 1) (hb : 0 ≤ β)
    (hhLo : 0 < hLo) (hh : hLo ≤ h ∧ h ≤ hHi)
    (hv : vLo^2 ≤ v^2 ∧ v^2 ≤ vHi^2) (hw : w^2 ≤ wHi^2)
    (hs : sLo^2 ≤ crownSq v w ∧ crownSq v w ≤ sHi^2)
    (hA : |A| ≤ Amax) (hκd : 0 ≤ κd) (hz : |z| ≤ cz) (hd : |d| ≤ dbar)
    (hL : uLo ≤ lowerInputBound H g α β hLo hHi vHi sLo wHi Amax (κd*vHi^4/hLo*cz))
    (hU : upperInputBound H g α hLo hHi vLo sHi Amax (κd*vHi^4/hLo*cz) ≤ uHi)
    (hT : 0 ≤ lowerTensionBound H g β hLo hHi sLo wHi Amax-κd*vHi^4/hLo*cz-dbar*vHi^2) :
    uLo ≤ robustInput H g α β h v w A κd z ∧
      robustInput H g α β h v w A κd z ≤ uHi ∧
      0 ≤ pickup (α+d) v (robustInput H g α β h v w A κd z) := by
  have hD := damping_bound hκd hhLo hh.1 hv.2 hz
  have hF := force_box_bounds hH hg ha hb hhLo hh hv hw hs hA hD
  have hP := tension_box_bound (α:=α) hH hg hb hhLo hh hv.2 hw hs.1 hA hD hd
  exact ⟨hL.trans hF.1,hF.2.trans hU,hT.trans hP⟩

end
end ChainFountain
