import Mathlib.MeasureTheory.Integral.IntervalIntegral.AbsolutelyContinuousFun
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap
import Mathlib.Analysis.Calculus.Deriv.Prod
import Mathlib.Tactic

namespace ChainFountain
noncomputable section
open Set Filter MeasureTheory Function
open scoped Topology NNReal

/-- Lipschitz composition preserves genuine metric absolute continuity. -/
theorem ac_lipschitz_comp {E F : Type*} [PseudoMetricSpace E] [PseudoMetricSpace F]
    {f : ℝ → E} {g : E → F} {a b : ℝ} {K : ℝ≥0}
    (hf : AbsolutelyContinuousOnInterval f a b) (hg : LipschitzWith K g) :
    AbsolutelyContinuousOnInterval (g ∘ f) a b := by
  apply squeeze_zero (fun _ => Finset.sum_nonneg (fun _ _ => dist_nonneg))
    (fun _ => ?_) (by simpa using Tendsto.const_mul (K:ℝ) hf)
  rw [Finset.mul_sum]
  exact Finset.sum_le_sum (fun i _ => hg.dist_le_mul _ _)

/-- Absolute continuity is invariant under equality on the interval. -/
theorem ac_congr {E : Type*} [PseudoMetricSpace E] {f g : ℝ → E} {a b : ℝ}
    (hf : AbsolutelyContinuousOnInterval f a b) (he : EqOn g f (uIcc a b)) :
    AbsolutelyContinuousOnInterval g a b := by
  apply (absolutelyContinuousOnInterval_iff g a b).mpr
  intro ε hε
  obtain ⟨δ,hδ,hfδ⟩ := (absolutelyContinuousOnInterval_iff f a b).mp hf ε hε
  refine ⟨δ,hδ,?_⟩
  intro E hE hlen
  have hends := hE.1
  have heq : (∑ i ∈ Finset.range E.1, dist (g (E.2 i).1) (g (E.2 i).2)) =
      ∑ i ∈ Finset.range E.1, dist (f (E.2 i).1) (f (E.2 i).2) := by
    apply Finset.sum_congr rfl
    intro i hi
    rw [he (hends i hi).1,he (hends i hi).2]
  rw [heq]
  exact hfδ E hE hlen

/-- Product absolute continuity, using the product metric. -/
theorem ac_prod {E F : Type*} [PseudoMetricSpace E] [PseudoMetricSpace F]
    {f : ℝ → E} {g : ℝ → F} {a b : ℝ}
    (hf : AbsolutelyContinuousOnInterval f a b) (hg : AbsolutelyContinuousOnInterval g a b) :
    AbsolutelyContinuousOnInterval (fun t => (f t,g t)) a b := by
  apply squeeze_zero (fun _ => Finset.sum_nonneg (fun _ _ => dist_nonneg))
    (fun _ => ?_) (by simpa using Tendsto.add hf hg)
  rw [←Finset.sum_add_distrib]
  exact Finset.sum_le_sum (fun i _ => by
    rw [Prod.dist_eq]
    exact max_le_add_of_nonneg (dist_nonneg) (dist_nonneg))

/-- Reverse FTC for every real absolutely continuous curve, with its a.e.
derivative supplied by an equation. No Lipschitz regularity is assumed. -/
theorem ac_integral_eq_sub {f g : ℝ → ℝ} {a b : ℝ}
    (hf : AbsolutelyContinuousOnInterval f a b)
    (hd : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt f (g t) t) :
    IntervalIntegrable g volume a b ∧ (∫ t in a..b, g t)=f b-f a := by
  have he : deriv f =ᵐ[volume.restrict (uIoc a b)] g := by
    filter_upwards [ae_restrict_of_ae hd,ae_restrict_mem measurableSet_uIoc] with t ht hmem
    exact (ht (uIoc_subset_uIcc hmem)).deriv
  refine ⟨hf.intervalIntegrable_deriv.congr_ae he,?_⟩
  rw [←intervalIntegral.integral_congr_ae_restrict he,hf.integral_deriv_eq_sub]

/-- The complete scalar Caratheodory equivalence on a compact interval. -/
theorem ac_ae_iff_integral {f g : ℝ → ℝ} {a b : ℝ} (hab : a≤ b) :
    (AbsolutelyContinuousOnInterval f a b ∧
      ∀ᵐ t ∂volume, t∈Icc a b → HasDerivAt f (g t) t) ↔
    (IntervalIntegrable g volume a b ∧
      ∀ t∈Icc a b, f t=f a+∫ s in a..t, g s) := by
  constructor
  · rintro ⟨hf,hd⟩
    have hd' : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt f (g t) t := by
      simpa only [uIcc_of_le hab] using hd
    refine ⟨(ac_integral_eq_sub hf hd').1,?_⟩
    intro t ht
    have hsub : uIcc a t ⊆ uIcc a b := by
      rw [uIcc_of_le ht.1,uIcc_of_le hab]
      exact Icc_subset_Icc le_rfl ht.2
    have hd'' : ∀ᵐ s ∂volume, s∈uIcc a t → HasDerivAt f (g s) s := by
      filter_upwards [hd'] with s hs hmem using hs (hsub hmem)
    have hi := (ac_integral_eq_sub (hf.mono hsub) hd'').2
    linarith
  · rintro ⟨hg,he⟩
    have hprim := hg.absolutelyContinuousOnInterval_intervalIntegral (c:=a) (by simp)
    have hc : AbsolutelyContinuousOnInterval (fun _ : ℝ => f a) a b :=
      (LipschitzWith.const (f a)).lipschitzOnWith.absolutelyContinuousOnInterval
    refine ⟨ac_congr (hc.fun_add hprim) (by intro t ht; exact he t (by simpa only [uIcc_of_le hab] using ht)),?_⟩
    have hne (c : ℝ) : ∀ᵐ t ∂volume, t≠c := by
      simp [ae_iff, measure_singleton]
    filter_upwards [hg.ae_hasDerivAt_integral,hne a,hne b] with t ht hta htb hmem
    have hto : t∈Ioo a b := ⟨lt_of_le_of_ne hmem.1 (Ne.symm hta),lt_of_le_of_ne hmem.2 htb⟩
    have hp := (ht (by simpa [uIcc_of_le hab] using hmem) a (by simp)).const_add (f a)
    apply hp.congr_of_eventuallyEq
    filter_upwards [Ioo_mem_nhds hto.1 hto.2] with s hs
    exact he s (Ioo_subset_Icc_self hs)

/-- Reverse FTC in the three mechanical coordinates. This is an actual vector
integral, not three unrelated scalar conclusions. -/
theorem ac_state_integral_eq_sub {f g : ℝ → ℝ × (ℝ × ℝ)} {a b : ℝ}
    (hf : AbsolutelyContinuousOnInterval f a b)
    (hd : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt f (g t) t) :
    IntervalIntegrable g volume a b ∧ (∫ t in a..b, g t)=f b-f a := by
  have h₁ := ac_lipschitz_comp hf LipschitzWith.prod_fst
  have h₂ := ac_lipschitz_comp (ac_lipschitz_comp hf LipschitzWith.prod_snd) LipschitzWith.prod_fst
  have h₃ := ac_lipschitz_comp (ac_lipschitz_comp hf LipschitzWith.prod_snd) LipschitzWith.prod_snd
  have hd₁ : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt (fun s => (f s).1) (g t).1 t := by
    filter_upwards [hd] with t ht hmem
    exact hasFDerivAt_fst.comp_hasDerivAt t (ht hmem)
  have hd₂ : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt (fun s => (f s).2.1) (g t).2.1 t := by
    filter_upwards [hd] with t ht hmem
    exact hasFDerivAt_fst.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t (ht hmem))
  have hd₃ : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt (fun s => (f s).2.2) (g t).2.2 t := by
    filter_upwards [hd] with t ht hmem
    exact hasFDerivAt_snd.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t (ht hmem))
  obtain ⟨hi₁,he₁⟩ := ac_integral_eq_sub h₁ hd₁
  obtain ⟨hi₂,he₂⟩ := ac_integral_eq_sub h₂ hd₂
  obtain ⟨hi₃,he₃⟩ := ac_integral_eq_sub h₃ hd₃
  have hi : IntervalIntegrable g volume a b :=
    ⟨hi₁.1.prodMk (hi₂.1.prodMk hi₃.1),hi₁.2.prodMk (hi₂.2.prodMk hi₃.2)⟩
  refine ⟨hi,?_⟩
  have hp₁ := (ContinuousLinearMap.fst ℝ ℝ (ℝ×ℝ)).intervalIntegral_comp_comm hi
  have hp₂ := ((ContinuousLinearMap.fst ℝ ℝ ℝ).comp
    (ContinuousLinearMap.snd ℝ ℝ (ℝ×ℝ))).intervalIntegral_comp_comm hi
  have hp₃ := ((ContinuousLinearMap.snd ℝ ℝ ℝ).comp
    (ContinuousLinearMap.snd ℝ ℝ (ℝ×ℝ))).intervalIntegral_comp_comm hi
  apply Prod.ext
  · exact hp₁.symm.trans he₁
  · exact Prod.ext (hp₂.symm.trans he₂) (hp₃.symm.trans he₃)

/-- Vector integral primitives are absolutely continuous in the mechanical
state space, including merely integrable right-hand sides. -/
theorem state_integral_ac {g : ℝ → ℝ × (ℝ × ℝ)} {a b : ℝ}
    (hg : IntervalIntegrable g volume a b) :
    AbsolutelyContinuousOnInterval (fun t => ∫ s in a..t, g s) a b := by
  have hi₁ : IntervalIntegrable (fun s => (g s).1) volume a b := ⟨hg.1.fst,hg.2.fst⟩
  have hi₂ : IntervalIntegrable (fun s => (g s).2.1) volume a b := ⟨hg.1.snd.fst,hg.2.snd.fst⟩
  have hi₃ : IntervalIntegrable (fun s => (g s).2.2) volume a b := ⟨hg.1.snd.snd,hg.2.snd.snd⟩
  apply ac_congr (ac_prod
    (hi₁.absolutelyContinuousOnInterval_intervalIntegral (c:=a) (by simp))
    (ac_prod (hi₂.absolutelyContinuousOnInterval_intervalIntegral (c:=a) (by simp))
      (hi₃.absolutelyContinuousOnInterval_intervalIntegral (c:=a) (by simp))))
  intro t ht
  have hit := hg.mono_set (uIcc_subset_uIcc_left ht)
  exact Prod.ext
    ((ContinuousLinearMap.fst ℝ ℝ (ℝ×ℝ)).intervalIntegral_comp_comm hit).symm
    (Prod.ext (((ContinuousLinearMap.fst ℝ ℝ ℝ).comp
      (ContinuousLinearMap.snd ℝ ℝ (ℝ×ℝ))).intervalIntegral_comp_comm hit).symm
      (((ContinuousLinearMap.snd ℝ ℝ ℝ).comp
      (ContinuousLinearMap.snd ℝ ℝ (ℝ×ℝ))).intervalIntegral_comp_comm hit).symm)

/-- The full AC/a.e.-integral equivalence for the mechanical state space.
There is no Lipschitz, continuity-of-the-field, or pre-existing FTC hypothesis. -/
theorem ac_state_ae_iff_integral {f g : ℝ → ℝ × (ℝ × ℝ)} {a b : ℝ} (hab : a≤ b) :
    (AbsolutelyContinuousOnInterval f a b ∧
      ∀ᵐ t ∂volume, t∈Icc a b → HasDerivAt f (g t) t) ↔
    (IntervalIntegrable g volume a b ∧
      ∀ t∈Icc a b, f t=f a+∫ s in a..t, g s) := by
  constructor
  · rintro ⟨hf,hd⟩
    have hd' : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt f (g t) t := by
      simpa only [uIcc_of_le hab] using hd
    refine ⟨(ac_state_integral_eq_sub hf hd').1,?_⟩
    intro t ht
    have hsub : uIcc a t ⊆ uIcc a b := by
      rw [uIcc_of_le ht.1,uIcc_of_le hab]
      exact Icc_subset_Icc le_rfl ht.2
    have hd'' : ∀ᵐ s ∂volume, s∈uIcc a t → HasDerivAt f (g s) s := by
      filter_upwards [hd'] with s hs hmem using hs (hsub hmem)
    rw [(ac_state_integral_eq_sub (hf.mono hsub) hd'').2]
    abel
  · rintro ⟨hg,he⟩
    have hc : AbsolutelyContinuousOnInterval (fun _ : ℝ => f a) a b :=
      (LipschitzWith.const (f a)).lipschitzOnWith.absolutelyContinuousOnInterval
    refine ⟨ac_congr (hc.fun_add (state_integral_ac hg)) ?_,?_⟩
    · intro t ht
      exact he t (by simpa only [uIcc_of_le hab] using ht)
    · have hne (c : ℝ) : ∀ᵐ t ∂volume, t≠c := by simp [ae_iff,measure_singleton]
      filter_upwards [hg.ae_hasDerivAt_integral,hne a,hne b] with t ht hta htb hmem
      have hto : t∈Ioo a b := ⟨lt_of_le_of_ne hmem.1 (Ne.symm hta),lt_of_le_of_ne hmem.2 htb⟩
      have hp := (ht (by simpa [uIcc_of_le hab] using hmem) a (by simp)).const_add (f a)
      apply hp.congr_of_eventuallyEq
      filter_upwards [Ioo_mem_nhds hto.1 hto.2] with s hs
      exact he s (Ioo_subset_Icc_self hs)

/-- A forward locally AC curve has a continuous extension to all real times,
constant before zero. No regularity at negative times is required of the curve. -/
theorem locally_ac_forward_extension {E : Type*} [NormedAddCommGroup E] {f : ℝ → E}
    (hf : ∀ T≥0, AbsolutelyContinuousOnInterval f 0 T) :
    Continuous (fun t => f (max 0 t)) := by
  rw [continuous_iff_continuousAt]
  intro t
  let N : ℝ := max 0 t+1
  have hN : 0≤ N := by dsimp [N]; positivity
  have hfc : ContinuousOn f (Icc 0 N) := by
    simpa only [uIcc_of_le hN] using AbsolutelyContinuousOnInterval.continuousOn (hf N hN)
  have hc : Continuous (fun s => f (projIcc 0 N hN s)) :=
    hfc.comp_continuous (continuous_subtype_val.comp continuous_projIcc)
      (fun s => (projIcc 0 N hN s).property)
  have htN : t<N := by dsimp [N]; linarith [le_max_right (0:ℝ) t]
  apply hc.continuousAt.congr_of_eventuallyEq
  filter_upwards [Iio_mem_nhds htN] with s hs
  by_cases hs0 : s≤0
  · rw [max_eq_left hs0,projIcc_of_le_left hN hs0]
  · have hs0' : 0≤ s := (not_le.mp hs0).le
    rw [max_eq_right hs0',projIcc_of_mem hN ⟨hs0',hs.le⟩]

end
end ChainFountain
