import ChainFountain.ModelCore
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus

/-!
# Driven circulation of a closed chain in zero gravity

The scalar plant describes distributed tangential actuation and homogeneous
linear tangential drag. It is a different geometry from the open fountain.
The results below concern circulation speed; no transverse shape stability is
asserted. Classical derivative hypotheses are explicit.
-/

namespace ChainFountain.ZeroGravity
noncomputable section
open Set Real

/-- Signed scalar Gronwall envelope used only by this zero-gravity module. -/
def scalarEnvelope (V0 κ C t : ℝ) : ℝ :=
  exp (-2 * κ * t) * V0 + C / (2 * κ) * (1 - exp (-2 * κ * t))

/-- Genuine-derivative scalar comparison, proved directly from Gronwall. -/
theorem scalarComparison {V V' : ℝ → ℝ} {T κ C : ℝ} (hκ : 0 < κ)
    (hc : ContinuousOn V (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt V (V' t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, V' t ≤ -2 * κ * V t + C) :
    ∀ t ∈ Icc 0 T, V t ≤ scalarEnvelope (V 0) κ C t := by
  have hG := le_gronwallBound_of_liminf_deriv_right_le hc
    (fun t ht _ hr => (hd t ht).liminf_right_slope_le hr) (le_refl (V 0)) hb
  intro t ht
  have h := hG t ht
  rw [gronwallBound, if_neg (by nlinarith : -2 * κ ≠ 0), sub_zero] at h
  unfold scalarEnvelope
  convert! h using 1
  ring

/-- The scalar envelope stays below a common cap on its endpoint amplitudes. -/
theorem scalarEnvelope_below_cap {V0 κ C cap t : ℝ}
    (hκ : 0 < κ) (ht : 0 ≤ t) (hV : V0 ≤ cap) (hC : C / (2 * κ) ≤ cap) :
    scalarEnvelope V0 κ C t ≤ cap := by
  have he0 : 0 ≤ exp (-2 * κ * t) := (exp_pos _).le
  have he1 : exp (-2 * κ * t) ≤ 1 := exp_le_one_iff.mpr (by nlinarith)
  have h1 := mul_le_mul_of_nonneg_left hV he0
  have h2 := mul_le_mul_of_nonneg_right hC (sub_nonneg.mpr he1)
  unfold scalarEnvelope
  nlinarith

/-- Tangential acceleration command, including reference feedforward. -/
def circulationCommand (γ k r rdot c : ℝ) : ℝ :=
  rdot + γ * r - k * (c - r)

/-- Exact cancellation for the tangential scalar plant. -/
theorem circulation_error_identity (γ k r rdot c d : ℝ) :
    circulationCommand γ k r rdot c - γ * c + d - rdot =
      -(γ + k) * (c - r) + d := by
  unfold circulationCommand
  ring

/-!
The feedback in the user's proposed command cancels drag at the reference,
so its actual error damping is γ+k. Using γ*c instead would give damping k.
Both forms have the same reference-tracking objective but different error
rates; the theorem records the actual rate rather than silently changing it.
-/

/-- Exact drag cancellation, when feedback compensation uses measured speed. -/
def circulationCompensatedCommand (γ k r rdot c : ℝ) : ℝ :=
  rdot + γ * c - k * (c - r)

theorem circulation_compensated_error_identity (γ k r rdot c d : ℝ) :
    circulationCompensatedCommand γ k r rdot c - γ * c + d - rdot =
      -k * (c - r) + d := by
  unfold circulationCompensatedCommand
  ring

/-- The reference-drag feedforward controller yields damping γ+k. -/
theorem circulation_error_hasDerivAt {c r : ℝ → ℝ} {γ k rdot d t : ℝ}
    (hc : HasDerivAt c
      (circulationCommand γ k (r t) rdot (c t) - γ * c t + d) t)
    (hr : HasDerivAt r rdot t) :
    HasDerivAt (fun s => c s - r s) (-(γ + k) * (c t - r t) + d) t := by
  convert! hc.sub hr using 1
  exact (circulation_error_identity γ k (r t) rdot (c t) d).symm

/-- Exponential envelope of a scalar stable equation with bounded forcing. -/
def circulationEnvelope (e0 a D t : ℝ) : ℝ :=
  exp (-a * t) * |e0| + D / a * (1 - exp (-a * t))

/-- Sharp scalar comparison, without differentiating the absolute value. -/
theorem circulation_error_bound {e d : ℝ → ℝ} {a D T : ℝ}
    (ha : 0 < a)
    (hc : ContinuousOn e (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T,
      HasDerivWithinAt e (-a * e t + d t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, |d t| ≤ D) :
    ∀ t ∈ Icc 0 T, |e t| ≤ circulationEnvelope (e 0) a D t := by
  have hu := scalarComparison (κ := a / 2) (C := D) (by linarith) hc hd
    (by intro t ht; linarith [(abs_le.mp (hb t ht)).2])
  have hl := scalarComparison (V := fun t => -e t)
    (V' := fun t => -(-a * e t + d t))
    (κ := a / 2) (C := D) (by linarith) hc.neg
    (fun t ht => (hd t ht).neg)
    (by intro t ht; nlinarith [(abs_le.mp (hb t ht)).1])
  intro t ht
  have hup := hu t ht
  have hlo := hl t ht
  have hpos := exp_pos (-a * t)
  have he1 : e 0 ≤ |e 0| := le_abs_self _
  have he2 : -e 0 ≤ |e 0| := neg_le_abs _
  have hup0 := mul_le_mul_of_nonneg_left he1 hpos.le
  have hlo0 := mul_le_mul_of_nonneg_left he2 hpos.le
  have hhalf : 2 * (a / 2) = a := by ring
  have hneg : -2 * (a / 2) * t = -a * t := by ring
  simp only [scalarEnvelope, hhalf, hneg] at hup hlo
  try dsimp only [Pi.neg_apply, Pi.sub_apply, Pi.add_apply, Pi.mul_apply, Pi.pow_apply] at hlo
  unfold circulationEnvelope
  exact abs_le.mpr ⟨by nlinarith, by nlinarith⟩

/-- The envelope is a convex combination of the initial error and D/a. -/
theorem circulation_envelope_below_max {e0 a D t : ℝ}
    (ha : 0 < a) (ht : 0 ≤ t) :
    circulationEnvelope e0 a D t ≤ max |e0| (D / a) := by
  have hhalf : 2 * (a / 2) = a := by ring
  have hneg : -2 * (a / 2) * t = -a * t := by ring
  have h := scalarEnvelope_below_cap (κ := a / 2) (V0 := |e0|) (C := D)
    (cap := max |e0| (D / a)) (by linarith) ht (le_max_left _ _)
    (by rw [hhalf]; exact le_max_right _ _)
  simpa only [circulationEnvelope, scalarEnvelope, hhalf, hneg] using h

/-- Exact exponential decay, including its sign, for the unforced equation. -/
theorem circulation_nominal_solution {e : ℝ → ℝ} {a T : ℝ}
    (ha : 0 < a)
    (hc : ContinuousOn e (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T,
      HasDerivWithinAt e (-a * e t) (Ici t) t) :
    ∀ t ∈ Icc 0 T, e t = exp (-a * t) * e 0 := by
  have hu := scalarComparison (κ := a / 2) (C := 0) (by linarith) hc hd
    (by intro t ht; ring_nf; exact le_rfl)
  have hl := scalarComparison (V := fun t => -e t)
    (V' := fun t => -(-a * e t))
    (κ := a / 2) (C := 0) (by linarith) hc.neg
    (fun t ht => (hd t ht).neg)
    (by intro t ht; nlinarith)
  intro t ht
  have hup := hu t ht
  have hlo := hl t ht
  have hneg : -2 * (a / 2) * t = -a * t := by ring
  simp only [scalarEnvelope, hneg, zero_div, zero_mul, add_zero] at hup hlo
  try dsimp only [Pi.neg_apply, Pi.sub_apply, Pi.add_apply, Pi.mul_apply, Pi.pow_apply] at hlo
  linarith

/-- A speed reference uniformly above the worst tracking error keeps circulation
strictly positive throughout every interval where the scalar equation holds. -/
theorem circulation_positive {c r d : ℝ → ℝ} {a D T rmin : ℝ}
    (ha : 0 < a)
    (hc : ContinuousOn (fun t => c t - r t) (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt (fun s => c s - r s)
      (-a * (c t - r t) + d t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, |d t| ≤ D)
    (hr : ∀ t ∈ Icc 0 T, rmin ≤ r t)
    (hmargin : max |c 0 - r 0| (D / a) < rmin) :
    ∀ t ∈ Icc 0 T, 0 < c t := by
  intro t ht
  have herr := (circulation_error_bound ha hc hd hb t ht).trans
    (circulation_envelope_below_max ha ht.1)
  have hlo := (abs_le.mp herr).1
  have href := hr t ht
  try dsimp only [Pi.neg_apply, Pi.sub_apply, Pi.add_apply, Pi.mul_apply, Pi.pow_apply] at hlo
  linarith

/-- Closed-loop robust estimate connected directly to plant derivatives. -/
theorem circulation_closedLoop_bound {c r rdot d : ℝ → ℝ} {γ k D T : ℝ}
    (ha : 0 < γ + k)
    (hc : ∀ t ∈ Icc 0 T, HasDerivAt c
      (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) t)
    (hr : ∀ t ∈ Icc 0 T, HasDerivAt r (rdot t) t)
    (hb : ∀ t ∈ Ico 0 T, |d t| ≤ D) :
    ∀ t ∈ Icc 0 T,
      |c t - r t| ≤ circulationEnvelope (c 0 - r 0) (γ + k) D t := by
  have hd := fun t ht => circulation_error_hasDerivAt (hc t ht) (hr t ht)
  exact circulation_error_bound ha
    (fun t ht => (hd t ht).continuousAt.continuousWithinAt)
    (fun t ht => (hd t (Ico_subset_Icc_self ht)).hasDerivWithinAt) hb

/-- Explicit global nominal closed-loop speed, with arbitrary smooth reference. -/
def circulationNominalPath (r : ℝ → ℝ) (a e0 t : ℝ) : ℝ :=
  r t + e0 * exp (-a * t)

theorem circulation_nominal_path_hasDerivAt {r : ℝ → ℝ}
    {γ k e0 rdot t : ℝ} (hr : HasDerivAt r rdot t) :
    HasDerivAt (circulationNominalPath r (γ + k) e0)
      (circulationCommand γ k (r t) rdot
        (circulationNominalPath r (γ + k) e0 t) -
        γ * circulationNominalPath r (γ + k) e0 t) t := by
  have hd := hr.add ((((hasDerivAt_id t).const_mul (-(γ + k))).exp).const_mul e0)
  convert! hd using 1
  simp only [circulationNominalPath, circulationCommand, id_eq]
  ring

/-- Constructive global nominal existence for every differentiable reference.
This conclusion is not conditional on a previously supplied speed trajectory. -/
theorem circulation_nominal_global_exists {r rdot : ℝ → ℝ} {γ k c0 : ℝ}
    (hr : ∀ t ∈ Ici 0, HasDerivAt r (rdot t) t) :
    ∃ c : ℝ → ℝ, c 0 = c0 ∧ ∀ t ∈ Ici 0,
      HasDerivAt c (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t) t := by
  refine ⟨circulationNominalPath r (γ + k) (c0 - r 0), ?_, ?_⟩
  · simp [circulationNominalPath]
  · intro t ht
    exact circulation_nominal_path_hasDerivAt (hr t ht)

/-- Variation-of-constants solution for continuous distributed disturbances. -/
def circulationForcedError (d : ℝ → ℝ) (a e0 t : ℝ) : ℝ :=
  exp (-a * t) * (e0 + ∫ s in (0 : ℝ)..t, exp (a * s) * d s)

theorem circulation_forced_error_hasDerivAt {d : ℝ → ℝ} {a e0 t : ℝ}
    (hd : Continuous d) :
    HasDerivAt (circulationForcedError d a e0)
      (-a * circulationForcedError d a e0 t + d t) t := by
  have hf : Continuous (fun s => exp (a * s) * d s) :=
    (Real.continuous_exp.comp (continuous_const.mul continuous_id)).mul hd
  have hI := intervalIntegral.integral_hasDerivAt_right
    (hf.intervalIntegrable 0 t) hf.aestronglyMeasurable.stronglyMeasurableAtFilter
    hf.continuousAt
  have hE := (((hasDerivAt_id t).const_mul (-a)).exp).mul (hI.const_add e0)
  have hexp : exp (-a * t) * exp (a * t) = 1 := by
    rw [← exp_add]
    rw [show -a * t + a * t = 0 by ring, exp_zero]
  have hcancel := congrArg (fun x : ℝ => x * d t) hexp
  convert! hE using 1
  unfold circulationForcedError
  simp only [id_eq] at *
  nlinarith

/-- Constructive global existence under continuous disturbance; no trajectory
is assumed. For merely measurable forcing the classical conclusion here is
not asserted. -/
theorem circulation_forced_global_exists {r rdot d : ℝ → ℝ} {γ k c0 : ℝ}
    (hr : ∀ t ∈ Ici 0, HasDerivAt r (rdot t) t) (hd : Continuous d) :
    ∃ c : ℝ → ℝ, c 0 = c0 ∧ ∀ t ∈ Ici 0,
      HasDerivAt c
        (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) t := by
  let e := circulationForcedError d (γ + k) (c0 - r 0)
  refine ⟨fun t => r t + e t, ?_, ?_⟩
  · simp [e, circulationForcedError]
  · intro t ht
    have he := circulation_forced_error_hasDerivAt
      (a := γ + k) (e0 := c0 - r 0) (t := t) hd
    convert! (hr t ht).add he using 1
    simp only [e, circulationCommand]
    ring

/-- Uniqueness for the forced scalar equation, proved by exact decay of the
difference. Continuity of the forcing is not required once derivatives exist. -/
theorem circulation_scalar_unique {c1 c2 f : ℝ → ℝ} {a T : ℝ}
    (ha : 0 < a) (hinit : c1 0 = c2 0)
    (h1 : ∀ t ∈ Icc 0 T, HasDerivAt c1 (-a * c1 t + f t) t)
    (h2 : ∀ t ∈ Icc 0 T, HasDerivAt c2 (-a * c2 t + f t) t) :
    ∀ t ∈ Icc 0 T, c1 t = c2 t := by
  have hd : ∀ t ∈ Icc 0 T,
      HasDerivAt (fun s => c1 s - c2 s) (-a * (c1 t - c2 t)) t := by
    intro t ht
    convert! (h1 t ht).sub (h2 t ht) using 1
    ring
  have hb := circulation_nominal_solution ha
    (fun t ht => (hd t ht).continuousAt.continuousWithinAt)
    (fun t ht => (hd t (Ico_subset_Icc_self ht)).hasDerivWithinAt)
  intro t ht
  have he := hb t ht
  try dsimp only [Pi.neg_apply, Pi.sub_apply, Pi.add_apply, Pi.mul_apply, Pi.pow_apply] at he
  rw [hinit, sub_self, mul_zero] at he
  exact sub_eq_zero.mp he

/-- A two-sided reference bound and the tracking error bound control tension. -/
theorem circulation_tension_upper {lam c r rmax ρ : ℝ}
    (hlam : 0 ≤ lam) (hc : 0 ≤ c) (hr : r ≤ rmax)
    (he : |c - r| ≤ ρ) :
    lam * c^2 ≤ lam * (rmax + ρ)^2 := by
  have hb : c ≤ rmax + ρ := by linarith [(abs_le.mp he).2]
  have hs : c^2 ≤ (rmax + ρ)^2 := by
    nlinarith [mul_nonneg (sub_nonneg.mpr hb) (show 0 ≤ rmax + ρ + c by linarith)]
  exact mul_le_mul_of_nonneg_left hs hlam

/-- A sufficient command magnitude bound for an unsaturated actuator. -/
theorem circulation_command_bound {γ k r rdot c A rmax ρ : ℝ}
    (hγ : 0 ≤ γ) (hk : 0 ≤ k) (hr0 : 0 ≤ r) (hr : r ≤ rmax)
    (hrdot : |rdot| ≤ A) (he : |c - r| ≤ ρ) :
    |circulationCommand γ k r rdot c| ≤ A + γ * rmax + k * ρ := by
  have htri := (abs_sub (rdot + γ * r) (k * (c - r))).trans
    (add_le_add (abs_add_le rdot (γ * r)) (le_refl _))
  have hdrag := mul_le_mul_of_nonneg_left hr hγ
  have hfeedback := mul_le_mul_of_nonneg_left he hk
  rw [abs_of_nonneg (mul_nonneg hγ hr0), abs_mul, abs_of_nonneg hk] at htri
  unfold circulationCommand
  linarith

/-! ## Reconstruction of the moving closed string

The following chain rules are valid in any real normed vector space. A periodic
unit-speed curve gives a closed inextensible chain. The balance is exact for
uniform tension lam c² and distributed tangential acceleration u−γc+d. The
result does not assert stability to perturbations outside this ansatz.
-/

section StringReconstruction
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- Material velocity of the traveling-shape ansatz. -/
theorem loop_position_hasDerivAt {R : ℝ → E} {θ : ℝ → ℝ}
    {R1 : E} {c a t : ℝ}
    (hR : HasDerivAt R R1 (a + θ t)) (hθ : HasDerivAt θ c t) :
    HasDerivAt (fun s => R (a + θ s)) (c • R1) t := by
  simpa only [Function.comp_def] using! hR.scomp t (hθ.const_add a)

/-- Material acceleration: curvature acceleration plus tangential acceleration. -/
theorem loop_velocity_hasDerivAt {R1 : ℝ → E} {θ c : ℝ → ℝ}
    {R2 : E} {cdot a t : ℝ}
    (hR1 : HasDerivAt R1 R2 (a + θ t))
    (hθ : HasDerivAt θ (c t) t) (hc : HasDerivAt c cdot t) :
    HasDerivAt (fun s => c s • R1 (a + θ s))
      ((c t)^2 • R2 + cdot • R1 (a + θ t)) t := by
  have h := hc.smul (hR1.scomp t (hθ.const_add a))
  simpa only [Function.comp_def, Pi.smul_apply, smul_smul, pow_two] using! h

/-- Spatial derivative of a uniform tension field times the tangent. -/
theorem loop_stress_hasDerivAt {R1 : ℝ → E} {θ c : ℝ → ℝ}
    {R2 : E} {lam a t : ℝ}
    (hR1 : HasDerivAt R1 R2 (a + θ t)) :
    HasDerivAt (fun b => (lam * (c t)^2) • R1 (b + θ t))
      ((lam * (c t)^2) • R2) a := by
  have h := (hR1.scomp a ((hasDerivAt_id a).add_const (θ t))).const_smul
    (lam * (c t)^2)
  simpa only [Function.comp_def, id_eq, Pi.smul_apply, one_smul] using! h

/-- Exact continuum momentum balance, using actual second time derivatives
and actual spatial derivatives. Uniform tension is lam*c². -/
theorem loop_continuum_balance {R R1 : ℝ → E} {θ c : ℝ → ℝ}
    {R2 : E} {lam γ u d a t : ℝ} (hlam : lam ≠ 0)
    (hR : ∀ x, HasDerivAt R (R1 x) x)
    (hR1 : HasDerivAt R1 R2 (a + θ t))
    (hθ : ∀ s, HasDerivAt θ (c s) s)
    (hc : HasDerivAt c (u - γ * c t + d) t) :
    deriv (fun τ => deriv (fun s => R (a + θ s)) τ) t =
      (1 / lam) • deriv
        (fun b => (lam * (c t)^2) • deriv (fun z => R (z + θ t)) b) a +
      (u - γ * c t + d) • deriv (fun z => R (z + θ t)) a := by
  have htime : (fun τ => deriv (fun s => R (a + θ s)) τ) =
      (fun τ => c τ • R1 (a + θ τ)) := by
    funext τ
    exact (loop_position_hasDerivAt (hR _) (hθ τ)).deriv
  have hspace : deriv (fun z => R (z + θ t)) =
      (fun b => R1 (b + θ t)) := by
    funext b
    have h := (hR (b + θ t)).scomp b ((hasDerivAt_id b).add_const (θ t))
    simpa only [Function.comp_def, id_eq, one_smul] using! h.deriv
  rw [htime, hspace,
    (loop_velocity_hasDerivAt hR1 (hθ t) hc).deriv,
    (loop_stress_hasDerivAt (lam := lam) hR1).deriv]
  have hscalar : 1 / lam * (lam * (c t)^2) = (c t)^2 := by field_simp
  rw [smul_smul, hscalar]

/-- Unit-speed shape parameterization implies material inextensibility. -/
theorem loop_inextensible {R R1 : ℝ → E} {θ : ℝ → ℝ} {a t : ℝ}
    (hR : HasDerivAt R (R1 (a + θ t)) (a + θ t))
    (hunit : ‖R1 (a + θ t)‖ = 1) :
    ‖deriv (fun z => R (z + θ t)) a‖ = 1 := by
  have h := hR.scomp a ((hasDerivAt_id a).add_const (θ t))
  have hd : deriv (fun z => R (z + θ t)) a = R1 (a + θ t) := by
    simpa only [Function.comp_def, id_eq, one_smul] using! h.deriv
  rw [hd, hunit]

omit [NormedAddCommGroup E] [NormedSpace ℝ E] in
/-- A periodic shape remains closed under every phase shift. -/
theorem loop_periodic {R : ℝ → E} {θ : ℝ → ℝ} {L t : ℝ}
    (hR : Function.Periodic R L) :
    Function.Periodic (fun a => R (a + θ t)) L := by
  intro a
  change R (a + L + θ t) = R (a + θ t)
  rw [show a + L + θ t = (a + θ t) + L by ring]
  exact hR (a + θ t)

/-- Positive density and positive circulation produce positive tension. -/
theorem loop_tension_positive {lam c : ℝ} (hlam : 0 < lam) (hc : 0 < c) :
    0 < lam * c^2 := by positivity

end StringReconstruction

end
end ChainFountain.ZeroGravity
