import ChainFountain.IntegralUniqueness
import ChainFountain.AbsoluteContinuity

namespace ChainFountain
noncomputable section
open Set Filter MeasureTheory
open scoped NNReal Topology

/-- A forward locally absolutely continuous a.e. mechanical solution satisfies
the integral equation on every finite horizon, with integrability derived. -/
theorem forward_ac_integral {F : ℝ → MechanicalState → MechanicalState}
    {x : ℝ → MechanicalState} {x₀ : MechanicalState} (hx₀ : x 0=x₀)
    (hx : ∀ T≥0, AbsolutelyContinuousOnInterval x 0 T)
    (hd : ∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (F t (x t)) t) :
    ∀ t≥0, IntervalIntegrable (fun s => F s (x s)) volume 0 t ∧
      x t=x₀+∫ s in (0:ℝ)..t, F s (x s) := by
  intro t ht
  have hd' : ∀ᵐ s ∂volume, s∈uIcc 0 t → HasDerivAt x (F s (x s)) s := by
    filter_upwards [hd] with s hs hmem
    rw [uIcc_of_le ht] at hmem
    exact hs hmem.1
  obtain ⟨hi,he⟩ := ac_state_integral_eq_sub (hx t ht) hd'
  refine ⟨hi,?_⟩
  rw [he,hx₀]
  abel

/-- Global physical existence and unrestricted forward Caratheodory uniqueness
for every bounded measurable disturbance. Competing curves need only be locally
absolutely continuous for nonnegative times; no safe-box, Lipschitz, positive
height, or pre-given trajectory hypothesis is imposed on them. -/
theorem GlobalTrackingData.exists_unique_global_caratheodory (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : Measurable d) (hdb : ∀ t, |d t|≤ c.dbar) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ T≥0, AbsolutelyContinuousOnInterval x 0 T) ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      (∀ t≥0, x t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (x s)) ∧
      (∀ t≥0, c.stateEnergy t (x t)≤ c.cap ∧
        c.stateEnergy t (x t)≤ Real.exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-Real.exp (-2*c.κ*t))) ∧
      ∀ y : ℝ → MechanicalState, y 0=c.x₀ →
        (∀ T≥0, AbsolutelyContinuousOnInterval y 0 T) →
        (∀ᵐ t ∂volume, 0≤ t → HasDerivAt y (c.measurableField d t (y t)) t) →
        ∀ t≥0, y t=x t := by
  obtain ⟨u,Ku,huL,hu₀,huB,huI,huUnique⟩ := c.exists_unique_global_integral hκd hdm hdb
  obtain ⟨x,K,hxL,hx₀,hxD,hxB,hxE⟩ := c.exists_global_measurable_tracking hκd hdm hdb
  have hxAC : ∀ T≥0, AbsolutelyContinuousOnInterval x 0 T :=
    fun _ _ => hxL.lipschitzOnWith.absolutelyContinuousOnInterval
  have hxI := forward_ac_integral hx₀ hxAC hxD
  have hxu := huUnique x hxL.continuous (fun t ht => (hxI t ht).2)
  refine ⟨x,K,hxL,hx₀,hxAC,hxD,hxB,fun t ht => (hxI t ht).2,hxE,?_⟩
  intro y hy₀ hyAC hyD
  have hyI := forward_ac_integral hy₀ hyAC hyD
  let yext : ℝ → MechanicalState := fun t => y (max 0 t)
  have hyext : Continuous yext := locally_ac_forward_extension hyAC
  have hext (t : ℝ) (ht : 0≤ t) : yext t=y t := by simp [yext,max_eq_right ht]
  have hyextI (t : ℝ) (ht : 0≤ t) :
      yext t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (yext s) := by
    rw [hext t ht,(hyI t ht).2]
    congr 1
    apply intervalIntegral.integral_congr
    intro s hs
    rw [uIcc_of_le ht] at hs
    dsimp only
    rw [hext s hs.1]
  have hyu := huUnique yext hyext hyextI
  intro t ht
  rw [←hext t ht,hyu t ht,hxu t ht]

/-- The same unrestricted Caratheodory uniqueness for Lebesgue-a.e. measurable
inputs, retaining their original values in the a.e. ODE. -/
theorem GlobalTrackingData.exists_unique_global_aemeasurable_caratheodory (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : AEMeasurable d volume) (hdb : ∀ t, |d t|≤ c.dbar) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ T≥0, AbsolutelyContinuousOnInterval x 0 T) ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      (∀ t≥0, x t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (x s)) ∧
      (∀ t≥0, c.stateEnergy t (x t)≤ c.cap ∧
        c.stateEnergy t (x t)≤ Real.exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-Real.exp (-2*c.κ*t))) ∧
      ∀ y : ℝ → MechanicalState, y 0=c.x₀ →
        (∀ T≥0, AbsolutelyContinuousOnInterval y 0 T) →
        (∀ᵐ t ∂volume, 0≤ t → HasDerivAt y (c.measurableField d t (y t)) t) →
        ∀ t≥0, y t=x t := by
  have hb0 : 0≤ c.dbar := (abs_nonneg (d 0)).trans (hdb 0)
  have horder : -c.dbar≤ c.dbar := by linarith
  let b : ℝ → ℝ := fun t => max (-c.dbar) (min c.dbar (hdm.mk d t))
  have hbm : Measurable b := measurable_const.max (measurable_const.min hdm.measurable_mk)
  have hbb (t : ℝ) : |b t|≤ c.dbar := by
    apply abs_le.mpr
    exact ⟨le_max_left _ _,max_le horder (min_le_left _ _)⟩
  have heq : d =ᵐ[volume] b := by
    filter_upwards [hdm.ae_eq_mk] with t ht
    have hb := abs_le.mp (hdb t)
    simp only [b,← ht,min_eq_right hb.2,max_eq_right hb.1]
  obtain ⟨x,K,hxL,hx₀,hxAC,hxD,hxB,hxI,hxE,hunique⟩ :=
    c.exists_unique_global_caratheodory hκd hbm hbb
  have hxD' : ∀ᵐ t ∂volume, 0≤t → HasDerivAt x (c.measurableField d t (x t)) t := by
    filter_upwards [hxD,heq] with t ht he ht0
    simpa only [measurableField,measurableParameters,←he] using! ht ht0
  have hxI' := forward_ac_integral hx₀ hxAC hxD'
  refine ⟨x,K,hxL,hx₀,hxAC,hxD',hxB,fun t ht => (hxI' t ht).2,hxE,?_⟩
  intro y hy₀ hyAC hyD
  apply hunique y hy₀ hyAC
  filter_upwards [hyD,heq] with t ht he ht0
  simpa only [measurableField,measurableParameters,he] using! ht ht0

end
end ChainFountain
