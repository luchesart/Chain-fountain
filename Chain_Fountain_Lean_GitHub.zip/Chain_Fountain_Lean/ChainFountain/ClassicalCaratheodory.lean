import ChainFountain.PrefixUniqueness
import ChainFountain.CaratheodoryCompletion

namespace ChainFountain
noncomputable section
open Set Filter MeasureTheory
open scoped Topology NNReal

/-- Classical solutions from certified data are locally absolutely continuous.
The bound on the original vector field and first-exit safety supply regularity. -/
theorem GlobalTrackingData.classical_forward_ac (c : GlobalTrackingData)
    {x : ℝ → MechanicalState} (hx : x 0 = c.x₀)
    (hd : ∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) :
    ∀ T ≥ 0, AbsolutelyContinuousOnInterval x 0 T := by
  obtain ⟨L,C,hL,hcont,hC⟩ := c.field_bounds
  intro T hT
  have hb := c.classical_safe_on_Icc hT hx (fun t ht => hd t ht.1)
  have hl : LipschitzOnWith ⟨max C 0,le_max_right _ _⟩ x (Icc 0 T) := by
    apply (convex_Icc (0:ℝ) T).lipschitzOnWith_of_nnnorm_hasDerivWithin_le
      (fun t ht => (hd t ht.1).hasDerivWithinAt)
    intro t ht
    exact_mod_cast (hC t (x t) (interior_subset (c.safeBox_interior (hb t ht)))).trans
      (le_max_left C 0)
  rw [← uIcc_of_le hT] at hl
  exact hl.absolutelyContinuousOnInterval

/-- Unrestricted uniqueness of the continuous-data integral equation. The
nominal gain may vanish; the proof uses a safe reference solution, not robust
division by kappa_d and not safety assumed of the competitor. -/
theorem GlobalTrackingData.classical_integral_unique (c : GlobalTrackingData)
    {x y : ℝ → MechanicalState} (hx : Continuous x) (hy : Continuous y)
    (hxb : ∀ t ≥ 0, x t ∈ c.safeBox)
    (hxi : ∀ t ≥ 0, x t = c.x₀ + ∫ s in (0:ℝ)..t, c.field s (x s))
    (hyi : ∀ t ≥ 0, y t = c.x₀ + ∫ s in (0:ℝ)..t, c.field s (y s)) :
    ∀ t ≥ 0, y t = x t := by
  let d : ℝ → ℝ := fun t => c.d (max 0 t)
  have hdm : Measurable d := c.parameters_continuous.snd.snd.snd.measurable
  have hdb : ∀ t, |d t| ≤ c.dbar := fun t => c.disturbance_bound _ (le_max_left _ _)
  have hfield (t : ℝ) (z : MechanicalState) : c.measurableField d t z = c.field t z := rfl
  have hprefix (T : ℝ) (hT : 0 ≤ T) (hyB : ∀ t ∈ Icc 0 T, y t ∈ c.outerBox) :
      ∀ t ∈ Icc 0 T, y t = x t := by
    obtain ⟨v,hmin,hmax,hzero,hinit,hv⟩ := c.measurable_picard_data hdm hdb hT
    have mk (z : ℝ → MechanicalState)
        (hi : ∀ t ≥ 0, z t = c.x₀ + ∫ s in (0:ℝ)..t, c.field s (z s))
        (hb : ∀ t ∈ Icc 0 T, z t ∈ c.outerBox) :
        ∀ t ∈ Icc v.tMin v.tMax, z t = v.x₀ + ∫ s in (v.t₀:ℝ)..t, v s (z s) := by
      intro t ht
      rw [hmin,hmax] at ht
      rw [hinit,hzero,hi t ht.1]
      congr 1
      apply intervalIntegral.integral_congr
      intro s hs
      rw [uIcc_of_le ht.1] at hs
      dsimp only
      rw [hv,c.project_eq (z s) (hb s ⟨hs.1,hs.2.trans ht.2⟩),hfield]
    have hh := v.continuous_integral_unique hy hx (mk y hyi hyB)
      (mk x hxi (fun t ht => interior_subset (c.safeBox_interior (hxb t ht.1))))
    simpa only [hmin,hmax] using hh
  have hy₀ : y 0 = c.x₀ := by simpa using hyi 0 le_rfl
  have hystay := no_exit_of_prefix_bound hy
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    (hy₀ ▸ c.safeBox_interior c.initial_mem) (by
      intro T hT hb
      rw [hprefix T hT hb T ⟨hT,le_rfl⟩]
      exact hxb T hT)
  intro t ht
  exact hprefix t ht (fun s hs => interior_subset (c.safeBox_interior (hystay s hs.1)))
    t ⟨ht,le_rfl⟩

/-- The continuous-data tracking theorem, including kappa_d = 0, is unique
among all forward locally absolutely continuous a.e. mechanical solutions.
No prior existence, competitor state bounds, or negative-time regularity. -/
theorem GlobalTrackingData.exists_unique_classical_caratheodory (c : GlobalTrackingData) :
    ∃ x : ℝ → MechanicalState, x 0 = c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      (∀ T ≥ 0, AbsolutelyContinuousOnInterval x 0 T) ∧
      (∀ t ≥ 0, x t ∈ c.safeBox) ∧
      (c.dbar = 0 → ∀ t ≥ 0,
        c.stateEnergy t (x t) ≤ Real.exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀) ∧
      (0 < c.κd → ∀ t ≥ 0,
        c.stateEnergy t (x t) ≤ Real.exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-Real.exp (-2*c.κ*t))) ∧
      ∀ y : ℝ → MechanicalState, y 0 = c.x₀ →
        (∀ T ≥ 0, AbsolutelyContinuousOnInterval y 0 T) →
        (∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt y (c.field t (y t)) t) →
        ∀ t ≥ 0, y t = x t := by
  obtain ⟨x,hx,hd,hb,hn,hr⟩ := c.exists_global_tracking
  have hac := c.classical_forward_ac hx hd
  have hxi := forward_ac_integral hx hac (Eventually.of_forall hd)
  refine ⟨x,hx,hd,hac,hb,hn,hr,?_⟩
  intro y hy hyAC hyD
  have hyi := forward_ac_integral hy hyAC hyD
  have ext (z : ℝ → MechanicalState)
      (hi : ∀ t ≥ 0, z t = c.x₀ + ∫ s in (0:ℝ)..t, c.field s (z s)) :
      ∀ t ≥ 0, z (max 0 t) = c.x₀ + ∫ s in (0:ℝ)..t, c.field s (z (max 0 s)) := by
    intro t ht
    rw [max_eq_right ht,hi t ht]
    congr 1
    apply intervalIntegral.integral_congr
    intro s hs
    rw [uIcc_of_le ht] at hs
    simp only [max_eq_right hs.1]
  have heq := c.classical_integral_unique
    (locally_ac_forward_extension hac) (locally_ac_forward_extension hyAC)
    (fun t ht => by simpa [max_eq_right ht] using hb t ht)
    (ext x (fun t ht => (hxi t ht).2)) (ext y (fun t ht => (hyi t ht).2))
  intro t ht
  simpa only [max_eq_right ht] using heq t ht

end
end ChainFountain
