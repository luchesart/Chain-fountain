import ChainFountain.LipschitzFTC
import ChainFountain.GlobalODE
import ChainFountain.Comparison

namespace ChainFountain
noncomputable section
open Set Metric Real Filter MeasureTheory
open scoped Topology NNReal

/-- A smooth function of a Lipschitz curve is Lipschitz on a compact interval.
The bound is obtained on a compact convex ball containing the curve. -/
theorem smooth_comp_lipschitzOn
    {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [ProperSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    {f : E → F} {x : ℝ → E} {K : ℝ≥0} {a b : ℝ}
    (hf : ContDiff ℝ 1 f) (hx : LipschitzOnWith K x (Icc a b)) :
    ∃ L : ℝ≥0, LipschitzOnWith L (fun t => f (x t)) (Icc a b) := by
  obtain ⟨N,hN⟩ := isCompact_Icc.exists_bound_of_continuousOn hx.continuousOn
  obtain ⟨L,C,hL,_⟩ := smooth_compact_convex_bounds isOpen_univ hf.contDiffOn
    (isCompact_closedBall (0:E) (max N 0)) (convex_closedBall (0:E) (max N 0)) (subset_univ _)
  refine ⟨L*K,hL.comp hx (fun t ht => ?_)⟩
  simpa only [mem_closedBall,dist_zero_right] using! (hN t ht).trans (le_max_left N 0)

/-- Scalar Gronwall comparison for Lipschitz curves whose differential inequality
holds only almost everywhere. The integrating-factor monotonicity is derived
from the proved Lipschitz FTC. -/
theorem scalar_comparison_ae {V V' : ℝ → ℝ} {T κ C : ℝ} {L : ℝ≥0}
    (hκ : 0<κ) (hV : LipschitzOnWith L V (Icc 0 T))
    (hd : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt V (V' t) t)
    (hb : ∀ᵐ t ∂volume, t∈Ioo 0 T → V' t≤ -2*κ*V t+C) :
    ∀ t∈Icc 0 T, V t≤ envelope (V 0) κ C t := by
  let W (t : ℝ) := (V t-C/(2*κ))*exp (2*κ*t)
  let W' (t : ℝ) := (V' t+2*κ*(V t-C/(2*κ)))*exp (2*κ*t)
  have hsm : ContDiff ℝ 1 (fun p : ℝ×ℝ => (p.2-C/(2*κ))*exp (2*κ*p.1)) := by fun_prop
  obtain ⟨LW,hLW⟩ := smooth_comp_lipschitzOn hsm (LipschitzWith.id.lipschitzOnWith.prodMk hV)
  have hWd : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt W (W' t) t := by
    filter_upwards [hd] with t ht hmem
    convert! ((ht hmem).sub_const (C/(2*κ))).mul
      (((hasDerivAt_id t).const_mul (2*κ)).exp) using 1 <;> dsimp [W,W'] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hWn : ∀ᵐ t ∂volume, t∈Ioo 0 T → W' t≤0 := by
    filter_upwards [hb] with t ht hmem
    have heq : 2*κ*(C/(2*κ))=C := by field_simp
    dsimp [W']
    apply mul_nonpos_of_nonpos_of_nonneg _ (exp_pos _).le
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [ht hmem]
  intro t ht
  have hsub : Icc (0:ℝ) t ⊆ Icc 0 T := Icc_subset_Icc le_rfl ht.2
  have hw := lipschitzOn_nonincreasing_of_ae_derivative ht.1 (hLW.mono hsub)
    (hWd.mono (fun s hs hmem => hs ⟨hmem.1,hmem.2.trans_le ht.2⟩))
    (hWn.mono (fun s hs hmem => hs ⟨hmem.1,hmem.2.trans_le ht.2⟩))
  change W t≤ W 0 at hw
  dsimp [W] at hw
  simp only [mul_zero,exp_zero,mul_one] at hw
  have hdiv : V t-C/(2*κ) ≤ (V 0-C/(2*κ))/exp (2*κ*t) :=
    (le_div_iff₀ (exp_pos _)).mpr hw
  have heq : envelope (V 0) κ C t = C/(2*κ)+(V 0-C/(2*κ))/exp (2*κ*t) := by
    unfold envelope
    rw [show -2*κ*t=-(2*κ*t) by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring,exp_neg]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [heq]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

/-- The robust energy envelope for genuinely a.e. error equations. -/
theorem robust_error_estimate_ae {e z G d : ℝ → ℝ} {T k₀ k₁ k₂ κ κd dbar : ℝ}
    {Le Lz : ℝ≥0} (hk₀ : 0≤ k₀) (hκ : 0<κ) (hk₁ : κ≤ k₁) (hk₂ : κ≤ k₂) (hκd : 0<κd)
    (hel : LipschitzOnWith Le e (Icc 0 T)) (hzl : LipschitzOnWith Lz z (Icc 0 T))
    (he : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt e (errorRate k₁ (e t) (z t)) t)
    (hz : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt z (zRate k₀ k₂ κd (G t) (d t) (e t) (z t)) t)
    (hb : ∀ᵐ t ∂volume, t∈Ioo 0 T → |d t|≤ dbar) :
    ∀ t∈Icc 0 T, errorEnergy k₀ (e t) (z t)≤
      exp (-2*κ*t)*errorEnergy k₀ (e 0) (z 0)+dbar^2/(16*κ*κd)*(1-exp (-2*κ*t)) := by
  have hsm : ContDiff ℝ 1 (fun p : ℝ×ℝ => errorEnergy k₀ p.1 p.2) := by
    unfold errorEnergy
    fun_prop (disch := norm_num)
  obtain ⟨L,hL⟩ := smooth_comp_lipschitzOn hsm (hel.prodMk hzl)
  have hd : ∀ᵐ t ∂volume, t∈Ioo 0 T →
      HasDerivAt (fun s => errorEnergy k₀ (e s) (z s))
        (-k₀*k₁*(e t)^2-k₂*(z t)^2/4-κd*(G t)^2*(z t)^2/4+G t*z t*d t/4) t := by
    filter_upwards [he,hz] with t het hzt hmem
    exact energy_hasDerivAt_errors (het hmem) (hzt hmem)
  have hi := scalar_comparison_ae hκ hL hd (by
    filter_upwards [hb] with t ht hmem
    exact robust_decay_uniform hk₀ hk₁ hk₂ hκd (ht hmem))
  intro t ht
  convert! hi t ht using 1
  unfold envelope
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

end
end ChainFountain
