import Chain_Fountain_Live
import Lean

/-! Read-only environment export. The graph is extracted from elaborated types
and proof terms. This tool is not part of the mathematical theory or axiom audit. -/
open Lean Elab Command

run_cmd liftTermElabM do
  let env ← getEnv
  let mut rows : Array Json := #[]
  for (name,ci) in env.constants.toList do
    if name.toString.startsWith "ChainFountainStochastic." || name.toString.startsWith "ChainFountain." then
      let kind := match ci with
        | .thmInfo _ => "theorem"
        | .defnInfo _ => "definition"
        | .axiomInfo _ => "axiom"
        | .opaqueInfo _ => "opaque"
        | .inductInfo _ => "inductive"
        | .ctorInfo _ => "constructor"
        | .recInfo _ => "recursor"
        | .quotInfo _ => "quotient"
      let typ ← Meta.ppExpr ci.type
      let typeRefs := ci.type.getUsedConstants.map (fun n => toJson n.toString)
      let valueRefs := (ci.value? true).map (fun e => e.getUsedConstants) |>.getD #[]
      let doc := (← findDocString? env name).getD ""
      rows := rows.push (Json.mkObj [
        ("name",toJson name.toString), ("kind",toJson kind),
        ("type",toJson typ.pretty), ("doc",toJson doc),
        ("type_refs",Json.arr typeRefs),
        ("value_refs",toJson (valueRefs.map Name.toString))])
  liftM <| IO.FS.writeFile "verification/environment.json" (Json.arr rows).pretty
