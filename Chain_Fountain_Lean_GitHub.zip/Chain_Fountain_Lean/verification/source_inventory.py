"""Named source declarations, respecting nested Lean namespaces and sections.
Only declarations present in the exported kernel environment are accepted by
build_map.py; check.py audits precisely the theorem inventory from this parser.
"""
import re

def mask_comments(source):
    out=list(source); i=0; depth=0; quoted=False
    while i<len(source):
        if depth:
            if source.startswith('/-',i): out[i:i+2]='  ';depth+=1;i+=2
            elif source.startswith('-/',i):out[i:i+2]='  ';depth-=1;i+=2
            else:
                if source[i]!='\n':out[i]=' '
                i+=1
        elif quoted:
            if source[i]=='\\':i+=2
            elif source[i]=='"':quoted=False;i+=1
            else:i+=1
        elif source[i]=='"':quoted=True;i+=1
        elif source.startswith('/-',i):out[i:i+2]='  ';depth=1;i+=2
        elif source.startswith('--',i):
            while i<len(source) and source[i]!='\n':out[i]=' ';i+=1
        else:i+=1
    if depth:raise ValueError('Unclosed Lean comment')
    return ''.join(out)

def declarations(source):
    plain=mask_comments(source); stack=[]; rows=[]
    pattern=r'^(?:@\[[^\]\n]*\]\s+)*(?:(?:noncomputable|private|protected|nonrec)\s+)*(namespace|section|end|theorem|lemma|def|abbrev|structure)\b([^\n]*)'
    for m in re.finditer(pattern,plain,re.M):
        kind=m[1];tail=m[2].strip();raw=tail.split()[0] if tail else ''
        if kind=='lemma':kind='theorem'
        if kind in ('namespace','section'):stack.append((kind,raw));continue
        if kind=='end':
            if not stack:raise ValueError('Unmatched end')
            old=stack.pop()
            if raw and old[1]!=raw:raise ValueError(f'Mismatched end {raw}: {old}')
            continue
        prefix='.'.join(n for k,n in stack if k=='namespace')
        name=raw.removeprefix('_root_.') if raw.startswith('_root_.') else '.'.join(filter(None,[prefix,raw]))
        rows.append(dict(name=name,kind=kind,start=m.start(),line=source[:m.start()].count('\n')+1))
    if stack:raise ValueError(f'Unclosed scopes: {stack}')
    for i,row in enumerate(rows):row['end']=rows[i+1]['start'] if i+1<len(rows) else len(source)
    return rows
