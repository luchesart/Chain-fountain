import ChainFountainZeroGravity
import Lean

/-! Read-only export of the actual elaborated environment and transitive axioms.
Module ownership includes generated declarations; authored theorem counts are
reported separately by the verification script. This is verification plumbing,
not part of the mathematical development. -/
open Lean Elab Command

run_cmd liftTermElabM do
  let env ← getEnv
  let targetModules := #["ChainFountain.ZeroGravityOpen", "ChainFountain.ZeroGravityCirculation",
    "ChainFountain.ZeroGravityAC", "ChainFountain.ZeroGravityACBounds",
    "ChainFountain.ZeroGravityAEReconstruction"]
  let mut rows : Array Json := #[]
  for (name, ci) in env.constants.toList do
    let moduleName := match env.getModuleIdxFor? name with
      | some idx => env.header.moduleNames[idx.toNat]!.toString
      | none => env.mainModule.toString
    if targetModules.contains moduleName then
      let kind := match ci with
        | .thmInfo _ => "theorem"
        | .defnInfo _ => "definition"
        | .axiomInfo _ => "axiom"
        | .opaqueInfo _ => "opaque"
        | .inductInfo _ => "inductive"
        | .ctorInfo _ => "constructor"
        | .recInfo _ => "recursor"
        | .quotInfo _ => "quotient"
      let typ ← Meta.ppExpr ci.type
      let typeRefs := ci.type.getUsedConstants.map (fun n => toJson n.toString)
      let valueRefs := (ci.value? true).map (fun e => e.getUsedConstants) |>.getD #[]
      let axioms ← collectAxioms name
      let doc := (← findDocString? env name).getD ""
      let range := match ← findDeclarationRanges? name with
        | some r => Json.mkObj [("start_line", toJson r.range.pos.line),
            ("start_column", toJson r.range.pos.column),
            ("end_line", toJson r.range.endPos.line),
            ("end_column", toJson r.range.endPos.column)]
        | none => Json.null
      rows := rows.push (Json.mkObj [
        ("name",toJson name.toString), ("module", toJson moduleName),
        ("kind",toJson kind), ("type",toJson typ.pretty), ("doc",toJson doc),
        ("source_range",range), ("type_refs",Json.arr typeRefs),
        ("value_refs",toJson (valueRefs.map Name.toString)),
        ("transitive_axioms",toJson (axioms.map Name.toString))])
  liftM <| IO.FS.writeFile "verification/zero-gravity/environment.json" (Json.arr rows).pretty
