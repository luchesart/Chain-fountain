/-
Copyright (c) 2026 Raphael Coelho. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Adapted for ChainFountain: retain the true martingale property and expose
modification at every frozen time, both already established by the construction.
-/
import MathFin.Foundations.ItoIntegralProcessLocalMartingaleGeneral
import ChainFountainStochastic.ItoExponential

namespace ChainFountainStochastic.ItoContinuousMartingale
noncomputable section
open MeasureTheory ProbabilityTheory Filter Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM MathFin.ItoIntegralProcess
open MathFin.ItoIntegralProcessGeneral MathFin.ItoIntegralProcessContinuousModification
open MathFin.ItoLocalMartingale MathFin.ItoIntegralProcessLocalMartingaleGeneral
open scoped NNReal ENNReal
variable {Ω : Type*} {m0 : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ)
set_option maxHeartbeats 1000000
set_option backward.isDefEq.respectTransparency false

theorem exists_continuous_martingale_modification (T : ℝ≥0)
    (hBmeas : ∀ t, Measurable (B t)) (hBcont : ∀ ω, Continuous fun t : ℝ≥0 ↦ B t ω)
    (φ : Lp ℝ 2 (trimMeasure_T (μ := μ) T hBmeas)) :
    ∃ X : ℝ≥0 → Ω → ℝ,
      (∀ t, X t =ᵐ[μ] itoProcessCLM hB T (min t T) hBmeas φ) ∧
      (∀ ω, Continuous fun t ↦ X t ω) ∧
      Martingale X (augFiltration (μ := μ) hBmeas) μ ∧
      (∀ i, StronglyMeasurable[augFiltration (μ := μ) hBmeas i] (X i)) := by
  -- a co-null good set of the null σ-algebra: pointwise convergence and continuity on `[0, T]`
  obtain ⟨G, hGaug, hGnull, hGgood⟩ := exists_nullsAlg_of_ae (μ := μ)
    (p := fun ω ↦ (∀ t : ℝ≥0, t ≤ T → Tendsto
        (fun n ↦ itoSimpleProcess hBmeas ((approxSeq T hBmeas φ).choose n).val t ω) atTop
        (𝓝 (itoContinuousMod T hBmeas φ t ω)))
      ∧ ContinuousOn (fun t ↦ itoContinuousMod T hBmeas φ t ω) (Set.Icc 0 T)) <| by
    filter_upwards [itoContinuousMod_tendsto hB T hBmeas hBcont φ,
      itoContinuousMod_continuousOn hB T hBmeas hBcont φ] with ω h1 h2 using ⟨h1, h2⟩
  -- adaptedness to the augmented filtration: a pointwise limit of `G.indicator` of the simple
  -- integrals, each `natFiltration`-measurable
  have hadapt : ∀ i : ℝ≥0, StronglyMeasurable[natFiltration hBmeas i ⊔ nullsAlg m0 μ]
      (fun ω ↦ itoLocalMod G T i hBmeas φ ω) := by
    intro i
    refine stronglyMeasurable_of_tendsto atTop
      (f := fun n ↦ G.indicator
        (fun ω ↦ itoSimpleProcess hBmeas ((approxSeq T hBmeas φ).choose n).val (min i T) ω))
      (fun n ↦ ?_) ?_
    · exact (((itoSimpleProcess_isMartingale hB hBmeas
          ((approxSeq T hBmeas φ).choose n).val).1 (min i T)).mono
        (((natFiltration hBmeas).mono (min_le_left i T)).trans le_sup_left)).indicator
        ((le_sup_right : nullsAlg m0 μ ≤ natFiltration hBmeas i ⊔ nullsAlg m0 μ) _ hGaug)
    · refine tendsto_pi_nhds.mpr (fun ω ↦ ?_)
      by_cases hω : ω ∈ G
      · simp only [Set.indicator_of_mem hω, itoLocalMod]
        exact (hGgood ω hω).1 (min i T) (min_le_right i T)
      · simp only [Set.indicator_of_notMem hω, itoLocalMod]
        exact tendsto_const_nhds
  have hcont : ∀ ω, Continuous (fun t ↦ itoLocalMod G T t hBmeas φ ω) :=
    continuous_indicator_min fun ω hω ↦ (hGgood ω hω).2
  refine ⟨fun t ω ↦ itoLocalMod G T t hBmeas φ ω, fun t ↦ ?_, hcont, ?_, hadapt⟩
  · exact itoLocalMod_ae_eq hB T hBmeas hBcont hGnull φ t
  · exact ⟨hadapt, fun i j hij ↦
      condExp_itoLocalMod hB T hBmeas hBcont hGnull φ hij⟩

/-- A continuous true martingale representing the genuine bounded-coefficient
Ito integral, with its exponential moment estimate at every time. -/
theorem exists_integral_martingale (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
    {a : ℝ≥0 → Ω → ℝ}
    (ha : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hc : ∀ ω, Continuous (a · ω)) {C : ℝ} (hb : ∀ t ω, |a t ω| ≤ C) :
    ∃ X : ℝ≥0 → Ω → ℝ,
      (∀ t, X t =ᵐ[μ] itoIntCont hB hBm ha hc hb (min t T)) ∧
      (∀ ω, Continuous (X · ω)) ∧
      Martingale X (augFiltration (μ:=μ) hBm) μ ∧
      (∀ q t, Integrable (fun ω => Real.exp (q*X t ω)) μ ∧
        (∫ ω, Real.exp (q*X t ω) ∂μ) ≤ Real.exp (q^2*C^2*(t:ℝ)/2)) := by
  obtain ⟨X,hX,hcX,hmX,haX⟩ := exists_continuous_martingale_modification hB T hBm hBc
    (processToLp (μ:=μ) T hBm ha hc hb)
  have hv : ∀ t, X t =ᵐ[μ] itoIntCont hB hBm ha hc hb (min t T) := by
    intro t
    have h := hX t
    rw [itoProcessCLM_consist hB hBm le_rfl (min_le_right t T) ha hc hb,
      itoProcessCLM_terminal_eq] at h
    exact h
  refine ⟨X,hv,hcX,hmX,fun q t => ?_⟩
  have he : (fun ω => Real.exp (q * itoIntCont hB hBm ha hc hb (min t T) ω)) =ᵐ[μ]
      (fun ω => Real.exp (q * X t ω)) := by
    filter_upwards [hv t] with ω hω
    rw [hω]
  obtain ⟨hi,hb⟩ := ItoExponential.terminal_mgf hB hBm ha hc hb q (min t T)
  refine ⟨hi.congr he, ?_⟩
  rw [← integral_congr_ae he]
  apply hb.trans
  apply Real.exp_le_exp.mpr
  exact div_le_div_of_nonneg_right
    (mul_le_mul_of_nonneg_left (by exact_mod_cast min_le_left t T)
      (mul_nonneg (sq_nonneg q) (sq_nonneg C))) (by norm_num)

end
end ChainFountainStochastic.ItoContinuousMartingale
