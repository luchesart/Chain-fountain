/-
Copyright (c) 2026 Latchezar Tomov. All rights reserved.
Released under Apache 2.0 license as described in LICENSE.
-/
module
public import ChainFountainStochastic.QuadraticIto
public import ChainFountainStochastic.TimeIntegral
@[expose] public section
namespace ChainFountainStochastic
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory MathFin
open MathFin.ItoIntegralL2 MathFin.ItoFormulaAdapted
open MathFin.ItoIntegralProcessLocalMartingaleGeneral
open scoped NNReal Topology

def trackingEnergy (k₀ e z : ℝ) := k₀*e^2/2+z^2/8
def trackingGenerator (k₀ k₁ k₂ κd σ e z G : ℝ) :=
  -k₀*k₁*e^2-k₂*z^2/4-κd*G^2*z^2/4+σ^2*G^2/8

/-- From the Brownian-driven error SDE to the actual energy decomposition.
The SDE is stated as its stochastic integral equation; an energy Itô formula,
quadratic-variation limit, or martingale decomposition is not assumed. -/
theorem tracking_energy_ito
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {a b z G : ℝ≥0 → Ω → ℝ} {e : ℝ → Ω → ℝ} {k₀ k₁ k₂ κd σ z₀ : ℝ}
    (ham : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hac : ∀ ω, Continuous (fun t => a t ω))
    (hbm : ∀ t, StronglyMeasurable[natFiltration hBm t] (b t))
    (hbc : ∀ ω, Continuous (fun t => b t ω))
    (hzc : ∀ ω, Continuous (fun t => z t ω))
    (he : ∀ ω t, 0≤ t → HasDerivAt (fun s => e s ω)
      (-k₁*e t ω+z (Real.toNNReal t) ω/2) t)
    (hab : ∀ t∈Icc 0 T, ∀ ω,
      a t ω=σ*G t ω ∧ b t ω= -2*k₀*e t ω-k₂*z t ω-κd*(G t ω)^2*z t ω)
    (hSDE : ∀ᵐ ω ∂μ, ∀ t∈Icc 0 T,
      z t ω=localItoProcess (μ:=μ) T hBm ham hac z₀ b t ω) :
    ∃ M : ℝ≥0 → Ω → ℝ,
      (∀ᵐ ω ∂μ, ∀ t∈Icc 0 T,
        trackingEnergy k₀ (e t ω) (z t ω)=trackingEnergy k₀ (e 0 ω) z₀+
          (∫ s in Ioc 0 t, trackingGenerator k₀ k₁ k₂ κd σ (e s ω) (z s ω) (G s ω)
            ∂timeMeasure)+M t ω) ∧
      (∀ ω, Continuous (fun t => M t ω)) ∧
      IsLocalMartingale M (augFiltration (μ:=μ) hBm) μ := by
  obtain ⟨M,hM,hMc,hMl⟩ := quadratic_ito_localMartingale hB T hBm hBc ham hac hbm hbc z₀
  refine ⟨M,?_,hMc,hMl⟩
  filter_upwards [hM,hSDE] with ω hMω hZω t ht
  have hec : ContinuousOn (fun s : ℝ => e s ω) (Ici 0) :=
    fun s hs => (he ω s hs).continuousAt.continuousWithinAt
  have hecn : Continuous (fun s : ℝ≥0 => e s ω) :=
    hec.comp_continuous NNReal.continuous_coe (fun s => s.coe_nonneg)
  have he'c : ContinuousOn (fun s : ℝ => -k₁*e s ω+z (Real.toNNReal s) ω/2)
      (Icc 0 (t:ℝ)) := by
    exact (continuousOn_const.mul (hec.mono (fun _ hs => hs.1))).add
      (((hzc ω).comp continuous_real_toNNReal).continuousOn.div_const 2)
  have hE := finite_variation_energy (k:=k₀)
    (fun s hs => he ω s hs.1) he'c
  have hZ := hMω t ht
  rw [←hZω t ht] at hZ
  have hconv : (∫ s in Ioc 0 t,
      (localItoProcess (μ:=μ) T hBm ham hac z₀ b s ω)*b s ω/4+(a s ω)^2/8
        ∂timeMeasure)=∫ s in Ioc 0 t, z s ω*b s ω/4+(a s ω)^2/8 ∂timeMeasure := by
    apply setIntegral_congr_fun measurableSet_Ioc
    intro s hs
    dsimp only
    rw [←hZω s ⟨zero_le,hs.2.trans ht.2⟩]
  rw [hconv] at hZ
  simp only [Real.toNNReal_coe] at hE
  have hi₁ : IntegrableOn (fun s : ℝ≥0 => k₀*e s ω*(-k₁*e s ω+z s ω/2))
      (Ioc 0 t) timeMeasure := by
    exact ((continuous_const.mul hecn).mul
      ((continuous_const.mul hecn).add ((hzc ω).div_const 2))).continuousOn.integrableOn_compact
        isCompact_Icc |>.mono_set Ioc_subset_Icc_self
  have hi₂ : IntegrableOn (fun s : ℝ≥0 => z s ω*b s ω/4+(a s ω)^2/8)
      (Ioc 0 t) timeMeasure := by
    exact (((hzc ω).mul (hbc ω)).div_const 4 |>.add ((hac ω).pow 2 |>.div_const 8)).continuousOn.integrableOn_compact
      isCompact_Icc |>.mono_set Ioc_subset_Icc_self
  have hsum : (∫ s in Ioc 0 t, trackingGenerator k₀ k₁ k₂ κd σ (e s ω) (z s ω) (G s ω)
      ∂timeMeasure)=(∫ s in Ioc 0 t, k₀*e s ω*(-k₁*e s ω+z s ω/2) ∂timeMeasure)+
      ∫ s in Ioc 0 t, z s ω*b s ω/4+(a s ω)^2/8 ∂timeMeasure := by
    rw [←integral_add hi₁ hi₂]
    apply setIntegral_congr_fun measurableSet_Ioc
    intro s hs
    obtain ⟨ha,hb⟩ := hab s ⟨zero_le,hs.2.trans ht.2⟩ ω
    dsimp only
    rw [ha,hb]
    dsimp [trackingGenerator]
    ring
  rw [hsum]
  dsimp [trackingEnergy]
  linarith

end
end ChainFountainStochastic
