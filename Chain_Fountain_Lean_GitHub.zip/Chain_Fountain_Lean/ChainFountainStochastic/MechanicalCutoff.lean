import ChainFountainStochastic.VectorSDE
import ChainFountain.GlobalODE
import ChainFountain.Tracking
namespace ChainFountainStochastic.MechanicalCutoff
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology ChainFountain VectorSDE
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 700000

abbrev State := Fin 3 → ℝ

def boxClamp (lo hi x : State) : State := fun i => max (lo i) (min (hi i) (x i))

theorem boxClamp_lipschitz (lo hi : State) : LipschitzWith 1 (boxClamp lo hi) := by
  apply LipschitzWith.of_dist_le_mul
  intro x y
  rw [NNReal.coe_one,one_mul,dist_pi_le_iff dist_nonneg]
  intro i
  simpa only [boxClamp,Function.eval,NNReal.coe_one,one_mul] using
    (((LipschitzWith.eval i).const_min (hi i)).const_max (lo i)).dist_le_mul x y

theorem boxClamp_mem {lo hi : State} (h : lo ≤ hi) (x : State) :
    boxClamp lo hi x ∈ Icc lo hi :=
  ⟨fun i => le_max_left _ _,fun i => max_le (h i) (min_le_left _ _)⟩

theorem boxClamp_eq {lo hi x : State} (h : x ∈ Icc lo hi) : boxClamp lo hi x = x := by
  ext i
  simp only [boxClamp,min_eq_right (h.2 i),max_eq_right (h.1 i)]

/-- Smooth drift and diffusion on a compact parameter/state box have jointly
continuous globally Lipschitz cutoff extensions, with proved origin bounds. -/
theorem exists_cutoff_coefficients
    {b σ : State × State → State} {U : Set (State × State)}
    (hU : IsOpen U) (hb : ContDiffOn ℝ 1 b U) (hσ : ContDiffOn ℝ 1 σ U)
    (p : ℝ≥0 → State) (hp : Continuous p) (plo phi lo hi : State)
    (hlo : lo ≤ hi) (hpmem : ∀ t, p t ∈ Icc plo phi)
    (hsub : (Icc plo phi ×ˢ Icc lo hi) ⊆ U) :
    ∃ c : Coefficients (Fin 3),
      (∀ t x, c.drift t x = b (p t,boxClamp lo hi x)) ∧
      (∀ t x, c.diffusion t x = σ (p t,boxClamp lo hi x)) ∧
      (∀ t x, ‖c.drift t x‖ ≤ c.bound ∧ ‖c.diffusion t x‖ ≤ c.bound) := by
  obtain ⟨Lb,Cb,hbL,hbC⟩ := smooth_compact_convex_bounds hU hb
    (isCompact_Icc.prod isCompact_Icc) ((convex_Icc _ _).prod (convex_Icc _ _)) hsub
  obtain ⟨Lσ,Cσ,hσL,hσC⟩ := smooth_compact_convex_bounds hU hσ
    (isCompact_Icc.prod isCompact_Icc) ((convex_Icc _ _).prod (convex_Icc _ _)) hsub
  have hm (z : ℝ≥0 × State) : (p z.1,boxClamp lo hi z.2) ∈ Icc plo phi ×ˢ Icc lo hi :=
    ⟨hpmem z.1,boxClamp_mem hlo z.2⟩
  have hcont : Continuous (fun z : ℝ≥0 × State => (p z.1,boxClamp lo hi z.2)) :=
    (hp.comp continuous_fst).prodMk ((boxClamp_lipschitz lo hi).continuous.comp continuous_snd)
  have hemb (t : ℝ≥0) : LipschitzWith 1 (fun x : State => (p t,boxClamp lo hi x)) := by
    simpa only [mul_one,Function.comp_def] using (LipschitzWith.prodMk_left (p t)).comp (boxClamp_lipschitz lo hi)
  have hbLip (t : ℝ≥0) : LipschitzWith Lb (fun x => b (p t,boxClamp lo hi x)) := by
    simpa only [mul_one,Function.comp_def,lipschitzOnWith_univ] using
      hbL.comp ((hemb t).lipschitzOnWith (s:=univ)) (fun x _ => hm (t,x))
  have hσLip (t : ℝ≥0) : LipschitzWith Lσ (fun x => σ (p t,boxClamp lo hi x)) := by
    simpa only [mul_one,Function.comp_def,lipschitzOnWith_univ] using
      hσL.comp ((hemb t).lipschitzOnWith (s:=univ)) (fun x _ => hm (t,x))
  refine ⟨{
    drift := fun t x => b (p t,boxClamp lo hi x)
    diffusion := fun t x => σ (p t,boxClamp lo hi x)
    drift_continuous := hbL.continuousOn.comp_continuous hcont hm
    diffusion_continuous := hσL.continuousOn.comp_continuous hcont hm
    Lb := Lb
    Lσ := Lσ
    drift_lipschitz := hbLip
    diffusion_lipschitz := hσLip
    bound := max Cb Cσ
    drift_zero := fun t => (hbC _ (hm (t,0))).trans (le_max_left _ _)
    diffusion_zero := fun t => (hσC _ (hm (t,0))).trans (le_max_right _ _)
  },fun _ _ => rfl,fun _ _ => rfl,fun t x =>
    ⟨(hbC _ (hm (t,x))).trans (le_max_left _ _),
      (hσC _ (hm (t,x))).trans (le_max_right _ _)⟩⟩

structure Parameters where
  H : ℝ
  g : ℝ
  α : ℝ
  β : ℝ
  k₀ : ℝ
  k₁ : ℝ
  k₂ : ℝ
  κd : ℝ
  noise : ℝ
  H_pos : 0 < H

/-- Original feedback mechanical drift in coordinates (height, rise speed, fall speed).
The parameter vector contains reference position, velocity and acceleration. -/
def Parameters.drift (d : Parameters) (y : State × State) : State :=
  let p := y.1
  let x := y.2
  let u := robustInput d.H d.g d.α d.β (x 0) (x 1) (x 2)
    (acceleration d.k₀ d.k₁ d.k₂ (x 0-p 0) (heightRate (x 1) (x 2)) (p 1) (p 2))
    d.κd (x 1-x 2-2*p 1+2*d.k₁*(x 0-p 0))
  ![heightRate (x 1) (x 2),rise d.g d.α (x 0) (x 1) (x 2) u,
    fall d.H d.g d.β (x 0) (x 1) (x 2)]

/-- The single physical Brownian input acts on rise speed, with coefficient sigma v²/h. -/
def Parameters.diffusion (d : Parameters) (y : State × State) : State :=
  ![0,d.noise*(y.2 1)^2/(y.2 0),0]

theorem Parameters.drift_smooth (d : Parameters) :
    ContDiffOn ℝ 1 d.drift {y | 0 < y.2 0} := by
  intro y hy
  have hh : y.2 0 ≠ 0 := ne_of_gt hy
  have hH : d.H+y.2 0 ≠ 0 := ne_of_gt (add_pos d.H_pos hy)
  apply ContDiffAt.contDiffWithinAt
  apply contDiffAt_pi.2
  intro i
  fin_cases i <;>
    dsimp [Parameters.drift] <;>
    simp only [robustInput,nominalInput,acceleration,heightRate,rise,fall,crownSq] <;>
    fun_prop (disch := first | assumption | norm_num)

theorem Parameters.diffusion_smooth (d : Parameters) :
    ContDiffOn ℝ 1 d.diffusion {y | 0 < y.2 0} := by
  intro y hy
  have hh : y.2 0 ≠ 0 := ne_of_gt hy
  apply ContDiffAt.contDiffWithinAt
  apply contDiffAt_pi.2
  intro i
  fin_cases i <;>
    dsimp [Parameters.diffusion] <;>
    fun_prop (disch := assumption)

/-- The actual rational mechanical fields admit compatible cutoff extensions
on every finite state box separated from height zero. -/
theorem Parameters.exists_cutoff (d : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi lo hi : State) (hlo : lo ≤ hi) (hh : 0 < lo 0)
    (hpmem : ∀ t, p t ∈ Icc plo phi) :
    ∃ c : Coefficients (Fin 3),
      (∀ t x, c.drift t x = d.drift (p t,boxClamp lo hi x)) ∧
      (∀ t x, c.diffusion t x = d.diffusion (p t,boxClamp lo hi x)) ∧
      (∀ t x, x ∈ Icc lo hi → c.drift t x = d.drift (p t,x)) ∧
      (∀ t x, x ∈ Icc lo hi → c.diffusion t x = d.diffusion (p t,x)) ∧
      (∀ t x, ‖c.drift t x‖ ≤ c.bound ∧ ‖c.diffusion t x‖ ≤ c.bound) := by
  obtain ⟨c,hb,hσ,hbound⟩ := exists_cutoff_coefficients
    (isOpen_lt continuous_const ((continuous_apply 0).comp continuous_snd))
    d.drift_smooth d.diffusion_smooth p hp plo phi lo hi hlo hpmem
    (fun y hy => lt_of_lt_of_le hh (hy.2.1 0))
  exact ⟨c,hb,hσ,fun t x hx => by rw [hb,boxClamp_eq hx],
    (fun t x hx => by rw [hσ,boxClamp_eq hx]),hbound⟩

/-- A strong solution is constructed for the mechanical cutoff; no trajectory
or existence hypothesis is supplied. Coefficients agree with the original
mechanical SDE throughout the chosen positive-height box. -/
theorem exists_unique_mechanical_cutoff_solution
    {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω} [IsProbabilityMeasure μ]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (d : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi lo hi : State) (hlo : lo ≤ hi) (hh : 0 < lo 0)
    (hpmem : ∀ t, p t ∈ Icc plo phi) (x₀ : State) :
    ∃ c : Coefficients (Fin 3),
      (∀ t x, x ∈ Icc lo hi → c.drift t x = d.drift (p t,x)) ∧
      (∀ t x, x ∈ Icc lo hi → c.diffusion t x = d.diffusion (p t,x)) ∧
      (∀ t x, ‖c.drift t x‖ ≤ c.bound ∧ ‖c.diffusion t x‖ ≤ c.bound) ∧
      ∃ T : ℝ≥0, 0 < T ∧ ∃ Y, StrongSolution (μ:=μ) T hBm c x₀ Y ∧
        ∀ Z, StrongSolution (μ:=μ) T hBm c x₀ Z →
          ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = Z t ω := by
  obtain ⟨c,_,_,hb,hσ,hbound⟩ := d.exists_cutoff p hp plo phi lo hi hlo hh hpmem
  exact ⟨c,hb,hσ,hbound,exists_unique_local_strong_solution hB hBm hBc c x₀⟩

end
end ChainFountainStochastic.MechanicalCutoff
