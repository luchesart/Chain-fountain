import ChainFountainStochastic.TimeProjection

namespace ChainFountainStochastic.IntervalOperators
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM MathFin.SDEExistence
open MathFin.ItoIntegralProcessGeneral MathFin.ItoIntegralProcessContinuousModification
open TimeProjection SDEContinuous VectorSDE
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 900000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}

/-- The drift slice energy is controlled by the full input energy. -/
theorem drift_slice_energy_le (T : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (g : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) {t : ℝ≥0} (ht : t ≤ T) :
    (∫ ω, (driftContinuousMod T hBm g t ω)^2 ∂μ) ≤ (T:ℝ)*‖g‖^2 := by
  have hg := memLp_product T hBm g
  have hs : ∀ᵐ ω ∂μ, MemLp (fun u => g (u,ω)) 2 (timeMeasure_T T) := by
    filter_upwards [hg.1.prodMk_right,hg.integrable_sq.prod_left_ae] with ω h1 h2
    exact (memLp_two_iff_integrable_sq h1).mpr h2
  have hp : ∀ᵐ ω ∂μ, (driftContinuousMod T hBm g t ω)^2 ≤
      (T:ℝ)*(∫ u, (g (u,ω))^2 ∂timeMeasure_T T) := by
    filter_upwards [hs,driftContinuousMod_eq_setIntegral T hBm g ht] with ω hs he
    rw [he]
    haveI : IsFiniteMeasure (timeMeasure.restrict (Ioc (0:ℝ≥0) t)) :=
      ⟨by rw [Measure.restrict_apply_univ,timeMeasure_Ioc]; exact ENNReal.ofReal_lt_top⟩
    have hCS := sq_integral_le_measureReal_mul
      (ν:=timeMeasure.restrict (Ioc (0:ℝ≥0) t))
      (f:=fun u => g (u,ω))
      (hs.mono_measure (Measure.restrict_mono (Ioc_subset_Ioc_right ht) le_rfl))
    rw [Measure.restrict_apply_univ,timeMeasure_Ioc,NNReal.coe_zero,sub_zero,
      ENNReal.toReal_ofReal t.coe_nonneg] at hCS
    refine hCS.trans (mul_le_mul (show (t:ℝ) ≤ (T:ℝ) from ht) ?_
      (integral_nonneg fun _ => sq_nonneg _) T.coe_nonneg)
    exact setIntegral_mono_set hs.integrable_sq (ae_of_all _ fun _ => sq_nonneg _)
      (Ioc_subset_Ioc_right ht).eventuallyLE
  have htotal : (∫ u, ∫ ω, (g (u,ω))^2 ∂μ ∂timeMeasure_T T) = ‖g‖^2 := by
    simpa only [cut_full] using (cut_norm_sq_eq_integral T T hBm le_rfl g).symm
  calc
    _ ≤ ∫ ω, (T:ℝ)*(∫ u, (g (u,ω))^2 ∂timeMeasure_T T) ∂μ :=
      integral_mono_of_nonneg (ae_of_all _ fun _ => sq_nonneg _)
        (hg.integrable_sq.integral_prod_right.const_mul _) hp
    _ = _ := by rw [integral_const_mul,←integral_integral_swap hg.integrable_sq,htotal]

/-- A zero input prefix has a zero drift prefix, for every time a.e. -/
theorem drift_zero_prefix (T s : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (g : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) (hg : cut T s hBm g = 0)
    {t : ℝ≥0} (hts : t ≤ s) (htT : t ≤ T) :
    ∀ᵐ ω ∂μ, driftContinuousMod T hBm g t ω = 0 := by
  have hp := PrefixLimits.ae_path_of_trim (μ:=μ) T hBm
    ((cut_eq_zero_iff T s hBm g).mp hg)
  filter_upwards [hp,driftContinuousMod_eq_setIntegral T hBm g htT] with ω hp he
  rw [he]
  apply integral_eq_zero_of_ae
  have hp' := hp.filter_mono (ae_mono (Measure.restrict_mono (Ioc_subset_Ioc_right htT) le_rfl))
  filter_upwards [hp',ae_restrict_mem (μ:=timeMeasure) measurableSet_Ioc] with u hu huI
  exact hu ⟨⟨huI.1,huI.2.trans hts⟩,mem_univ _⟩

/-- The Itô slice energy is bounded by the full predictable input energy. -/
theorem ito_slice_energy_le (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ u, Measurable (B u)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (g : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) {t : ℝ≥0} (ht : t ≤ T) :
    (∫ ω, (itoContinuousMod T hBm g t ω)^2 ∂μ) ≤ ‖g‖^2 := by
  have he : (∫ ω, (itoContinuousMod T hBm g t ω)^2 ∂μ) =
      ‖itoProcessCLM hB T t hBm g‖^2 := by
    rw [lp_two_norm_sq]
    apply integral_congr_ae
    filter_upwards [itoContinuousMod_modification hB T hBm hBc g ht] with ω hω
    rw [hω]
  rw [he]
  exact pow_le_pow_left₀ (norm_nonneg _) (itoProcessCLM_norm_le hB T t hBm g) 2

/-- Itô isometry proves zero-prefix locality for arbitrary L2 inputs. -/
theorem ito_zero_prefix (hB : IsPreBrownianReal B μ) (T s : ℝ≥0)
    (hBm : ∀ u, Measurable (B u)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (g : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) (hg : cut T s hBm g = 0)
    {t : ℝ≥0} (hts : t ≤ s) (htT : t ≤ T) :
    ∀ᵐ ω ∂μ, itoContinuousMod T hBm g t ω = 0 := by
  have hc : cut T t hBm g = 0 := by
    rw [←cut_absorb T t s hBm hts,hg,map_zero]
  have hs : ‖itoProcessCLM hB T t hBm g‖^2 = 0 := by
    rw [itoProcessCLM_norm_sq hB htT hBm,←cut_norm_sq T t hBm,hc,norm_zero,zero_pow (by decide : 2 ≠ 0)]
  have hz : itoProcessCLM hB T t hBm g = 0 := norm_eq_zero.mp (by nlinarith [norm_nonneg (itoProcessCLM hB T t hBm g)])
  filter_upwards [itoContinuousMod_modification hB T hBm hBc g htT,
    Lp.coeFn_zero (E:=ℝ) (p:=2) (μ:=μ)] with ω he h0
  exact he.trans (hz ▸ h0)

/-- Short-interval drift contraction after fixing the earlier input prefix. -/
theorem drift_interval_norm_le (T s t : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (hst : s ≤ t) (ht : t ≤ T) (g : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm))
    (hg : cut T s hBm g = 0) :
    ‖cut T t hBm (driftProcessAssembled (μ:=μ) T hBm g)‖ ≤
      Real.sqrt ((t:ℝ)-(s:ℝ))*Real.sqrt (T:ℝ)*‖g‖ := by
  have hs := cut_sq_le T s t hBm hst ht (driftProcessAssembled (μ:=μ) T hBm g)
    (driftProcessAssembled_coeFn T hBm g) ((T:ℝ)*‖g‖^2) (by positivity)
    (fun u hu => drift_slice_energy_le T hBm g (hu.trans ht))
    (fun u hu => drift_zero_prefix T s hBm g hg hu (hu.trans (hst.trans ht)))
  have hh := Real.sqrt_le_sqrt hs
  rw [Real.sqrt_sq (norm_nonneg _),Real.sqrt_mul (sub_nonneg.mpr (show (s:ℝ) ≤ (t:ℝ) from hst)),
    Real.sqrt_mul T.coe_nonneg,Real.sqrt_sq (norm_nonneg _)] at hh
  simpa only [mul_assoc] using hh

/-- Short-interval Itô contraction after fixing the earlier input prefix. -/
theorem ito_interval_norm_le (hB : IsPreBrownianReal B μ) (T s t : ℝ≥0)
    (hBm : ∀ u, Measurable (B u)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (hst : s ≤ t) (ht : t ≤ T) (g : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm))
    (hg : cut T s hBm g = 0) :
    ‖cut T t hBm (itoProcessAssembled hB T hBm hBc g)‖ ≤
      Real.sqrt ((t:ℝ)-(s:ℝ))*‖g‖ := by
  have hs := cut_sq_le T s t hBm hst ht (itoProcessAssembled hB T hBm hBc g)
    (memLp_itoContinuousMod hB T hBm hBc g).coeFn_toLp (‖g‖^2) (sq_nonneg _)
    (fun u hu => ito_slice_energy_le hB T hBm hBc g (hu.trans ht))
    (fun u hu => ito_zero_prefix hB T s hBm hBc g hg hu (hu.trans (hst.trans ht)))
  have hh := Real.sqrt_le_sqrt hs
  rwa [Real.sqrt_sq (norm_nonneg _),Real.sqrt_mul (sub_nonneg.mpr (show (s:ℝ) ≤ (t:ℝ) from hst)),
    Real.sqrt_sq (norm_nonneg _)] at hh

end
end ChainFountainStochastic.IntervalOperators
