/-
Copyright (c) 2026 Latchezar Tomov. All rights reserved.
Released under Apache 2.0 license as described in LICENSE.
-/
module
public import ChainFountainStochastic.EnergyIto
@[expose] public section
namespace ChainFountainStochastic
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory MathFin
open MathFin.ItoIntegralL2 MathFin.ItoFormulaAdapted
open MathFin.ItoIntegralProcessLocalMartingaleGeneral
open scoped NNReal Topology

/-- Transfer the proved finite-horizon Itô local martingale to a stopped,
everywhere continuous adapted residual, then derive the true martingale
property from a bound. No optional-stopping axiom is assumed. -/
theorem bounded_stopped_residual_martingale
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {ℱ : Filtration ℝ≥0 ‹MeasurableSpace Ω›} {Y R : ℝ≥0 → Ω → ℝ} {T : ℝ≥0}
    (hY : IsLocalMartingale Y ℱ μ)
    (hR : StronglyAdapted ℱ R) (hRc : ∀ ω, Continuous (fun t => R t ω))
    (heq : ∀ᵐ ω ∂μ, ∀ t∈Icc 0 T, Y t ω=R t ω)
    {τ : Ω → WithTop ℝ≥0} (hτ : IsStoppingTime ℱ τ)
    (hτpos : ∀ ω, ⊥<τ ω) (hτT : ∀ ω, τ ω≤ T)
    {C : ℝ} (hbound : ∀ t ω, ‖stoppedProcess R τ t ω‖≤ C) :
    Martingale (stoppedProcess R τ) ℱ μ := by
  have hloc := (isStable_martingale (𝓕:=ℱ) (P:=μ)).locally Y hY τ hτ
  have had := hR.stoppedProcess_indicator (fun ω => (hRc ω).isCadlag.right_continuous) hτ
  have hcad := isStable_isCadlag (𝓕:=ℱ) R (fun ω => (hRc ω).isCadlag) τ hτ
  rw [stoppedProcess_indicator_eq hτpos] at hloc had hcad
  have hind : ∀ᵐ ω ∂μ, ∀ t, stoppedProcess Y τ t ω=stoppedProcess R τ t ω := by
    filter_upwards [heq] with ω hω t
    apply hω
    refine ⟨zero_le,?_⟩
    exact WithTop.untopA_le ((min_le_right _ _).trans (hτT ω))
  exact bounded_localMartingale_is_martingale
    (isLocalMartingale_congr_ae hloc had hcad hind) had hbound

/-- Stopped continuous adapted processes are integrable when bounded.
This will discharge, rather than assume, the integrability used in expectations. -/
theorem stopped_process_integrable
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {ℱ : Filtration ℝ≥0 ‹MeasurableSpace Ω›} {X : ℝ≥0 → Ω → ℝ}
    (hX : StronglyAdapted ℱ X) (hXc : ∀ ω, Continuous (fun t => X t ω))
    {τ : Ω → WithTop ℝ≥0} (hτ : IsStoppingTime ℱ τ) (hτpos : ∀ ω, ⊥<τ ω)
    {C : ℝ} (hbound : ∀ t ω, ‖stoppedProcess X τ t ω‖≤ C) (t : ℝ≥0) :
    Integrable (stoppedProcess X τ t) μ := by
  have had := hX.stoppedProcess_indicator (fun ω => (hXc ω).isCadlag.right_continuous) hτ
  rw [stoppedProcess_indicator_eq hτpos] at had
  exact (integrable_const C).mono' ((had t).mono (ℱ.le t)).aestronglyMeasurable
    (Eventually.of_forall (hbound t))

/-- Exact expectation estimate for a stopped energy residual that is a genuine
martingale. Unlike the older theorem, all three scalar integrability conditions
are discharged from adaptedness, path continuity, and localization bounds. -/
theorem stopped_dissipation_expectation
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {ℱ : Filtration ℝ≥0 ‹MeasurableSpace Ω›} {V I S R : ℝ≥0 → Ω → ℝ}
    {τ : Ω → WithTop ℝ≥0} (hτ : IsStoppingTime ℱ τ) (hτpos : ∀ ω, ⊥<τ ω)
    (hV : StronglyAdapted ℱ V) (hVc : ∀ ω, Continuous (fun t => V t ω))
    (hI : StronglyAdapted ℱ I) (hIc : ∀ ω, Continuous (fun t => I t ω))
    (hS : StronglyAdapted ℱ S) (hSc : ∀ ω, Continuous (fun t => S t ω))
    {CV CI CS : ℝ}
    (hVB : ∀ t ω, ‖stoppedProcess V τ t ω‖≤ CV)
    (hIB : ∀ t ω, ‖stoppedProcess I τ t ω‖≤ CI)
    (hSB : ∀ t ω, ‖stoppedProcess S τ t ω‖≤ CS)
    (hM : Martingale (stoppedProcess R τ) ℱ μ) (hR0 : ∀ ω, R 0 ω=0)
    {V₀ κ C : ℝ}
    (hineq : ∀ᵐ ω ∂μ, ∀ t,
      stoppedProcess V τ t ω+2*κ*stoppedProcess I τ t ω≤
        V₀+C*stoppedProcess S τ t ω+stoppedProcess R τ t ω) (t : ℝ≥0) :
    (∫ ω, stoppedProcess V τ t ω ∂μ)+2*κ*(∫ ω, stoppedProcess I τ t ω ∂μ)≤
      V₀+C*(∫ ω, stoppedProcess S τ t ω ∂μ) := by
  have hv := stopped_process_integrable (μ:=μ) hV hVc hτ hτpos hVB t
  have hi := stopped_process_integrable (μ:=μ) hI hIc hτ hτpos hIB t
  have hs := stopped_process_integrable (μ:=μ) hS hSc hτ hτpos hSB t
  have hzero : (∫ ω, stoppedProcess R τ t ω ∂μ)=0 := by
    have hm := hM.setIntegral_eq (zero_le : (0:ℝ≥0)≤ t) (s:=univ) MeasurableSet.univ
    have h₀ (ω : Ω) : stoppedProcess R τ 0 ω=0 := by
      exact (stoppedProcess_eq_of_le (u:=R) (τ:=τ) (i:=0) (ω:=ω) (by exact bot_le)).trans (hR0 ω)
    simpa [h₀] using hm.symm
  have hle := integral_mono_ae (hv.add (hi.const_mul (2*κ)))
    (((integrable_const V₀).add (hs.const_mul C)).add (hM.integrable t))
    (hineq.mono (fun ω hω => hω t))
  simp only [Pi.add_apply] at hle
  have hleft := integral_add hv (hi.const_mul (2*κ))
  have hright := integral_add ((integrable_const V₀).add (hs.const_mul C)) (hM.integrable t)
  have hmiddle := integral_add (integrable_const V₀) (hs.const_mul C)
  simp only [Pi.add_apply] at hleft hright hmiddle
  rw [hleft,hright,hmiddle,integral_const_mul,integral_const_mul,hzero] at hle
  simpa using hle

end
end ChainFountainStochastic
