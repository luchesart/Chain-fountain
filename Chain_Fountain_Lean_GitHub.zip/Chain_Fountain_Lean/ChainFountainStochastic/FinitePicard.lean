import ChainFountainStochastic.IntervalOperators
import ChainFountainStochastic.CausalFixedPoint

namespace ChainFountainStochastic.FinitePicard
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM MathFin.SDEExistence
open MathFin.ItoIntegralProcessContinuousModification
open TimeProjection IntervalOperators VectorSDE VectorLp
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1000000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Time-dependent coefficient composition preserves equality of pasts. -/
theorem cut_coefficient_eq (T s : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    {f : ℝ≥0 → (ι → ℝ) → (ι → ℝ)} (hf : Continuous (Function.uncurry f))
    {L : ℝ≥0} (hL : ∀ t, LipschitzWith L (f t)) {M : ℝ} (hM : ∀ t, ‖f t 0‖ ≤ M)
    (X Y : ProcessLp (μ:=μ) (ι:=ι) T hBm) (he : cut T s hBm X = cut T s hBm Y) :
    cut T s hBm (coefficientLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) hf hL (fun z => hM z.1) X) =
      cut T s hBm (coefficientLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) hf hL (fun z => hM z.1) Y) := by
  apply (cut_eq_iff T s hBm _ _).mpr
  filter_upwards [(cut_eq_iff T s hBm X Y).mp he,
    coefficientLp_coe (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) hf hL (fun z => hM z.1) X,
    coefficientLp_coe (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) hf hL (fun z => hM z.1) Y] with z he hx hy hz
  rw [hx,hy,he hz]

/-- Scalar interval estimates lift to a coupled vector process. -/
theorem cut_lift_sub_norm_le (T s t : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    {A : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm) → Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)}
    (hsub : ∀ X Y, A (X-Y) = A X-A Y) {q : ℝ} (hq : 0 ≤ q)
    (hA : ∀ g, cut T s hBm g = 0 → ‖cut T t hBm (A g)‖ ≤ q*‖g‖)
    (X Y : ProcessLp (μ:=μ) (ι:=ι) T hBm) (he : cut T s hBm X = cut T s hBm Y) :
    ‖cut T t hBm (liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) A X) - cut T t hBm (liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) A Y)‖ ≤
      (Fintype.card ι:ℝ)*q*‖X-Y‖ := by
  letI : MeasurableSpace (ℝ≥0 × Ω) := (natFiltration hBm).predictable
  rw [←map_sub,liftOperator,liftOperator,←assembleLp_sub,cut_assemble]
  calc
    _ ≤ ∑ i, ‖cut T t hBm (A (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i X)-A (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i Y))‖ := assembleLp_norm_le (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) _
    _ ≤ ∑ i : ι, q*‖X-Y‖ := by
      apply Finset.sum_le_sum
      intro i _
      rw [←hsub,←map_sub]
      have hz : cut T s hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i (X-Y)) = 0 := by
        change cut T s hBm ((ContinuousLinearMap.proj i : (ι → ℝ) →L[ℝ] ℝ).compLpL 2 _ (X-Y)) = 0
        rw [cut_compLp,map_sub,he,sub_self,map_zero]
      exact (hA _ hz).trans (mul_le_mul_of_nonneg_left (evalLp_norm_le (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i (X-Y)) hq)
    _ = _ := by simp; ring

/-- The Picard operator is contractive on a short new interval after its past
is fixed, even when the total horizon T is arbitrarily large. -/
theorem picard_interval_norm_le (hB : IsPreBrownianReal B μ) (T s t : ℝ≥0)
    (hBm : ∀ u, Measurable (B u)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (hst : s ≤ t) (ht : t ≤ T)
    (X Y : ProcessLp (μ:=μ) (ι:=ι) T hBm) (he : cut T s hBm X = cut T s hBm Y) :
    ‖cut T t hBm (picard hB T hBm hBc c x₀ X) - cut T t hBm (picard hB T hBm hBc c x₀ Y)‖ ≤
      ((Fintype.card ι:ℝ)*Real.sqrt ((t:ℝ)-(s:ℝ))*(Real.sqrt (T:ℝ)*c.Lb+c.Lσ))*‖X-Y‖ := by
  have hd := cut_coefficient_eq T s hBm c.drift_continuous c.drift_lipschitz c.drift_zero X Y he
  have hi := cut_coefficient_eq T s hBm c.diffusion_continuous c.diffusion_lipschitz c.diffusion_zero X Y he
  have hdn := cut_lift_sub_norm_le T s t hBm (q:=Real.sqrt ((t:ℝ)-(s:ℝ))*Real.sqrt (T:ℝ))
    (fun U V => map_sub (driftProcessAssembled (μ:=μ) T hBm) U V)
    (mul_nonneg (Real.sqrt_nonneg _) (Real.sqrt_nonneg _))
    (fun g hg => by simpa only [mul_assoc] using drift_interval_norm_le T s t hBm hst ht g hg)
    (c.driftLp T hBm X) (c.driftLp T hBm Y) hd
  have hin := cut_lift_sub_norm_le T s t hBm (q:=Real.sqrt ((t:ℝ)-(s:ℝ))) (itoProcessAssembled_sub hB T hBm hBc)
    (Real.sqrt_nonneg _) (fun g hg => ito_interval_norm_le hB T s t hBm hBc hst ht g hg)
    (c.diffusionLp T hBm X) (c.diffusionLp T hBm Y) hi
  have hbd := coefficientLp_sub_norm_le (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.drift_continuous
    c.drift_lipschitz (fun z => c.drift_zero z.1) X Y
  have hsd := coefficientLp_sub_norm_le (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.diffusion_continuous
    c.diffusion_lipschitz (fun z => c.diffusion_zero z.1) X Y
  rw [picard,picard,map_add,map_add,map_add,map_add]
  rw [show ∀ a b d e f : ProcessLp (μ:=μ) (ι:=ι) T hBm,
    (a+b+d)-(a+e+f)=(b-e)+(d-f) from fun _ _ _ _ _ => by abel]
  calc
    _ ≤ _ := norm_add_le _ _
    _ ≤ (Fintype.card ι:ℝ)*(Real.sqrt ((t:ℝ)-(s:ℝ))*Real.sqrt (T:ℝ))*‖c.driftLp T hBm X-c.driftLp T hBm Y‖ +
      (Fintype.card ι:ℝ)*Real.sqrt ((t:ℝ)-(s:ℝ))*‖c.diffusionLp T hBm X-c.diffusionLp T hBm Y‖ := add_le_add hdn hin
    _ ≤ (Fintype.card ι:ℝ)*(Real.sqrt ((t:ℝ)-(s:ℝ))*Real.sqrt (T:ℝ))*(c.Lb*‖X-Y‖) +
      (Fintype.card ι:ℝ)*Real.sqrt ((t:ℝ)-(s:ℝ))*(c.Lσ*‖X-Y‖) :=
      add_le_add (mul_le_mul_of_nonneg_left hbd (by positivity))
        (mul_le_mul_of_nonneg_left hsd (by positivity))
    _ = _ := by ring

/-- Predictable L2 Picard iteration is causal at every deterministic time. -/
theorem picard_causal (hB : IsPreBrownianReal B μ) (T s : ℝ≥0)
    (hBm : ∀ u, Measurable (B u)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (hs : s ≤ T)
    (X Y : ProcessLp (μ:=μ) (ι:=ι) T hBm) (he : cut T s hBm X = cut T s hBm Y) :
    cut T s hBm (picard hB T hBm hBc c x₀ X) = cut T s hBm (picard hB T hBm hBc c x₀ Y) := by
  have h := picard_interval_norm_le hB T s s hBm hBc c x₀ le_rfl hs X Y he
  simp only [sub_self,Real.sqrt_zero,mul_zero,zero_mul] at h
  exact sub_eq_zero.mp (norm_eq_zero.mp (le_antisymm h (norm_nonneg _)))

end
end ChainFountainStochastic.FinitePicard
