module
public import ChainFountainStochastic.SDEContinuous
@[expose] public section
namespace ChainFountainStochastic.SDEContinuous
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology
open scoped NNReal ENNReal
open MathFin MathFin.SDEExistence MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM
  MathFin.ItoIntegralProcess MathFin.ItoIntegralProcessGeneral
  MathFin.ItoIntegralProcessContinuousModification
set_option backward.isDefEq.respectTransparency true
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}

/-- All-times equality of predictable processes induces equality of their L2 classes. -/
theorem trim_eq_of_ae_paths (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    {Y Z : ℝ≥0 → Ω → ℝ} (hY : IsStronglyPredictable (natFiltration hBm) Y)
    (hZ : IsStronglyPredictable (natFiltration hBm) Z)
    (he : ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = Z t ω) :
    Function.uncurry Y =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry Z := by
  have hYm : Measurable (Function.uncurry Y) :=
    hY.measurable.mono (natFiltration hBm).predictable_le_prod le_rfl
  have hZm : Measurable (Function.uncurry Z) :=
    hZ.measurable.mono (natFiltration hBm).predictable_le_prod le_rfl
  have hs : (fun z : Ω × ℝ≥0 => Y z.2 z.1) =ᵐ[μ.prod (timeMeasure_T T)]
      (fun z : Ω × ℝ≥0 => Z z.2 z.1) := by
    apply (Measure.ae_prod_iff_ae_ae
      (measurableSet_eq_fun (hYm.comp measurable_swap) (hZm.comp measurable_swap))).2
    filter_upwards [he] with ω hω
    filter_upwards [show ∀ᵐ t ∂timeMeasure_T T, t ∈ Ioc 0 T from
      ae_restrict_mem measurableSet_Ioc] with t ht
    exact hω t ht.2
  exact ae_eq_trim_of_measurable (natFiltration hBm).predictable_le_prod
    hY.measurable hZ.measurable
    (Measure.measurePreserving_swap.quasiMeasurePreserving.ae hs)

/-- The Picard operator has the stated continuous integral representative. -/
theorem picardMap_coe (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {b σ : ℝ → ℝ} {Lb Lσ : ℝ≥0} (hb : LipschitzWith Lb b) (hσ : LipschitzWith Lσ σ)
    (x₀ : ℝ) (X : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) :
    ⇑(picardMap hB T hBm hBc hb hσ (Lp.const 2 _ x₀) X)
      =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => x₀ +
      driftContinuousMod T hBm (lipComp T hBm b Lb hb X) z.1 z.2 +
      itoContinuousMod T hBm (lipComp T hBm σ Lσ hσ X) z.1 z.2 := by
  let φ := lipComp T hBm b Lb hb X
  let ψ := lipComp T hBm σ Lσ hσ X
  have hI : ⇑(itoProcessAssembled hB T hBm hBc ψ)
      =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry (itoContinuousMod T hBm ψ) :=
    (memLp_itoContinuousMod hB T hBm hBc ψ).coeFn_toLp
  filter_upwards [Lp.coeFn_add
    (Lp.const 2 _ x₀ + driftProcessAssembled (μ:=μ) T hBm φ)
    (itoProcessAssembled hB T hBm hBc ψ),
    Lp.coeFn_add (Lp.const 2 _ x₀) (driftProcessAssembled (μ:=μ) T hBm φ),
    Lp.coeFn_const (p:=2) (μ:=trimMeasure_T (μ:=μ) T hBm) (c:=x₀),
    driftProcessAssembled_coeFn T hBm φ,hI] with z h1 h2 h0 hd hi
  change (Lp.const 2 (trimMeasure_T (μ:=μ) T hBm) x₀ +
    driftProcessAssembled (μ:=μ) T hBm φ + itoProcessAssembled hB T hBm hBc ψ :
    Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) z = _
  simp only [h1,h2,h0,hd,hi,Pi.add_apply,Function.const_apply,Function.uncurry]
  rfl

/-- The integral identity determines the canonical Picard representative for every
strong solution, not only the solution constructed by Banach's theorem. -/
theorem ScalarStrongSolution.canonical_equation (_hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t))
    {b σ : ℝ → ℝ} {Lb Lσ : ℝ≥0} (hb : LipschitzWith Lb b) (hσ : LipschitzWith Lσ σ)
    (x₀ : ℝ) {Y : ℝ≥0 → Ω → ℝ} (hY : ScalarStrongSolution (μ:=μ) T hBm b σ x₀ Y) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = x₀ +
      driftContinuousMod T hBm (lipComp T hBm b Lb hb (hY.state_memLp.toLp (Function.uncurry Y))) t ω +
      itoContinuousMod T hBm (lipComp T hBm σ Lσ hσ (hY.state_memLp.toLp (Function.uncurry Y))) t ω := by
  let X := hY.state_memLp.toLp (Function.uncurry Y)
  let φ := lipComp T hBm b Lb hb X
  let ψ := lipComp T hBm σ Lσ hσ X
  have hφ : ⇑φ =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => b (Y z.1 z.2) := by
    filter_upwards [lipComp_coe T hBm hb X,hY.state_memLp.coeFn_toLp] with z hc hz
    exact hc.trans (congrArg b hz)
  have hψ : ⇑ψ =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => σ (Y z.1 z.2) := by
    filter_upwards [lipComp_coe T hBm hσ X,hY.state_memLp.coeFn_toLp] with z hc hz
    exact hc.trans (congrArg σ hz)
  have hψclass : hY.diffusion_memLp.toLp (fun z : ℝ≥0 × Ω => σ (Y z.1 z.2)) = ψ :=
    (MemLp.toLp_congr hY.diffusion_memLp (Lp.memLp ψ) hψ.symm).trans
      (Lp.toLp_coeFn ψ (Lp.memLp ψ))
  filter_upwards [hY.equation,drift_mod_integral_all_times T hBm φ,
    ae_path_of_trim_eq T hBm hφ] with ω he hd hc
  intro t ht
  change Y t ω = x₀ + driftContinuousMod T hBm φ t ω + itoContinuousMod T hBm ψ t ω
  rw [he t ht,hψclass,hd t ht]
  congr 2
  exact (integral_congr_ae (hc.filter_mono
    (ae_mono (Measure.restrict_mono (Ioc_subset_Ioc_right ht) le_rfl)))).symm

/-- Every square-integrable predictable strong solution is a Picard fixed point. -/
theorem ScalarStrongSolution.fixed_point (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {b σ : ℝ → ℝ} {Lb Lσ : ℝ≥0} (hb : LipschitzWith Lb b) (hσ : LipschitzWith Lσ σ)
    (x₀ : ℝ) {Y : ℝ≥0 → Ω → ℝ} (hY : ScalarStrongSolution (μ:=μ) T hBm b σ x₀ Y) :
    picardMap hB T hBm hBc hb hσ (Lp.const 2 _ x₀)
      (hY.state_memLp.toLp (Function.uncurry Y)) = hY.state_memLp.toLp (Function.uncurry Y) := by
  let X := hY.state_memLp.toLp (Function.uncurry Y)
  have hp : IsStronglyPredictable (natFiltration hBm) (fun t ω => x₀ +
      driftContinuousMod T hBm (lipComp T hBm b Lb hb X) t ω +
      itoContinuousMod T hBm (lipComp T hBm σ Lσ hσ X) t ω) :=
    (stronglyMeasurable_const.add (driftContinuousMod_isStronglyPredictable T hBm _)).add
      (itoContinuousMod_isStronglyPredictable hB T hBm hBc _)
  have he := trim_eq_of_ae_paths T hBm hY.predictable hp
    (hY.canonical_equation hB T hBm hb hσ x₀)
  exact Lp.ext ((picardMap_coe hB T hBm hBc hb hσ x₀ X).trans
    (he.symm.trans hY.state_memLp.coeFn_toLp.symm))

/-- Pathwise uniqueness on the whole horizon, on one probability-one event. -/
theorem scalar_strong_solution_unique (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {b σ : ℝ → ℝ} {Lb Lσ : ℝ≥0} (hb : LipschitzWith Lb b) (hσ : LipschitzWith Lσ σ)
    (x₀ : ℝ) (hc : (T:ℝ)*Lb + Real.sqrt (T:ℝ)*Lσ < 1)
    {Y Z : ℝ≥0 → Ω → ℝ} (hY : ScalarStrongSolution (μ:=μ) T hBm b σ x₀ Y)
    (hZ : ScalarStrongSolution (μ:=μ) T hBm b σ x₀ Z) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = Z t ω := by
  obtain ⟨X,hX,hu⟩ := picardMap_exists_unique_fixedPoint hB T hBm hBc hb hσ
    (Lp.const 2 _ x₀) hc
  have he : hY.state_memLp.toLp (Function.uncurry Y) = hZ.state_memLp.toLp (Function.uncurry Z) :=
    (hu _ (hY.fixed_point hB T hBm hBc hb hσ x₀)).trans
      (hu _ (hZ.fixed_point hB T hBm hBc hb hσ x₀)).symm
  filter_upwards [hY.canonical_equation hB T hBm hb hσ x₀,
    hZ.canonical_equation hB T hBm hb hσ x₀] with ω hy hz
  intro t ht
  rw [hy t ht,hz t ht,he]

/-- Locally, a positive contraction horizon always exists for finite Lipschitz constants. -/
theorem exists_positive_contraction_horizon (Lb Lσ : ℝ≥0) :
    ∃ T : ℝ≥0, 0 < T ∧ (T:ℝ)*Lb + Real.sqrt (T:ℝ)*Lσ < 1 := by
  have hq : Continuous (fun t : ℝ≥0 => (t:ℝ)*Lb + Real.sqrt (t:ℝ)*Lσ) := by fun_prop
  have hnear : ∀ᶠ t : ℝ≥0 in 𝓝 0, (t:ℝ)*Lb + Real.sqrt (t:ℝ)*Lσ < 1 :=
    (hq.tendsto 0).eventually (by simpa using (gt_mem_nhds (by norm_num : (0:ℝ)<1)))
  obtain ⟨ε,hε,hεq⟩ := Metric.eventually_nhds_iff.mp hnear
  let T : ℝ≥0 := ⟨ε/2,by positivity⟩
  refine ⟨T,?_,hεq ?_⟩
  · change (0:ℝ) < ε/2
    exact half_pos hε
  · change |ε/2-(0:ℝ)| < ε
    rw [sub_zero,abs_of_pos (half_pos hε)]
    linarith

/-- A scalar strong solution is constructed on a positive horizon and is unique
among all predictable square-integrable strong solutions on that horizon. -/
theorem exists_unique_local_scalar_strong_solution (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {b σ : ℝ → ℝ} {Lb Lσ : ℝ≥0} (hb : LipschitzWith Lb b) (hσ : LipschitzWith Lσ σ)
    (x₀ : ℝ) : ∃ T : ℝ≥0, 0 < T ∧ ∃ Y : ℝ≥0 → Ω → ℝ,
      ScalarStrongSolution (μ:=μ) T hBm b σ x₀ Y ∧
      ∀ Z, ScalarStrongSolution (μ:=μ) T hBm b σ x₀ Z →
        ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = Z t ω := by
  obtain ⟨T,hT,hc⟩ := exists_positive_contraction_horizon Lb Lσ
  obtain ⟨Y,hY⟩ := exists_scalar_strong_solution hB T hBm hBc hb hσ x₀ hc
  exact ⟨T,hT,Y,hY,fun Z hZ => scalar_strong_solution_unique hB T hBm hBc hb hσ x₀ hc hY hZ⟩
end
end ChainFountainStochastic.SDEContinuous
