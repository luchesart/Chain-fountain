import ChainFountainStochastic.ItoContinuousMartingale

namespace ChainFountainStochastic.ItoMaximal
noncomputable section
open MeasureTheory ProbabilityTheory Real Filter Set
open scoped NNReal ENNReal
set_option maxHeartbeats 1000000
set_option backward.isDefEq.respectTransparency false
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {ℱ : Filtration ℝ≥0 mΩ} {X : ℝ≥0 → Ω → ℝ}
  (hM : Martingale X ℱ μ) (hc : ∀ ω, Continuous (X · ω))
  {C : ℝ}
  (he : ∀ q t, Integrable (fun ω => exp (q*X t ω)) μ ∧
    (∫ ω, exp (q*X t ω) ∂μ) ≤ exp (q^2*C^2*(t:ℝ)/2))

include hM hc he

/-- Doob's inequality turns terminal exponential moment estimates into a
uniform-in-time exponential estimate. -/
theorem maximal_exponential (T : ℝ≥0) (a q : ℝ) (hq : 0 ≤ q) :
    μ.real {ω | (a:EReal) ≤ ⨆ s ≤ T, (X s ω:EReal)} ≤
      exp (-q*a+q^2*C^2*(T:ℝ)/2) := by
  let W := fun t ω => exp (q*X t ω)
  have hw : Submartingale W ℱ μ :=
    (hM.smul q).submartingale_convex_comp convexOn_exp continuous_exp (fun t => (he q t).1)
  have hwc : ∀ ω, Continuous (W · ω) := fun ω => by dsimp [W]; fun_prop
  let ε := exp (q*a)
  have hmax := maximal_ineq hw (show 0 ≤ W from fun t ω => (exp_pos _).le) ε T
    (fun ω => (hwc ω).isRightContinuous)
  have hbound : ε * μ.real {ω | ε ≤ ⨆ s : Iic T, W s ω} ≤ exp (q^2*C^2*(T:ℝ)/2) :=
    hmax.trans ((setIntegral_le_integral (hw.integrable T)
      (ae_of_all _ fun ω => (exp_pos _).le)).trans (he q T).2)
  have hsub : {ω | (a:EReal) ≤ ⨆ s ≤ T, (X s ω:EReal)} ⊆
      {ω | ε ≤ ⨆ s : Iic T, W s ω} := by
    intro ω hω
    obtain ⟨s,hs,hsm⟩ := isCompact_Icc.exists_isMaxOn
      (nonempty_Icc.mpr (show (0:ℝ≥0) ≤ T from bot_le)) (hc ω).continuousOn
    have ha : a ≤ X s ω := EReal.coe_le_coe_iff.mp
      (hω.trans (iSup_le fun (u : ℝ≥0) => iSup_le fun (hu : u ≤ T) => EReal.coe_le_coe (hsm ⟨bot_le,hu⟩)))
    have hb : BddAbove (range fun s : Iic T => W s ω) := by
      have hr : range (fun s : Iic T => W s ω) = (W · ω) '' Icc 0 T := by
        ext y; simp only [mem_range,mem_image,mem_Icc]
        constructor
        · rintro ⟨u,rfl⟩; exact ⟨u,⟨bot_le,u.property⟩,rfl⟩
        · rintro ⟨u,hu,rfl⟩; exact ⟨⟨u,hu.2⟩,rfl⟩
      rw [hr]
      exact (isCompact_Icc.image (hwc ω)).bddAbove
    exact (exp_le_exp.mpr (mul_le_mul_of_nonneg_left ha hq)).trans (le_ciSup hb ⟨s,hs.2⟩)
  have hp := (mul_le_mul_of_nonneg_left (measureReal_mono hsub) (exp_pos _).le).trans hbound
  calc
    _ ≤ exp (q^2*C^2*(T:ℝ)/2) / ε := (le_div_iff₀ (exp_pos _)).mpr
      (by simpa [mul_comm] using hp)
    _ = _ := by rw [← exp_sub]; congr 1; ring

/-- Gaussian maximal estimate for a continuous martingale with bounded-
diffusion exponential moments. -/
theorem maximal_gaussian (hC : 0 < C) {T : ℝ≥0} (hT : 0 < T)
    {a : ℝ} (ha : 0 ≤ a) :
    μ.real {ω | (a:EReal) ≤ ⨆ s ≤ T, (X s ω:EReal)} ≤
      exp (-(a^2)/(2*C^2*(T:ℝ))) := by
  have h := maximal_exponential hM hc he T a (a/(C^2*T)) (by positivity)
  convert h using 1
  congr 1
  have ht : (T:ℝ) ≠ 0 := ne_of_gt hT
  field_simp
  <;> ring

end
end ChainFountainStochastic.ItoMaximal
