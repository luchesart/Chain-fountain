import ChainFountainStochastic.ItoFreezing
import ChainFountainStochastic.LILDriftStability

namespace ChainFountainStochastic.ActualIntegralLIL
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Real MathFin BrownianSmallTime LILDriftStability
open MathFin.ItoIntegralL2 MathFin.ItoIntegralLocalised
open scoped NNReal ENNReal Topology
set_option maxHeartbeats 1000000
set_option backward.isDefEq.respectTransparency true

/-- Pathwise transfer of both LIL limits through a negligible remainder. -/
theorem transfer_nonneg {b x : ℝ≥0 → ℝ} {q : ℝ} (hq : 0 ≤ q)
    (hb : limsup (fun t => (b t/scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = 1 ∧
      liminf (fun t => (b t/scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = -1)
    (hr : Tendsto (fun t => (x t-q*b t)/scale t) (𝓝[>] (0:ℝ≥0)) (𝓝 0)) :
    limsup (fun t => (x t/scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = q ∧
      liminf (fun t => (x t/scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = -q := by
  have he (t : ℝ≥0) : (x t/scale t).toEReal =
      (q:EReal)*(b t/scale t).toEReal + ((x t-q*b t)/scale t).toEReal := by
    rw [← EReal.coe_mul,← EReal.coe_add]
    congr 1
    ring
  simp_rw [he]
  rw [limsup_add_zero hr,liminf_add_zero hr,
    EReal.limsup_const_mul_of_nonneg_of_ne_top (by exact_mod_cast hq) (by simp),
    EReal.liminf_const_mul_of_nonneg_of_ne_top (by exact_mod_cast hq) (by simp),hb.1,hb.2]
  simp

/-- A single Brownian probability-one event supports transfer for every real
initial coefficient and every path with a negligible normalized remainder. -/
theorem transfer {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    {B : ℝ≥0 → Ω → ℝ} (hB : IsBrownianReal B μ) :
    ∀ᵐ ω ∂μ, ∀ q : ℝ, ∀ x : ℝ≥0 → ℝ,
      Tendsto (fun t => (x t-q*B t ω)/scale t) (𝓝[>] (0:ℝ≥0)) (𝓝 0) →
      limsup (fun t => (x t/scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = |q| ∧
      liminf (fun t => (x t/scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = -|q| := by
  filter_upwards [two_sided_zero hB,two_sided_zero hB.neg] with ω hp hn
  intro q x hr
  by_cases hq : 0 ≤ q
  · simpa only [abs_of_nonneg hq] using transfer_nonneg hq hp hr
  · have hq' : q ≤ 0 := (not_le.mp hq).le
    have hr' : Tendsto (fun t => (x t-(-q)*(-B t ω))/scale t) (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
      simpa only [neg_mul_neg] using hr
    simpa only [abs_of_nonpos hq'] using transfer_nonneg (neg_nonneg.mpr hq') hn hr'

/-- Sharp LIL for the actual stochastic integral with a bounded continuous
adapted coefficient, including a path-dependent O(t) drift. -/
theorem integral {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hT : 0 < T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
    {a : ℝ≥0 → Ω → ℝ}
    (ha : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hc : ∀ ω, Continuous (a · ω))
    (hp : IsStronglyPredictable (natFiltration hBm) a)
    {C q : ℝ} (hb : ∀ t ω, |a t ω| ≤ C) (hz : ∀ᵐ ω ∂μ, a 0 ω = q) :
    ∀ᵐ ω ∂μ, ∀ A : ℝ≥0 → ℝ, ∀ K : ℝ,
      (∀ᶠ t in 𝓝[>] (0:ℝ≥0), |A t| ≤ K*(t:ℝ)) →
      limsup (fun t => ((predItoIntegral (μ:=μ) T hBm hp t ω+A t)/scale t).toEReal)
        (𝓝[>] (0:ℝ≥0)) = |q| ∧
      liminf (fun t => ((predItoIntegral (μ:=μ) T hBm hp t ω+A t)/scale t).toEReal)
        (𝓝[>] (0:ℝ≥0)) = -|q| := by
  filter_upwards [transfer (show IsBrownianReal B μ from ⟨hB,ae_of_all _ hBc⟩),
    ItoFreezing.bounded_coefficient hB T hT hBm hBc ha hc hp hb hz] with ω ht hr
  intro A K hA
  apply ht q
  convert hr.add (bounded_drift_negligible hA) using 1
  · ext t
    ring
  · simp

end
end ChainFountainStochastic.ActualIntegralLIL
