import ChainFountainStochastic.CutoffExhaustion
namespace ChainFountainStochastic.CutoffExhaustion
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralProcessLocalMartingaleGeneral
open VectorSDE GlobalCutoffSDE MechanicalCutoff MechanicalExhaustion GlobalLocalization
open CutoffExhaustion LocalIntegralBridge
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1000000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {hBm : ∀ t, Measurable (B t)} {a : Parameters} {p : ℝ≥0 → State} {x₀ : State}

/-- The maximal lifetime is the supremum of the constructed genuine exits. -/
def Family.lifetime (F : Family (μ:=μ) hBm a p x₀) (ω : Ω) : WithTop ℝ≥0 :=
  ⨆ n, F.exit n ω

/-- A measurable pointwise limit glues the natural-filtration predictable
solutions. Its value after the lifetime is irrelevant to the local SDE. -/
def Family.process (F : Family (μ:=μ) hBm a p x₀) (t : ℝ≥0) (ω : Ω) : State :=
  limUnder atTop (fun n => F.Y n t ω)

theorem Family.lifetime_stopping (F : Family (μ:=μ) hBm a p x₀) :
    IsStoppingTime (augFiltration (μ:=μ) hBm) F.lifetime := by
  intro t
  have he : {ω | F.lifetime ω ≤ (t:WithTop ℝ≥0)} =
      ⋂ n : ℕ, {ω | F.exit n ω ≤ (t:WithTop ℝ≥0)} := by
    ext ω; simp only [Family.lifetime,mem_setOf_eq,iSup_le_iff,mem_iInter]
  rw [he]
  exact MeasurableSet.iInter (fun n => (F.exit_properties n).1 t)

theorem Family.lifetime_positive (F : Family (μ:=μ) hBm a p x₀) (ω : Ω) :
    ⊥ < F.lifetime ω :=
  ((F.exit_properties 0).2.1 ω).trans_le (le_iSup (fun n => F.exit n ω) 0)

theorem Family.process_predictable (F : Family (μ:=μ) hBm a p x₀) :
    IsStronglyPredictable (natFiltration hBm) F.process := by
  letI : MeasurableSpace (ℝ≥0 × Ω) := (natFiltration hBm).predictable
  exact StronglyMeasurable.limUnder (fun n => (F.strong n 0).predictable)

theorem Family.process_initial (F : Family (μ:=μ) hBm a p x₀) (ω : Ω) :
    F.process 0 ω = x₀ := by
  apply Tendsto.limUnder_eq
  simpa only [(F.strong _ 0).initial ω] using
    (tendsto_const_nhds : Tendsto (fun _ : ℕ => x₀) atTop (𝓝 x₀))

/-- The glued process agrees with each actual cutoff solution all the way to
its genuine exit, on a single conull event for all indices and all times. -/
theorem Family.process_eq_before_exit (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ, ∀ n : ℕ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ F.exit n ω →
      F.process t ω = F.X n t ω ∧ F.process t ω = F.Y n t ω := by
  filter_upwards [F.prefix_agreement,ae_all_iff.mpr F.version] with ω hco hv
  intro n t ht
  have he : F.process t ω = F.X n t ω := by
    apply Tendsto.limUnder_eq
    apply tendsto_const_nhds.congr'
    refine eventually_atTop.2 ⟨n,fun m hm => ?_⟩
    exact (hco n m hm t ht).trans (hv m t)
  exact ⟨he,he.trans (hv n t)⟩

/-- The path is continuous and has strictly positive height before its
lifetime, without any pre-existing solution hypothesis. -/
theorem Family.process_regular (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ, ContinuousOn (fun t => F.process t ω) {t | (t:WithTop ℝ≥0) < F.lifetime ω} ∧
      ∀ t : ℝ≥0, (t:WithTop ℝ≥0) < F.lifetime ω → 0 < F.process t ω 0 := by
  filter_upwards [F.process_eq_before_exit] with ω he
  have hlocal (t : ℝ≥0) (ht : (t:WithTop ℝ≥0) < F.lifetime ω) :
      ∃ n, (t:WithTop ℝ≥0) < F.exit n ω := lt_iSup_iff.mp ht
  refine ⟨?_,?_⟩
  · intro t ht
    obtain ⟨n,hn⟩ := hlocal t ht
    apply ContinuousAt.continuousWithinAt
    apply (F.continuous n ω).continuousAt.congr_of_eventuallyEq
    have ho : IsOpen {s : ℝ≥0 | (s:WithTop ℝ≥0) < F.exit n ω} :=
      isOpen_lt WithTop.continuous_coe continuous_const
    filter_upwards [ho.mem_nhds hn] with s hs
    exact (he n s hs.le).1
  · intro t ht
    obtain ⟨n,hn⟩ := hlocal t ht
    rw [(he n t hn.le).1]
    have hr : 0 < (n:ℝ)+F.R := by have := F.radius_gt; positivity
    exact height_pos_of_gauge_le hr
      (GaugeExit.interior_before (F.continuous n) (gauge_continuous _) ω hn).le

/-- If the lifetime is finite, every localization exits strictly before it.
This excludes a spurious finite terminal index in the gluing construction. -/
theorem Family.exit_lt_lifetime (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ, F.lifetime ω ≠ ⊤ → ∀ n, F.exit n ω < F.lifetime ω := by
  filter_upwards [F.exits_increase] with ω hω hf n
  have hn : F.exit n ω ≠ ⊤ := by
    intro he
    have hl : F.exit n ω ≤ F.lifetime ω := le_iSup (fun m => F.exit m ω) n
    rw [he] at hl
    exact hf (top_le_iff.mp hl)
  exact (hω.2 n hn).trans_le (le_iSup (fun m => F.exit m ω) (n+1))

/-- Explosion alternative in the positive-height domain: on finite lifetime
no compact subset can contain any final segment of the trajectory. The compact
set is quantified after the common conull event. -/
theorem Family.explosion_alternative (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ, F.lifetime ω ≠ ⊤ → ∀ K : Set State, IsCompact K →
      (∀ x ∈ K, 0 < x 0) → ∀ t : ℝ≥0, (t:WithTop ℝ≥0) < F.lifetime ω →
      ∃ s : ℝ≥0, t ≤ s ∧ (s:WithTop ℝ≥0) < F.lifetime ω ∧ F.process s ω ∉ K := by
  filter_upwards [F.exits_increase,F.exit_lt_lifetime,F.process_eq_before_exit] with ω hmono hstrict he
  intro hf K hK hKpos t ht
  obtain ⟨N,hN⟩ := compact_subset_gauge F.R hK hKpos
  obtain ⟨j,hj⟩ := (lt_iSup_iff.mp ht : ∃ j, (t:WithTop ℝ≥0) < F.exit j ω)
  let m := max (N+1) j
  have hm : N < m := (Nat.lt_succ_self N).trans_le (le_max_left _ _)
  have hmf : F.exit m ω ≠ ⊤ := ne_of_lt ((hstrict hf m).trans_le le_top)
  let s := (F.exit m ω).untopA
  have hs : (s:WithTop ℝ≥0) = F.exit m ω := by
    dsimp [s]; rw [WithTop.untopA_eq_untop hmf]; exact WithTop.coe_untop _ _
  refine ⟨s,WithTop.coe_le_coe.mp (hs.symm ▸ (hj.le.trans (hmono.1 (le_max_right _ _)))),
    hs.symm ▸ hstrict hf m,?_⟩
  intro hmem
  have hr : 0 < (N:ℝ)+F.R := by have := F.radius_gt; positivity
  have hrad : (N:ℝ)+F.R < (m:ℝ)+F.R := by
    have hnm : (N:ℝ) < (m:ℝ) := by exact_mod_cast hm
    linarith
  have hin := gauge_strict_nesting hr hrad (hN _ hmem).le
  have hb := GaugeExit.boundary_of_finite (F.continuous m) (gauge_continuous ((m:ℝ)+F.R)) ω hmf
  have hp := (he m s hs.le).1
  change F.process s ω = F.X m (F.exit m ω).untopA ω at hp
  rw [hp] at hin
  exact not_le.mpr hin hb

/-- A finite-lifetime trajectory has no continuous continuation through its
terminal time with positive height. This is a proved maximality property. -/
theorem Family.no_positive_continuous_extension (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ, ∀ z : ℝ≥0, F.lifetime ω = (z:WithTop ℝ≥0) →
      ¬ ∃ Z : ℝ≥0 → State, ContinuousOn Z (Icc 0 z) ∧
        (∀ t ∈ Icc 0 z, 0 < Z t 0) ∧
        ∀ t < z, Z t = F.process t ω := by
  filter_upwards [F.explosion_alternative] with ω hex
  intro z hz ⟨Z,hZc,hZpos,hZe⟩
  let K := Z '' Icc 0 z
  have hK : IsCompact K := isCompact_Icc.image_of_continuousOn hZc
  have hKpos : ∀ x ∈ K, 0 < x 0 := by
    rintro x ⟨t,ht,rfl⟩
    exact hZpos t ht
  obtain ⟨s,hs,hsz,hout⟩ := hex (hz ▸ WithTop.coe_ne_top) K hK hKpos 0
    (F.lifetime_positive ω)
  have hsz' : s < z := WithTop.coe_lt_coe.mp (hz ▸ hsz)
  apply hout
  rw [←hZe s hsz']
  exact mem_image_of_mem Z ⟨zero_le,hsz'.le⟩

/-- Both actual mechanical fields agree with the localized integrands along
the glued solution. -/
theorem Family.coefficients_before_exit (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ, ∀ n : ℕ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ F.exit n ω →
      (F.c n).drift t (F.Y n t ω) = a.drift (p t,F.process t ω) ∧
      (F.c n).diffusion t (F.Y n t ω) = a.diffusion (p t,F.process t ω) := by
  filter_upwards [F.process_eq_before_exit] with ω he
  intro n t ht
  have hb := (F.exit_properties n).2.2 t ω
  rw [stoppedProcess_eq_of_le ht] at hb
  rw [←(he n t ht).1] at hb
  rw [←(he n t ht).2]
  exact F.agrees n t _ hb

/-- Local mechanical stochastic integral equation on every integer horizon.
The diffusion integrand is predictable, bounded, and proved above to equal the
original singular diffusion before the genuine exit. -/
theorem Family.local_mechanical_equation (F : Family (μ:=μ) hBm a p x₀)
    (hB : IsPreBrownianReal B μ) (hBc : ∀ ω, Continuous (fun t => B t ω)) :
    ∀ᵐ ω ∂μ, ∀ n N : ℕ, ∀ t ∈ Icc 0 (N:ℝ≥0), (t:WithTop ℝ≥0) ≤ F.exit n ω → ∀ i : Fin 3,
      F.process t ω i = x₀ i + (∫ s in Ioc (0:ℝ≥0) t,
        a.drift (p s,F.process s ω) i ∂timeMeasure) +
        MathFin.ItoIntegralLocalised.predItoIntegral (μ:=μ) N hBm
          (diffusion_predictable hBm (F.c n) (F.strong n N).predictable i) t ω := by
  have hsol (n N : ℕ) := strong_solution_predIto_equation hB N hBm hBc (F.c n) x₀
    (F.strong n N) (F.bound n)
  filter_upwards [ae_all_iff.mpr (fun n => ae_all_iff.mpr (hsol n)),
    F.coefficients_before_exit,F.process_eq_before_exit] with ω he hc hp
  intro n N t ht hτ i
  have hi : (∫ s in Ioc (0:ℝ≥0) t, (F.c n).drift s (F.Y n s ω) i ∂timeMeasure) =
      ∫ s in Ioc (0:ℝ≥0) t, a.drift (p s,F.process s ω) i ∂timeMeasure := by
    apply setIntegral_congr_fun measurableSet_Ioc
    intro s hs
    exact congrFun (hc n s ((WithTop.coe_le_coe.mpr hs.2).trans hτ)).1 i
  rw [(hp n t hτ).2,←hi]
  exact he n N t ht i

end
end ChainFountainStochastic.CutoffExhaustion
