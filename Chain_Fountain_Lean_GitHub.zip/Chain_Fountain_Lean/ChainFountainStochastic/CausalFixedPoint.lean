import Mathlib.Analysis.Normed.Operator.Basic
import Mathlib.Topology.MetricSpace.Contracting
import Mathlib.Tactic

namespace ChainFountainStochastic.CausalFixedPoint
noncomputable section
open Set
open scoped NNReal
set_option maxHeartbeats 600000
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

/-- Extend a fixed prefix by applying Banach on the closed affine space of
extensions of that prefix. Future values are set by the larger projection. -/
theorem extend_prefix (P Q : E →L[ℝ] E) (F : E → E)
    (hPQ : ∀ x, P (Q x) = P x)
    (hcausal : ∀ x y, P x = P y → P (F x) = P (F y))
    (q : ℝ≥0) (hq : q < 1)
    (hcontract : ∀ x y, P x = P y → ‖Q (F x) - Q (F y)‖ ≤ q * ‖x-y‖)
    (y : E) (hy : P (F y) = y) (hPy : P y = y) :
    ∃ x : E, Q (F x) = x ∧ P x = y := by
  let S : Set E := {x | P x = y}
  have hclosed : IsClosed S := isClosed_eq P.continuous continuous_const
  letI : CompleteSpace S := hclosed.completeSpace_coe
  letI : Nonempty S := ⟨⟨y,hPy⟩⟩
  let f : S → S := fun x => ⟨Q (F x), by
    change P (Q (F x)) = y
    rw [hPQ, hcausal x y (x.property.trans hPy.symm), hy]⟩
  have hf : ContractingWith q f := by
    refine ⟨hq,LipschitzWith.of_dist_le_mul fun x z => ?_⟩
    change dist (Q (F x)) (Q (F z)) ≤ q * dist (x:E) (z:E)
    simp only [dist_eq_norm]
    exact hcontract x z (x.property.trans z.property.symm)
  let x : S := hf.fixedPoint f
  refine ⟨(x:E),?_,x.property⟩
  exact congrArg Subtype.val hf.fixedPoint_isFixedPt

/-- A causal map has a fixed point if every piece of a finite time partition
is contractive after fixing its past. No smallness of the full horizon is assumed. -/
theorem exists_fixed_point (N : ℕ) (P : ℕ → E →L[ℝ] E) (F : E → E)
    (hzero : ∀ x, P 0 x = 0) (hfull : ∀ x, P N x = x)
    (habsorb : ∀ m n, m ≤ n → ∀ x, P m (P n x) = P m x)
    (hcausal : ∀ n, n ≤ N → ∀ x y, P n x = P n y → P n (F x) = P n (F y))
    (q : ℝ≥0) (hq : q < 1)
    (hcontract : ∀ n, n < N → ∀ x y, P n x = P n y →
      ‖P (n+1) (F x) - P (n+1) (F y)‖ ≤ q * ‖x-y‖) :
    ∃ x, F x = x := by
  have hex : ∀ n, n ≤ N → ∃ x, P n (F x) = x ∧ P n x = x := by
    intro n
    induction n with
    | zero => exact fun _ => ⟨0,hzero _,hzero _⟩
    | succ n ih =>
      intro hn
      obtain ⟨y,hy,hPy⟩ := ih (Nat.le_of_succ_le hn)
      obtain ⟨x,hx,_⟩ := extend_prefix (P n) (P (n+1)) F
        (habsorb n (n+1) (Nat.le_succ _))
        (hcausal n (Nat.le_of_succ_le hn)) q hq
        (hcontract n (Nat.lt_of_succ_le hn)) y hy hPy
      refine ⟨x,hx,?_⟩
      rw [←hx,habsorb (n+1) (n+1) le_rfl]
  obtain ⟨x,hx,_⟩ := hex N le_rfl
  exact ⟨x,by simpa only [hfull] using hx⟩

/-- The same finite causal partition also proves uniqueness of the fixed point. -/
theorem fixed_point_unique (N : ℕ) (P : ℕ → E →L[ℝ] E) (F : E → E)
    (hzero : ∀ x, P 0 x = 0) (hfull : ∀ x, P N x = x)
    (habsorb : ∀ m n, m ≤ n → ∀ x, P m (P n x) = P m x)
    (hcausal : ∀ n, n ≤ N → ∀ x y, P n x = P n y → P n (F x) = P n (F y))
    (q : ℝ≥0) (hq : q < 1)
    (hcontract : ∀ n, n < N → ∀ x y, P n x = P n y →
      ‖P (n+1) (F x) - P (n+1) (F y)‖ ≤ q * ‖x-y‖)
    {x y : E} (hx : F x = x) (hy : F y = y) : x = y := by
  have he : ∀ n, n ≤ N → P n x = P n y := by
    intro n
    induction n with
    | zero => exact fun _ => (hzero x).trans (hzero y).symm
    | succ n ih =>
      intro hn
      have hprev : P n (P (n+1) x) = P n (P (n+1) y) := by
        rw [habsorb n (n+1) (Nat.le_succ _),habsorb n (n+1) (Nat.le_succ _)]
        exact ih (Nat.le_of_succ_le hn)
      have hx' : P (n+1) (F (P (n+1) x)) = P (n+1) x :=
        (hcausal (n+1) hn _ _ (habsorb _ _ le_rfl x)).trans (congrArg (P (n+1)) hx)
      have hy' : P (n+1) (F (P (n+1) y)) = P (n+1) y :=
        (hcausal (n+1) hn _ _ (habsorb _ _ le_rfl y)).trans (congrArg (P (n+1)) hy)
      have h := hcontract n (Nat.lt_of_succ_le hn) _ _ hprev
      rw [hx',hy'] at h
      apply sub_eq_zero.mp
      apply norm_eq_zero.mp
      have hq' : (q:ℝ) < 1 := hq
      nlinarith [norm_nonneg (P (n+1) x-P (n+1) y)]
  simpa only [hfull] using he N le_rfl

end
end ChainFountainStochastic.CausalFixedPoint
