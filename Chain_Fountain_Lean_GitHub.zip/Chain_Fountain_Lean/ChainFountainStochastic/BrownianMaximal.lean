import MathFin.Foundations.BrownianMartingale
import BrownianMotion.StochasticIntegral.DoobLp

namespace ChainFountainStochastic.BrownianMaximal
noncomputable section
open MeasureTheory ProbabilityTheory Real Filter Set
open scoped NNReal ENNReal
set_option maxHeartbeats 600000
set_option backward.isDefEq.respectTransparency true
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {P : Measure Ω}
  {X : ℝ≥0 → Ω → ℝ}

/-- The Wald exponential has expectation one at each deterministic time. -/
theorem wald_integral (hX : IsPreBrownianReal X P) (θ : ℝ) (T : ℝ≥0) :
    ∫ ω, exp (θ * X T ω - θ^2 * (T : ℝ) / 2) ∂P = 1 := by
  simp_rw [exp_sub, div_eq_mul_inv]
  rw [integral_mul_const]
  have h := (hX.hasLaw_eval T).integral_comp
    (show AEStronglyMeasurable (fun x : ℝ => exp (θ*x)) (gaussianReal 0 T) from
      (by fun_prop : Continuous (fun x : ℝ => exp (θ*x))).aestronglyMeasurable)
  change (∫ ω, exp (θ * X T ω) ∂P) * (exp (θ^2 * (T:ℝ) * 2⁻¹))⁻¹ = 1
  dsimp only [Function.comp_def] at h
  rw [h, integral_exp_mul_gaussianReal_zero]
  simp [div_eq_mul_inv, exp_ne_zero]

/-- Exponential maximal bound, obtained from the Wald martingale and Doob's
maximal inequality. This proof does not use a reflection principle. -/
theorem maximal_exponential (hX : IsPreBrownianReal X P)
    (hm : ∀ t, Measurable (X t)) (hc : ∀ ω, Continuous (X · ω))
    (T : ℝ≥0) (a θ : ℝ) (hθ : 0 ≤ θ) :
    P.real {ω | (a : EReal) ≤ ⨆ s ≤ T, (X s ω : EReal)} ≤
      exp (-θ*a + θ^2 * (T:ℝ)/2) := by
  haveI := (hX.hasLaw ∅).isProbabilityMeasure
  letI := hX.isFilteredPreBrownian hm
  let W := fun t ω => exp (θ * X t ω - θ^2 * (t:ℝ)/2)
  have hw : Martingale W (Filtration.natural X (fun t => (hm t).stronglyMeasurable)) P :=
    IsFilteredPreBrownian.waldExponential_isMartingale θ
  have hwc : ∀ ω, Continuous (W · ω) := fun ω => by dsimp [W]; fun_prop
  let ε := exp (θ*a - θ^2*(T:ℝ)/2)
  have hmax := maximal_ineq hw.submartingale
    (show 0 ≤ W from fun t ω => (exp_pos _).le) ε T
    (fun ω => (hwc ω).isRightContinuous)
  have htotal : ∫ ω, W T ω ∂P = 1 := wald_integral hX θ T
  have hbound : ε * P.real {ω | ε ≤ ⨆ s : Iic T, W s ω} ≤ 1 :=
    hmax.trans ((setIntegral_le_integral (hw.integrable T)
      (ae_of_all _ fun ω => (exp_pos _).le)).trans_eq htotal)
  have hsub : {ω | (a : EReal) ≤ ⨆ s ≤ T, (X s ω : EReal)} ⊆
      {ω | ε ≤ ⨆ s : Iic T, W s ω} := by
    intro ω hω
    obtain ⟨s, hs, hsm⟩ := isCompact_Icc.exists_isMaxOn
      (nonempty_Icc.mpr (show (0:ℝ≥0) ≤ T from bot_le)) (hc ω).continuousOn
    have ha : a ≤ X s ω := by
      apply EReal.coe_le_coe_iff.mp
      exact hω.trans (iSup_le fun (u : ℝ≥0) => iSup_le fun (hu : u ≤ T) =>
        EReal.coe_le_coe (hsm ⟨bot_le,hu⟩))
    have hb : BddAbove (range fun s : Iic T => W s ω) := by
      have he : range (fun s : Iic T => W s ω) = (W · ω) '' Icc 0 T := by
        ext y; simp only [mem_range,mem_image,mem_Icc]
        constructor
        · rintro ⟨u,rfl⟩; exact ⟨u,⟨bot_le,u.property⟩,rfl⟩
        · rintro ⟨u,hu,rfl⟩; exact ⟨⟨u,hu.2⟩,rfl⟩
      rw [he]
      exact (isCompact_Icc.image (hwc ω)).bddAbove
    apply le_trans (b := W s ω) _ (le_ciSup hb ⟨s,hs.2⟩)
    apply exp_le_exp.mpr
    have ht : (s:ℝ) ≤ T := hs.2
    nlinarith [mul_le_mul_of_nonneg_left ha hθ, sq_nonneg θ]
  have hp : ε * P.real {ω | (a:EReal) ≤ ⨆ s ≤ T, (X s ω:EReal)} ≤ 1 :=
    (mul_le_mul_of_nonneg_left (measureReal_mono hsub) (exp_pos _).le).trans hbound
  have he : 0 < ε := exp_pos _
  calc
    _ ≤ 1 / ε := (le_div_iff₀ he).mpr (by simpa [mul_comm] using hp)
    _ = _ := by rw [one_div, ← exp_neg]; congr 1; ring

/-- The sharp Gaussian exponential upper bound for a Brownian running maximum. -/
theorem maximal_gaussian (hX : IsBrownianReal X P) {T : ℝ≥0} (hT : 0 < T)
    {a : ℝ} (ha : 0 ≤ a) :
    P.real {ω | (a : EReal) ≤ ⨆ s ≤ T, (X s ω : EReal)} ≤
      exp (-(a^2)/(2*(T:ℝ))) := by
  have h := maximal_exponential hX.isBrownianReal_mk.toIsPreBrownianReal
    hX.measurable_mk hX.continuous_mk T a (a/T) (by positivity)
  have hsets : {ω | (a:EReal) ≤ ⨆ s ≤ T, (hX.toIsPreBrownianReal.mk X s ω:EReal)} =ᵐ[P]
      {ω | (a:EReal) ≤ ⨆ s ≤ T, (X s ω:EReal)} := by
    filter_upwards [hX.mk_ae_forall_eq] with ω hω
    change ((a:EReal) ≤ ⨆ s ≤ T, (hX.toIsPreBrownianReal.mk X s ω:EReal)) =
      ((a:EReal) ≤ ⨆ s ≤ T, (X s ω:EReal))
    simp only [hω]
  rw [measureReal_congr hsets] at h
  convert h using 1
  congr 1
  have ht : (T:ℝ) ≠ 0 := ne_of_gt hT
  field_simp
  <;> ring

end
end ChainFountainStochastic.BrownianMaximal
