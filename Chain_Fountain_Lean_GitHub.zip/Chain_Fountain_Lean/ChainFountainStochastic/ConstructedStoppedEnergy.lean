import ChainFountainStochastic.ConstructedEnergy
import ChainFountainStochastic.GeneralStoppedEnergy
namespace ChainFountainStochastic.ConstructedEnergy
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory MathFin ChainFountain
open MathFin.ItoIntegralL2 MathFin.ItoFormulaAdapted MathFin.AdaptedDrift
open MathFin.ItoIntegralProcessLocalMartingaleGeneral
open VectorSDE GlobalCutoffSDE MechanicalCutoff CutoffExhaustion ConullBrownian RegularRealization
open GlobalLocalization MechanicalExhaustion
open scoped NNReal Topology
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 200000


/-- A compact exhaustion level gives an explicit physical diffusion bound. -/
theorem noise_bound {ρ : ℝ} (hρ : 0 < ρ) {x : State} (hx : |gauge ρ x| ≤ 1) :
    |(x 1)^2/x 0| ≤ ρ^3 := by
  obtain ⟨hn,hh⟩ := (gauge_le_iff hρ x).mp hx
  have hheight := height_pos_of_gauge_le hρ hx
  have hv : |x 1| ≤ ρ := (norm_le_pi_norm x 1).trans hn
  have hv2 : (x 1)^2 ≤ ρ^2 := by
    simpa only [sq_abs] using (sq_le_sq₀ (abs_nonneg (x 1)) hρ.le).mpr hv
  rw [abs_of_nonneg (div_nonneg (sq_nonneg _) hheight.le),div_le_iff₀ hheight]
  have hm := mul_le_mul_of_nonneg_left hh (sq_nonneg ρ)
  nlinarith

theorem energy_continuous (a : Parameters) : Continuous (fun y : State × State => energy a y.1 y.2) := by
  unfold energy trackingEnergy errorZ
  fun_prop

theorem cutoffGenerator_continuous (a : Parameters) (p : ℝ≥0 → State)
    (hp : Continuous p) (c : Coefficients (Fin 3)) :
    Continuous (fun y : ℝ≥0 × State => cutoffGenerator a p c y.1 y.2) := by
  have hd := c.drift_continuous
  have hs := c.diffusion_continuous
  unfold cutoffGenerator errorZ
  fun_prop

/-- The Dynkin dissipation estimate for the actually constructed cutoff SDE.
No energy identity, martingale compensator, or random trajectory is supplied:
all of them are derived from its strong solution and finite-variation coordinates. -/
theorem cutoff_energy_expectation
    {Ω Ω' : Type*} [MeasurableSpace Ω] [MeasurableSpace Ω']
    {μ : Measure Ω} {ν : Measure Ω'} [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hT : 0 < T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (a : Parameters) (r : ℝ → State)
    (hp : Continuous (fun t : ℝ≥0 => r t))
    (dr : ∀ t, 0 ≤ t → HasDerivAt (fun s => r s 0) (r t 1) t)
    (dr₁ : ∀ t, 0 ≤ t → HasDerivAt (fun s => r s 1) (r t 2) t)
    (c : Coefficients (Fin 3)) (x₀ : State) {Y : ℝ≥0 → Ω → State}
    (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    {f : Ω' → Ω} (hf : MeasurableEmbedding f) (hm : MeasurePreserving f ν μ)
    (hYf : ∀ ω, Continuous (fun t => Y t (f ω)))
    (hFV : ∀ ω t,
      Y t (f ω) 0 = x₀ 0+driftPath (fun s ω => c.drift s (Y s (f ω)) 0) t ω ∧
      Y t (f ω) 2 = x₀ 2+driftPath (fun s ω => c.drift s (Y s (f ω)) 2) t ω)
    {ρ κ : ℝ} (hρ : 0 < ρ) (hi : |gauge ρ x₀| < 1)
    (hc : ∀ t x, |gauge ρ x| ≤ 1 →
      c.drift t x = a.drift (r t,x) ∧ c.diffusion t x = a.diffusion (r t,x))
    (hk₀ : 0 ≤ a.k₀) (hk₁ : 0 ≤ a.k₁) (hk₂ : 0 ≤ a.k₂) (hκd : 0 ≤ a.κd)
    (hκ₁ : κ ≤ a.k₁) (hκ₂ : κ ≤ a.k₂) (t : ℝ≥0) :
    let X := fun t ω => Y t (f ω)
    let V := fun (t : ℝ≥0) ω => energy a (r t) (X t ω)
    let τ := fun ω => min (gaugeExit X (gauge ρ) ω) (T:WithTop ℝ≥0)
    (∫ ω, stoppedProcess V τ t ω ∂ν)+
      2*κ*(∫ ω, stoppedProcess (driftPath V) τ t ω ∂ν) ≤
      energy a (r 0) x₀+(a.noise^2*(ρ^3)^2/8)*
        (∫ ω, stoppedProcess (fun (s:ℝ≥0) (_:Ω') => (s:ℝ)) τ t ω ∂ν) := by
  let X := fun t ω => Y t (f ω)
  let V := fun (t : ℝ≥0) ω => energy a (r t) (X t ω)
  let J := fun (t : ℝ≥0) ω => cutoffGenerator a (fun u => r u) c t (X t ω)
  let τ := fun ω => min (gaugeExit X (gauge ρ) ω) (T:WithTop ℝ≥0)
  change (∫ ω, stoppedProcess V τ t ω ∂ν)+2*κ*(∫ ω, stoppedProcess (driftPath V) τ t ω ∂ν) ≤ _
  let ℱ := augFiltration (μ:=ν) (fun s => (hBm s).comp hf.measurable)
  have hXa : StronglyAdapted ℱ X := fun s =>
    (adapted_pullback hBm hf.measurable (hY 0).predictable.stronglyAdapted s).mono
      (show _ ≤ ℱ s from le_sup_left)
  have hX₀ ω : X 0 ω = x₀ := (hY 0).initial (f ω)
  obtain ⟨he,hep,heb⟩ := gaugeExit_properties hXa hYf (gauge_continuous ρ) hX₀ hi
  have hτ : IsStoppingTime ℱ τ := he.min (isStoppingTime_const ℱ T)
  have hτpos ω : 0 < τ ω := lt_min (hep ω) (WithTop.coe_lt_coe.mpr hT)
  have hτT ω : τ ω ≤ (T:WithTop ℝ≥0) := min_le_right _ _
  have hin (s : ℝ≥0) ω (hs : (s:WithTop ℝ≥0) ≤ τ ω) : |gauge ρ (X s ω)| ≤ 1 := by
    have hb' := heb s ω
    rw [stoppedProcess_eq_of_le (hs.trans (min_le_left _ _))] at hb'
    exact hb'
  have hVc ω : Continuous (fun s => V s ω) :=
    (energy_continuous a).comp (hp.prodMk (hYf ω))
  have hVa : StronglyAdapted ℱ V := fun s =>
    ((energy_continuous a).comp (continuous_const.prodMk continuous_id)).comp_stronglyMeasurable (hXa s)
  have hJc ω : Continuous (fun s => J s ω) :=
    (cutoffGenerator_continuous a _ hp c).comp (continuous_id.prodMk (hYf ω))
  have hJa : StronglyAdapted ℱ J := fun s =>
    ((cutoffGenerator_continuous a _ hp c).comp (continuous_const.prodMk continuous_id)).comp_stronglyMeasurable (hXa s)
  have hV₀ ω : V 0 ω = energy a (r 0) x₀ := by dsimp [V]; rw [hX₀]
  have hcont : Continuous (fun y : ℝ≥0 × State => |energy a (r y.1) y.2|) :=
    ((energy_continuous a).comp ((hp.comp continuous_fst).prodMk continuous_snd)).abs
  obtain ⟨D,hD⟩ := ((isCompact_Icc : IsCompact (Icc (0:ℝ≥0) T)).prod (gauge_sublevel_compact hρ)).bddAbove_image hcont.continuousOn
  let CV := max 0 D
  have hCV : 0 ≤ CV := le_max_left _ _
  have hVB s (hs : s ∈ Icc 0 T) ω (hsτ : (s:WithTop ℝ≥0) ≤ τ ω) : ‖V s ω‖ ≤ CV := by
    rw [Real.norm_eq_abs]
    apply le_trans (hD (show |energy a (r s) (X s ω)| ∈ _ from
      ⟨(s,X s ω),⟨hs,hin s ω hsτ⟩,rfl⟩))
    exact le_max_right _ _
  let CJ := 2*(a.k₁+a.k₂+a.κd*(ρ^3)^2)*CV+a.noise^2*(ρ^3)^2/8
  have hCJ : 0 ≤ CJ := by dsimp [CJ]; positivity
  have hJid (s : ℝ≥0) ω (hsτ : (s:WithTop ℝ≥0) ≤ τ ω) : J s ω =
      trackingGenerator a.k₀ a.k₁ a.k₂ a.κd a.noise (X s ω 0-r s 0)
        (errorZ a (r s) (X s ω)) ((X s ω 1)^2/X s ω 0) :=
    cutoffGenerator_eq a _ c s _ (height_pos_of_gauge_le hρ (hin s ω hsτ)) (hc s _ (hin s ω hsτ))
  have hJB s (hs : s ∈ Icc 0 T) ω (hsτ : (s:WithTop ℝ≥0) ≤ τ ω) : ‖J s ω‖ ≤ CJ := by
    rw [Real.norm_eq_abs,hJid s ω hsτ]
    exact tracking_generator_abs_le hk₀ hk₁ hk₂ hκd
      ((le_abs_self _).trans ((Real.norm_eq_abs _).symm.trans_le (hVB s hs ω hsτ)))
      (noise_bound hρ (hin s ω hsτ))
  have hgen s (_ : s ∈ Icc 0 T) ω (hsτ : (s:WithTop ℝ≥0) ≤ τ ω) :
      J s ω ≤ -2*κ*V s ω+a.noise^2*(ρ^3)^2/8 := by
    rw [hJid s ω hsτ]
    exact tracking_generator_le hk₀ hκ₁ hκ₂ hκd (noise_bound hρ (hin s ω hsτ))
  obtain ⟨M,hIto,hMc,hMl⟩ := cutoff_energy_ito hB T hBm hBc a r hp dr dr₁ c x₀ hY hb hf hm hYf hFV
  exact stopped_generator_expectation hτ hτpos hτT hVa hVc hJa hJc hV₀ hCV hCJ
    hVB hJB hgen hMl hIto t

end
end ChainFountainStochastic.ConstructedEnergy
