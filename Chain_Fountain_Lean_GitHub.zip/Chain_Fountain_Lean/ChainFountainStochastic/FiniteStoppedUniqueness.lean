import ChainFountainStochastic.FiniteHorizon
import ChainFountainStochastic.StoppedUniqueness
import ChainFountainStochastic.CausalConvergence

namespace ChainFountainStochastic.FiniteStoppedUniqueness
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM
open VectorSDE VectorLp PrefixLimits StoppedUniqueness FiniteHorizon
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 900000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The actual coupled Picard iteration converges on every finite horizon,
from every predictable square-integrable initial iterate. -/
theorem picard_iterates_converge
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ)
    (X Y : ProcessLp (μ:=μ) (ι:=ι) T hBm)
    (hY : picard hB T hBm hBc c x₀ Y = Y) :
    Tendsto (fun n => (picard hB T hBm hBc c x₀)^[n] X) atTop (𝓝 Y) := by
  obtain ⟨N,P,q,hq,hzero,hfull,hab,hca,hco⟩ :=
    exists_contracting_partition hB T hBm hBc c x₀
  exact CausalConvergence.tendsto_iterate_of_causal_partition N P _ hzero hfull hab hca
    (contractionFactor c T) (picard_sub_norm_le hB T hBm hBc c x₀) q hq hco X Y hY

/-- Pathwise uniqueness before any random prefix on which the coefficient
fields agree along the comparison solution. Neither the equality of solutions
nor a stopped energy estimate is assumed. -/
theorem strong_solution_prefix_unique_all_horizons
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c d : Coefficients ι) (x₀ : ι → ℝ)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖d.diffusion t x‖ ≤ d.bound)
    {Y Z : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hZ : StrongSolution (μ:=μ) T hBm d x₀ Z)
    (τ : Ω → ℝ≥0)
    (hcoeff : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω →
      c.drift t (Z t ω) = d.drift t (Z t ω) ∧
      c.diffusion t (Z t ω) = d.diffusion t (Z t ω)) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω → Y t ω = Z t ω := by
  let f := picard hB T hBm hBc c x₀
  let Z₀ := hZ.state_memLp.toLp (Function.uncurry Z)
  let Yn (n : ℕ) := picardPath T hBm c x₀ (f^[n] Z₀)
  have hcoe (n : ℕ) : ⇑(f^[n+1] Z₀) =ᵐ[trimMeasure_T (μ:=μ) T hBm]
      Function.uncurry (Yn n) := by
    unfold Yn picardPath Function.uncurry
    simpa only [Function.iterate_succ_apply',f] using
      picard_coe hB T hBm hBc c x₀ (f^[n] Z₀)
  have he (n : ℕ) : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω → Yn n t ω = Z t ω := by
    induction n with
    | zero =>
      exact picardPath_preserves_prefix hB T hBm hBc c d x₀ hb hd hZ Z₀
        hZ.predictable hZ.continuous hZ.state_memLp.coeFn_toLp τ hcoeff
        (ae_of_all _ fun _ _ _ _ => rfl)
    | succ n ih =>
      exact picardPath_preserves_prefix hB T hBm hBc c d x₀ hb hd hZ (f^[n+1] Z₀)
        (picardPath_predictable hB T hBm hBc c x₀ _) (picardPath_continuous hB T hBm hBc c x₀ _)
        (hcoe n) τ hcoeff ih
  have hlim : Tendsto (fun n => f^[n+1] Z₀) atTop
      (𝓝 (hY.state_memLp.toLp (Function.uncurry Y))) :=
    (picard_iterates_converge hB T hBm hBc c x₀ Z₀ _
      (hY.fixed_point hB T hBm hBc c x₀)).comp (tendsto_add_atTop_nat 1)
  exact prefix_agreement_of_tendsto_Lp T hBm (fun n => f^[n+1] Z₀) _ hlim
    hcoe hY.state_memLp.coeFn_toLp hY.continuous hZ.continuous
    (fun ω => (hY.initial ω).trans (hZ.initial ω).symm) τ he


end
end ChainFountainStochastic.FiniteStoppedUniqueness
