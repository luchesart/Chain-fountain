import MathFin.Foundations.NormalTail
import MathFin.Foundations.GaussianCDFDeriv
import Mathlib.Analysis.Calculus.LHopital
import Mathlib.Analysis.Asymptotics.AsymptoticEquivalent

namespace ChainFountainStochastic.GaussianTail
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin Asymptotics
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 600000

/-- The normal density divided by the positive threshold tends to zero. -/
theorem density_div_tendsto_zero :
    Tendsto (fun x : ℝ => gaussianPDFReal 0 1 x / x) atTop (𝓝 0) := by
  apply squeeze_zero'
    (eventually_gt_atTop 0 |>.mono fun x hx => div_nonneg (gaussianPDFReal_nonneg _ _ _) hx.le)
    (eventually_gt_atTop 0 |>.mono fun x hx =>
      div_le_div_of_nonneg_right (gaussianPDFReal_zero_one_le_one x) hx.le)
  simpa only [one_div] using (tendsto_inv_atTop_zero : Tendsto (fun x : ℝ => x⁻¹) atTop (𝓝 0))

/-- The correctly normalized Mills asymptotic, derived from the derivatives of
the normal density and CDF using L'Hopital's rule. -/
theorem tail_ratio_tendsto_one :
    Tendsto (fun x : ℝ => (1 - Phi x) / (gaussianPDFReal 0 1 x / x)) atTop (𝓝 1) := by
  have hf : ∀ᶠ x : ℝ in atTop,
      HasDerivAt (fun x => 1 - Phi x) (-gaussianPDFReal 0 1 x) x :=
    Eventually.of_forall fun x => by simpa using (hasDerivAt_Phi x).const_sub 1
  have hg : ∀ᶠ x : ℝ in atTop,
      HasDerivAt (fun x => gaussianPDFReal 0 1 x / x)
        (-(1 + (x⁻¹)^2) * gaussianPDFReal 0 1 x) x := by
    filter_upwards [eventually_gt_atTop (0:ℝ)] with x hx
    convert (hasDerivAt_gaussianPDFReal_zero_one x).div (hasDerivAt_id x) hx.ne' using 1 <;> (try simp only [id_eq]) <;>
      (first | rfl | (field_simp [hx.ne']; ring))
  have hgn : ∀ᶠ x : ℝ in atTop,
      -(1 + (x⁻¹)^2) * gaussianPDFReal 0 1 x ≠ 0 :=
    Eventually.of_forall fun x => mul_ne_zero (neg_ne_zero.mpr (by positivity))
      (gaussianPDFReal_pos 0 1 x (by norm_num)).ne'
  have hf0 : Tendsto (fun x : ℝ => 1 - Phi x) atTop (𝓝 0) := by
    simpa using (tendsto_const_nhds : Tendsto (fun _ : ℝ => (1:ℝ)) atTop (𝓝 1)).sub tendsto_Phi_atTop
  have hratio : Tendsto
      (fun x : ℝ => (-gaussianPDFReal 0 1 x) /
        (-(1 + (x⁻¹)^2) * gaussianPDFReal 0 1 x)) atTop (𝓝 1) := by
    have h := (tendsto_const_nhds : Tendsto (fun _ : ℝ => (1:ℝ)) atTop (𝓝 1)).div
      (tendsto_const_nhds.add ((tendsto_inv_atTop_zero :
        Tendsto (fun x : ℝ => x⁻¹) atTop (𝓝 0)).pow 2)) (by norm_num : (1:ℝ) + 0^2 ≠ 0)
    convert h using 1
    · ext x
      have hp := (gaussianPDFReal_pos 0 1 x (by norm_num)).ne'
      rw [Pi.div_apply,neg_mul,neg_div_neg_eq,div_mul_eq_div_div_swap,div_self hp]
    · norm_num
  exact HasDerivAt.lhopital_zero_atTop hf hg hgn hf0 density_div_tendsto_zero hratio

/-- Equivalent form of the Gaussian upper-tail asymptotic. -/
theorem tail_isEquivalent_density_div :
    (fun x : ℝ => 1 - Phi x) ~[atTop] (fun x => gaussianPDFReal 0 1 x / x) :=
  isEquivalent_of_tendsto_one tail_ratio_tendsto_one

/-- The result applies to the probability of a standard normal upper tail. -/
theorem gaussianReal_tail_isEquivalent :
    (fun x : ℝ => (gaussianReal 0 1).real (Ioi x)) ~[atTop]
      (fun x => gaussianPDFReal 0 1 x / x) := by
  simpa only [Measure.real,gaussianReal_Ioi_toReal,Phi_neg] using tail_isEquivalent_density_div

/-- Explicit normalization: the leading constant is `1 / sqrt (2*pi)`. -/
theorem gaussianReal_tail_isEquivalent_exp :
    (fun x : ℝ => (gaussianReal 0 1).real (Ioi x)) ~[atTop]
      (fun x => Real.exp (-(x^2) / 2) / (Real.sqrt (2 * Real.pi) * x)) := by
  convert gaussianReal_tail_isEquivalent using 1
  ext x
  simp only [gaussianPDFReal_def,NNReal.coe_one,mul_one,sub_zero]
  ring

end
end ChainFountainStochastic.GaussianTail
