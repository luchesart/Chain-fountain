import ChainFountainStochastic.FiniteStoppedUniqueness
import ChainFountainStochastic.CutoffCompatibility

namespace ChainFountainStochastic.FiniteCutoffCompatibility
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralProcessLocalMartingaleGeneral
open VectorSDE MechanicalCutoff ConstructedExit CutoffCompatibility
open FiniteStoppedUniqueness FiniteHorizon
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 900000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}

/-- Before the norm-ball exit of a continuous version, two bounded-diffusion
strong solutions agree whenever their fields agree on that ball. -/
theorem strong_solutions_agree_before_normExit_all_horizons
    [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c d : Coefficients (Fin 3)) (x₀ : State)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖d.diffusion t x‖ ≤ d.bound)
    {Y Z XZ : ℝ≥0 → Ω → State}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hZ : StrongSolution (μ:=μ) T hBm d x₀ Z)
    {R : ℝ}
    (hstop : ∀ t ω, stoppedProcess XZ (normExit XZ x₀ R T) t ω ∈ Metric.closedBall x₀ R)
    (hXZ : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, XZ t ω = Z t ω)
    (hcoeff : ∀ t x, x ∈ Metric.closedBall x₀ R →
      c.drift t x = d.drift t x ∧ c.diffusion t x = d.diffusion t x) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ normExit XZ x₀ R T ω → Y t ω = Z t ω := by
  have hcap (ω : Ω) : normExit XZ x₀ R T ω ≤ T := min_le_right _ _
  have hfin (ω : Ω) : normExit XZ x₀ R T ω ≠ ⊤ :=
    ne_of_lt ((hcap ω).trans_lt (WithTop.coe_lt_top T))
  let τ := fun ω => (normExit XZ x₀ R T ω).untopA
  have hτ (ω : Ω) : (τ ω:WithTop ℝ≥0) = normExit XZ x₀ R T ω := by
    dsimp [τ]
    rw [WithTop.untopA_eq_untop (hfin ω)]
    exact WithTop.coe_untop _ _
  have hm := original_state_mem_before_exit hcap hstop hXZ
  have he := strong_solution_prefix_unique_all_horizons hB T hBm hBc c d x₀ hb hd hY hZ τ
    (by
      filter_upwards [hm] with ω hω
      intro t ht hle
      exact hcoeff t (Z t ω) (hω t (hτ ω ▸ WithTop.coe_le_coe.mpr hle)))
  filter_upwards [he] with ω hω
  intro t ht
  exact hω t ⟨zero_le,WithTop.coe_le_coe.mp (ht.trans (hcap ω))⟩
    (WithTop.coe_le_coe.mp ((hτ ω).symm ▸ ht))

/-- Arbitrary-finite-horizon cutoff compatibility includes equality of the actual random exits
and indistinguishability of the stopped continuous versions. -/
theorem continuous_versions_stopped_eq_all_horizons
    [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hT : 0 < T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c d : Coefficients (Fin 3)) (x₀ : State)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖d.diffusion t x‖ ≤ d.bound)
    {Y Z XY XZ : ℝ≥0 → Ω → State}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hZ : StrongSolution (μ:=μ) T hBm d x₀ Z)
    (hXYa : StronglyAdapted (augFiltration (μ:=μ) hBm) XY)
    (hXZa : StronglyAdapted (augFiltration (μ:=μ) hBm) XZ)
    (hXYc : ∀ ω, Continuous (fun t => XY t ω))
    (hXZc : ∀ ω, Continuous (fun t => XZ t ω))
    (hXY₀ : ∀ ω, XY 0 ω = x₀) (hXZ₀ : ∀ ω, XZ 0 ω = x₀)
    (hXY : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, XY t ω = Y t ω)
    (hXZ : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, XZ t ω = Z t ω)
    (R : ℝ) (hR : 0 < R)
    (hcoeff : ∀ t x, x ∈ Metric.closedBall x₀ R →
      c.drift t x = d.drift t x ∧ c.diffusion t x = d.diffusion t x) :
    ∀ᵐ ω ∂μ, normExit XY x₀ R T ω = normExit XZ x₀ R T ω ∧
      ∀ t, stoppedProcess XY (normExit XY x₀ R T) t ω =
        stoppedProcess XZ (normExit XZ x₀ R T) t ω := by
  obtain ⟨_,_,hcapZ,hstopZ⟩ := normExit_properties hXZa hXZc hXZ₀ hR hT
  have he := strong_solutions_agree_before_normExit_all_horizons hB T hBm hBc c d x₀ hb hd
    hY hZ hstopZ hXZ hcoeff
  filter_upwards [he,hXY,hXZ] with ω he hXY hXZ
  have heXZ (t : ℝ≥0) (ht : (t:WithTop ℝ≥0) ≤ normExit XZ x₀ R T ω) : XY t ω = XZ t ω := by
    have htT : t ∈ Icc 0 T := ⟨zero_le,WithTop.coe_le_coe.mp (ht.trans (hcapZ ω))⟩
    exact (hXY t htT).trans ((he t ht).trans (hXZ t htT).symm)
  have hτ := normExit_eq_of_prefix_eq hXYc hXZc hR ω
    (fun t _ ht => heXZ t (ht.trans (min_le_right _ _)))
  refine ⟨hτ,?_⟩
  intro t
  change XY (min (t:WithTop ℝ≥0) (normExit XY x₀ R T ω)).untopA ω =
    XZ (min (t:WithTop ℝ≥0) (normExit XZ x₀ R T ω)).untopA ω
  rw [hτ]
  apply heXZ
  rw [coe_untopA_min]
  exact min_le_right _ _

/-- Two actual mechanical cutoff constructions on different positive-height
boxes give the same stopped trajectory in every common ball, on a constructed
arbitrary prescribed positive horizon. All solutions and stopping times are conclusions. -/
theorem exists_compatible_mechanical_cutoff_solutions_all_horizons
    [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hT : 0 < T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (a : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi lo₁ hi₁ lo₂ hi₂ : State)
    (hlo₁ : lo₁ ≤ hi₁) (hh₁ : 0 < lo₁ 0)
    (hlo₂ : lo₂ ≤ hi₂) (hh₂ : 0 < lo₂ 0)
    (hpmem : ∀ t, p t ∈ Icc plo phi) (x₀ : State)
    (R : ℝ) (hR : 0 < R)
    (hball₁ : Metric.closedBall x₀ R ⊆ Icc lo₁ hi₁)
    (hball₂ : Metric.closedBall x₀ R ⊆ Icc lo₂ hi₂) :
    ∃ c d : Coefficients (Fin 3),
      (∀ t x, x ∈ Icc lo₁ hi₁ → c.drift t x = a.drift (p t,x) ∧
        c.diffusion t x = a.diffusion (p t,x)) ∧
      (∀ t x, x ∈ Icc lo₂ hi₂ → d.drift t x = a.drift (p t,x) ∧
        d.diffusion t x = a.diffusion (p t,x)) ∧
      ∃ Y Z XY XZ : ℝ≥0 → Ω → State,
        StrongSolution (μ:=μ) T hBm c x₀ Y ∧
        StrongSolution (μ:=μ) T hBm d x₀ Z ∧
        StronglyAdapted (augFiltration (μ:=μ) hBm) XY ∧
        StronglyAdapted (augFiltration (μ:=μ) hBm) XZ ∧
        (∀ ω, Continuous (fun t => XY t ω)) ∧
        (∀ ω, Continuous (fun t => XZ t ω)) ∧
        (∀ ω, XY 0 ω = x₀ ∧ XZ 0 ω = x₀) ∧
        (∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, XY t ω = Y t ω ∧ XZ t ω = Z t ω) ∧
        IsStoppingTime (augFiltration (μ:=μ) hBm) (normExit XY x₀ R T) ∧
        IsStoppingTime (augFiltration (μ:=μ) hBm) (normExit XZ x₀ R T) ∧
        (∀ ω, ⊥ < normExit XY x₀ R T ω ∧ ⊥ < normExit XZ x₀ R T ω) ∧
        (∀ᵐ ω ∂μ, normExit XY x₀ R T ω = normExit XZ x₀ R T ω ∧
          ∀ t, stoppedProcess XY (normExit XY x₀ R T) t ω =
            stoppedProcess XZ (normExit XZ x₀ R T) t ω) := by
  obtain ⟨c,_,_,hcb,hcσ,hcbd⟩ := a.exists_cutoff p hp plo phi lo₁ hi₁ hlo₁ hh₁ hpmem
  obtain ⟨d,_,_,hdb,hdσ,hdbd⟩ := a.exists_cutoff p hp plo phi lo₂ hi₂ hlo₂ hh₂ hpmem
  obtain ⟨Y,hY⟩ := exists_strong_solution_all_horizons hB T hBm hBc c x₀
  obtain ⟨Z,hZ⟩ := exists_strong_solution_all_horizons hB T hBm hBc d x₀
  obtain ⟨XY,hXYa,hXYc,hXY₀,hXY⟩ := exists_continuous_adapted_version
    hY.predictable.stronglyAdapted hY.continuous hY.initial
  obtain ⟨XZ,hXZa,hXZc,hXZ₀,hXZ⟩ := exists_continuous_adapted_version
    hZ.predictable.stronglyAdapted hZ.continuous hZ.initial
  obtain ⟨hτY,hposY,_,_⟩ := normExit_properties hXYa hXYc hXY₀ hR hT
  obtain ⟨hτZ,hposZ,_,_⟩ := normExit_properties hXZa hXZc hXZ₀ hR hT
  refine ⟨c,d,(fun t x hx => ⟨hcb t x hx,hcσ t x hx⟩),
    (fun t x hx => ⟨hdb t x hx,hdσ t x hx⟩),Y,Z,XY,XZ,hY,hZ,
    hXYa,hXZa,hXYc,hXZc,(fun ω => ⟨hXY₀ ω,hXZ₀ ω⟩),?_,hτY,hτZ,
    (fun ω => ⟨hposY ω,hposZ ω⟩),?_⟩
  · filter_upwards [hXY,hXZ] with ω hy hz
    exact fun t ht => ⟨hy t ht,hz t ht⟩
  · apply continuous_versions_stopped_eq_all_horizons hB T hT hBm hBc c d x₀
      (fun t x => (hcbd t x).2) (fun t x => (hdbd t x).2)
      hY hZ hXYa hXZa hXYc hXZc hXY₀ hXZ₀ hXY hXZ R hR
    intro t x hx
    exact ⟨(hcb t x (hball₁ hx)).trans (hdb t x (hball₂ hx)).symm,
      (hcσ t x (hball₁ hx)).trans (hdσ t x (hball₂ hx)).symm⟩


end
end ChainFountainStochastic.FiniteCutoffCompatibility
