/-
The change-of-variables proof is adapted verbatim from MathFin, GyongyMimicry.lean,
commit 61d945b970561fcce6996fac0a5f18a424eb851f.
Copyright (c) 2026 Yang Ye. All rights reserved.
Released under Apache 2.0 license as described in LICENSE.
-/
module
public import MathFin.Foundations.ItoIntegralL2
@[expose] public section
namespace ChainFountainStochastic
noncomputable section
open Set Filter MeasureTheory MathFin MathFin.ItoIntegralL2
open scoped NNReal Topology

theorem timeMeasure_Ioc_eq_interval {g : ℝ≥0 → ℝ} (T : ℝ≥0) :
    ∫ s in Set.Ioc (0:ℝ≥0) T, g s ∂ItoIntegralL2.timeMeasure
      = ∫ x in (0)..(T:ℝ), g (Real.toNNReal x) := by
  have himg : ((↑) : ℝ≥0 → ℝ) '' Set.Ioc (0:ℝ≥0) T = Set.Ioc (0:ℝ) (T:ℝ) := by
    ext x
    simp only [Set.mem_image, Set.mem_Ioc]
    constructor
    · rintro ⟨y, ⟨hy1, hy2⟩, rfl⟩
      exact ⟨by exact_mod_cast hy1, by exact_mod_cast hy2⟩
    · rintro ⟨hx1, hx2⟩
      have hy : (Real.toNNReal x : ℝ) = x := Real.coe_toNNReal x hx1.le
      have hle : (Real.toNNReal x : ℝ) ≤ (T:ℝ) := by rw [hy]; exact hx2
      exact ⟨Real.toNNReal x, Set.mem_Ioc.2 ⟨Real.toNNReal_pos.2 hx1,
        NNReal.coe_le_coe.mp hle⟩, hy⟩
  have hrng : ((↑) : ℝ≥0 → ℝ) '' Set.Ioc (0:ℝ≥0) T ⊆ Set.range ((↑) : ℝ≥0 → ℝ) :=
    Set.image_subset_range _ _
  have hmap : MeasureTheory.Measure.map ((↑) : ℝ≥0 → ℝ)
      (ItoIntegralL2.timeMeasure.restrict (Set.Ioc (0:ℝ≥0) T))
      = MeasureTheory.volume.restrict (((↑) : ℝ≥0 → ℝ) '' Set.Ioc (0:ℝ≥0) T) := by
    rw [ItoIntegralL2.timeMeasure,
      MeasurableEmbedding.restrict_comap measurableEmbedding_nnrealCoe,
      MeasurableEmbedding.map_comap measurableEmbedding_nnrealCoe,
      Measure.restrict_restrict measurableEmbedding_nnrealCoe.measurableSet_range,
      Set.inter_eq_right.2 hrng]
  calc ∫ s in Set.Ioc (0:ℝ≥0) T, g s ∂ItoIntegralL2.timeMeasure
      = ∫ x, g (Real.toNNReal (↑x)) ∂(ItoIntegralL2.timeMeasure.restrict (Set.Ioc (0:ℝ≥0) T)) :=
        MeasureTheory.integral_congr_ae (Eventually.of_forall fun x => by
          simp only [Real.toNNReal_coe])
    _ = ∫ y, g (Real.toNNReal y) ∂(MeasureTheory.Measure.map ((↑) : ℝ≥0 → ℝ)
          (ItoIntegralL2.timeMeasure.restrict (Set.Ioc (0:ℝ≥0) T))) :=
          (measurableEmbedding_nnrealCoe.integral_map
            (fun y : ℝ => g (Real.toNNReal y))).symm
    _ = ∫ y, g (Real.toNNReal y) ∂(MeasureTheory.volume.restrict
          (((↑) : ℝ≥0 → ℝ) '' Set.Ioc (0:ℝ≥0) T)) := by rw [hmap]
    _ = ∫ x in ((↑) : ℝ≥0 → ℝ) '' Set.Ioc (0:ℝ≥0) T, g (Real.toNNReal x) ∂volume := rfl
    _ = ∫ x in Set.Ioc (0:ℝ) (T:ℝ), g (Real.toNNReal x) ∂volume := by rw [himg]
    _ = ∫ x in (0)..(T:ℝ), g (Real.toNNReal x) ∂volume :=
        (intervalIntegral.integral_of_le (NNReal.coe_nonneg T)).symm


/-- Ordinary FTC for the finite-variation height-error energy, expressed in
exactly the time measure used by the Brownian stochastic integral. -/
theorem finite_variation_energy {e e' : ℝ → ℝ} {k : ℝ} {T : ℝ≥0}
    (hd : ∀ t∈Icc (0:ℝ) T, HasDerivAt e (e' t) t)
    (hc : ContinuousOn e' (Icc (0:ℝ) T)) :
    k*(e T)^2/2 = k*(e 0)^2/2 + ∫ s in Ioc (0:ℝ≥0) T, k*e s*e' s ∂timeMeasure := by
  have he : ContinuousOn e (Icc (0:ℝ) T) := fun t ht => (hd t ht).continuousAt.continuousWithinAt
  have hD (t : ℝ) (ht : t∈Icc (0:ℝ) T) :
      HasDerivAt (fun s => k*(e s)^2/2) (k*e t*e' t) t := by
    convert! (((hd t ht).pow 2).const_mul k).div_const 2 using 1 <;> ring
  have hI : IntervalIntegrable (fun s => k*e s*e' s) volume 0 T :=
    ((continuousOn_const.mul he).mul hc).intervalIntegrable_of_Icc T.coe_nonneg
  have hFTC := intervalIntegral.integral_eq_sub_of_hasDerivAt
    (fun t ht => hD t (by simpa [uIcc_of_le T.coe_nonneg] using ht)) hI
  rw [timeMeasure_Ioc_eq_interval]
  have hi : (∫ t in (0:ℝ)..(T:ℝ), k*e (Real.toNNReal t)*e' (Real.toNNReal t))=
      ∫ t in (0:ℝ)..(T:ℝ), k*e t*e' t := by
    apply intervalIntegral.integral_congr
    intro t ht
    rw [uIcc_of_le T.coe_nonneg] at ht
    simp [Real.coe_toNNReal t ht.1]
  rw [hi,hFTC]
  ring

end
end ChainFountainStochastic
