module
public import MathFin.Foundations.ExitTime
public import MathFin.Foundations.StoppedProcessPaths
public import Mathlib.Analysis.Normed.Module.FiniteDimension
@[expose] public section
namespace ChainFountainStochastic
noncomputable section
open Set Filter MeasureTheory MathFin
open scoped NNReal Topology

/-- The normalized distance from the deterministic initial mechanical state. -/
def physicalGauge {Ω : Type*} (X : ℝ≥0 → Ω → ℝ × (ℝ × ℝ))
    (x₀ : ℝ × (ℝ × ℝ)) (R : ℝ) (t : ℝ≥0) (ω : Ω) := ‖X t ω-x₀‖/R

/-- First exit from the open mechanical ball, capped by a deterministic horizon.
Choosing the closed ball inside the regular physical domain gives physical localization. -/
def physicalExit {Ω : Type*} (X : ℝ≥0 → Ω → ℝ × (ℝ × ℝ))
    (x₀ : ℝ × (ℝ × ℝ)) (R : ℝ) (T : ℝ≥0) (ω : Ω) : WithTop ℝ≥0 :=
  min (exitTime (physicalGauge X x₀ R) 1 ω) T

/-- The actual physical first exit is a positive bounded stopping time, and
continuity keeps the stopped mechanical state in the closed localization ball. -/
theorem physical_exit_properties
    {Ω : Type*} [MeasurableSpace Ω] {ℱ : Filtration ℝ≥0 ‹MeasurableSpace Ω›}
    {X : ℝ≥0 → Ω → ℝ × (ℝ × ℝ)} {x₀ : ℝ × (ℝ × ℝ)} {R : ℝ} {T : ℝ≥0}
    (hX : StronglyAdapted ℱ X) (hXc : ∀ ω, Continuous (fun t => X t ω))
    (hX₀ : ∀ ω, X 0 ω=x₀) (hR : 0<R) (hT : 0<T) :
    IsStoppingTime ℱ (physicalExit X x₀ R T) ∧
    (∀ ω, ⊥<physicalExit X x₀ R T ω) ∧
    (∀ ω, physicalExit X x₀ R T ω≤ T) ∧
    (∀ t ω, stoppedProcess X (physicalExit X x₀ R T) t ω∈Metric.closedBall x₀ R) := by
  have hGc : ∀ ω, Continuous (fun t => physicalGauge X x₀ R t ω) :=
    fun ω => (((hXc ω).sub continuous_const).norm).div_const R
  have hGm : ∀ t, Measurable[ℱ t] (physicalGauge X x₀ R t) :=
    fun t => (((hX t).sub stronglyMeasurable_const).norm.div stronglyMeasurable_const).measurable
  have hτ := isStoppingTime_exitTime_of_measurable hGm hGc 1
  have hpos (ω : Ω) : ⊥<exitTime (physicalGauge X x₀ R) 1 ω := by
    apply lt_of_not_ge
    intro hn
    obtain ⟨s,hs,hg⟩ := (exitTime_le_iff hGc 1 0 ω).mp hn
    have hs0 : s=0 := le_antisymm hs.2 zero_le
    norm_num [hs0,physicalGauge,hX₀] at hg
  refine ⟨hτ.min (isStoppingTime_const ℱ T),?_,fun _ => min_le_right _ _,?_⟩
  · intro ω
    exact lt_min (hpos ω) (by change ((0:ℝ≥0):WithTop ℝ≥0)<(T:WithTop ℝ≥0); exact WithTop.coe_lt_coe.mpr hT)
  · intro t ω
    have hb := abs_le_of_le_exitTime hGc (hpos ω)
      (s:=(min (t:WithTop ℝ≥0) (physicalExit X x₀ R T ω)).untopA)
      (by rw [coe_untopA_min]; exact (min_le_right _ _).trans (min_le_left _ _))
    have hq := (le_abs_self _).trans hb
    rw [physicalGauge] at hq
    have hn := (div_le_iff₀ hR).mp hq
    simpa only [Nat.cast_one,one_mul,Metric.mem_closedBall,dist_eq_norm,stoppedProcess] using hn

/-- Before the deterministic cap, the stopping event is exactly the event
that the mechanical path has reached the boundary or exterior of the ball. -/
theorem physical_exit_le_iff
    {Ω : Type*} {X : ℝ≥0 → Ω → ℝ × (ℝ × ℝ)} {x₀ : ℝ × (ℝ × ℝ)} {R : ℝ}
    (hXc : ∀ ω, Continuous (fun t => X t ω)) (hR : 0<R)
    {T t : ℝ≥0} (ht : t<T) (ω : Ω) :
    physicalExit X x₀ R T ω≤ t ↔ ∃ s∈Icc 0 t, R≤ dist (X s ω) x₀ := by
  have hGc : ∀ ω, Continuous (fun t => physicalGauge X x₀ R t ω) :=
    fun ω => (((hXc ω).sub continuous_const).norm).div_const R
  have hnot : ¬(T:WithTop ℝ≥0)≤ t := by exact_mod_cast not_le.mpr ht
  rw [physicalExit,min_le_iff,or_iff_left hnot,exitTime_le_iff hGc]
  congr! 2 with s
  rw [physicalGauge,abs_of_nonneg (div_nonneg (norm_nonneg _) hR.le),le_div_iff₀ hR]
  simp only [Nat.cast_one,one_mul,dist_eq_norm]

/-- Interior physical states of the reduced model, with a strict crown margin. -/
def physicalDomain (vmin : ℝ) : Set (ℝ×(ℝ×ℝ)) :=
  {x | 0<x.1 ∧ 0<x.2.1 ∧ 0<x.2.2 ∧ vmin<(x.2.1+x.2.2)/2}

theorem physicalDomain_isOpen (vmin : ℝ) : IsOpen (physicalDomain vmin) := by
  exact (isOpen_lt continuous_const continuous_fst).inter
    ((isOpen_lt continuous_const (continuous_fst.comp continuous_snd)).inter
      ((isOpen_lt continuous_const (continuous_snd.comp continuous_snd)).inter
        (isOpen_lt continuous_const
          (((continuous_fst.comp continuous_snd).add (continuous_snd.comp continuous_snd)).div_const 2))))

/-- Every strictly physical initial state has a compact localization ball
entirely inside the physical domain. -/
theorem exists_physical_localization_ball {x₀ : ℝ×(ℝ×ℝ)} {vmin : ℝ}
    (hx₀ : x₀∈physicalDomain vmin) :
    ∃ R : ℝ, 0<R ∧ IsCompact (Metric.closedBall x₀ R) ∧
      Metric.closedBall x₀ R⊆physicalDomain vmin := by
  obtain ⟨ε,hε,hsub⟩ := Metric.mem_nhds_iff.mp ((physicalDomain_isOpen vmin).mem_nhds hx₀)
  exact ⟨ε/2,half_pos hε,isCompact_closedBall x₀ (ε/2),
    (Metric.closedBall_subset_ball (half_lt_self hε)).trans hsub⟩

/-- Actual physical-domain safety up to the constructed first exit. -/
theorem stopped_state_physical
    {Ω : Type*} [MeasurableSpace Ω] {ℱ : Filtration ℝ≥0 ‹MeasurableSpace Ω›}
    {X : ℝ≥0 → Ω → ℝ×(ℝ×ℝ)} {x₀ : ℝ×(ℝ×ℝ)} {R vmin : ℝ} {T : ℝ≥0}
    (hX : StronglyAdapted ℱ X) (hXc : ∀ ω, Continuous (fun t => X t ω))
    (hX₀ : ∀ ω, X 0 ω=x₀) (hR : 0<R) (hT : 0<T)
    (hball : Metric.closedBall x₀ R⊆physicalDomain vmin) :
    ∀ t ω, stoppedProcess X (physicalExit X x₀ R T) t ω∈physicalDomain vmin := by
  intro t ω
  exact hball ((physical_exit_properties hX hXc hX₀ hR hT).2.2.2 t ω)

end
end ChainFountainStochastic
