module
public import ChainFountainStochastic.Localization
public import ChainFountainStochastic.PhysicalExit
public import Mathlib.MeasureTheory.Integral.Prod
@[expose] public section
namespace ChainFountainStochastic
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory MathFin
open MathFin.ItoIntegralL2 MathFin.AdaptedDrift
open scoped NNReal Topology

/-- Time integrals of continuous adapted rates are adapted, without a global
bound on the rate. Progressive measurability supplies the parameter integral. -/
theorem continuous_drift_adapted
    {Ω : Type*} [MeasurableSpace Ω] {ℱ : Filtration ℝ≥0 ‹MeasurableSpace Ω›}
    {b : ℝ≥0 → Ω → ℝ} (hb : StronglyAdapted ℱ b)
    (hbc : ∀ ω, Continuous (fun t => b t ω)) : StronglyAdapted ℱ (driftPath b) := by
  have hp := hb.isStronglyProgressive_of_continuous hbc
  intro t
  letI : MeasurableSpace Ω := ℱ t
  let clip : ℝ≥0 × Ω → Iic t × Ω := fun p => (⟨min p.1 t,by exact min_le_right p.1 t⟩,p.2)
  have hclip : Measurable clip :=
    ((measurable_fst.min measurable_const).subtype_mk).prodMk measurable_snd
  have hm : StronglyMeasurable (fun p : ℝ≥0 × Ω => b (min p.1 t) p.2) :=
    (hp t).comp_measurable hclip
  have hi : StronglyMeasurable (fun ω => ∫ s in Ioc 0 t, b (min s t) ω ∂timeMeasure) :=
    hm.integral_prod_left
  convert! hi using 1
  funext ω
  apply setIntegral_congr_fun measurableSet_Ioc
  intro s hs
  simp only [min_eq_left hs.2]

/-- Path continuity of the time primitive needs only local integrability,
which follows from continuity of its rate. -/
theorem continuous_drift_paths
    {Ω : Type*} {b : ℝ≥0 → Ω → ℝ}
    (hbc : ∀ ω, Continuous (fun t => b t ω)) (ω : Ω) :
    Continuous (fun t => driftPath b t ω) := by
  have hc := (hbc ω).comp continuous_real_toNNReal
  have hP := (intervalIntegral.differentiable_integral_of_continuous (a:=0) hc).continuous
  have hPN := hP.comp NNReal.continuous_coe
  apply hPN.congr
  intro t
  exact (timeMeasure_Ioc_eq_interval (g:=fun s => b s ω) t).symm

/-- A bound on a finite prefix suffices to bound its time integral. -/
theorem drift_prefix_bound {Ω : Type*} {b : ℝ≥0 → Ω → ℝ} {C : ℝ}
    (u : ℝ≥0) (ω : Ω) (hb : ∀ s∈Icc 0 u, |b s ω|≤ C) :
    |driftPath b u ω|≤ C*u := by
  rw [driftPath,←Real.norm_eq_abs]
  refine (norm_setIntegral_le_of_norm_le_const
    (by rw [timeMeasure_Ioc]; exact ENNReal.ofReal_lt_top)
    (fun s hs => (Real.norm_eq_abs _).trans_le (hb s (Ioc_subset_Icc_self hs)))).trans_eq ?_
  simp only [measureReal_def,timeMeasure_Ioc,NNReal.coe_zero,sub_zero,
    ENNReal.toReal_ofReal u.coe_nonneg]

/-- The integrated generator inequality on a finite prefix. -/
theorem drift_dissipation_prefix {Ω : Type*} {V J : ℝ≥0 → Ω → ℝ} {κ C : ℝ}
    (hVc : ∀ ω, Continuous (fun t => V t ω))
    (hJc : ∀ ω, Continuous (fun t => J t ω)) (u : ℝ≥0) (ω : Ω)
    (hgen : ∀ s∈Icc 0 u, J s ω≤ -2*κ*V s ω+C) :
    driftPath J u ω+2*κ*driftPath V u ω≤ C*u := by
  have hVi : IntegrableOn (fun s => V s ω) (Ioc 0 u) timeMeasure :=
    ((hVc ω).continuousOn.integrableOn_compact isCompact_Icc).mono_set Ioc_subset_Icc_self
  have hJi : IntegrableOn (fun s => J s ω) (Ioc 0 u) timeMeasure :=
    ((hJc ω).continuousOn.integrableOn_compact isCompact_Icc).mono_set Ioc_subset_Icc_self
  letI : IsFiniteMeasure (timeMeasure.restrict (Ioc 0 u)) :=
    ⟨by rw [Measure.restrict_apply_univ,timeMeasure_Ioc]; exact ENNReal.ofReal_lt_top⟩
  have hle := integral_mono_ae (hJi.add (hVi.const_mul (2*κ)))
    (integrable_const C) (by
      filter_upwards [ae_restrict_mem measurableSet_Ioc] with s hs
      have h := hgen s (Ioc_subset_Icc_self hs)
      change J s ω+2*κ*V s ω≤ C
      linarith)
  simp only [Pi.add_apply] at hle
  rw [integral_add hJi (hVi.const_mul (2*κ)),integral_const_mul,integral_const] at hle
  simpa only [driftPath,smul_eq_mul,Measure.restrict_apply_univ,measureReal_def,timeMeasure_Ioc,NNReal.coe_zero,
    sub_zero,ENNReal.toReal_ofReal u.coe_nonneg,mul_comm] using hle

/-- Dynkin's dissipation estimate assembled with the actual first physical
exit. Adaptedness, path continuity, integrability, martingale promotion, and
the integrated generator inequality are proved here, not assumed. -/
theorem physical_stopped_generator_expectation
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {ℱ : Filtration ℝ≥0 ‹MeasurableSpace Ω›}
    {X : ℝ≥0 → Ω → ℝ × (ℝ × ℝ)} {x₀ : ℝ × (ℝ × ℝ)} {R : ℝ} {T : ℝ≥0}
    (hX : StronglyAdapted ℱ X) (hXc : ∀ ω, Continuous (fun t => X t ω))
    (hX₀ : ∀ ω, X 0 ω=x₀) (hR : 0<R) (hT : 0<T)
    {V J M : ℝ≥0 → Ω → ℝ} {V₀ κ C CV CJ : ℝ}
    (hV : StronglyAdapted ℱ V) (hVc : ∀ ω, Continuous (fun t => V t ω))
    (hJ : StronglyAdapted ℱ J) (hJc : ∀ ω, Continuous (fun t => J t ω))
    (hV₀ : ∀ ω, V 0 ω=V₀) (hCV : 0≤ CV) (hCJ : 0≤ CJ)
    (hVB : ∀ t∈Icc 0 T, ∀ ω, X t ω∈Metric.closedBall x₀ R → ‖V t ω‖≤ CV)
    (hJB : ∀ t∈Icc 0 T, ∀ ω, X t ω∈Metric.closedBall x₀ R → ‖J t ω‖≤ CJ)
    (hgen : ∀ t∈Icc 0 T, ∀ ω, X t ω∈Metric.closedBall x₀ R → J t ω≤ -2*κ*V t ω+C)
    (hM : IsLocalMartingale M ℱ μ)
    (hIto : ∀ᵐ ω ∂μ, ∀ t∈Icc 0 T, V t ω=V₀+driftPath J t ω+M t ω)
    (t : ℝ≥0) :
    (∫ ω, stoppedProcess V (physicalExit X x₀ R T) t ω ∂μ)+
        2*κ*(∫ ω, stoppedProcess (driftPath V) (physicalExit X x₀ R T) t ω ∂μ)≤
      V₀+C*(∫ ω, stoppedProcess (fun (s:ℝ≥0) (_:Ω) => (s:ℝ)) (physicalExit X x₀ R T) t ω ∂μ) := by
  let τ := physicalExit X x₀ R T
  obtain ⟨hτ,hτpos,hτT,hXB⟩ := physical_exit_properties hX hXc hX₀ hR hT
  let residual := fun s ω => V s ω-V₀-driftPath J s ω
  have hRa : StronglyAdapted ℱ residual := fun s =>
    ((hV s).sub stronglyMeasurable_const).sub (continuous_drift_adapted hJ hJc s)
  have hRc : ∀ ω, Continuous (fun s => residual s ω) := fun ω =>
    ((hVc ω).sub continuous_const).sub (continuous_drift_paths hJc ω)
  have htime (s : ℝ≥0) (ω : Ω) :
      (min (s:WithTop ℝ≥0) (τ ω)).untopA≤ T ∧
      (((min (s:WithTop ℝ≥0) (τ ω)).untopA:ℝ≥0):WithTop ℝ≥0)≤τ ω := by
    exact ⟨WithTop.untopA_le ((min_le_right _ _).trans (hτT ω)),
      by rw [coe_untopA_min]; exact min_le_right _ _⟩
  have hprefix (u : ℝ≥0) (ω : Ω) (hu : (u:WithTop ℝ≥0)≤τ ω) :
      ∀ s∈Icc 0 u, X s ω∈Metric.closedBall x₀ R := by
    intro s hs
    have hsτ : (s:WithTop ℝ≥0)≤τ ω := (WithTop.coe_le_coe.mpr hs.2).trans hu
    have h := hXB s ω
    rw [stoppedProcess_eq_of_le hsτ] at h
    exact h
  have hJint (u : ℝ≥0) (ω : Ω) (huT : u≤ T) (hu : (u:WithTop ℝ≥0)≤τ ω) :
      |driftPath J u ω|≤ CJ*T := by
    apply (drift_prefix_bound u ω (fun s hs => ?_)).trans
      (mul_le_mul_of_nonneg_left (by exact_mod_cast huT) hCJ)
    exact (Real.norm_eq_abs _).symm.trans_le
      (hJB s ⟨zero_le,hs.2.trans huT⟩ ω (hprefix u ω hu s hs))
  have hVstop : ∀ s ω, ‖stoppedProcess V τ s ω‖≤ CV := by
    intro s ω
    exact hVB _ ⟨zero_le,(htime s ω).1⟩ ω
      (hprefix _ ω (htime s ω).2 _ ⟨zero_le,le_rfl⟩)
  have hIstop : ∀ s ω, ‖stoppedProcess (driftPath V) τ s ω‖≤ CV*T := by
    intro s ω
    rw [Real.norm_eq_abs]
    apply (drift_prefix_bound _ ω (fun q hq => ?_)).trans
      (mul_le_mul_of_nonneg_left (by exact_mod_cast (htime s ω).1) hCV)
    exact (Real.norm_eq_abs _).symm.trans_le
      (hVB q ⟨zero_le,hq.2.trans (htime s ω).1⟩ ω
        (hprefix _ ω (htime s ω).2 q hq))
  have hSstop : ∀ s ω, ‖stoppedProcess (fun (q:ℝ≥0) (_:Ω) => (q:ℝ)) τ s ω‖≤(T:ℝ) := by
    intro s ω
    simpa only [stoppedProcess,Real.norm_eq_abs,abs_of_nonneg (NNReal.coe_nonneg _)] using
      (show ((min (s:WithTop ℝ≥0) (τ ω)).untopA:ℝ)≤ T by exact_mod_cast (htime s ω).1)
  have hRstop : ∀ s ω, ‖stoppedProcess residual τ s ω‖≤ CV+|V₀|+CJ*T := by
    intro s ω
    let u := (min (s:WithTop ℝ≥0) (τ ω)).untopA
    have hvi := hVstop s ω
    have hji := hJint u ω (htime s ω).1 (htime s ω).2
    change ‖V u ω-V₀-driftPath J u ω‖≤ CV+|V₀|+CJ*T
    have hn₁ := norm_sub_le (V u ω-V₀) (driftPath J u ω)
    have hn₂ := norm_sub_le (V u ω) V₀
    simp only [Real.norm_eq_abs] at hn₁ hn₂ hvi ⊢
    change |V u ω|≤ CV at hvi
    linarith
  have heq : ∀ᵐ ω ∂μ, ∀ s∈Icc 0 T, M s ω=residual s ω := by
    filter_upwards [hIto] with ω hω s hs
    dsimp [residual]
    linarith [hω s hs]
  have hmart := bounded_stopped_residual_martingale hM hRa hRc heq hτ hτpos hτT hRstop
  have hR₀ (ω : Ω) : residual 0 ω=0 := by simp [residual,driftPath,hV₀]
  have hineq : ∀ᵐ ω ∂μ, ∀ s,
      stoppedProcess V τ s ω+2*κ*stoppedProcess (driftPath V) τ s ω≤
        V₀+C*stoppedProcess (fun (q:ℝ≥0) (_:Ω) => (q:ℝ)) τ s ω+stoppedProcess residual τ s ω := by
    apply Eventually.of_forall
    intro ω s
    have hi := drift_dissipation_prefix hVc hJc _ ω (fun q hq =>
      hgen q ⟨zero_le,hq.2.trans (htime s ω).1⟩ ω (hprefix _ ω (htime s ω).2 q hq))
    dsimp only [stoppedProcess,residual]
    linarith
  exact stopped_dissipation_expectation hτ hτpos hV hVc
    (continuous_drift_adapted hV hVc) (continuous_drift_paths hVc)
    (fun _ => stronglyMeasurable_const) (fun _ => NNReal.continuous_coe)
    hVstop hIstop hSstop hmart hR₀ hineq t

end
end ChainFountainStochastic
