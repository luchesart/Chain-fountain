/-
Indicator-CLM construction adapted from Raphael Coelho's MathFin
ItoIntegralProcessIsometry.lean (Apache 2.0), commit
61d945b970561fcce6996fac0a5f18a424eb851f; generalized to vector-valued L2.
-/
import ChainFountainStochastic.PrefixLimits

namespace ChainFountainStochastic.TimeProjection
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM
open VectorSDE VectorLp
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 700000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

abbrev band (t : ℝ≥0) : Set (ℝ≥0 × Ω) := Ioc 0 t ×ˢ univ

theorem measurable_band (t : ℝ≥0) (hBm : ∀ u, Measurable (B u)) :
    MeasurableSet[(natFiltration hBm).predictable] (band (Ω:=Ω) t) :=
  MeasureTheory.measurableSet_predictable_Ioc_prod _ _ MeasurableSet.univ

/-- Continuous projection onto the part of a predictable L2 process before t. -/
def cut (T t : ℝ≥0) (hBm : ∀ u, Measurable (B u)) :
    Lp E 2 (trimMeasure_T (μ:=μ) T hBm) →L[ℝ] Lp E 2 (trimMeasure_T (μ:=μ) T hBm) :=
  LinearMap.mkContinuous
    { toFun := fun X => ((Lp.memLp X).indicator (measurable_band t hBm)).toLp ((band t).indicator X)
      map_add' := fun X Y => by
        apply Lp.ext
        filter_upwards [((Lp.memLp (X+Y)).indicator (measurable_band t hBm)).coeFn_toLp,
          Lp.coeFn_add (((Lp.memLp X).indicator (measurable_band t hBm)).toLp _)
            (((Lp.memLp Y).indicator (measurable_band t hBm)).toLp _),
          ((Lp.memLp X).indicator (measurable_band t hBm)).coeFn_toLp,
          ((Lp.memLp Y).indicator (measurable_band t hBm)).coeFn_toLp,Lp.coeFn_add X Y]
          with z h1 h2 h3 h4 h5
        rw [h1,h2,Pi.add_apply,h3,h4]
        by_cases hz : z ∈ band t
        · simp only [Set.indicator_of_mem hz]
          exact h5
        · simp only [Set.indicator_of_notMem hz,zero_add]
      map_smul' := fun c X => by
        apply Lp.ext
        filter_upwards [((Lp.memLp (c • X)).indicator (measurable_band t hBm)).coeFn_toLp,
          Lp.coeFn_smul c (((Lp.memLp X).indicator (measurable_band t hBm)).toLp _),
          ((Lp.memLp X).indicator (measurable_band t hBm)).coeFn_toLp,Lp.coeFn_smul c X]
          with z h1 h2 h3 h4
        rw [h1,RingHom.id_apply,h2,Pi.smul_apply,h3]
        by_cases hz : z ∈ band t <;> simp [hz,h4] }
    1 (fun X => by
      simp only [LinearMap.coe_mk,AddHom.coe_mk,one_mul]
      rw [Lp.norm_toLp,Lp.norm_def]
      exact ENNReal.toReal_mono (Lp.memLp X).2.ne (eLpNorm_indicator_le _))

theorem cut_coe (T t : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (X : Lp E 2 (trimMeasure_T (μ:=μ) T hBm)) :
    ⇑(cut T t hBm X) =ᵐ[trimMeasure_T (μ:=μ) T hBm] (band t).indicator X :=
  ((Lp.memLp X).indicator (measurable_band t hBm)).coeFn_toLp

theorem cut_zero (T : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (X : Lp E 2 (trimMeasure_T (μ:=μ) T hBm)) : cut T 0 hBm X = 0 := by
  apply Lp.ext
  filter_upwards [cut_coe T 0 hBm X,Lp.coeFn_zero (E:=E) (p:=2) (μ:=trimMeasure_T (μ:=μ) T hBm)] with z hz h0
  change cut T 0 hBm X z = (0 : Lp E 2 (trimMeasure_T (μ:=μ) T hBm)) z
  rw [h0]
  simpa [band] using hz

theorem cut_full (T : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (X : Lp E 2 (trimMeasure_T (μ:=μ) T hBm)) : cut T T hBm X = X := by
  apply Lp.ext
  have hb : ∀ᵐ z ∂trimMeasure_T (μ:=μ) T hBm, z ∈ band T := by
    rw [trimMeasure_T_eq_restrict]
    exact ae_restrict_mem (measurable_band T hBm)
  filter_upwards [cut_coe T T hBm X,hb] with z hz hb
  simpa [hb] using hz

theorem cut_absorb (T s t : ℝ≥0) (hBm : ∀ u, Measurable (B u)) (hst : s ≤ t)
    (X : Lp E 2 (trimMeasure_T (μ:=μ) T hBm)) :
    cut T s hBm (cut T t hBm X) = cut T s hBm X := by
  apply Lp.ext
  filter_upwards [cut_coe T s hBm (cut T t hBm X),cut_coe T t hBm X,cut_coe T s hBm X]
    with z h1 h2 h3
  by_cases hs : z ∈ band s
  · have ht : z ∈ band t := ⟨⟨hs.1.1,hs.1.2.trans hst⟩,mem_univ _⟩
    simp_all
  · simp_all

theorem cut_eq_iff (T t : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (X Y : Lp E 2 (trimMeasure_T (μ:=μ) T hBm)) :
    cut T t hBm X = cut T t hBm Y ↔
      ∀ᵐ z ∂trimMeasure_T (μ:=μ) T hBm, z ∈ band t → X z = Y z := by
  constructor
  · intro he
    filter_upwards [cut_coe T t hBm X,cut_coe T t hBm Y] with z hx hy hz
    rw [he] at hx
    simpa [hz] using hx.symm.trans hy
  · intro he
    apply Lp.ext
    filter_upwards [cut_coe T t hBm X,cut_coe T t hBm Y,he] with z hx hy he
    by_cases hz : z ∈ band t <;> simp_all

/-- The square norm of a scalar projected process is its prefix energy. -/
theorem cut_norm_sq (T t : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (X : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) :
    ‖cut T t hBm X‖^2 = ∫ z in band t, (X z)^2 ∂trimMeasure_T (μ:=μ) T hBm := by
  rw [lp_two_norm_sq,←integral_indicator (measurable_band t hBm)]
  apply integral_congr_ae
  filter_upwards [cut_coe T t hBm X] with z hz
  rw [hz]
  by_cases ht : z ∈ band t <;> simp [ht]

/-- Restricting the predictable measure to a smaller time band gives exactly
that smaller horizon measure. -/
theorem trim_restrict_eq (T t : ℝ≥0) (hBm : ∀ u, Measurable (B u)) (ht : t ≤ T) :
    (trimMeasure_T (μ:=μ) T hBm).restrict (band t) = trimMeasure_T (μ:=μ) t hBm := by
  rw [trimMeasure_T_eq_restrict,Measure.restrict_restrict_of_subset]
  · exact (trimMeasure_T_eq_restrict t hBm).symm
  · exact fun z hz => ⟨⟨hz.1.1,hz.1.2.trans ht⟩,mem_univ _⟩

theorem memLp_product (T : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (X : Lp E 2 (trimMeasure_T (μ:=μ) T hBm)) :
    MemLp (⇑X) 2 ((timeMeasure_T T).prod μ) := by
  refine ⟨(Lp.stronglyMeasurable X).mono (natFiltration hBm).predictable_le_prod |>.aestronglyMeasurable,?_⟩
  rw [← eLpNorm_trim (natFiltration hBm).predictable_le_prod (Lp.stronglyMeasurable X)]
  exact (Lp.memLp X).2

/-- Prefix energy is the integral of the square energies of its time slices. -/
theorem cut_norm_sq_eq_integral (T t : ℝ≥0) (hBm : ∀ u, Measurable (B u)) (ht : t ≤ T)
    (X : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) :
    ‖cut T t hBm X‖^2 = ∫ u, ∫ ω, (X (u,ω))^2 ∂μ ∂timeMeasure_T t := by
  have hm : MemLp (⇑X) 2 ((timeMeasure_T t).prod μ) :=
    (memLp_product T hBm X).mono_measure
      (Measure.prod_mono (Measure.restrict_mono (Ioc_subset_Ioc_right ht) le_rfl) le_rfl)
  rw [cut_norm_sq,trim_restrict_eq T t hBm ht]
  have htrim : (∫ z, (X z)^2 ∂trimMeasure_T (μ:=μ) t hBm) =
      ∫ z, (X z)^2 ∂(timeMeasure_T t).prod μ :=
    (integral_trim (μ:=(timeMeasure_T t).prod μ)
      (natFiltration hBm).predictable_le_prod ((Lp.stronglyMeasurable X).pow 2)).symm
  rw [htrim]
  exact integral_prod _ hm.integrable_sq

theorem cut_eq_zero_iff (T t : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (X : Lp E 2 (trimMeasure_T (μ:=μ) T hBm)) :
    cut T t hBm X = 0 ↔ ∀ᵐ z ∂trimMeasure_T (μ:=μ) T hBm, z ∈ band t → X z = 0 := by
  rw [← map_zero (cut T t hBm),cut_eq_iff]
  constructor <;> intro he
  · filter_upwards [he,Lp.coeFn_zero (E:=E) (p:=2) (μ:=trimMeasure_T (μ:=μ) T hBm)] with z hz h0
    exact fun ht => (hz ht).trans h0
  · filter_upwards [he,Lp.coeFn_zero (E:=E) (p:=2) (μ:=trimMeasure_T (μ:=μ) T hBm)] with z hz h0
    exact fun ht => (hz ht).trans h0.symm

/-- The prefix energy formula is invariant under choice of representative. -/
theorem cut_energy_of_rep (T t : ℝ≥0) (hBm : ∀ u, Measurable (B u)) (ht : t ≤ T)
    (X : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) {f : ℝ≥0 → Ω → ℝ}
    (hf : ⇑X =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry f) :
    ‖cut T t hBm X‖^2 = ∫ u, ∫ ω, (f u ω)^2 ∂μ ∂timeMeasure_T t := by
  rw [cut_norm_sq_eq_integral T t hBm ht]
  have hp := Measure.ae_ae_of_ae_prod (ae_of_ae_trim (natFiltration hBm).predictable_le_prod hf)
  have hp' := hp.filter_mono (ae_mono (Measure.restrict_mono (Ioc_subset_Ioc_right ht) le_rfl))
  apply integral_congr_ae
  filter_upwards [hp'] with u hu
  exact integral_congr_ae (hu.mono fun ω hω => congrArg (fun x : ℝ => x^2) hω)

/-- A process vanishing before s costs only the length t-s in the outer
energy integral. The bound is used for both drift and stochastic integration. -/
theorem cut_sq_le (T s t : ℝ≥0) (hBm : ∀ u, Measurable (B u)) (hst : s ≤ t) (ht : t ≤ T)
    (X : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) {f : ℝ≥0 → Ω → ℝ}
    (hf : ⇑X =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry f)
    (M : ℝ) (hM : 0 ≤ M)
    (hbound : ∀ u, u ≤ t → (∫ ω, (f u ω)^2 ∂μ) ≤ M)
    (hzero : ∀ u, u ≤ s → ∀ᵐ ω ∂μ, f u ω = 0) :
    ‖cut T t hBm X‖^2 ≤ ((t:ℝ)-(s:ℝ))*M := by
  rw [cut_energy_of_rep T t hBm ht X hf]
  calc
    _ ≤ ∫ u, (Ioc s t).indicator (fun _ => M) u ∂timeMeasure_T t := by
      apply integral_mono_of_nonneg (ae_of_all _ fun _ => integral_nonneg fun _ => sq_nonneg _)
        ((integrable_const M).indicator measurableSet_Ioc)
      filter_upwards [ae_restrict_mem (μ:=timeMeasure) measurableSet_Ioc] with u hu
      by_cases hs : u ≤ s
      · have hz : (∫ ω, (f u ω)^2 ∂μ) = 0 := by
          apply integral_eq_zero_of_ae
          filter_upwards [hzero u hs] with ω hω
          simp [hω]
        rw [hz,indicator_of_notMem (by exact fun h => not_lt_of_ge hs h.1)]
      · rw [indicator_of_mem (show u ∈ Ioc s t from ⟨lt_of_not_ge hs,hu.2⟩)]
        exact hbound u hu.2
    _ = ((t:ℝ)-(s:ℝ))*M := by
      rw [integral_indicator measurableSet_Ioc,integral_const,smul_eq_mul]
      congr 1
      rw [measureReal_def,Measure.restrict_apply_univ,timeMeasure_T,
        Measure.restrict_apply measurableSet_Ioc,
        inter_eq_left.mpr (Ioc_subset_Ioc_left (show (0:ℝ≥0) ≤ s from zero_le)),timeMeasure_Ioc,
        ENNReal.toReal_ofReal (sub_nonneg.mpr (show (s:ℝ) ≤ (t:ℝ) from hst))]

/-- Time projection commutes with continuous linear coordinate maps. -/
theorem cut_compLp {F : Type*} [NormedAddCommGroup F] [NormedSpace ℝ F]
    (T t : ℝ≥0) (hBm : ∀ u, Measurable (B u)) (L : E →L[ℝ] F)
    (X : Lp E 2 (trimMeasure_T (μ:=μ) T hBm)) :
    cut T t hBm (L.compLpL 2 _ X) = L.compLpL 2 _ (cut T t hBm X) := by
  apply Lp.ext
  filter_upwards [cut_coe T t hBm (L.compLpL 2 _ X),L.coeFn_compLpL X,
    L.coeFn_compLpL (cut T t hBm X),cut_coe T t hBm X] with z h1 h2 h3 h4
  rw [h1,h3,h4]
  by_cases hz : z ∈ band t
  · simpa only [indicator_of_mem hz] using h2
  · simp only [indicator_of_notMem hz,map_zero]

theorem cut_assemble {ι : Type*} [Fintype ι] [DecidableEq ι]
    (T t : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (X : ι → Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) :
    cut T t hBm (assembleLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) X) = assembleLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (fun i => cut T t hBm (X i)) := by
  simp only [assembleLp,map_sum,singleLp]
  apply Finset.sum_congr rfl
  intro i _
  exact cut_compLp T t hBm _ _

end
end ChainFountainStochastic.TimeProjection
