/-
Copyright (c) 2026 Raphael Coelho. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors of adapted upstream proofs: Raphael Coelho.

Modified: simultaneous-in-time drift identity, continuous strong realization
and actual trajectory coefficient composition.
Drift uniform-convergence argument adapted from Raphael Coelho's
MathFin.Foundations.ItoIntegralProcessContinuousModification and
MathFin.Foundations.DriftProcessModification, Apache 2.0,
commit 61d945b970561fcce6996fac0a5f18a424eb851f.
-/
module
public import MathFin.Foundations.SDEExistence
public import MathFin.Foundations.DriftProcessModification
@[expose] public section
namespace ChainFountainStochastic.SDEContinuous
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology
open scoped NNReal ENNReal
open MathFin MathFin.SDEExistence MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM
  MathFin.ItoIntegralProcess MathFin.ItoIntegralProcessGeneral
  MathFin.ItoIntegralProcessContinuousModification


variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}

/-- Coefficients are the actual pointwise composition, as predictable L2 classes. -/
theorem lipComp_coe (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    {f : ℝ → ℝ} {L : ℝ≥0} (hf : LipschitzWith L f)
    (X : Lp ℝ 2 (trimMeasure_T (μ := μ) T hBm)) :
    ⇑(lipComp T hBm f L hf X) =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => f (X z) := by
  filter_upwards [Lp.coeFn_add (Lp.const 2 (trimMeasure_T (μ:=μ) T hBm) (f 0))
    ((lipschitz_sub_const hf).compLp (by simp) X),
    Lp.coeFn_const (p:=2) (μ:=trimMeasure_T (μ:=μ) T hBm) (c:=f 0),
    (lipschitz_sub_const hf).coeFn_compLp (by simp) X] with z ha hc hx
  change ⇑(Lp.const 2 (trimMeasure_T (μ:=μ) T hBm) (f 0) + (lipschitz_sub_const hf).compLp (by simp) X) z = _
  rw [ha,Pi.add_apply,hc,hx]
  dsimp only [Function.const_apply,Function.comp_apply]
  ring

/-- Transfer a predictable product-null equality to almost every path. -/
theorem ae_path_of_trim_eq (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    {f g : ℝ≥0 × Ω → ℝ} (he : f =ᵐ[trimMeasure_T (μ:=μ) T hBm] g) :
    ∀ᵐ ω ∂μ, ∀ᵐ s ∂timeMeasure_T T, f (s,ω)=g (s,ω) := by
  have hp : f =ᵐ[(timeMeasure_T T).prod μ] g :=
    ae_of_ae_trim (natFiltration hBm).predictable_le_prod he
  exact Measure.ae_ae_of_ae_prod (Measure.measurePreserving_swap.quasiMeasurePreserving.ae hp)

/-- Uniform control of consecutive elementary drifts. -/
theorem drift_consecutive_norm_le (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (V : ℕ → TBoundedSP T hBm) (ω : Ω) {t : ℝ≥0} (ht : t ≤ T) (a : ℕ) :
    ‖driftSimpleProcess hBm (V a).val t ω - driftSimpleProcess hBm (V (a+1)).val t ω‖
      ≤ ⨆ j : Iic T, |driftSimpleProcess hBm (V a - V (a+1)).val (j:ℝ≥0) ω| := by
  have hc : ((V a - V (a+1)).val : SimpleProcess ℝ (natFiltration hBm)) =
      (V a).val - (V (a+1)).val := rfl
  rw [show driftSimpleProcess hBm (V a).val t ω - driftSimpleProcess hBm (V (a+1)).val t ω
      = driftSimpleProcess hBm (V a - V (a+1)).val t ω by
        rw [hc]; exact (congrFun (driftSimpleProcess_sub hBm (V a).val (V (a+1)).val t) ω).symm,
      Real.norm_eq_abs]
  exact drift_norm_le_iSup_Iic hBm (V a - V (a+1)).val ω ht

/-- The predictable drift realization has continuous paths on one full-measure event. -/
theorem drift_mod_continuousOn (T : ℝ≥0) (hBmeas : ∀ t, Measurable (B t))
    (φ : Lp ℝ 2 (trimMeasure_T (μ := μ) T hBmeas)) :
    ∀ᵐ ω ∂μ, ContinuousOn (fun t ↦ driftContinuousMod T hBmeas φ t ω) (Set.Icc 0 T) := by
  set V := (approxSeq T hBmeas φ).choose with hVdef
  have hV := (approxSeq T hBmeas φ).choose_spec
  filter_upwards [drift_ae_eventually_sup_lt T hBmeas φ V hV,
    driftContinuousMod_tendsto T hBmeas φ] with ω hω htends
  rw [show (Set.Icc 0 T : Set ℝ≥0) = Set.Iic T from by
    ext x; simp only [Set.mem_Icc, Set.mem_Iic, zero_le, true_and]]
  obtain ⟨N, hN⟩ := eventually_atTop.mp hω
  have huniform : TendstoUniformlyOn (fun n t ↦ driftSimpleProcess hBmeas (V n).val t ω)
      (fun t ↦ driftContinuousMod T hBmeas φ t ω) atTop (Set.Iic T) := by
    rw [Metric.tendstoUniformlyOn_iff]
    intro ε hε
    have htend0 : Tendsto (fun n ↦ 4 * (3 / 4 : ℝ) ^ n) atTop (𝓝 0) := by
      rw [show (0 : ℝ) = 4 * 0 from by ring]
      exact (tendsto_pow_atTop_nhds_zero_of_lt_one (by norm_num) (by norm_num)).const_mul 4
    filter_upwards [eventually_ge_atTop N, htend0.eventually_lt_const hε] with n hn hnε
    intro t ht
    rw [Set.mem_Iic] at ht
    rw [dist_comm]
    -- the uniform bound: dist (fₙ t ω) (X t ω) ≤ 4·(3/4)ⁿ
    have htendsto : Tendsto (fun k ↦ driftSimpleProcess hBmeas (V (k + n)).val t ω) atTop
        (𝓝 (driftContinuousMod T hBmeas φ t ω)) := (htends t ht).comp (tendsto_add_atTop_nat n)
    have hstep : ∀ k, dist (driftSimpleProcess hBmeas (V (k + n)).val t ω)
        (driftSimpleProcess hBmeas (V (k + 1 + n)).val t ω) ≤ (3 / 4 : ℝ) ^ n * (3 / 4 : ℝ) ^ k := by
      intro k
      rw [show k + 1 + n = (k + n) + 1 from by ring, dist_eq_norm]
      refine (drift_consecutive_norm_le T hBmeas V ω ht (k + n)).trans ?_
      exact (hN (k + n) (hn.trans (Nat.le_add_left n k))).le.trans
        (le_of_eq (by rw [pow_add]; ring))
    have h0 :=
      dist_le_of_le_geometric_of_tendsto₀ (3 / 4) ((3 / 4 : ℝ) ^ n) (by norm_num) hstep htendsto
    simp only [zero_add] at h0
    refine lt_of_le_of_lt (h0.trans (le_of_eq ?_)) hnε
    rw [show (1 : ℝ) - 3 / 4 = 1 / 4 from by norm_num]; ring
  have hcont : ∀ᶠ n in atTop,
      ContinuousOn (fun t ↦ driftSimpleProcess hBmeas (V n).val t ω) (Set.Iic T) :=
    Eventually.of_forall fun n ↦
      (driftSimpleProcess_continuous hBmeas (V n).val ω).continuousOn
  exact huniform.continuousOn hcont.frequently

/-- The drift integral identity holds at every time on one probability-one event. -/
theorem drift_mod_integral_all_times (T : ℝ≥0) (hBmeas : ∀ t, Measurable (B t))
    (g : Lp ℝ 2 (trimMeasure_T (μ := μ) T hBmeas)) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → driftContinuousMod T hBmeas g t ω
      = ∫ s in Set.Ioc (0 : ℝ≥0) t, ⇑g (s, ω) ∂timeMeasure := by
  set V := (approxSeq T hBmeas g).choose with hVdef
  have hV := (approxSeq T hBmeas g).choose_spec
  have hg_prod : MemLp (⇑g) 2 ((timeMeasure_T T).prod μ) :=
    ⟨aestronglyMeasurable_of_aestronglyMeasurable_trim (natFiltration hBmeas).predictable_le_prod
      (Lp.aestronglyMeasurable g),
     by rw [← eLpNorm_trim_ae (natFiltration hBmeas).predictable_le_prod
         (Lp.aestronglyMeasurable g)]
        exact (Lp.memLp g).2⟩
  have hg_slice : ∀ᵐ ω ∂μ, MemLp (fun s ↦ ⇑g (s, ω)) 2 (timeMeasure_T T) := by
    filter_upwards [hg_prod.1.prodMk_right, hg_prod.integrable_sq.prod_left_ae] with ω hω1 hω2
    exact (memLp_two_iff_integrable_sq hω1).mpr hω2
  -- the ω-slice energy and its L¹(μ) decay
  set D : ℕ → Ω → ℝ := fun n ω ↦
    ∫ s in Set.Ioc (0 : ℝ≥0) T, (⇑(V n).val s ω - ⇑g (s, ω)) ^ 2 ∂timeMeasure with hDdef
  have hDnn : ∀ n, 0 ≤ᵐ[μ] D n := fun n ↦ ae_of_all _ fun ω ↦ integral_nonneg fun s ↦ sq_nonneg _
  have hDint : ∀ n, Integrable (D n) μ :=
    fun n ↦ (drift_slice_sq_integrable T hBmeas g (V n)).integral_prod_right
  have hD0 : Tendsto (fun n ↦ ∫ ω, D n ω ∂μ) atTop (𝓝 0) := by
    have heq : ∀ n, (∫ ω, D n ω ∂μ) = ‖simpleAssembly_T (μ := μ) T hBmeas (V n) - g‖ ^ 2 :=
      fun n ↦ drift_slice_energy_eq T hBmeas g (V n)
    simp_rw [heq]
    have h0 : Tendsto (fun n ↦ ‖simpleAssembly_T (μ := μ) T hBmeas (V n) - g‖) atTop (𝓝 0) :=
      squeeze_zero (fun n ↦ norm_nonneg _) hV
        (tendsto_pow_atTop_nhds_zero_of_lt_one (by norm_num) (by norm_num))
    simpa using h0.pow 2
  -- L¹ decay ⟹ convergence in measure ⟹ a.e.-convergent subsequence
  have hDeLp : Tendsto (fun n ↦ eLpNorm (D n - fun _ ↦ (0 : ℝ)) 1 μ) atTop (𝓝 0) := by
    have hrw : ∀ n, eLpNorm (D n - fun _ ↦ (0 : ℝ)) 1 μ = ENNReal.ofReal (∫ ω, D n ω ∂μ) := by
      intro n
      have hsub : (D n - fun _ ↦ (0 : ℝ)) = D n := by funext ω; simp
      have hlint : (∫⁻ ω, ‖D n ω‖ₑ ∂μ) = ∫⁻ ω, ENNReal.ofReal (D n ω) ∂μ := by
        refine lintegral_congr_ae ?_
        filter_upwards [hDnn n] with ω hω
        rw [Real.enorm_eq_ofReal_abs, abs_of_nonneg hω]
      rw [hsub, eLpNorm_one_eq_lintegral_enorm, hlint,
        ← ofReal_integral_eq_lintegral_ofReal (hDint n) (hDnn n)]
    rw [tendsto_congr hrw, ← ENNReal.ofReal_zero]
    exact (ENNReal.continuous_ofReal.tendsto 0).comp hD0
  have hDmeasure : TendstoInMeasure μ D atTop (fun _ ↦ (0 : ℝ)) :=
    tendstoInMeasure_of_tendsto_eLpNorm one_ne_zero (fun n ↦ (hDint n).aestronglyMeasurable)
      aestronglyMeasurable_const hDeLp
  obtain ⟨ns, hns_mono, hns_ae⟩ := hDmeasure.exists_seq_tendsto_ae
  -- combine, a.e. ω
  filter_upwards [hns_ae, hg_slice, driftContinuousMod_tendsto T hBmeas g] with ω hωD hωg hωlim
  intro t ht
  haveI : IsFiniteMeasure (timeMeasure.restrict (Set.Ioc (0 : ℝ≥0) t)) :=
    ⟨by rw [Measure.restrict_apply_univ, timeMeasure_Ioc]; exact ENNReal.ofReal_lt_top⟩
  have hlim_sub : Tendsto (fun k ↦ driftSimpleProcess hBmeas (V (ns k)).val t ω) atTop
      (𝓝 (driftContinuousMod T hBmeas g t ω)) := (hωlim t ht).comp hns_mono.tendsto_atTop
  have hlim_int : Tendsto (fun k ↦ driftSimpleProcess hBmeas (V (ns k)).val t ω) atTop
      (𝓝 (∫ s in Set.Ioc (0 : ℝ≥0) t, ⇑g (s, ω) ∂timeMeasure)) := by
    rw [tendsto_iff_dist_tendsto_zero]
    refine squeeze_zero (fun k ↦ dist_nonneg) (fun k ↦ ?_)
      (g := fun k ↦ Real.sqrt ((T : ℝ) * D (ns k) ω)) ?_
    · -- dist bound via interval Cauchy–Schwarz
      have hVt : MemLp (fun s ↦ ⇑(V (ns k)).val s ω) 2 (timeMeasure.restrict (Set.Ioc 0 t)) :=
        (memLp_slice T hBmeas (V (ns k)).val ω).mono_measure
          (Measure.restrict_mono (Set.Ioc_subset_Ioc_right ht) le_rfl)
      have hgt : MemLp (fun s ↦ ⇑g (s, ω)) 2 (timeMeasure.restrict (Set.Ioc 0 t)) :=
        hωg.mono_measure (Measure.restrict_mono (Set.Ioc_subset_Ioc_right ht) le_rfl)
      have hfT : MemLp (fun s ↦ ⇑(V (ns k)).val s ω - ⇑g (s, ω)) 2
          (timeMeasure.restrict (Set.Ioc (0 : ℝ≥0) T)) :=
        (memLp_slice T hBmeas (V (ns k)).val ω).sub hωg
      rw [Real.dist_eq, ← Real.sqrt_sq_eq_abs]
      refine Real.sqrt_le_sqrt ?_
      rw [driftSimpleProcess_eq_setIntegral,
        ← integral_sub (hVt.integrable (by norm_num)) (hgt.integrable (by norm_num))]
      calc (∫ s in Set.Ioc (0 : ℝ≥0) t, (⇑(V (ns k)).val s ω - ⇑g (s, ω)) ∂timeMeasure) ^ 2
          ≤ (timeMeasure.restrict (Set.Ioc (0 : ℝ≥0) t)).real Set.univ
              * ∫ s in Set.Ioc (0 : ℝ≥0) t, (⇑(V (ns k)).val s ω - ⇑g (s, ω)) ^ 2 ∂timeMeasure :=
            sq_integral_le_measureReal_mul (hVt.sub hgt)
        _ ≤ (T : ℝ) * D (ns k) ω := by
            rw [measureReal_def, Measure.restrict_apply_univ, timeMeasure_Ioc,
              ENNReal.toReal_ofReal (by rw [NNReal.coe_zero, sub_zero]; exact t.coe_nonneg),
              NNReal.coe_zero, sub_zero]
            refine mul_le_mul (by exact_mod_cast ht) ?_ (integral_nonneg fun s ↦ sq_nonneg _)
              T.coe_nonneg
            exact setIntegral_mono_set hfT.integrable_sq (ae_of_all _ fun s ↦ sq_nonneg _)
              (Set.Ioc_subset_Ioc_right ht).eventuallyLE
    · rw [← Real.sqrt_zero, ← mul_zero (T : ℝ)]
      exact (Real.continuous_sqrt.tendsto _).comp (tendsto_const_nhds.mul hωD)
  exact tendsto_nhds_unique hlim_sub hlim_int

/-- Both continuous integral realizations start at zero, path by path. -/
theorem integral_mod_zero (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (φ : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) (ω : Ω) :
    driftContinuousMod T hBm φ 0 ω = 0 ∧ itoContinuousMod T hBm φ 0 ω = 0 := by
  constructor
  · simpa [driftContinuousMod,driftSimpleProcess] using
      (tendsto_const_nhds : Tendsto (fun _ : ℕ => (0:ℝ)) atTop (𝓝 0)).limUnder_eq
  · simpa [itoContinuousMod,itoSimpleProcess_apply] using
      (tendsto_const_nhds : Tendsto (fun _ : ℕ => (0:ℝ)) atTop (𝓝 0)).limUnder_eq

/-- Strong finite-horizon solution with the actual trajectory coefficients.
Continuity and the integral identity hold for all times on a single conull event.
The stochastic integral is the constructed predictable-L2 Ito integral. -/
structure ScalarStrongSolution (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (b σ : ℝ → ℝ) (x₀ : ℝ) (Y : ℝ≥0 → Ω → ℝ) : Prop where
  predictable : IsStronglyPredictable (natFiltration hBm) Y
  continuous : ∀ᵐ ω ∂μ, ContinuousOn (fun t => Y t ω) (Icc 0 T)
  initial : ∀ ω, Y 0 ω = x₀
  state_memLp : MemLp (Function.uncurry Y) 2 (trimMeasure_T (μ:=μ) T hBm)
  drift_memLp : MemLp (fun z : ℝ≥0 × Ω => b (Y z.1 z.2)) 2 (trimMeasure_T (μ:=μ) T hBm)
  diffusion_memLp : MemLp (fun z : ℝ≥0 × Ω => σ (Y z.1 z.2)) 2 (trimMeasure_T (μ:=μ) T hBm)
  equation : ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T →
    Y t ω = x₀ + (∫ s in Ioc (0:ℝ≥0) t, b (Y s ω) ∂timeMeasure) +
      itoContinuousMod T hBm (diffusion_memLp.toLp (fun z => σ (Y z.1 z.2))) t ω

set_option backward.isDefEq.respectTransparency true in
set_option maxHeartbeats 400000 in
/-- Realize any Picard fixed point as a continuous adapted strong solution.
In particular, composition is proved for the new trajectory, rather than
silently identifying an arbitrary representative of the L2 class with it. -/
theorem realize_picard_fixed_point (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {b σ : ℝ → ℝ} {Lb Lσ : ℝ≥0} (hb : LipschitzWith Lb b) (hσ : LipschitzWith Lσ σ)
    (x₀ : ℝ) (X : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm))
    (hfix : picardMap hB T hBm hBc hb hσ (Lp.const 2 _ x₀) X = X) :
    ∃ Y : ℝ≥0 → Ω → ℝ, ScalarStrongSolution (μ:=μ) T hBm b σ x₀ Y ∧
      ⇑X =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry Y := by
  let φ := lipComp T hBm b Lb hb X
  let ψ := lipComp T hBm σ Lσ hσ X
  let Y : ℝ≥0 → Ω → ℝ := fun t ω =>
    x₀ + driftContinuousMod T hBm φ t ω + itoContinuousMod T hBm ψ t ω
  have hI : ⇑(itoProcessAssembled hB T hBm hBc ψ)
      =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry (itoContinuousMod T hBm ψ) :=
    (memLp_itoContinuousMod hB T hBm hBc ψ).coeFn_toLp
  have hX : ⇑X =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry Y := by
    have he : ⇑(picardMap hB T hBm hBc hb hσ (Lp.const 2 _ x₀) X)
        =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry Y := by
      filter_upwards [Lp.coeFn_add
        (Lp.const 2 _ x₀ + driftProcessAssembled (μ:=μ) T hBm φ)
        (itoProcessAssembled hB T hBm hBc ψ),
        Lp.coeFn_add (Lp.const 2 _ x₀) (driftProcessAssembled (μ:=μ) T hBm φ),
        Lp.coeFn_const (p:=2) (μ:=trimMeasure_T (μ:=μ) T hBm) (c:=x₀),
        driftProcessAssembled_coeFn T hBm φ,
        hI] with z h1 h2 h0 hd hi
      change (Lp.const 2 (trimMeasure_T (μ:=μ) T hBm) x₀ +
        driftProcessAssembled (μ:=μ) T hBm φ +
        itoProcessAssembled hB T hBm hBc ψ : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) z = Y z.1 z.2
      simp only [h1,h2,h0,hd,hi,Pi.add_apply,Function.const_apply,Y,Function.uncurry]
    rwa [hfix] at he
  have hφ : ⇑φ =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => b (Y z.1 z.2) := by
    filter_upwards [lipComp_coe T hBm hb X,hX] with z hc hz
    exact hc.trans (congrArg b hz)
  have hψ : ⇑ψ =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => σ (Y z.1 z.2) := by
    filter_upwards [lipComp_coe T hBm hσ X,hX] with z hc hz
    exact hc.trans (congrArg σ hz)
  have hYm : MemLp (Function.uncurry Y) 2 (trimMeasure_T (μ:=μ) T hBm) := (Lp.memLp X).ae_eq hX
  have hφm : MemLp (fun z : ℝ≥0 × Ω => b (Y z.1 z.2)) 2 (trimMeasure_T (μ:=μ) T hBm) := (Lp.memLp φ).ae_eq hφ
  have hψm : MemLp (fun z : ℝ≥0 × Ω => σ (Y z.1 z.2)) 2 (trimMeasure_T (μ:=μ) T hBm) := (Lp.memLp ψ).ae_eq hψ
  have hψclass : hψm.toLp (fun z : ℝ≥0 × Ω => σ (Y z.1 z.2)) = ψ := by
    exact (MemLp.toLp_congr hψm (Lp.memLp ψ) hψ.symm).trans
      (Lp.toLp_coeFn ψ (Lp.memLp ψ))
  refine ⟨Y,⟨?_,?_,?_,hYm,hφm,hψm,?_⟩,hX⟩
  · change StronglyMeasurable[(natFiltration hBm).predictable]
      (fun z : ℝ≥0 × Ω => x₀ + driftContinuousMod T hBm φ z.1 z.2 + itoContinuousMod T hBm ψ z.1 z.2)
    exact (stronglyMeasurable_const.add (driftContinuousMod_isStronglyPredictable T hBm φ)).add
      (itoContinuousMod_isStronglyPredictable hB T hBm hBc ψ)
  · filter_upwards [drift_mod_continuousOn T hBm φ,
      itoContinuousMod_continuousOn hB T hBm hBc ψ] with ω hd hi
    exact (continuousOn_const.add hd).add hi
  · intro ω
    dsimp only [Y]
    rw [(integral_mod_zero T hBm φ ω).1,(integral_mod_zero T hBm ψ ω).2]
    ring
  · rw [hψclass]
    filter_upwards [drift_mod_integral_all_times T hBm φ,ae_path_of_trim_eq T hBm hφ]
      with ω hd hc
    intro t ht
    change x₀ + driftContinuousMod T hBm φ t ω + itoContinuousMod T hBm ψ t ω = _
    rw [hd t ht]
    congr 2
    exact integral_congr_ae (hc.filter_mono
      (ae_mono (Measure.restrict_mono (Ioc_subset_Ioc_right ht) le_rfl)))

/-- A genuine scalar strong solution is constructed from Lipschitz coefficients
and deterministic initial data on every horizon in the contraction regime. -/
theorem exists_scalar_strong_solution (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {b σ : ℝ → ℝ} {Lb Lσ : ℝ≥0} (hb : LipschitzWith Lb b) (hσ : LipschitzWith Lσ σ)
    (x₀ : ℝ) (hc : (T:ℝ)*Lb + Real.sqrt (T:ℝ)*Lσ < 1) :
    ∃ Y : ℝ≥0 → Ω → ℝ, ScalarStrongSolution (μ:=μ) T hBm b σ x₀ Y := by
  obtain ⟨X,hX,hu⟩ := picardMap_exists_unique_fixedPoint hB T hBm hBc hb hσ
    (Lp.const 2 _ x₀) hc
  obtain ⟨Y,hY,hrep⟩ := realize_picard_fixed_point hB T hBm hBc hb hσ x₀ X hX
  exact ⟨Y,hY⟩

end
end ChainFountainStochastic.SDEContinuous
