import ChainFountainStochastic.ActualIntegralLIL
import ChainFountainStochastic.RegularRealization
import ChainFountainStochastic.MaximalUniqueness

namespace ChainFountainStochastic.MechanicalSmallTime
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Real MathFin ChainFountain
open MathFin.ItoIntegralL2 MathFin.ItoIntegralLocalised MathFin.AdaptedDrift
open MathFin.ItoFormulaAdapted
open VectorSDE GlobalCutoffSDE MechanicalCutoff CutoffExhaustion
open ConullBrownian RegularRealization BrownianSmallTime
open scoped NNReal ENNReal Topology
set_option maxHeartbeats 1500000
set_option backward.isDefEq.respectTransparency true

/-- The leading stochastic term of an actual constructed coordinate on a
continuous measure-preserving realization. Its SDE equation is derived from
the global strong solution. -/
theorem coordinate_leading
    {Ω Ω' : Type*} [MeasurableSpace Ω] [MeasurableSpace Ω']
    {μ : Measure Ω} {ν : Measure Ω'} [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
    (c : Coefficients (Fin 3)) (x₀ : State) {Y : ℝ≥0 → Ω → State}
    (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖c.drift t x‖ ≤ c.bound)
    {f : Ω' → Ω} (hf : MeasurableEmbedding f) (hm : MeasurePreserving f ν μ)
    (hYf : ∀ ω, Continuous (fun t => Y t (f ω))) (i : Fin 3) :
    ∀ᵐ ω ∂ν, Tendsto
      (fun t => (Y t (f ω) i-x₀ i-c.diffusion 0 x₀ i*B t (f ω))/scale t)
      (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
  obtain ⟨ha,hc,he⟩ := strong_solution_pullback_equation hB 1 hBm hBc c x₀ hY hb hf hm hYf i
  have hab : ∀ t ω, |c.diffusion t (Y t (f ω)) i| ≤ c.bound :=
    fun t ω => (norm_le_pi_norm (c.diffusion t (Y t (f ω))) i).trans (hb t _)
  have hz : ∀ᵐ ω ∂ν, c.diffusion 0 (Y 0 (f ω)) i = c.diffusion 0 x₀ i :=
    ae_of_all _ fun ω => by rw [(hY 0).initial]
  have hl := ItoFreezing.local_bounded (preBrownian_pullback hB hm) 1 (by norm_num)
    (fun t => (hBm t).comp hf.measurable) (fun ω => hBc (f ω)) ha hc hab hz
  let d := fun t ω => c.drift t (Y t (f ω)) i
  have hdc : ∀ ω, Continuous (d · ω) := fun ω =>
    (continuous_apply i).comp (c.drift_continuous.comp (continuous_id.prodMk (hYf ω)))
  have hdb : ∀ t ω, |d t ω| ≤ c.bound :=
    fun t ω => (norm_le_pi_norm (c.drift t (Y t (f ω))) i).trans (hd t _)
  filter_upwards [he,hl] with ω he hl
  have hdt : Tendsto (fun t => driftPath d t ω/scale t) (𝓝[>] (0:ℝ≥0)) (𝓝 0) :=
    LILDriftStability.bounded_drift_negligible (Eventually.of_forall fun t => by
      simpa [driftPath] using abs_driftPath_sub_le hdc hdb (s:=0) (t:=t) (show 0 ≤ t from bot_le) ω)
  have hs : Tendsto (fun t =>
      (localItoIntegral (μ:=ν) 1 (fun t => (hBm t).comp hf.measurable) ha hc t ω-
        c.diffusion 0 x₀ i*B t (f ω))/scale t + driftPath d t ω/scale t)
      (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by simpa only [zero_add] using hl.add hdt
  apply hs.congr'
  filter_upwards [((eventually_lt_nhds (by norm_num : (0:ℝ≥0) < 1)).filter_mono nhdsWithin_le_nhds)] with t ht
  rw [he t ⟨bot_le,ht.le⟩]
  dsimp [localItoProcess,d]
  ring

/-- Leading term of the crown coordinate of an actual strong vector SDE. -/
theorem crown_leading_realization
    {Ω Ω' : Type*} [MeasurableSpace Ω] [MeasurableSpace Ω']
    {μ : Measure Ω} {ν : Measure Ω'} [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
    (c : Coefficients (Fin 3)) (x₀ : State) {Y : ℝ≥0 → Ω → State}
    (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖c.drift t x‖ ≤ c.bound)
    {f : Ω' → Ω} (hf : MeasurableEmbedding f) (hm : MeasurePreserving f ν μ)
    (hYf : ∀ ω, Continuous (fun t => Y t (f ω))) :
    ∀ᵐ ω ∂ν, Tendsto (fun t =>
      ((Y t (f ω) 1+Y t (f ω) 2-x₀ 1-x₀ 2)/2-
        ((c.diffusion 0 x₀ 1+c.diffusion 0 x₀ 2)/2)*B t (f ω))/scale t)
      (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
  filter_upwards [coordinate_leading hB hBm hBc c x₀ hY hb hd hf hm hYf 1,
    coordinate_leading hB hBm hBc c x₀ hY hb hd hf hm hYf 2] with ω h1 h2
  convert (h1.add h2).div_const 2 using 1
  · ext t
    ring
  · simp

/-- The crown expansion on the original probability space of the constructed
cutoff solution. Continuity is obtained on a conull realization and transported back. -/
theorem cutoff_crown_leading
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
    (c : Coefficients (Fin 3)) (x₀ : State) {Y : ℝ≥0 → Ω → State}
    (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖c.drift t x‖ ≤ c.bound) :
    ∀ᵐ ω ∂μ, Tendsto (fun t =>
      ((Y t ω 1+Y t ω 2-x₀ 1-x₀ 2)/2-
        ((c.diffusion 0 x₀ 1+c.diffusion 0 x₀ 2)/2)*B t ω)/scale t)
      (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
  obtain ⟨G,hG,hGa,hgood⟩ := exists_measurable_conull (global_strong_solution_continuous hBm c x₀ hY)
  let ν := μ.comap ((↑) : G → Ω)
  have hm : MeasurePreserving ((↑) : G → Ω) ν μ := conull_subtype_preserving hG hGa
  letI : IsProbabilityMeasure ν := hm.hasLaw.isProbabilityMeasure
  have hf : MeasurableEmbedding ((↑) : G → Ω) := MeasurableEmbedding.subtype_coe hG
  have he := crown_leading_realization hB hBm hBc c x₀ hY hb hd hf hm
    (fun ω => hgood ω.val ω.property)
  rw [← hm.map_eq,hf.ae_map_iff]
  exact he

/-- Every positive lifetime contains a deterministic neighbourhood of zero on
each sample path. The neighbourhood may depend on that path. -/
theorem eventually_before {τ : WithTop ℝ≥0} (hτ : 0 < τ) :
    ∀ᶠ t : ℝ≥0 in 𝓝[>] (0:ℝ≥0), (t:WithTop ℝ≥0) < τ := by
  by_cases he : τ = ⊤
  · exact Eventually.of_forall fun t => by rw [he]; exact WithTop.coe_lt_top t
  · have hu : (τ.untopA:WithTop ℝ≥0) = τ := by
      rw [WithTop.untopA_eq_untop he]
      exact WithTop.coe_untop _ _
    have hp : (0:ℝ≥0) < τ.untopA := WithTop.coe_lt_coe.mp (by simpa only [hu,WithTop.coe_zero] using hτ)
    filter_upwards [((eventually_lt_nhds hp).filter_mono nhdsWithin_le_nhds)] with t ht
    exact hu ▸ WithTop.coe_lt_coe.mpr ht

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
  {B : ℝ≥0 → Ω → ℝ} {hBm : ∀ t, Measurable (B t)}
  {a : Parameters} {p : ℝ≥0 → State} {x₀ : State}

/-- Mechanical coefficient in the crown's actual stochastic integral. -/
def crownDiffusion (a : Parameters) (x : State) : ℝ := a.noise*(x 1)^2/(2*x 0)

/-- The constructed maximal mechanical solution has the frozen leading
Brownian coefficient sigma*v0^2/(2*h0), before its genuine positive exit. -/
theorem maximal_crown_leading (hB : IsPreBrownianReal B μ)
    (hBc : ∀ ω, Continuous (B · ω)) (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ, Tendsto (fun t =>
      ((F.process t ω 1+F.process t ω 2-x₀ 1-x₀ 2)/2-
        crownDiffusion a x₀*B t ω)/scale t) (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
  have hd := (F.agrees 0 0 x₀ (by simpa using F.initial_inside.le)).2
  have hq : ((F.c 0).diffusion 0 x₀ 1+(F.c 0).diffusion 0 x₀ 2)/2 = crownDiffusion a x₀ := by
    rw [hd]
    simp [Parameters.diffusion,crownDiffusion]
    ring
  filter_upwards [cutoff_crown_leading hB hBm hBc (F.c 0) x₀ (F.strong 0)
    (F.bound 0) (F.drift_bound 0),F.process_eq_before_exit] with ω hl he
  rw [hq] at hl
  apply hl.congr'
  filter_upwards [eventually_before ((F.exit_properties 0).2.1 ω)] with t ht
  rw [(he 0 t ht.le).2]

/-- Both sharp small-time LIL limits for the actual constructed maximal
mechanical solution, on its original probability space. -/
theorem maximal_crown_lil (hB : IsPreBrownianReal B μ)
    (hBc : ∀ ω, Continuous (B · ω)) (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ,
      limsup (fun t => ((F.process t ω 1+F.process t ω 2-x₀ 1-x₀ 2)/2/scale t).toEReal)
        (𝓝[>] (0:ℝ≥0)) = |crownDiffusion a x₀| ∧
      liminf (fun t => ((F.process t ω 1+F.process t ω 2-x₀ 1-x₀ 2)/2/scale t).toEReal)
        (𝓝[>] (0:ℝ≥0)) = -|crownDiffusion a x₀| := by
  filter_upwards [maximal_crown_leading hB hBc F,
    ActualIntegralLIL.transfer (show IsBrownianReal B μ from ⟨hB,ae_of_all _ hBc⟩)] with ω hl ht
  exact ht (crownDiffusion a x₀) _ hl


/-- Exact unit normalization of the mechanical crown LIL. -/
theorem maximal_crown_normalized_lil (hB : IsPreBrownianReal B μ)
    (hBc : ∀ ω, Continuous (B · ω)) (F : Family (μ:=μ) hBm a p x₀)
    (hq : crownDiffusion a x₀ ≠ 0) :
    ∀ᵐ ω ∂μ,
      limsup (fun t => ((F.process t ω 1+F.process t ω 2-x₀ 1-x₀ 2)/2/
        (|crownDiffusion a x₀| * scale t)).toEReal) (𝓝[>] (0:ℝ≥0)) = 1 ∧
      liminf (fun t => ((F.process t ω 1+F.process t ω 2-x₀ 1-x₀ 2)/2/
        (|crownDiffusion a x₀| * scale t)).toEReal) (𝓝[>] (0:ℝ≥0)) = -1 := by
  filter_upwards [maximal_crown_lil hB hBc F] with ω hl
  have he (t : ℝ≥0) : ((F.process t ω 1+F.process t ω 2-x₀ 1-x₀ 2)/2/
        (|crownDiffusion a x₀| * scale t)).toEReal =
      (|crownDiffusion a x₀|⁻¹).toEReal*
        ((F.process t ω 1+F.process t ω 2-x₀ 1-x₀ 2)/2/scale t).toEReal := by
    rw [← EReal.coe_mul]
    congr 1
    ring
  simp_rw [he]
  rw [EReal.limsup_const_mul_of_nonneg_of_ne_top (by positivity) (by simp),
    EReal.liminf_const_mul_of_nonneg_of_ne_top (by positivity) (by simp),hl.1,hl.2]
  norm_cast
  constructor
  · exact inv_mul_cancel₀ (abs_ne_zero.mpr hq)
  · rw [mul_neg,inv_mul_cancel₀ (abs_ne_zero.mpr hq)]
    simp

/-- Nonzero physical noise and positive initial rise speed give a nonzero
crown diffusion at every positive-height initial state. -/
theorem crownDiffusion_ne_zero (hσ : a.noise ≠ 0) (hv : x₀ 1 ≠ 0) (hh : x₀ 0 ≠ 0) :
    crownDiffusion a x₀ ≠ 0 := by
  dsimp [crownDiffusion]
  exact div_ne_zero (mul_ne_zero hσ (pow_ne_zero 2 hv)) (mul_ne_zero (by norm_num) hh)

/-- A negative LIL lower limit forces negative values arbitrarily near zero. -/
theorem negative_germ {x : ℝ≥0 → ℝ} {q : ℝ} (hq : q ≠ 0)
    (hl : liminf (fun t => (x t/scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = -|q|) :
    ∃ᶠ t in 𝓝[>] (0:ℝ≥0), x t < 0 := by
  have hf : ∃ᶠ t in 𝓝[>] (0:ℝ≥0), (x t/scale t).toEReal < 0 :=
    frequently_lt_of_liminf_lt (by isBoundedDefault) (by
      rw [hl]
      exact_mod_cast neg_neg_of_pos (abs_pos.mpr hq))
  apply hf.mono
  intro t ht
  have hr : x t/scale t < 0 := by exact_mod_cast ht
  rcases div_neg_iff.mp hr with h | h
  · exact (not_lt_of_ge (sqrt_nonneg _) h.2).elim
  · exact h.1

/-- Almost-sure failure of crown-boundary invariance for the actual maximal
mechanical SDE, at arbitrarily small positive times before its genuine exit. -/
theorem boundary_negative (hB : IsPreBrownianReal B μ)
    (hBc : ∀ ω, Continuous (B · ω)) (F : Family (μ:=μ) hBm a p x₀)
    (hσ : a.noise ≠ 0) (hv : x₀ 1 ≠ 0) (hh : x₀ 0 ≠ 0)
    {vmin : ℝ} (hboundary : (x₀ 1+x₀ 2)/2 = vmin) :
    ∀ᵐ ω ∂μ, ∀ ε : ℝ≥0, 0 < ε → ∃ t : ℝ≥0,
      0 < t ∧ t < ε ∧ (t:WithTop ℝ≥0) < F.exit 0 ω ∧
      (t:WithTop ℝ≥0) < F.lifetime ω ∧
      (F.process t ω 1+F.process t ω 2)/2-vmin < 0 := by
  filter_upwards [maximal_crown_lil hB hBc F] with ω hl
  have hn := negative_germ (crownDiffusion_ne_zero hσ hv hh) hl.2
  intro ε hε
  have hpos : ∀ᶠ t : ℝ≥0 in 𝓝[>] (0:ℝ≥0), 0 < t := self_mem_nhdsWithin
  obtain ⟨t,htneg,htpos,htε,htτ⟩ := (hn.and_eventually
    (hpos.and (((eventually_lt_nhds hε).filter_mono nhdsWithin_le_nhds).and
      (eventually_before ((F.exit_properties 0).2.1 ω))))).exists
  refine ⟨t,htpos,htε,htτ,htτ.trans_le (le_iSup (fun n => F.exit n ω) 0),?_⟩
  rw [← hboundary]
  linarith

/-- End-to-end existence with the sharp crown LIL from mechanical model data.
No stochastic trajectory or Brownian time-change representation is supplied. -/
theorem exists_mechanical_crown_lil (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
    (a : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi : State) (hpmem : ∀ t, p t ∈ Icc plo phi)
    (x₀ : State) (hh : 0 < x₀ 0) :
    ∃ F : Family (μ:=μ) hBm a p x₀,
      (∀ ω, 0 < F.lifetime ω) ∧
      ∀ᵐ ω ∂μ,
        limsup (fun t => ((F.process t ω 1+F.process t ω 2-x₀ 1-x₀ 2)/2/scale t).toEReal)
          (𝓝[>] (0:ℝ≥0)) = |crownDiffusion a x₀| ∧
        liminf (fun t => ((F.process t ω 1+F.process t ω 2-x₀ 1-x₀ 2)/2/scale t).toEReal)
          (𝓝[>] (0:ℝ≥0)) = -|crownDiffusion a x₀| := by
  obtain ⟨F⟩ := exists_family hB hBm hBc a p hp plo phi hpmem x₀ hh
  exact ⟨F,F.lifetime_positive,maximal_crown_lil hB hBc F⟩

end
end ChainFountainStochastic.MechanicalSmallTime
