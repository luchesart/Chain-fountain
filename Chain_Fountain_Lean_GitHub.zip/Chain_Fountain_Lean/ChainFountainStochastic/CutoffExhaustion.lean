import ChainFountainStochastic.GaugeExit
namespace ChainFountainStochastic.CutoffExhaustion
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralProcessLocalMartingaleGeneral
open VectorSDE GlobalCutoffSDE MechanicalCutoff MechanicalExhaustion GlobalLocalization
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1000000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}

/-- A sequence of actual globally constructed cutoffs, including their strong
solutions and continuous adapted representatives. Compatibility is proved by
`exists_family`; it is not an input to the mechanical existence theorem. -/
structure Family (hBm : ∀ t, Measurable (B t)) (a : Parameters)
    (p : ℝ≥0 → State) (x₀ : State) where
  R : ℝ
  radius_gt : 1 < R
  initial_inside : |gauge R x₀| < 1
  c : ℕ → Coefficients (Fin 3)
  drift_bound : ∀ n t x, ‖(c n).drift t x‖ ≤ (c n).bound
  clamped_drift : ∀ n t x, (c n).drift t x = a.drift (p t,boxClamp (lower ((n:ℝ)+R)) (upper ((n:ℝ)+R)) x)
  clamped_diffusion : ∀ n t x, (c n).diffusion t x = a.diffusion (p t,boxClamp (lower ((n:ℝ)+R)) (upper ((n:ℝ)+R)) x)
  bound : ∀ n t x, ‖(c n).diffusion t x‖ ≤ (c n).bound
  agrees : ∀ (n : ℕ) t x, |gauge ((n:ℝ)+R) x| ≤ 1 →
    (c n).drift t x = a.drift (p t,x) ∧ (c n).diffusion t x = a.diffusion (p t,x)
  Y : ℕ → ℝ≥0 → Ω → State
  strong : ∀ n, GlobalStrongSolution (μ:=μ) hBm (c n) x₀ (Y n)
  X : ℕ → ℝ≥0 → Ω → State
  adapted : ∀ n, StronglyAdapted (augFiltration (μ:=μ) hBm) (X n)
  continuous : ∀ n ω, Continuous (fun t => X n t ω)
  initial : ∀ n ω, X n 0 ω = x₀
  version : ∀ n, ∀ᵐ ω ∂μ, ∀ t, X n t ω = Y n t ω
  compatible : ∀ᵐ ω ∂μ, ∀ n m : ℕ, n ≤ m →
    gaugeExit (X n) (gauge ((n:ℝ)+R)) ω = gaugeExit (X m) (gauge ((n:ℝ)+R)) ω ∧
    ∀ t, stoppedProcess (X n) (gaugeExit (X n) (gauge ((n:ℝ)+R))) t ω =
      stoppedProcess (X m) (gaugeExit (X m) (gauge ((n:ℝ)+R))) t ω

theorem radius_initial_inside {R : ℝ} (hR : 1 < R) {x₀ : State}
    (hi : |gauge R x₀| < 1) (n : ℕ) : |gauge ((n:ℝ)+R) x₀| < 1 := by
  by_cases hn : n = 0
  · simpa only [hn,Nat.cast_zero,zero_add] using hi
  · have hnpos : (0:ℝ) < n := by exact_mod_cast Nat.pos_of_ne_zero hn
    exact gauge_strict_nesting (by linarith : 0 < R) (by linarith : R < (n:ℝ)+R) hi.le

theorem radius_nesting {R : ℝ} (hR : 1 < R) {n m : ℕ} (hnm : n ≤ m)
    {x : State} (hx : |gauge ((n:ℝ)+R) x| ≤ 1) : |gauge ((m:ℝ)+R) x| ≤ 1 := by
  rcases hnm.eq_or_lt with he | hl
  · simpa only [he] using hx
  · have hlt : (n:ℝ) < (m:ℝ) := by exact_mod_cast hl
    exact (gauge_strict_nesting (by positivity : 0 < (n:ℝ)+R)
      (by linarith : (n:ℝ)+R < (m:ℝ)+R) hx).le

/-- Construct the full countable family from positive initial height and the
actual mechanical coefficients. No trajectories or exit sequence are supplied. -/
theorem exists_family
    (hB : IsPreBrownianReal B μ) (hBm : ∀ t, Measurable (B t))
    (hBc : ∀ ω, Continuous (fun t => B t ω))
    (a : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi : State) (hpmem : ∀ t, p t ∈ Icc plo phi)
    (x₀ : State) (hh : 0 < x₀ 0) : Nonempty (Family (μ:=μ) hBm a p x₀) := by
  obtain ⟨R,hR,hi⟩ := exists_initial_radius x₀ hh
  have hrad (n : ℕ) : 1 < (n:ℝ)+R := by have := Nat.cast_nonneg (α:=ℝ) n; linarith
  have hpos (n : ℕ) : 0 < (n:ℝ)+R := by linarith [hrad n]
  have hex (n : ℕ) := a.exists_cutoff p hp plo phi
    (lower ((n:ℝ)+R)) (upper ((n:ℝ)+R))
    (cutoff_box_valid (hrad n)).1 (cutoff_box_valid (hrad n)).2 hpmem
  choose c hcl hcs hca hcb hbound using hex
  have hsol (n : ℕ) := exists_global_strong_solution hB hBm hBc (c n) x₀
    (fun t x => (hbound n t x).2)
  choose Y hY using hsol
  choose X hXa hXc hX₀ hXY using fun n => exists_global_continuous_adapted_version hBm (c n) x₀ (hY n)
  have hagree (n : ℕ) (t : ℝ≥0) (x : State) (hx : |gauge ((n:ℝ)+R) x| ≤ 1) :
      (c n).drift t x = a.drift (p t,x) ∧ (c n).diffusion t x = a.diffusion (p t,x) :=
    ⟨hca n t x (gauge_sublevel_box (hpos n) hx),hcb n t x (gauge_sublevel_box (hpos n) hx)⟩
  have hco (n m : ℕ) : ∀ᵐ ω ∂μ, n ≤ m →
      gaugeExit (X n) (gauge ((n:ℝ)+R)) ω = gaugeExit (X m) (gauge ((n:ℝ)+R)) ω ∧
      ∀ t, stoppedProcess (X n) (gaugeExit (X n) (gauge ((n:ℝ)+R))) t ω =
        stoppedProcess (X m) (gaugeExit (X m) (gauge ((n:ℝ)+R))) t ω := by
    by_cases hnm : n ≤ m
    · have he := global_versions_stopped_eq hB hBm hBc (c n) (c m) x₀
        (fun t x => (hbound n t x).2) (fun t x => (hbound m t x).2)
        (hY n) (hY m) (hXa n) (hXa m) (hXc n) (hXc m) (hX₀ n) (hX₀ m)
        (hXY n) (hXY m) (gauge ((n:ℝ)+R)) (gauge_continuous _)
        (radius_initial_inside hR hi n) (fun t x hx =>
          ⟨(hagree n t x hx).1.trans (hagree m t x (radius_nesting hR hnm hx)).1.symm,
           (hagree n t x hx).2.trans (hagree m t x (radius_nesting hR hnm hx)).2.symm⟩)
      exact he.mono (fun _ h _ => h)
    · exact ae_of_all _ (fun _ h => (hnm h).elim)
  exact ⟨{
    R := R
    radius_gt := hR
    initial_inside := hi
    c := c
    drift_bound := fun n t x => (hbound n t x).1
    clamped_drift := hcl
    clamped_diffusion := hcs
    bound := fun n t x => (hbound n t x).2
    agrees := hagree
    Y := Y
    strong := hY
    X := X
    adapted := hXa
    continuous := hXc
    initial := hX₀
    version := hXY
    compatible := ae_all_iff.mpr (fun n => ae_all_iff.mpr (hco n)) }⟩

variable {hBm : ∀ t, Measurable (B t)} {a : Parameters} {p : ℝ≥0 → State} {x₀ : State}

def Family.exit (F : Family (μ:=μ) hBm a p x₀) (n : ℕ) : Ω → WithTop ℝ≥0 :=
  gaugeExit (F.X n) (gauge ((n:ℝ)+F.R))

theorem Family.exit_properties (F : Family (μ:=μ) hBm a p x₀) (n : ℕ) :
    IsStoppingTime (augFiltration (μ:=μ) hBm) (F.exit n) ∧
      (∀ ω, ⊥ < F.exit n ω) ∧
      ∀ t ω, |gauge ((n:ℝ)+F.R) (stoppedProcess (F.X n) (F.exit n) t ω)| ≤ 1 :=
  gaugeExit_properties (F.adapted n) (F.continuous n) (gauge_continuous _)
    (F.initial n) (radius_initial_inside F.radius_gt F.initial_inside n)

/-- Countably many null sets are removed once, before choosing either the
localization index or the real time. -/
theorem Family.prefix_agreement (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ, ∀ n m : ℕ, n ≤ m → ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ F.exit n ω →
      F.X n t ω = F.X m t ω := by
  filter_upwards [F.compatible] with ω hω
  intro n m hnm t ht
  obtain ⟨hτ,he⟩ := hω n m hnm
  have ht' : (t:WithTop ℝ≥0) ≤ gaugeExit (F.X m) (gauge ((n:ℝ)+F.R)) ω := hτ ▸ ht
  change (t:WithTop ℝ≥0) ≤ gaugeExit (F.X n) (gauge ((n:ℝ)+F.R)) ω at ht
  simpa only [stoppedProcess_eq_of_le ht,stoppedProcess_eq_of_le ht'] using he t

/-- The genuine exits increase, strictly until infinity. -/
theorem Family.exits_increase (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ, Monotone (fun n => F.exit n ω) ∧
      ∀ n, F.exit n ω ≠ ⊤ → F.exit n ω < F.exit (n+1) ω := by
  filter_upwards [F.compatible] with ω hω
  have hstrict (n m : ℕ) (hnm : n < m) : F.exit n ω ≤ F.exit m ω ∧
      (F.exit n ω ≠ ⊤ → F.exit n ω < F.exit m ω) := by
    have he := (hω n m hnm.le).1
    have hp := (gaugeExit_properties (F.adapted m) (F.continuous m) (gauge_continuous ((n:ℝ)+F.R))
      (F.initial m) (radius_initial_inside F.radius_gt F.initial_inside n)).2.1
    have hn : 0 < (n:ℝ)+F.R := by have := F.radius_gt; positivity
    have hm : (n:ℝ)+F.R < (m:ℝ)+F.R := by
      have hnmc : (n:ℝ) < (m:ℝ) := by exact_mod_cast hnm
      linarith
    simpa only [Family.exit,he] using GaugeExit.strict_mono (F.continuous m)
      (gauge_continuous ((n:ℝ)+F.R)) (gauge_continuous ((m:ℝ)+F.R)) hp
      (fun x hx => gauge_strict_nesting hn hm hx) ω
  refine ⟨?_,fun n => (hstrict n (n+1) (Nat.lt_succ_self n)).2⟩
  intro n m hnm
  rcases hnm.eq_or_lt with rfl | hlt
  · exact le_rfl
  · exact (hstrict n m hlt).1

end
end ChainFountainStochastic.CutoffExhaustion
