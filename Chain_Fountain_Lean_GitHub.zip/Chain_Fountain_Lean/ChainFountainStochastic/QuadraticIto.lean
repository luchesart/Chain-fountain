/-
Copyright (c) 2026 Latchezar Tomov. All rights reserved.
Released under Apache 2.0 license as described in LICENSE.
-/
module
public import MathFin.Foundations.ItoFormulaAdaptedProcess
public import MathFin.Foundations.BoundedLocalMartingale
@[expose] public section

namespace ChainFountainStochastic
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory MathFin
open MathFin.ItoIntegralL2 MathFin.ItoFormulaAdapted
open MathFin.ItoIntegralProcessLocalMartingaleGeneral
open scoped NNReal Topology

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
  {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
  (hBmeas : ∀ t, Measurable (B t)) (hBcont : ∀ ω, Continuous (fun t => B t ω))
  {σ b : ℝ≥0 → Ω → ℝ}
  (hσad : ∀ t, StronglyMeasurable[natFiltration hBmeas t] (σ t))
  (hσc : ∀ ω, Continuous (fun t => σ t ω))
  (hbad : ∀ t, StronglyMeasurable[natFiltration hBmeas t] (b t))
  (hbc : ∀ ω, Continuous (fun t => b t ω)) (z₀ : ℝ)

include hB hBcont hbad hbc in
/-- The quadratic Itô decomposition is derived from the constructed Brownian
stochastic integral. No partition-limit or martingale-decomposition hypothesis
occurs in the statement. The drift and diffusion coefficients may be unbounded.
This is a finite-horizon scalar Itô-process theorem, not SDE existence. -/
theorem quadratic_ito_localMartingale :
    ∃ M : ℝ≥0 → Ω → ℝ,
      (∀ᵐ ω ∂μ, ∀ t∈Icc 0 T,
        (localItoProcess (μ:=μ) T hBmeas hσad hσc z₀ b t ω)^2/8 = z₀^2/8 +
          (∫ s in Ioc 0 t,
            (localItoProcess (μ:=μ) T hBmeas hσad hσc z₀ b s ω)*b s ω/4 +
              (σ s ω)^2/8 ∂timeMeasure) + M t ω) ∧
      (∀ ω, Continuous (fun t => M t ω)) ∧
      IsLocalMartingale M (augFiltration (μ:=μ) hBmeas) μ := by
  have hf₁ (t x : ℝ) : HasDerivAt (fun _ : ℝ => x^2/8) 0 t := hasDerivAt_const _ _
  have hf₂ (t x : ℝ) : HasDerivAt (fun x : ℝ => x^2/8) (x/4) x := by
    convert! ((hasDerivAt_id x).pow 2).div_const 8 using 1 <;> simp [id_eq] <;> ring
  have hf₃ (t x : ℝ) : HasDerivAt (fun x : ℝ => x/4) (1/4) x := by
    simpa using (hasDerivAt_id x).div_const 4
  obtain ⟨M,hM,hMc,hMl⟩ := exists_localMartingale_ito_formula hB T hBmeas hBcont
    hσad hσc hbad hbc z₀ (f:=fun _ x => x^2/8) (f_t:=fun _ _ => 0)
    (f_x:=fun _ x => x/4) (f_xx:=fun _ _ => 1/4)
    hf₁ hf₂ hf₃ continuous_const (by fun_prop) continuous_const
  refine ⟨M,?_,hMc,hMl⟩
  filter_upwards [hM] with ω hω t ht
  have heq : (∫ s in Ioc 0 t,
      0+(localItoProcess (μ:=μ) T hBmeas hσad hσc z₀ b s ω)/4*b s ω+
        1/2*((1/4)*(σ s ω)^2) ∂timeMeasure)=
      ∫ s in Ioc 0 t,
        (localItoProcess (μ:=μ) T hBmeas hσad hσc z₀ b s ω)*b s ω/4+
          (σ s ω)^2/8 ∂timeMeasure := by
    apply integral_congr_ae
    exact Eventually.of_forall (fun _ => by ring)
  have hm := hω t ht
  rw [heq] at hm
  linarith

end
end ChainFountainStochastic
