import ChainFountainStochastic.MechanicalCutoff
import ChainFountainStochastic.PhysicalExit
import ChainFountainStochastic.LocalIntegralBridge

namespace ChainFountainStochastic.ConstructedExit
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoLocalMartingale
  MathFin.ItoIntegralProcessLocalMartingaleGeneral
open VectorSDE MechanicalCutoff LocalIntegralBridge
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 600000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}

/-- Repair almost-sure path continuity using the null augmentation, retain the
deterministic initial state on every path, and freeze the process at the horizon.
No continuity or adaptedness is asserted for the original exceptional paths. -/
theorem exists_continuous_adapted_version
    {E : Type*} [NormedAddCommGroup E] [MeasurableSpace E] [BorelSpace E]
    {ℱ : Filtration ℝ≥0 mΩ} {Y : ℝ≥0 → Ω → E} {x₀ : E} {T : ℝ≥0}
    (hY : StronglyAdapted ℱ Y)
    (hc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => Y t ω) (Icc 0 T))
    (h₀ : ∀ ω, Y 0 ω = x₀) :
    ∃ X : ℝ≥0 → Ω → E,
      StronglyAdapted (nullAugmentation ℱ μ) X ∧
      (∀ ω, Continuous (fun t => X t ω)) ∧
      (∀ ω, X 0 ω = x₀) ∧
      (∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, X t ω = Y t ω) := by
  classical
  obtain ⟨G,hG,hGc,hGood⟩ := exists_nullsAlg_of_ae hc
  let X : ℝ≥0 → Ω → E := fun t ω => if ω ∈ G then Y (min t T) ω else x₀
  refine ⟨X,?_,?_,?_,?_⟩
  · intro t
    letI : MeasurableSpace Ω := nullAugmentation ℱ μ t
    have hGt : MeasurableSet[nullAugmentation ℱ μ t] G :=
      (le_sup_right : nullsAlg mΩ μ ≤ ℱ t ⊔ nullsAlg mΩ μ) G hG
    have hYX : StronglyMeasurable[nullAugmentation ℱ μ t] (Y (min t T)) :=
      (hY (min t T)).mono ((ℱ.mono (min_le_left t T)).trans
        (le_sup_left : ℱ t ≤ ℱ t ⊔ nullsAlg mΩ μ))
    exact StronglyMeasurable.ite hGt hYX stronglyMeasurable_const
  · intro ω
    by_cases hω : ω ∈ G
    · simpa only [X,if_pos hω,Function.comp_def,id_eq] using (hGood ω hω).comp_continuous
        (continuous_id.min continuous_const) (fun t => ⟨zero_le,min_le_right t T⟩)
    · simpa only [X,if_neg hω] using (continuous_const : Continuous (fun _ : ℝ≥0 => x₀))
  · intro ω
    simp [X,h₀]
  · have hGae : ∀ᵐ ω ∂μ, ω ∈ G := by rw [ae_iff]; exact hGc
    filter_upwards [hGae] with ω hω
    intro t ht
    simp only [X,if_pos hω,min_eq_left ht.2]

/-- First exit from a norm ball, capped at the finite construction horizon. -/
def normExit {E : Type*} [NormedAddCommGroup E]
    (X : ℝ≥0 → Ω → E) (x₀ : E) (R : ℝ) (T : ℝ≥0) (ω : Ω) : WithTop ℝ≥0 :=
  min (exitTime (fun t ω => ‖X t ω-x₀‖/R) 1 ω) T

/-- The actual exit of a continuous adapted finite-dimensional process is a
positive bounded stopping time and its stopped path stays in the closed ball. -/
theorem normExit_properties
    {E : Type*} [NormedAddCommGroup E] [MeasurableSpace E] [BorelSpace E]
    {ℱ : Filtration ℝ≥0 mΩ} {X : ℝ≥0 → Ω → E} {x₀ : E} {R : ℝ} {T : ℝ≥0}
    (hX : StronglyAdapted ℱ X) (hc : ∀ ω, Continuous (fun t => X t ω))
    (h₀ : ∀ ω, X 0 ω = x₀) (hR : 0 < R) (hT : 0 < T) :
    IsStoppingTime ℱ (normExit X x₀ R T) ∧
      (∀ ω, ⊥ < normExit X x₀ R T ω) ∧
      (∀ ω, normExit X x₀ R T ω ≤ T) ∧
      (∀ t ω, stoppedProcess X (normExit X x₀ R T) t ω ∈ Metric.closedBall x₀ R) := by
  let G : ℝ≥0 → Ω → ℝ := fun t ω => ‖X t ω-x₀‖/R
  have hGc : ∀ ω, Continuous (fun t => G t ω) :=
    fun ω => (((hc ω).sub continuous_const).norm).div_const R
  have hGm : ∀ t, Measurable[ℱ t] (G t) :=
    fun t => (((hX t).sub stronglyMeasurable_const).norm.div stronglyMeasurable_const).measurable
  have hτ := isStoppingTime_exitTime_of_measurable hGm hGc 1
  have hpos (ω : Ω) : ⊥ < exitTime G 1 ω := by
    apply lt_of_not_ge
    intro hn
    obtain ⟨s,hs,hg⟩ := (exitTime_le_iff hGc 1 0 ω).mp hn
    have hs0 : s = 0 := le_antisymm hs.2 zero_le
    norm_num [hs0,G,h₀] at hg
  refine ⟨hτ.min (isStoppingTime_const ℱ T),?_,fun _ => min_le_right _ _,?_⟩
  · intro ω
    exact lt_min (hpos ω) (by
      change ((0:ℝ≥0):WithTop ℝ≥0) < (T:WithTop ℝ≥0)
      exact WithTop.coe_lt_coe.mpr hT)
  · intro t ω
    have hb := abs_le_of_le_exitTime hGc (hpos ω)
      (s := (min (t:WithTop ℝ≥0) (normExit X x₀ R T ω)).untopA)
      (by rw [coe_untopA_min]; exact (min_le_right _ _).trans (min_le_left _ _))
    have hq := (le_abs_self _).trans hb
    change ‖X _ ω-x₀‖/R ≤ (1:ℕ) at hq
    have hn := (div_le_iff₀ hR).mp hq
    simpa only [Nat.cast_one,one_mul,Metric.mem_closedBall,dist_eq_norm,stoppedProcess] using hn

/-- Before the horizon the exit event is precisely a hit of the ball boundary
or exterior. This fixes the meaning of the constructed stopping time. -/
theorem normExit_le_iff
    {E : Type*} [NormedAddCommGroup E] {X : ℝ≥0 → Ω → E} {x₀ : E} {R : ℝ}
    (hc : ∀ ω, Continuous (fun t => X t ω)) (hR : 0 < R)
    {T t : ℝ≥0} (ht : t < T) (ω : Ω) :
    normExit X x₀ R T ω ≤ t ↔ ∃ s ∈ Icc 0 t, R ≤ dist (X s ω) x₀ := by
  have hGc : ∀ ω, Continuous (fun t => ‖X t ω-x₀‖/R) :=
    fun ω => (((hc ω).sub continuous_const).norm).div_const R
  have hnot : ¬ (T:WithTop ℝ≥0) ≤ t := by exact_mod_cast not_le.mpr ht
  rw [normExit,min_le_iff,or_iff_left hnot,exitTime_le_iff hGc]
  congr! 2 with s
  rw [abs_of_nonneg (div_nonneg (norm_nonneg _) hR.le),le_div_iff₀ hR]
  simp only [Nat.cast_one,one_mul,dist_eq_norm]

/-- On a common conull event the original strong solution remains inside the
localization ball up to the exit of its continuous adapted representative. -/
theorem original_state_mem_before_exit
    {E : Type*} [NormedAddCommGroup E]
    {X Y : ℝ≥0 → Ω → E} {x₀ : E} {R : ℝ} {T : ℝ≥0}
    (hτ : ∀ ω, normExit X x₀ R T ω ≤ T)
    (hb : ∀ t ω, stoppedProcess X (normExit X x₀ R T) t ω ∈ Metric.closedBall x₀ R)
    (he : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, X t ω = Y t ω) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ normExit X x₀ R T ω →
      Y t ω ∈ Metric.closedBall x₀ R := by
  filter_upwards [he] with ω hω
  intro t ht
  have htT : t ≤ T := WithTop.coe_le_coe.mp (ht.trans (hτ ω))
  rw [←hω t ⟨zero_le,htT⟩]
  simpa only [stoppedProcess_eq_of_le ht] using hb t ω

/-- The construction supplies a positive genuine stopping time for the
original mechanical fields. The integral solution is constructed, and the
coefficients agree with the original fields up to this random exit. This does
not assert compatibility of solutions obtained from different cutoffs. -/
theorem exists_constructed_mechanical_exit
    [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
    (hB : IsPreBrownianReal B μ) (hBm : ∀ t, Measurable (B t))
    (hBc : ∀ ω, Continuous (fun t => B t ω))
    (d : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi lo hi : State) (hlo : lo ≤ hi) (hh : 0 < lo 0)
    (hpmem : ∀ t, p t ∈ Icc plo phi) (x₀ : State) (R : ℝ) (hR : 0 < R)
    (hball : Metric.closedBall x₀ R ⊆ Icc lo hi) :
    ∃ c : Coefficients (Fin 3), ∃ T : ℝ≥0, 0 < T ∧
      ∃ Y X : ℝ≥0 → Ω → State,
        StrongSolution (μ:=μ) T hBm c x₀ Y ∧
        StronglyAdapted (augFiltration (μ:=μ) hBm) X ∧
        (∀ ω, Continuous (fun t => X t ω)) ∧
        (∀ ω, X 0 ω = x₀) ∧
        (∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, X t ω = Y t ω) ∧
        IsStoppingTime (augFiltration (μ:=μ) hBm) (normExit X x₀ R T) ∧
        (∀ ω, ⊥ < normExit X x₀ R T ω) ∧
        (∀ ω, normExit X x₀ R T ω ≤ T) ∧
        (∀ t ω, stoppedProcess X (normExit X x₀ R T) t ω ∈ Icc lo hi) ∧
        (∀ᵐ ω ∂μ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ normExit X x₀ R T ω →
          c.drift t (Y t ω) = d.drift (p t,Y t ω) ∧
          c.diffusion t (Y t ω) = d.diffusion (p t,Y t ω)) ∧
        (∃ hpred : IsStronglyPredictable (natFiltration hBm) Y,
          ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ normExit X x₀ R T ω → ∀ i : Fin 3,
          Y t ω i = x₀ i + (∫ s in Ioc (0:ℝ≥0) t, d.drift (p s,Y s ω) i ∂timeMeasure) +
            MathFin.ItoIntegralLocalised.predItoIntegral (μ:=μ) T hBm
              (diffusion_predictable hBm c hpred i) t ω) := by
  obtain ⟨c,_,_,hb,hσ,hbound⟩ := d.exists_cutoff p hp plo phi lo hi hlo hh hpmem
  obtain ⟨T,hT,Y,hY,_⟩ := exists_unique_local_strong_solution hB hBm hBc c x₀
  obtain ⟨X,hXm,hXc,hX₀,hXY⟩ := exists_continuous_adapted_version
    hY.predictable.stronglyAdapted hY.continuous hY.initial
  obtain ⟨hτ,hpos,hcap,hstop⟩ := normExit_properties hXm hXc hX₀ hR hT
  refine ⟨c,T,hT,Y,X,hY,hXm,hXc,hX₀,hXY,hτ,hpos,hcap,
    (fun t ω => hball (hstop t ω)),?_,?_⟩
  · filter_upwards [original_state_mem_before_exit hcap hstop hXY] with ω hω
    intro t ht
    exact ⟨hb t (Y t ω) (hball (hω t ht)),hσ t (Y t ω) (hball (hω t ht))⟩
  · refine ⟨hY.predictable,?_⟩
    filter_upwards [strong_solution_predIto_equation hB T hBm hBc c x₀ hY
      (fun t x => (hbound t x).2), original_state_mem_before_exit hcap hstop hXY]
      with ω he hm
    intro t ht i
    have htT : t ≤ T := WithTop.coe_le_coe.mp (ht.trans (hcap ω))
    have hi : (∫ s in Ioc (0:ℝ≥0) t, c.drift s (Y s ω) i ∂timeMeasure) =
        ∫ s in Ioc (0:ℝ≥0) t, d.drift (p s,Y s ω) i ∂timeMeasure := by
      apply setIntegral_congr_fun measurableSet_Ioc
      intro s hs
      exact congrFun (hb s (Y s ω) (hball (hm s ((WithTop.coe_le_coe.mpr hs.2).trans ht)))) i
    simpa only [hi] using he t ⟨zero_le,htT⟩ i

/-- Every positive-height initial state admits explicit finite cutoff boxes
containing a ball about that state. No pre-existing trajectory is required. -/
theorem exists_initial_localization_box (x₀ : State) (hh : 0 < x₀ 0) :
    ∃ lo hi : State, ∃ R : ℝ, 0 < R ∧ lo ≤ hi ∧ 0 < lo 0 ∧
      Metric.closedBall x₀ R ⊆ Icc lo hi := by
  let R := x₀ 0 / 2
  let lo : State := fun i => x₀ i - R
  let hi : State := fun i => x₀ i + R
  have hR : 0 < R := half_pos hh
  refine ⟨lo,hi,R,hR,(fun i => by dsimp [lo,hi]; linarith),?_,?_⟩
  · dsimp [lo,R]
    linarith
  · intro x hx
    have hn : ‖x-x₀‖ ≤ R := by simpa only [Metric.mem_closedBall,dist_eq_norm] using hx
    have hcoord (i : Fin 3) : |x i-x₀ i| ≤ R :=
      (norm_le_pi_norm (x-x₀) i).trans hn
    exact ⟨fun i => by have := (abs_le.mp (hcoord i)).1; dsimp [lo]; linarith,
      fun i => by have := (abs_le.mp (hcoord i)).2; dsimp [hi]; linarith⟩

end
end ChainFountainStochastic.ConstructedExit
