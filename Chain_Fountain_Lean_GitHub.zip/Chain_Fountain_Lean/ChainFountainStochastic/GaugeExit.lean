import ChainFountainStochastic.MechanicalExhaustion
namespace ChainFountainStochastic.GaugeExit
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open GlobalLocalization
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
variable {Ω E : Type*} [TopologicalSpace E]

/-- The first exit is attained when finite; it is not merely an arbitrary
stopping time bounded by an exit. -/
theorem boundary_of_finite {X : ℝ≥0 → Ω → E} {g : E → ℝ}
    (hX : ∀ ω, Continuous (fun t => X t ω)) (hg : Continuous g)
    (ω : Ω) (hf : gaugeExit X g ω ≠ ⊤) :
    1 ≤ |g (X (gaugeExit X g ω).untopA ω)| := by
  let u := (gaugeExit X g ω).untopA
  have hu : (u:WithTop ℝ≥0) = gaugeExit X g ω := by
    dsimp [u]; rw [WithTop.untopA_eq_untop hf]; exact WithTop.coe_untop _ _
  obtain ⟨s,hs,hb⟩ := (exitTime_le_iff (fun ω => hg.comp (hX ω)) 1 u ω).mp hu.ge
  have hτs : gaugeExit X g ω ≤ (s:WithTop ℝ≥0) :=
    (exitTime_le_iff (fun ω => hg.comp (hX ω)) 1 s ω).mpr ⟨s,⟨zero_le,le_rfl⟩,hb⟩
  have hus : u ≤ s := WithTop.coe_le_coe.mp (hu.symm ▸ hτs)
  have he : s = u := le_antisymm hs.2 hus
  simpa only [he,Nat.cast_one,Function.comp_apply,u] using hb

/-- Strict interior membership before the actual exit. -/
theorem interior_before {X : ℝ≥0 → Ω → E} {g : E → ℝ}
    (hX : ∀ ω, Continuous (fun t => X t ω)) (hg : Continuous g)
    (ω : Ω) {t : ℝ≥0} (ht : (t:WithTop ℝ≥0) < gaugeExit X g ω) :
    |g (X t ω)| < 1 := by
  by_contra hn
  have hb : 1 ≤ |g (X t ω)| := not_lt.mp hn
  exact not_le.mpr ht ((exitTime_le_iff (fun ω => hg.comp (hX ω)) 1 t ω).mpr
    ⟨t,⟨zero_le,le_rfl⟩,by simpa only [Function.comp_apply,Nat.cast_one] using hb⟩)

/-- Strict nesting of the closed regions gives strictly ordered finite exits
of the same continuous path. -/
theorem strict_mono {X : ℝ≥0 → Ω → E} {g h : E → ℝ}
    (hX : ∀ ω, Continuous (fun t => X t ω)) (hg : Continuous g) (hh : Continuous h)
    (hpos : ∀ ω, ⊥ < gaugeExit X g ω)
    (hsub : ∀ x, |g x| ≤ 1 → |h x| < 1) (ω : Ω) :
    gaugeExit X g ω ≤ gaugeExit X h ω ∧
      (gaugeExit X g ω ≠ ⊤ → gaugeExit X g ω < gaugeExit X h ω) := by
  by_cases hf : gaugeExit X h ω = ⊤
  · rw [hf]
    exact ⟨le_top,fun hn => lt_top_iff_ne_top.mpr hn⟩
  · have hn : ¬ gaugeExit X h ω ≤ gaugeExit X g ω := by
      intro hle
      have hu : (((gaugeExit X h ω).untopA):WithTop ℝ≥0) = gaugeExit X h ω := by
        rw [WithTop.untopA_eq_untop hf]; exact WithTop.coe_untop _ _
      have hin : |g (X (gaugeExit X h ω).untopA ω)| ≤ 1 :=
        by
          simpa only [Function.comp_apply,Nat.cast_one] using
            abs_le_of_le_exitTime (fun ω => hg.comp (hX ω)) (hpos ω) (s := (gaugeExit X h ω).untopA) (hu.symm ▸ hle)
      exact not_le.mpr (hsub _ hin) (boundary_of_finite hX hh ω hf)
    exact ⟨(not_le.mp hn).le,fun _ => not_le.mp hn⟩

end
end ChainFountainStochastic.GaugeExit
