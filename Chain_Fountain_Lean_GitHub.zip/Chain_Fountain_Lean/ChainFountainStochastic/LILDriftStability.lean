import ChainFountainStochastic.BrownianSmallTime

namespace ChainFountainStochastic.LILDriftStability
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Real BrownianSmallTime
open scoped NNReal ENNReal Topology
set_option maxHeartbeats 600000
set_option backward.isDefEq.respectTransparency false

/-- The LIL scale dominates linear drift near zero. -/
theorem time_div_scale_zero :
    Tendsto (fun t : ℝ≥0 => (t:ℝ)/scale t) (𝓝[>] 0) (𝓝 0) := by
  have ht : Tendsto (fun t : ℝ≥0 => (t:ℝ)) (𝓝[>] 0) (𝓝 0) :=
    (NNReal.continuous_coe.tendsto 0).mono_left nhdsWithin_le_nhds
  have hlog : Tendsto (fun t : ℝ≥0 => log (log (1/(t:ℝ)))) (𝓝[>] 0) atTop := by
    simpa only [NNReal.coe_inv,one_div,Function.comp_def] using
      tendsto_log_atTop.comp (tendsto_log_atTop.comp
        (NNReal.tendsto_coe_atTop.mpr (tendsto_inv_nhdsGT_zero (𝕜:=ℝ≥0))))
  apply squeeze_zero' (Eventually.of_forall fun t => by positivity [sqrt_nonneg (2*(t:ℝ)*log (log (1/(t:ℝ))))])
    ?_ (by simpa using ht.sqrt)
  filter_upwards [hlog.eventually_ge_atTop 1,self_mem_nhdsWithin] with t hlog htpos
  have hp : (0:ℝ) < t := htpos
  have hs : sqrt (t:ℝ) ≤ scale t := by
    apply sqrt_le_sqrt
    nlinarith
  have hspos := lt_of_lt_of_le (sqrt_pos.mpr hp) hs
  apply (div_le_iff₀ hspos).mpr
  calc
    (t:ℝ) = sqrt (t:ℝ) * sqrt (t:ℝ) := (mul_self_sqrt t.coe_nonneg).symm
    _ ≤ _ := mul_le_mul_of_nonneg_left hs (sqrt_nonneg _)

/-- A pathwise O(t) perturbation is negligible at the sharp LIL scale.
The bound may depend on the sample path. -/
theorem bounded_drift_negligible {A : ℝ≥0 → ℝ} {K : ℝ}
    (hA : ∀ᶠ t in 𝓝[>] (0:ℝ≥0), |A t| ≤ K*(t:ℝ)) :
    Tendsto (fun t => A t/scale t) (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
  apply squeeze_zero_norm' ?_ (by simpa using time_div_scale_zero.const_mul K)
  filter_upwards [hA] with t ht
  rw [Real.norm_eq_abs, abs_div, abs_of_nonneg (show 0 ≤ scale t from sqrt_nonneg _)]
  calc
    _ ≤ (K*(t:ℝ))/scale t := div_le_div_of_nonneg_right ht (sqrt_nonneg _)
    _ = _ := by ring

/-- Addition of a real-valued term tending to zero preserves EReal limsup. -/
theorem limsup_add_zero {ι : Type*} {f : Filter ι} [NeBot f]
    {u : ι → EReal} {v : ι → ℝ} (hv : Tendsto v f (𝓝 0)) :
    limsup (fun t => u t + (v t:EReal)) f = limsup u f := by
  have he : Tendsto (fun t => (v t:EReal)) f (𝓝 0) := by
    simpa only [Function.comp_def,EReal.coe_zero] using
      continuous_coe_real_ereal.continuousAt.tendsto.comp hv
  have hsup := he.limsup_eq
  have hinf := he.liminf_eq
  apply le_antisymm
  · have h := EReal.limsup_add_le (u:=u) (v:=fun t => (v t:EReal)) (f:=f)
      (Or.inr (by rw [hsup]; simp)) (Or.inr (by rw [hsup]; simp))
    simpa only [hsup,add_zero,Pi.add_def] using h
  · have h := EReal.le_limsup_add (u:=u) (v:=fun t => (v t:EReal)) (f:=f)
    simpa only [hinf,add_zero,Pi.add_def] using h

/-- Addition of a real-valued term tending to zero preserves EReal liminf. -/
theorem liminf_add_zero {ι : Type*} {f : Filter ι} [NeBot f]
    {u : ι → EReal} {v : ι → ℝ} (hv : Tendsto v f (𝓝 0)) :
    liminf (fun t => u t + (v t:EReal)) f = liminf u f := by
  have he : Tendsto (fun t => (v t:EReal)) f (𝓝 0) := by
    simpa only [Function.comp_def,EReal.coe_zero] using
      continuous_coe_real_ereal.continuousAt.tendsto.comp hv
  have hsup := he.limsup_eq
  have hinf := he.liminf_eq
  apply le_antisymm
  · have h := EReal.liminf_add_le (u:=fun t => (v t:EReal)) (v:=u) (f:=f)
      (Or.inl (by rw [hsup]; simp)) (Or.inl (by rw [hsup]; simp))
    simpa only [hsup,zero_add,Pi.add_def,add_comm,add_zero] using h
  · have h := EReal.le_liminf_add (u:=u) (v:=fun t => (v t:EReal)) (f:=f)
    simpa only [hinf,add_zero,Pi.add_def] using h

/-- On one probability-one event, every nonnegative constant diffusion and
every pathwise linearly bounded drift obey both sharp small-time LIL limits. -/
theorem affine_lil {Ω : Type*} [MeasurableSpace Ω] {P : Measure Ω}
    {B : ℝ≥0 → Ω → ℝ} (hB : IsBrownianReal B P) :
    ∀ᵐ ω ∂P, ∀ σ : ℝ, 0 ≤ σ → ∀ A : ℝ≥0 → ℝ, ∀ K : ℝ,
      (∀ᶠ t in 𝓝[>] (0:ℝ≥0), |A t| ≤ K*(t:ℝ)) →
      limsup (fun t => ((σ*B t ω+A t)/scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = σ ∧
      liminf (fun t => ((σ*B t ω+A t)/scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = -σ := by
  filter_upwards [two_sided_zero hB] with ω hω
  intro σ hσ A K hA
  have ha := bounded_drift_negligible hA
  have he (t : ℝ≥0) : ((σ*B t ω+A t)/scale t).toEReal =
      (σ:EReal)*(B t ω/scale t).toEReal + (A t/scale t).toEReal := by
    rw [add_div,mul_div_assoc,EReal.coe_add,EReal.coe_mul]
  simp_rw [he]
  rw [limsup_add_zero ha,liminf_add_zero ha,
    EReal.limsup_const_mul_of_nonneg_of_ne_top (by exact_mod_cast hσ) (by simp),
    EReal.liminf_const_mul_of_nonneg_of_ne_top (by exact_mod_cast hσ) (by simp),hω.1,hω.2]
  simp

end
end ChainFountainStochastic.LILDriftStability
