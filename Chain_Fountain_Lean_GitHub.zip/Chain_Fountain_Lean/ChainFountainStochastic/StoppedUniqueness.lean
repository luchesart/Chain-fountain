import ChainFountainStochastic.PrefixLimits

namespace ChainFountainStochastic.StoppedUniqueness
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM
  MathFin.ItoIntegralProcessContinuousModification MathFin.ItoIntegralProcessGeneral
  MathFin.ItoIntegralLocalised MathFin.LocalisationInMeasure
open VectorSDE VectorLp LocalIntegralBridge PrefixLimits
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 900000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The continuous predictable representative of one coupled Picard step. -/
def picardPath (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (c : Coefficients ι) (x₀ : ι → ℝ) (X : ProcessLp (μ:=μ) (ι:=ι) T hBm) :=
  fun t ω => x₀ + vectorDrift T hBm (c.driftLp T hBm X) t ω +
    vectorIto T hBm (c.diffusionLp T hBm X) t ω

theorem picardPath_predictable
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (X : ProcessLp (μ:=μ) (ι:=ι) T hBm) :
    IsStronglyPredictable (natFiltration hBm) (picardPath T hBm c x₀ X) :=
  (stronglyMeasurable_const.add (vectorDrift_predictable T hBm _)).add
    (vectorIto_predictable hB T hBm hBc _)

theorem picardPath_continuous
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (X : ProcessLp (μ:=μ) (ι:=ι) T hBm) :
    ∀ᵐ ω ∂μ, ContinuousOn (fun t => picardPath T hBm c x₀ X t ω) (Icc 0 T) := by
  filter_upwards [vectorDrift_continuous T hBm (c.driftLp T hBm X),
    vectorIto_continuous hB T hBm hBc (c.diffusionLp T hBm X)] with ω hd hi
  exact (continuousOn_const.add hd).add hi

/-- A Picard step uses the actual coefficients of any continuous predictable
representative of its input class. -/
theorem picardPath_equation
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (X : ProcessLp (μ:=μ) (ι:=ι) T hBm)
    {U : ℝ≥0 → Ω → (ι → ℝ)}
    (hUp : IsStronglyPredictable (natFiltration hBm) U)
    (hUc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => U t ω) (Icc 0 T))
    (hX : ⇑X =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry U)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, ∀ i : ι,
      picardPath T hBm c x₀ X t ω i = x₀ i +
        (∫ s in Ioc (0:ℝ≥0) t, c.drift s (U s ω) i ∂timeMeasure) +
        predItoIntegral (μ:=μ) T hBm (diffusion_predictable hBm c hUp i) t ω := by
  have hd : ⇑(c.driftLp T hBm X) =ᵐ[trimMeasure_T (μ:=μ) T hBm]
      fun z => c.drift z.1 (U z.1 z.2) := by
    filter_upwards [coefficientLp_coe (mα := (natFiltration hBm).predictable)
      (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.drift_continuous
      c.drift_lipschitz (fun z : ℝ≥0 × Ω => c.drift_zero z.1) X,hX] with z hz hX
    exact hz.trans (congrArg (c.drift z.1) hX)
  have hs : ⇑(c.diffusionLp T hBm X) =ᵐ[trimMeasure_T (μ:=μ) T hBm]
      fun z => c.diffusion z.1 (U z.1 z.2) := by
    filter_upwards [coefficientLp_coe (mα := (natFiltration hBm).predictable)
      (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.diffusion_continuous
      c.diffusion_lipschitz (fun z : ℝ≥0 × Ω => c.diffusion_zero z.1) X,hX] with z hz hX
    exact hz.trans (congrArg (c.diffusion z.1) hX)
  have hi (i : ι) : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      vectorIto T hBm (c.diffusionLp T hBm X) t ω i =
        predItoIntegral (μ:=μ) T hBm (diffusion_predictable hBm c hUp i) t ω := by
    apply continuousMod_eq_predIto hB T hBm hBc (diffusion_predictable hBm c hUp i)
    · filter_upwards [hUc] with ω hω
      exact (continuous_apply i).comp_continuousOn
        (c.diffusion_continuous.comp_continuousOn (continuousOn_id.prodMk hω))
    · intro t ω
      exact (norm_le_pi_norm (c.diffusion t (U t ω)) i).trans (hb t (U t ω))
    · filter_upwards [evalLp_coe (mα := (natFiltration hBm).predictable)
        (trimMeasure_T (μ:=μ) T hBm) i (c.diffusionLp T hBm X),hs] with z hz hs
      exact hz.trans (congrFun hs i)
  filter_upwards [vectorDrift_integral_all_times T hBm (c.driftLp T hBm X) hd,
    ae_all_iff.mpr hi] with ω hd hi
  intro t ht i
  change x₀ i + vectorDrift T hBm (c.driftLp T hBm X) t ω i +
    vectorIto T hBm (c.diffusionLp T hBm X) t ω i = _
  rw [hd t ht.2 i,hi i t ht]

/-- If an input already agrees with a solution on a random prefix, one Picard
step preserves that agreement, provided the two coefficient fields agree along
the comparison solution there. This is proved using integral locality. -/
theorem picardPath_preserves_prefix
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c d : Coefficients ι) (x₀ : ι → ℝ)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖d.diffusion t x‖ ≤ d.bound)
    {Z U : ℝ≥0 → Ω → (ι → ℝ)} (hZ : StrongSolution (μ:=μ) T hBm d x₀ Z)
    (X : ProcessLp (μ:=μ) (ι:=ι) T hBm)
    (hUp : IsStronglyPredictable (natFiltration hBm) U)
    (hUc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => U t ω) (Icc 0 T))
    (hX : ⇑X =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry U)
    (τ : Ω → ℝ≥0)
    (hcoeff : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω →
      c.drift t (Z t ω) = d.drift t (Z t ω) ∧
      c.diffusion t (Z t ω) = d.diffusion t (Z t ω))
    (he : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω → U t ω = Z t ω) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω →
      picardPath T hBm c x₀ X t ω = Z t ω := by
  have hlocal (i : ι) := predIto_prefix_locality hB T hBm hBc
    (diffusion_predictable hBm c hUp i) (diffusion_predictable hBm d hZ.predictable i)
    (hUc.mono fun ω hω => (continuous_apply i).comp_continuousOn
      (c.diffusion_continuous.comp_continuousOn (continuousOn_id.prodMk hω)))
    (hZ.continuous.mono fun ω hω => (continuous_apply i).comp_continuousOn
      (d.diffusion_continuous.comp_continuousOn (continuousOn_id.prodMk hω)))
  filter_upwards [picardPath_equation hB T hBm hBc c x₀ X hUp hUc hX hb,
    strong_solution_predIto_equation hB T hBm hBc d x₀ hZ hd,
    ae_all_iff.mpr hlocal,hcoeff,he] with ω hP hZ hl hc he
  intro t ht hτ
  ext i
  rw [hP t ht i,hZ t ht i]
  have hpre (s : ℝ≥0) (hs : s ∈ Icc 0 t) : s ∈ Icc 0 T ∧ s ≤ τ ω :=
    ⟨⟨hs.1,hs.2.trans ht.2⟩,hs.2.trans hτ⟩
  have hi := hl i t ht (fun s hs => by
    rw [he s (hpre s hs).1 (hpre s hs).2]
    exact congrFun (hc s (hpre s hs).1 (hpre s hs).2).2 i)
  rw [hi]
  congr 2
  apply setIntegral_congr_fun measurableSet_Ioc
  intro s hs
  have hs' : s ∈ Icc 0 t := ⟨hs.1.le,hs.2⟩
  change c.drift s (U s ω) i = d.drift s (Z s ω) i
  rw [he s (hpre s hs').1 (hpre s hs').2]
  exact congrFun (hc s (hpre s hs').1 (hpre s hs').2).1 i

/-- Pathwise uniqueness before any random prefix on which the coefficient
fields agree along the comparison solution. Neither the equality of solutions
nor a stopped energy estimate is assumed. -/
theorem strong_solution_prefix_unique
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c d : Coefficients ι) (x₀ : ι → ℝ)
    (hc : contractionFactor c T < 1)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖d.diffusion t x‖ ≤ d.bound)
    {Y Z : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hZ : StrongSolution (μ:=μ) T hBm d x₀ Z)
    (τ : Ω → ℝ≥0)
    (hcoeff : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω →
      c.drift t (Z t ω) = d.drift t (Z t ω) ∧
      c.diffusion t (Z t ω) = d.diffusion t (Z t ω)) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω → Y t ω = Z t ω := by
  let f := picard hB T hBm hBc c x₀
  let Z₀ := hZ.state_memLp.toLp (Function.uncurry Z)
  let Yn (n : ℕ) := picardPath T hBm c x₀ (f^[n] Z₀)
  have hcoe (n : ℕ) : ⇑(f^[n+1] Z₀) =ᵐ[trimMeasure_T (μ:=μ) T hBm]
      Function.uncurry (Yn n) := by
    unfold Yn picardPath Function.uncurry
    simpa only [Function.iterate_succ_apply',f] using
      picard_coe hB T hBm hBc c x₀ (f^[n] Z₀)
  have he (n : ℕ) : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω → Yn n t ω = Z t ω := by
    induction n with
    | zero =>
      exact picardPath_preserves_prefix hB T hBm hBc c d x₀ hb hd hZ Z₀
        hZ.predictable hZ.continuous hZ.state_memLp.coeFn_toLp τ hcoeff
        (ae_of_all _ fun _ _ _ _ => rfl)
    | succ n ih =>
      exact picardPath_preserves_prefix hB T hBm hBc c d x₀ hb hd hZ (f^[n+1] Z₀)
        (picardPath_predictable hB T hBm hBc c x₀ _) (picardPath_continuous hB T hBm hBc c x₀ _)
        (hcoe n) τ hcoeff ih
  have hq : 0 ≤ contractionFactor c T := by dsimp [contractionFactor]; positivity
  have hf : ContractingWith (Real.toNNReal (contractionFactor c T)) f := by
    refine ⟨?_,LipschitzWith.of_dist_le_mul fun X Y => ?_⟩
    · rw [←NNReal.coe_lt_coe,Real.coe_toNNReal _ hq,NNReal.coe_one]; exact hc
    · rw [dist_eq_norm,dist_eq_norm,Real.coe_toNNReal _ hq]
      exact picard_sub_norm_le hB T hBm hBc c x₀ X Y
  have hfix : hf.fixedPoint f = hY.state_memLp.toLp (Function.uncurry Y) :=
    (hf.fixedPoint_unique (hY.fixed_point hB T hBm hBc c x₀)).symm
  have hlim : Tendsto (fun n => f^[n+1] Z₀) atTop
      (𝓝 (hY.state_memLp.toLp (Function.uncurry Y))) := by
    rw [←hfix]
    exact (hf.tendsto_iterate_fixedPoint Z₀).comp (tendsto_add_atTop_nat 1)
  exact prefix_agreement_of_tendsto_Lp T hBm (fun n => f^[n+1] Z₀) _ hlim
    hcoe hY.state_memLp.coeFn_toLp hY.continuous hZ.continuous
    (fun ω => (hY.initial ω).trans (hZ.initial ω).symm) τ he

end
end ChainFountainStochastic.StoppedUniqueness
