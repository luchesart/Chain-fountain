import ChainFountainStochastic.ItoMaximal
import ChainFountainStochastic.BrownianSmallTime
import ChainFountainStochastic.LocalIntegralBridge

namespace ChainFountainStochastic.ItoSmallTimeBound
noncomputable section
open MeasureTheory ProbabilityTheory Real Filter Set
open scoped NNReal ENNReal Topology
set_option maxHeartbeats 1000000
set_option backward.isDefEq.respectTransparency true
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ} {X : ℝ≥0 → Ω → ℝ} {C : ℝ}

/-- A Gaussian running-maximum estimate implies a coarse pathwise LIL upper
bound. Its constant need not be sharp: it will be applied to arbitrarily small
clipped residual coefficients. -/
theorem upper (hC : 0 < C)
    (hm : ∀ (T : ℝ≥0), 0 < T → ∀ a : ℝ, 0 ≤ a →
      μ.real {ω | (a:EReal) ≤ ⨆ s ≤ T, (X s ω:EReal)} ≤
        exp (-(a^2)/(2*C^2*(T:ℝ)))) :
    ∀ᵐ ω ∂μ, ∀ᶠ t in 𝓝[>] (0:ℝ≥0), X t ω / BrownianSmallTime.scale t ≤ 4*C := by
  let f := fun (t : ℝ≥0) => sqrt (2*(t:ℝ)*log (log (t:ℝ)))
  let M := fun t ω => ⨆ s ≤ t, (X s ω:EReal)
  have fmono : MonotoneOn f (Ici (⟨exp 1,by positivity⟩)) := by
    intro x hx y hy hxy
    have hx0 : (0 < x) := lt_of_lt_of_le (exp_pos _) hx
    have hx1 : 1 ≤ log x := by rwa [← exp_le_exp,exp_log (by positivity)]
    apply sqrt_le_sqrt
    apply mul_le_mul (by bound) _ (log_nonneg hx1) (by bound)
    exact log_le_log (by positivity) (log_le_log hx0 hxy)
  have hbc : ∀ᵐ ω ∂μ, ∀ᶠ n : ℕ in atTop,
      ω ∉ {ω | (2*C*f (2^n)/(2:ℝ)^n).toEReal ≤ M ((2:ℝ≥0)^n)⁻¹ ω} := by
    have hs : Summable (fun n : ℕ => μ.real
        {ω | (2*C*f (2^n)/(2:ℝ)^n).toEReal ≤ M (((2:ℝ≥0)^n)⁻¹) ω}) := by
      apply Summable.of_nonneg_of_le (fun _ => measureReal_nonneg)
        (fun n => hm ((2:ℝ≥0)^n)⁻¹ (by positivity) _ (by positivity))
      apply summable_of_isBigO_nat (summable_nat_rpow_inv.2 (by norm_num : (1:ℝ) < 4))
      apply Asymptotics.IsBigO.of_bound ((log 2)^4)⁻¹
      have hlarge : ∀ᶠ n : ℕ in atTop, 1 ≤ log ((2:ℝ)^n) :=
        (tendsto_log_atTop.comp (tendsto_pow_atTop_atTop_of_one_lt (by norm_num : (1:ℝ) < 2))).eventually_ge_atTop 1
      filter_upwards [hlarge,eventually_ge_atTop 1] with n hnlog hn
      repeat rw [norm_of_nonneg (by positivity)]
      apply le_of_eq
      have hn0 : (2:ℝ)^n ≠ 0 := by positivity
      have hx : -((2*C*f (2^n)/(2:ℝ)^n)^2)/(2*C^2*(((2:ℝ≥0)^n)⁻¹:ℝ≥0)) =
          -4*log (log ((2:ℝ)^n)) := by
        dsimp [f]
        push_cast
        rw [div_pow,mul_pow,mul_pow,sq_sqrt (by positivity [log_nonneg hnlog])]
        field_simp
        <;> ring
      rw [hx]
      rw [show (-4:ℝ)*log (log ((2:ℝ)^n)) = -(4*log (log ((2:ℝ)^n))) by ring,
        exp_neg,mul_comm (4:ℝ),exp_mul,exp_log (lt_of_lt_of_le (by norm_num) hnlog),log_pow]
      rw [mul_rpow (by positivity : (0:ℝ) ≤ n) (log_pos (by norm_num : (1:ℝ) < 2)).le]
      simp [Real.rpow_natCast,mul_inv_rev]
    apply ae_eventually_notMem
    simpa only [Measure.real_def, ENNReal.ofReal_toReal (measure_ne_top μ _)] using hs.tsum_ofReal_ne_top
  filter_upwards [hbc] with ω hω
  rw [← inv_atTop₀]
  change ∀ᶠ t in map (fun t : ℝ≥0 => t⁻¹) atTop,
    X t ω / BrownianSmallTime.scale t ≤ 4*C
  rw [eventually_map]
  choose n htn1 htn2 using fun t : ℝ≥0 =>
    exists_nat_pow_near (x:=max 1 t) (y:=2) (by bound) (by norm_num)
  have hnt : Tendsto n atTop atTop := by
    apply Tendsto.atTop_of_add_const 1
    rw [tendsto_atTop]
    intro m
    filter_upwards [eventually_ge_atTop 1,eventually_ge_atTop ((2:ℝ≥0)^m)] with t ht1 ht2
    have h := htn2 t
    rw [max_eq_right ht1] at h
    rw [← pow_le_pow_iff_right₀ (by norm_num : (1:ℝ≥0) < 2)]
    exact (ht2.trans_lt h).le
  have hpow := (tendsto_pow_atTop_atTop_of_one_lt (by norm_num : (1:ℝ≥0) < 2)).comp hnt
  filter_upwards [hnt.eventually hω,eventually_ge_atTop 1,
    hpow.eventually_ge_atTop ⟨exp 1,by positivity⟩] with t ht ht1 hn3
  have ht0 : 0 < t := lt_of_lt_of_le (by norm_num) ht1
  have h1 := htn1 t
  have h2 := htn2 t
  rw [max_eq_right ht1] at h1 h2
  have hxt : X t⁻¹ ω < 2*C*f (2^n t)/(2:ℝ)^n t := by
    apply EReal.coe_lt_coe_iff.mp
    have hle : (X t⁻¹ ω:EReal) ≤ M (((2:ℝ≥0)^n t)⁻¹) ω := by
      apply le_iSup_of_le t⁻¹
      exact le_iSup_of_le (inv_anti₀ (by positivity : (0:ℝ≥0) < 2^n t) h1) le_rfl
    exact hle.trans_lt (lt_of_not_ge ht)
  rw [BrownianSmallTime.inversion_ratio t ht0.ne']
  apply div_le_of_le_mul₀ (by positivity) (by positivity)
  have hp : (0:ℝ) < (2:ℝ)^n t := by positivity
  have htR : (t:ℝ) < 2*(2:ℝ)^n t := by exact_mod_cast (by simpa [pow_succ,mul_comm] using h2)
  have hff : f (2^n t) ≤ f t := fmono hn3 (hn3.trans h1) h1
  calc
    (t:ℝ)*X t⁻¹ ω ≤ (t:ℝ)*(2*C*f (2^n t)/(2:ℝ)^n t) :=
      mul_le_mul_of_nonneg_left hxt.le t.coe_nonneg
    _ ≤ (2*(2:ℝ)^n t)*(2*C*f (2^n t)/(2:ℝ)^n t) :=
      mul_le_mul_of_nonneg_right htR.le (by positivity)
    _ = 4*C*f (2^n t) := by field_simp; ring
    _ ≤ 4*C*f t := mul_le_mul_of_nonneg_left hff (by positivity)

open MathFin MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM
open MathFin.ItoIntegralProcessContinuousModification MathFin.ItoIntegralProcessGeneral
open MathFin.ItoIntegralPredictable MathFin.ItoIntegralLocalised
open MathFin.ItoIntegralProcessLocalMartingaleGeneral MathFin.LocalisationInMeasure

/-- The genuine predictable integral inherits the two-sided coarse bound. -/
theorem pred_integral (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hT : 0 < T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
    {a : ℝ≥0 → Ω → ℝ}
    (ha : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hc : ∀ ω, Continuous (a · ω))
    (hp : IsStronglyPredictable (natFiltration hBm) a)
    (hC : 0 < C) (hb : ∀ t ω, |a t ω| ≤ C) :
    ∀ᵐ ω ∂μ, ∀ᶠ t in 𝓝[>] (0:ℝ≥0),
      |predItoIntegral (μ:=μ) T hBm hp t ω / BrownianSmallTime.scale t| ≤ 4*C := by
  obtain ⟨X,hv,hcX,hmX,he⟩ := ItoContinuousMartingale.exists_integral_martingale hB T hBm hBc ha hc hb
  have heNeg : ∀ q t, Integrable (fun ω => exp (q * (-X t ω))) μ ∧
      (∫ ω, exp (q * (-X t ω)) ∂μ) ≤ exp (q^2*C^2*(t:ℝ)/2) := by
    intro q t
    simpa only [neg_mul,mul_neg,neg_sq] using he (-q) t
  have heq : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      X t ω = predItoIntegral (μ:=μ) T hBm hp t ω := by
    have hxc : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
        X t ω = itoContinuousMod T hBm (processToLp (μ:=μ) T hBm ha hc hb) t ω := by
      apply ae_forall_eq_of_continuousOn (ae_of_all _ fun ω => (hcX ω).continuousOn)
        (itoContinuousMod_continuousOn hB T hBm hBc _)
      intro t ht
      have h := itoContinuousMod_modification hB T hBm hBc
        (processToLp (μ:=μ) T hBm ha hc hb) ht.2
      rw [itoProcessCLM_consist hB hBm le_rfl ht.2 ha hc hb,itoProcessCLM_terminal_eq] at h
      have hv' : X t =ᵐ[μ] itoIntCont hB hBm ha hc hb t := by
        simpa only [min_eq_left ht.2] using hv t
      exact hv'.trans h.symm
    filter_upwards [hxc,LocalIntegralBridge.continuousMod_eq_predIto hB T hBm hBc hp
      (ae_of_all _ fun ω => (hc ω).continuousOn) hb _ (processToLp_coeFn T hBm ha hc hb)] with ω h1 h2
    exact fun t ht => (h1 t ht).trans (h2 t ht)
  filter_upwards [heq,
    upper hC (fun T hT a ha => ItoMaximal.maximal_gaussian hmX hcX he hC hT ha),
    upper (X:=fun t ω => -X t ω) hC (fun T hT a ha =>
      ItoMaximal.maximal_gaussian hmX.neg (fun ω => (hcX ω).neg) heNeg hC hT ha)] with ω heq hu hl
  filter_upwards [hu,hl,((eventually_lt_nhds hT).filter_mono nhdsWithin_le_nhds)] with t hu hl ht
  rw [← heq t ⟨bot_le,ht.le⟩]
  exact abs_le.mpr ⟨by simpa only [neg_div,neg_le] using hl,hu⟩

end
end ChainFountainStochastic.ItoSmallTimeBound
