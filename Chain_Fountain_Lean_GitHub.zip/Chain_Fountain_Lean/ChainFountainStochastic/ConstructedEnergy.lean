import ChainFountainStochastic.RegularRealization
import ChainFountainStochastic.GeneralEnergyIto
namespace ChainFountainStochastic.ConstructedEnergy
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory MathFin ChainFountain
open MathFin.ItoIntegralL2 MathFin.ItoFormulaAdapted MathFin.AdaptedDrift
open MathFin.ItoIntegralProcessLocalMartingaleGeneral
open VectorSDE GlobalCutoffSDE MechanicalCutoff CutoffExhaustion ConullBrownian RegularRealization
open scoped NNReal Topology
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 2000000

def errorZ (a : Parameters) (p x : State) : ℝ :=
  x 1-x 2-2*p 1+2*a.k₁*(x 0-p 0)

def energy (a : Parameters) (p x : State) : ℝ :=
  trackingEnergy a.k₀ (x 0-p 0) (errorZ a p x)

def cutoffGenerator (a : Parameters) (p : ℝ≥0 → State)
    (c : Coefficients (Fin 3)) (t : ℝ≥0) (x : State) : ℝ :=
  a.k₀*(x 0-p t 0)*(c.drift t x 0-p t 1)+
    errorZ a (p t) x*(c.drift t x 1-c.drift t x 2-2*p t 2+
      2*a.k₁*(c.drift t x 0-p t 1))/4+(c.diffusion t x 1)^2/8

/-- The globally regular cutoff generator is the physical generator wherever
its coefficients agree with the mechanical system. -/
theorem cutoffGenerator_eq (a : Parameters) (p : ℝ≥0 → State)
    (c : Coefficients (Fin 3)) (t : ℝ≥0) (x : State)
    (hx : 0 < x 0)
    (hc : c.drift t x = a.drift (p t,x) ∧ c.diffusion t x = a.diffusion (p t,x)) :
    cutoffGenerator a p c t x = trackingGenerator a.k₀ a.k₁ a.k₂ a.κd a.noise
      (x 0-p t 0) (errorZ a (p t) x) ((x 1)^2/x 0) := by
  have hd := mechanical_error_drift a.H a.g a.α a.β a.k₀ a.k₁ a.k₂ a.κd
    (x 0) (x 1) (x 2) (p t 0) (p t 1) (p t 2) (ne_of_gt hx)
    (ne_of_gt (add_pos_of_nonneg_of_pos a.H_pos.le hx))
  have he : heightRate (x 1) (x 2)-p t 1 =
      -a.k₁*(x 0-p t 0)+errorZ a (p t) x/2 := by
    dsimp [heightRate,errorZ]; ring
  dsimp only [cutoffGenerator]
  rw [hc.1,hc.2]
  dsimp only [Parameters.drift,Parameters.diffusion]
  simp only [Matrix.cons_val_zero,Matrix.cons_val_one,Matrix.cons_val_two,Matrix.vecHead,Matrix.vecTail,Function.comp_apply,Fin.succ_zero_eq_one]
  rw [hd,he]
  dsimp [trackingGenerator,errorZ]
  ring

/-- A real-time finite-variation extension of a continuous NNReal drift. -/
def fvLift {Ω : Type*} (b : ℝ≥0 → Ω → ℝ) (x₀ : ℝ) (t : ℝ) (ω : Ω) :=
  x₀+∫ s in 0..t, b (Real.toNNReal s) ω

theorem fvLift_deriv {Ω : Type*} {b : ℝ≥0 → Ω → ℝ}
    (hb : ∀ ω, Continuous (fun t => b t ω)) (x₀ t : ℝ) (ω : Ω) :
    HasDerivAt (fun s => fvLift b x₀ s ω) (b (Real.toNNReal t) ω) t := by
  have hc := (hb ω).comp continuous_real_toNNReal
  simpa only [fvLift,zero_add,Function.comp_def,Pi.add_def] using (hasDerivAt_const t x₀).add
    (intervalIntegral.integral_hasDerivAt_right (hc.intervalIntegrable 0 t)
      hc.stronglyMeasurable.stronglyMeasurableAtFilter hc.continuousAt)

theorem fvLift_eq {Ω : Type*} (b : ℝ≥0 → Ω → ℝ) (x₀ : ℝ) (t : ℝ≥0) (ω : Ω) :
    fvLift b x₀ t ω = x₀+driftPath b t ω := by
  rw [fvLift,driftPath,timeMeasure_Ioc_eq_interval]

/-- Energy decomposition of an actual constructed cutoff solution on a
measure-preserving continuous realization. The transformed SDE, the finite
variation derivatives, and the Itô identity are all derived. -/
theorem cutoff_energy_ito
    {Ω Ω' : Type*} [MeasurableSpace Ω] [MeasurableSpace Ω']
    {μ : Measure Ω} {ν : Measure Ω'} [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (a : Parameters) (r : ℝ → State)
    (hp : Continuous (fun t : ℝ≥0 => r t))
    (dr : ∀ t, 0 ≤ t → HasDerivAt (fun s => r s 0) (r t 1) t)
    (dr₁ : ∀ t, 0 ≤ t → HasDerivAt (fun s => r s 1) (r t 2) t)
    (c : Coefficients (Fin 3)) (x₀ : State) {Y : ℝ≥0 → Ω → State}
    (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    {f : Ω' → Ω} (hf : MeasurableEmbedding f) (hm : MeasurePreserving f ν μ)
    (hYf : ∀ ω, Continuous (fun t => Y t (f ω)))
    (hFV : ∀ ω t,
      Y t (f ω) 0 = x₀ 0+driftPath (fun s ω => c.drift s (Y s (f ω)) 0) t ω ∧
      Y t (f ω) 2 = x₀ 2+driftPath (fun s ω => c.drift s (Y s (f ω)) 2) t ω) :
    ∃ M : ℝ≥0 → Ω' → ℝ,
      (∀ᵐ ω ∂ν, ∀ t ∈ Icc 0 T,
        energy a (r t) (Y t (f ω)) = energy a (r 0) x₀+
          (∫ s in Ioc 0 t, cutoffGenerator a (fun u => r u) c s (Y s (f ω)) ∂timeMeasure)+M t ω) ∧
      (∀ ω, Continuous (fun t => M t ω)) ∧
      IsLocalMartingale M (augFiltration (μ:=ν) (fun s => (hBm s).comp hf.measurable)) ν := by
  let X := fun t ω => Y t (f ω)
  let d := fun t ω => c.drift t (X t ω)
  have hdC (ω : Ω') : Continuous (fun t => d t ω) :=
    c.drift_continuous.comp (continuous_id.prodMk (hYf ω))
  have hd₀ (ω : Ω') : Continuous (fun t => d t ω 0) := (continuous_apply 0).comp (hdC ω)
  have hd₂ (ω : Ω') : Continuous (fun t => d t ω 2) := (continuous_apply 2).comp (hdC ω)
  have hXa := adapted_pullback hBm hf.measurable (hY 0).predictable.stronglyAdapted
  have hda t : StronglyMeasurable[natFiltration (fun s => (hBm s).comp hf.measurable) t] (d t) :=
    (c.drift_continuous.comp (continuous_const.prodMk continuous_id)).comp_stronglyMeasurable (hXa t)
  have hdai t i := (continuous_apply i).comp_stronglyMeasurable (hda t)
  let H := fvLift (fun t ω => d t ω 0) (x₀ 0)
  let W := fvLift (fun t ω => d t ω 2) (x₀ 2)
  have hH (t : ℝ≥0) ω : H t ω = X t ω 0 :=
    (fvLift_eq _ _ t ω).trans (hFV ω t).1.symm
  have hW (t : ℝ≥0) ω : W t ω = X t ω 2 :=
    (fvLift_eq _ _ t ω).trans (hFV ω t).2.symm
  let e := fun t ω => H t ω-r t 0
  let e' := fun t ω => d (Real.toNNReal t) ω 0-r t 1
  let q := fun t ω => -W t ω-2*r t 1+2*a.k₁*e t ω
  let q' := fun t ω => -d (Real.toNNReal t) ω 2-2*r t 2+2*a.k₁*e' t ω
  let z := fun (t : ℝ≥0) ω => X t ω 1+q t ω
  let b := fun (t : ℝ≥0) ω => d t ω 1+q' t ω
  have he ω t ht : HasDerivAt (fun s => e s ω) (e' t ω) t :=
    (fvLift_deriv hd₀ (x₀ 0) t ω).sub (dr t ht)
  have hq ω t ht : HasDerivAt (fun s => q s ω) (q' t ω) t :=
    (((fvLift_deriv hd₂ (x₀ 2) t ω).neg.sub ((dr₁ t ht).const_mul 2)).add
      ((he ω t ht).const_mul (2*a.k₁)))
  have he'C ω : Continuous (fun t : ℝ≥0 => e' t ω) := by
    simpa only [e',Real.toNNReal_coe,Function.comp_def,Pi.sub_def] using (hd₀ ω).sub ((continuous_apply 1).comp hp)
  have hqC ω : Continuous (fun t : ℝ≥0 => q' t ω) := by
    simpa only [q',Real.toNNReal_coe,Function.comp_def,Pi.sub_def,Pi.add_def,Pi.neg_def] using
      ((hd₂ ω).neg.sub (((continuous_apply 2).comp hp).const_mul 2)).add ((he'C ω).const_mul (2*a.k₁))
  have hzval t ω : z t ω = errorZ a (r t) (X t ω) := by
    dsimp only [z,q,e]
    rw [hH,hW]
    dsimp only [errorZ]; ring
  have hzC ω : Continuous (fun t => z t ω) := by
    have hx (i : Fin 3) : Continuous (fun t => X t ω i) := (continuous_apply i).comp (hYf ω)
    have hr (i : Fin 3) : Continuous (fun t : ℝ≥0 => r t i) := (continuous_apply i).comp hp
    simp_rw [hzval,errorZ]
    exact (((hx 1).sub (hx 2)).sub ((hr 1).const_mul 2)).add
      (((hx 0).sub (hr 0)).const_mul (2*a.k₁))
  have hbC ω : Continuous (fun t => b t ω) :=
    ((continuous_apply 1).comp (hdC ω)).add (hqC ω)
  have hba t : StronglyMeasurable[natFiltration (fun s => (hBm s).comp hf.measurable) t] (b t) := by
    dsimp only [b,q',e']
    simp only [Real.toNNReal_coe]
    fun_prop
  obtain ⟨ham,hac,hv⟩ := strong_solution_pullback_equation hB T hBm hBc c x₀ hY hb hf hm hYf 1
  have hq₀ ω : q 0 ω = -x₀ 2-2*r 0 1+2*a.k₁*(x₀ 0-r 0 0) := by
    simp [q,e,H,W,fvLift]
  have hqCc ω : ContinuousOn (fun t : ℝ => q' t ω) (Icc 0 (T:ℝ)) := by
    apply ((hqC ω).comp continuous_real_toNNReal).continuousOn.congr
    intro s hs
    simp only [Function.comp_apply,Real.coe_toNNReal s hs.1]
  have hz := ito_add_finite_variation T (fun s => (hBm s).comp hf.measurable) ham hac
    (fun ω => (continuous_apply 1).comp (hdC ω)) hq₀ (fun ω t ht => hq ω t ht.1) hqCc hv
  obtain ⟨M,hM,hMc,hMl⟩ := general_energy_ito (preBrownian_pullback hB hm) T
    (fun s => (hBm s).comp hf.measurable) (fun ω => hBc (f ω))
    ham hac hba hbC hzC he he'C hz
  refine ⟨M,?_,hMc,hMl⟩
  filter_upwards [hM] with ω hMω t ht
  have h := hMω t ht
  have hzin : x₀ 1+(-x₀ 2-2*r 0 1+2*a.k₁*(x₀ 0-r 0 0)) = errorZ a (r 0) x₀ := by
    dsimp only [errorZ]; ring
  have he₀ : e 0 ω = x₀ 0-r 0 0 := by simp [e,H,fvLift]
  rw [hzin,he₀,hzval] at h
  have hi : (∫ s in Ioc 0 t, a.k₀*e s ω*e' s ω+z s ω*b s ω/4+
      (c.diffusion s (Y s (f ω)) 1)^2/8 ∂timeMeasure) =
      ∫ s in Ioc 0 t, cutoffGenerator a (fun u => r u) c s (Y s (f ω)) ∂timeMeasure := by
    apply setIntegral_congr_fun measurableSet_Ioc
    intro s hs
    dsimp only [e]
    rw [hH,hzval]
    dsimp only [e',b,q',X,d,cutoffGenerator]
    simp only [Real.toNNReal_coe]
    ring
  rw [hi] at h
  simpa only [energy,e,hH,X] using h

end
end ChainFountainStochastic.ConstructedEnergy
