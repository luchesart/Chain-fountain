import ChainFountainStochastic.BrownianLIL

namespace ChainFountainStochastic.BrownianSmallTime
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Real
open scoped NNReal ENNReal Topology
set_option maxHeartbeats 600000
set_option backward.isDefEq.respectTransparency false
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {P : Measure Ω}
  {X : ℝ≥0 → Ω → ℝ}

/-- The small-time LIL normalization. -/
def scale (t : ℝ≥0) : ℝ := sqrt (2*(t:ℝ)*log (log (1/(t:ℝ))))

/-- Algebraic compatibility of the LIL normalization with Brownian time inversion. -/
theorem inversion_ratio (t : ℝ≥0) (ht : t ≠ 0) (x : ℝ) :
    x / scale t⁻¹ = ((t:ℝ)*x) / sqrt (2*(t:ℝ)*log (log (t:ℝ))) := by
  have htR : (t:ℝ) ≠ 0 := by exact_mod_cast ht
  have he : sqrt (2*(t:ℝ)*log (log (t:ℝ))) =
      (t:ℝ) * sqrt (2*(t:ℝ)⁻¹*log (log (t:ℝ))) := by
    calc
      _ = sqrt ((t:ℝ)^2 * (2*(t:ℝ)⁻¹*log (log (t:ℝ)))) := by
        congr 1
        field_simp
        <;> ring
      _ = _ := by rw [sqrt_mul (sq_nonneg (t:ℝ)),sqrt_sq t.coe_nonneg]
  simp only [scale,NNReal.coe_inv,one_div,inv_inv]
  rw [he]
  exact (mul_div_mul_left x _ htR).symm

/-- Sharp small-time upper LIL, on every probability space carrying Brownian motion. -/
theorem limsup_zero (hX : IsBrownianReal X P) :
    ∀ᵐ ω ∂P, limsup (fun t => (X t ω / scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = 1 := by
  filter_upwards [BrownianLIL.limsup_atTop hX.inv] with ω hω
  simp only [← EReal.coe_div] at hω
  rw [← inv_atTop₀]
  change limsup (fun t => (X t ω / scale t).toEReal)
    (map (fun t : ℝ≥0 => t⁻¹) atTop) = 1
  rw [← limsup_comp]
  apply (limsup_congr ?_).trans hω
  filter_upwards [eventually_gt_atTop (0:ℝ≥0)] with t ht
  simp only [Function.comp_def, inversion_ratio t ht.ne',one_div]

/-- Sharp small-time lower LIL. -/
theorem liminf_zero (hX : IsBrownianReal X P) :
    ∀ᵐ ω ∂P, liminf (fun t => (X t ω / scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = -1 := by
  filter_upwards [limsup_zero hX.neg] with ω hω
  change limsup (fun t => (-X t ω / scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = 1 at hω
  simp only [neg_div, EReal.coe_neg, ← Pi.neg_def, EReal.limsup_neg] at hω
  exact neg_injective (by simpa using hω)

/-- Both sharp limits hold on a single probability-one event. -/
theorem two_sided_zero (hX : IsBrownianReal X P) :
    ∀ᵐ ω ∂P,
      limsup (fun t => (X t ω / scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = 1 ∧
      liminf (fun t => (X t ω / scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = -1 :=
  (limsup_zero hX).and (liminf_zero hX)

end
end ChainFountainStochastic.BrownianSmallTime
