module

public import ChainFountain.ZeroGravityOpen
public import Mathlib.Analysis.SpecialFunctions.Log.Deriv
public import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus

@[expose] public section

/-!
# Finite supply for the exact zero-gravity open solution

The rational positive speed is the exact solution already verified in
`ZeroGravityOpen`. The source length here is a kinematic inventory: the
mechanical model is used only until that inventory reaches zero. No motion
after depletion is asserted.
-/
namespace ChainFountain.ZeroGravity
noncomputable section
open Set Filter Real MeasureTheory
open scoped Topology

/-- Length transported from the source by the exact rational-decay motion. -/
def consumedLength (b w0 t : ℝ) : ℝ := Real.log (1 + b * w0 * t) / b

/-- Exact time at which an initial available length `ell0` is consumed. -/
def depletionTime (b w0 ell0 : ℝ) : ℝ :=
  (Real.exp (b * ell0) - 1) / (b * w0)

/-- The remaining supply is initial supply minus transported length. -/
def remainingSupply (b w0 ell0 t : ℝ) : ℝ :=
  ell0 - consumedLength b w0 t

theorem decay_denominator_pos {b w0 t : ℝ}
    (hb : 0 < b) (hw : 0 < w0) (ht : 0 ≤ t) :
    0 < 1 + b * w0 * t := by positivity

theorem consumedLength_initial (b w0 : ℝ) : consumedLength b w0 0 = 0 := by
  simp [consumedLength]

/-- The transported-length expression has the actual mechanical speed as
its classical derivative at every forward time. -/
theorem consumedLength_hasDerivAt {b w0 t : ℝ}
    (hb : 0 < b) (hw : 0 < w0) (ht : 0 ≤ t) :
    HasDerivAt (consumedLength b w0) (decaySpeed b w0 t) t := by
  have hden := decay_denominator_pos hb hw ht
  have hd := ((((hasDerivAt_id t).const_mul (b * w0)).const_add 1).log
    hden.ne').div_const b
  convert! hd using 1
  simp only [decaySpeed, id_eq, mul_one]
  field_simp [hb.ne', hden.ne']

/-- Exact integral of the transported speed on each forward interval. -/
theorem decaySpeed_integral {b w0 t : ℝ}
    (hb : 0 < b) (hw : 0 < w0) (ht : 0 ≤ t) :
    (∫ s in (0 : ℝ)..t, decaySpeed b w0 s) = consumedLength b w0 t := by
  have hc : ContinuousOn (decaySpeed b w0) (uIcc 0 t) := by
    intro s hs
    rw [uIcc_of_le ht] at hs
    exact (decaySpeed_hasDerivAt (decay_denominator_pos hb hw hs.1).ne').continuousAt.continuousWithinAt
  have hd : ∀ s ∈ uIcc 0 t,
      HasDerivAt (consumedLength b w0) (decaySpeed b w0 s) s := by
    intro s hs
    rw [uIcc_of_le ht] at hs
    exact consumedLength_hasDerivAt hb hw hs.1
  rw [intervalIntegral.integral_eq_sub_of_hasDerivAt hd hc.intervalIntegrable,
    consumedLength_initial, sub_zero]

theorem depletionTime_pos {b w0 ell0 : ℝ}
    (hb : 0 < b) (hw : 0 < w0) (hell : 0 < ell0) :
    0 < depletionTime b w0 ell0 := by
  exact div_pos (sub_pos.mpr (Real.one_lt_exp_iff.mpr (mul_pos hb hell))) (mul_pos hb hw)

theorem depletion_denominator {b w0 ell0 : ℝ}
    (hb : b ≠ 0) (hw : w0 ≠ 0) :
    1 + b * w0 * depletionTime b w0 ell0 = Real.exp (b * ell0) := by
  unfold depletionTime
  field_simp
  ring

/-- At the claimed time the actual integrated transport equals initial supply. -/
theorem consumedLength_at_depletion {b w0 ell0 : ℝ}
    (hb : 0 < b) (hw : 0 < w0) :
    consumedLength b w0 (depletionTime b w0 ell0) = ell0 := by
  unfold consumedLength
  rw [depletion_denominator hb.ne' hw.ne', Real.log_exp]
  field_simp

/-- Before, and only before, the explicit depletion time, the consumed length
is strictly less than the initial supply. -/
theorem consumedLength_lt_iff {b w0 ell0 t : ℝ}
    (hb : 0 < b) (hw : 0 < w0) (ht : 0 ≤ t) :
    consumedLength b w0 t < ell0 ↔ t < depletionTime b w0 ell0 := by
  have hden := decay_denominator_pos hb hw ht
  have hbw := mul_pos hb hw
  constructor
  · intro h
    have hlog : Real.log (1 + b * w0 * t) < b * ell0 := by
      have h' := (div_lt_iff₀ hb).mp h
      nlinarith
    have hexp := Real.exp_lt_exp.mpr hlog
    rw [Real.exp_log hden] at hexp
    unfold depletionTime
    apply (lt_div_iff₀ hbw).mpr
    nlinarith
  · intro h
    have h' := (lt_div_iff₀ hbw).mp h
    have hlt : 1 + b * w0 * t < Real.exp (b * ell0) := by nlinarith
    have hlog := Real.log_lt_log hden hlt
    rw [Real.log_exp] at hlog
    unfold consumedLength
    apply (div_lt_iff₀ hb).mpr
    nlinarith

theorem remainingSupply_initial (b w0 ell0 : ℝ) :
    remainingSupply b w0 ell0 0 = ell0 := by
  simp [remainingSupply, consumedLength_initial]

theorem remainingSupply_hasDerivAt {b w0 ell0 t : ℝ}
    (hb : 0 < b) (hw : 0 < w0) (ht : 0 ≤ t) :
    HasDerivAt (remainingSupply b w0 ell0) (-decaySpeed b w0 t) t := by
  simpa [remainingSupply] using! (consumedLength_hasDerivAt hb hw ht).const_sub ell0

theorem remainingSupply_pos_iff {b w0 ell0 t : ℝ}
    (hb : 0 < b) (hw : 0 < w0) (ht : 0 ≤ t) :
    0 < remainingSupply b w0 ell0 t ↔ t < depletionTime b w0 ell0 := by
  rw [remainingSupply, sub_pos]
  exact consumedLength_lt_iff hb hw ht

theorem remainingSupply_at_depletion {b w0 ell0 : ℝ}
    (hb : 0 < b) (hw : 0 < w0) :
    remainingSupply b w0 ell0 (depletionTime b w0 ell0) = 0 := by
  simp [remainingSupply, consumedLength_at_depletion hb hw]

/-- The exact depletion time is the only forward zero of the inventory. -/
theorem remainingSupply_eq_zero_iff {b w0 ell0 t : ℝ}
    (hb : 0 < b) (hw : 0 < w0) (ht : 0 ≤ t) :
    remainingSupply b w0 ell0 t = 0 ↔ t = depletionTime b w0 ell0 := by
  constructor
  · intro hz
    have hc : consumedLength b w0 t = ell0 := by
      unfold remainingSupply at hz
      linarith
    have hlog : Real.log (1 + b * w0 * t) = b * ell0 := by
      have h := (div_eq_iff hb.ne').mp hc
      nlinarith
    have he := congrArg Real.exp hlog
    rw [Real.exp_log (decay_denominator_pos hb hw ht)] at he
    unfold depletionTime
    apply (eq_div_iff (mul_pos hb hw).ne').mpr
    nlinarith
  · intro ht'
    rw [ht']
    exact remainingSupply_at_depletion hb hw

/-- The computed time is a genuine first depletion time for positive supply. -/
theorem first_depletion {b w0 ell0 : ℝ}
    (hb : 0 < b) (hw : 0 < w0) (hell : 0 < ell0) :
    0 < depletionTime b w0 ell0 ∧
      remainingSupply b w0 ell0 (depletionTime b w0 ell0) = 0 ∧
      ∀ t ∈ Ico (0 : ℝ) (depletionTime b w0 ell0),
        0 < remainingSupply b w0 ell0 t := by
  exact ⟨depletionTime_pos hb hw hell, remainingSupply_at_depletion hb hw,
    fun t ht => (remainingSupply_pos_iff hb hw ht.1).mpr ht.2⟩

/-- The actual speed integral exhausts precisely the available chain length
at the positive first depletion time. -/
theorem integral_at_depletion {b w0 ell0 : ℝ}
    (hb : 0 < b) (hw : 0 < w0) (hell : 0 < ell0) :
    (∫ s in (0 : ℝ)..depletionTime b w0 ell0, decaySpeed b w0 s) = ell0 := by
  rw [decaySpeed_integral hb hw (depletionTime_pos hb hw hell).le,
    consumedLength_at_depletion hb hw]

/-- Positive exact speed tends to zero; this is not finite-time stopping. -/
theorem decaySpeed_tendsto_zero {b w0 : ℝ} (hb : 0 < b) (hw : 0 < w0) :
    Tendsto (decaySpeed b w0) atTop (𝓝 0) := by
  have hlin : Tendsto (fun t : ℝ => b * w0 * t) atTop atTop :=
    tendsto_id.const_mul_atTop (mul_pos hb hw)
  have hden : Tendsto (fun t : ℝ => 1 + b * w0 * t) atTop atTop :=
    tendsto_const_nhds.add_atTop hlin
  exact tendsto_const_nhds.div_atTop hden

/-- Pickup tension for the exact constant-height braking command. -/
theorem constant_height_pickup (α r b w : ℝ) :
    pickup α w ((α + r * b) * w ^ 2) = (1 + r * b) * w ^ 2 := by
  unfold pickup
  ring

/-- The required command is a passive brake and the pickup tension is positive. -/
theorem constant_height_passive_and_tension {α r b w : ℝ}
    (hα : 0 ≤ α) (hr : 0 < r) (hb : 0 < b) (hw : 0 < w) :
    0 ≤ (α + r * b) * w ^ 2 ∧
      0 < pickup α w ((α + r * b) * w ^ 2) := by
  rw [constant_height_pickup]
  constructor <;> positivity

/-- End-to-end finite-source version of the exact open mechanical solution.
All three state equations and the supply equation hold before depletion;
the input is passive and the pickup tension remains positive there. -/
theorem constant_height_finite_supply {H α β r w0 ell0 : ℝ}
    (hr : 0 < r) (hden : 0 < H + r) (hβ : β < 1)
    (hα : 0 ≤ α) (hw : 0 < w0) (hell : 0 < ell0) :
    let b := decayRate H β r
    let speed := decaySpeed b w0
    let input := fun t => (α + r * b) * speed t ^ 2
    let supply := remainingSupply b w0 ell0
    let τ := depletionTime b w0 ell0
    0 < τ ∧ supply 0 = ell0 ∧ supply τ = 0 ∧
      ∀ t ∈ Ico (0 : ℝ) τ,
        HasDerivAt (fun _ : ℝ => r) (heightRate (speed t) (speed t)) t ∧
        HasDerivAt speed (rise 0 α r (speed t) (speed t) (input t)) t ∧
        HasDerivAt speed (fall H 0 β r (speed t) (speed t)) t ∧
        HasDerivAt supply (-speed t) t ∧
        0 < supply t ∧ 0 < speed t ∧
        0 ≤ input t ∧ 0 < pickup α (speed t) (input t) := by
  dsimp only
  have hb := decayRate_pos hden hβ
  refine ⟨depletionTime_pos hb hw hell, remainingSupply_initial _ _ _,
    remainingSupply_at_depletion hb hw, ?_⟩
  intro t ht
  have hm := constant_height_solution (α := α) hr.ne' hden.ne'
    (decay_denominator_pos hb hw ht.1).ne'
  have hs := decaySpeed_pos hb hw ht.1
  have hp := constant_height_passive_and_tension hα hr hb hs
  exact ⟨hm.1, hm.2.1, hm.2.2, remainingSupply_hasDerivAt hb hw ht.1,
    (remainingSupply_pos_iff hb hw ht.1).mpr ht.2, hs, hp.1, hp.2⟩

end
end ChainFountain.ZeroGravity
