module

public import ChainFountain.ZeroGravityCirculation
public import ChainFountain.ZeroGravityAC
public import Mathlib.Analysis.Calculus.ContDiff.Deriv
public import Mathlib.Analysis.Calculus.ContDiff.RCLike

@[expose] public section

/-!
# Absolutely continuous circulation and the actual string equation

The phase is constructed from the speed, using a constant extension before time
zero. The common null set in the acceleration equation is independent of the
material label. Spatial shape remains prescribed; no shape-attraction theorem
is asserted.
-/
namespace ChainFountain.ZeroGravity
noncomputable section
open Set Filter MeasureTheory Real
open scoped Topology NNReal

/-- Constant extension of a forward speed to negative time. -/
def forwardSpeed (c : ℝ → ℝ) (t : ℝ) : ℝ := c (max 0 t)

/-- Material phase constructed by integrating the continuous extended speed. -/
def circulationPhase (c : ℝ → ℝ) (θ0 t : ℝ) : ℝ :=
  θ0 + ∫ s in (0 : ℝ)..t, forwardSpeed c s

theorem forwardSpeed_eq {c : ℝ → ℝ} {t : ℝ} (ht : 0 ≤ t) :
    forwardSpeed c t = c t := by simp [forwardSpeed, max_eq_right ht]

theorem forwardSpeed_continuous {c : ℝ → ℝ}
    (hc : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T) :
    Continuous (forwardSpeed c) := locally_ac_forward_extension hc

theorem forwardSpeed_hasDerivAt {c : ℝ → ℝ} {t z : ℝ}
    (ht : 0 < t) (hc : HasDerivAt c z t) :
    HasDerivAt (forwardSpeed c) z t := by
  apply hc.congr_of_eventuallyEq
  filter_upwards [Ioi_mem_nhds ht] with s hs
  exact forwardSpeed_eq hs.le

theorem circulationPhase_initial (c : ℝ → ℝ) (θ0 : ℝ) :
    circulationPhase c θ0 0 = θ0 := by simp [circulationPhase]

/-- The phase has a classical derivative at every real time, including zero. -/
theorem circulationPhase_hasDerivAt {c : ℝ → ℝ} {θ0 t : ℝ}
    (hc : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T) :
    HasDerivAt (circulationPhase c θ0) (forwardSpeed c t) t := by
  have h := forwardSpeed_continuous hc
  exact (intervalIntegral.integral_hasDerivAt_right
    (h.intervalIntegrable 0 t) h.aestronglyMeasurable.stronglyMeasurableAtFilter
    h.continuousAt).const_add θ0

/-- The phase is continuously differentiable, not merely differentiable a.e. -/
theorem circulationPhase_contDiff {c : ℝ → ℝ} {θ0 : ℝ}
    (hc : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T) :
    ContDiff ℝ 1 (circulationPhase c θ0) := by
  apply contDiff_one_iff_deriv.mpr
  refine ⟨fun t => (circulationPhase_hasDerivAt hc).differentiableAt, ?_⟩
  have he : deriv (circulationPhase c θ0) = forwardSpeed c := by
    funext t
    exact (circulationPhase_hasDerivAt hc).deriv
  rw [he]
  exact forwardSpeed_continuous hc

/-- On forward times the phase is exactly the integral of the original speed. -/
theorem circulationPhase_forward_integral {c : ℝ → ℝ} {θ0 t : ℝ} (ht : 0 ≤ t) :
    circulationPhase c θ0 t = θ0 + ∫ s in (0 : ℝ)..t, c s := by
  unfold circulationPhase
  congr 1
  apply intervalIntegral.integral_congr
  intro s hs
  rw [uIcc_of_le ht] at hs
  exact forwardSpeed_eq hs.1

section Vector
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- Material velocity is the actual time derivative of the reconstructed position
at every forward time and every material label. -/
theorem loop_ac_material_velocity {R R1 : ℝ → E} {c : ℝ → ℝ} {θ0 t a : ℝ}
    (hc : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T)
    (hR : ∀ x, HasDerivAt R (R1 x) x) (ht : 0 ≤ t) :
    deriv (fun s => R (a + circulationPhase c θ0 s)) t =
      c t • R1 (a + circulationPhase c θ0 t) := by
  simpa only [forwardSpeed_eq ht] using
    (loop_position_hasDerivAt (a := a) (t := t) (hR _)
      (circulationPhase_hasDerivAt (θ0 := θ0) hc)).deriv

/-- The actual second time derivative obeys momentum balance on one common
full-measure time set, simultaneously for all material labels. -/
theorem loop_continuum_balance_ae {R R1 R2 : ℝ → E} {c u d : ℝ → ℝ}
    {lam γ θ0 : ℝ} (hlam : lam ≠ 0)
    (hR : ∀ x, HasDerivAt R (R1 x) x)
    (hR1 : ∀ x, HasDerivAt R1 (R2 x) x)
    (hc : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T)
    (hd : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c (u t - γ * c t + d t) t) :
    ∀ᵐ t ∂volume, 0 ≤ t → ∀ a : ℝ,
      deriv (fun τ => deriv (fun s => R (a + circulationPhase c θ0 s)) τ) t =
        (1 / lam) • deriv
          (fun b => (lam * (c t)^2) •
            deriv (fun z => R (z + circulationPhase c θ0 t)) b) a +
        (u t - γ * c t + d t) •
          deriv (fun z => R (z + circulationPhase c θ0 t)) a := by
  have hne : ∀ᵐ t : ℝ ∂volume, t ≠ 0 := by simp [ae_iff, measure_singleton]
  filter_upwards [hd,hne] with t hdt hnt ht a
  have htp : 0 < t := lt_of_le_of_ne ht (Ne.symm hnt)
  have hce := forwardSpeed_hasDerivAt htp (hdt ht)
  rw [←forwardSpeed_eq (c := c) ht] at hce
  have he := loop_continuum_balance (c := forwardSpeed c)
    (θ := circulationPhase c θ0) (a := a) hlam hR (hR1 _)
    (fun s => circulationPhase_hasDerivAt hc) hce
  simpa only [forwardSpeed_eq ht] using he

/-- The material velocity itself is forward locally absolutely continuous.
The C¹ tangent hypothesis is supplied by a C² reference curve. -/
theorem loop_material_velocity_ac {R1 : ℝ → E} {c : ℝ → ℝ} {θ0 a T : ℝ}
    (hc : ∀ S ≥ 0, AbsolutelyContinuousOnInterval c 0 S)
    (hR1 : ContDiff ℝ 1 R1) (hT : 0 ≤ T) :
    AbsolutelyContinuousOnInterval
      (fun t => c t • R1 (a + circulationPhase c θ0 t)) 0 T := by
  have htan : ContDiff ℝ 1 (fun t => R1 (a + circulationPhase c θ0 t)) :=
    hR1.comp (contDiff_const.add (circulationPhase_contDiff hc))
  obtain ⟨K,hK⟩ := htan.contDiffOn.exists_lipschitzOnWith (by norm_num)
    (convex_Icc (0 : ℝ) T) isCompact_Icc
  have hAC : AbsolutelyContinuousOnInterval
      (fun t => R1 (a + circulationPhase c θ0 t)) 0 T := by
    apply LipschitzOnWith.absolutelyContinuousOnInterval
    simpa only [uIcc_of_le hT] using hK
  exact (hc T hT).fun_smul hAC

/-- A.e. acceleration of the AC material velocity; the exceptional time set is
again common to all material labels. -/
theorem loop_material_acceleration_ae {R1 R2 : ℝ → E} {c u d : ℝ → ℝ}
    {γ θ0 : ℝ}
    (hR1 : ∀ x, HasDerivAt R1 (R2 x) x)
    (hc : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T)
    (hd : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c (u t - γ * c t + d t) t) :
    ∀ᵐ t ∂volume, 0 ≤ t → ∀ a : ℝ,
      HasDerivAt (fun s => c s • R1 (a + circulationPhase c θ0 s))
        ((c t)^2 • R2 (a + circulationPhase c θ0 t) +
          (u t - γ * c t + d t) • R1 (a + circulationPhase c θ0 t)) t := by
  filter_upwards [hd] with t hdt ht a
  exact loop_velocity_hasDerivAt (hR1 _)
    (by simpa only [forwardSpeed_eq ht] using circulationPhase_hasDerivAt (θ0 := θ0) (t := t) hc)
    (hdt ht)

/-- The reconstructed loop inherits closure and inextensibility at all times. -/
theorem loop_ac_geometry {R R1 : ℝ → E} {c : ℝ → ℝ} {θ0 L : ℝ}
    (hR : ∀ x, HasDerivAt R (R1 x) x)
    (hunit : ∀ x, ‖R1 x‖ = 1) (hperiod : Function.Periodic R L) :
    (∀ t, Function.Periodic (fun a => R (a + circulationPhase c θ0 t)) L) ∧
    (∀ a t, ‖deriv (fun z => R (z + circulationPhase c θ0 t)) a‖ = 1) := by
  exact ⟨fun t => loop_periodic hperiod,
    fun a t => loop_inextensible (hR _) (hunit _)⟩

/-- Spatial stress divergence is the curvature term, with the actual spatial
first and second derivatives. This identity needs no temporal differentiability. -/
theorem loop_spatial_force {R R1 R2 : ℝ → E} {θ c u d : ℝ → ℝ}
    {lam γ a t : ℝ} (hlam : lam ≠ 0)
    (hR : ∀ x, HasDerivAt R (R1 x) x)
    (hR1 : ∀ x, HasDerivAt R1 (R2 x) x) :
    (1 / lam) • deriv
        (fun b => (lam * (c t)^2) • deriv (fun z => R (z + θ t)) b) a +
      (u t - γ * c t + d t) • deriv (fun z => R (z + θ t)) a =
    (c t)^2 • R2 (a + θ t) + (u t - γ * c t + d t) • R1 (a + θ t) := by
  have hspace : deriv (fun z => R (z + θ t)) = (fun b => R1 (b + θ t)) := by
    funext b
    have h := (hR (b + θ t)).scomp b ((hasDerivAt_id b).add_const (θ t))
    simpa only [Function.comp_def, id_eq, one_smul] using! h.deriv
  rw [hspace, (loop_stress_hasDerivAt (lam := lam) (hR1 _)).deriv]
  have hscalar : 1 / lam * (lam * (c t)^2) = (c t)^2 := by field_simp
  rw [smul_smul, hscalar]

end Vector

/-- Actual vector integral momentum equation in three real coordinates for each
material label. Integrability follows from genuine AC and the a.e. equation.
This coordinate bridge makes no unit-speed claim for the product norm; the
physical geometry below uses an inner-product-space norm. -/
theorem loop_ac_integral_momentum
    {R1 R2 : ℝ → ℝ × (ℝ × ℝ)} {c u d : ℝ → ℝ} {γ θ0 T a : ℝ}
    (hT : 0 ≤ T) (hc : ∀ S ≥ 0, AbsolutelyContinuousOnInterval c 0 S)
    (hR1 : ContDiff ℝ 1 R1) (hR1d : ∀ x, HasDerivAt R1 (R2 x) x)
    (hd : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c (u t - γ * c t + d t) t) :
    let V := fun t => c t • R1 (a + circulationPhase c θ0 t)
    let A := fun t => (c t)^2 • R2 (a + circulationPhase c θ0 t) +
      (u t - γ * c t + d t) • R1 (a + circulationPhase c θ0 t)
    IntervalIntegrable A volume 0 T ∧ V T = V 0 + ∫ t in (0 : ℝ)..T, A t := by
  dsimp only
  have hacc := loop_material_acceleration_ae (θ0 := θ0) hR1d hc hd
  have hD : ∀ᵐ t ∂volume, t ∈ uIcc 0 T →
      HasDerivAt (fun t => c t • R1 (a + circulationPhase c θ0 t))
        ((c t)^2 • R2 (a + circulationPhase c θ0 t) +
          (u t - γ * c t + d t) • R1 (a + circulationPhase c θ0 t)) t := by
    filter_upwards [hacc] with t ht hmem
    rw [uIcc_of_le hT] at hmem
    exact ht hmem.1 a
  obtain ⟨hi,he⟩ := ac_state_integral_eq_sub (loop_material_velocity_ac hc hR1 hT) hD
  exact ⟨hi, by rw [he]; abel⟩

/-- The coordinate integral momentum theorem written entirely with actual
position derivatives and spatial stress divergence. It does not assert a
unit-speed constraint for the coordinate product norm. -/
theorem loop_ac_integral_balance
    {R R1 R2 : ℝ → ℝ × (ℝ × ℝ)} {c u d : ℝ → ℝ} {lam γ θ0 T a : ℝ}
    (hlam : lam ≠ 0) (hT : 0 ≤ T)
    (hc : ∀ S ≥ 0, AbsolutelyContinuousOnInterval c 0 S)
    (hR : ∀ x, HasDerivAt R (R1 x) x)
    (hR1 : ContDiff ℝ 1 R1) (hR1d : ∀ x, HasDerivAt R1 (R2 x) x)
    (hd : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c (u t - γ * c t + d t) t) :
    let V := fun t => deriv (fun s => R (a + circulationPhase c θ0 s)) t
    let F := fun t => (1 / lam) • deriv
        (fun b => (lam * (c t)^2) •
          deriv (fun z => R (z + circulationPhase c θ0 t)) b) a +
      (u t - γ * c t + d t) • deriv (fun z => R (z + circulationPhase c θ0 t)) a
    IntervalIntegrable F volume 0 T ∧ V T = V 0 + ∫ t in (0 : ℝ)..T, F t := by
  dsimp only
  simpa only [loop_spatial_force hlam hR hR1d,
    loop_ac_material_velocity hc hR hT,
    loop_ac_material_velocity hc hR (le_refl (0 : ℝ))] using
    loop_ac_integral_momentum (θ0 := θ0) (a := a) hT hc hR1 hR1d hd

section InnerProduct
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

/-- The reconstructed zero-gravity loop, with its actual derivatives and a.e.
closed-loop mechanics. The norm is the inner-product norm (for example the
Euclidean norm on `EuclideanSpace ℝ (Fin 3)`), and the material period is positive.
This proposition describes the prescribed-shape circulation family; it makes
no assertion of stability with respect to arbitrary shape perturbations. -/
structure AECirculatingLoop (R : ℝ → E) (r rdot d : ℝ → ℝ)
    (γ k lam L c0 θ0 : ℝ) (c : ℝ → ℝ) : Prop where
  positive_period : 0 < L
  positive_density : 0 < lam
  speed_initial : c 0 = c0
  speed_locallyAC : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T
  phase_initial : circulationPhase c θ0 0 = θ0
  phase_contDiff : ContDiff ℝ 1 (circulationPhase c θ0)
  phase_integral : ∀ t ≥ 0,
    circulationPhase c θ0 t = θ0 + ∫ s in (0 : ℝ)..t, c s
  closed : ∀ t, Function.Periodic (fun a => R (a + circulationPhase c θ0 t)) L
  inextensible : ∀ a t, ‖deriv (fun z => R (z + circulationPhase c θ0 t)) a‖ = 1
  tension_nonnegative : ∀ t, 0 ≤ lam * (c t)^2
  material_velocity : ∀ a t, 0 ≤ t →
    deriv (fun s => R (a + circulationPhase c θ0 s)) t =
      c t • deriv R (a + circulationPhase c θ0 t)
  material_velocity_locallyAC : ∀ a T, 0 ≤ T →
    AbsolutelyContinuousOnInterval
      (fun t => c t • deriv R (a + circulationPhase c θ0 t)) 0 T
  plant_ae : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c
    (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) t
  plant_integral : ∀ t ≥ 0,
    IntervalIntegrable (fun s =>
      circulationCommand γ k (r s) (rdot s) (c s) - γ * c s + d s) volume 0 t ∧
    c t = c0 + ∫ s in (0 : ℝ)..t,
      circulationCommand γ k (r s) (rdot s) (c s) - γ * c s + d s
  momentum_ae : ∀ᵐ t ∂volume, 0 ≤ t → ∀ a : ℝ,
    deriv (fun τ => deriv (fun s => R (a + circulationPhase c θ0 s)) τ) t =
      (1 / lam) • deriv
        (fun b => (lam * (c t)^2) •
          deriv (fun z => R (z + circulationPhase c θ0 t)) b) a +
      (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) •
        deriv (fun z => R (z + circulationPhase c θ0 t)) a

/-- Global construction from a C² unit-speed closed reference curve and a
forward a.e. measurable, essentially bounded disturbance. The scalar speed,
phase, and actual continuum solution are all constructed; no candidate speed
or phase trajectory is assumed. No regularity of the disturbance before zero
is required. -/
theorem measurable_closed_loop_exists {R : ℝ → E} {r rdot d : ℝ → ℝ}
    {γ k lam L c0 θ0 D : ℝ}
    (hL : 0 < L) (hlam : 0 < lam)
    (hR : ContDiff ℝ 2 R) (hunit : ∀ x, ‖deriv R x‖ = 1)
    (hperiod : Function.Periodic R L)
    (hrC1 : ContDiffOn ℝ 1 r (Ici 0))
    (hr : ∀ t : ℝ, 0 < t → HasDerivAt r (rdot t) t)
    (hd : AEMeasurable d (volume.restrict (Ici 0)))
    (hb : ∀ᵐ t ∂volume, 0 ≤ t → |d t| ≤ D) :
    ∃ c : ℝ → ℝ, AECirculatingLoop R r rdot d γ k lam L c0 θ0 c := by
  obtain ⟨c,hc0,hc,hplant,hint⟩ := circulation_forward_measurable_global_exists
    (γ := γ) (k := k) (c0 := c0) hrC1 hr hd hb
  have hR1 : ContDiff ℝ 1 (deriv R) := hR.deriv'
  have hRd : ∀ x, HasDerivAt R (deriv R x) x :=
    fun x => (hR.differentiable (by norm_num) x).hasDerivAt
  have hR1d : ∀ x, HasDerivAt (deriv R) (deriv (deriv R) x) x :=
    fun x => (hR1.differentiable (by norm_num) x).hasDerivAt
  have hgeo := loop_ac_geometry (c := c) (θ0 := θ0) hRd hunit hperiod
  refine ⟨c, {
    positive_period := hL
    positive_density := hlam
    speed_initial := hc0
    speed_locallyAC := hc
    phase_initial := circulationPhase_initial c θ0
    phase_contDiff := circulationPhase_contDiff hc
    phase_integral := fun t ht => circulationPhase_forward_integral ht
    closed := hgeo.1
    inextensible := hgeo.2
    tension_nonnegative := fun t => mul_nonneg hlam.le (sq_nonneg (c t))
    material_velocity := fun a t ht => loop_ac_material_velocity hc hRd ht
    material_velocity_locallyAC := fun a T hT => loop_material_velocity_ac hc hR1 hT
    plant_ae := hplant
    plant_integral := hint
    momentum_ae := loop_continuum_balance_ae hlam.ne' hRd hR1d hc hplant }⟩

end InnerProduct

end
end ChainFountain.ZeroGravity
