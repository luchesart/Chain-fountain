module

public import ChainFountain.GlobalExistence
public import ChainFountain.Convergence

@[expose] public section

namespace ChainFountain
noncomputable section
open Set Real

/-- Corollary 6.2 with the global trajectory constructed, not supplied.
Only data, a constant reference, zero disturbance bound and a decay rate are inputs. -/
theorem GlobalTrackingData.exists_global_convergent (c : GlobalTrackingData)
    (hd : c.dbar = 0) (hβ : c.β < 1) (r wr ρ : ℝ)
    (hr : ∀ t ≥ 0, c.r t = r) (hr₁ : ∀ t ≥ 0, c.r₁ t = 0)
    (hwr : 0 ≤ wr) (heq : (1-c.β)*wr^2=c.g*(c.H+r))
    (hρ0 : 0 < ρ) (hρ : ρ < (1-c.β)*(c.wlo+wr)/(c.H+c.hhi)) (hρκ : ρ ≤ c.κ) :
    let Ce := sqrt (2*c.stateEnergy 0 c.x₀/c.k₀)
    let Cq := sqrt (2*c.stateEnergy 0 c.x₀)*sqrt (1+c.k₁^2/c.k₀)
    let M := |c.x₀.2.2-wr|+((|c.g| *Ce+2*Cq*c.whi+Cq^2)/(c.H+c.hlo))/
      ((1-c.β)*(c.wlo+wr)/(c.H+c.hhi)-ρ)
    ∃ x : ℝ → MechanicalState, x 0 = c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      (∀ t ≥ 0, x t ∈ c.safeBox) ∧
      ∀ t ≥ 0, |(x t).1-r| ≤ Ce*exp (-ρ*t) ∧
        |(x t).2.2-wr| ≤ M*exp (-ρ*t) ∧
        |(x t).2.1-wr| ≤ (M+2*Cq)*exp (-ρ*t) := by
  dsimp only
  obtain ⟨x,hx,hdx,hbox,hdec,_⟩ := c.exists_global_tracking
  let Ce := sqrt (2*c.stateEnergy 0 c.x₀/c.k₀)
  let Cq := sqrt (2*c.stateEnergy 0 c.x₀)*sqrt (1+c.k₁^2/c.k₀)
  have he (t : ℝ) (ht : 0 ≤ t) :
      |(x t).1-r| ≤ Ce*exp (-c.κ*t) ∧
      |heightRate (x t).2.1 (x t).2.2| ≤ Cq*exp (-c.κ*t) := by
    have hh := error_decay_enclosure (k₁:=c.k₁) c.k₀_pos
      (energy_nonneg c.k₀_pos.le _ _) (hdec hd t ht)
    simp only [stateEnergy,hr t ht,hr₁ t ht,mul_zero,sub_zero] at hh
    convert! hh using 2 <;> dsimp [Ce,Cq,heightRate] <;> congr 1 <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hc : ContinuousOn x (Ici 0) := fun t ht => (hdx t ht).continuousAt.continuousWithinAt
  have hR : 0 ≤ c.R₁ := (abs_nonneg _).trans (c.rate_bound 0 le_rfl)
  have hQ : 0 ≤ c.Q := by dsimp [Q]; positivity
  have hwlo : 0 < c.wlo := by have := c.forward; change 2*c.Q < c.wlo at this; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hwd (t : ℝ) (ht : 0 ≤ t) : HasDerivAt (fun s => (x s).2.2)
      (internal c.H c.g c.β (x t).1 (x t).2.2 (heightRate (x t).2.1 (x t).2.2)) t := by
    have hw := hasFDerivAt_snd.comp_hasDerivAt t
      (hasFDerivAt_snd.comp_hasDerivAt t (hdx t ht))
    convert! hw using 1
    dsimp [field,jointField,internal,fall,crownSq,heightRate]
    have hden : c.H+(x t).1 ≠ 0 := (add_pos c.H_pos (lt_of_lt_of_le c.height_positive (hbox t ht).1.1)).ne'
    field_simp
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have result := constant_reference_fullstate_convergence
    (hc.fst) (hc.snd.snd) (add_pos c.H_pos c.height_positive) hβ hwr hwlo
    (show 0 ≤ Ce by positivity) (show 0 ≤ Cq by positivity) hρ0
    (fun t ht => (hbox t ht).1) (fun t ht => (hbox t ht).2.2) heq
    hwd (fun t ht => (he t ht).1) (fun t ht => (he t ht).2) hρ hρκ
  refine ⟨x,hx,hdx,hbox,?_⟩
  intro t ht
  have h := result.2 t ht
  rw [hx] at h
  have hid : (x t).2.2+2*heightRate (x t).2.1 (x t).2.2-wr = (x t).2.1-wr := by
    unfold heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [hid] at h
  exact h

end
end ChainFountain
