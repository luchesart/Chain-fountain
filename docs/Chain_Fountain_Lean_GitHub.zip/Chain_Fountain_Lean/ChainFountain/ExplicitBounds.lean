module

public import ChainFountain.AEIntegralEstimate
public import ChainFountain.Trajectories

@[expose] public section

namespace ChainFountain
noncomputable section
open Set Real MeasureTheory Filter
open scoped NNReal

def fallingRateBound (H g β hlo shi whi : ℝ) := g+(shi^2+β*whi^2)/(H+hlo)
def risingRateBound (Mw A κd Gmax cz dbar : ℝ) := Mw+2*A+κd*Gmax^2*cz+Gmax*dbar

theorem falling_rate_bound {H g β h v w hlo shi whi : ℝ}
    (hg : 0≤ g) (hb : 0≤β) (hD : 0<H+hlo) (hh : hlo≤ h)
    (hs : |(v+w)/2|≤ shi) (hw : |w|≤ whi) :
    |fall H g β h v w|≤ fallingRateBound H g β hlo shi whi := by
  have hDp : 0<H+h := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hsq : crownSq v w≤ shi^2 := by
    dsimp [crownSq]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [sq_le_sq₀ (abs_nonneg ((v+w)/2)) ((abs_nonneg _).trans hs) |>.mpr hs,
      sq_abs ((v+w)/2)]
  have hwq : w^2≤ whi^2 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [sq_le_sq₀ (abs_nonneg w) ((abs_nonneg _).trans hw) |>.mpr hw,sq_abs w]
  have hnum : |-crownSq v w+β*w^2|≤ shi^2+β*whi^2 := by
    have h := abs_add_le (-crownSq v w) (β*w^2)
    have hcn : 0≤ crownSq v w := by dsimp [crownSq]; positivity
    rw [abs_neg,abs_of_nonneg hcn,abs_of_nonneg (mul_nonneg hb (sq_nonneg w))] at h
    have hm := mul_le_mul_of_nonneg_left hwq hb
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hdiv : |(-crownSq v w+β*w^2)/(H+h)|≤(shi^2+β*whi^2)/(H+hlo) := by
    rw [abs_div,abs_of_pos hDp]
    exact (div_le_div_of_nonneg_right hnum hDp.le).trans
      (div_le_div_of_nonneg_left (by positivity) hD (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith))
  have h := abs_add_le g ((-crownSq v w+β*w^2)/(H+h))
  rw [abs_of_nonneg hg] at h
  exact h.trans (add_le_add (le_refl g) hdiv)

theorem rising_rate_bound {H g α β h v w A κd z d Mw Amax Gmax cz dbar : ℝ}
    (hh : h≠0) (hH : H+h≠0) (hκd : 0≤κd)
    (hw : |fall H g β h v w|≤ Mw) (hA : |A|≤ Amax)
    (hG : |v^2/h|≤ Gmax) (hz : |z|≤ cz) (hd : |d|≤ dbar) :
    |rise g (α+d) h v w (robustInput H g α β h v w A κd z)|≤
      risingRateBound Mw Amax κd Gmax cz dbar := by
  have hid := robust_acceleration H g α β h v w A κd z d hh hH
  have heq : rise g (α+d) h v w (robustInput H g α β h v w A κd z)=
      fall H g β h v w+2*A-κd*(v^2/h)^2*z+(v^2/h)*d := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hG0 : 0≤ Gmax := (abs_nonneg _).trans hG
  have hz0 : 0≤ cz := (abs_nonneg _).trans hz
  have hGq : (v^2/h)^2≤ Gmax^2 := by
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [sq_le_sq₀ (abs_nonneg (v^2/h)) hG0 |>.mpr hG,sq_abs (v^2/h)]
  have hz' := mul_le_mul (mul_le_mul_of_nonneg_left hGq hκd) hz (abs_nonneg z) (by positivity : 0≤κd*Gmax^2)
  have hd' := mul_le_mul hG hd (abs_nonneg d) hG0
  have h₁ := abs_add_le (fall H g β h v w) (2*A)
  have h₂ := abs_sub (fall H g β h v w+2*A) (κd*(v^2/h)^2*z)
  have h₃ := abs_add_le (fall H g β h v w+2*A-κd*(v^2/h)^2*z) ((v^2/h)*d)
  simp only [abs_mul,abs_of_nonneg hκd,abs_of_nonneg (sq_nonneg (v^2/h)),
    abs_of_pos (by norm_num : (0:ℝ)<2)] at h₁ h₂ h₃
  rw [heq]
  dsimp [risingRateBound]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

/-- The product norm is exactly the sup norm used in the paper. -/
theorem mechanical_sup_norm_bound {h' v' w' Q Mw Mv : ℝ}
    (hh : |h'|≤ Q) (hv : |v'|≤ Mv) (hw : |w'|≤ Mw) :
    ‖(h',v',w')‖ ≤ max Q (max Mw Mv) := by
  rw [Prod.norm_def,Prod.norm_def,Real.norm_eq_abs,Real.norm_eq_abs,Real.norm_eq_abs]
  exact max_le (hh.trans (le_max_left _ _))
    (max_le (hv.trans ((le_max_right Mw Mv).trans (le_max_right Q _)))
      (hw.trans ((le_max_left Mw Mv).trans (le_max_right Q _))))

/-- The displayed M bounds the actual closed-loop mechanical vector, including
both uncertainty and additional damping. -/
theorem mechanical_explicit_bound
    {H g α β h v w A κd z d hlo shi vhi whi Q Amax cz dbar : ℝ}
    (hg : 0≤ g) (hb : 0≤β) (hhlo : 0<hlo) (hD : 0<H+hlo) (hh : hlo≤ h)
    (hκd : 0≤κd) (hq : |heightRate v w|≤ Q) (hs : |(v+w)/2|≤ shi)
    (hv : |v|≤ vhi) (hw : |w|≤ whi) (hA : |A|≤ Amax) (hz : |z|≤ cz) (hd : |d|≤ dbar) :
    let Mw := fallingRateBound H g β hlo shi whi
    let Mv := risingRateBound Mw Amax κd (vhi^2/hlo) cz dbar
    ‖(heightRate v w,rise g (α+d) h v w (robustInput H g α β h v w A κd z),
      fall H g β h v w)‖ ≤ max Q (max Mw Mv) := by
  have hp : 0<h := hhlo.trans_le hh
  have hHp : 0<H+h := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hvsq : v^2≤ vhi^2 := by
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [sq_le_sq₀ (abs_nonneg v) ((abs_nonneg v).trans hv) |>.mpr hv,sq_abs v]
  have hG : |v^2/h|≤ vhi^2/hlo := by
    rw [abs_of_nonneg (div_nonneg (sq_nonneg v) hp.le)]
    exact (div_le_div_of_nonneg_right hvsq hp.le).trans
      (div_le_div_of_nonneg_left (sq_nonneg _) hhlo hh)
  have hfw := falling_rate_bound hg hb hD hh hs hw
  exact mechanical_sup_norm_bound hq
    (rising_rate_bound hp.ne' hHp.ne' hκd hfw hA hG hz hd) hfw

/-- An a.e. derivative bound sharpens any prior local Lipschitz constant to M.
This is the integral justification of the paper's time-Lipschitz estimate. -/
theorem time_lipschitz_of_ae_bound {f : ℝ → ℝ} {L M : ℝ≥0} {a b : ℝ}
    (hf : LipschitzOnWith L f (Icc a b))
    (hb : ∀ᵐ t ∂volume, t∈Ioo a b → |deriv f t|≤ M) :
    LipschitzOnWith M f (Icc a b) := by
  apply LipschitzOnWith.of_dist_le_mul
  intro s hs t ht
  wlog hst : s≤ t generalizing s t
  · rw [dist_comm (f s),dist_comm s]
    exact this t ht s hs (le_of_not_ge hst)
  have hsub : Icc s t⊆Icc a b := Icc_subset_Icc hs.1 ht.2
  obtain ⟨hi,hFTC⟩ := lipschitzOn_integral_deriv hst (hf.mono hsub)
  have hne : ∀ᵐ u ∂volume, u≠t := by simp [ae_iff,measure_singleton]
  have hnorm : ‖∫ u in s..t, deriv f u‖≤(M:ℝ)*(t-s) := by
    rw [←abs_of_nonneg (sub_nonneg.mpr hst)]
    apply intervalIntegral.norm_integral_le_of_norm_le_const_ae
    filter_upwards [hb,hne] with u hu hnt hmem
    rw [uIoc_of_le hst] at hmem
    exact hu ⟨hs.1.trans_lt hmem.1,(lt_of_le_of_ne hmem.2 hnt).trans_le ht.2⟩
  rw [hFTC] at hnorm
  simpa [dist_eq_norm,Real.norm_eq_abs,abs_sub_comm (f s),abs_of_nonpos (sub_nonpos.mpr hst),
    neg_sub] using hnorm

end
end ChainFountain
