module

public import ChainFountain.MeasurablePicard

@[expose] public section

namespace ChainFountain
noncomputable section
open Set Metric Filter Function MeasureTheory intervalIntegral
open scoped Topology NNReal
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

theorem IntegralPicard.fixed_unique (v : IntegralPicard E) (f g : v.FunSpace)
    (hf : f.next=f) (hg : g.next=g) : f=g := by
  obtain ⟨N,K,hK⟩ := v.exists_contracting_iterate
  have hfN : (IntegralPicard.FunSpace.next^[N]) f=f := IsFixedPt.iterate hf N
  have hgN : (IntegralPicard.FunSpace.next^[N]) g=g := IsFixedPt.iterate hg N
  have hi := hK.2.dist_le_mul f g
  rw [hfN,hgN] at hi
  apply dist_le_zero.mp
  have hlt : (K:ℝ)<1 := hK.1
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [dist_nonneg (x:=f) (y:=g)]

/-- Uniqueness on a finite interval for the Lipschitz integral solutions just
constructed. This is proved by the factorial Picard estimate. -/
theorem IntegralPicard.integral_unique (v : IntegralPicard E) {x y : ℝ → E}
    (hxL : LipschitzWith v.C x) (hyL : LipschitzWith v.C y)
    (hx₀ : x v.t₀=v.x₀) (hy₀ : y v.t₀=v.x₀)
    (hx : ∀ t∈Icc v.tMin v.tMax, x t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (x s))
    (hy : ∀ t∈Icc v.tMin v.tMax, y t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (y s)) :
    EqOn x y (Icc v.tMin v.tMax) := by
  let f : v.FunSpace := ⟨fun t => x t,hx₀,by simpa using! hxL.comp (LipschitzWith.subtype_val _)⟩
  let g : v.FunSpace := ⟨fun t => y t,hy₀,by simpa using! hyL.comp (LipschitzWith.subtype_val _)⟩
  have hf : f.next=f := by
    apply IntegralPicard.FunSpace.toContinuousMap.injective
    apply ContinuousMap.ext
    intro t
    change v.x₀+∫ s in (v.t₀:ℝ)..(t:ℝ), v s (x (v.proj s)) = x t
    rw [hx t t.property]
    congr 1
    apply intervalIntegral.integral_congr
    intro s hs
    dsimp only
    rw [v.proj_of_mem (uIcc_subset_Icc v.t₀.property t.property hs)]
  have hg : g.next=g := by
    apply IntegralPicard.FunSpace.toContinuousMap.injective
    apply ContinuousMap.ext
    intro t
    change v.x₀+∫ s in (v.t₀:ℝ)..(t:ℝ), v s (y (v.proj s)) = y t
    rw [hy t t.property]
    congr 1
    apply intervalIntegral.integral_congr
    intro s hs
    dsimp only
    rw [v.proj_of_mem (uIcc_subset_Icc v.t₀.property t.property hs)]
  have he := v.fixed_unique f g hf hg
  intro t ht
  exact congrArg (fun z : v.FunSpace => z ⟨t,ht⟩) he

/-- Arbitrary measurable time dependence is allowed. The hypotheses contain
only the field and its global bounds; the Lipschitz integral solution is built
on the entire real line by gluing unique finite-horizon fixed points. -/
theorem bounded_measurable_global_integral_exists
    {F : ℝ → E → E} {L C : ℝ≥0}
    (hL : ∀ t, LipschitzWith L (F t))
    (hMeas : ∀ f : ℝ → E, Continuous f → AEStronglyMeasurable (fun t => F t (f t)) volume)
    (hC : ∀ t x, ‖F t x‖≤ C) (x₀ : E) :
    ∃ x : ℝ → E, LipschitzWith C x ∧ x 0=x₀ ∧
      ∀ t, x t=x₀+∫ s in (0:ℝ)..t, F s (x s) := by
  let data (a : ℝ) : IntegralPicard E :=
    { toFun := F, tMin := -|a|, tMax := |a|,
      t₀ := ⟨0,by constructor <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [abs_nonneg a]⟩,
      x₀ := x₀, C := C, L := L,
      lipschitz_all := hL, measurable_curve := hMeas, bound_all := hC }
  have hex (a : ℝ) := (data a).exists_integral_solution
  choose f hfL hf₀ hfI using hex
  have agree {a b : ℝ} (ha : 0≤ a) (hab : a≤ b) : EqOn (f a) (f b) (Icc (-a) a) := by
    have hb : 0≤ b := ha.trans hab
    have hfa : ∀ t∈Icc (data a).tMin (data a).tMax,
        f a t=(data a).x₀+∫ s in ((data a).t₀:ℝ)..t, (data a) s (f a s) := hfI a
    have hfb : ∀ t∈Icc (data a).tMin (data a).tMax,
        f b t=(data a).x₀+∫ s in ((data a).t₀:ℝ)..t, (data a) s (f b s) := by
      intro t ht
      apply hfI b
      dsimp [data] at ht ⊢
      rw [abs_of_nonneg ha] at ht
      rw [abs_of_nonneg hb]
      exact ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [ht.1],ht.2.trans hab⟩
    simpa [data,abs_of_nonneg ha] using! (data a).integral_unique
      (hfL a) (hfL b) (hf₀ a) (hf₀ b) hfa hfb
  let x : ℝ → E := fun t => f (|t|+1) t
  have heq {a : ℝ} (ha : 0≤ a) : EqOn x (f a) (Icc (-a) a) := by
    intro t ht
    by_cases hab : |t|+1≤ a
    · exact agree (by positivity) hab (abs_le.mp (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith : |t|≤|t|+1))
    · exact (agree ha (le_of_not_ge hab) ht).symm
  have hxL : LipschitzWith C x := by
    apply LipschitzWith.of_dist_le_mul
    intro t s
    let a := |t|+|s|+1
    have ha : 0≤ a := by dsimp [a]; positivity
    have ht : t∈Icc (-a) a := abs_le.mp (by dsimp [a]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [abs_nonneg s])
    have hs : s∈Icc (-a) a := abs_le.mp (by dsimp [a]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [abs_nonneg t])
    rw [heq ha ht,heq ha hs]
    exact (hfL a).dist_le_mul t s
  refine ⟨x,hxL,by simpa [x,data] using! hf₀ 1,fun t => ?_⟩
  let a := |t|+1
  have ha : 0≤ a := by dsimp [a]; positivity
  have ht : t∈Icc (-a) a := abs_le.mp (by dsimp [a]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith)
  have hzero : (0:ℝ)∈Icc (-a) a := ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith,ha⟩
  rw [heq ha ht]
  have hi := hfI a t (by simpa [data,abs_of_nonneg ha] using! ht)
  dsimp [data] at hi
  rw [hi]
  congr 1
  apply intervalIntegral.integral_congr
  intro s hs
  dsimp only
  rw [heq ha (uIcc_subset_Icc hzero ht hs)]

end
end ChainFountain
