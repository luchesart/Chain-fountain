module

public import ChainFountain.Convergence

@[expose] public section

namespace ChainFountain
noncomputable section
open Set Real

/-- Explicit positive-branch solution of `w' = a (s²-w²)`. The formula is
defined on all real times; the theorem only asserts regularity for `t ≥ 0`. -/
def zeroFlow (a s w₀ t : ℝ) : ℝ :=
  s * (1 + ((w₀-s)/(w₀+s))*exp (-2*a*s*t)) /
    (1 - ((w₀-s)/(w₀+s))*exp (-2*a*s*t))

theorem zero_ratio_abs_lt_one {s w₀ : ℝ} (hs : 0<s) (hw : 0<w₀) :
    |(w₀-s)/(w₀+s)|<1 := by
  rw [abs_div,abs_of_pos (add_pos hw hs),div_lt_one (add_pos hw hs)]
  exact abs_lt.mpr ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith,by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith⟩

theorem zero_flow_den_pos {a s w₀ t : ℝ}
    (ha : 0<a) (hs : 0<s) (hw : 0<w₀) (ht : 0≤ t) :
    0<1-((w₀-s)/(w₀+s))*exp (-2*a*s*t) := by
  have he : exp (-2*a*s*t)≤1 := exp_le_one_iff.mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_nonneg (mul_nonneg ha.le hs.le) ht])
  have hq := zero_ratio_abs_lt_one hs hw
  have hprod : |((w₀-s)/(w₀+s))*exp (-2*a*s*t)|<1 := by
    rw [abs_mul,abs_of_pos (exp_pos _)]
    exact (mul_le_mul_of_nonneg_left he (abs_nonneg _)).trans_lt (by simpa using! hq)
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(abs_lt.mp hprod).2]

theorem zero_flow_pos {a s w₀ t : ℝ}
    (ha : 0<a) (hs : 0<s) (hw : 0<w₀) (ht : 0≤ t) :
    0<zeroFlow a s w₀ t := by
  have he : exp (-2*a*s*t)≤1 := exp_le_one_iff.mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_nonneg (mul_nonneg ha.le hs.le) ht])
  have hq := zero_ratio_abs_lt_one hs hw
  have hp : |((w₀-s)/(w₀+s))*exp (-2*a*s*t)|<1 := by
    rw [abs_mul,abs_of_pos (exp_pos _)]
    exact (mul_le_mul_of_nonneg_left he (abs_nonneg _)).trans_lt (by simpa using! hq)
  exact div_pos (mul_pos hs (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(abs_lt.mp hp).1]))
    (zero_flow_den_pos ha hs hw ht)

theorem zero_flow_initial {a s w₀ : ℝ} (hs : 0<s) (hw : 0<w₀) :
    zeroFlow a s w₀ 0=w₀ := by
  have hd : w₀+s≠0 := (add_pos hw hs).ne'
  have hq : 1-(w₀-s)/(w₀+s)≠0 := by
    have hh := (abs_lt.mp (zero_ratio_abs_lt_one hs hw)).2
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  dsimp [zeroFlow]
  simp only [mul_zero,exp_zero,mul_one]
  field_simp [hs.ne']
  <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem zero_flow_derivative {a s w₀ t : ℝ}
    (ha : 0<a) (hs : 0<s) (hw : 0<w₀) (ht : 0≤ t) :
    HasDerivAt (zeroFlow a s w₀) (a*(s^2-(zeroFlow a s w₀ t)^2)) t := by
  have hd := (zero_flow_den_pos ha hs hw ht).ne'
  have de := (((hasDerivAt_id t).const_mul (-2*a*s)).exp).const_mul ((w₀-s)/(w₀+s))
  have dh := ((de.const_add 1).const_mul s).div (de.const_sub 1) hd
  convert! dh using 1
  dsimp only [zeroFlow, id_eq]
  generalize (w₀-s)/(w₀+s) = q at hd ⊢
  generalize exp (-2*a*s*t) = E at hd ⊢
  field_simp [hd]
  <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- Global positive solution and the paper's exact exponential estimate, for
every positive initial speed. Existence is supplied by `zeroFlow`, not assumed. -/
theorem exists_global_zero_dynamics {H g β r s w₀ : ℝ}
    (hD : 0<H+r) (hβ : β<1) (hs : 0<s) (hw : 0<w₀)
    (heq : (1-β)*s^2=g*(H+r)) :
    ∃ w : ℝ → ℝ, w 0=w₀ ∧ ∀ t≥0,
      0<w t ∧ HasDerivAt w (internal H g β r (w t) 0) t ∧
      |w t-s|≤|w₀-s| *exp (-((1-β)*s/(H+r))*t) := by
  let a := (1-β)/(H+r)
  have ha : 0<a := div_pos (sub_pos.mpr hβ) hD
  let w := zeroFlow a s w₀
  have hd (t : ℝ) (ht : 0≤ t) := zero_flow_derivative ha hs hw ht
  have hp (t : ℝ) (ht : 0≤ t) : 0<w t := zero_flow_pos ha hs hw ht
  have hinit : w 0=w₀ := zero_flow_initial hs hw
  refine ⟨w,hinit,?_⟩
  intro t ht
  have hc : ContinuousOn w (Icc 0 t) :=
    fun u hu => (hd u hu.1).continuousAt.continuousWithinAt
  refine ⟨hp t ht,?_,?_⟩
  · convert! hd t ht using 1
    dsimp [internal,a]
    field_simp
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [heq]
  · have hdec := scalar_exponential_decay (y:=fun u => w u-s)
      (a:=fun u => a*(s+w u)) (f:=fun _ => 0) (T:=t)
      (ρ:=a*s) (δ:=0) (M:=|w₀-s|)
      (continuousOn_const.mul (continuousOn_const.add hc))
      (hc.sub continuousOn_const)
      (fun u hu => by
        convert! ((hd u hu.1).sub_const s).hasDerivWithinAt using 1 <;> dsimp [w] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring)
      (abs_nonneg _) (fun u hu => by
        change a*s+0≤ a*(s+w u)
        (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_pos ha (hp u hu.1)])
      (by intro u hu; simp) (by simpa only [hinit] using! le_refl |w₀-s|) t ⟨ht,le_rfl⟩
    convert! hdec using 1 <;> dsimp [a] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

end
end ChainFountain
