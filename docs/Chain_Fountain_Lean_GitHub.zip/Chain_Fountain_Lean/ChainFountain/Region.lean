module

public import ChainFountain.Comparison

@[expose] public section

namespace ChainFountain
noncomputable section
open Real Set

def internal (H g β h w q : ℝ) : ℝ :=
  (g * (H + h) - (1 - β) * w ^ 2 - 2 * q * w - q ^ 2) / (H + h)

theorem internal_identity (H g β h w q : ℝ) (hH : H + h ≠ 0) :
    fall H g β h (w + 2*q) w = internal H g β h w q := by
  unfold fall internal crownSq; field_simp <;> ring

theorem error_height_sq {k₀ e z cap : ℝ} (hk : 0 < k₀)
    (hV : errorEnergy k₀ e z ≤ cap) : e ^ 2 ≤ 2 * cap / k₀ := by
  rw [le_div_iff₀ hk]
  unfold errorEnergy at hV; nlinarith [sq_nonneg z]

theorem error_z_sq {k₀ e z cap : ℝ} (hk : 0 ≤ k₀)
    (hV : errorEnergy k₀ e z ≤ cap) : z ^ 2 ≤ 8 * cap := by
  unfold errorEnergy at hV
  nlinarith [mul_nonneg hk (sq_nonneg e)]

/-- The weighted Cauchy--Schwarz estimate used in (6.1). -/
theorem error_q_sq {k₀ k₁ e z cap : ℝ} (hk : 0 < k₀)
    (hV : errorEnergy k₀ e z ≤ cap) :
    (z / 2 - k₁ * e) ^ 2 ≤ 2 * cap * (1 + k₁ ^ 2 / k₀) := by
  have hid : (2 * errorEnergy k₀ e z * (1 + k₁ ^ 2 / k₀) -
      (z/2-k₁*e)^2) * k₀ = (k₀ * e + k₁ * z / 2) ^ 2 := by
    unfold errorEnergy; field_simp <;> ring
  have hnon : 0 ≤ (2 * errorEnergy k₀ e z * (1 + k₁ ^ 2 / k₀) -
      (z/2-k₁*e)^2) := by
    apply nonneg_of_mul_nonneg_left (b:=k₀)
    · rw [hid]; exact sq_nonneg _
    · exact hk
  have hp : 0 ≤ 1 + k₁ ^ 2 / k₀ := by positivity
  have hm := mul_le_mul_of_nonneg_right hV hp
  linarith

theorem error_enclosure {k₀ k₁ e z cap : ℝ} (hk : 0 < k₀)
    (hV : errorEnergy k₀ e z ≤ cap) :
    |e| ≤ sqrt (2 * cap / k₀) ∧ |z| ≤ sqrt (8 * cap) ∧
    |z / 2 - k₁ * e| ≤ sqrt (2 * cap) * sqrt (1 + k₁ ^ 2 / k₀) := by
  have hc : 0 ≤ cap := (energy_nonneg hk.le e z).trans hV
  refine ⟨abs_le_sqrt (error_height_sq hk hV), abs_le_sqrt (error_z_sq hk.le hV), ?_⟩
  have h := abs_le_sqrt (error_q_sq (k₁:=k₁) hk hV)
  rwa [sqrt_mul (by positivity : 0 ≤ 2 * cap)] at h

theorem transport_positive {w q Q wlo vmin : ℝ}
    (hw : wlo ≤ w) (hq : |q| ≤ Q) (hforward : 2 * Q < wlo)
    (hcrown : vmin ≤ wlo - Q) :
    0 < w + 2 * q ∧ vmin ≤ w + q := by
  have hq' := abs_le.mp hq
  constructor <;> linarith

theorem height_enclosure {h r rlo rhi ce : ℝ}
    (hr : rlo ≤ r ∧ r ≤ rhi) (he : |h-r| ≤ ce) :
    rlo-ce ≤ h ∧ h ≤ rhi+ce := by
  have he' := abs_le.mp he; constructor <;> linarith

theorem q_enclosure {q r₁ cq R₁ : ℝ}
    (hr : |r₁| ≤ R₁) (hq : |q-r₁| ≤ cq) : |q| ≤ R₁+cq := by
  have hh := abs_add_le (q-r₁) r₁
  rw [sub_add_cancel] at hh; linarith

theorem lower_face {H g β h hlo wlo Q q : ℝ}
    (hden : 0 < H + h) (hg : 0 ≤ g) (hh : hlo ≤ h)
    (hq : |q| ≤ Q) (hw : 2 * Q < wlo)
    (hface : (1-β) * wlo^2 + 2*Q*wlo + Q^2 ≤ g*(H+hlo)) :
    0 ≤ internal H g β h wlo q := by
  have hQ : 0 ≤ Q := (abs_nonneg q).trans hq
  have hq' := abs_le.mp hq
  have hs : (wlo+q)^2 ≤ (wlo+Q)^2 := by
    apply pow_le_pow_left₀ (by linarith) (by linarith)
  have hgh := mul_le_mul_of_nonneg_left hh hg
  unfold internal
  apply div_nonneg _ hden.le
  nlinarith

theorem upper_face {H g β h hhi whi Q q : ℝ}
    (hden : 0 < H + h) (hg : 0 ≤ g) (hh : h ≤ hhi)
    (hq : |q| ≤ Q) (hw : 2 * Q < whi)
    (hface : g*(H+hhi) ≤ (1-β) * whi^2 - 2*Q*whi + Q^2) :
    internal H g β h whi q ≤ 0 := by
  have hQ : 0 ≤ Q := (abs_nonneg q).trans hq
  have hq' := abs_le.mp hq
  have hs : (whi-Q)^2 ≤ (whi+q)^2 := by
    apply pow_le_pow_left₀ (by linarith) (by linarith)
  have hgh := mul_le_mul_of_nonneg_left hh hg
  unfold internal
  apply div_nonpos_of_nonpos_of_nonneg _ hden.le
  nlinarith

/-- Difference factorization needed to integrate the inward face inequalities. -/
theorem internal_difference (H g β h w b q : ℝ) :
    internal H g β h w q - internal H g β h b q =
      -(((1-β)*(w+b)+2*q)/(H+h))*(w-b) := by
  unfold internal; ring

theorem zero_dynamics_factor (H g β r w wr : ℝ)
    (hden : H+r ≠ 0) (heq : (1-β)*wr^2=g*(H+r)) :
    internal H g β r w 0 = -(1-β)/(H+r)*(w+wr)*(w-wr) := by
  unfold internal; field_simp <;> nlinarith [heq]

theorem fullstate_forcing_identity (H g β r e q w wr : ℝ)
    (hden : H+(r+e) ≠ 0) (heq : (1-β)*wr^2=g*(H+r)) :
    internal H g β (r+e) w q =
      -(1-β)*(w+wr)/(H+(r+e))*(w-wr) +
        (g*e-2*q*w-q^2)/(H+(r+e)) := by
  unfold internal; field_simp <;> nlinarith [heq]

end
end ChainFountain
