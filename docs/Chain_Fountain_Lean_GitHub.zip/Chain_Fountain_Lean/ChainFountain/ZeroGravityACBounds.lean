module

public import ChainFountain.ZeroGravityAC

@[expose] public section

/-!
# Almost-everywhere circulation estimates and unrestricted AC uniqueness

The hypotheses are genuine metric absolute continuity and an almost-everywhere
ODE. Neither an integral representation nor an assumed Lipschitz bound is
required of a competing solution.
-/
namespace ChainFountain.ZeroGravity
noncomputable section
open Set Filter MeasureTheory Real
open scoped Topology NNReal

/-- Every locally AC scalar solution has the integrating-factor representation.
Integrability of the weighted forcing is a consequence, not a hypothesis. -/
theorem circulation_ac_variation_of_constants {e d : ℝ → ℝ} {a t : ℝ}
    (ht : 0 ≤ t)
    (he : AbsolutelyContinuousOnInterval e 0 t)
    (hd : ∀ᵐ s ∂volume, 0 ≤ s → HasDerivAt e (-a * e s + d s) s) :
    IntervalIntegrable (fun s => exp (a * s) * d s) volume 0 t ∧
      e t = circulationForcedError d a (e 0) t := by
  have hexp : ContDiff ℝ 1 (fun s : ℝ => exp (a * s)) := by fun_prop
  have hW : AbsolutelyContinuousOnInterval (fun s => exp (a * s) * e s) 0 t :=
    hexp.contDiffOn.absolutelyContinuousOnInterval.fun_mul he
  have hWd : ∀ᵐ s ∂volume, s ∈ uIcc 0 t →
      HasDerivAt (fun z => exp (a * z) * e z) (exp (a * s) * d s) s := by
    filter_upwards [hd] with s hs hmem
    rw [uIcc_of_le ht] at hmem
    have h := ((((hasDerivAt_id s).const_mul a).exp).mul (hs hmem.1))
    convert! h using 1
    simp only [id_eq]
    ring
  obtain ⟨hi,hI⟩ := ChainFountain.ac_integral_eq_sub hW hWd
  refine ⟨hi,?_⟩
  have hcancel : exp (-a * t) * exp (a * t) = 1 := by
    rw [← exp_add, show -a * t + a * t = 0 by ring, exp_zero]
  unfold circulationForcedError
  rw [hI]
  simp only [mul_zero,exp_zero,one_mul]
  calc
    e t = (exp (-a * t) * exp (a * t)) * e t := by rw [hcancel,one_mul]
    _ = exp (-a * t) * (e 0 + (exp (a * t) * e t - e 0)) := by ring

/-- Uniqueness among all forward locally absolutely continuous solutions of
an a.e. scalar equation. No safe box or Lipschitz hypothesis is imposed. -/
theorem circulation_ac_unique {e₁ e₂ d : ℝ → ℝ} {a : ℝ}
    (hinit : e₁ 0 = e₂ 0)
    (h₁ : ∀ T ≥ 0, AbsolutelyContinuousOnInterval e₁ 0 T)
    (h₂ : ∀ T ≥ 0, AbsolutelyContinuousOnInterval e₂ 0 T)
    (hd₁ : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt e₁ (-a * e₁ t + d t) t)
    (hd₂ : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt e₂ (-a * e₂ t + d t) t) :
    ∀ t ≥ 0, e₁ t = e₂ t := by
  intro t ht
  rw [(circulation_ac_variation_of_constants ht (h₁ t ht) hd₁).2,
    (circulation_ac_variation_of_constants ht (h₂ t ht) hd₂).2,hinit]

/-- Explicit integral of the positive exponential comparison kernel. -/
theorem circulation_exp_integral {a D t : ℝ} (ha : a ≠ 0) :
    (∫ s in (0 : ℝ)..t, exp (a * s) * D) = D / a * (exp (a * t) - 1) := by
  have hint : IntervalIntegrable (fun s : ℝ => exp (a * s) * D) volume 0 t :=
    (by fun_prop : Continuous (fun s : ℝ => exp (a * s) * D)).intervalIntegrable 0 t
  have hd : ∀ s ∈ uIcc 0 t,
      HasDerivAt (fun z : ℝ => D / a * exp (a * z)) (exp (a * s) * D) s := by
    intro s _
    convert! ((((hasDerivAt_id s).const_mul a).exp).const_mul (D / a)) using 1
    simp only [id_eq]
    field_simp
  rw [intervalIntegral.integral_eq_sub_of_hasDerivAt hd hint]
  simp only [mul_zero,exp_zero,mul_one]
  ring

/-- The sharp weighted forcing estimate uses only an almost-everywhere bound. -/
theorem circulation_weighted_integral_bound {d : ℝ → ℝ} {a D t : ℝ}
    (ha : 0 < a) (ht : 0 ≤ t)
    (hb : ∀ᵐ s ∂volume, 0 ≤ s → |d s| ≤ D) :
    |∫ s in (0 : ℝ)..t, exp (a * s) * d s| ≤ D / a * (exp (a * t) - 1) := by
  have hint : IntervalIntegrable (fun s : ℝ => exp (a * s) * D) volume 0 t :=
    (by fun_prop : Continuous (fun s : ℝ => exp (a * s) * D)).intervalIntegrable 0 t
  have hnorm : ∀ᵐ s ∂volume, s ∈ Ioc (0 : ℝ) t →
      ‖exp (a * s) * d s‖ ≤ exp (a * s) * D := by
    filter_upwards [hb] with s hs hmem
    simp only [Real.norm_eq_abs,abs_mul,abs_of_pos (exp_pos _)]
    exact mul_le_mul_of_nonneg_left (hs hmem.1.le) (exp_pos _).le
  have h := intervalIntegral.norm_integral_le_of_norm_le ht hnorm hint
  rw [Real.norm_eq_abs,circulation_exp_integral (ne_of_gt ha)] at h
  exact h

/-- Sharp global error envelope for genuinely locally AC/a.e. solutions. -/
theorem circulation_ac_error_bound {e d : ℝ → ℝ} {a D : ℝ}
    (ha : 0 < a)
    (he : ∀ T ≥ 0, AbsolutelyContinuousOnInterval e 0 T)
    (hd : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt e (-a * e t + d t) t)
    (hb : ∀ᵐ t ∂volume, 0 ≤ t → |d t| ≤ D) :
    ∀ t ≥ 0, |e t| ≤ circulationEnvelope (e 0) a D t := by
  intro t ht
  have hrep := (circulation_ac_variation_of_constants ht (he t ht) hd).2
  have hI := circulation_weighted_integral_bound ha ht hb
  rw [hrep]
  unfold circulationForcedError
  rw [abs_mul,abs_of_pos (exp_pos _)]
  calc
    exp (-a * t) * |e 0 + ∫ s in (0 : ℝ)..t, exp (a * s) * d s| ≤
      exp (-a * t) * (|e 0| + D / a * (exp (a * t) - 1)) := by
      apply mul_le_mul_of_nonneg_left _ (exp_pos _).le
      exact (abs_add_le _ _).trans (add_le_add le_rfl hI)
    _ = circulationEnvelope (e 0) a D t := by
      have hcancel : exp (-a * t) * exp (a * t) = 1 := by
        rw [← exp_add, show -a * t + a * t = 0 by ring, exp_zero]
      unfold circulationEnvelope
      have hh := congrArg (fun x : ℝ => x * (D / a)) hcancel
      nlinarith


/-- The a.e. closed-loop equation induces the same a.e. stable error equation. -/
theorem circulation_ac_closedLoop_error {c r rdot d : ℝ → ℝ} {γ k : ℝ}
    (hc : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c
      (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) t)
    (hr : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt r (rdot t) t) :
    ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt (fun s => c s - r s)
      (-(γ + k) * (c t - r t) + d t) t := by
  filter_upwards [hc, hr] with t ht hrt hpos
  exact circulation_error_hasDerivAt (ht hpos) (hrt hpos)

/-- The sharp estimate applies to every locally AC closed-loop speed. -/
theorem circulation_ac_closedLoop_bound {c r rdot d : ℝ → ℝ} {γ k D : ℝ}
    (ha : 0 < γ + k)
    (hcAC : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T)
    (hrAC : ∀ T ≥ 0, AbsolutelyContinuousOnInterval r 0 T)
    (hc : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c
      (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) t)
    (hr : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt r (rdot t) t)
    (hb : ∀ᵐ t ∂volume, 0 ≤ t → |d t| ≤ D) :
    ∀ t ≥ 0, |c t - r t| ≤ circulationEnvelope (c 0 - r 0) (γ + k) D t := by
  exact circulation_ac_error_bound ha (fun T hT => (hcAC T hT).fun_sub (hrAC T hT))
    (circulation_ac_closedLoop_error hc hr) hb

/-- Uniqueness is forward in time and covers every locally AC competitor. -/
theorem circulation_ac_closedLoop_unique {c₁ c₂ r rdot d : ℝ → ℝ} {γ k : ℝ}
    (hinit : c₁ 0 = c₂ 0)
    (h₁ : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c₁ 0 T)
    (h₂ : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c₂ 0 T)
    (hrAC : ∀ T ≥ 0, AbsolutelyContinuousOnInterval r 0 T)
    (hd₁ : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c₁
      (circulationCommand γ k (r t) (rdot t) (c₁ t) - γ * c₁ t + d t) t)
    (hd₂ : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c₂
      (circulationCommand γ k (r t) (rdot t) (c₂ t) - γ * c₂ t + d t) t)
    (hr : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt r (rdot t) t) :
    ∀ t ≥ 0, c₁ t = c₂ t := by
  have hu := circulation_ac_unique (by rw [hinit] : c₁ 0 - r 0 = c₂ 0 - r 0)
    (fun T hT => (h₁ T hT).fun_sub (hrAC T hT))
    (fun T hT => (h₂ T hT).fun_sub (hrAC T hT))
    (circulation_ac_closedLoop_error hd₁ hr) (circulation_ac_closedLoop_error hd₂ hr)
  intro t ht
  have h := hu t ht
  linarith

/-- The pointwise lower tension estimate complements the existing upper bound. -/
theorem circulation_tension_lower {lam c rmin ρ : ℝ}
    (hlam : 0 ≤ lam) (hmargin : ρ ≤ rmin) (hc : rmin - ρ ≤ c) :
    lam * (rmin - ρ)^2 ≤ lam * c^2 := by
  apply mul_le_mul_of_nonneg_left _ hlam
  have hlo : 0 ≤ rmin - ρ := sub_nonneg.mpr hmargin
  nlinarith [mul_nonneg (sub_nonneg.mpr hc) (show 0 ≤ c + (rmin - ρ) by linarith)]

/-- All forward-time physical bounds hold pointwise, although the disturbance
bound and differential equation hold only almost everywhere. -/
theorem circulation_ac_physical_bounds {c r rdot d : ℝ → ℝ}
    {γ k D lam rmin rmax A : ℝ}
    (hγ : 0 ≤ γ) (hk : 0 ≤ k) (ha : 0 < γ + k) (hlam : 0 < lam)
    (hcAC : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T)
    (hrAC : ∀ T ≥ 0, AbsolutelyContinuousOnInterval r 0 T)
    (hc : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c
      (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) t)
    (hr : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt r (rdot t) t)
    (hb : ∀ᵐ t ∂volume, 0 ≤ t → |d t| ≤ D)
    (href : ∀ t ≥ 0, rmin ≤ r t ∧ r t ≤ rmax)
    (hrdot : ∀ t ≥ 0, |rdot t| ≤ A)
    (hmargin : max |c 0 - r 0| (D / (γ + k)) < rmin) :
    ∀ t ≥ 0, let ρ := max |c 0 - r 0| (D / (γ + k))
      |c t - r t| ≤ circulationEnvelope (c 0 - r 0) (γ + k) D t ∧
      |c t - r t| ≤ ρ ∧
      rmin - ρ ≤ c t ∧ c t ≤ rmax + ρ ∧ 0 < c t ∧
      lam * (rmin - ρ)^2 ≤ lam * (c t)^2 ∧
      lam * (c t)^2 ≤ lam * (rmax + ρ)^2 ∧ 0 < lam * (c t)^2 ∧
      |circulationCommand γ k (r t) (rdot t) (c t)| ≤ A + γ * rmax + k * ρ := by
  intro t ht
  let ρ := max |c 0 - r 0| (D / (γ + k))
  have hρ : 0 ≤ ρ := (abs_nonneg _).trans (le_max_left _ _)
  have herr := circulation_ac_closedLoop_bound ha hcAC hrAC hc hr hb t ht
  have hcap : |c t - r t| ≤ ρ := herr.trans (circulation_envelope_below_max ha ht)
  have hrl := (href t ht).1
  have hru := (href t ht).2
  have hl : rmin - ρ ≤ c t := by linarith [(abs_le.mp hcap).1]
  have hu : c t ≤ rmax + ρ := by linarith [(abs_le.mp hcap).2]
  have hpos : 0 < c t := by change ρ < rmin at hmargin; linarith
  refine ⟨herr, hcap, hl, hu, hpos, ?_, ?_, loop_tension_positive hlam hpos, ?_⟩
  · exact circulation_tension_lower hlam.le hmargin.le hl
  · exact circulation_tension_upper hlam.le hpos.le hru hcap
  · exact circulation_command_bound hγ hk (by change ρ < rmin at hmargin; linarith)
      hru (hrdot t ht) hcap


/-- Global well-posedness and physical admissibility with merely measurable,
essentially bounded forcing. The speed is constructed, uniqueness includes every
forward locally AC competitor, and every physical bound holds at every t≥0. -/
theorem circulation_measurable_global_wellposed {r rdot d : ℝ → ℝ}
    {γ k c0 D lam rmin rmax A : ℝ}
    (hγ : 0 ≤ γ) (hk : 0 ≤ k) (ha : 0 < γ + k) (hlam : 0 < lam)
    (hrC1 : ContDiffOn ℝ 1 r (Ici 0))
    (hr : ∀ t > 0, HasDerivAt r (rdot t) t)
    (hd : AEMeasurable d (volume.restrict (Ici 0)))
    (hb : ∀ᵐ t ∂volume, 0 ≤ t → |d t| ≤ D)
    (href : ∀ t ≥ 0, rmin ≤ r t ∧ r t ≤ rmax)
    (hrdot : ∀ t ≥ 0, |rdot t| ≤ A)
    (hmargin : max |c0 - r 0| (D / (γ + k)) < rmin) :
    let ρ := max |c0 - r 0| (D / (γ + k))
    ∃ c : ℝ → ℝ, c 0 = c0 ∧
      (∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T) ∧
      (∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c
        (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) t) ∧
      (∀ t ≥ 0,
        IntervalIntegrable (fun s => circulationCommand γ k (r s) (rdot s) (c s)
          - γ * c s + d s) volume 0 t ∧
        c t = c0 + ∫ s in (0 : ℝ)..t,
          circulationCommand γ k (r s) (rdot s) (c s) - γ * c s + d s) ∧
      (∀ c₂ : ℝ → ℝ, c₂ 0 = c0 →
        (∀ T ≥ 0, AbsolutelyContinuousOnInterval c₂ 0 T) →
        (∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c₂
          (circulationCommand γ k (r t) (rdot t) (c₂ t) - γ * c₂ t + d t) t) →
        ∀ t ≥ 0, c₂ t = c t) ∧
      (∀ t ≥ 0,
        |c t - r t| ≤ circulationEnvelope (c0 - r 0) (γ + k) D t ∧
        |c t - r t| ≤ ρ ∧
        rmin - ρ ≤ c t ∧ c t ≤ rmax + ρ ∧ 0 < c t ∧
        lam * (rmin - ρ)^2 ≤ lam * (c t)^2 ∧
        lam * (c t)^2 ≤ lam * (rmax + ρ)^2 ∧ 0 < lam * (c t)^2 ∧
        |circulationCommand γ k (r t) (rdot t) (c t)| ≤ A + γ * rmax + k * ρ) := by
  have hdi := forward_intervalIntegrable_of_aebounded_restrict hd hb
  have hrAE := forward_ae_hasDerivAt_of_pos hr
  have hrAC := forward_locallyAC_of_contDiffOn hrC1
  let c := circulationACSolution r d γ k c0
  have hc0 : c 0 = c0 := circulationACSolution_initial r d γ k c0
  have hcAC : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c 0 T :=
    circulationACSolution_locallyAC hrAC hdi
  have hc : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c
      (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t) t :=
    circulationACSolution_ae hrAE hdi
  have hI := circulationACSolution_integral (γ := γ) (k := k) (c0 := c0) hrAC hrAE hdi
  refine ⟨c, hc0, hcAC, hc, hI, ?_, ?_⟩
  · intro c₂ hc₂0 hc₂AC hc₂
    exact circulation_ac_closedLoop_unique (hc₂0.trans hc0.symm) hc₂AC hcAC hrAC hc₂ hc hrAE
  · have hm : max |c 0 - r 0| (D / (γ + k)) < rmin := by simpa only [hc0] using hmargin
    simpa only [hc0] using
      circulation_ac_physical_bounds hγ hk ha hlam hcAC hrAC hc hrAE hb href hrdot hm

end
end ChainFountain.ZeroGravity
