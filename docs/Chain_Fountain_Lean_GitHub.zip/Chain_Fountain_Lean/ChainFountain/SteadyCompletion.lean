module

public import ChainFountain.Model

@[expose] public section

namespace ChainFountain
noncomputable section
open Set Real

/-- The reverse inverse identity completes the affine input/height bijection. -/
theorem height_input_inverse (H g α β u : ℝ)
    (hg : g ≠ 0) (hβ : 1-β ≠ 0) (hαβ : 1-α-β ≠ 0) :
    steadyInput H g α β (heightFromInput H g α β u) = u := by
  unfold steadyInput heightFromInput
  field_simp
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem steady_input_antitone {H g α β : ℝ}
    (hg : 0 < g) (hβ : 0 < 1-β) (hαβ : 0 < 1-α-β) :
    StrictAnti (steadyInput H g α β) := by
  intro a b hab
  unfold steadyInput
  apply (div_lt_div_iff_of_pos_right hβ).mpr
  exact mul_lt_mul_of_pos_left (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith) hg

/-- Exact actuator interval, with the reversed height endpoints. -/
theorem steady_actuator_interval {H g α β r uLo uHi : ℝ}
    (hg : 0 < g) (hβ : 0 < 1-β) (hαβ : 0 < 1-α-β) :
    steadyInput H g α β r ∈ Icc uLo uHi ↔
      r ∈ Icc (heightFromInput H g α β uHi) (heightFromInput H g α β uLo) := by
  have hanti := steady_input_antitone (H:=H) hg hβ hαβ
  have hinv := height_input_inverse H g α β
  constructor
  · intro h
    constructor
    · by_contra hn
      have hc := hanti (lt_of_not_ge hn)
      rw [hinv uHi hg.ne' hβ.ne' hαβ.ne'] at hc
      exact (not_lt_of_ge h.2) hc
    · by_contra hn
      have hc := hanti (lt_of_not_ge hn)
      rw [hinv uLo hg.ne' hβ.ne' hαβ.ne'] at hc
      exact (not_lt_of_ge h.1) hc
  · rintro ⟨hl,hu⟩
    constructor
    · have h := hanti.antitone hu
      rwa [hinv uLo hg.ne' hβ.ne' hαβ.ne'] at h
    · have h := hanti.antitone hl
      rwa [hinv uHi hg.ne' hβ.ne' hαβ.ne'] at h

/-- Positive equilibrium uniqueness includes unequal-speed candidate states. -/
theorem positive_equilibrium_iff {H g α β r v w u : ℝ}
    (hH : 0 < H) (hg : 0 < g) (hβ : β < 1) (hr : 0 < r) (hv : 0 < v) :
    (heightRate v w = 0 ∧ rise g α r v w u = 0 ∧ fall H g β r v w = 0) ↔
      (v = sqrt (steadySpeedSq H g β r) ∧ w = v ∧ u = steadyInput H g α β r) := by
  have hden : H+r ≠ 0 := (add_pos hH hr).ne'
  have hb : 1-β ≠ 0 := (sub_pos.mpr hβ).ne'
  have hbpos : 0 < 1-β := sub_pos.mpr hβ
  constructor
  · rintro ⟨hq,hu,hf⟩
    have hw : w=v := by unfold heightRate at hq; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
    rw [hw] at hu hf
    obtain ⟨hs,hi⟩ := (steady_state_iff hr.ne' hden hb).mp ⟨hu,hf⟩
    refine ⟨?_,hw,hi⟩
    rw [←hs, sqrt_sq_eq_abs,abs_of_pos hv]
  · rintro ⟨hs,rfl,rfl⟩
    apply steady_is_equilibrium hr.ne' hden hb
    rw [hs,sq_sqrt]
    unfold steadySpeedSq
    positivity

theorem steady_input_coefficient_monotone {H g β r : ℝ}
    (hg : 0 ≤ g) (hβ : 0 < 1-β) (hHr : 0 ≤ H+r) :
    Monotone (fun α => steadyInput H g α β r) := by
  intro a b hab
  unfold steadyInput
  apply (div_le_div_iff_of_pos_right hβ).mpr
  apply mul_le_mul_of_nonneg_left _ hg
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_nonneg (sub_nonneg.mpr hab) hHr]

/-- Both coefficient endpoints are necessary and sufficient for all coefficients. -/
theorem steady_uncertain_endpoints {H g β r aLo aHi uLo uHi : ℝ}
    (hg : 0 ≤ g) (hβ : 0 < 1-β) (hHr : 0 ≤ H+r) (ha : aLo ≤ aHi) :
    (∀ α ∈ Icc aLo aHi, steadyInput H g α β r ∈ Icc uLo uHi) ↔
      (uLo ≤ steadyInput H g aLo β r ∧ steadyInput H g aHi β r ≤ uHi) := by
  have hm := steady_input_coefficient_monotone hg hβ hHr
  constructor
  · intro h
    exact ⟨(h aLo ⟨le_rfl,ha⟩).1,(h aHi ⟨ha,le_rfl⟩).2⟩
  · rintro ⟨hl,hu⟩ a ⟨hal,hau⟩
    exact ⟨hl.trans (hm hal),(hm hau).trans hu⟩

end
end ChainFountain
