module

public import ChainFountain.Certificate

@[expose] public section

namespace ChainFountain
noncomputable section
open Set Real

/-- The zero-disturbance estimate includes both the nominal controller and any
nonnegative additional damping. It is derived from the mechanical equations. -/
theorem ClassicalSolution.nominal_damped_energy_bound
    {H g α β k₀ k₁ k₂ κ κd T : ℝ}
    (sol : ClassicalSolution H g α β k₀ k₁ k₂ κd T)
    (hk₀ : 0 ≤ k₀) (hκ : 0 < κ) (hk₁ : κ ≤ k₁) (hk₂ : κ ≤ k₂)
    (hκd : 0 ≤ κd) (hdzero : ∀ t ∈ Ico 0 T, sol.d t = 0) :
    ∀ t ∈ Icc 0 T, sol.V t ≤ exp (-2*κ*t)*sol.V 0 := by
  have heq := fun t ht => closed_loop_error_equations (sol.h_ne t ht) (sol.Hh_ne t ht)
    (sol.dh t ht) (sol.dv t ht) (sol.dw t ht) (sol.dr t ht) (sol.dr₁ t ht)
  have hd := fun t ht => energy_hasDerivAt_errors (heq t ht).1 (heq t ht).2
  have hc : ContinuousOn sol.V (Icc 0 T) := fun t ht =>
    (hd t ht).continuousAt.continuousWithinAt
  have hb := scalar_comparison (C:=0) hκ hc
    (fun t ht => (hd t (Ico_subset_Icc_self ht)).hasDerivWithinAt) (by
      intro t ht
      rw [hdzero t ht]
      have hn := nominal_decay (e:=heightError sol.h sol.r t)
        (z:=velocityError k₁ sol.h sol.v sol.w sol.r sol.r₁ t) hk₀ hk₁ hk₂
      have hp : 0 ≤ κd * (sol.v t ^ 2 / sol.h t)^2 *
        (velocityError k₁ sol.h sol.v sol.w sol.r sol.r₁ t)^2 / 4 := by positivity
      dsimp [ClassicalSolution.V]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith)
  simpa [envelope] using hb

/-- The geometric argument requires only an already proved energy cap. This
factorization allows the same continuation construction for nominal and robust
controllers without assuming a strictly positive robust damping gain. -/
theorem ClassicalSolution.physical_region_of_cap
    {H g α β k₀ k₁ k₂ κd T cap rlo rhi R₁ wlo whi vmin : ℝ}
    (sol : ClassicalSolution H g α β k₀ k₁ k₂ κd T)
    (hH : 0 < H) (hg : 0 ≤ g) (hk₀ : 0 < k₀)
    (hEC : ∀ t ∈ Icc 0 T, sol.V t ≤ cap)
    (hr : ∀ t ∈ Icc 0 T, rlo ≤ sol.r t ∧ sol.r t ≤ rhi)
    (hr₁ : ∀ t ∈ Icc 0 T, |sol.r₁ t| ≤ R₁)
    (hpositive : 0 < rlo-sqrt (2*cap/k₀))
    (hforward : 2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀)) < wlo)
    (horder : wlo ≤ whi)
    (hcrown : vmin ≤ wlo-(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀)))
    (hl : (1-β)*wlo^2+2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))*wlo+
      (R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))^2 ≤ g*(H+(rlo-sqrt (2*cap/k₀))))
    (hu : g*(H+(rhi+sqrt (2*cap/k₀))) ≤ (1-β)*whi^2-
      2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))*whi+(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))^2)
    (hw₀ : wlo ≤ sol.w 0 ∧ sol.w 0 ≤ whi) :
    ∀ t ∈ Icc 0 T, sol.V t ≤ cap ∧
      0 < sol.h t ∧ wlo ≤ sol.w t ∧ sol.w t ≤ whi ∧
      0 < sol.v t ∧ vmin ≤ (sol.v t+sol.w t)/2 := by
  have hbox := fun t ht => trajectory_enclosure hk₀ (hEC t ht) (hr t ht) (hr₁ t ht)
  have hhc : ContinuousOn sol.h (Icc 0 T) := fun t ht => (sol.dh t ht).continuousAt.continuousWithinAt
  have hwc : ContinuousOn sol.w (Icc 0 T) := fun t ht => (sol.dw t ht).continuousAt.continuousWithinAt
  have hvc : ContinuousOn sol.v (Icc 0 T) := fun t ht => (sol.dv t ht).continuousAt.continuousWithinAt
  have hqc : ContinuousOn (fun t => heightRate (sol.v t) (sol.w t)) (Icc 0 T) :=
    (hvc.sub hwc).div_const 2
  have hK (b : ℝ) : ContinuousOn
      (fun t => -((1-β)*(sol.w t+b)+2*heightRate (sol.v t) (sol.w t))/(H+sol.h t)) (Icc 0 T) :=
    ((continuousOn_const.mul (hwc.add continuousOn_const)).add
      (continuousOn_const.mul hqc)).neg.div (continuousOn_const.add hhc) sol.Hh_ne
  have hphys := physical_region_invariant hH hg hpositive
    (fun t ht => (sol.dw t ht).continuousAt.continuousWithinAt)
    (fun t ht => (mechanical_internal_equation (sol.Hh_ne t (Ico_subset_Icc_self ht))
      (sol.dw t (Ico_subset_Icc_self ht))).hasDerivWithinAt)
    (hK wlo) (hK whi) (fun t ht => ⟨(hbox t ht).1,(hbox t ht).2.1⟩)
    (fun t ht => (hbox t ht).2.2) hforward horder hcrown hl hu hw₀
  intro t ht
  obtain ⟨hh,hwlo,hwhi,hv,hc⟩ := hphys t ht
  have hvId : sol.w t+2*heightRate (sol.v t) (sol.w t) = sol.v t := by unfold heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hsId : sol.w t+heightRate (sol.v t) (sol.w t) = (sol.v t+sol.w t)/2 := by unfold heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [hvId] at hv; rw [hsId] at hc
  exact ⟨hEC t ht,hh,hwlo,hwhi,hv,hc⟩

end
end ChainFountain
