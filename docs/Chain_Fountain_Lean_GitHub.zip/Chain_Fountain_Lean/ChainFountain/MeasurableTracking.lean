module

public import ChainFountain.MeasurablePlant
public import ChainFountain.AEComparison

@[expose] public section

namespace ChainFountain
noncomputable section
open Set Metric Real Filter MeasureTheory
open scoped Topology NNReal
set_option maxHeartbeats 800000

theorem GlobalTrackingData.reference_lipschitz (c : GlobalTrackingData) (T : ℝ) :
    ∃ L₁ L₂ : ℝ≥0, LipschitzOnWith L₁ c.r (Icc 0 T) ∧
      LipschitzOnWith L₂ c.r₁ (Icc 0 T) := by
  have hR₁ : 0≤ c.R₁ := (abs_nonneg _).trans (c.rate_bound 0 le_rfl)
  have hR₂ : 0≤ c.R₂ := (abs_nonneg _).trans (c.accel_bound 0 le_rfl)
  refine ⟨⟨c.R₁,hR₁⟩,⟨c.R₂,hR₂⟩,?_,?_⟩
  · apply (convex_Icc (0:ℝ) T).lipschitzOnWith_of_nnnorm_deriv_le
      (fun t ht => (c.dr t ht.1).differentiableAt)
    intro t ht
    rw [(c.dr t ht.1).deriv]
    exact_mod_cast c.rate_bound t ht.1
  · apply (convex_Icc (0:ℝ) T).lipschitzOnWith_of_nnnorm_deriv_le
      (fun t ht => (c.dr₁ t ht.1).differentiableAt)
    intro t ht
    rw [(c.dr₁ t ht.1).deriv]
    exact_mod_cast c.accel_bound t ht.1

theorem GlobalTrackingData.errors_lipschitz (c : GlobalTrackingData)
    {x : ℝ → MechanicalState} {K : ℝ≥0} (hx : LipschitzWith K x) (T : ℝ) :
    ∃ Le Lz : ℝ≥0,
      LipschitzOnWith Le (heightError (fun t => (x t).1) c.r) (Icc 0 T) ∧
      LipschitzOnWith Lz (velocityError c.k₁ (fun t => (x t).1)
        (fun t => (x t).2.1) (fun t => (x t).2.2) c.r c.r₁) (Icc 0 T) := by
  obtain ⟨L₁,L₂,hr,hr₁⟩ := c.reference_lipschitz T
  have hp := hx.lipschitzOnWith.prodMk (hr.prodMk hr₁)
  have hse : ContDiff ℝ 1 (fun p : MechanicalState × (ℝ×ℝ) => p.1.1-p.2.1) := by fun_prop
  have hsz : ContDiff ℝ 1 (fun p : MechanicalState × (ℝ×ℝ) =>
      p.1.2.1-p.1.2.2-2*p.2.2+2*c.k₁*(p.1.1-p.2.1)) := by fun_prop
  obtain ⟨Le,he⟩ := smooth_comp_lipschitzOn hse hp
  obtain ⟨Lz,hz⟩ := smooth_comp_lipschitzOn hsz hp
  exact ⟨Le,Lz,he,hz⟩

theorem GlobalTrackingData.measurable_prefix_energy (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdb : ∀ t, |d t|≤ c.dbar)
    {x : ℝ → MechanicalState} {K : ℝ≥0} {T : ℝ} (hxL : LipschitzWith K x)
    (hx₀ : x 0=c.x₀) (hbox : ∀ t∈Icc 0 T, x t∈c.outerBox)
    (hxD : ∀ᵐ t ∂volume, HasDerivAt x (c.measurableField d t (c.project (x t))) t) :
    ∀ t∈Icc 0 T, c.stateEnergy t (x t)≤
      exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+c.dbar^2/(16*c.κ*c.κd)*(1-exp (-2*c.κ*t)) ∧
      c.stateEnergy t (x t)≤ c.cap := by
  let h := fun t => (x t).1
  let v := fun t => (x t).2.1
  let w := fun t => (x t).2.2
  obtain ⟨Le,Lz,hel,hzl⟩ := c.errors_lipschitz hxL T
  have heq : ∀ᵐ t ∂volume, t∈Ioo 0 T →
      HasDerivAt (heightError h c.r) (errorRate c.k₁ (heightError h c.r t)
        (velocityError c.k₁ h v w c.r c.r₁ t)) t ∧
      HasDerivAt (velocityError c.k₁ h v w c.r c.r₁)
        (zRate c.k₀ c.k₂ c.κd ((v t)^2/h t) (d t) (heightError h c.r t)
          (velocityError c.k₁ h v w c.r c.r₁ t)) t := by
    filter_upwards [hxD] with t hdt ht
    have hB := hbox t (Ioo_subset_Icc_self ht)
    rw [c.project_eq (x t) hB] at hdt
    have hp : 0<(x t).1 := by have hl := hB.1.1; have := c.height_positive; change 0<c.hlo at this; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
    have hHp : 0<c.H+(x t).1 := add_pos c.H_pos hp
    have dh : HasDerivAt h (heightRate (v t) (w t)) t := by
      simpa [h,v,w,measurableField,jointField] using! hasFDerivAt_fst.comp_hasDerivAt t hdt
    have dv : HasDerivAt v (rise c.g (c.α+d t) (h t) (v t) (w t)
        (requestedInput c.H c.g c.α c.β c.k₀ c.k₁ c.k₂ c.κd h v w c.r c.r₁ c.r₂ t)) t := by
      simpa [h,v,w,measurableField,measurableParameters,jointField,parameters,max_eq_right ht.1.le,
        requestedInput,heightError,velocityError] using!
        hasFDerivAt_fst.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t hdt)
    have dw : HasDerivAt w (fall c.H c.g c.β (h t) (v t) (w t)) t := by
      simpa [h,v,w,measurableField,jointField] using!
        hasFDerivAt_snd.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t hdt)
    exact closed_loop_error_equations hp.ne' hHp.ne' dh dv dw (c.dr t ht.1.le) (c.dr₁ t ht.1.le)
  have he := robust_error_estimate_ae c.k₀_pos.le c.κ_pos c.κ_le_k₁ c.κ_le_k₂ hκd
    hel hzl (heq.mono (fun t ht hmem => (ht hmem).1))
    (heq.mono (fun t ht hmem => (ht hmem).2)) (Filter.Eventually.of_forall (fun t _ => hdb t))
  intro t ht
  have he' : c.stateEnergy t (x t)≤
      exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+c.dbar^2/(16*c.κ*c.κd)*(1-exp (-2*c.κ*t)) := by
    simpa [stateEnergy,heightError,velocityError,h,v,w,hx₀] using! he t ht
  refine ⟨he',he'.trans ?_⟩
  have hcap : (c.dbar^2/(8*c.κd))/(2*c.κ)≤ c.cap := by
    convert! c.disturbance_cap using 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  convert! envelope_below_cap c.κ_pos ht.1 c.initial_energy hcap using 1
  unfold envelope stateEnergy
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- The falling speed is classical even under measurable pickup disturbances,
because its a.e. right hand side is a continuous function of the state. -/
theorem GlobalTrackingData.measurable_fall_classical (c : GlobalTrackingData)
    {d : ℝ → ℝ} {x : ℝ → MechanicalState} {K : ℝ≥0} (hxL : LipschitzWith K x)
    (hxD : ∀ᵐ t ∂volume, HasDerivAt x (c.measurableField d t (c.project (x t))) t) :
    ∀ t, HasDerivAt (fun s => (x s).2.2)
      (fall c.H c.g c.β (c.project (x t)).1 (c.project (x t)).2.1 (c.project (x t)).2.2) t := by
  have hwL : LipschitzWith K (fun t => (x t).2.2) := by
    simpa using! LipschitzWith.prod_snd.comp (LipschitzWith.prod_snd.comp hxL)
  have hpc : Continuous (fun t => c.project (x t)) := c.project_lipschitz.continuous.comp hxL.continuous
  have hden (t : ℝ) : c.H+(c.project (x t)).1≠0 := by
    have hl := (c.project_mem (x t)).1.1
    have hp : 0<c.hlo := c.height_positive
    exact ne_of_gt (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [c.H_pos])
  have hcont : Continuous (fun t =>
      fall c.H c.g c.β (c.project (x t)).1 (c.project (x t)).2.1 (c.project (x t)).2.2) := by
    unfold fall crownSq
    exact continuous_const.add
      (((((hpc.snd.fst.add hpc.snd.snd).div_const 2).pow 2).neg.add
        (continuous_const.mul (hpc.snd.snd.pow 2))).div
          (continuous_const.add hpc.fst) hden)
  apply lipschitz_ae_continuous_derivative hwL hcont
  filter_upwards [hxD] with t ht
  simpa [measurableField,jointField] using!
    hasFDerivAt_snd.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t ht)

theorem GlobalTrackingData.measurable_prefix_bound (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdb : ∀ t, |d t|≤ c.dbar)
    {x : ℝ → MechanicalState} {K : ℝ≥0} {T : ℝ} (hxL : LipschitzWith K x)
    (hT : 0≤ T) (hx₀ : x 0=c.x₀) (hbox : ∀ t∈Icc 0 T, x t∈c.outerBox)
    (hxD : ∀ᵐ t ∂volume, HasDerivAt x (c.measurableField d t (c.project (x t))) t) :
    x T∈c.safeBox := by
  have henergy := c.measurable_prefix_energy hκd hdb hxL hx₀ hbox hxD
  have he (t : ℝ) (ht : t∈Icc 0 T) := trajectory_enclosure
    (h:=fun s => (x s).1) (v:=fun s => (x s).2.1) (w:=fun s => (x s).2.2)
    (r:=c.r) (r₁:=c.r₁) (k₁:=c.k₁) (cap:=c.cap)
    (rlo:=c.rlo) (rhi:=c.rhi) (R₁:=c.R₁)
    c.k₀_pos (henergy t ht).2 (c.ref_bounds t ht.1) (c.rate_bound t ht.1)
  have hhc : ContinuousOn (fun t => (x t).1) (Icc 0 T) := hxL.continuous.fst.continuousOn
  have hwc : ContinuousOn (fun t => (x t).2.2) (Icc 0 T) := hxL.continuous.snd.snd.continuousOn
  have hvc : ContinuousOn (fun t => (x t).2.1) (Icc 0 T) := hxL.continuous.snd.fst.continuousOn
  have hqc : ContinuousOn (fun t => heightRate (x t).2.1 (x t).2.2) (Icc 0 T) :=
    (hvc.sub hwc).div_const 2
  have hden (t : ℝ) (ht : t∈Icc 0 T) : c.H+(x t).1≠0 := by
    have hl := (hbox t ht).1.1
    have hp : 0<c.hlo := c.height_positive
    exact ne_of_gt (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [c.H_pos])
  have hK (b : ℝ) : ContinuousOn
      (fun t => -((1-c.β)*((x t).2.2+b)+2*heightRate (x t).2.1 (x t).2.2)/(c.H+(x t).1))
      (Icc 0 T) :=
    ((continuousOn_const.mul (hwc.add continuousOn_const)).add
      (continuousOn_const.mul hqc)).neg.div (continuousOn_const.add hhc) hden
  have hwd := c.measurable_fall_classical hxL hxD
  have hwdActual (t : ℝ) (ht : t∈Icc 0 T) :
      HasDerivAt (fun s => (x s).2.2)
        (fall c.H c.g c.β (x t).1 (x t).2.1 (x t).2.2) t := by
    simpa only [c.project_eq (x t) (hbox t ht)] using! hwd t
  have hi (t : ℝ) (ht : t∈Ico 0 T) :
      HasDerivWithinAt (fun s => (x s).2.2)
        (internal c.H c.g c.β (x t).1 (x t).2.2
          (heightRate (x t).2.1 (x t).2.2)) (Ici t) t := by
    exact (mechanical_internal_equation
      (h:=fun s => (x s).1) (v:=fun s => (x s).2.1) (w:=fun s => (x s).2.2)
      (H:=c.H) (g:=c.g) (β:=c.β) (t:=t)
      (hden t (Ico_subset_Icc_self ht)) (hwdActual t (Ico_subset_Icc_self ht))).hasDerivWithinAt
  have hwinv := physical_region_invariant
    (h:=fun t => (x t).1) (w:=fun t => (x t).2.2)
    (q:=fun t => heightRate (x t).2.1 (x t).2.2)
    (H:=c.H) (g:=c.g) (β:=c.β) (T:=T) (hlo:=c.hlo) (hhi:=c.hhi)
    (Q:=c.Q) (wlo:=c.wlo) (whi:=c.whi) (vmin:=c.vmin)
    c.H_pos c.g_nonneg c.height_positive hwc
    hi
    (hK c.wlo) (hK c.whi) (fun t ht => ⟨(he t ht).1,(he t ht).2.1⟩)
    (fun t ht => (he t ht).2.2) c.forward c.speed_order c.crown
    c.lower_face_bound c.upper_face_bound (by simpa [hx₀] using! c.initial_speed) T ⟨hT,le_rfl⟩
  exact c.box_of_energy_speed T hT (x T) (henergy T ⟨hT,le_rfl⟩).2 ⟨hwinv.2.1,hwinv.2.2.1⟩

/-- Global physical existence and tracking for bounded measurable disturbances.
The trajectory is constructed from data, the projection is proved inactive for
all nonnegative times, and the original equations hold almost everywhere. -/
theorem GlobalTrackingData.exists_global_measurable_tracking (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : Measurable d) (hdb : ∀ t, |d t|≤ c.dbar) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      ∀ t≥0, c.stateEnergy t (x t)≤ c.cap ∧
        c.stateEnergy t (x t)≤ exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-exp (-2*c.κ*t)) := by
  obtain ⟨x,K,ε,hε,hxL,hx₀,hxI,hxD,hlocal,hlocalD⟩ := c.exists_measurable_local hdm hdb
  have hstay := no_exit_of_prefix_bound hxL.continuous
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    (hx₀ ▸ c.safeBox_interior c.initial_mem) (fun T hT hbox =>
      c.measurable_prefix_bound hκd hdb hxL hT hx₀ hbox hxD)
  refine ⟨x,K,hxL,hx₀,?_,hstay,?_⟩
  · filter_upwards [hxD] with t ht ht0
    simpa [c.project_eq (x t) (interior_subset (c.safeBox_interior (hstay t ht0)))] using! ht
  · intro t ht
    have he := c.measurable_prefix_energy hκd hdb hxL hx₀
      (fun s (hs : s∈Icc 0 t) => interior_subset (c.safeBox_interior (hstay s hs.1))) hxD t ⟨ht,le_rfl⟩
    exact ⟨he.2,he.1⟩

end
end ChainFountain
