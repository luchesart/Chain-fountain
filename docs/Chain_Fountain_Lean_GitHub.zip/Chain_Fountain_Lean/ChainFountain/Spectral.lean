module

public import ChainFountain.Model

@[expose] public section

namespace ChainFountain
noncomputable section

def coeff₂ (ρ ω : ℝ) := (1 - ρ) * ω
def coeff₁ (α ρ ω : ℝ) := ((5 / 2) * α * (1 + ρ) - 4 * α ^ 2) * ω ^ 2
def coeff₀ (α ρ ω : ℝ) := α ^ 2 * (1 - ρ) * ω ^ 3
def cubic (α ρ ω p : ℝ) := p ^ 3 + coeff₂ ρ ω * p ^ 2 + coeff₁ α ρ ω * p + coeff₀ α ρ ω

theorem routh_factorization (α ρ ω : ℝ) :
    coeff₂ ρ ω * coeff₁ α ρ ω - coeff₀ α ρ ω =
      (5 / 2) * α * (1 - ρ) * (1 + ρ - 2 * α) * ω ^ 3 := by
  unfold coeff₂ coeff₁ coeff₀; ring

theorem hurwitz_conditions {α ρ ω : ℝ}
    (ha : 0 < α) (ha1 : α < 1 / 2) (hr : 0 < ρ) (hr1 : ρ < 1) (hw : 0 < ω) :
    0 < coeff₂ ρ ω ∧ 0 < coeff₁ α ρ ω ∧ 0 < coeff₀ α ρ ω ∧
      coeff₀ α ρ ω < coeff₂ ρ ω * coeff₁ α ρ ω := by
  have hr0 : 0 < 1 - ρ := by linarith
  have hb : 0 < (5 / 2) * (1 + ρ) - 4 * α := by linarith
  have hc : 0 < (5 / 2) * α * (1 + ρ) - 4 * α ^ 2 := by
    nlinarith [mul_pos ha hb]
  have hp : 0 < 1 + ρ - 2 * α := by linarith
  have hf : 0 < (5 / 2 : ℝ) * α * (1 - ρ) * (1 + ρ - 2 * α) * ω ^ 3 := by positivity
  refine ⟨by unfold coeff₂; positivity, by unfold coeff₁; positivity,
    by unfold coeff₀; positivity, ?_⟩
  rw [← routh_factorization] at hf; linarith

theorem rho_parameter_range {α β : ℝ}
    (ha : 0 < α) (hb : 0 ≤ β) (hab : α + β < 1 / 2) :
    0 < α / (1 - β) ∧ α / (1 - β) < 1 := by
  have hd : 0 < 1 - β := by linarith
  constructor
  · exact div_pos ha hd
  · rw [div_lt_one hd]; linarith

/-- A direct proof of the cubic Hurwitz criterion, rather than an assumed bridge. -/
theorem cubic_roots_left {a₂ a₁ a₀ : ℝ}
    (h₂ : 0 < a₂) (h₁ : 0 < a₁) (h₀ : 0 < a₀) (hH : a₀ < a₂ * a₁)
    (z : ℂ) (hz : z ^ 3 + (a₂ : ℂ) * z ^ 2 + (a₁ : ℂ) * z + (a₀ : ℂ) = 0) :
    z.re < 0 := by
  by_contra h
  have hx : 0 ≤ z.re := le_of_not_gt h
  have hre := congrArg Complex.re hz
  have him := congrArg Complex.im hz
  simp only [Complex.add_re, Complex.add_im, Complex.mul_re, Complex.mul_im,
    Complex.ofReal_re, Complex.ofReal_im, Complex.zero_re, Complex.zero_im,
    pow_succ, pow_zero, Complex.one_re, Complex.one_im] at hre him
  by_cases hy : z.im = 0
  · simp only [hy, mul_zero, zero_mul, add_zero, sub_zero, mul_one, zero_add] at hre
    have h3 : 0 ≤ z.re * z.re * z.re := by positivity
    have h2 : 0 ≤ a₂ * (z.re * z.re) := by positivity
    have h1 : 0 ≤ a₁ * z.re := by positivity
    nlinarith
  · have hi : z.im * (3 * z.re ^ 2 - z.im ^ 2 + 2 * a₂ * z.re + a₁) = 0 := by
      nlinarith [him]
    have hy2 : z.im ^ 2 - (3 * z.re ^ 2 + 2 * a₂ * z.re + a₁) = 0 := by
      have := (mul_eq_zero.mp hi).resolve_left hy; linarith
    have he : 8 * z.re ^ 3 + 8 * a₂ * z.re ^ 2 +
        2 * (a₁ + a₂ ^ 2) * z.re + (a₂ * a₁ - a₀) = 0 := by
      linear_combination -hre - (3 * z.re + a₂) * hy2
    have h3 : 0 ≤ z.re ^ 3 := by positivity
    have h2 : 0 ≤ a₂ * z.re ^ 2 := by positivity
    have h1 : 0 ≤ (a₁ + a₂ ^ 2) * z.re := by positivity
    linarith

theorem plant_cubic_roots_left {α ρ ω : ℝ}
    (ha : 0 < α) (ha1 : α < 1 / 2) (hr : 0 < ρ) (hr1 : ρ < 1) (hw : 0 < ω)
    (z : ℂ) (hz : z ^ 3 + (coeff₂ ρ ω : ℂ) * z ^ 2 +
      (coeff₁ α ρ ω : ℂ) * z + (coeff₀ α ρ ω : ℂ) = 0) : z.re < 0 := by
  obtain ⟨h₂,h₁,h₀,hH⟩ := hurwitz_conditions ha ha1 hr hr1 hw
  exact cubic_roots_left h₂ h₁ h₀ hH z hz

theorem no_pole_zero_cancellation (α ρ ω : ℝ) :
    cubic α ρ ω (-2 * α * ω) = -10 * α ^ 2 * ρ * ω ^ 3 := by
  unfold cubic coeff₂ coeff₁ coeff₀; ring

theorem transfer_zero_negative {α ω : ℝ} (ha : 0 < α) (hw : 0 < ω) :
    -2 * α * ω < 0 := by nlinarith [mul_pos ha hw]

theorem transfer_zero_not_root {α ρ ω : ℝ}
    (ha : 0 < α) (hr : 0 < ρ) (hw : 0 < ω) :
    cubic α ρ ω (-2 * α * ω) ≠ 0 := by
  rw [no_pole_zero_cancellation]
  have hp : 0 < 10 * α ^ 2 * ρ * ω ^ 3 := by positivity
  exact ne_of_lt (by nlinarith)

/-- Determinant of pI-J for the displayed Jacobian; J's differential identification
and nonlinear local exponential stability are separate analytic obligations. -/
theorem characteristic_determinant (α β ρ ω p : ℝ) (hrel : α = (1 - β) * ρ) :
    Matrix.det (!![p, -(1/2 : ℝ), (1/2 : ℝ);
      α * ω ^ 2, p + (1 - 2 * α) * ω, -ω;
      -α * ρ * ω ^ 2, ρ * ω, p + (1 - 2 * β) * ρ * ω]) = cubic α ρ ω p := by
  simp only [Matrix.det_fin_three]
  simp
  unfold cubic coeff₂ coeff₁ coeff₀
  rw [hrel]
  ring

/-- Resolvent input-output identity for the displayed Jacobian. The equations
are (pI-J)x=(0,-1/h,0); no inverse-matrix or transfer-function conclusion is
assumed. The identity is valid for complex p and state amplitudes. -/
theorem resolvent_output (α β ρ ω h : ℝ) (p x₀ x₁ x₂ : ℂ)
    (hrel : α = (1-β)*ρ)
    (he₀ : p*x₀-(1/2 : ℂ)*x₁+(1/2 : ℂ)*x₂=0)
    (he₁ : (α : ℂ)*ω^2*x₀+(p+(1-2*(α : ℂ))*ω)*x₁-(ω : ℂ)*x₂=-(1/(h : ℂ)))
    (he₂ : -(α : ℂ)*ρ*ω^2*x₀+(ρ : ℂ)*ω*x₁+(p+(1-2*(β : ℂ))*ρ*ω)*x₂=0) :
    (p^3+(coeff₂ ρ ω : ℂ)*p^2+(coeff₁ α ρ ω : ℂ)*p+(coeff₀ α ρ ω : ℂ))*x₀ =
      -(p+2*(α : ℂ)*ω)/(2*(h : ℂ)) := by
  have hr : (α : ℂ) = (1-(β : ℂ))*(ρ : ℂ) := by exact_mod_cast hrel
  unfold coeff₂ coeff₁ coeff₀
  push_cast
  rw [hr] at he₁ he₂ ⊢
  linear_combination
    ((p+(1-2*((1-(β : ℂ))*ρ))*ω)*(p+(1-2*(β : ℂ))*ρ*ω)+(ρ : ℂ)*ω^2)*he₀ +
    ((p+2*(1-(β : ℂ))*ρ*ω)/2)*he₁ +
    ((2*((1-(β : ℂ))*ρ)*ω-p)/2)*he₂

end
end ChainFountain
