module

public import ChainFountain.ModelCore
public import Mathlib.Analysis.Calculus.Deriv.Inv

@[expose] public section

/-!
# The zero-gravity open-chain obstruction

These results concern the existing two-leg, fixed-height-offset model with g = 0.
They are statements about that model, not a model of an arbitrary free chain.
The physical interval hypotheses are explicit: the momentum obstruction does
not assert a particular exit time or an extension through zero leg length.
-/
namespace ChainFountain
namespace ZeroGravity
noncomputable section
open Set Real

/-- Falling-leg momentum divided by the constant linear density. -/
def fallingMomentum (H h w : ℝ) : ℝ := (H + h) * w

/-- The old positive-speed lower-face condition cannot hold at zero gravity. -/
theorem lower_face_impossible {β w Q : ℝ}
    (hβ : β < 1) (hw : 0 < w) (hQ : 0 ≤ Q) :
    ¬ (0 ≥ (1 - β) * w ^ 2 + 2 * Q * w + Q ^ 2) := by
  have h1 : 0 < (1 - β) * w ^ 2 := mul_pos (by linarith) (sq_pos_of_pos hw)
  have h2 : 0 ≤ 2 * Q * w := by positivity
  nlinarith [sq_nonneg Q]

/-- Exact cancellation of the controlled rising-leg acceleration from P'. -/
theorem falling_momentum_rate (H β h v w : ℝ) (hden : H + h ≠ 0) :
    heightRate v w * w + (H + h) * fall H 0 β h v w =
      -(v ^ 2) / 4 - (3 / 4 - β) * w ^ 2 := by
  unfold heightRate fall crownSq
  field_simp
  <;> ring

/-- Genuine derivative of falling-leg momentum along a classical trajectory. -/
theorem falling_momentum_hasDerivAt {H β t : ℝ} {h v w : ℝ → ℝ}
    (hden : H + h t ≠ 0)
    (dh : HasDerivAt h (heightRate (v t) (w t)) t)
    (dw : HasDerivAt w (fall H 0 β (h t) (v t) (w t)) t) :
    HasDerivAt (fun τ => fallingMomentum H (h τ) (w τ))
      (-(v t ^ 2) / 4 - (3 / 4 - β) * w t ^ 2) t := by
  have hd := (dh.const_add H).mul dw
  convert! hd using 1
  exact (falling_momentum_rate H β (h t) (v t) (w t) hden).symm

/-- Dissipation dominates one half of the squared crown speed. -/
theorem falling_momentum_rate_le {β v w : ℝ} (hβ : β ≤ 1 / 2) :
    -(v ^ 2) / 4 - (3 / 4 - β) * w ^ 2 ≤ -crownSq v w / 2 := by
  have hb := mul_nonneg (sub_nonneg.mpr hβ) (sq_nonneg w)
  unfold crownSq
  nlinarith [sq_nonneg (v - w)]

/-- A classical derivative inequality gives the affine momentum bound. -/
theorem momentum_affine_bound {P P' : ℝ → ℝ} {T a : ℝ}
    (hc : ContinuousOn P (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt P (P' t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, P' t ≤ -a) :
    ∀ t ∈ Icc 0 T, P t ≤ P 0 - a * t := by
  have hg := le_gronwallBound_of_liminf_deriv_right_le hc
    (fun t ht _ hr => (hd t ht).liminf_right_slope_le hr)
    (le_refl (P 0)) (K := 0) (ε := -a)
    (by intro t ht; simpa using hb t ht)
  intro t ht
  have h := hg t ht
  simp [gronwallBound] at h
  linarith

/-- Positive momentum and a positive crown-speed margin bound the interval.
The conclusion is a strict upper bound, not a claimed exact exit time. -/
theorem positive_margin_time_bound {H β T smin : ℝ} {h v w : ℝ → ℝ}
    (hT : 0 ≤ T) (hβ : β ≤ 1 / 2) (hs : 0 < smin)
    (dh : ∀ t ∈ Icc 0 T, HasDerivAt h (heightRate (v t) (w t)) t)
    (dw : ∀ t ∈ Icc 0 T, HasDerivAt w (fall H 0 β (h t) (v t) (w t)) t)
    (hden : ∀ t ∈ Icc 0 T, 0 < H + h t)
    (hw : ∀ t ∈ Icc 0 T, 0 < w t)
    (hmargin : ∀ t ∈ Icc 0 T, smin ≤ (v t + w t) / 2) :
    T < 2 * fallingMomentum H (h 0) (w 0) / smin ^ 2 := by
  let P := fun t => fallingMomentum H (h t) (w t)
  let D := fun t => -(v t ^ 2) / 4 - (3 / 4 - β) * w t ^ 2
  have hd : ∀ t ∈ Icc 0 T, HasDerivAt P (D t) t := by
    intro t ht
    exact falling_momentum_hasDerivAt (ne_of_gt (hden t ht)) (dh t ht) (dw t ht)
  have hc : ContinuousOn P (Icc 0 T) := fun t ht => (hd t ht).continuousAt.continuousWithinAt
  have hb : ∀ t ∈ Ico 0 T, D t ≤ -(smin ^ 2 / 2) := by
    intro t ht
    have hr := falling_momentum_rate_le (v := v t) (w := w t) hβ
    have hm := hmargin t (Ico_subset_Icc_self ht)
    have hsq : smin ^ 2 ≤ crownSq (v t) (w t) := by
      unfold crownSq
      nlinarith
    dsimp [D]
    linarith
  have ht := momentum_affine_bound hc
    (fun t ht => (hd t (Ico_subset_Icc_self ht)).hasDerivWithinAt) hb T ⟨hT, le_rfl⟩
  have hp : 0 < P T := mul_pos (hden T ⟨hT, le_rfl⟩) (hw T ⟨hT, le_rfl⟩)
  have hsq : 0 < smin ^ 2 := sq_pos_of_pos hs
  apply (lt_div_iff₀ hsq).mpr
  dsimp [P] at ht hp ⊢
  nlinarith

/-- No global classical trajectory can retain the positive crown margin and
positive falling-leg momentum in the same open geometry. -/
theorem global_positive_margin_impossible {H β smin : ℝ} {h v w : ℝ → ℝ}
    (hβ : β ≤ 1 / 2) (hs : 0 < smin)
    (dh : ∀ t, 0 ≤ t → HasDerivAt h (heightRate (v t) (w t)) t)
    (dw : ∀ t, 0 ≤ t → HasDerivAt w (fall H 0 β (h t) (v t) (w t)) t)
    (hden : ∀ t, 0 ≤ t → 0 < H + h t)
    (hw : ∀ t, 0 ≤ t → 0 < w t)
    (hmargin : ∀ t, 0 ≤ t → smin ≤ (v t + w t) / 2) : False := by
  let T := 2 * fallingMomentum H (h 0) (w 0) / smin ^ 2
  have hP : 0 < fallingMomentum H (h 0) (w 0) :=
    mul_pos (hden 0 le_rfl) (hw 0 le_rfl)
  have hT : 0 ≤ T := by dsimp [T]; positivity
  have hb := positive_margin_time_bound hT hβ hs
    (fun t ht => dh t ht.1) (fun t ht => dw t ht.1)
    (fun t ht => hden t ht.1) (fun t ht => hw t ht.1)
    (fun t ht => hmargin t ht.1)
  exact (lt_irrefl T) hb

/-- The open two-leg model has no equilibrium with positive transport speed. -/
theorem no_positive_flow_equilibrium {H β h v w : ℝ}
    (hden : H + h ≠ 0) (hβ : β < 1) (hw : 0 < w)
    (hh : heightRate v w = 0) : fall H 0 β h v w ≠ 0 := by
  have hv : v = w := by unfold heightRate at hh; linarith
  subst v
  have hc : crownSq w w = w ^ 2 := by unfold crownSq; ring
  unfold fall
  rw [hc, zero_add]
  apply div_ne_zero _ hden
  have hp := mul_pos (show 0 < 1 - β by linarith) (sq_pos_of_pos hw)
  nlinarith

/-- Constant-height decay coefficient. -/
def decayRate (H β r : ℝ) : ℝ := (1 - β) / (H + r)

def decaySpeed (c w₀ t : ℝ) : ℝ := w₀ / (1 + c * w₀ * t)

theorem decayRate_pos {H β r : ℝ} (hden : 0 < H + r) (hβ : β < 1) :
    0 < decayRate H β r := div_pos (by linarith) hden

theorem decaySpeed_pos {c w₀ t : ℝ} (hc : 0 < c) (hw : 0 < w₀) (ht : 0 ≤ t) :
    0 < decaySpeed c w₀ t := by
  unfold decaySpeed
  positivity

theorem decaySpeed_initial (c w₀ : ℝ) : decaySpeed c w₀ 0 = w₀ := by
  simp [decaySpeed]

/-- The rational decay formula solves the quadratic scalar decay equation. -/
theorem decaySpeed_hasDerivAt {c w₀ t : ℝ} (hden : 1 + c * w₀ * t ≠ 0) :
    HasDerivAt (decaySpeed c w₀) (-c * decaySpeed c w₀ t ^ 2) t := by
  have hd := (hasDerivAt_const t w₀).div
    (((hasDerivAt_id t).const_mul (c * w₀)).const_add 1) hden
  convert! hd using 1 <;> dsimp [decaySpeed]
  field_simp
  <;> ring

/-- A compatible input makes both leg accelerations equal to quadratic decay. -/
theorem constant_height_vector_field (H α β r w : ℝ)
    (hr : r ≠ 0) (hden : H + r ≠ 0) :
    heightRate w w = 0 ∧
    rise 0 α r w w ((α + r * decayRate H β r) * w ^ 2) =
      -decayRate H β r * w ^ 2 ∧
    fall H 0 β r w w = -decayRate H β r * w ^ 2 := by
  refine ⟨by simp [heightRate], ?_, ?_⟩
  · unfold rise crownSq decayRate
    field_simp
    <;> ring
  · unfold fall crownSq decayRate
    field_simp
    <;> ring

/-- The explicit rational speed and compatible input solve all three original
zero-gravity plant equations at every nonsingular time. -/
theorem constant_height_solution {H α β r w₀ t : ℝ}
    (hr : r ≠ 0) (hden : H + r ≠ 0)
    (hdec : 1 + decayRate H β r * w₀ * t ≠ 0) :
    let c := decayRate H β r
    let speed := decaySpeed c w₀
    let input := (α + r * c) * speed t ^ 2
    HasDerivAt (fun _ : ℝ => r) (heightRate (speed t) (speed t)) t ∧
    HasDerivAt speed (rise 0 α r (speed t) (speed t) input) t ∧
    HasDerivAt speed (fall H 0 β r (speed t) (speed t)) t := by
  dsimp only
  have hv := constant_height_vector_field H α β r (decaySpeed (decayRate H β r) w₀ t) hr hden
  refine ⟨?_, ?_, ?_⟩
  · rw [hv.1]
    exact hasDerivAt_const t r
  · rw [hv.2.1]
    exact decaySpeed_hasDerivAt hdec
  · rw [hv.2.2]
    exact decaySpeed_hasDerivAt hdec

/-- Zero gravity removes the positive gravitational power supply exactly. -/
theorem energy_balance_zeroGravity (H lam α β h v w u : ℝ)
    (hh : h ≠ 0) (hH : H + h ≠ 0) :
    lam / 2 * (heightRate v w * v ^ 2 + h * (2 * v * rise 0 α h v w u) +
      heightRate v w * w ^ 2 + (H + h) * (2 * w * fall H 0 β h v w)) =
      -lam * (1 / 2 - α) * v ^ 3 - lam * (1 / 2 - β) * w ^ 3 - lam * u * v := by
  simpa using energy_balance H 0 lam α β h v w u hh hH

end
end ZeroGravity
end ChainFountain
