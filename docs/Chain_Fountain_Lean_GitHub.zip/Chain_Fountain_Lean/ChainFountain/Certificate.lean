module

public import ChainFountain.Trajectories

@[expose] public section

namespace ChainFountain
noncomputable section
open Set Real

/-- Data of an existing classical solution. Fields are modelling/regularity
assumptions only; no tracking, safety, or convergence conclusion is a field. -/
structure ClassicalSolution (H g α β k₀ k₁ k₂ κd T : ℝ) where
  h : ℝ → ℝ
  v : ℝ → ℝ
  w : ℝ → ℝ
  r : ℝ → ℝ
  r₁ : ℝ → ℝ
  r₂ : ℝ → ℝ
  d : ℝ → ℝ
  h_ne : ∀ t ∈ Icc 0 T, h t ≠ 0
  Hh_ne : ∀ t ∈ Icc 0 T, H+h t ≠ 0
  dh : ∀ t ∈ Icc 0 T, HasDerivAt h (heightRate (v t) (w t)) t
  dv : ∀ t ∈ Icc 0 T, HasDerivAt v (rise g (α+d t) (h t) (v t) (w t)
    (requestedInput H g α β k₀ k₁ k₂ κd h v w r r₁ r₂ t)) t
  dw : ∀ t ∈ Icc 0 T, HasDerivAt w (fall H g β (h t) (v t) (w t)) t
  dr : ∀ t ∈ Icc 0 T, HasDerivAt r (r₁ t) t
  dr₁ : ∀ t ∈ Icc 0 T, HasDerivAt r₁ (r₂ t) t

def ClassicalSolution.V {H g α β k₀ k₁ k₂ κd T : ℝ}
    (sol : ClassicalSolution H g α β k₀ k₁ k₂ κd T) (t : ℝ) :=
  errorEnergy k₀ (heightError sol.h sol.r t) (velocityError k₁ sol.h sol.v sol.w sol.r sol.r₁ t)

theorem ClassicalSolution.energy_bound {H g α β k₀ k₁ k₂ κ κd dbar T : ℝ}
    (sol : ClassicalSolution H g α β k₀ k₁ k₂ κd T)
    (hk₀ : 0 ≤ k₀) (hκ : 0 < κ) (hk₁ : κ ≤ k₁) (hk₂ : κ ≤ k₂) (hκd : 0 < κd)
    (hdb : ∀ t ∈ Ico 0 T, |sol.d t| ≤ dbar) :
    ∀ t ∈ Icc 0 T, sol.V t ≤ exp (-2*κ*t)*sol.V 0+
      dbar^2/(16*κ*κd)*(1-exp (-2*κ*t)) :=
  mechanical_tracking_estimate hk₀ hκ hk₁ hk₂ hκd sol.h_ne sol.Hh_ne
    sol.dh sol.dv sol.dw sol.dr sol.dr₁ hdb

/-- Composed, finite-interval robust physical-region theorem. The energy cap is
derived from the controlled ODE rather than assumed along the trajectory.
Global existence, measurable-input extensions, and nonideal actuators are not
conclusions of this statement. -/
theorem ClassicalSolution.physical_region
    {H g α β k₀ k₁ k₂ κ κd dbar T cap rlo rhi R₁ wlo whi vmin : ℝ}
    (sol : ClassicalSolution H g α β k₀ k₁ k₂ κd T)
    (hH : 0 < H) (hg : 0 ≤ g) (hk₀ : 0 < k₀)
    (hκ : 0 < κ) (hk₁ : κ ≤ k₁) (hk₂ : κ ≤ k₂) (hκd : 0 < κd)
    (hdb : ∀ t ∈ Ico 0 T, |sol.d t| ≤ dbar)
    (hinit : sol.V 0 ≤ cap) (hcap : dbar^2/(16*κ*κd) ≤ cap)
    (hr : ∀ t ∈ Icc 0 T, rlo ≤ sol.r t ∧ sol.r t ≤ rhi)
    (hr₁ : ∀ t ∈ Icc 0 T, |sol.r₁ t| ≤ R₁)
    (hpositive : 0 < rlo-sqrt (2*cap/k₀))
    (hforward : 2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀)) < wlo)
    (horder : wlo ≤ whi)
    (hcrown : vmin ≤ wlo-(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀)))
    (hl : (1-β)*wlo^2+2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))*wlo+
      (R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))^2 ≤ g*(H+(rlo-sqrt (2*cap/k₀))))
    (hu : g*(H+(rhi+sqrt (2*cap/k₀))) ≤ (1-β)*whi^2-
      2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))*whi+(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))^2)
    (hw₀ : wlo ≤ sol.w 0 ∧ sol.w 0 ≤ whi) :
    ∀ t ∈ Icc 0 T, sol.V t ≤ cap ∧
      0 < sol.h t ∧ wlo ≤ sol.w t ∧ sol.w t ≤ whi ∧
      0 < sol.v t ∧ vmin ≤ (sol.v t+sol.w t)/2 := by
  have hE := sol.energy_bound hk₀.le hκ hk₁ hk₂ hκd hdb
  have hEC : ∀ t ∈ Icc 0 T, sol.V t ≤ cap := by
    intro t ht
    have henv := envelope_below_cap (C:=dbar^2/(8*κd)) hκ ht.1 hinit
      (by convert! hcap using 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring)
    have he : sol.V t ≤ envelope (sol.V 0) κ (dbar^2/(8*κd)) t := by
      convert! hE t ht using 1; unfold envelope; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    exact he.trans henv
  have hbox := fun t ht => trajectory_enclosure hk₀ (hEC t ht) (hr t ht) (hr₁ t ht)
  have hhc : ContinuousOn sol.h (Icc 0 T) := fun t ht => (sol.dh t ht).continuousAt.continuousWithinAt
  have hwc : ContinuousOn sol.w (Icc 0 T) := fun t ht => (sol.dw t ht).continuousAt.continuousWithinAt
  have hvc : ContinuousOn sol.v (Icc 0 T) := fun t ht => (sol.dv t ht).continuousAt.continuousWithinAt
  have hqc : ContinuousOn (fun t => heightRate (sol.v t) (sol.w t)) (Icc 0 T) :=
    (hvc.sub hwc).div_const 2
  have hK (b : ℝ) : ContinuousOn
      (fun t => -((1-β)*(sol.w t+b)+2*heightRate (sol.v t) (sol.w t))/(H+sol.h t)) (Icc 0 T) :=
    ((continuousOn_const.mul (hwc.add continuousOn_const)).add
      (continuousOn_const.mul hqc)).neg.div (continuousOn_const.add hhc) sol.Hh_ne
  have hphys := physical_region_invariant hH hg hpositive
    (fun t ht => (sol.dw t ht).continuousAt.continuousWithinAt)
    (fun t ht => (mechanical_internal_equation (sol.Hh_ne t (Ico_subset_Icc_self ht))
      (sol.dw t (Ico_subset_Icc_self ht))).hasDerivWithinAt)
    (hK wlo) (hK whi) (fun t ht => ⟨(hbox t ht).1,(hbox t ht).2.1⟩)
    (fun t ht => (hbox t ht).2.2) hforward horder hcrown hl hu hw₀
  intro t ht
  obtain ⟨hh,hwlo,hwhi,hv,hc⟩ := hphys t ht
  have hvId : sol.w t+2*heightRate (sol.v t) (sol.w t) = sol.v t := by unfold heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hsId : sol.w t+heightRate (sol.v t) (sol.w t) = (sol.v t+sol.w t)/2 := by unfold heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [hvId] at hv; rw [hsId] at hc
  exact ⟨hEC t ht,hh,hwlo,hwhi,hv,hc⟩

end
end ChainFountain
