module

public import ChainFountain.MeasurableTracking

@[expose] public section

namespace ChainFountain
noncomputable section
open Set Filter MeasureTheory Function Metric
open scoped NNReal Topology

/-- Uniqueness of integral solutions does not assume a Lipschitz trajectory.
The bounded integral equation itself supplies the required regularity. -/
theorem IntegralPicard.continuous_integral_unique
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    (v : IntegralPicard E) {x y : ℝ → E} (hx : Continuous x) (hy : Continuous y)
    (hxi : ∀ t∈Icc v.tMin v.tMax, x t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (x s))
    (hyi : ∀ t∈Icc v.tMin v.tMax, y t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (y s)) :
    ∀ t∈Icc v.tMin v.tMax, x t=y t := by
  have mk (z : ℝ → E) (hz : Continuous z)
      (hi : ∀ t∈Icc v.tMin v.tMax, z t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (z s)) :
      ∃ f : v.FunSpace, f.next=f ∧ ∀ t : Icc v.tMin v.tMax, f t=z t := by
    have hInt (a b : ℝ) : IntervalIntegrable (fun s => v s (z s)) volume a b := by
      rw [intervalIntegrable_iff]
      exact Measure.integrableOn_of_bounded measure_Ioc_lt_top.ne
        (v.measurable_curve z hz) (Eventually.of_forall (fun s => v.bound_all s (z s)))
    let f : v.FunSpace := {
      toFun := fun t => z t
      map_t₀' := by simpa using! hi v.t₀ v.t₀.2
      lipschitz' := LipschitzWith.of_dist_le_mul (fun a b => by
        rw [hi a a.2, hi b b.2, dist_add_left, dist_eq_norm,
          intervalIntegral.integral_interval_sub_left (hInt _ _) (hInt _ _)]
        exact intervalIntegral.norm_integral_le_of_norm_le_const
          (fun s _ => v.bound_all s (z s))) }
    refine ⟨f,?_,fun _ => rfl⟩
    apply IntegralPicard.FunSpace.toContinuousMap.injective
    apply ContinuousMap.ext
    intro t
    change v.x₀+∫ s in (v.t₀:ℝ)..(t:ℝ), v s (z (v.proj s))=z t
    rw [hi t t.2]
    congr 1
    apply intervalIntegral.integral_congr
    intro s hs
    have hmem : s∈Icc v.tMin v.tMax := (uIcc_subset_Icc v.t₀.2 t.2) hs
    dsimp only
    rw [v.proj_of_mem hmem]
  obtain ⟨f,hf,hfx⟩ := mk x hx hxi
  obtain ⟨g,hg,hgy⟩ := mk y hy hyi
  obtain ⟨n,K,hK⟩ := v.exists_contracting_iterate
  have hfg : f=g := hK.fixedPoint_unique' (IsFixedPt.iterate hf n) (IsFixedPt.iterate hg n)
  intro t ht
  rw [←hfx ⟨t,ht⟩,←hgy ⟨t,ht⟩,hfg]

/-- The actual projected mechanical field supplies bounded measurable Picard
 data uniformly on every finite interval. -/
theorem GlobalTrackingData.measurable_picard_data (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hd : Measurable d) (hb : ∀ t, |d t|≤ c.dbar) {T : ℝ} (hT : 0≤ T) :
    ∃ v : IntegralPicard MechanicalState,
      v.tMin=0 ∧ v.tMax=T ∧ (v.t₀:ℝ)=0 ∧ v.x₀=c.x₀ ∧
      ∀ t x, v t x=c.measurableField d t (c.project x) := by
  obtain ⟨L,N,hL,hN⟩ := c.joint_bounds
  let F := fun t x => c.measurableField d t (c.project x)
  have hfl : ∀ t, LipschitzWith L (F t) := by
    intro t
    have hh := hL.comp
      ((LipschitzWith.prodMk_left (c.measurableParameters d t)).comp c.project_lipschitz).lipschitzOnWith (s:=univ)
      (fun x _ => ⟨c.measurable_parameters_mem hb t,c.project_mem x⟩)
    simpa [F,GlobalTrackingData.measurableField,lipschitzOnWith_univ] using! hh
  have hpm : Measurable (c.measurableParameters d) :=
    c.parameters_continuous.fst.measurable.prodMk
      (c.parameters_continuous.snd.fst.measurable.prodMk
        (c.parameters_continuous.snd.snd.fst.measurable.prodMk hd))
  have hfm : ∀ f : ℝ → MechanicalState, Continuous f →
      AEStronglyMeasurable (fun t => F t (f t)) volume := by
    intro f hf
    let y (t : ℝ) : c.parameterBox ×ˢ c.outerBox :=
      ⟨(c.measurableParameters d t,c.project (f t)),c.measurable_parameters_mem hb t,c.project_mem _⟩
    have hy : Measurable y := (hpm.prodMk (c.project_lipschitz.continuous.comp hf).measurable).subtype_mk
    exact (hL.continuousOn.restrict.measurable.comp hy).aestronglyMeasurable
  let v : IntegralPicard MechanicalState := {
    toFun := F
    tMin := 0
    tMax := T
    t₀ := ⟨0,le_rfl,hT⟩
    x₀ := c.x₀
    C := ⟨max N 0,le_max_right _ _⟩
    L := L
    lipschitz_all := hfl
    measurable_curve := hfm
    bound_all := fun t x => (hN _ ⟨c.measurable_parameters_mem hb t,c.project_mem x⟩).trans
      (le_max_left _ _) }
  exact ⟨v,rfl,rfl,rfl,rfl,fun _ _ => rfl⟩

/-- A globally constructed physical solution is unique among all continuous
integral solutions of the ORIGINAL field. No safe-box, Lipschitz, or existence
hypothesis is imposed on the competing solution. This is the integral
Caratheodory formulation; the AC/a.e. equivalence is a separate FTC bridge. -/
theorem GlobalTrackingData.exists_unique_global_integral (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hd : Measurable d) (hb : ∀ t, |d t|≤ c.dbar) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      (∀ t≥0, x t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (x s)) ∧
      ∀ y : ℝ → MechanicalState, Continuous y →
        (∀ t≥0, y t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (y s)) →
        ∀ t≥0, y t=x t := by
  obtain ⟨x,K,ε,hε,hxL,hx₀,hxI,hxD,hlocal,hlocalD⟩ := c.exists_measurable_local hd hb
  have hstay := no_exit_of_prefix_bound hxL.continuous
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    (hx₀ ▸ c.safeBox_interior c.initial_mem) (fun T hT hbox =>
      c.measurable_prefix_bound hκd hb hxL hT hx₀ hbox hxD)
  have hxi (t : ℝ) (ht : 0≤ t) : x t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (x s) := by
    rw [hxI t]
    congr 1
    apply intervalIntegral.integral_congr
    intro s hs
    rw [uIcc_of_le ht] at hs
    dsimp only
    rw [c.project_eq (x s) (interior_subset (c.safeBox_interior (hstay s hs.1)))]
  refine ⟨x,K,hxL,hx₀,hstay,hxi,?_⟩
  intro y hy hyi
  have hprefix (T : ℝ) (hT : 0≤ T) (hyB : ∀ t∈Icc 0 T, y t∈c.outerBox) :
      ∀ t∈Icc 0 T, y t=x t := by
    obtain ⟨v,hmin,hmax,hzero,hinit,hfield⟩ := c.measurable_picard_data hd hb hT
    have hi (t : ℝ) (ht : t∈Icc v.tMin v.tMax) :
        y t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (y s) := by
      rw [hmin,hmax] at ht
      rw [hinit,hzero,hyi t ht.1]
      congr 1
      apply intervalIntegral.integral_congr
      intro s hs
      rw [uIcc_of_le ht.1] at hs
      dsimp only
      rw [hfield,c.project_eq (y s) (hyB s ⟨hs.1,hs.2.trans ht.2⟩)]
    have hj (t : ℝ) (ht : t∈Icc v.tMin v.tMax) :
        x t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (x s) := by
      simpa only [hinit,hzero,hfield] using! hxI t
    simpa only [hmin,hmax] using! v.continuous_integral_unique hy hxL.continuous hi hj
  have hy₀ : y 0=c.x₀ := by simpa using! hyi 0 le_rfl
  have hystay := no_exit_of_prefix_bound hy
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    (hy₀ ▸ c.safeBox_interior c.initial_mem) (fun T hT hbox => by
      rw [hprefix T hT hbox T ⟨hT,le_rfl⟩]; exact hstay T hT)
  intro t ht
  exact hprefix t ht (fun s hs => interior_subset (c.safeBox_interior (hystay s hs.1))) t ⟨ht,le_rfl⟩

end
end ChainFountain
