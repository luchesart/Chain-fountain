module

public import ChainFountain.LebesgueFTC

@[expose] public section

namespace ChainFountain
noncomputable section
open Set Filter MeasureTheory intervalIntegral
open scoped Topology NNReal

/-- Reverse FTC for a Lipschitz real function, proved by dominated convergence
of difference quotients. This excludes singular continuous counterexamples to
an a.e.-derivative-only comparison argument. -/
theorem lipschitz_integral_deriv {f : ℝ → ℝ} {L : ℝ≥0}
    (hf : LipschitzWith L f) {a b : ℝ} (hab : a≤ b) :
    ∫ t in a..b, deriv f t = f b-f a := by
  let q (ε t : ℝ) := ε⁻¹*(f (t+ε)-f t)
  have hbound {ε : ℝ} (hε : 0<ε) (t : ℝ) : ‖q ε t‖≤ L := by
    have hl := hf.norm_sub_le (t+ε) t
    simp only [add_sub_cancel_left,Real.norm_eq_abs,abs_of_pos hε] at hl
    dsimp [q]
    rw [abs_mul,abs_inv,abs_of_pos hε]
    calc
      ε⁻¹*‖f (t+ε)-f t‖ ≤ ε⁻¹*((L:ℝ)*ε) := mul_le_mul_of_nonneg_left hl (by positivity)
      _ = L := by field_simp
  have hlim : Tendsto (fun ε => ∫ t in Ioc a b, q ε t) (𝓝[>] 0)
      (𝓝 (∫ t in Ioc a b, deriv f t)) := by
    apply MeasureTheory.tendsto_integral_filter_of_dominated_convergence (fun _ => (L:ℝ))
    · apply Filter.Eventually.of_forall
      intro ε
      have hc : Continuous (q ε) := by
        dsimp [q]
        exact continuous_const.mul ((hf.continuous.comp (continuous_id.add continuous_const)).sub hf.continuous)
      exact hc.aestronglyMeasurable
    · filter_upwards [self_mem_nhdsWithin] with ε (hε:0<ε)
      exact Filter.Eventually.of_forall (hbound hε)
    · exact integrable_const _
    · filter_upwards [ae_restrict_of_ae hf.ae_differentiableAt_real] with t ht
      simpa [q,smul_eq_mul] using! ht.hasDerivAt.tendsto_slope_zero_right
  let P : ℝ → ℝ := fun t => ∫ s in (0:ℝ)..t, f s
  have hP (t : ℝ) : HasDerivAt P (f t) t :=
    integral_hasDerivAt_right (hf.continuous.intervalIntegrable _ _)
      hf.continuous.aestronglyMeasurable.stronglyMeasurableAtFilter hf.continuous.continuousAt
  have hboundary := (hP b).tendsto_slope_zero_right.sub (hP a).tendsto_slope_zero_right
  have heq (ε : ℝ) : (∫ t in Ioc a b, q ε t) =
      ε⁻¹*(P (b+ε)-P b)-ε⁻¹*(P (a+ε)-P a) := by
    rw [← integral_of_le hab]
    change (∫ t in a..b, ε⁻¹*(f (t+ε)-f t)) = _
    have hshift : IntervalIntegrable (fun t => f (t+ε)) volume a b :=
      (hf.continuous.comp (continuous_id.add continuous_const)).intervalIntegrable _ _
    rw [intervalIntegral.integral_const_mul,intervalIntegral.integral_sub
      hshift
      (hf.continuous.intervalIntegrable _ _),integral_comp_add_right]
    have hi (u v : ℝ) : IntervalIntegrable f volume u v := hf.continuous.intervalIntegrable u v
    rw [integral_interval_sub_interval_comm' (hi (a+ε) (b+ε)) (hi a b) (hi (a+ε) a)]
    dsimp [P]
    rw [integral_interval_sub_left (hi 0 (b+ε)) (hi 0 b),
      integral_interval_sub_left (hi 0 (a+ε)) (hi 0 a)]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hother : Tendsto (fun ε => ∫ t in Ioc a b, q ε t) (𝓝[>] 0) (𝓝 (f b-f a)) := by
    simpa only [heq,smul_eq_mul] using! hboundary
  rw [integral_of_le hab]
  exact tendsto_nhds_unique hlim hother

/-- A.e. derivative comparison for Lipschitz curves, with an actual integral
proof rather than an assumption that an a.e. inequality implies monotonicity. -/
theorem lipschitz_nonincreasing_of_ae_derivative {f f' : ℝ → ℝ} {L : ℝ≥0}
    (hf : LipschitzWith L f) {a b : ℝ} (hab : a≤ b)
    (hd : ∀ᵐ t ∂volume, t∈Icc a b → HasDerivAt f (f' t) t)
    (hneg : ∀ᵐ t ∂volume, t∈Icc a b → f' t≤0) : f b≤ f a := by
  have hle : ∫ t in a..b, deriv f t ≤ 0 := by
    rw [intervalIntegral.integral_of_le hab]
    apply integral_nonpos_of_ae
    filter_upwards [ae_restrict_of_ae hd,ae_restrict_of_ae hneg,ae_restrict_mem measurableSet_Ioc]
      with t ht hn hmem
    rw [(ht (Ioc_subset_Icc_self hmem)).deriv]
    exact hn (Ioc_subset_Icc_self hmem)
  rw [lipschitz_integral_deriv hf hab] at hle
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

theorem lipschitzOn_nonincreasing_of_ae_derivative {f f' : ℝ → ℝ} {L : ℝ≥0}
    {a b : ℝ} (hab : a≤ b) (hf : LipschitzOnWith L f (Icc a b))
    (hd : ∀ᵐ t ∂volume, t∈Ioo a b → HasDerivAt f (f' t) t)
    (hneg : ∀ᵐ t ∂volume, t∈Ioo a b → f' t≤0) : f b≤ f a := by
  by_cases heq : a=b
  · simpa [heq]
  have hab' : a<b := lt_of_le_of_ne hab heq
  let g : ℝ → ℝ := fun t => f (projIcc a b hab t)
  have hgl : LipschitzWith L g := by
    simpa only [mul_one,Function.comp_def,Set.restrict_apply] using!
      hf.to_restrict.comp (LipschitzWith.projIcc hab)
  have he (t : ℝ) (ht : t∈Ioo a b) : g =ᶠ[𝓝 t] f := by
    filter_upwards [Ioo_mem_nhds ht.1 ht.2] with s hs
    simp [g,projIcc_of_mem hab (Ioo_subset_Icc_self hs)]
  have hneq (c : ℝ) : ∀ᵐ t ∂volume, t≠c := by
    simp [ae_iff,measure_singleton]
  have hgd : ∀ᵐ t ∂volume, t∈Icc a b → HasDerivAt g (f' t) t := by
    filter_upwards [hd,hneq a,hneq b] with t ht hta htb hmem
    have ho : t∈Ioo a b := ⟨lt_of_le_of_ne hmem.1 (Ne.symm hta),lt_of_le_of_ne hmem.2 htb⟩
    exact (ht ho).congr_of_eventuallyEq (he t ho)
  have hgn : ∀ᵐ t ∂volume, t∈Icc a b → f' t≤0 := by
    filter_upwards [hneg,hneq a,hneq b] with t ht hta htb hmem
    exact ht ⟨lt_of_le_of_ne hmem.1 (Ne.symm hta),lt_of_le_of_ne hmem.2 htb⟩
  have h := lipschitz_nonincreasing_of_ae_derivative hgl hab hgd hgn
  simpa [g,projIcc_of_mem hab (left_mem_Icc.mpr hab),projIcc_of_mem hab (right_mem_Icc.mpr hab)] using! h

/-- A Lipschitz curve with a continuous a.e. derivative is classical. This is
used for the height/falling components, which have no direct disturbance term. -/
theorem lipschitz_ae_continuous_derivative {f g : ℝ → ℝ} {L : ℝ≥0}
    (hf : LipschitzWith L f) (hg : Continuous g)
    (hd : ∀ᵐ t ∂volume, HasDerivAt f (g t) t) :
    ∀ t, HasDerivAt f (g t) t := by
  have hie (a b : ℝ) : ∫ t in a..b, deriv f t = f b-f a := by
    rcases le_total a b with hab | hba
    · exact lipschitz_integral_deriv hf hab
    · rw [integral_symm,lipschitz_integral_deriv hf hba]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have heq (t : ℝ) : f t=f 0+∫ s in (0:ℝ)..t, g s := by
    have he : (∫ s in (0:ℝ)..t, deriv f s) = ∫ s in (0:ℝ)..t, g s := by
      apply intervalIntegral.integral_congr_ae
      filter_upwards [hd] with s hs _
      exact hs.deriv
    rw [hie] at he
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  intro t
  have hp := intervalIntegral.integral_hasDerivAt_right (hg.intervalIntegrable 0 t)
    hg.aestronglyMeasurable.stronglyMeasurableAtFilter hg.continuousAt
  convert! hp.const_add (f 0) using 1
  exact funext heq

end
end ChainFountain
