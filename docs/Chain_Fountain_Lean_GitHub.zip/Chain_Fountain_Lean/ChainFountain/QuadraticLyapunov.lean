module

public import ChainFountain.Linearization
public import ChainFountain.GlobalODE
public import ChainFountain.Comparison

@[expose] public section

namespace ChainFountain
noncomputable section
open Set Metric Real Filter
open scoped Topology

/-- Compactness turns a positive homogeneous quadratic function into a uniform
coercivity estimate. The minimum is proved to be positive, not assumed. -/
theorem quadratic_coercive {V : State₃ → ℝ}
    (hc : Continuous V) (hh : ∀ (a : ℝ) x, V (a • x) = a^2 * V x)
    (hp : ∀ x ≠ 0, 0 < V x) :
    ∃ m > 0, ∀ x, m * ‖x‖^2 ≤ V x := by
  have hne : (sphere (0 : State₃) 1).Nonempty := by
    refine ⟨(1,0,0), ?_⟩
    norm_num [mem_sphere, dist_eq_norm, Prod.norm_def]
  obtain ⟨u,hu,hmin⟩ := (isCompact_sphere (0 : State₃) 1).exists_isMinOn hne hc.continuousOn
  have hun : ‖u‖ = 1 := by simpa [mem_sphere,dist_zero_right] using! hu
  have hup : 0 < V u := hp u (by intro h; simp [h] at hun)
  refine ⟨V u,hup,fun x => ?_⟩
  by_cases hx : x = 0
  · have hz := hh 0 (0 : State₃)
    simpa [hx] using! hz.ge
  · have hn : 0 < ‖x‖ := norm_pos_iff.mpr hx
    have hs : ‖x‖⁻¹ • x ∈ sphere (0 : State₃) 1 := by
      simpa [mem_sphere,dist_zero_right] using! (norm_smul_inv_norm (𝕜:=ℝ) hx)
    have h := mul_le_mul_of_nonneg_left (hmin hs) (sq_nonneg ‖x‖)
    rw [hh] at h
    have he : ‖x‖^2 * (‖x‖⁻¹^2 * V x) = V x := by field_simp
    rw [he] at h
    simpa [mul_comm] using! h

abbrev QuadraticBilin := State₃ →L[ℝ] State₃ →L[ℝ] ℝ

theorem quadratic_bilin_bound (B : QuadraticBilin) (x y : State₃) :
    |B x y| ≤ ‖B‖ * ‖x‖ * ‖y‖ := by
  exact (B x).le_opNorm y |>.trans
    (mul_le_mul_of_nonneg_right (B.le_opNorm x) (norm_nonneg y))

/-- A strict quadratic certificate for the derivative survives the nonlinear
remainder. All constants are obtained from the actual Frechet derivative. -/
theorem nonlinear_quadratic_decay
    {F : State₃ → State₃} {A : State₃ →L[ℝ] State₃} (B : QuadraticBilin)
    (hF : HasFDerivAt F A 0) (hzero : F 0 = 0)
    (hpos : ∀ x ≠ 0, 0 < B x x)
    (hneg : ∀ x ≠ 0, B x (A x) + B (A x) x < 0) :
    ∃ m M κ r : ℝ, 0 < m ∧ 0 < M ∧ 0 < κ ∧ 0 < r ∧
      (∀ x, m*‖x‖^2 ≤ B x x ∧ B x x ≤ M*‖x‖^2) ∧
      ∀ x, ‖x‖ < r → B x (F x)+B (F x) x ≤ -2*κ*(B x x) := by
  obtain ⟨m,hm,hml⟩ := quadratic_coercive
    (B.continuous.clm_apply continuous_id)
    (by intro a x; simp [map_smul,smul_eq_mul]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring) hpos
  obtain ⟨q,hq,hql⟩ := quadratic_coercive
    ((B.continuous.clm_apply A.continuous).add
      ((B.continuous.comp A.continuous).clm_apply continuous_id)).neg
    (by intro a x; simp [map_smul,smul_eq_mul]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring)
    (fun x hx => neg_pos.mpr (hneg x hx))
  let M : ℝ := ‖B‖+1
  have hM : 0 < M := by dsimp [M]; positivity
  have hMv (x : State₃) : B x x ≤ M*‖x‖^2 := by
    have hb := quadratic_bilin_bound B x x
    have hba := le_abs_self (B x x)
    dsimp [M]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [sq_nonneg ‖x‖]
  have heps : 0 < q/(4*M) := by positivity
  obtain ⟨r,hr,hrem⟩ := Metric.eventually_nhds_iff.mp (hF.isLittleO.bound heps)
  refine ⟨m,M,q/(8*M),r,hm,hM,by positivity,hr,
    fun x => ⟨hml x,hMv x⟩,fun x hx => ?_⟩
  have he : ‖F x-A x‖ ≤ q/(4*M)*‖x‖ := by
    simpa [hzero,dist_zero_right] using! hrem (by simpa [dist_zero_right] using! hx)
  have b₁ := quadratic_bilin_bound B x (F x-A x)
  have b₂ := quadratic_bilin_bound B (F x-A x) x
  have hh₁ := mul_le_mul_of_nonneg_left he (mul_nonneg (norm_nonneg B) (norm_nonneg x))
  have hh₂ := mul_le_mul_of_nonneg_right
    (mul_le_mul_of_nonneg_left he (norm_nonneg B)) (norm_nonneg x)
  have hl := hql x
  dsimp only [Function.comp_apply,id_eq] at hl
  have heq : B x (F x)+B (F x) x = B x (A x)+B (A x) x +
      B x (F x-A x)+B (F x-A x) x := by simp [map_sub]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hlin : B x (F x)+B (F x) x ≤ -q/2*‖x‖^2 := by
    have hnM : ‖B‖ ≤ M := by dsimp [M]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
    have hcoef : 2*‖B‖*(q/(4*M)) ≤ q/2 := by
      calc
        2*‖B‖*(q/(4*M)) ≤ 2*M*(q/(4*M)) := by gcongr
        _ = q/2 := by field_simp <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    have hcs := mul_le_mul_of_nonneg_right hcoef (sq_nonneg ‖x‖)
    rw [heq]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [le_abs_self (B x (F x-A x)),le_abs_self (B (F x-A x) x)]
  have hc := mul_le_mul_of_nonneg_left (hMv x) (show 0 ≤ q/(4*M) by positivity)
  have hc' : q/(4*M)*(M*‖x‖^2) = q/4*‖x‖^2 := by field_simp <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [hc'] at hc
  have heκ : 2*(q/(8*M)) = q/(4*M) := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [neg_mul,heκ]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_nonneg hq.le (sq_nonneg ‖x‖)]

end
end ChainFountain
