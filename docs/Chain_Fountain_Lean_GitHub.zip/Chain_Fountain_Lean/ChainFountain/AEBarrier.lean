module

public import ChainFountain.Barrier
public import ChainFountain.AEComparison

@[expose] public section

namespace ChainFountain
noncomputable section
open Set Real Filter MeasureTheory
open scoped NNReal

def filteredCommand (H g β αlo αhi γ vmin uLo uHi : ℝ)
    (h v w desired : ℝ → ℝ) (t : ℝ) :=
  clip (max uLo (barrierLower αhi (v t)))
    (min uHi (barrierUpper H g β αlo (h t) (v t) (w t) γ ((v t+w t)/2-vmin)))
    (desired t)

/-- The robust least-change filter implies the crown comparison along an a.e.
mechanical trajectory on a regular interval. It does not assert existence of
the filtered trajectory or positivity of either leg separately. -/
theorem filtered_mechanical_crown_ae
    {H g β αlo αhi γ vmin uLo uHi T : ℝ}
    {h v w α desired : ℝ → ℝ} {Lv Lw : ℝ≥0}
    (hγ : 0<γ) (hα : αlo≤αhi)
    (hvL : LipschitzOnWith Lv v (Icc 0 T)) (hwL : LipschitzOnWith Lw w (Icc 0 T))
    (hh : ∀ t∈Icc 0 T, 0<h t)
    (hcoef : ∀ t∈Icc 0 T, α t∈Icc αlo αhi)
    (hfeas : ∀ t∈Icc 0 T, max uLo (barrierLower αhi (v t))≤
      min uHi (barrierUpper H g β αlo (h t) (v t) (w t) γ ((v t+w t)/2-vmin)))
    (dv : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt v
      (rise g (α t) (h t) (v t) (w t)
        (filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t)) t)
    (dw : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt w (fall H g β (h t) (v t) (w t)) t) :
    ∀ t∈Icc 0 T,
      ((v 0+w 0)/2-vmin)*exp (-γ*t)≤(v t+w t)/2-vmin ∧
      uLo≤ filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t ∧
      filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t≤ uHi ∧
      0≤ pickup (α t) (v t) (filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t) := by
  let u := filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired
  let B := fun t => (v t+w t)/2-vmin
  have hclip (t : ℝ) (ht : t∈Icc 0 T) := clip_mem (desired:=desired t) (hfeas t ht)
  have hupper (t : ℝ) (ht : t∈Icc 0 T) :
      u t≤ barrierUpper H g β αlo (h t) (v t) (w t) γ (B t) :=
    (hclip t ht).2.trans (min_le_right _ _)
  have hcrown (t : ℝ) (ht : t∈Icc 0 T) :
      0≤(rise g (α t) (h t) (v t) (w t) (u t)+fall H g β (h t) (v t) (w t))/2+γ*B t :=
    ((crown_endpoint_iff (hh t ht) hα).mpr (hupper t ht)) (α t) (hcoef t ht)
  have hsm : ContDiff ℝ 1 (fun p : ℝ×ℝ => -((p.1+p.2)/2-vmin)) := by fun_prop (disch := norm_num)
  obtain ⟨L,hL⟩ := smooth_comp_lipschitzOn hsm (hvL.prodMk hwL)
  have hd : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt (fun s => -B s)
      (-((rise g (α t) (h t) (v t) (w t) (u t)+fall H g β (h t) (v t) (w t))/2)) t := by
    filter_upwards [dv,dw] with t ht hv hmem
    exact ((((ht hmem).add (hv hmem)).div_const 2).sub_const vmin).neg
  have hi := scalar_comparison_ae (κ:=γ/2) (C:=0) (by positivity) hL hd (by
    apply Eventually.of_forall
    intro t ht
    have hh := hcrown t (Ioo_subset_Icc_self ht)
    dsimp [B] at hh ⊢
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith)
  intro t ht
  refine ⟨?_,(le_max_left _ _).trans (hclip t ht).1,
    (hclip t ht).2.trans (min_le_left _ _),?_⟩
  · have hb := hi t ht
    dsimp [envelope] at hb
    have heq : -2*(γ/2)*t= -γ*t := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    rw [heq] at hb
    simp only [zero_div,zero_mul,add_zero] at hb
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
  · exact ((pickup_endpoint_iff hα).mpr ((le_max_right _ _).trans (hclip t ht).1))
      (α t) (hcoef t ht)

theorem filtered_command_least_change
    {H g β αlo αhi γ vmin uLo uHi t : ℝ} {h v w desired : ℝ → ℝ}
    (hfeas : max uLo (barrierLower αhi (v t))≤
      min uHi (barrierUpper H g β αlo (h t) (v t) (w t) γ ((v t+w t)/2-vmin)))
    {u : ℝ} (hu : uLo≤ u ∧ u≤ uHi ∧ barrierLower αhi (v t)≤ u ∧
      u≤ barrierUpper H g β αlo (h t) (v t) (w t) γ ((v t+w t)/2-vmin)) :
    (filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t-desired t)^2≤
      (u-desired t)^2 :=
  clip_nearest hfeas ⟨max_le hu.1 hu.2.2.1,le_min hu.2.1 hu.2.2.2⟩

end
end ChainFountain
