module

public import ChainFountain.Spectral

@[expose] public section

namespace ChainFountain
noncomputable section
set_option maxHeartbeats 1000000

abbrev State₃ := ℝ × ℝ × ℝ
def heightProjection : State₃ →L[ℝ] ℝ := ContinuousLinearMap.fst ℝ ℝ (ℝ×ℝ)
def riseProjection : State₃ →L[ℝ] ℝ :=
  (ContinuousLinearMap.fst ℝ ℝ ℝ).comp (ContinuousLinearMap.snd ℝ ℝ (ℝ×ℝ))
def fallProjection : State₃ →L[ℝ] ℝ :=
  (ContinuousLinearMap.snd ℝ ℝ ℝ).comp (ContinuousLinearMap.snd ℝ ℝ (ℝ×ℝ))

def openLoopField (H g α β : ℝ) (x : State₃) : State₃ :=
  (heightRate x.2.1 x.2.2,rise g α x.1 x.2.1 x.2.2 0,fall H g β x.1 x.2.1 x.2.2)

/-- The matrix in equation (4.4), as a continuous linear map on product coordinates. -/
def paperJacobian (α β ρ ω : ℝ) : State₃ →L[ℝ] State₃ :=
  ((1/2 : ℝ) • riseProjection - (1/2 : ℝ) • fallProjection).prod
    (((-α*ω^2) • heightProjection - ((1-2*α)*ω) • riseProjection + ω • fallProjection).prod
      ((α*ρ*ω^2) • heightProjection - (ρ*ω) • riseProjection -
        ((1-2*β)*ρ*ω) • fallProjection))

/-- A genuine Frechet derivative of the mechanical field, under the equilibrium
balances. No derivative-identification hypothesis is assumed. -/
theorem open_loop_frechet_derivative {H g α β h s : ℝ}
    (hh : h ≠ 0) (hH : H+h ≠ 0)
    (he₁ : α*s^2=g*h) (he₂ : (1-β)*s^2=g*(H+h)) :
    HasFDerivAt (openLoopField H g α β)
      (paperJacobian α β (h/(H+h)) (s/h)) (h,s,s) := by
  let x : State₃ := (h,s,s)
  have dh := heightProjection.hasFDerivAt (x:=x)
  have dv := riseProjection.hasFDerivAt (x:=x)
  have dw := fallProjection.hasFDerivAt (x:=x)
  have ds := (dv.add dw).mul_const (1/2 : ℝ)
  have dS := ds.mul ds
  have dr := (((dS.sub ((dv.mul dv).const_mul (1-α))).sub (dh.const_mul g)).sub_const 0).mul ((hasFDerivAt_inv hh).comp x dh)
  have df := ((dS.neg.add ((dw.mul dw).const_mul β)).mul ((hasFDerivAt_inv hH).comp x (dh.const_add H))).const_add g
  have dq := (dv.sub dw).mul_const (1/2 : ℝ)
  have dF := dq.prodMk (dr.prodMk df)
  refine (dF.congr_of_eventuallyEq ?_).congr_fderiv ?_
  · apply Filter.Eventually.of_forall
    intro y
    ext <;> simp [openLoopField,heightRate,rise,fall,crownSq,heightProjection,riseProjection,fallProjection] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  · apply ContinuousLinearMap.ext
    intro y
    apply Prod.ext
    · simp [paperJacobian,heightProjection,riseProjection,fallProjection]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    · apply Prod.ext <;>
        simp [paperJacobian,heightProjection,riseProjection,fallProjection,x,
          ContinuousLinearMap.prod_apply,ContinuousLinearMap.comp_apply] <;>
        field_simp
      · (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
      · linear_combination 4*y.1*h*he₂ - 4*y.1*(H+h)*he₁

theorem paper_jacobian_action (α β ρ ω : ℝ) (y : State₃) :
    paperJacobian α β ρ ω y =
      (y.2.1/2-y.2.2/2,
       -α*ω^2*y.1-(1-2*α)*ω*y.2.1+ω*y.2.2,
       α*ρ*ω^2*y.1-ρ*ω*y.2.1-(1-2*β)*ρ*ω*y.2.2) := by
  simp [paperJacobian,heightProjection,riseProjection,fallProjection]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- Genuine derivative with respect to the physical input u, at a fixed state. -/
theorem input_vector_derivative (H g α β h v w u : ℝ) :
    HasDerivAt (fun U => (heightRate v w,rise g α h v w U,fall H g β h v w))
      (0,-1/h,0) u := by
  have hu := ((hasDerivAt_const u (crownSq v w-(1-α)*v^2-g*h)).sub
    (hasDerivAt_id u)).div_const h
  simpa [rise] using! (hasDerivAt_const u (heightRate v w)).prodMk
    (hu.prodMk (hasDerivAt_const u (fall H g β h v w)))

end
end ChainFountain
