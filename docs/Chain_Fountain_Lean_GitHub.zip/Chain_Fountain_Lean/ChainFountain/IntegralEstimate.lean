module

public import ChainFountain.Comparison

@[expose] public section

namespace ChainFountain
noncomputable section
open Set Real MeasureTheory

/-- Equation (7.5), integrated via the fundamental theorem of calculus.
Interval integrability and classical derivatives are explicit, not placeholders
for the estimate being proved. The weighted error norm squared equals 2V. -/
theorem weighted_integral_estimate {V V' d : ℝ → ℝ} {T κ κd : ℝ}
    (hT : 0 ≤ T) (hκ : 0 < κ) (hκd : 0 < κd)
    (hV : IntervalIntegrable V volume 0 T)
    (hVp : IntervalIntegrable V' volume 0 T)
    (hd : IntervalIntegrable (fun t => d t ^ 2) volume 0 T)
    (hder : ∀ t ∈ Icc 0 T, HasDerivAt V (V' t) t)
    (hbound : ∀ t ∈ Icc 0 T, V' t ≤ -2*κ*V t+d t^2/(8*κd))
    (hVT : 0 ≤ V T) :
    (∫ t in (0 : ℝ)..T, 2*V t) ≤
      V 0/κ + (1/(8*κ*κd))*(∫ t in (0 : ℝ)..T, d t^2) := by
  have hi := intervalIntegral.integral_mono_on hT hVp
    ((hV.const_mul (-2*κ)).add (hd.div_const (8*κd))) hbound
  have hFTC : (∫ t in (0 : ℝ)..T, V' t) = V T-V 0 := by
    apply intervalIntegral.integral_eq_sub_of_hasDerivAt _ hVp
    simpa only [uIcc_of_le hT] using hder
  rw [hFTC, intervalIntegral.integral_add (hV.const_mul (-2*κ)) (hd.div_const (8*κd)),
    intervalIntegral.integral_const_mul,intervalIntegral.integral_div] at hi
  rw [intervalIntegral.integral_const_mul]
  apply (mul_le_mul_iff_right₀ hκ).mp
  have hc₁ : κ*(V 0/κ) = V 0 := by field_simp
  have hc₂ : κ*(1/(8*κ*κd)) = 1/(8*κd) := by field_simp <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hc₃ : κ*(1/(8*κ*κd)*(∫ t in (0 : ℝ)..T, d t^2)) =
      (∫ t in (0 : ℝ)..T, d t^2)/(8*κd) := by
    rw [←mul_assoc, hc₂]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [mul_add, hc₁, hc₃]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hi]

end
end ChainFountain
