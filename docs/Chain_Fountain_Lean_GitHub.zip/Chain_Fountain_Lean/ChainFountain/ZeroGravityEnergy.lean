module

public import ChainFountain.ZeroGravityAEReconstruction
public import Mathlib.Analysis.InnerProductSpace.Calculus

@[expose] public section

/-!
# Kinetic energy and power on the exact circulating-loop family

These statements concern the already constructed scalar circulation family.
The power identity is classical where the speed is differentiable and holds
almost everywhere, with an actual integral balance, for locally absolutely
continuous speed. It is not a claim about arbitrary spatial string solutions.
-/
namespace ChainFountain.ZeroGravity
noncomputable section
open Set Filter MeasureTheory

/-- Kinetic energy of a unit-speed loop of length `L` and linear density `lam`. -/
def loopKineticEnergy (lam L c : ℝ) : ℝ := lam * L / 2 * c ^ 2

section Geometry
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- Unit-speed geometry identifies the actual material kinetic-energy density. -/
theorem loop_kinetic_density {R1 : ℝ → E} {lam c θ a : ℝ}
    (hunit : ∀ s, ‖R1 s‖ = 1) :
    lam / 2 * ‖c • R1 (a + θ)‖ ^ 2 = lam / 2 * c ^ 2 := by
  rw [norm_smul, Real.norm_eq_abs, hunit, mul_one, sq_abs]

/-- The spatial kinetic-energy integral of the reconstructed material velocity
is exactly the scalar expression used in the paper. -/
theorem loop_kinetic_integral {R1 : ℝ → E} {lam L c θ : ℝ}
    (hunit : ∀ s, ‖R1 s‖ = 1) :
    (∫ a in (0 : ℝ)..L, lam / 2 * ‖c • R1 (a + θ)‖ ^ 2) =
      loopKineticEnergy lam L c := by
  calc
    (∫ a in (0 : ℝ)..L, lam / 2 * ‖c • R1 (a + θ)‖ ^ 2) =
        ∫ _a in (0 : ℝ)..L, lam / 2 * c ^ 2 := by
      apply intervalIntegral.integral_congr
      intro a _
      exact loop_kinetic_density hunit
    _ = loopKineticEnergy lam L c := by
      rw [intervalIntegral.integral_const]
      simp only [sub_zero, smul_eq_mul, loopKineticEnergy]
      ring

end Geometry

/-- Exact chain rule for the circulation kinetic energy. -/
theorem loopKineticEnergy_hasDerivAt {c : ℝ → ℝ} {lam L acceleration t : ℝ}
    (hc : HasDerivAt c acceleration t) :
    HasDerivAt (fun s => loopKineticEnergy lam L (c s))
      (lam * L * c t * acceleration) t := by
  convert! (hc.pow 2).const_mul (lam * L / 2) using 1
  ring

/-- Classical kinetic-power identity for the actual scalar plant. -/
theorem loop_power_hasDerivAt {c : ℝ → ℝ} {lam L γ u d t : ℝ}
    (hc : HasDerivAt c (u - γ * c t + d) t) :
    HasDerivAt (fun s => loopKineticEnergy lam L (c s))
      (lam * L * c t * (u - γ * c t + d)) t :=
  loopKineticEnergy_hasDerivAt hc

/-- Kinetic energy remains absolutely continuous on each interval where speed is. -/
theorem loopKineticEnergy_ac {c : ℝ → ℝ} {lam L a b : ℝ}
    (hc : AbsolutelyContinuousOnInterval c a b) :
    AbsolutelyContinuousOnInterval (fun t => loopKineticEnergy lam L (c t)) a b := by
  simpa [loopKineticEnergy, pow_two] using
    (hc.fun_mul hc).const_mul (lam * L / 2)

/-- The power identity for measurable forcing, on a common full-measure set. -/
theorem loop_power_ae {c u d : ℝ → ℝ} {lam L γ : ℝ}
    (hc : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c (u t - γ * c t + d t) t) :
    ∀ᵐ t ∂volume, 0 ≤ t →
      HasDerivAt (fun s => loopKineticEnergy lam L (c s))
        (lam * L * c t * (u t - γ * c t + d t)) t := by
  filter_upwards [hc] with t ht hpos
  exact loop_power_hasDerivAt (ht hpos)

/-- Genuine integral energy balance. Integrability of power is a conclusion
of absolute continuity and the almost-everywhere plant equation. -/
theorem loop_power_integral {c u d : ℝ → ℝ} {lam L γ T : ℝ}
    (hT : 0 ≤ T) (hcAC : AbsolutelyContinuousOnInterval c 0 T)
    (hc : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c (u t - γ * c t + d t) t) :
    IntervalIntegrable (fun t => lam * L * c t * (u t - γ * c t + d t)) volume 0 T ∧
      (∫ t in (0 : ℝ)..T, lam * L * c t * (u t - γ * c t + d t)) =
        loopKineticEnergy lam L (c T) - loopKineticEnergy lam L (c 0) := by
  have hd : ∀ᵐ t ∂volume, t ∈ uIcc (0 : ℝ) T →
      HasDerivAt (fun s => loopKineticEnergy lam L (c s))
        (lam * L * c t * (u t - γ * c t + d t)) t := by
    filter_upwards [loop_power_ae (lam := lam) (L := L) hc] with t ht hmem
    rw [uIcc_of_le hT] at hmem
    exact ht hmem.1
  exact ChainFountain.ac_integral_eq_sub (loopKineticEnergy_ac hcAC) hd

/-- Explicit separation of drive, drag loss, and disturbance power. -/
theorem loop_power_split (lam L c u γ d : ℝ) :
    lam * L * c * (u - γ * c + d) =
      lam * L * c * u - lam * L * γ * c ^ 2 + lam * L * c * d := by ring

theorem loop_drag_dissipation {lam L γ c : ℝ}
    (hlam : 0 ≤ lam) (hL : 0 ≤ L) (hγ : 0 ≤ γ) :
    0 ≤ lam * L * γ * c ^ 2 := by positivity

section SpatialPower
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]
open scoped RealInnerProductSpace

/-- Differentiating the unit-speed condition proves tangent/curvature
orthogonality; it is not an additional mechanical hypothesis. -/
theorem loop_tangent_curvature_orthogonal {R1 : ℝ → E} {R2 : E} {a : ℝ}
    (hunit : ∀ s, ‖R1 s‖ = 1) (hR1 : HasDerivAt R1 R2 a) :
    ⟪R1 a, R2⟫ = 0 := by
  have he : (fun s => ‖R1 s‖ ^ 2) = (fun _ : ℝ => (1 : ℝ)) := by
    funext s
    simp only [hunit, one_pow]
  have hd := hR1.norm_sq
  change HasDerivAt (fun s => ‖R1 s‖ ^ 2) (2 * ⟪R1 a, R2⟫) a at hd
  rw [he] at hd
  have hz := hd.unique (hasDerivAt_const a (1 : ℝ))
  linarith

/-- On the circulation family the actual spatial tension-force derivative
is normal to the material velocity and hence has zero power density. -/
theorem loop_tension_power_density {R1 : ℝ → E} {R2 : E}
    {lam c θ a : ℝ} (hunit : ∀ s, ‖R1 s‖ = 1)
    (hR1 : HasDerivAt R1 R2 (a + θ)) :
    ⟪deriv (fun b => (lam * c ^ 2) • R1 (b + θ)) a,
      c • R1 (a + θ)⟫ = 0 := by
  have hd : HasDerivAt (fun b => (lam * c ^ 2) • R1 (b + θ))
      ((lam * c ^ 2) • R2) a := by
    simpa only [Function.comp_def, id_eq, one_smul, Pi.smul_apply] using!
      ((hR1.scomp a ((hasDerivAt_id a).add_const θ)).const_smul (lam * c ^ 2))
  rw [hd.deriv, real_inner_smul_left, real_inner_smul_right,
    real_inner_comm (R1 (a + θ)) R2,
    loop_tangent_curvature_orthogonal hunit hR1]
  ring

/-- The internal tension power is genuinely integrable and its spatial
integral is zero because its density vanishes at every material label. -/
theorem loop_tension_power_integral {R1 R2 : ℝ → E} {lam L c θ : ℝ}
    (hunit : ∀ s, ‖R1 s‖ = 1) (hR1 : ∀ s, HasDerivAt R1 (R2 s) s) :
    IntervalIntegrable
      (fun a => ⟪deriv (fun b => (lam * c ^ 2) • R1 (b + θ)) a,
        c • R1 (a + θ)⟫) volume 0 L ∧
    (∫ a in (0 : ℝ)..L,
      ⟪deriv (fun b => (lam * c ^ 2) • R1 (b + θ)) a,
        c • R1 (a + θ)⟫) = 0 := by
  have he : (fun a => ⟪deriv (fun b => (lam * c ^ 2) • R1 (b + θ)) a,
      c • R1 (a + θ)⟫) = (fun _ : ℝ => (0 : ℝ)) := by
    funext a
    exact loop_tension_power_density hunit (hR1 (a + θ))
  rw [he]
  exact ⟨intervalIntegrable_const, by simp⟩

/-- The actual spatial external force dotted with the actual material time
derivative has the scalar power density used in the energy equation. -/
theorem loop_external_power_density {R R1 : ℝ → E} {θ : ℝ → ℝ}
    {lam acceleration c a t : ℝ} (hunit : ∀ s, ‖R1 s‖ = 1)
    (hR : ∀ s, HasDerivAt R (R1 s) s) (hθ : HasDerivAt θ c t) :
    ⟪(lam * acceleration) • R1 (a + θ t),
      deriv (fun s => R (a + θ s)) t⟫ = lam * c * acceleration := by
  rw [(loop_position_hasDerivAt (hR _) hθ).deriv,
    real_inner_smul_left, real_inner_smul_right, real_inner_self_eq_norm_sq,
    hunit, one_pow]
  ring

/-- Actual external-force power is an integrable spatial quantity, and its
integral agrees with density times loop length times speed times acceleration. -/
theorem loop_external_power_integral {R R1 : ℝ → E} {θ : ℝ → ℝ}
    {lam L acceleration c t : ℝ} (hunit : ∀ s, ‖R1 s‖ = 1)
    (hR : ∀ s, HasDerivAt R (R1 s) s) (hθ : HasDerivAt θ c t) :
    IntervalIntegrable
      (fun a => ⟪(lam * acceleration) • R1 (a + θ t),
        deriv (fun s => R (a + θ s)) t⟫) volume 0 L ∧
    (∫ a in (0 : ℝ)..L, ⟪(lam * acceleration) • R1 (a + θ t),
        deriv (fun s => R (a + θ s)) t⟫) = lam * L * c * acceleration := by
  have he : (fun a => ⟪(lam * acceleration) • R1 (a + θ t),
      deriv (fun s => R (a + θ s)) t⟫) =
      (fun _ : ℝ => lam * c * acceleration) := by
    funext a
    exact loop_external_power_density hunit hR hθ
  rw [he]
  refine ⟨intervalIntegrable_const, ?_⟩
  rw [intervalIntegral.integral_const]
  simp only [sub_zero, smul_eq_mul]
  ring

/-- The scalar energy derivative equals the actual spatial external-force
power integral; the actual spatial tension-force power is integrable and zero. -/
theorem loop_spatial_power_balance {R R1 R2 : ℝ → E} {θ c : ℝ → ℝ}
    {lam L γ u d t : ℝ} (hunit : ∀ s, ‖R1 s‖ = 1)
    (hR : ∀ s, HasDerivAt R (R1 s) s)
    (hR1 : ∀ s, HasDerivAt R1 (R2 s) s)
    (hθ : HasDerivAt θ (c t) t)
    (hc : HasDerivAt c (u - γ * c t + d) t) :
    IntervalIntegrable
      (fun a => ⟪(lam * (u - γ * c t + d)) • R1 (a + θ t),
        deriv (fun s => R (a + θ s)) t⟫) volume 0 L ∧
    HasDerivAt (fun s => loopKineticEnergy lam L (c s))
      (∫ a in (0 : ℝ)..L,
        ⟪(lam * (u - γ * c t + d)) • R1 (a + θ t),
          deriv (fun s => R (a + θ s)) t⟫) t ∧
    IntervalIntegrable
      (fun a => ⟪deriv (fun b => (lam * (c t) ^ 2) • R1 (b + θ t)) a,
        (c t) • R1 (a + θ t)⟫) volume 0 L ∧
    (∫ a in (0 : ℝ)..L,
      ⟪deriv (fun b => (lam * (c t) ^ 2) • R1 (b + θ t)) a,
        (c t) • R1 (a + θ t)⟫) = 0 := by
  have he := loop_external_power_integral (L := L) (lam := lam)
    (acceleration := u - γ * c t + d) hunit hR hθ
  refine ⟨he.1, ?_, loop_tension_power_integral hunit hR1⟩
  rw [he.2]
  exact loop_power_hasDerivAt hc

end SpatialPower

section ConstructedLoop
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

/-- The exact AC loop already constructed from initial data satisfies the
integral energy balance with its actual feedback command. -/
theorem AECirculatingLoop.energy_balance
    {R : ℝ → E} {r rdot d c : ℝ → ℝ} {γ k lam L c0 θ0 T : ℝ}
    (hloop : AECirculatingLoop R r rdot d γ k lam L c0 θ0 c) (hT : 0 ≤ T) :
    IntervalIntegrable
      (fun t => lam * L * c t *
        (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t)) volume 0 T ∧
      (∫ t in (0 : ℝ)..T, lam * L * c t *
        (circulationCommand γ k (r t) (rdot t) (c t) - γ * c t + d t)) =
        loopKineticEnergy lam L (c T) - loopKineticEnergy lam L c0 := by
  simpa only [hloop.speed_initial] using
    loop_power_integral hT (hloop.speed_locallyAC T hT) hloop.plant_ae

end ConstructedLoop

end
end ChainFountain.ZeroGravity
