module

public import ChainFountain.ZeroGravityACBounds
public import Mathlib.Topology.MetricSpace.HausdorffDistance
public import Mathlib.Algebra.Field.Periodic
public import Mathlib.Analysis.InnerProductSpace.Continuous
public import Mathlib.Analysis.Normed.Module.RCLike.Real
public import Mathlib.Analysis.Calculus.ContDiff.Operations

@[expose] public section

/-!
# The scalar circulation regulator cannot select a spatial geometry

Shapes are actual spatial images, not parameterized curves. Their discrepancy
is the usual Hausdorff distance between nonempty compact subsets of the ambient
metric space. A phase shift of the material labels preserves that image exactly.
Thus a solution on the circulation family approaches a prescribed compact shape
in Hausdorff distance if and only if it already has that spatial image.

The final theorem connects this geometric obstruction to the actual a.e.
closed-loop speed equation and its unrestricted locally-AC uniqueness theorem.
It makes no transverse-stability assertion. The existence of two particular
geometrically distinct curves, or their membership in a specified small
neighborhood modulo rigid motions, is not an assumption hidden in a metric.
-/

namespace ChainFountain.ZeroGravity
noncomputable section
open Set Filter MeasureTheory
open scoped Topology

/-- The spatial image of a material-phase-shifted curve. -/
def circulationShape {E : Type*} (R : ℝ → E) (θ : ℝ → ℝ) (t : ℝ) : Set E :=
  Set.range (fun a => R (a + θ t))

/-- Translating all material labels is surjective; it never changes the
spatial image. This does not require any smoothness or periodicity. -/
theorem circulation_shape_eq_range {E : Type*} (R : ℝ → E)
    (θ : ℝ → ℝ) (t : ℝ) : circulationShape R θ t = Set.range R := by
  ext x
  constructor
  · rintro ⟨a, ha⟩
    exact ⟨a + θ t, ha⟩
  · rintro ⟨a, ha⟩
    refine ⟨a - θ t, ?_⟩
    simpa only [sub_add_cancel] using ha

/-- A continuous periodic curve has compact spatial image, with no assumed
compactness of the whole real parameter domain. -/
theorem periodic_curve_range_compact {E : Type*} [TopologicalSpace E]
    {R : ℝ → E} {L : ℝ} (hR : Continuous R)
    (hperiod : Function.Periodic R L) (hL : 0 < L) :
    IsCompact (Set.range R) := by
  rw [← hperiod.image_Icc hL 0]
  exact isCompact_Icc.image hR

section HausdorffObstruction
variable {E : Type*} [MetricSpace E]

/-- The Hausdorff error to a fixed target is constant along every exact-family
motion, regardless of its speed history or material phase. -/
theorem circulation_shape_distance_constant (R : ℝ → E) (θ : ℝ → ℝ)
    (S : Set E) (t : ℝ) :
    Metric.hausdorffDist (circulationShape R θ t) S =
      Metric.hausdorffDist (Set.range R) S := by
  rw [circulation_shape_eq_range]

/-- Distinct nonempty compact spatial images have a strictly positive
Hausdorff discrepancy. The finiteness condition is derived from compactness. -/
theorem compact_shape_distance_pos {S Q : Set E}
    (hS : IsCompact S) (hQ : IsCompact Q)
    (hneS : S.Nonempty) (hneQ : Q.Nonempty) (hne : S ≠ Q) :
    0 < Metric.hausdorffDist S Q := by
  have hfin : Metric.hausdorffEDist S Q ≠ ⊤ :=
    Metric.hausdorffEDist_ne_top_of_nonempty_of_bounded hneS hneQ
      hS.isBounded hQ.isBounded
  have hn : Metric.hausdorffDist S Q ≠ 0 := by
    intro hz
    exact hne ((hS.isClosed.hausdorffDist_zero_iff_eq hQ.isClosed hfin).mp hz)
  exact lt_of_le_of_ne Metric.hausdorffDist_nonneg (Ne.symm hn)

/-- Exact characterization of attraction to a fixed compact spatial image.
The limit is the ordinary real limit of the actual Hausdorff distance. -/
theorem circulation_shape_attracted_iff {R : ℝ → E} {θ : ℝ → ℝ}
    {S : Set E} (hR : IsCompact (Set.range R)) (hS : IsCompact S)
    (hneS : S.Nonempty) :
    Tendsto (fun t : ℝ => Metric.hausdorffDist (circulationShape R θ t) S)
      atTop (𝓝 0) ↔ Set.range R = S := by
  have hneR : (Set.range R).Nonempty := ⟨R 0, ⟨0, rfl⟩⟩
  have hfin : Metric.hausdorffEDist (Set.range R) S ≠ ⊤ :=
    Metric.hausdorffEDist_ne_top_of_nonempty_of_bounded hneR hneS
      hR.isBounded hS.isBounded
  constructor
  · intro hlim
    simp only [circulation_shape_distance_constant] at hlim
    have hz : Metric.hausdorffDist (Set.range R) S = 0 :=
      tendsto_nhds_unique tendsto_const_nhds hlim
    exact (hR.isClosed.hausdorffDist_zero_iff_eq hS.isClosed hfin).mp hz
  · intro heq
    simp only [circulation_shape_distance_constant, heq,
      Metric.hausdorffDist_self_zero]
    exact tendsto_const_nhds

/-- A continuous closed curve different from a prescribed compact target never
converges to that target, even when its circulation speed tracks perfectly. -/
theorem periodic_circulation_not_shape_attracted {R : ℝ → E} {θ : ℝ → ℝ}
    {L : ℝ} {S : Set E} (hR : Continuous R)
    (hperiod : Function.Periodic R L) (hL : 0 < L)
    (hS : IsCompact S) (hneS : S.Nonempty) (hne : Set.range R ≠ S) :
    ¬ Tendsto (fun t : ℝ => Metric.hausdorffDist (circulationShape R θ t) S)
      atTop (𝓝 0) := by
  intro hlim
  exact hne ((circulation_shape_attracted_iff
    (periodic_curve_range_compact hR hperiod hL) hS hneS).mp hlim)

/-- Two distinct closed curves cannot both approach one fixed compact spatial
image under any choices of phase histories. -/
theorem two_circulation_shapes_no_common_attractor
    {R₁ R₂ : ℝ → E} {θ₁ θ₂ : ℝ → ℝ} {L : ℝ} {S : Set E}
    (hR₁ : Continuous R₁) (hR₂ : Continuous R₂)
    (hp₁ : Function.Periodic R₁ L) (hp₂ : Function.Periodic R₂ L)
    (hL : 0 < L) (hne : Set.range R₁ ≠ Set.range R₂)
    (hS : IsCompact S) (hneS : S.Nonempty) :
    ¬ (Tendsto (fun t : ℝ => Metric.hausdorffDist (circulationShape R₁ θ₁ t) S)
        atTop (𝓝 0) ∧
      Tendsto (fun t : ℝ => Metric.hausdorffDist (circulationShape R₂ θ₂ t) S)
        atTop (𝓝 0)) := by
  rintro ⟨h₁, h₂⟩
  have he₁ := (circulation_shape_attracted_iff
    (periodic_curve_range_compact hR₁ hp₁ hL) hS hneS).mp h₁
  have he₂ := (circulation_shape_attracted_iff
    (periodic_curve_range_compact hR₂ hp₂ hL) hS hneS).mp h₂
  exact hne (he₁.trans he₂.symm)

/-- The geometric images remain separated by one fixed positive distance. -/
theorem two_circulation_shapes_uniformly_separated
    {R₁ R₂ : ℝ → E} (θ₁ θ₂ : ℝ → ℝ) {L : ℝ}
    (hR₁ : Continuous R₁) (hR₂ : Continuous R₂)
    (hp₁ : Function.Periodic R₁ L) (hp₂ : Function.Periodic R₂ L)
    (hL : 0 < L) (hne : Set.range R₁ ≠ Set.range R₂) :
    ∃ ε : ℝ, 0 < ε ∧ ∀ t : ℝ,
      Metric.hausdorffDist (circulationShape R₁ θ₁ t)
        (circulationShape R₂ θ₂ t) = ε := by
  refine ⟨Metric.hausdorffDist (Set.range R₁) (Set.range R₂), ?_, ?_⟩
  · exact compact_shape_distance_pos
      (periodic_curve_range_compact hR₁ hp₁ hL)
      (periodic_curve_range_compact hR₂ hp₂ hL)
      ⟨R₁ 0, ⟨0, rfl⟩⟩ ⟨R₂ 0, ⟨0, rfl⟩⟩ hne
  · intro t
    rw [circulation_shape_eq_range, circulation_shape_eq_range]

/-- Same reference, disturbance and initial speed give indistinguishable speed
outputs, while different compact geometries remain a positive distance apart.
This uses the actual feedback plant a.e. and genuine local absolute continuity;
neither equal trajectories nor their integral representations are assumed. -/
theorem circulation_speed_shape_obstruction
    {R₁ R₂ : ℝ → E} (θ₁ θ₂ : ℝ → ℝ) {L : ℝ}
    (hR₁ : Continuous R₁) (hR₂ : Continuous R₂)
    (hp₁ : Function.Periodic R₁ L) (hp₂ : Function.Periodic R₂ L)
    (hL : 0 < L) (hne : Set.range R₁ ≠ Set.range R₂)
    {c₁ c₂ r rdot d : ℝ → ℝ} {γ k : ℝ}
    (hinit : c₁ 0 = c₂ 0)
    (hc₁ : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c₁ 0 T)
    (hc₂ : ∀ T ≥ 0, AbsolutelyContinuousOnInterval c₂ 0 T)
    (hrAC : ∀ T ≥ 0, AbsolutelyContinuousOnInterval r 0 T)
    (hd₁ : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c₁
      (circulationCommand γ k (r t) (rdot t) (c₁ t) - γ * c₁ t + d t) t)
    (hd₂ : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt c₂
      (circulationCommand γ k (r t) (rdot t) (c₂ t) - γ * c₂ t + d t) t)
    (hr : ∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt r (rdot t) t) :
    (∀ t ≥ 0, c₁ t = c₂ t) ∧
      ∃ ε : ℝ, 0 < ε ∧ ∀ t : ℝ,
        Metric.hausdorffDist (circulationShape R₁ θ₁ t)
          (circulationShape R₂ θ₂ t) = ε := by
  exact ⟨circulation_ac_closedLoop_unique hinit hc₁ hc₂ hrAC hd₁ hd₂ hr,
    two_circulation_shapes_uniformly_separated θ₁ θ₂ hR₁ hR₂ hp₁ hp₂ hL hne⟩

end HausdorffObstruction

section NearbyFixedFrameShapes
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

/-- Translating a nonempty compact curve by a nonzero vector changes its
spatial image. A maximum of the linear functional in that vector's direction
rules out translation invariance. -/
theorem translated_compact_curve_range_ne {R : ℝ → E} {v : E}
    (hR : IsCompact (Set.range R)) (hv : v ≠ 0) :
    Set.range (fun a => R a + v) ≠ Set.range R := by
  intro heq
  obtain ⟨x, hx, hmax⟩ := hR.exists_isMaxOn
    (show (Set.range R).Nonempty from ⟨R 0, ⟨0, rfl⟩⟩)
    (show ContinuousOn (fun x : E => inner ℝ v x) (Set.range R) from
      (continuous_const.inner continuous_id).continuousOn)
  have hxv : x + v ∈ Set.range R := by
    rw [← heq]
    obtain ⟨a, rfl⟩ := hx
    exact ⟨a, rfl⟩
  have hineq := hmax hxv
  change inner ℝ v (x + v) ≤ inner ℝ v x at hineq
  simp only [inner_add_right, real_inner_self_eq_norm_sq] at hineq
  have hpos : 0 < ‖v‖ ^ 2 := sq_pos_of_pos (norm_pos_iff.mpr hv)
  linarith

omit [InnerProductSpace ℝ E] in
/-- Translation by v changes a curve's Hausdorff image by at most ‖v‖. -/
theorem translated_curve_hausdorff_le (R : ℝ → E) (v : E) :
    Metric.hausdorffDist (Set.range (fun a => R a + v)) (Set.range R) ≤ ‖v‖ := by
  apply Metric.hausdorffDist_le_of_mem_dist (norm_nonneg v)
  · rintro x ⟨a, rfl⟩
    refine ⟨R a, ⟨a, rfl⟩, ?_⟩
    simp [dist_eq_norm]
  · rintro x ⟨a, rfl⟩
    refine ⟨R a + v, ⟨a, rfl⟩, ?_⟩
    rw [dist_comm]
    simp [dist_eq_norm]

/-- Arbitrarily close distinct closed curves exist in a fixed spatial frame.
The example is a translation: it preserves every material derivative, the
period, and C² regularity. Thus unit speed, total length and inextensibility
are preserved whenever the original curve has them. This is deliberately
not a claim about geometric shapes modulo translations or rigid motions. -/
theorem nearby_distinct_periodic_curve [Nontrivial E]
    {R : ℝ → E} {L ε : ℝ} (hR : ContDiff ℝ 2 R)
    (hperiod : Function.Periodic R L) (hL : 0 < L) (hε : 0 < ε) :
    ∃ Q : ℝ → E, ContDiff ℝ 2 Q ∧ Function.Periodic Q L ∧
      (∀ a : ℝ, deriv Q a = deriv R a) ∧
      Set.range Q ≠ Set.range R ∧
      Metric.hausdorffDist (Set.range Q) (Set.range R) < ε := by
  obtain ⟨v, hv⟩ := exists_norm_eq E (show 0 ≤ ε / 2 by linarith)
  have hvne : v ≠ 0 := by
    intro hz
    simp only [hz, norm_zero] at hv
    linarith
  refine ⟨fun a => R a + v, hR.add contDiff_const, ?_, ?_, ?_, ?_⟩
  · intro a
    change R (a + L) + v = R a + v
    rw [hperiod a]
  · intro a
    exact deriv_add_const v
  · exact translated_compact_curve_range_ne
      (periodic_curve_range_compact hR.continuous hperiod hL) hvne
  · exact (translated_curve_hausdorff_le R v).trans_lt (by rw [hv]; linarith)

/-- Every positive Hausdorff neighborhood contains a same-period, same-length
translation whose exact-family motion does not approach the original spatial
image. This is a local non-attraction statement in a fixed spatial frame. -/
theorem arbitrarily_close_nonattracting_circulation [Nontrivial E]
    {R : ℝ → E} (θ : ℝ → ℝ) {L ε : ℝ} (hR : ContDiff ℝ 2 R)
    (hperiod : Function.Periodic R L) (hL : 0 < L) (hε : 0 < ε) :
    ∃ Q : ℝ → E, ContDiff ℝ 2 Q ∧ Function.Periodic Q L ∧
      (∀ a : ℝ, deriv Q a = deriv R a) ∧
      Metric.hausdorffDist (circulationShape Q θ 0) (Set.range R) < ε ∧
      ¬ Tendsto (fun t : ℝ =>
          Metric.hausdorffDist (circulationShape Q θ t) (Set.range R))
        atTop (𝓝 0) := by
  obtain ⟨Q, hQ, hp, hder, hne, hdist⟩ :=
    nearby_distinct_periodic_curve hR hperiod hL hε
  refine ⟨Q, hQ, hp, hder, ?_, ?_⟩
  · simpa only [circulation_shape_distance_constant] using hdist
  · exact periodic_circulation_not_shape_attracted hQ.continuous hp hL
      (periodic_curve_range_compact hR.continuous hperiod hL)
      ⟨R 0, ⟨0, rfl⟩⟩ hne

end NearbyFixedFrameShapes

end
end ChainFountain.ZeroGravity
