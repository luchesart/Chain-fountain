module

public import ChainFountain.Model

@[expose] public section

namespace ChainFountain
noncomputable section
open Real

def quintic (x : ℝ) := 10*x^3-15*x^4+6*x^5
def quinticRate (x : ℝ) := 30*x^2*(1-x)^2
def quinticAcceleration (x : ℝ) := 60*x*(1-x)*(1-2*x)

theorem quintic_derivative (x : ℝ) : HasDerivAt quintic (quinticRate x) x := by
  convert! (((hasDerivAt_id x).pow 3).const_mul 10).sub
    (((hasDerivAt_id x).pow 4).const_mul 15) |>.add
    (((hasDerivAt_id x).pow 5).const_mul 6) using 1
  simp only [id_eq]; unfold quinticRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> ring

theorem quintic_second_derivative (x : ℝ) :
    HasDerivAt quinticRate (quinticAcceleration x) x := by
  convert! (((hasDerivAt_id x).pow 2).const_mul 30).mul
    (((hasDerivAt_id x).const_sub 1).pow 2) using 1
  simp only [id_eq]; unfold quinticAcceleration; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> ring

theorem quintic_endpoint_data :
    quintic 0=0 ∧ quintic 1=1 ∧ quinticRate 0=0 ∧ quinticRate 1=0 ∧
      quinticAcceleration 0=0 ∧ quinticAcceleration 1=0 := by
  norm_num [quintic,quinticRate,quinticAcceleration]

theorem quintic_rate_bound {x : ℝ} (hx : 0 ≤ x ∧ x ≤ 1) :
    |quinticRate x| ≤ 15/8 := by
  have hprod : 0 ≤ x*(1-x) := mul_nonneg hx.1 (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> linarith)
  have hprodU : x*(1-x) ≤ 1/4 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> nlinarith [sq_nonneg (x-1/2)]
  have hsq := pow_le_pow_left₀ hprod hprodU 2
  unfold quinticRate
  rw [abs_of_nonneg (by positivity)]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> nlinarith [hsq]

theorem quintic_acceleration_bound {x : ℝ} (hx : 0 ≤ x ∧ x ≤ 1) :
    |quinticAcceleration x| ≤ 10/sqrt 3 := by
  have hy : (1-2*x)^2 ≤ 1 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> nlinarith
  have hpos : 0 ≤ (4/3 : ℝ)-(1-2*x)^2 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> linarith
  have hp : 0 ≤ (225 : ℝ)*(4/3-(1-2*x)^2)*((1-2*x)^2-1/3)^2 := by positivity
  have hi : (100/3 : ℝ)-(quinticAcceleration x)^2 =
      225*(4/3-(1-2*x)^2)*((1-2*x)^2-1/3)^2 := by unfold quinticAcceleration; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> ring
  have hs : (quinticAcceleration x)^2 ≤ 100/3 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> linarith
  have hroot : sqrt (3 : ℝ)^2=3 := sq_sqrt (by norm_num)
  have hroot0 : 0 < sqrt (3 : ℝ) := sqrt_pos.mpr (by norm_num)
  apply (le_div_iff₀ hroot0).mpr
  have habs := sq_abs (quinticAcceleration x)
  have hm := mul_le_mul_of_nonneg_right hs (show 0 ≤ (3 : ℝ) by norm_num)
  have hneg := abs_nonneg (quinticAcceleration x)
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> nlinarith [sq_nonneg (|quinticAcceleration x| * sqrt 3-10)]

end
end ChainFountain
