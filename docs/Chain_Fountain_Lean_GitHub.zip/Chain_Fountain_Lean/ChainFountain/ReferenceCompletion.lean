module

public import ChainFountain.Reference

@[expose] public section

namespace ChainFountain
noncomputable section
open Set Real Filter
open scoped Topology

/-- C1 gluing at a single junction, proved from the two one-sided derivatives. -/
theorem derivative_glue {f g f' g' : ℝ → ℝ} (a : ℝ)
    (hf : ∀ x, HasDerivAt f (f' x) x) (hg : ∀ x, HasDerivAt g (g' x) x)
    (hval : f a=g a) (hslope : f' a=g' a) (x : ℝ) :
    HasDerivAt (fun t => if t ≤ a then f t else g t)
      (if x ≤ a then f' x else g' x) x := by
  rcases lt_trichotomy x a with hlt | he | hgt
  · rw [if_pos hlt.le]
    apply (hf x).congr_of_eventuallyEq
    filter_upwards [eventually_lt_nhds hlt] with t ht
    exact if_pos ht.le
  · subst x
    rw [if_pos le_rfl]
    have hl : HasDerivWithinAt (fun t => if t ≤ a then f t else g t) (f' a) (Iic a) a :=
      (hf a).hasDerivWithinAt.congr (fun t ht => if_pos ht) (if_pos le_rfl)
    have hr : HasDerivWithinAt (fun t => if t ≤ a then f t else g t) (f' a) (Ici a) a := by
      rw [hslope]
      apply (hg a).hasDerivWithinAt.congr
      · intro t ht
        by_cases h : t ≤ a
        · have : t=a := le_antisymm h ht
          simpa [this] using! hval
        · exact if_neg h
      · simpa using! hval
    have hu := hl.union hr
    rw [Iic_union_Ici] at hu
    exact hu.hasDerivAt (by simp)
  · rw [if_neg (not_le.mpr hgt)]
    apply (hg x).congr_of_eventuallyEq
    filter_upwards [eventually_gt_nhds hgt] with t ht
    exact if_neg (not_le.mpr ht)

def cappedQuintic (x : ℝ) := if x ≤ 0 then 0 else if x ≤ 1 then quintic x else 1
def cappedRate (x : ℝ) := if x ≤ 0 then 0 else if x ≤ 1 then quinticRate x else 0
def cappedAcceleration (x : ℝ) := if x ≤ 0 then 0 else if x ≤ 1 then quinticAcceleration x else 0

theorem capped_quintic_derivative (x : ℝ) :
    HasDerivAt cappedQuintic (cappedRate x) x := by
  apply derivative_glue 0 (fun t => hasDerivAt_const t 0)
    (derivative_glue 1 quintic_derivative (fun t => hasDerivAt_const t 1)
      (by norm_num [quintic]) (by norm_num [quinticRate]))
    (by norm_num [quintic]) (by norm_num [quinticRate])

theorem capped_quintic_second_derivative (x : ℝ) :
    HasDerivAt cappedRate (cappedAcceleration x) x := by
  apply derivative_glue 0 (fun t => hasDerivAt_const t 0)
    (derivative_glue 1 quintic_second_derivative (fun t => hasDerivAt_const t 0)
      (by norm_num [quinticRate]) (by norm_num [quinticAcceleration]))
    (by norm_num [quinticRate]) (by norm_num [quinticAcceleration])

theorem capped_acceleration_continuous : Continuous cappedAcceleration := by
  have hp : Continuous quinticAcceleration := by unfold quinticAcceleration; fun_prop
  have hinner : Continuous (fun x : ℝ => if x ≤ 1 then quinticAcceleration x else 0) := by
    apply Continuous.if _ hp continuous_const
    intro x hx
    have : x=1 := by simpa only [show {x : ℝ | x ≤ 1}=Iic 1 from rfl,frontier_Iic,mem_singleton_iff] using! hx
    simp [this,quinticAcceleration]
  apply Continuous.if _ continuous_const hinner
  intro x hx
  have : x=0 := by simpa only [show {x : ℝ | x ≤ 0}=Iic 0 from rfl,frontier_Iic,mem_singleton_iff] using! hx
  simp [this,quinticAcceleration]

/-- The constant extension is genuinely C2 across both junctions. -/
theorem capped_quintic_C2 : ContDiff ℝ 2 cappedQuintic := by
  have hd : deriv cappedQuintic=cappedRate := funext (fun x => (capped_quintic_derivative x).deriv)
  have hdd : deriv cappedRate=cappedAcceleration := funext (fun x => (capped_quintic_second_derivative x).deriv)
  rw [show (2 : WithTop ℕ∞)=1+1 from rfl,contDiff_succ_iff_deriv]
  refine ⟨fun x => (capped_quintic_derivative x).differentiableAt,by norm_num,?_⟩
  rw [hd,contDiff_one_iff_deriv,hdd]
  exact ⟨fun x => (capped_quintic_second_derivative x).differentiableAt,capped_acceleration_continuous⟩

theorem capped_quintic_bounds (x : ℝ) :
    |cappedRate x| ≤ 15/8 ∧ |cappedAcceleration x| ≤ 10/sqrt 3 := by
  by_cases hx : x ≤ 0
  · norm_num [cappedRate,cappedAcceleration,hx]; positivity
  · by_cases hx1 : x ≤ 1
    · simpa [cappedRate,cappedAcceleration,hx,hx1] using!
        And.intro (quintic_rate_bound ⟨(lt_of_not_ge hx).le,hx1⟩)
          (quintic_acceleration_bound ⟨(lt_of_not_ge hx).le,hx1⟩)
    · norm_num [cappedRate,cappedAcceleration,hx,hx1]; positivity

def transition (r₀ r₁ T t : ℝ) := r₀+(r₁-r₀)*cappedQuintic (t/T)

theorem transition_C2 (r₀ r₁ T : ℝ) : ContDiff ℝ 2 (transition r₀ r₁ T) := by
  unfold transition
  exact contDiff_const.add (contDiff_const.mul (capped_quintic_C2.comp (contDiff_id.div_const T)))

theorem transition_derivatives (r₀ r₁ T t : ℝ) :
    HasDerivAt (transition r₀ r₁ T) ((r₁-r₀)*cappedRate (t/T)/T) t ∧
    HasDerivAt (fun s => (r₁-r₀)*cappedRate (s/T)/T)
      ((r₁-r₀)*cappedAcceleration (t/T)/T^2) t := by
  constructor
  · convert! (((capped_quintic_derivative (t/T)).comp t ((hasDerivAt_id t).div_const T)).const_mul (r₁-r₀)).const_add r₀ using 1 <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  · convert! (((capped_quintic_second_derivative (t/T)).comp t ((hasDerivAt_id t).div_const T)).const_mul (r₁-r₀)).div_const T using 1 <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem transition_rate_bounds {r₀ r₁ T : ℝ} (hT : 0 < T) (t : ℝ) :
    |(r₁-r₀)*cappedRate (t/T)/T| ≤ (15/8)*|r₁-r₀|/T ∧
    |(r₁-r₀)*cappedAcceleration (t/T)/T^2| ≤ (10/sqrt 3)*|r₁-r₀|/T^2 := by
  obtain ⟨h₁,h₂⟩ := capped_quintic_bounds (t/T)
  simp only [abs_div,abs_mul,abs_of_pos hT,abs_of_nonneg (sq_nonneg T)]
  constructor
  · apply div_le_div_of_nonneg_right _ hT.le
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_le_mul_of_nonneg_left h₁ (abs_nonneg (r₁-r₀))]
  · apply div_le_div_of_nonneg_right _ (sq_nonneg T)
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_le_mul_of_nonneg_left h₂ (abs_nonneg (r₁-r₀))]

theorem transition_endpoints {r₀ r₁ T t : ℝ} (hT : 0 < T) :
    (t ≤ 0 → transition r₀ r₁ T t=r₀) ∧ (T ≤ t → transition r₀ r₁ T t=r₁) := by
  constructor
  · intro ht
    simp [transition,cappedQuintic,div_nonpos_of_nonpos_of_nonneg ht hT.le]
  · intro ht
    have hq : 1 ≤ t/T := (le_div_iff₀ hT).mpr (by simpa using! ht)
    by_cases he : t/T=1
    · norm_num [transition,cappedQuintic,he,quintic]
    · have hgt : 1 < t/T := lt_of_le_of_ne hq (Ne.symm he)
      simp [transition,cappedQuintic,show ¬t/T ≤ 0 by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith,not_le.mpr hgt]

end
end ChainFountain
