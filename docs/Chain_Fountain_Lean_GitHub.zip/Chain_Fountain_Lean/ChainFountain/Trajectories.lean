module

public import ChainFountain.Invariance
public import ChainFountain.Forces

@[expose] public section

namespace ChainFountain
noncomputable section
open Set Real

def heightError (h r : ℝ → ℝ) (t : ℝ) := h t-r t
def velocityError (k₁ : ℝ) (h v w r r₁ : ℝ → ℝ) (t : ℝ) :=
  v t-w t-2*r₁ t+2*k₁*(h t-r t)
def requestedInput (H g α β k₀ k₁ k₂ κd : ℝ)
    (h v w r r₁ r₂ : ℝ → ℝ) (t : ℝ) :=
  robustInput H g α β (h t) (v t) (w t)
    (acceleration k₀ k₁ k₂ (heightError h r t) (heightRate (v t) (w t)) (r₁ t) (r₂ t))
    κd (velocityError k₁ h v w r r₁ t)

/-- The coordinate change is proved using derivatives of the mechanical states,
not imposed as an independent error-system axiom. -/
theorem closed_loop_error_equations {H g α β k₀ k₁ k₂ κd d t : ℝ}
    {h v w r r₁ r₂ : ℝ → ℝ}
    (hh : h t ≠ 0) (hH : H+h t ≠ 0)
    (dh : HasDerivAt h (heightRate (v t) (w t)) t)
    (dv : HasDerivAt v (rise g (α+d) (h t) (v t) (w t)
      (requestedInput H g α β k₀ k₁ k₂ κd h v w r r₁ r₂ t)) t)
    (dw : HasDerivAt w (fall H g β (h t) (v t) (w t)) t)
    (dr : HasDerivAt r (r₁ t) t) (dr₁ : HasDerivAt r₁ (r₂ t) t) :
    HasDerivAt (heightError h r)
      (errorRate k₁ (heightError h r t) (velocityError k₁ h v w r r₁ t)) t ∧
    HasDerivAt (velocityError k₁ h v w r r₁)
      (zRate k₀ k₂ κd ((v t)^2/h t) d (heightError h r t)
        (velocityError k₁ h v w r r₁ t)) t := by
  have he : HasDerivAt (heightError h r) (heightRate (v t) (w t)-r₁ t) t := dh.sub dr
  refine ⟨?_, ?_⟩
  · convert! he using 1
    exact (transformed_error_rate k₁ (h t) (r t) (v t) (w t) (r₁ t)).symm
  · have hz := ((dv.sub dw).sub (dr₁.const_mul 2)).add (he.const_mul (2*k₁))
    have ha := robust_acceleration H g α β (h t) (v t) (w t)
      (acceleration k₀ k₁ k₂ (heightError h r t) (heightRate (v t) (w t)) (r₁ t) (r₂ t))
      κd (velocityError k₁ h v w r r₁ t) d hh hH
    have heq : velocityError k₁ h v w r r₁ t =
        2*(heightRate (v t) (w t)-r₁ t+k₁*heightError h r t) := by
      unfold velocityError heightRate heightError; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    have halg := transformed_z_rate k₀ k₁ k₂ (heightError h r t)
      (heightRate (v t) (w t)) (r₁ t) (r₂ t) κd ((v t)^2/h t) d
      (velocityError k₁ h v w r r₁ t) heq
    convert! hz using 1
    unfold requestedInput
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [ha,halg]

/-- Theorem 7.1's tracking estimate starting from the actual controlled ODE.
Existence and differentiability on the stated interval are explicit hypotheses. -/
theorem mechanical_tracking_estimate {H g α β k₀ k₁ k₂ κ κd dbar T : ℝ}
    {h v w r r₁ r₂ d : ℝ → ℝ}
    (hk₀ : 0 ≤ k₀) (hκ : 0 < κ) (hk₁ : κ ≤ k₁) (hk₂ : κ ≤ k₂) (hκd : 0 < κd)
    (hh : ∀ t ∈ Icc 0 T, h t ≠ 0) (hH : ∀ t ∈ Icc 0 T, H+h t ≠ 0)
    (dh : ∀ t ∈ Icc 0 T, HasDerivAt h (heightRate (v t) (w t)) t)
    (dv : ∀ t ∈ Icc 0 T, HasDerivAt v (rise g (α+d t) (h t) (v t) (w t)
      (requestedInput H g α β k₀ k₁ k₂ κd h v w r r₁ r₂ t)) t)
    (dw : ∀ t ∈ Icc 0 T, HasDerivAt w (fall H g β (h t) (v t) (w t)) t)
    (dr : ∀ t ∈ Icc 0 T, HasDerivAt r (r₁ t) t)
    (dr₁ : ∀ t ∈ Icc 0 T, HasDerivAt r₁ (r₂ t) t)
    (hdb : ∀ t ∈ Ico 0 T, |d t| ≤ dbar) :
    ∀ t ∈ Icc 0 T,
      errorEnergy k₀ (heightError h r t) (velocityError k₁ h v w r r₁ t) ≤
      exp (-2*κ*t) * errorEnergy k₀ (heightError h r 0) (velocityError k₁ h v w r r₁ 0) +
        dbar^2/(16*κ*κd)*(1-exp (-2*κ*t)) := by
  have heq := fun t ht => closed_loop_error_equations (hh t ht) (hH t ht)
    (dh t ht) (dv t ht) (dw t ht) (dr t ht) (dr₁ t ht)
  exact robust_error_estimate hk₀ hκ hk₁ hk₂ hκd
    (fun t ht => (heq t ht).1) (fun t ht => (heq t ht).2) hdb

/-- Converts the weighted error bound into the height and rate box used by the
invariance proof. No bounds on either transport velocity are assumed here. -/
theorem trajectory_enclosure {k₀ k₁ cap rlo rhi R₁ : ℝ}
    {h v w r r₁ : ℝ → ℝ} {t : ℝ}
    (hk₀ : 0 < k₀)
    (hV : errorEnergy k₀ (heightError h r t) (velocityError k₁ h v w r r₁ t) ≤ cap)
    (hr : rlo ≤ r t ∧ r t ≤ rhi) (hr₁ : |r₁ t| ≤ R₁) :
    rlo-sqrt (2*cap/k₀) ≤ h t ∧ h t ≤ rhi+sqrt (2*cap/k₀) ∧
      |heightRate (v t) (w t)| ≤ R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀) := by
  obtain ⟨he,_,hq⟩ := error_enclosure (k₁:=k₁) hk₀ hV
  have hhb := height_enclosure hr he
  have hid : velocityError k₁ h v w r r₁ t/2 - k₁*heightError h r t =
      heightRate (v t) (w t)-r₁ t := by unfold velocityError heightError heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [hid] at hq
  exact ⟨hhb.1,hhb.2,q_enclosure hr₁ hq⟩

/-- Connects the state speed to the internal Riccati equation without assuming v=w. -/
theorem mechanical_internal_equation {h v w : ℝ → ℝ} {H g β t : ℝ}
    (hden : H+h t ≠ 0)
    (hw : HasDerivAt w (fall H g β (h t) (v t) (w t)) t) :
    HasDerivAt w (internal H g β (h t) (w t) (heightRate (v t) (w t))) t := by
  have hcoord : w t+2*heightRate (v t) (w t) = v t := by unfold heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have heq := internal_identity H g β (h t) (w t) (heightRate (v t) (w t)) hden
  rw [hcoord] at heq
  rwa [←heq]

end
end ChainFountain
