/-
# Chain fountain: historical v0.16 single-file baseline

Open this file INSIDE this Lake project (see README_FIRST_BG.txt / README.md).
It is not a self-contained file for the public Mathlib-only Live Lean service.
The stochastic proofs import the pinned MathFin and BrownianMotion libraries.
Keep lean-toolchain and lake-manifest.json next to the source tree.

The mathematical source below is the original 557-theorem unified development.
It is retained as historical evidence and does not contain later completions.
For the current entire article use ChainFountainCompletion.lean. Run
python verify.py to check the full current project and its transitive axioms.
-/

import Mathlib
import Mathlib.MeasureTheory.Integral.IntervalIntegral.AbsolutelyContinuousFun
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap
import Mathlib.Analysis.Calculus.Deriv.Prod
import Mathlib.Tactic
import MathFin.Foundations.ItoFormulaAdaptedProcess
import MathFin.Foundations.BoundedLocalMartingale
import MathFin.Foundations.ItoIntegralL2
import MathFin.Foundations.ExitTime
import MathFin.Foundations.StoppedProcessPaths
import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.MeasureTheory.Integral.Prod
import BrownianMotion.Gaussian.BrownianMotion
import Mathlib.Analysis.SpecificLimits.Basic
import MathFin.Foundations.SDEExistence
import MathFin.Foundations.DriftProcessModification
import Mathlib.MeasureTheory.Function.LpSpace.Complete
import Mathlib.MeasureTheory.SpecificCodomains.Pi
import MathFin.Foundations.ItoIntegralLocalisedPredictable
import MathFin.Foundations.NormalTail
import MathFin.Foundations.GaussianCDFDeriv
import Mathlib.Analysis.Calculus.LHopital
import Mathlib.Analysis.Asymptotics.AsymptoticEquivalent
import Mathlib.Analysis.Normed.Operator.Basic
import Mathlib.Topology.MetricSpace.Contracting
import Mathlib.MeasureTheory.Constructions.Polish.StronglyMeasurable
import MathFin.Foundations.BrownianMartingale
import BrownianMotion.StochasticIntegral.DoobLp
import Mathlib.Analysis.PSeries
import Mathlib.Probability.BorelCantelli
import MathFin.Foundations.GirsanovAdaptedTheta
import MathFin.Foundations.ItoIntegralLocalised
import MathFin.Foundations.ItoIntegralProcessLocalMartingaleGeneral

-- The original verifier supplied this elaborator compatibility option on its command line.
set_option backward.isDefEq.respectTransparency false



/-!
# The reduced chain-fountain model
Paper: Boundary Actuation of a Chain Fountain, Latchezar Tomov.
All variables are real. The equations are assumed physical modelling laws;
the identities below are proved from those laws, not empirical validation.
-/

namespace ChainFountain

noncomputable section

def crownSq (v w : ℝ) : ℝ := ((v + w) / 2) ^ 2
def heightRate (v w : ℝ) : ℝ := (v - w) / 2
def rise (g α h v w u : ℝ) : ℝ :=
  (crownSq v w - (1 - α) * v ^ 2 - g * h - u) / h
def fall (H g β h v w : ℝ) : ℝ :=
  g + (-crownSq v w + β * w ^ 2) / (H + h)
def pickup (α v u : ℝ) : ℝ := (1 - α) * v ^ 2 + u
def energy (H g lam h v w : ℝ) : ℝ :=
  lam / 2 * (h * v ^ 2 + (H + h) * w ^ 2) + lam * g * h ^ 2

theorem crown_identity (v w : ℝ) :
    (v - w) * crownSq v w + (v - w) * (v ^ 2 + w ^ 2) / 4 =
      (v ^ 3 - w ^ 3) / 2 := by unfold crownSq; ring

/-- Proposition 3.1, the directional derivative of energy along the vector field. -/
theorem energy_balance (H g lam α β h v w u : ℝ)
    (hh : h ≠ 0) (hH : H + h ≠ 0) :
    lam / 2 * (heightRate v w * v ^ 2 + h * (2 * v * rise g α h v w u) +
      heightRate v w * w ^ 2 + (H + h) * (2 * w * fall H g β h v w)) +
      lam * g * (2 * h * heightRate v w) =
    lam * g * H * w - lam * (1 / 2 - α) * v ^ 3 -
      lam * (1 / 2 - β) * w ^ 3 - lam * u * v := by
  unfold heightRate rise fall crownSq
  field_simp <;> ring

/-- Proposition 3.1 with genuine derivatives, at every classical-solution time. -/
theorem energy_hasDerivAt {H g lam α β u t : ℝ} {h v w : ℝ → ℝ}
    (hh : h t ≠ 0) (hH : H + h t ≠ 0)
    (dh : HasDerivAt h (heightRate (v t) (w t)) t)
    (dv : HasDerivAt v (rise g α (h t) (v t) (w t) u) t)
    (dw : HasDerivAt w (fall H g β (h t) (v t) (w t)) t) :
    HasDerivAt (fun s => energy H g lam (h s) (v s) (w s))
      (lam * g * H * w t - lam * (1 / 2 - α) * v t ^ 3 -
       lam * (1 / 2 - β) * w t ^ 3 - lam * u * v t) t := by
  have hd := (((dh.mul (dv.pow 2)).add
    ((dh.const_add H).mul (dw.pow 2))).const_mul (lam / 2)).add
    ((dh.pow 2).const_mul (lam * g))
  convert! hd using 1
  convert! (energy_balance H g lam α β (h t) (v t) (w t) u hh hH).symm using 1 <;>
    simp only [Pi.pow_apply] <;> ring

def steadySpeedSq (H g β r : ℝ) : ℝ := g * (H + r) / (1 - β)
def steadyInput (H g α β r : ℝ) : ℝ :=
  g * (α * H - (1 - α - β) * r) / (1 - β)
def heightFromInput (H g α β u : ℝ) : ℝ :=
  (α * H - (1 - β) * u / g) / (1 - α - β)

theorem steady_input_balance (H g α β r : ℝ) (hβ : 1 - β ≠ 0) :
    steadyInput H g α β r = α * steadySpeedSq H g β r - g * r := by
  unfold steadyInput steadySpeedSq
  field_simp <;> ring

theorem steady_tension (H g α β r : ℝ) (hβ : 1 - β ≠ 0) :
    (1 - α) * steadySpeedSq H g β r + steadyInput H g α β r =
      g * (H + β * r) / (1 - β) := by
  unfold steadySpeedSq steadyInput
  field_simp <;> ring

theorem steady_tension_pos {H g β r : ℝ}
    (hH : 0 < H) (hg : 0 < g) (hβ : 0 ≤ β) (hβ1 : β < 1) (hr : 0 ≤ r) :
    0 < g * (H + β * r) / (1 - β) := by
  have hd : 0 < 1 - β := by linarith
  positivity

theorem steady_is_equilibrium {H g α β r v : ℝ}
    (_hr : r ≠ 0) (hH : H + r ≠ 0) (hβ : 1 - β ≠ 0)
    (hv : v ^ 2 = steadySpeedSq H g β r) :
    heightRate v v = 0 ∧
      rise g α r v v (steadyInput H g α β r) = 0 ∧
      fall H g β r v v = 0 := by
  have hc : crownSq v v = v ^ 2 := by unfold crownSq; ring
  have hb := steady_input_balance H g α β r hβ
  have hs : (1 - β) * v ^ 2 = g * (H + r) := by
    rw [hv, steadySpeedSq]; field_simp
  refine ⟨by simp [heightRate], ?_, ?_⟩
  · unfold rise; rw [hc]; rw [← hv] at hb
    have : v ^ 2 - (1 - α) * v ^ 2 - g * r - steadyInput H g α β r = 0 := by
      nlinarith
    rw [this]; simp
  · unfold fall; rw [hc]
    field_simp
    nlinarith [hs]

theorem input_height_inverse (H g α β r : ℝ)
    (hg : g ≠ 0) (hβ : 1 - β ≠ 0) (hαβ : 1 - α - β ≠ 0) :
    heightFromInput H g α β (steadyInput H g α β r) = r := by
  unfold heightFromInput steadyInput
  field_simp <;> ring

theorem passive_height_limit {H g α β r : ℝ}
    (hg : 0 < g) (hβ : 0 < 1 - β) (hαβ : 0 < 1 - α - β) :
    0 ≤ steadyInput H g α β r ↔ r ≤ α * H / (1 - α - β) := by
  unfold steadyInput
  rw [le_div_iff₀ hαβ, le_div_iff₀ hβ]
  constructor
  · intro hu; nlinarith
  · intro hr; nlinarith

theorem steady_state_iff {H g α β r v u : ℝ}
    (hr : r ≠ 0) (hH : H+r ≠ 0) (hβ : 1-β ≠ 0) :
    (rise g α r v v u=0 ∧ fall H g β r v v=0) ↔
      (v^2=steadySpeedSq H g β r ∧ u=steadyInput H g α β r) := by
  have hc : crownSq v v=v^2 := by unfold crownSq; ring
  constructor
  · rintro ⟨hu,hf⟩
    unfold fall at hf; rw [hc] at hf
    have heq : (1-β)*v^2=g*(H+r) := by
      field_simp at hf; nlinarith [hf]
    have hv : v^2=steadySpeedSq H g β r := by
      unfold steadySpeedSq; apply (eq_div_iff hβ).mpr; nlinarith [heq]
    refine ⟨hv,?_⟩
    unfold rise at hu; rw [hc] at hu
    have hnum := (div_eq_zero_iff.mp hu).resolve_right hr
    have hb := steady_input_balance H g α β r hβ
    rw [←hv] at hb; nlinarith
  · rintro ⟨hv,rfl⟩
    exact (steady_is_equilibrium hr hH hβ hv).2

end
end ChainFountain


namespace ChainFountain
noncomputable section

def errorEnergy (k₀ e z : ℝ) : ℝ := k₀ / 2 * e ^ 2 + z ^ 2 / 8
def errorRate (k₁ e z : ℝ) : ℝ := -k₁ * e + z / 2
def zRate (k₀ k₂ κd G d e z : ℝ) : ℝ :=
  -2 * k₀ * e - k₂ * z - κd * G ^ 2 * z + G * d
def acceleration (k₀ k₁ k₂ e q r₁ r₂ : ℝ) : ℝ :=
  r₂ - (k₁ + k₂) * (q - r₁) - (k₀ + k₁ * k₂) * e
def nominalInput (H g α β h v w A : ℝ) : ℝ :=
  (1 + h / (H + h)) * crownSq v w - (1 - α) * v ^ 2 -
    2 * g * h - β * h * w ^ 2 / (H + h) - 2 * h * A
def robustInput (H g α β h v w A κd z : ℝ) : ℝ :=
  nominalInput H g α β h v w A + κd * v ^ 4 / h * z

theorem nominal_acceleration (H g α β h v w A : ℝ)
    (hh : h ≠ 0) (hH : H + h ≠ 0) :
    (rise g α h v w (nominalInput H g α β h v w A) -
      fall H g β h v w) / 2 = A := by
  unfold rise fall nominalInput
  field_simp <;> ring

theorem robust_acceleration (H g α β h v w A κd z d : ℝ)
    (hh : h ≠ 0) (hH : H + h ≠ 0) :
    (rise g (α + d) h v w (robustInput H g α β h v w A κd z) -
      fall H g β h v w) / 2 =
        A - κd * (v ^ 2 / h) ^ 2 * z / 2 + (v ^ 2 / h) * d / 2 := by
  unfold robustInput rise fall nominalInput
  field_simp <;> ring

theorem transformed_error_rate (k₁ h r v w r₁ : ℝ) :
    heightRate v w - r₁ =
      errorRate k₁ (h-r) (v - w - 2 * r₁ + 2 * k₁ * (h-r)) := by
  unfold heightRate errorRate; ring

theorem transformed_z_rate (k₀ k₁ k₂ e q r₁ r₂ κd G d z : ℝ)
    (hz : z = 2 * (q - r₁ + k₁ * e)) :
    2 * (acceleration k₀ k₁ k₂ e q r₁ r₂ - κd * G ^ 2 * z / 2 + G * d / 2) -
      2 * r₂ + 2 * k₁ * (q - r₁) = zRate k₀ k₂ κd G d e z := by
  unfold acceleration zRate; rw [hz]; ring

theorem energy_nonneg {k₀ : ℝ} (hk₀ : 0 ≤ k₀) (e z : ℝ) :
    0 ≤ errorEnergy k₀ e z := by unfold errorEnergy; positivity

theorem energy_zero_iff {k₀ e z : ℝ} (hk₀ : 0 < k₀) :
    errorEnergy k₀ e z = 0 ↔ e = 0 ∧ z = 0 := by
  unfold errorEnergy
  constructor
  · intro h
    have he : e ^ 2 = 0 := by nlinarith [sq_nonneg z, sq_nonneg e]
    have hz : z ^ 2 = 0 := by nlinarith
    exact ⟨eq_zero_of_pow_eq_zero he, eq_zero_of_pow_eq_zero hz⟩
  · rintro ⟨rfl,rfl⟩; ring

/-- The exact Lyapunov identity, including bounded coefficient uncertainty. -/
theorem lyapunov_identity (k₀ k₁ k₂ κd G d e z : ℝ) :
    k₀ * e * errorRate k₁ e z + z / 4 * zRate k₀ k₂ κd G d e z =
      -k₀ * k₁ * e ^ 2 - k₂ * z ^ 2 / 4 - κd * G ^ 2 * z ^ 2 / 4 + G * z * d / 4 := by
  unfold errorRate zRate; ring

theorem energy_hasDerivAt_errors {e z : ℝ → ℝ} {k₀ k₁ k₂ κd G d t : ℝ}
    (he : HasDerivAt e (errorRate k₁ (e t) (z t)) t)
    (hz : HasDerivAt z (zRate k₀ k₂ κd G d (e t) (z t)) t) :
    HasDerivAt (fun s => errorEnergy k₀ (e s) (z s))
      (-k₀ * k₁ * e t ^ 2 - k₂ * z t ^ 2 / 4 -
        κd * G ^ 2 * z t ^ 2 / 4 + G * z t * d / 4) t := by
  have hd := ((he.pow 2).const_mul (k₀ / 2)).add ((hz.pow 2).div_const 8)
  convert! hd using 1
  unfold errorRate zRate; ring

theorem nominal_decay {k₀ k₁ k₂ κ e z : ℝ}
    (hk₀ : 0 ≤ k₀) (hκ₁ : κ ≤ k₁) (hκ₂ : κ ≤ k₂) :
    -k₀ * k₁ * e ^ 2 - k₂ * z ^ 2 / 4 ≤ -2 * κ * errorEnergy k₀ e z := by
  unfold errorEnergy
  have h₁ := mul_nonneg (sub_nonneg.mpr hκ₁) (mul_nonneg hk₀ (sq_nonneg e))
  have h₂ := mul_nonneg (sub_nonneg.mpr hκ₂) (sq_nonneg z)
  nlinarith

theorem weighted_young {κd G z d : ℝ} (hd : 0 < κd) :
    G * z * d / 4 ≤ κd * G ^ 2 * z ^ 2 / 8 + d ^ 2 / (8 * κd) := by
  apply (mul_le_mul_iff_right₀ (show 0 < 8 * κd by positivity)).mp
  have hsq := sq_nonneg (κd * G * z - d)
  have hc : (8 * κd) * (d ^ 2 / (8 * κd)) = d ^ 2 := by field_simp
  nlinarith

/-- Equation (7.2), proved directly from the weighted square identity. -/
theorem robust_decay {k₀ k₁ k₂ κ κd G d e z : ℝ}
    (hk₀ : 0 ≤ k₀) (hκ₁ : κ ≤ k₁) (hκ₂ : κ ≤ k₂) (hd : 0 < κd) :
    -k₀ * k₁ * e ^ 2 - k₂ * z ^ 2 / 4 - κd * G ^ 2 * z ^ 2 / 4 + G * z * d / 4 ≤
      -2 * κ * errorEnergy k₀ e z - κd * G ^ 2 * z ^ 2 / 8 + d ^ 2 / (8 * κd) := by
  have hn := nominal_decay (e:=e) (z:=z) hk₀ hκ₁ hκ₂
  have hy := weighted_young (G:=G) (z:=z) (d:=d) hd
  linarith

theorem robust_decay_uniform {k₀ k₁ k₂ κ κd G d dbar e z : ℝ}
    (hk₀ : 0 ≤ k₀) (hκ₁ : κ ≤ k₁) (hκ₂ : κ ≤ k₂)
    (hd : 0 < κd) (hbound : |d| ≤ dbar) :
    -k₀ * k₁ * e ^ 2 - k₂ * z ^ 2 / 4 - κd * G ^ 2 * z ^ 2 / 4 + G * z * d / 4 ≤
      -2 * κ * errorEnergy k₀ e z + dbar ^ 2 / (8 * κd) := by
  have h := robust_decay (e:=e) (z:=z) (G:=G) (d:=d) hk₀ hκ₁ hκ₂ hd
  have hs : d ^ 2 ≤ dbar ^ 2 := by
    have hsq := (sq_le_sq₀ (abs_nonneg d) (le_trans (abs_nonneg d) hbound)).mpr hbound
    simpa only [sq_abs] using hsq
  have hdiv := div_le_div_of_nonneg_right hs (by positivity : 0 ≤ 8 * κd)
  have hn : 0 ≤ κd * G ^ 2 * z ^ 2 / 8 := by positivity
  linarith

/-- Exact additional term caused by replacing the requested input. -/
theorem input_correction (z h u ur : ℝ) :
    z / 4 * (-(u - ur) / h) = -z / (4 * h) * (u - ur) := by ring

/-- The quadratic generator expression; no stochastic-process theorem is assumed. -/
theorem generator_identity (k₀ k₁ k₂ κd G σ e z : ℝ) :
    k₀ * e * errorRate k₁ e z + z / 4 * zRate k₀ k₂ κd G 0 e z +
      (1 / 2) * (σ * G) ^ 2 * (1 / 4) =
    -k₀ * k₁ * e ^ 2 - k₂ * z ^ 2 / 4 - κd * G ^ 2 * z ^ 2 / 4 + σ ^ 2 * G ^ 2 / 8 := by
  unfold errorRate zRate; ring

end
end ChainFountain


namespace ChainFountain
noncomputable section

def coeff₂ (ρ ω : ℝ) := (1 - ρ) * ω
def coeff₁ (α ρ ω : ℝ) := ((5 / 2) * α * (1 + ρ) - 4 * α ^ 2) * ω ^ 2
def coeff₀ (α ρ ω : ℝ) := α ^ 2 * (1 - ρ) * ω ^ 3
def cubic (α ρ ω p : ℝ) := p ^ 3 + coeff₂ ρ ω * p ^ 2 + coeff₁ α ρ ω * p + coeff₀ α ρ ω

theorem routh_factorization (α ρ ω : ℝ) :
    coeff₂ ρ ω * coeff₁ α ρ ω - coeff₀ α ρ ω =
      (5 / 2) * α * (1 - ρ) * (1 + ρ - 2 * α) * ω ^ 3 := by
  unfold coeff₂ coeff₁ coeff₀; ring

theorem hurwitz_conditions {α ρ ω : ℝ}
    (ha : 0 < α) (ha1 : α < 1 / 2) (hr : 0 < ρ) (hr1 : ρ < 1) (hw : 0 < ω) :
    0 < coeff₂ ρ ω ∧ 0 < coeff₁ α ρ ω ∧ 0 < coeff₀ α ρ ω ∧
      coeff₀ α ρ ω < coeff₂ ρ ω * coeff₁ α ρ ω := by
  have hr0 : 0 < 1 - ρ := by linarith
  have hb : 0 < (5 / 2) * (1 + ρ) - 4 * α := by linarith
  have hc : 0 < (5 / 2) * α * (1 + ρ) - 4 * α ^ 2 := by
    nlinarith [mul_pos ha hb]
  have hp : 0 < 1 + ρ - 2 * α := by linarith
  have hf : 0 < (5 / 2 : ℝ) * α * (1 - ρ) * (1 + ρ - 2 * α) * ω ^ 3 := by positivity
  refine ⟨by unfold coeff₂; positivity, by unfold coeff₁; positivity,
    by unfold coeff₀; positivity, ?_⟩
  rw [← routh_factorization] at hf; linarith

theorem rho_parameter_range {α β : ℝ}
    (ha : 0 < α) (hb : 0 ≤ β) (hab : α + β < 1 / 2) :
    0 < α / (1 - β) ∧ α / (1 - β) < 1 := by
  have hd : 0 < 1 - β := by linarith
  constructor
  · exact div_pos ha hd
  · rw [div_lt_one hd]; linarith

/-- A direct proof of the cubic Hurwitz criterion, rather than an assumed bridge. -/
theorem cubic_roots_left {a₂ a₁ a₀ : ℝ}
    (h₂ : 0 < a₂) (h₁ : 0 < a₁) (h₀ : 0 < a₀) (hH : a₀ < a₂ * a₁)
    (z : ℂ) (hz : z ^ 3 + (a₂ : ℂ) * z ^ 2 + (a₁ : ℂ) * z + (a₀ : ℂ) = 0) :
    z.re < 0 := by
  by_contra h
  have hx : 0 ≤ z.re := le_of_not_gt h
  have hre := congrArg Complex.re hz
  have him := congrArg Complex.im hz
  simp only [Complex.add_re, Complex.add_im, Complex.mul_re, Complex.mul_im,
    Complex.ofReal_re, Complex.ofReal_im, Complex.zero_re, Complex.zero_im,
    pow_succ, pow_zero, Complex.one_re, Complex.one_im] at hre him
  by_cases hy : z.im = 0
  · simp only [hy, mul_zero, zero_mul, add_zero, sub_zero, mul_one, zero_add] at hre
    have h3 : 0 ≤ z.re * z.re * z.re := by positivity
    have h2 : 0 ≤ a₂ * (z.re * z.re) := by positivity
    have h1 : 0 ≤ a₁ * z.re := by positivity
    nlinarith
  · have hi : z.im * (3 * z.re ^ 2 - z.im ^ 2 + 2 * a₂ * z.re + a₁) = 0 := by
      nlinarith [him]
    have hy2 : z.im ^ 2 - (3 * z.re ^ 2 + 2 * a₂ * z.re + a₁) = 0 := by
      have := (mul_eq_zero.mp hi).resolve_left hy; linarith
    have he : 8 * z.re ^ 3 + 8 * a₂ * z.re ^ 2 +
        2 * (a₁ + a₂ ^ 2) * z.re + (a₂ * a₁ - a₀) = 0 := by
      linear_combination -hre - (3 * z.re + a₂) * hy2
    have h3 : 0 ≤ z.re ^ 3 := by positivity
    have h2 : 0 ≤ a₂ * z.re ^ 2 := by positivity
    have h1 : 0 ≤ (a₁ + a₂ ^ 2) * z.re := by positivity
    linarith

theorem plant_cubic_roots_left {α ρ ω : ℝ}
    (ha : 0 < α) (ha1 : α < 1 / 2) (hr : 0 < ρ) (hr1 : ρ < 1) (hw : 0 < ω)
    (z : ℂ) (hz : z ^ 3 + (coeff₂ ρ ω : ℂ) * z ^ 2 +
      (coeff₁ α ρ ω : ℂ) * z + (coeff₀ α ρ ω : ℂ) = 0) : z.re < 0 := by
  obtain ⟨h₂,h₁,h₀,hH⟩ := hurwitz_conditions ha ha1 hr hr1 hw
  exact cubic_roots_left h₂ h₁ h₀ hH z hz

theorem no_pole_zero_cancellation (α ρ ω : ℝ) :
    cubic α ρ ω (-2 * α * ω) = -10 * α ^ 2 * ρ * ω ^ 3 := by
  unfold cubic coeff₂ coeff₁ coeff₀; ring

theorem transfer_zero_negative {α ω : ℝ} (ha : 0 < α) (hw : 0 < ω) :
    -2 * α * ω < 0 := by nlinarith [mul_pos ha hw]

theorem transfer_zero_not_root {α ρ ω : ℝ}
    (ha : 0 < α) (hr : 0 < ρ) (hw : 0 < ω) :
    cubic α ρ ω (-2 * α * ω) ≠ 0 := by
  rw [no_pole_zero_cancellation]
  have hp : 0 < 10 * α ^ 2 * ρ * ω ^ 3 := by positivity
  exact ne_of_lt (by nlinarith)

/-- Determinant of pI-J for the displayed Jacobian; J's differential identification
and nonlinear local exponential stability are separate analytic obligations. -/
theorem characteristic_determinant (α β ρ ω p : ℝ) (hrel : α = (1 - β) * ρ) :
    Matrix.det (!![p, -(1/2 : ℝ), (1/2 : ℝ);
      α * ω ^ 2, p + (1 - 2 * α) * ω, -ω;
      -α * ρ * ω ^ 2, ρ * ω, p + (1 - 2 * β) * ρ * ω]) = cubic α ρ ω p := by
  simp only [Matrix.det_fin_three]
  simp
  unfold cubic coeff₂ coeff₁ coeff₀
  rw [hrel]
  ring

/-- Resolvent input-output identity for the displayed Jacobian. The equations
are (pI-J)x=(0,-1/h,0); no inverse-matrix or transfer-function conclusion is
assumed. The identity is valid for complex p and state amplitudes. -/
theorem resolvent_output (α β ρ ω h : ℝ) (p x₀ x₁ x₂ : ℂ)
    (hrel : α = (1-β)*ρ)
    (he₀ : p*x₀-(1/2 : ℂ)*x₁+(1/2 : ℂ)*x₂=0)
    (he₁ : (α : ℂ)*ω^2*x₀+(p+(1-2*(α : ℂ))*ω)*x₁-(ω : ℂ)*x₂=-(1/(h : ℂ)))
    (he₂ : -(α : ℂ)*ρ*ω^2*x₀+(ρ : ℂ)*ω*x₁+(p+(1-2*(β : ℂ))*ρ*ω)*x₂=0) :
    (p^3+(coeff₂ ρ ω : ℂ)*p^2+(coeff₁ α ρ ω : ℂ)*p+(coeff₀ α ρ ω : ℂ))*x₀ =
      -(p+2*(α : ℂ)*ω)/(2*(h : ℂ)) := by
  have hr : (α : ℂ) = (1-(β : ℂ))*(ρ : ℂ) := by exact_mod_cast hrel
  unfold coeff₂ coeff₁ coeff₀
  push_cast
  rw [hr] at he₁ he₂ ⊢
  linear_combination
    ((p+(1-2*((1-(β : ℂ))*ρ))*ω)*(p+(1-2*(β : ℂ))*ρ*ω)+(ρ : ℂ)*ω^2)*he₀ +
    ((p+2*(1-(β : ℂ))*ρ*ω)/2)*he₁ +
    ((2*((1-(β : ℂ))*ρ)*ω-p)/2)*he₂

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Real

def envelope (V₀ κ C t : ℝ) : ℝ :=
  exp (-2 * κ * t) * V₀ + C / (2 * κ) * (1 - exp (-2 * κ * t))

/-- Comparison for genuine derivatives; this does not assume its conclusion. -/
theorem scalar_comparison {V V' : ℝ → ℝ} {T κ C : ℝ} (hκ : 0 < κ)
    (hc : ContinuousOn V (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt V (V' t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, V' t ≤ -2 * κ * V t + C) :
    ∀ t ∈ Icc 0 T, V t ≤ envelope (V 0) κ C t := by
  have hG := le_gronwallBound_of_liminf_deriv_right_le hc
    (fun t ht _ hr => (hd t ht).liminf_right_slope_le hr) (le_refl (V 0)) hb
  intro t ht
  have h := hG t ht
  rw [gronwallBound, if_neg (by nlinarith : -2 * κ ≠ 0), sub_zero] at h
  unfold envelope
  convert! h using 1; ring

theorem envelope_below_cap {V₀ κ C cap t : ℝ}
    (hκ : 0 < κ) (ht : 0 ≤ t) (hV : V₀ ≤ cap) (hC : C / (2 * κ) ≤ cap) :
    envelope V₀ κ C t ≤ cap := by
  have he0 : 0 ≤ exp (-2 * κ * t) := (exp_pos _).le
  have he1 : exp (-2 * κ * t) ≤ 1 := exp_le_one_iff.mpr (by nlinarith)
  have h₁ := mul_le_mul_of_nonneg_left hV he0
  have h₂ := mul_le_mul_of_nonneg_right hC (sub_nonneg.mpr he1)
  unfold envelope; nlinarith

/-- Theorem 7.1's finite-time estimate for existing classical error trajectories.
The measurable-disturbance Caratheodory extension is not hidden in this theorem. -/
theorem robust_error_estimate {e z G d : ℝ → ℝ} {T k₀ k₁ k₂ κ κd dbar : ℝ}
    (hk₀ : 0 ≤ k₀) (hκ : 0 < κ) (hκ₁ : κ ≤ k₁) (hκ₂ : κ ≤ k₂) (hκd : 0 < κd)
    (he : ∀ t ∈ Icc 0 T, HasDerivAt e (errorRate k₁ (e t) (z t)) t)
    (hz : ∀ t ∈ Icc 0 T, HasDerivAt z (zRate k₀ k₂ κd (G t) (d t) (e t) (z t)) t)
    (hb : ∀ t ∈ Ico 0 T, |d t| ≤ dbar) :
    ∀ t ∈ Icc 0 T, errorEnergy k₀ (e t) (z t) ≤
      exp (-2 * κ * t) * errorEnergy k₀ (e 0) (z 0) +
      dbar ^ 2 / (16 * κ * κd) * (1 - exp (-2 * κ * t)) := by
  have hd := fun t ht => energy_hasDerivAt_errors (he t ht) (hz t ht)
  have hc : ContinuousOn (fun t => errorEnergy k₀ (e t) (z t)) (Icc 0 T) :=
    fun t ht => (hd t ht).continuousAt.continuousWithinAt
  have hcomp := scalar_comparison hκ hc
    (fun t ht => (hd t (Ico_subset_Icc_self ht)).hasDerivWithinAt)
    (fun t ht => robust_decay_uniform hk₀ hκ₁ hκ₂ hκd (hb t ht))
  intro t ht
  have h := hcomp t ht
  unfold envelope at h
  convert! h using 1; ring

theorem nominal_error_estimate {e z : ℝ → ℝ} {T k₀ k₁ k₂ κ : ℝ}
    (hk₀ : 0 ≤ k₀) (hκ : 0 < κ) (hκ₁ : κ ≤ k₁) (hκ₂ : κ ≤ k₂)
    (he : ∀ t ∈ Icc 0 T, HasDerivAt e (errorRate k₁ (e t) (z t)) t)
    (hz : ∀ t ∈ Icc 0 T, HasDerivAt z (zRate k₀ k₂ 0 0 0 (e t) (z t)) t) :
    ∀ t ∈ Icc 0 T, errorEnergy k₀ (e t) (z t) ≤
      exp (-2 * κ * t) * errorEnergy k₀ (e 0) (z 0) := by
  have hd := fun t ht => energy_hasDerivAt_errors (he t ht) (hz t ht)
  have hc : ContinuousOn (fun t => errorEnergy k₀ (e t) (z t)) (Icc 0 T) :=
    fun t ht => (hd t ht).continuousAt.continuousWithinAt
  have hcomp := scalar_comparison (C:=0) hκ hc
    (fun t ht => (hd t (Ico_subset_Icc_self ht)).hasDerivWithinAt) (by
      intro t ht
      simpa using nominal_decay (e:=e t) (z:=z t) hk₀ hκ₁ hκ₂)
  simpa [envelope] using hcomp

/-- The energy-level part of the robust invariant-region theorem. -/
theorem robust_energy_invariant {V V' : ℝ → ℝ} {T κ κd dbar cap : ℝ}
    (hκ : 0 < κ) (_hκd : 0 < κd)
    (hc : ContinuousOn V (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt V (V' t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, V' t ≤ -2 * κ * V t + dbar ^ 2 / (8 * κd))
    (h₀ : V 0 ≤ cap) (hcap : dbar ^ 2 / (16 * κ * κd) ≤ cap) :
    ∀ t ∈ Icc 0 T, V t ≤ cap := by
  have hb' : (dbar ^ 2 / (8 * κd)) / (2 * κ) ≤ cap := by
    convert! hcap using 1; ring
  intro t ht
  exact (scalar_comparison hκ hc hd hb t ht).trans
    (envelope_below_cap hκ ht.1 h₀ hb')

/-- Conditional crown safety, obtained from derivatives and scalar comparison. -/
theorem crown_barrier_invariant {B B' : ℝ → ℝ} {T γ : ℝ}
    (hc : ContinuousOn B (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt B (B' t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, -γ * B t ≤ B' t) (h₀ : 0 ≤ B 0) :
    ∀ t ∈ Icc 0 T, 0 ≤ B t := by
  have hcomp := le_gronwallBound_of_liminf_deriv_right_le hc.neg
    (fun t ht _ hr => (hd t ht).neg.liminf_right_slope_le hr)
    (le_refl (-B 0)) (K := -γ) (ε := 0)
    (by intro t ht; simp only [Pi.neg_apply]; linarith [hb t ht])
  intro t ht
  have h := hcomp t ht
  rw [gronwallBound_ε0] at h
  simp only [Pi.neg_apply] at h
  have hp := exp_pos (-γ * (t - 0))
  nlinarith

end
end ChainFountain


namespace ChainFountain
noncomputable section

def barrierLower (αhi v : ℝ) := -(1 - αhi) * v ^ 2
def barrierUpper (H g β αlo h v w γ B : ℝ) :=
  crownSq v w - (1 - αlo) * v ^ 2 - g * h +
    h * (fall H g β h v w + 2 * γ * B)

theorem pickup_endpoint_iff {αlo αhi v u : ℝ} (hα : αlo ≤ αhi) :
    (∀ α ∈ Set.Icc αlo αhi, 0 ≤ pickup α v u) ↔ barrierLower αhi v ≤ u := by
  constructor
  · intro h
    have he := h αhi ⟨hα,le_rfl⟩
    unfold pickup at he; unfold barrierLower; linarith
  · intro h α ha
    have hs := mul_nonneg (sub_nonneg.mpr ha.2) (sq_nonneg v)
    unfold pickup; unfold barrierLower at h; nlinarith

theorem crown_input_iff {H g β α h v w γ B u : ℝ} (hh : 0 < h) :
    0 ≤ (rise g α h v w u + fall H g β h v w) / 2 + γ * B ↔
      u ≤ barrierUpper H g β α h v w γ B := by
  have hid : 2 * h * ((rise g α h v w u + fall H g β h v w) / 2 + γ * B) =
      barrierUpper H g β α h v w γ B - u := by
    unfold rise barrierUpper; field_simp <;> ring
  constructor
  · intro hb
    have := mul_nonneg (by positivity : 0 ≤ 2 * h) hb; rw [hid] at this; linarith
  · intro hu
    have hp : 0 < 2 * h := by positivity
    have : 0 ≤ 2 * h * ((rise g α h v w u + fall H g β h v w) / 2 + γ * B) := by
      rw [hid]; linarith
    exact nonneg_of_mul_nonneg_right this hp

theorem crown_endpoint_iff {H g β αlo αhi h v w γ B u : ℝ}
    (hh : 0 < h) (hα : αlo ≤ αhi) :
    (∀ α ∈ Set.Icc αlo αhi,
      0 ≤ (rise g α h v w u + fall H g β h v w) / 2 + γ * B) ↔
      u ≤ barrierUpper H g β αlo h v w γ B := by
  constructor
  · intro hb; exact (crown_input_iff hh).mp (hb αlo ⟨le_rfl,hα⟩)
  · intro hu α ha
    apply (crown_input_iff hh).mpr
    have hs := mul_nonneg (sub_nonneg.mpr ha.1) (sq_nonneg v)
    unfold barrierUpper at *; nlinarith

theorem barrier_width (H g β αlo αhi h v w γ B : ℝ) (hH : H + h ≠ 0) :
    barrierUpper H g β αlo h v w γ B - barrierLower αhi v =
      (H * crownSq v w + β * h * w ^ 2) / (H + h) +
        2 * h * γ * B - (αhi - αlo) * v ^ 2 := by
  unfold barrierUpper barrierLower fall
  field_simp <;> ring

/-- Proposition 8.1's exact pointwise feasibility equivalence. -/
theorem barrier_feasible_iff {H g β αlo αhi h v w γ B : ℝ}
    (hh : 0 < h) (hH : H + h ≠ 0) (hα : αlo ≤ αhi) :
    (∃ u, (∀ α ∈ Set.Icc αlo αhi, 0 ≤ pickup α v u) ∧
      (∀ α ∈ Set.Icc αlo αhi,
        0 ≤ (rise g α h v w u + fall H g β h v w) / 2 + γ * B)) ↔
    (αhi - αlo) * v ^ 2 ≤
      (H * crownSq v w + β * h * w ^ 2) / (H + h) + 2 * h * γ * B := by
  have hw := barrier_width H g β αlo αhi h v w γ B hH
  simp_rw [pickup_endpoint_iff hα, crown_endpoint_iff hh hα]
  constructor
  · rintro ⟨u,hl,hu⟩; linarith
  · intro h; exact ⟨barrierLower αhi v,le_rfl,by linarith⟩

theorem interval_intersection_iff (amin amax L U : ℝ) :
    (∃ u, amin ≤ u ∧ u ≤ amax ∧ L ≤ u ∧ u ≤ U) ↔ max amin L ≤ min amax U := by
  constructor
  · rintro ⟨u,ha,hb,hL,hU⟩
    exact (max_le ha hL).trans (le_min hb hU)
  · intro h
    exact ⟨max amin L,le_max_left _ _,h.trans (min_le_left _ _),
      le_max_right _ _,h.trans (min_le_right _ _)⟩

def clip (L U desired : ℝ) := min U (max L desired)

theorem clip_mem {L U desired : ℝ} (h : L ≤ U) : L ≤ clip L U desired ∧ clip L U desired ≤ U := by
  unfold clip
  exact ⟨le_min h (le_max_left _ _),min_le_left _ _⟩

theorem clip_nearest {L U desired u : ℝ} (h : L ≤ U) (hu : L ≤ u ∧ u ≤ U) :
    (clip L U desired - desired) ^ 2 ≤ (u - desired) ^ 2 := by
  unfold clip
  by_cases hl : desired ≤ L
  · rw [max_eq_left hl, min_eq_right h]
    nlinarith [sq_nonneg (u-L)]
  · have hld : L ≤ desired := (lt_of_not_ge hl).le
    rw [max_eq_right hld]
    by_cases hd : U ≤ desired
    · rw [min_eq_left hd]
      nlinarith [sq_nonneg (U-u)]
    · rw [min_eq_right (lt_of_not_ge hd).le]
      simp only [sub_self, zero_pow (by decide : 2 ≠ 0)]
      exact sq_nonneg _

theorem nominal_barrier_nonempty {H g h β v w γ B α : ℝ}
    (hH : 0 < H) (hh : 0 < h) (hβ : 0 ≤ β) (hγ : 0 ≤ γ) (hB : 0 ≤ B) :
    barrierLower α v ≤ barrierUpper H g β α h v w γ B := by
  have hw := barrier_width H g β α α h v w γ B (ne_of_gt (add_pos hH hh))
  have hp : 0 ≤ (H * crownSq v w + β * h * w ^ 2) / (H+h) + 2*h*γ*B := by
    unfold crownSq; positivity
  simp only [sub_self,zero_mul,sub_zero] at hw
  linarith

/-- Appendix A.1: positive crown margin does not give an inward falling-speed face. -/
theorem counterexample_falling_speed :
    (10 + (0 : ℝ)) / 2 - 16/5 > 0 ∧
    fall 2 (981/100) (1/50) (1/10) 10 0 < 0 := by
  norm_num [fall,crownSq]

/-- Appendix A.2: both velocities positive but the robust interval is empty. -/
theorem counterexample_empty_interval (γ : ℝ) :
    barrierUpper 2 (981/100) (1/50) (3/50) 3 (63/10) (1/10) γ 0 <
      barrierLower (9/50) (63/10) := by
  norm_num [barrierUpper,barrierLower,fall,crownSq]

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Real Set

def internal (H g β h w q : ℝ) : ℝ :=
  (g * (H + h) - (1 - β) * w ^ 2 - 2 * q * w - q ^ 2) / (H + h)

theorem internal_identity (H g β h w q : ℝ) (hH : H + h ≠ 0) :
    fall H g β h (w + 2*q) w = internal H g β h w q := by
  unfold fall internal crownSq; field_simp <;> ring

theorem error_height_sq {k₀ e z cap : ℝ} (hk : 0 < k₀)
    (hV : errorEnergy k₀ e z ≤ cap) : e ^ 2 ≤ 2 * cap / k₀ := by
  rw [le_div_iff₀ hk]
  unfold errorEnergy at hV; nlinarith [sq_nonneg z]

theorem error_z_sq {k₀ e z cap : ℝ} (hk : 0 ≤ k₀)
    (hV : errorEnergy k₀ e z ≤ cap) : z ^ 2 ≤ 8 * cap := by
  unfold errorEnergy at hV
  nlinarith [mul_nonneg hk (sq_nonneg e)]

/-- The weighted Cauchy--Schwarz estimate used in (6.1). -/
theorem error_q_sq {k₀ k₁ e z cap : ℝ} (hk : 0 < k₀)
    (hV : errorEnergy k₀ e z ≤ cap) :
    (z / 2 - k₁ * e) ^ 2 ≤ 2 * cap * (1 + k₁ ^ 2 / k₀) := by
  have hid : (2 * errorEnergy k₀ e z * (1 + k₁ ^ 2 / k₀) -
      (z/2-k₁*e)^2) * k₀ = (k₀ * e + k₁ * z / 2) ^ 2 := by
    unfold errorEnergy; field_simp <;> ring
  have hnon : 0 ≤ (2 * errorEnergy k₀ e z * (1 + k₁ ^ 2 / k₀) -
      (z/2-k₁*e)^2) := by
    apply nonneg_of_mul_nonneg_left (b:=k₀)
    · rw [hid]; exact sq_nonneg _
    · exact hk
  have hp : 0 ≤ 1 + k₁ ^ 2 / k₀ := by positivity
  have hm := mul_le_mul_of_nonneg_right hV hp
  linarith

theorem error_enclosure {k₀ k₁ e z cap : ℝ} (hk : 0 < k₀)
    (hV : errorEnergy k₀ e z ≤ cap) :
    |e| ≤ sqrt (2 * cap / k₀) ∧ |z| ≤ sqrt (8 * cap) ∧
    |z / 2 - k₁ * e| ≤ sqrt (2 * cap) * sqrt (1 + k₁ ^ 2 / k₀) := by
  have hc : 0 ≤ cap := (energy_nonneg hk.le e z).trans hV
  refine ⟨abs_le_sqrt (error_height_sq hk hV), abs_le_sqrt (error_z_sq hk.le hV), ?_⟩
  have h := abs_le_sqrt (error_q_sq (k₁:=k₁) hk hV)
  rwa [sqrt_mul (by positivity : 0 ≤ 2 * cap)] at h

theorem transport_positive {w q Q wlo vmin : ℝ}
    (hw : wlo ≤ w) (hq : |q| ≤ Q) (hforward : 2 * Q < wlo)
    (hcrown : vmin ≤ wlo - Q) :
    0 < w + 2 * q ∧ vmin ≤ w + q := by
  have hq' := abs_le.mp hq
  constructor <;> linarith

theorem height_enclosure {h r rlo rhi ce : ℝ}
    (hr : rlo ≤ r ∧ r ≤ rhi) (he : |h-r| ≤ ce) :
    rlo-ce ≤ h ∧ h ≤ rhi+ce := by
  have he' := abs_le.mp he; constructor <;> linarith

theorem q_enclosure {q r₁ cq R₁ : ℝ}
    (hr : |r₁| ≤ R₁) (hq : |q-r₁| ≤ cq) : |q| ≤ R₁+cq := by
  have hh := abs_add_le (q-r₁) r₁
  rw [sub_add_cancel] at hh; linarith

theorem lower_face {H g β h hlo wlo Q q : ℝ}
    (hden : 0 < H + h) (hg : 0 ≤ g) (hh : hlo ≤ h)
    (hq : |q| ≤ Q) (hw : 2 * Q < wlo)
    (hface : (1-β) * wlo^2 + 2*Q*wlo + Q^2 ≤ g*(H+hlo)) :
    0 ≤ internal H g β h wlo q := by
  have hQ : 0 ≤ Q := (abs_nonneg q).trans hq
  have hq' := abs_le.mp hq
  have hs : (wlo+q)^2 ≤ (wlo+Q)^2 := by
    apply pow_le_pow_left₀ (by linarith) (by linarith)
  have hgh := mul_le_mul_of_nonneg_left hh hg
  unfold internal
  apply div_nonneg _ hden.le
  nlinarith

theorem upper_face {H g β h hhi whi Q q : ℝ}
    (hden : 0 < H + h) (hg : 0 ≤ g) (hh : h ≤ hhi)
    (hq : |q| ≤ Q) (hw : 2 * Q < whi)
    (hface : g*(H+hhi) ≤ (1-β) * whi^2 - 2*Q*whi + Q^2) :
    internal H g β h whi q ≤ 0 := by
  have hQ : 0 ≤ Q := (abs_nonneg q).trans hq
  have hq' := abs_le.mp hq
  have hs : (whi-Q)^2 ≤ (whi+q)^2 := by
    apply pow_le_pow_left₀ (by linarith) (by linarith)
  have hgh := mul_le_mul_of_nonneg_left hh hg
  unfold internal
  apply div_nonpos_of_nonpos_of_nonneg _ hden.le
  nlinarith

/-- Difference factorization needed to integrate the inward face inequalities. -/
theorem internal_difference (H g β h w b q : ℝ) :
    internal H g β h w q - internal H g β h b q =
      -(((1-β)*(w+b)+2*q)/(H+h))*(w-b) := by
  unfold internal; ring

theorem zero_dynamics_factor (H g β r w wr : ℝ)
    (hden : H+r ≠ 0) (heq : (1-β)*wr^2=g*(H+r)) :
    internal H g β r w 0 = -(1-β)/(H+r)*(w+wr)*(w-wr) := by
  unfold internal; field_simp <;> nlinarith [heq]

theorem fullstate_forcing_identity (H g β r e q w wr : ℝ)
    (hden : H+(r+e) ≠ 0) (heq : (1-β)*wr^2=g*(H+r)) :
    internal H g β (r+e) w q =
      -(1-β)*(w+wr)/(H+(r+e))*(w-wr) +
        (g*e-2*q*w-q^2)/(H+(r+e)) := by
  unfold internal; field_simp <;> nlinarith [heq]

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Real MeasureTheory

/-- Sign preservation for a scalar differential inequality with a continuous,
time-dependent coefficient, proved using an integrating factor and the FTC. -/
theorem linear_sign_preservation {y y' K : ℝ → ℝ} {T : ℝ}
    (hK : Continuous K) (hy : ContinuousOn y (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt y (y' t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, y' t ≤ K t * y t) (h₀ : y 0 ≤ 0) :
    ∀ t ∈ Icc 0 T, y t ≤ 0 := by
  let A : ℝ → ℝ := fun t => ∫ s in (0 : ℝ)..t, K s
  have hA : ∀ t, HasDerivAt A (K t) t := fun t =>
    intervalIntegral.integral_hasDerivAt_right (hK.intervalIntegrable _ _)
      hK.aestronglyMeasurable.stronglyMeasurableAtFilter hK.continuousAt
  have hAc : Continuous A := continuous_iff_continuousAt.mpr (fun t => (hA t).continuousAt)
  have hc : ContinuousOn (fun t => y t * exp (-A t)) (Icc 0 T) :=
    hy.mul (Real.continuous_exp.comp hAc.neg).continuousOn
  have hder : ∀ t ∈ Ico 0 T, HasDerivWithinAt (fun t => y t * exp (-A t))
      ((y' t - K t * y t) * exp (-A t)) (Ici t) t := by
    intro t ht
    convert! (hd t ht).mul ((hA t).neg.exp.hasDerivWithinAt) using 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hin : y 0 * exp (-A 0) ≤ (0 : ℝ) := mul_nonpos_of_nonpos_of_nonneg h₀ (exp_pos _).le
  have hcmp := image_le_of_deriv_right_le_deriv_boundary hc hder hin continuousOn_const
    (fun t _ => hasDerivWithinAt_const t (Ici t) (0 : ℝ)) (by
      intro t ht
      exact mul_nonpos_of_nonpos_of_nonneg (sub_nonpos.mpr (hb t ht)) (exp_pos _).le)
  intro t ht
  exact nonpos_of_mul_nonpos_left (hcmp ht) (exp_pos _)

/-- The same comparison needs continuity only on the supplied time interval. -/
theorem linear_sign_preservation_on {y y' K : ℝ → ℝ} {T : ℝ}
    (hK : ContinuousOn K (Icc 0 T)) (hy : ContinuousOn y (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt y (y' t) (Ici t) t)
    (hb : ∀ t ∈ Ico 0 T, y' t ≤ K t * y t) (h₀ : y 0 ≤ 0) :
    ∀ t ∈ Icc 0 T, y t ≤ 0 := by
  by_cases hT : 0 ≤ T
  · let Kext : ℝ → ℝ := fun t => K (projIcc 0 T hT t)
    have hKe : Continuous Kext := hK.comp_continuous
      (continuous_subtype_val.comp continuous_projIcc) (fun t => (projIcc 0 T hT t).property)
    have hEq : ∀ t ∈ Icc 0 T, Kext t=K t := by
      intro t ht; simp [Kext,projIcc_of_mem hT ht]
    exact linear_sign_preservation hKe hy hd (by
      intro t ht; rw [hEq t (Ico_subset_Icc_self ht)]; exact hb t ht) h₀
  · intro t ht; exfalso; exact hT (ht.1.trans ht.2)

/-- Invariance of the falling-speed interval for an existing classical trajectory.
Unlike a boundary-only check this theorem proves the time-dependent conclusion.
The two continuous coefficients are the explicitly factored Riccati differences.
It does not assert construction or global continuation of a solution. -/
theorem speed_interval_invariant {h w q : ℝ → ℝ} {H g β T wlo whi : ℝ}
    (hw : ContinuousOn w (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt w (internal H g β (h t) (w t) (q t)) (Ici t) t)
    (hKl : ContinuousOn (fun t => -((1-β)*(w t+wlo)+2*q t)/(H+h t)) (Icc 0 T))
    (hKu : ContinuousOn (fun t => -((1-β)*(w t+whi)+2*q t)/(H+h t)) (Icc 0 T))
    (hl : ∀ t ∈ Ico 0 T, 0 ≤ internal H g β (h t) wlo (q t))
    (hu : ∀ t ∈ Ico 0 T, internal H g β (h t) whi (q t) ≤ 0)
    (h₀ : wlo ≤ w 0 ∧ w 0 ≤ whi) :
    ∀ t ∈ Icc 0 T, wlo ≤ w t ∧ w t ≤ whi := by
  have hlo := linear_sign_preservation_on hKl (continuousOn_const.sub hw)
    (fun t ht => (hd t ht).const_sub wlo) (by
      intro t ht
      have hi := internal_difference H g β (h t) (w t) wlo (q t)
      have hf := hl t ht
      simp only [neg_div]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hi]) (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [h₀.1] : wlo - w 0 ≤ 0)
  have hhi := linear_sign_preservation_on hKu (hw.sub continuousOn_const)
    (fun t ht => (hd t ht).sub_const whi) (by
      intro t ht
      have hi := internal_difference H g β (h t) (w t) whi (q t)
      have hf := hu t ht
      simp only [neg_div]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hi]) (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [h₀.2] : w 0 - whi ≤ 0)
  intro t ht; exact ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hlo t ht], by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hhi t ht]⟩

/-- The geometric part of Theorem 6.1 on any supplied existence interval.
The energy estimate supplies h and q bounds independently in Region/Comparison. -/
theorem physical_region_invariant {h w q : ℝ → ℝ} {H g β T hlo hhi Q wlo whi vmin : ℝ}
    (hH : 0 < H) (hg : 0 ≤ g) (hlo0 : 0 < hlo)
    (hw : ContinuousOn w (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt w (internal H g β (h t) (w t) (q t)) (Ici t) t)
    (hKl : ContinuousOn (fun t => -((1-β)*(w t+wlo)+2*q t)/(H+h t)) (Icc 0 T))
    (hKu : ContinuousOn (fun t => -((1-β)*(w t+whi)+2*q t)/(H+h t)) (Icc 0 T))
    (hh : ∀ t ∈ Icc 0 T, hlo ≤ h t ∧ h t ≤ hhi)
    (hq : ∀ t ∈ Icc 0 T, |q t| ≤ Q)
    (hforward : 2*Q < wlo) (horder : wlo ≤ whi) (hcrown : vmin ≤ wlo-Q)
    (hl : (1-β)*wlo^2 + 2*Q*wlo + Q^2 ≤ g*(H+hlo))
    (hu : g*(H+hhi) ≤ (1-β)*whi^2 - 2*Q*whi + Q^2)
    (h₀ : wlo ≤ w 0 ∧ w 0 ≤ whi) :
    ∀ t ∈ Icc 0 T, 0 < h t ∧ wlo ≤ w t ∧ w t ≤ whi ∧
      0 < w t + 2*q t ∧ vmin ≤ w t+q t := by
  have hb := speed_interval_invariant hw hd hKl hKu (by
    intro t ht
    have htt := Ico_subset_Icc_self ht
    exact lower_face (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hh t htt).1]) hg (hh t htt).1 (hq t htt) hforward hl)
    (by
      intro t ht
      have htt := Ico_subset_Icc_self ht
      exact upper_face (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hh t htt).1]) hg (hh t htt).2 (hq t htt)
        (lt_of_lt_of_le hforward horder) hu) h₀
  intro t ht
  have hv := transport_positive (hb t ht).1 (hq t ht) hforward hcrown
  exact ⟨lt_of_lt_of_le hlo0 (hh t ht).1,(hb t ht).1,(hb t ht).2,hv.1,hv.2⟩

end
end ChainFountain


namespace ChainFountain
noncomputable section

theorem square_interval {x lo hi : ℝ} (hlo : 0 ≤ lo) (hx : lo ≤ x ∧ x ≤ hi) :
    lo^2 ≤ x^2 ∧ x^2 ≤ hi^2 := by
  exact ⟨pow_le_pow_left₀ hlo hx.1 2, pow_le_pow_left₀ (hlo.trans hx.1) hx.2 2⟩

theorem acceleration_bound {k₀ k₁ k₂ e q r₁ r₂ ce cq R₂ : ℝ}
    (hk₀ : 0 ≤ k₀) (hk₁ : 0 ≤ k₁) (hk₂ : 0 ≤ k₂)
    (he : |e| ≤ ce) (hq : |q-r₁| ≤ cq) (hr : |r₂| ≤ R₂) :
    |acceleration k₀ k₁ k₂ e q r₁ r₂| ≤
      R₂+(k₁+k₂)*cq+(k₀+k₁*k₂)*ce := by
  unfold acceleration
  have h₁ := abs_sub r₂ ((k₁+k₂)*(q-r₁))
  have h₂ := abs_sub (r₂-(k₁+k₂)*(q-r₁)) ((k₀+k₁*k₂)*e)
  rw [abs_mul, abs_of_nonneg (by positivity : 0 ≤ k₁+k₂)] at h₁
  rw [abs_mul, abs_of_nonneg (by positivity : 0 ≤ k₀+k₁*k₂)] at h₂
  have h₃ := mul_le_mul_of_nonneg_left hq (by positivity : 0 ≤ k₁+k₂)
  have h₄ := mul_le_mul_of_nonneg_left he (by positivity : 0 ≤ k₀+k₁*k₂)
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

theorem damping_bound {κd v vmax h hlo z cz : ℝ}
    (hκd : 0 ≤ κd) (hhlo : 0 < hlo) (hh : hlo ≤ h)
    (hv : v^2 ≤ vmax^2) (hz : |z| ≤ cz) :
    |κd * v^4/h*z| ≤ κd * vmax^4/hlo*cz := by
  have hh0 : 0 < h := hhlo.trans_le hh
  have hv4 : v^4 ≤ vmax^4 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [sq_nonneg (v^2-vmax^2),sq_nonneg v,sq_nonneg vmax]
  have hdiv := div_le_div₀ (pow_nonneg (sq_nonneg vmax) 2) (show (v^2)^2 ≤ (vmax^2)^2 by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hv4]) hhlo hh
  have hdiv' : v^4/h ≤ vmax^4/hlo := by simpa only [←pow_mul] using hdiv
  have hm := mul_le_mul_of_nonneg_left hdiv' hκd
  have hprod := mul_le_mul hm hz (abs_nonneg z) (by positivity : 0 ≤ κd*(vmax^4/hlo))
  rw [abs_mul,abs_of_nonneg (by positivity : 0 ≤ κd*v^4/h)]
  convert! hprod using 1 <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

def lowerInputBound (H g α β hlo hhi vhi slo whi A D : ℝ) :=
  slo^2-(1-α)*vhi^2-2*g*hhi-β*hhi*whi^2/(H+hlo)-2*hhi*A-D
def upperInputBound (H g α hlo hhi vlo shi A D : ℝ) :=
  (1+hhi/(H+hlo))*shi^2-(1-α)*vlo^2-2*g*hlo+2*hhi*A+D
def lowerTensionBound (H g β hlo hhi slo whi A : ℝ) :=
  slo^2-hhi*(2*g+β*whi^2/(H+hlo)+2*A)

/-- Proposition 6.3's input enclosure, with explicit state-box hypotheses. -/
theorem force_box_bounds {H g α β h hLo hHi v vLo vHi w wHi sLo sHi A Amax D damp : ℝ}
    (hH : 0 < H) (hg : 0 ≤ g) (ha : α ≤ 1) (hb : 0 ≤ β)
    (hhLo : 0 < hLo) (hh : hLo ≤ h ∧ h ≤ hHi)
    (hv : vLo^2 ≤ v^2 ∧ v^2 ≤ vHi^2)
    (hw : w^2 ≤ wHi^2) (hs : sLo^2 ≤ crownSq v w ∧ crownSq v w ≤ sHi^2)
    (hA : |A| ≤ Amax) (hd : |damp| ≤ D) :
    lowerInputBound H g α β hLo hHi vHi sLo wHi Amax D ≤
      nominalInput H g α β h v w A+damp ∧
    nominalInput H g α β h v w A+damp ≤
      upperInputBound H g α hLo hHi vLo sHi Amax D := by
  have hh0 : 0 < h := hhLo.trans_le hh.1
  have hhHi : 0 < hHi := hh0.trans_le hh.2
  have hden : 0 < H+hLo := add_pos hH hhLo
  have hden' : 0 < H+h := add_pos hH hh0
  have ha0 : 0 ≤ 1-α := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hS : 0 ≤ crownSq v w := by unfold crownSq; positivity
  have hr0 : 0 ≤ h/(H+h) := by positivity
  have hr : h/(H+h) ≤ hHi/(H+hLo) := div_le_div₀ hhHi.le hh.2 hden (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith)
  have hlS : sLo^2 ≤ (1+h/(H+h))*crownSq v w := by
    have hp := mul_nonneg hr0 hS; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hs.1]
  have huS : (1+h/(H+h))*crownSq v w ≤ (1+hHi/(H+hLo))*sHi^2 := by
    exact mul_le_mul (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) hs.2 hS (by positivity)
  have hvL := mul_le_mul_of_nonneg_left hv.1 ha0
  have hvU := mul_le_mul_of_nonneg_left hv.2 ha0
  have hgL := mul_le_mul_of_nonneg_left hh.1 hg
  have hgU := mul_le_mul_of_nonneg_left hh.2 hg
  have hbn : 0 ≤ β*h*w^2/(H+h) := by positivity
  have hbnum : β*h*w^2 ≤ β*hHi*wHi^2 :=
    mul_le_mul (mul_le_mul_of_nonneg_left hh.2 hb) hw (sq_nonneg w) (by positivity)
  have hbU := div_le_div₀ (by positivity : 0 ≤ β*hHi*wHi^2) hbnum hden (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith : H+hLo ≤ H+h)
  have hA0 : 0 ≤ Amax := (abs_nonneg A).trans hA
  have hAA : |2*h*A| ≤ 2*hHi*Amax := by
    rw [abs_mul,abs_of_nonneg (by positivity : 0 ≤ 2*h)]
    exact mul_le_mul (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) hA (abs_nonneg A) (by positivity)
  have hAA' := abs_le.mp hAA
  have hd' := abs_le.mp hd
  unfold lowerInputBound upperInputBound nominalInput
  constructor <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

/-- Pickup-tension enclosure, using the same interval estimates. -/
theorem tension_box_bound {H g α β h hLo hHi v vHi w wHi sLo A Amax D damp d dbar : ℝ}
    (hH : 0 < H) (hg : 0 ≤ g) (hb : 0 ≤ β)
    (hhLo : 0 < hLo) (hh : hLo ≤ h ∧ h ≤ hHi)
    (hv : v^2 ≤ vHi^2) (hw : w^2 ≤ wHi^2)
    (hs : sLo^2 ≤ crownSq v w) (hA : |A| ≤ Amax)
    (hd : |damp| ≤ D) (hdd : |d| ≤ dbar) :
    lowerTensionBound H g β hLo hHi sLo wHi Amax-D-dbar*vHi^2 ≤
      pickup (α+d) v (nominalInput H g α β h v w A+damp) := by
  have hh0 : 0 < h := hhLo.trans_le hh.1
  have hhHi : 0 < hHi := hh0.trans_le hh.2
  have hden : 0 < H+hLo := add_pos hH hhLo
  have hS : 0 ≤ crownSq v w := by unfold crownSq; positivity
  have hp := mul_nonneg (show 0 ≤ h/(H+h) by positivity) hS
  have hgU := mul_le_mul_of_nonneg_left hh.2 hg
  have hbnum : β*h*w^2 ≤ β*hHi*wHi^2 :=
    mul_le_mul (mul_le_mul_of_nonneg_left hh.2 hb) hw (sq_nonneg w) (by positivity)
  have hbU := div_le_div₀ (by positivity : 0 ≤ β*hHi*wHi^2) hbnum hden (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith : H+hLo ≤ H+h)
  have hAA : |2*h*A| ≤ 2*hHi*Amax := by
    rw [abs_mul,abs_of_nonneg (by positivity : 0 ≤ 2*h)]
    exact mul_le_mul (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) hA (abs_nonneg A) (by positivity)
  have hAA' := abs_le.mp hAA
  have hd' := abs_le.mp hd
  have hdd' := abs_le.mp hdd
  have hdb0 : 0 ≤ dbar := (abs_nonneg d).trans hdd
  have hdv : d*v^2 ≤ dbar*vHi^2 := mul_le_mul hdd'.2 hv (sq_nonneg v) hdb0
  unfold lowerTensionBound pickup nominalInput
  have hrearr : hHi*(β*wHi^2/(H+hLo)) = β*hHi*wHi^2/(H+hLo) := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hrearr]

/-- Proposition 6.3 assembled for the actual damped input and uncertain pickup. -/
theorem robust_force_feasibility
    {H g α β h hLo hHi v vLo vHi w wHi sLo sHi A Amax κd z cz d dbar uLo uHi : ℝ}
    (hH : 0 < H) (hg : 0 ≤ g) (ha : α ≤ 1) (hb : 0 ≤ β)
    (hhLo : 0 < hLo) (hh : hLo ≤ h ∧ h ≤ hHi)
    (hv : vLo^2 ≤ v^2 ∧ v^2 ≤ vHi^2) (hw : w^2 ≤ wHi^2)
    (hs : sLo^2 ≤ crownSq v w ∧ crownSq v w ≤ sHi^2)
    (hA : |A| ≤ Amax) (hκd : 0 ≤ κd) (hz : |z| ≤ cz) (hd : |d| ≤ dbar)
    (hL : uLo ≤ lowerInputBound H g α β hLo hHi vHi sLo wHi Amax (κd*vHi^4/hLo*cz))
    (hU : upperInputBound H g α hLo hHi vLo sHi Amax (κd*vHi^4/hLo*cz) ≤ uHi)
    (hT : 0 ≤ lowerTensionBound H g β hLo hHi sLo wHi Amax-κd*vHi^4/hLo*cz-dbar*vHi^2) :
    uLo ≤ robustInput H g α β h v w A κd z ∧
      robustInput H g α β h v w A κd z ≤ uHi ∧
      0 ≤ pickup (α+d) v (robustInput H g α β h v w A κd z) := by
  have hD := damping_bound hκd hhLo hh.1 hv.2 hz
  have hF := force_box_bounds hH hg ha hb hhLo hh hv hw hs hA hD
  have hP := tension_box_bound (α:=α) hH hg hb hhLo hh hv.2 hw hs.1 hA hD hd
  exact ⟨hL.trans hF.1,hF.2.trans hU,hT.trans hP⟩

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Real

def heightError (h r : ℝ → ℝ) (t : ℝ) := h t-r t
def velocityError (k₁ : ℝ) (h v w r r₁ : ℝ → ℝ) (t : ℝ) :=
  v t-w t-2*r₁ t+2*k₁*(h t-r t)
def requestedInput (H g α β k₀ k₁ k₂ κd : ℝ)
    (h v w r r₁ r₂ : ℝ → ℝ) (t : ℝ) :=
  robustInput H g α β (h t) (v t) (w t)
    (acceleration k₀ k₁ k₂ (heightError h r t) (heightRate (v t) (w t)) (r₁ t) (r₂ t))
    κd (velocityError k₁ h v w r r₁ t)

/-- The coordinate change is proved using derivatives of the mechanical states,
not imposed as an independent error-system axiom. -/
theorem closed_loop_error_equations {H g α β k₀ k₁ k₂ κd d t : ℝ}
    {h v w r r₁ r₂ : ℝ → ℝ}
    (hh : h t ≠ 0) (hH : H+h t ≠ 0)
    (dh : HasDerivAt h (heightRate (v t) (w t)) t)
    (dv : HasDerivAt v (rise g (α+d) (h t) (v t) (w t)
      (requestedInput H g α β k₀ k₁ k₂ κd h v w r r₁ r₂ t)) t)
    (dw : HasDerivAt w (fall H g β (h t) (v t) (w t)) t)
    (dr : HasDerivAt r (r₁ t) t) (dr₁ : HasDerivAt r₁ (r₂ t) t) :
    HasDerivAt (heightError h r)
      (errorRate k₁ (heightError h r t) (velocityError k₁ h v w r r₁ t)) t ∧
    HasDerivAt (velocityError k₁ h v w r r₁)
      (zRate k₀ k₂ κd ((v t)^2/h t) d (heightError h r t)
        (velocityError k₁ h v w r r₁ t)) t := by
  have he : HasDerivAt (heightError h r) (heightRate (v t) (w t)-r₁ t) t := dh.sub dr
  refine ⟨?_, ?_⟩
  · convert! he using 1
    exact (transformed_error_rate k₁ (h t) (r t) (v t) (w t) (r₁ t)).symm
  · have hz := ((dv.sub dw).sub (dr₁.const_mul 2)).add (he.const_mul (2*k₁))
    have ha := robust_acceleration H g α β (h t) (v t) (w t)
      (acceleration k₀ k₁ k₂ (heightError h r t) (heightRate (v t) (w t)) (r₁ t) (r₂ t))
      κd (velocityError k₁ h v w r r₁ t) d hh hH
    have heq : velocityError k₁ h v w r r₁ t =
        2*(heightRate (v t) (w t)-r₁ t+k₁*heightError h r t) := by
      unfold velocityError heightRate heightError; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    have halg := transformed_z_rate k₀ k₁ k₂ (heightError h r t)
      (heightRate (v t) (w t)) (r₁ t) (r₂ t) κd ((v t)^2/h t) d
      (velocityError k₁ h v w r r₁ t) heq
    convert! hz using 1
    unfold requestedInput
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [ha,halg]

/-- Theorem 7.1's tracking estimate starting from the actual controlled ODE.
Existence and differentiability on the stated interval are explicit hypotheses. -/
theorem mechanical_tracking_estimate {H g α β k₀ k₁ k₂ κ κd dbar T : ℝ}
    {h v w r r₁ r₂ d : ℝ → ℝ}
    (hk₀ : 0 ≤ k₀) (hκ : 0 < κ) (hk₁ : κ ≤ k₁) (hk₂ : κ ≤ k₂) (hκd : 0 < κd)
    (hh : ∀ t ∈ Icc 0 T, h t ≠ 0) (hH : ∀ t ∈ Icc 0 T, H+h t ≠ 0)
    (dh : ∀ t ∈ Icc 0 T, HasDerivAt h (heightRate (v t) (w t)) t)
    (dv : ∀ t ∈ Icc 0 T, HasDerivAt v (rise g (α+d t) (h t) (v t) (w t)
      (requestedInput H g α β k₀ k₁ k₂ κd h v w r r₁ r₂ t)) t)
    (dw : ∀ t ∈ Icc 0 T, HasDerivAt w (fall H g β (h t) (v t) (w t)) t)
    (dr : ∀ t ∈ Icc 0 T, HasDerivAt r (r₁ t) t)
    (dr₁ : ∀ t ∈ Icc 0 T, HasDerivAt r₁ (r₂ t) t)
    (hdb : ∀ t ∈ Ico 0 T, |d t| ≤ dbar) :
    ∀ t ∈ Icc 0 T,
      errorEnergy k₀ (heightError h r t) (velocityError k₁ h v w r r₁ t) ≤
      exp (-2*κ*t) * errorEnergy k₀ (heightError h r 0) (velocityError k₁ h v w r r₁ 0) +
        dbar^2/(16*κ*κd)*(1-exp (-2*κ*t)) := by
  have heq := fun t ht => closed_loop_error_equations (hh t ht) (hH t ht)
    (dh t ht) (dv t ht) (dw t ht) (dr t ht) (dr₁ t ht)
  exact robust_error_estimate hk₀ hκ hk₁ hk₂ hκd
    (fun t ht => (heq t ht).1) (fun t ht => (heq t ht).2) hdb

/-- Converts the weighted error bound into the height and rate box used by the
invariance proof. No bounds on either transport velocity are assumed here. -/
theorem trajectory_enclosure {k₀ k₁ cap rlo rhi R₁ : ℝ}
    {h v w r r₁ : ℝ → ℝ} {t : ℝ}
    (hk₀ : 0 < k₀)
    (hV : errorEnergy k₀ (heightError h r t) (velocityError k₁ h v w r r₁ t) ≤ cap)
    (hr : rlo ≤ r t ∧ r t ≤ rhi) (hr₁ : |r₁ t| ≤ R₁) :
    rlo-sqrt (2*cap/k₀) ≤ h t ∧ h t ≤ rhi+sqrt (2*cap/k₀) ∧
      |heightRate (v t) (w t)| ≤ R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀) := by
  obtain ⟨he,_,hq⟩ := error_enclosure (k₁:=k₁) hk₀ hV
  have hhb := height_enclosure hr he
  have hid : velocityError k₁ h v w r r₁ t/2 - k₁*heightError h r t =
      heightRate (v t) (w t)-r₁ t := by unfold velocityError heightError heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [hid] at hq
  exact ⟨hhb.1,hhb.2,q_enclosure hr₁ hq⟩

/-- Connects the state speed to the internal Riccati equation without assuming v=w. -/
theorem mechanical_internal_equation {h v w : ℝ → ℝ} {H g β t : ℝ}
    (hden : H+h t ≠ 0)
    (hw : HasDerivAt w (fall H g β (h t) (v t) (w t)) t) :
    HasDerivAt w (internal H g β (h t) (w t) (heightRate (v t) (w t))) t := by
  have hcoord : w t+2*heightRate (v t) (w t) = v t := by unfold heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have heq := internal_identity H g β (h t) (w t) (heightRate (v t) (w t)) hden
  rw [hcoord] at heq
  rwa [←heq]

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Real

/-- Data of an existing classical solution. Fields are modelling/regularity
assumptions only; no tracking, safety, or convergence conclusion is a field. -/
structure ClassicalSolution (H g α β k₀ k₁ k₂ κd T : ℝ) where
  h : ℝ → ℝ
  v : ℝ → ℝ
  w : ℝ → ℝ
  r : ℝ → ℝ
  r₁ : ℝ → ℝ
  r₂ : ℝ → ℝ
  d : ℝ → ℝ
  h_ne : ∀ t ∈ Icc 0 T, h t ≠ 0
  Hh_ne : ∀ t ∈ Icc 0 T, H+h t ≠ 0
  dh : ∀ t ∈ Icc 0 T, HasDerivAt h (heightRate (v t) (w t)) t
  dv : ∀ t ∈ Icc 0 T, HasDerivAt v (rise g (α+d t) (h t) (v t) (w t)
    (requestedInput H g α β k₀ k₁ k₂ κd h v w r r₁ r₂ t)) t
  dw : ∀ t ∈ Icc 0 T, HasDerivAt w (fall H g β (h t) (v t) (w t)) t
  dr : ∀ t ∈ Icc 0 T, HasDerivAt r (r₁ t) t
  dr₁ : ∀ t ∈ Icc 0 T, HasDerivAt r₁ (r₂ t) t

def ClassicalSolution.V {H g α β k₀ k₁ k₂ κd T : ℝ}
    (sol : ClassicalSolution H g α β k₀ k₁ k₂ κd T) (t : ℝ) :=
  errorEnergy k₀ (heightError sol.h sol.r t) (velocityError k₁ sol.h sol.v sol.w sol.r sol.r₁ t)

theorem ClassicalSolution.energy_bound {H g α β k₀ k₁ k₂ κ κd dbar T : ℝ}
    (sol : ClassicalSolution H g α β k₀ k₁ k₂ κd T)
    (hk₀ : 0 ≤ k₀) (hκ : 0 < κ) (hk₁ : κ ≤ k₁) (hk₂ : κ ≤ k₂) (hκd : 0 < κd)
    (hdb : ∀ t ∈ Ico 0 T, |sol.d t| ≤ dbar) :
    ∀ t ∈ Icc 0 T, sol.V t ≤ exp (-2*κ*t)*sol.V 0+
      dbar^2/(16*κ*κd)*(1-exp (-2*κ*t)) :=
  mechanical_tracking_estimate hk₀ hκ hk₁ hk₂ hκd sol.h_ne sol.Hh_ne
    sol.dh sol.dv sol.dw sol.dr sol.dr₁ hdb

/-- Composed, finite-interval robust physical-region theorem. The energy cap is
derived from the controlled ODE rather than assumed along the trajectory.
Global existence, measurable-input extensions, and nonideal actuators are not
conclusions of this statement. -/
theorem ClassicalSolution.physical_region
    {H g α β k₀ k₁ k₂ κ κd dbar T cap rlo rhi R₁ wlo whi vmin : ℝ}
    (sol : ClassicalSolution H g α β k₀ k₁ k₂ κd T)
    (hH : 0 < H) (hg : 0 ≤ g) (hk₀ : 0 < k₀)
    (hκ : 0 < κ) (hk₁ : κ ≤ k₁) (hk₂ : κ ≤ k₂) (hκd : 0 < κd)
    (hdb : ∀ t ∈ Ico 0 T, |sol.d t| ≤ dbar)
    (hinit : sol.V 0 ≤ cap) (hcap : dbar^2/(16*κ*κd) ≤ cap)
    (hr : ∀ t ∈ Icc 0 T, rlo ≤ sol.r t ∧ sol.r t ≤ rhi)
    (hr₁ : ∀ t ∈ Icc 0 T, |sol.r₁ t| ≤ R₁)
    (hpositive : 0 < rlo-sqrt (2*cap/k₀))
    (hforward : 2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀)) < wlo)
    (horder : wlo ≤ whi)
    (hcrown : vmin ≤ wlo-(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀)))
    (hl : (1-β)*wlo^2+2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))*wlo+
      (R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))^2 ≤ g*(H+(rlo-sqrt (2*cap/k₀))))
    (hu : g*(H+(rhi+sqrt (2*cap/k₀))) ≤ (1-β)*whi^2-
      2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))*whi+(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))^2)
    (hw₀ : wlo ≤ sol.w 0 ∧ sol.w 0 ≤ whi) :
    ∀ t ∈ Icc 0 T, sol.V t ≤ cap ∧
      0 < sol.h t ∧ wlo ≤ sol.w t ∧ sol.w t ≤ whi ∧
      0 < sol.v t ∧ vmin ≤ (sol.v t+sol.w t)/2 := by
  have hE := sol.energy_bound hk₀.le hκ hk₁ hk₂ hκd hdb
  have hEC : ∀ t ∈ Icc 0 T, sol.V t ≤ cap := by
    intro t ht
    have henv := envelope_below_cap (C:=dbar^2/(8*κd)) hκ ht.1 hinit
      (by convert! hcap using 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring)
    have he : sol.V t ≤ envelope (sol.V 0) κ (dbar^2/(8*κd)) t := by
      convert! hE t ht using 1; unfold envelope; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    exact he.trans henv
  have hbox := fun t ht => trajectory_enclosure hk₀ (hEC t ht) (hr t ht) (hr₁ t ht)
  have hhc : ContinuousOn sol.h (Icc 0 T) := fun t ht => (sol.dh t ht).continuousAt.continuousWithinAt
  have hwc : ContinuousOn sol.w (Icc 0 T) := fun t ht => (sol.dw t ht).continuousAt.continuousWithinAt
  have hvc : ContinuousOn sol.v (Icc 0 T) := fun t ht => (sol.dv t ht).continuousAt.continuousWithinAt
  have hqc : ContinuousOn (fun t => heightRate (sol.v t) (sol.w t)) (Icc 0 T) :=
    (hvc.sub hwc).div_const 2
  have hK (b : ℝ) : ContinuousOn
      (fun t => -((1-β)*(sol.w t+b)+2*heightRate (sol.v t) (sol.w t))/(H+sol.h t)) (Icc 0 T) :=
    ((continuousOn_const.mul (hwc.add continuousOn_const)).add
      (continuousOn_const.mul hqc)).neg.div (continuousOn_const.add hhc) sol.Hh_ne
  have hphys := physical_region_invariant hH hg hpositive
    (fun t ht => (sol.dw t ht).continuousAt.continuousWithinAt)
    (fun t ht => (mechanical_internal_equation (sol.Hh_ne t (Ico_subset_Icc_self ht))
      (sol.dw t (Ico_subset_Icc_self ht))).hasDerivWithinAt)
    (hK wlo) (hK whi) (fun t ht => ⟨(hbox t ht).1,(hbox t ht).2.1⟩)
    (fun t ht => (hbox t ht).2.2) hforward horder hcrown hl hu hw₀
  intro t ht
  obtain ⟨hh,hwlo,hwhi,hv,hc⟩ := hphys t ht
  have hvId : sol.w t+2*heightRate (sol.v t) (sol.w t) = sol.v t := by unfold heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hsId : sol.w t+heightRate (sol.v t) (sol.w t) = (sol.v t+sol.w t)/2 := by unfold heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [hvId] at hv; rw [hsId] at hc
  exact ⟨hEC t ht,hh,hwlo,hwhi,hv,hc⟩

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Real MeasureTheory

/-- Equation (7.5), integrated via the fundamental theorem of calculus.
Interval integrability and classical derivatives are explicit, not placeholders
for the estimate being proved. The weighted error norm squared equals 2V. -/
theorem weighted_integral_estimate {V V' d : ℝ → ℝ} {T κ κd : ℝ}
    (hT : 0 ≤ T) (hκ : 0 < κ) (hκd : 0 < κd)
    (hV : IntervalIntegrable V volume 0 T)
    (hVp : IntervalIntegrable V' volume 0 T)
    (hd : IntervalIntegrable (fun t => d t ^ 2) volume 0 T)
    (hder : ∀ t ∈ Icc 0 T, HasDerivAt V (V' t) t)
    (hbound : ∀ t ∈ Icc 0 T, V' t ≤ -2*κ*V t+d t^2/(8*κd))
    (hVT : 0 ≤ V T) :
    (∫ t in (0 : ℝ)..T, 2*V t) ≤
      V 0/κ + (1/(8*κ*κd))*(∫ t in (0 : ℝ)..T, d t^2) := by
  have hi := intervalIntegral.integral_mono_on hT hVp
    ((hV.const_mul (-2*κ)).add (hd.div_const (8*κd))) hbound
  have hFTC : (∫ t in (0 : ℝ)..T, V' t) = V T-V 0 := by
    apply intervalIntegral.integral_eq_sub_of_hasDerivAt _ hVp
    simpa only [uIcc_of_le hT] using hder
  rw [hFTC, intervalIntegral.integral_add (hV.const_mul (-2*κ)) (hd.div_const (8*κd)),
    intervalIntegral.integral_const_mul,intervalIntegral.integral_div] at hi
  rw [intervalIntegral.integral_const_mul]
  apply (mul_le_mul_iff_right₀ hκ).mp
  have hc₁ : κ*(V 0/κ) = V 0 := by field_simp
  have hc₂ : κ*(1/(8*κ*κd)) = 1/(8*κd) := by field_simp <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hc₃ : κ*(1/(8*κ*κd)*(∫ t in (0 : ℝ)..T, d t^2)) =
      (∫ t in (0 : ℝ)..T, d t^2)/(8*κd) := by
    rw [←mul_assoc, hc₂]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [mul_add, hc₁, hc₃]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hi]

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Real

def quintic (x : ℝ) := 10*x^3-15*x^4+6*x^5
def quinticRate (x : ℝ) := 30*x^2*(1-x)^2
def quinticAcceleration (x : ℝ) := 60*x*(1-x)*(1-2*x)

theorem quintic_derivative (x : ℝ) : HasDerivAt quintic (quinticRate x) x := by
  convert! (((hasDerivAt_id x).pow 3).const_mul 10).sub
    (((hasDerivAt_id x).pow 4).const_mul 15) |>.add
    (((hasDerivAt_id x).pow 5).const_mul 6) using 1
  simp only [id_eq]; unfold quinticRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> ring

theorem quintic_second_derivative (x : ℝ) :
    HasDerivAt quinticRate (quinticAcceleration x) x := by
  convert! (((hasDerivAt_id x).pow 2).const_mul 30).mul
    (((hasDerivAt_id x).const_sub 1).pow 2) using 1
  simp only [id_eq]; unfold quinticAcceleration; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> ring

theorem quintic_endpoint_data :
    quintic 0=0 ∧ quintic 1=1 ∧ quinticRate 0=0 ∧ quinticRate 1=0 ∧
      quinticAcceleration 0=0 ∧ quinticAcceleration 1=0 := by
  norm_num [quintic,quinticRate,quinticAcceleration]

theorem quintic_rate_bound {x : ℝ} (hx : 0 ≤ x ∧ x ≤ 1) :
    |quinticRate x| ≤ 15/8 := by
  have hprod : 0 ≤ x*(1-x) := mul_nonneg hx.1 (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> linarith)
  have hprodU : x*(1-x) ≤ 1/4 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> nlinarith [sq_nonneg (x-1/2)]
  have hsq := pow_le_pow_left₀ hprod hprodU 2
  unfold quinticRate
  rw [abs_of_nonneg (by positivity)]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> nlinarith [hsq]

theorem quintic_acceleration_bound {x : ℝ} (hx : 0 ≤ x ∧ x ≤ 1) :
    |quinticAcceleration x| ≤ 10/sqrt 3 := by
  have hy : (1-2*x)^2 ≤ 1 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> nlinarith
  have hpos : 0 ≤ (4/3 : ℝ)-(1-2*x)^2 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> linarith
  have hp : 0 ≤ (225 : ℝ)*(4/3-(1-2*x)^2)*((1-2*x)^2-1/3)^2 := by positivity
  have hi : (100/3 : ℝ)-(quinticAcceleration x)^2 =
      225*(4/3-(1-2*x)^2)*((1-2*x)^2-1/3)^2 := by unfold quinticAcceleration; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> ring
  have hs : (quinticAcceleration x)^2 ≤ 100/3 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> linarith
  have hroot : sqrt (3 : ℝ)^2=3 := sq_sqrt (by norm_num)
  have hroot0 : 0 < sqrt (3 : ℝ) := sqrt_pos.mpr (by norm_num)
  apply (le_div_iff₀ hroot0).mpr
  have habs := sq_abs (quinticAcceleration x)
  have hm := mul_le_mul_of_nonneg_right hs (show 0 ≤ (3 : ℝ) by norm_num)
  have hneg := abs_nonneg (quinticAcceleration x)
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply,id_eq] at *) <;> nlinarith [sq_nonneg (|quinticAcceleration x| * sqrt 3-10)]

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Real

/-- A checked comparison for a stable scalar equation with exponentially
decaying forcing. The constant M is an explicit supersolution amplitude. -/
theorem scalar_exponential_decay {y a f : ℝ → ℝ} {T ρ δ M : ℝ}
    (ha : ContinuousOn a (Icc 0 T))
    (hy : ContinuousOn y (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt y (-a t*y t+f t) (Ici t) t)
    (hM : 0 ≤ M)
    (hdecay : ∀ t ∈ Ico 0 T, ρ+δ ≤ a t)
    (hforce : ∀ t ∈ Ico 0 T, |f t| ≤ δ*M*exp (-ρ*t))
    (hinit : |y 0| ≤ M) :
    ∀ t ∈ Icc 0 T, |y t| ≤ M*exp (-ρ*t) := by
  have hE (t : ℝ) : HasDerivAt (fun s => M*exp (-ρ*s))
      (-ρ*(M*exp (-ρ*t))) t := by
    convert! (((hasDerivAt_id t).const_mul (-ρ)).exp.const_mul M) using 1; simp only [id_eq]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hEc : Continuous (fun t => M*exp (-ρ*t)) := by fun_prop
  have hup := linear_sign_preservation_on ha.neg (hy.sub hEc.continuousOn)
    (fun t ht => (hd t ht).sub (hE t).hasDerivWithinAt) (by
      intro t ht
      have hp := mul_le_mul_of_nonneg_right (hdecay t ht)
        (mul_nonneg hM (exp_pos (-ρ*t)).le)
      have hf := (abs_le.mp (hforce t ht)).2
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith) (by simpa using (sub_nonpos.mpr (abs_le.mp hinit).2))
  have hlo := linear_sign_preservation_on ha.neg (hy.neg.sub hEc.continuousOn)
    (fun t ht => (hd t ht).neg.sub (hE t).hasDerivWithinAt) (by
      intro t ht
      have hp := mul_le_mul_of_nonneg_right (hdecay t ht)
        (mul_nonneg hM (exp_pos (-ρ*t)).le)
      have hf := (abs_le.mp (hforce t ht)).1
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith) (by simpa using (show -y 0-M ≤ 0 by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(abs_le.mp hinit).1]))
  intro t ht
  exact abs_le.mpr ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hlo t ht],by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hup t ht]⟩

/-- Explicit amplitude for every rate strictly below the damping and forcing
rates, including the equal-rate case without a singular convolution formula. -/
theorem forced_exponential_estimate {y a f : ℝ → ℝ} {T a₀ κ ρ F : ℝ}
    (ha : ContinuousOn a (Icc 0 T))
    (hy : ContinuousOn y (Icc 0 T))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt y (-a t*y t+f t) (Ici t) t)
    (hρ : ρ < a₀) (hκ : ρ ≤ κ) (hF : 0 ≤ F)
    (hdecay : ∀ t ∈ Ico 0 T, a₀ ≤ a t)
    (hforce : ∀ t ∈ Ico 0 T, |f t| ≤ F*exp (-κ*t)) :
    ∀ t ∈ Icc 0 T, |y t| ≤ (|y 0|+F/(a₀-ρ))*exp (-ρ*t) := by
  have hδ : 0 < a₀-ρ := sub_pos.mpr hρ
  have hamp : F ≤ (a₀-ρ)*(|y 0|+F/(a₀-ρ)) := by
    have hid : (a₀-ρ)*(F/(a₀-ρ))=F := by field_simp
    rw [mul_add,hid]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_nonneg hδ.le (abs_nonneg (y 0))]
  apply scalar_exponential_decay (δ:=a₀-ρ) ha hy hd (by positivity)
    (by intro t ht; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hdecay t ht])
    (by
      intro t ht
      have he : exp (-κ*t) ≤ exp (-ρ*t) := exp_le_exp.mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [ht.1])
      exact (hforce t ht).trans ((mul_le_mul_of_nonneg_left he hF).trans
        (mul_le_mul_of_nonneg_right hamp (exp_pos _).le)))
    (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [div_nonneg hF hδ.le])

/-- The forcing term in the internal-state equation inherits the tracking rate. -/
theorem internal_forcing_bound {g e q w D D₀ Ce Cq W κ t : ℝ}
    (hD₀ : 0 < D₀) (hD : D₀ ≤ D) (hCe : 0 ≤ Ce) (hCq : 0 ≤ Cq)
    (hW : 0 ≤ W) (hκ : 0 ≤ κ) (ht : 0 ≤ t)
    (he : |e| ≤ Ce*exp (-κ*t)) (hq : |q| ≤ Cq*exp (-κ*t))
    (hw : |w| ≤ W) :
    |(g*e-2*q*w-q^2)/D| ≤
      ((|g| *Ce+2*Cq*W+Cq^2)/D₀)*exp (-κ*t) := by
  have hE0 : 0 ≤ exp (-κ*t) := (exp_pos _).le
  have hE1 : exp (-κ*t) ≤ 1 := exp_le_one_iff.mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith)
  have he' := mul_le_mul_of_nonneg_left he (abs_nonneg g)
  have hq' := mul_le_mul hq hw (abs_nonneg w) (by positivity : 0 ≤ Cq*exp (-κ*t))
  have hq2 : q^2 ≤ Cq^2*exp (-κ*t) := by
    have hq0 : |q| ≤ Cq := hq.trans (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith)
    have hm := mul_le_mul hq hq0 (abs_nonneg q) (by positivity : 0 ≤ Cq*exp (-κ*t))
    rw [←sq, sq_abs] at hm
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
  have hn : |g*e-2*q*w-q^2| ≤ (|g| *Ce+2*Cq*W+Cq^2)*exp (-κ*t) := by
    have h₁ := abs_sub (g*e-2*q*w) (q^2)
    have h₂ := abs_sub (g*e) (2*q*w)
    simp only [abs_mul,abs_of_nonneg (sq_nonneg q),abs_of_nonneg (show (0:ℝ) ≤ 2 by norm_num)] at h₁ h₂
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
  have hDpos : 0 < D := hD₀.trans_le hD
  rw [abs_div,abs_of_pos hDpos]
  calc
    |g*e-2*q*w-q^2|/D ≤ ((|g| *Ce+2*Cq*W+Cq^2)*exp (-κ*t))/D :=
      div_le_div_of_nonneg_right hn hDpos.le
    _ ≤ ((|g| *Ce+2*Cq*W+Cq^2)*exp (-κ*t))/D₀ :=
      div_le_div_of_nonneg_left (by positivity) hD₀ hD
    _ = _ := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- Exponential energy decay yields exponential coordinate bounds, with exact
constants from the weighted energy ellipsoid. -/
theorem error_decay_enclosure {k₀ k₁ e z V₀ κ t : ℝ} (hk : 0 < k₀)
    (hV₀ : 0 ≤ V₀)
    (hV : errorEnergy k₀ e z ≤ exp (-2*κ*t)*V₀) :
    |e| ≤ sqrt (2*V₀/k₀)*exp (-κ*t) ∧
    |z/2-k₁*e| ≤ (sqrt (2*V₀)*sqrt (1+k₁^2/k₀))*exp (-κ*t) := by
  have he := error_height_sq hk hV
  have hq := error_q_sq (k₁:=k₁) hk hV
  have hexp : exp (-κ*t)^2=exp (-2*κ*t) := by rw [sq,←exp_add]; congr 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hs₁ : sqrt (2*V₀/k₀)^2=2*V₀/k₀ := sq_sqrt (by positivity)
  have hs₂ : sqrt (2*V₀)^2=2*V₀ := sq_sqrt (by positivity)
  have hs₃ : sqrt (1+k₁^2/k₀)^2=1+k₁^2/k₀ := sq_sqrt (by positivity)
  constructor
  · apply abs_le_of_sq_le_sq _ (by positivity)
    rw [mul_pow,hs₁,hexp]
    convert! he using 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  · apply abs_le_of_sq_le_sq _ (by positivity)
    rw [mul_pow,mul_pow,hs₂,hs₃,hexp]
    convert! hq using 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- Constant-reference internal-speed convergence on an existing classical
trajectory. Geometric bounds come from the physical-region theorem; e and q
decay bounds come from error_decay_enclosure and nominal tracking. -/
theorem internal_exponential_estimate {h w q : ℝ → ℝ}
    {H g β r wr T hlo hhi wlo whi Ce Cq κ ρ : ℝ}
    (hhc : ContinuousOn h (Icc 0 T)) (hwc : ContinuousOn w (Icc 0 T))
    (hHlo : 0 < H+hlo) (hβ : β < 1) (hwr : 0 ≤ wr) (hwlo : 0 < wlo)
    (hCe : 0 ≤ Ce) (hCq : 0 ≤ Cq) (hκ : 0 ≤ κ)
    (hh : ∀ t ∈ Icc 0 T, hlo ≤ h t ∧ h t ≤ hhi)
    (hw : ∀ t ∈ Icc 0 T, wlo ≤ w t ∧ w t ≤ whi)
    (heq : (1-β)*wr^2=g*(H+r))
    (hd : ∀ t ∈ Ico 0 T, HasDerivWithinAt w (internal H g β (h t) (w t) (q t)) (Ici t) t)
    (he : ∀ t ∈ Ico 0 T, |h t-r| ≤ Ce*exp (-κ*t))
    (hq : ∀ t ∈ Ico 0 T, |q t| ≤ Cq*exp (-κ*t))
    (hρ : ρ < (1-β)*(wlo+wr)/(H+hhi)) (hρκ : ρ ≤ κ) :
    ∀ t ∈ Icc 0 T, |w t-wr| ≤
      (|w 0-wr|+((|g| *Ce+2*Cq*whi+Cq^2)/(H+hlo))/
        ((1-β)*(wlo+wr)/(H+hhi)-ρ))*exp (-ρ*t) := by
  by_cases hT : 0 ≤ T
  · have hb : 0 < 1-β := sub_pos.mpr hβ
    have hD (t) (ht : t ∈ Icc 0 T) : 0 < H+h t := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hh t ht).1]
    have hDhi : 0 < H+hhi := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hh 0 ⟨le_refl 0,hT⟩).1,(hh 0 ⟨le_refl 0,hT⟩).2]
    have hwhi : 0 ≤ whi := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hw 0 ⟨le_refl 0,hT⟩).1,(hw 0 ⟨le_refl 0,hT⟩).2]
    let a : ℝ → ℝ := fun t => (1-β)*(w t+wr)/(H+h t)
    let f : ℝ → ℝ := fun t => (g*(h t-r)-2*q t*w t-q t^2)/(H+h t)
    have ha : ContinuousOn a (Icc 0 T) :=
      (continuousOn_const.mul (hwc.add continuousOn_const)).div
        (continuousOn_const.add hhc) (fun t ht => (hD t ht).ne')
    have hder : ∀ t ∈ Ico 0 T, HasDerivWithinAt (fun t => w t-wr)
        (-a t*(w t-wr)+f t) (Ici t) t := by
      intro t ht
      have hi := fullstate_forcing_identity H g β r (h t-r) (q t) (w t) wr
        (by simpa only [add_sub_cancel] using (hD t (Ico_subset_Icc_self ht)).ne') heq
      simp only [add_sub_cancel] at hi
      convert! (hd t ht).sub_const wr using 1
      simpa only [sub_zero,a,f,neg_mul,neg_div] using hi.symm
    apply forced_exponential_estimate ha (hwc.sub continuousOn_const) hder hρ hρκ
      (by positivity)
    · intro t ht
      have htt := Ico_subset_Icc_self ht
      apply (div_le_div_iff₀ hDhi (hD t htt)).mpr
      have h₁ := mul_le_mul_of_nonneg_left (show H+h t ≤ H+hhi by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hh t htt).2])
        (show 0 ≤ (1-β)*(wlo+wr) by positivity)
      have h₂ := mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_left (show wlo+wr ≤ w t+wr by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hw t htt).1])
          (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith : 0 ≤ 1-β)) hDhi.le
      exact h₁.trans h₂
    · intro t ht
      have htt := Ico_subset_Icc_self ht
      exact internal_forcing_bound hHlo (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hh t htt).1]) hCe hCq hwhi hκ ht.1
        (he t ht) (hq t ht) (by rw [abs_of_pos (hwlo.trans_le (hw t htt).1)]; exact (hw t htt).2)
  · intro t ht; exact False.elim (hT (ht.1.trans ht.2))

/-- The rising speed inherits the slower internal/error decay rate. -/
theorem rising_speed_decay {w q wr M Cq κ ρ t : ℝ}
    (hCq : 0 ≤ Cq) (ht : 0 ≤ t) (hρκ : ρ ≤ κ)
    (hw : |w-wr| ≤ M*exp (-ρ*t)) (hq : |q| ≤ Cq*exp (-κ*t)) :
    |w+2*q-wr| ≤ (M+2*Cq)*exp (-ρ*t) := by
  have he : exp (-κ*t) ≤ exp (-ρ*t) := exp_le_exp.mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith)
  have hq' := hq.trans (mul_le_mul_of_nonneg_left he hCq)
  have ha := abs_add_le (w-wr) (2*q)
  simp only [abs_mul,abs_of_nonneg (show (0:ℝ) ≤ 2 by norm_num)] at ha
  have hid : w-wr+2*q=w+2*q-wr := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [hid] at ha
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith

/-- Full-state exponential convergence for a supplied global classical
trajectory. This composes the internal-speed estimate with the tracking bounds;
it does not assert that such a global trajectory has been constructed. -/
theorem constant_reference_fullstate_convergence {h w q : ℝ → ℝ}
    {H g β r wr hlo hhi wlo whi Ce Cq κ ρ : ℝ}
    (hhc : ContinuousOn h (Ici 0)) (hwc : ContinuousOn w (Ici 0))
    (hHlo : 0 < H+hlo) (hβ : β < 1) (hwr : 0 ≤ wr) (hwlo : 0 < wlo)
    (hCe : 0 ≤ Ce) (hCq : 0 ≤ Cq) (hρ0 : 0 < ρ)
    (hh : ∀ t ∈ Ici 0, hlo ≤ h t ∧ h t ≤ hhi)
    (hw : ∀ t ∈ Ici 0, wlo ≤ w t ∧ w t ≤ whi)
    (heq : (1-β)*wr^2=g*(H+r))
    (hd : ∀ t ∈ Ici 0, HasDerivAt w (internal H g β (h t) (w t) (q t)) t)
    (he : ∀ t ∈ Ici 0, |h t-r| ≤ Ce*exp (-κ*t))
    (hq : ∀ t ∈ Ici 0, |q t| ≤ Cq*exp (-κ*t))
    (hρ : ρ < (1-β)*(wlo+wr)/(H+hhi)) (hρκ : ρ ≤ κ) :
    let M := |w 0-wr|+((|g| * Ce+2*Cq*whi+Cq^2)/(H+hlo))/
      ((1-β)*(wlo+wr)/(H+hhi)-ρ)
    0 < ρ ∧ ∀ t ∈ Ici 0,
      |h t-r| ≤ Ce*exp (-ρ*t) ∧
      |w t-wr| ≤ M*exp (-ρ*t) ∧
      |w t+2*q t-wr| ≤ (M+2*Cq)*exp (-ρ*t) := by
  dsimp only
  refine ⟨hρ0,?_⟩
  intro t ht
  have hb := internal_exponential_estimate (T:=t)
    (hhc.mono (fun _ hx => hx.1)) (hwc.mono (fun _ hx => hx.1))
    hHlo hβ hwr hwlo hCe hCq (hρ0.le.trans hρκ)
    (fun s hs => hh s hs.1) (fun s hs => hw s hs.1) heq
    (fun s hs => (hd s hs.1).hasDerivWithinAt)
    (fun s hs => he s hs.1) (fun s hs => hq s hs.1) hρ hρκ t ⟨ht,le_refl t⟩
  have heE : exp (-κ*t) ≤ exp (-ρ*t) := exp_le_exp.mpr (by
    have ht0 : 0 ≤ t := ht
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith)
  exact ⟨(he t ht).trans (mul_le_mul_of_nonneg_left heE hCe),hb,
    rising_speed_decay hCq ht hρκ hb (hq t ht)⟩

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Metric Filter
open scoped Topology NNReal

/-- Construct a global classical solution of a bounded vector field which is
uniformly Lipschitz in the state and continuous in time. Picard--Lindelof is
applied on every finite interval; uniqueness makes the resulting curves agree.
No solution is included among the hypotheses. -/
theorem bounded_lipschitz_global_exists
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    {F : ℝ → E → E} {L : ℝ≥0} {C : ℝ}
    (hL : ∀ t, LipschitzWith L (F t))
    (hcont : ∀ x, Continuous (fun t => F t x))
    (hC : ∀ t x, ‖F t x‖ ≤ C) (x₀ : E) :
    ∃ x : ℝ → E, x 0 = x₀ ∧ ∀ t, HasDerivAt x (F t (x t)) t := by
  have hC0 : 0 ≤ C := (norm_nonneg _).trans (hC 0 x₀)
  have hex (a : ℝ) : ∃ x : ℝ → E, x 0 = x₀ ∧
      ∀ t ∈ Ioo (-a) a, HasDerivAt x (F t (x t)) t := by
    by_cases ha : 0 < a
    · let t₀ : Icc (-a) a := ⟨0,by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith,ha.le⟩
      have hp : IsPicardLindelof F t₀ x₀ ⟨C*a,mul_nonneg hC0 ha.le⟩ 0 ⟨C,hC0⟩ L :=
        { lipschitzOnWith := fun t _ => (hL t).lipschitzOnWith
          continuousOn := fun x _ => (hcont x).continuousOn
          norm_le := fun t _ x _ => hC t x
          mul_max_le := by simp [t₀]; exact le_rfl }
      obtain ⟨x,hx,hd⟩ := hp.exists_eq_forall_mem_Icc_hasDerivWithinAt₀
      exact ⟨x,hx,fun t ht => (hd t (Ioo_subset_Icc_self ht)).hasDerivAt
        (Icc_mem_nhds ht.1 ht.2)⟩
    · exact ⟨fun _ => x₀,rfl,fun t ht => False.elim (ha (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [ht.1,ht.2]))⟩
  choose f hf hd using hex
  have agree {a b : ℝ} (ha : 0 < a) (hab : a ≤ b) :
      EqOn (f a) (f b) (Ioo (-a) a) := by
    apply ODE_solution_unique_of_mem_Ioo (s:=fun _ => univ)
      (fun t _ => (hL t).lipschitzOnWith) (t₀:=0) ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith,ha⟩
      (fun t ht => ⟨hd a t ht, mem_univ _⟩)
      (fun t ht => ⟨hd b t ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [ht.1],lt_of_lt_of_le ht.2 hab⟩,mem_univ _⟩)
    rw [hf a,hf b]
  let x : ℝ → E := fun t => f (|t|+1) t
  have heq (a : ℝ) : EqOn x (f a) (Ioo (-a) a) := by
    intro t ht
    by_cases hlt : |t|+1 < a
    · exact agree (by positivity) hlt.le (abs_lt.mp (lt_add_one _))
    · exact (agree (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [ht.1,ht.2]) (not_lt.mp hlt) ht).symm
  refine ⟨x,by simp [x,hf],?_⟩
  intro t
  have ht : t ∈ Ioo (-(|t|+1)) (|t|+1) := abs_lt.mp (lt_add_one _)
  have hevent : x =ᶠ[𝓝 t] f (|t|+1) :=
    Filter.eventuallyEq_iff_exists_mem.mpr
      ⟨Ioo (-(|t|+1)) (|t|+1),Ioo_mem_nhds ht.1 ht.2,heq _⟩
  rw [heq _ ht]
  exact (hd _ t ht).congr_of_eventuallyEq hevent

/-- A first-exit argument with a closed outer set and an interior target.
The supplied implication must be an a priori estimate on *every* finite
prefix, not an assumption that the constructed curve is safe. -/
theorem no_exit_of_prefix_bound
    {E : Type*} [TopologicalSpace E] {x : ℝ → E} {B K : Set E}
    (hx : Continuous x) (hB : IsClosed B) (hKB : K ⊆ interior B)
    (hx₀ : x 0 ∈ interior B)
    (hprefix : ∀ T ≥ 0, (∀ t ∈ Icc 0 T, x t ∈ B) → x T ∈ K) :
    ∀ t ≥ 0, x t ∈ K := by
  have hstay : ∀ T ≥ 0, ∀ t ∈ Icc 0 T, x t ∈ interior B := by
    intro T hT
    by_contra hn
    push_neg at hn
    let S := Icc 0 T ∩ x ⁻¹' (interior B)ᶜ
    have hS : IsCompact S := isCompact_Icc.inter_right
      (isOpen_interior.isClosed_compl.preimage hx)
    have hSne : S.Nonempty := by
      obtain ⟨t,ht,hxt⟩ := hn
      exact ⟨t,ht,hxt⟩
    obtain ⟨a,ha,hle⟩ := hS.exists_isLeast hSne
    have ha0 : 0 < a := lt_of_le_of_ne ha.1.1 (by
      intro hh; subst a; exact ha.2 hx₀)
    have hbefore : ∀ t ∈ Ico 0 a, x t ∈ interior B := by
      intro t ht
      by_contra hnot
      have := hle (show t ∈ S from ⟨⟨ht.1,ht.2.le.trans ha.1.2⟩,hnot⟩)
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [ht.2]
    have hclosed : ∀ t ∈ Icc 0 a, x t ∈ B := by
      intro t ht
      have hsub : Ico 0 a ⊆ x ⁻¹' B := fun s hs => (interior_subset (s:=B)) (hbefore s hs)
      have hc := closure_minimal hsub (hB.preimage hx)
      rw [closure_Ico ha0.ne] at hc
      exact hc ht
    exact ha.2 (hKB (hprefix a ha.1.1 hclosed))
  intro t ht
  exact hprefix t ht (fun s hs => interior_subset (hstay t ht s hs))

/-- Global construction from a bounded Lipschitz extension and a proved
finite-prefix estimate. The retraction is only used in the construction;
the resulting forward trajectory solves the original vector field. -/
theorem global_exists_of_retraction_and_prefix
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    {F : ℝ → E → E} {B K : Set E} {P : E → E} {L : ℝ≥0} {C : ℝ}
    (hB : IsClosed B) (hKB : K ⊆ interior B)
    (hP : LipschitzWith 1 P) (hPB : ∀ x, P x ∈ B)
    (hPid : ∀ x ∈ B, P x = x)
    (hL : ∀ t, LipschitzOnWith L (F t) B)
    (hcont : ∀ x ∈ B, Continuous (fun t => F t x))
    (hC : ∀ t x, x ∈ B → ‖F t x‖ ≤ C)
    (x₀ : E) (hx₀ : x₀ ∈ interior B)
    (hprefix : ∀ (x : ℝ → E) T, 0 ≤ T → x 0 = x₀ →
      (∀ t ∈ Icc 0 T, x t ∈ B) →
      (∀ t ∈ Icc 0 T, HasDerivAt x (F t (x t)) t) → x T ∈ K) :
    ∃ x : ℝ → E, x 0 = x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (F t (x t)) t) ∧ ∀ t ≥ 0, x t ∈ K := by
  have hLp : ∀ t, LipschitzWith L (fun x => F t (P x)) := by
    intro t
    have hh := (hL t).comp (hP.lipschitzOnWith (s:=univ)) (fun x _ => hPB x)
    simpa only [mul_one, lipschitzOnWith_univ, Function.comp_def] using hh
  obtain ⟨x,hx₀',hd⟩ := bounded_lipschitz_global_exists hLp
    (fun x => hcont (P x) (hPB x)) (fun t x => hC t (P x) (hPB x)) x₀
  have hx : Continuous x := continuous_iff_continuousAt.mpr (fun t => (hd t).continuousAt)
  have hstay := no_exit_of_prefix_bound hx hB hKB (hx₀' ▸ hx₀) (by
    intro T hT hxb
    exact hprefix x T hT hx₀' hxb (fun t ht => by
      simpa only [hPid (x t) (hxb t ht)] using hd t))
  exact ⟨x,hx₀',fun t ht => by
    simpa only [hPid (x t) (interior_subset (hKB (hstay t ht)))] using hd t,hstay⟩

/-- Smoothness on an open domain supplies quantitative Lipschitz and size
bounds on a compact convex subset. This is used on state/parameter boxes. -/
theorem smooth_compact_convex_bounds
    {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    {f : E → F} {U S : Set E}
    (hU : IsOpen U) (hf : ContDiffOn ℝ 1 f U)
    (hS : IsCompact S) (hc : Convex ℝ S) (hSU : S ⊆ U) :
    ∃ L : ℝ≥0, ∃ C : ℝ, LipschitzOnWith L f S ∧ ∀ x ∈ S, ‖f x‖ ≤ C := by
  obtain ⟨C,hC⟩ := hS.exists_bound_of_continuousOn (hf.continuousOn.mono hSU)
  obtain ⟨D,hD⟩ := hS.exists_bound_of_continuousOn
    ((hf.continuousOn_fderiv_of_isOpen hU le_rfl).mono hSU)
  refine ⟨⟨max D 0,le_max_right _ _⟩,C,?_,hC⟩
  apply hc.lipschitzOnWith_of_nnnorm_fderiv_le
    (fun x hx => ((hf x (hSU hx)).contDiffAt (hU.mem_nhds (hSU hx))).differentiableAt (by norm_num))
  intro x hx
  exact_mod_cast (hD x hx).trans (le_max_left D 0)

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Real

/-- The zero-disturbance estimate includes both the nominal controller and any
nonnegative additional damping. It is derived from the mechanical equations. -/
theorem ClassicalSolution.nominal_damped_energy_bound
    {H g α β k₀ k₁ k₂ κ κd T : ℝ}
    (sol : ClassicalSolution H g α β k₀ k₁ k₂ κd T)
    (hk₀ : 0 ≤ k₀) (hκ : 0 < κ) (hk₁ : κ ≤ k₁) (hk₂ : κ ≤ k₂)
    (hκd : 0 ≤ κd) (hdzero : ∀ t ∈ Ico 0 T, sol.d t = 0) :
    ∀ t ∈ Icc 0 T, sol.V t ≤ exp (-2*κ*t)*sol.V 0 := by
  have heq := fun t ht => closed_loop_error_equations (sol.h_ne t ht) (sol.Hh_ne t ht)
    (sol.dh t ht) (sol.dv t ht) (sol.dw t ht) (sol.dr t ht) (sol.dr₁ t ht)
  have hd := fun t ht => energy_hasDerivAt_errors (heq t ht).1 (heq t ht).2
  have hc : ContinuousOn sol.V (Icc 0 T) := fun t ht =>
    (hd t ht).continuousAt.continuousWithinAt
  have hb := scalar_comparison (C:=0) hκ hc
    (fun t ht => (hd t (Ico_subset_Icc_self ht)).hasDerivWithinAt) (by
      intro t ht
      rw [hdzero t ht]
      have hn := nominal_decay (e:=heightError sol.h sol.r t)
        (z:=velocityError k₁ sol.h sol.v sol.w sol.r sol.r₁ t) hk₀ hk₁ hk₂
      have hp : 0 ≤ κd * (sol.v t ^ 2 / sol.h t)^2 *
        (velocityError k₁ sol.h sol.v sol.w sol.r sol.r₁ t)^2 / 4 := by positivity
      dsimp [ClassicalSolution.V]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith)
  simpa [envelope] using hb

/-- The geometric argument requires only an already proved energy cap. This
factorization allows the same continuation construction for nominal and robust
controllers without assuming a strictly positive robust damping gain. -/
theorem ClassicalSolution.physical_region_of_cap
    {H g α β k₀ k₁ k₂ κd T cap rlo rhi R₁ wlo whi vmin : ℝ}
    (sol : ClassicalSolution H g α β k₀ k₁ k₂ κd T)
    (hH : 0 < H) (hg : 0 ≤ g) (hk₀ : 0 < k₀)
    (hEC : ∀ t ∈ Icc 0 T, sol.V t ≤ cap)
    (hr : ∀ t ∈ Icc 0 T, rlo ≤ sol.r t ∧ sol.r t ≤ rhi)
    (hr₁ : ∀ t ∈ Icc 0 T, |sol.r₁ t| ≤ R₁)
    (hpositive : 0 < rlo-sqrt (2*cap/k₀))
    (hforward : 2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀)) < wlo)
    (horder : wlo ≤ whi)
    (hcrown : vmin ≤ wlo-(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀)))
    (hl : (1-β)*wlo^2+2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))*wlo+
      (R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))^2 ≤ g*(H+(rlo-sqrt (2*cap/k₀))))
    (hu : g*(H+(rhi+sqrt (2*cap/k₀))) ≤ (1-β)*whi^2-
      2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))*whi+(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))^2)
    (hw₀ : wlo ≤ sol.w 0 ∧ sol.w 0 ≤ whi) :
    ∀ t ∈ Icc 0 T, sol.V t ≤ cap ∧
      0 < sol.h t ∧ wlo ≤ sol.w t ∧ sol.w t ≤ whi ∧
      0 < sol.v t ∧ vmin ≤ (sol.v t+sol.w t)/2 := by
  have hbox := fun t ht => trajectory_enclosure hk₀ (hEC t ht) (hr t ht) (hr₁ t ht)
  have hhc : ContinuousOn sol.h (Icc 0 T) := fun t ht => (sol.dh t ht).continuousAt.continuousWithinAt
  have hwc : ContinuousOn sol.w (Icc 0 T) := fun t ht => (sol.dw t ht).continuousAt.continuousWithinAt
  have hvc : ContinuousOn sol.v (Icc 0 T) := fun t ht => (sol.dv t ht).continuousAt.continuousWithinAt
  have hqc : ContinuousOn (fun t => heightRate (sol.v t) (sol.w t)) (Icc 0 T) :=
    (hvc.sub hwc).div_const 2
  have hK (b : ℝ) : ContinuousOn
      (fun t => -((1-β)*(sol.w t+b)+2*heightRate (sol.v t) (sol.w t))/(H+sol.h t)) (Icc 0 T) :=
    ((continuousOn_const.mul (hwc.add continuousOn_const)).add
      (continuousOn_const.mul hqc)).neg.div (continuousOn_const.add hhc) sol.Hh_ne
  have hphys := physical_region_invariant hH hg hpositive
    (fun t ht => (sol.dw t ht).continuousAt.continuousWithinAt)
    (fun t ht => (mechanical_internal_equation (sol.Hh_ne t (Ico_subset_Icc_self ht))
      (sol.dw t (Ico_subset_Icc_self ht))).hasDerivWithinAt)
    (hK wlo) (hK whi) (fun t ht => ⟨(hbox t ht).1,(hbox t ht).2.1⟩)
    (fun t ht => (hbox t ht).2.2) hforward horder hcrown hl hu hw₀
  intro t ht
  obtain ⟨hh,hwlo,hwhi,hv,hc⟩ := hphys t ht
  have hvId : sol.w t+2*heightRate (sol.v t) (sol.w t) = sol.v t := by unfold heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hsId : sol.w t+heightRate (sol.v t) (sol.w t) = (sol.v t+sol.w t)/2 := by unfold heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [hvId] at hv; rw [hsId] at hc
  exact ⟨hEC t ht,hh,hwlo,hwhi,hv,hc⟩

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Real Metric
open scoped Topology NNReal

abbrev MechanicalState := ℝ × ℝ × ℝ
abbrev ReferenceParameters := ℝ × ℝ × ℝ × ℝ

/-- Pure data and checkable inequalities. There is no trajectory field and no
existence, invariance, or convergence assumption in this structure. -/
structure GlobalTrackingData where
  H : ℝ
  g : ℝ
  α : ℝ
  β : ℝ
  k₀ : ℝ
  k₁ : ℝ
  k₂ : ℝ
  κ : ℝ
  κd : ℝ
  dbar : ℝ
  cap : ℝ
  rlo : ℝ
  rhi : ℝ
  R₁ : ℝ
  R₂ : ℝ
  wlo : ℝ
  whi : ℝ
  vmin : ℝ
  r : ℝ → ℝ
  r₁ : ℝ → ℝ
  r₂ : ℝ → ℝ
  d : ℝ → ℝ
  x₀ : MechanicalState
  H_pos : 0 < H
  g_nonneg : 0 ≤ g
  k₀_pos : 0 < k₀
  κ_pos : 0 < κ
  κ_le_k₁ : κ ≤ k₁
  κ_le_k₂ : κ ≤ k₂
  κd_nonneg : 0 ≤ κd
  regime : dbar = 0 ∨ 0 < κd
  vmin_pos : 0 < vmin
  dr : ∀ t ≥ 0, HasDerivAt r (r₁ t) t
  dr₁ : ∀ t ≥ 0, HasDerivAt r₁ (r₂ t) t
  r₂_cont : ContinuousOn r₂ (Ici 0)
  d_cont : ContinuousOn d (Ici 0)
  ref_bounds : ∀ t ≥ 0, rlo ≤ r t ∧ r t ≤ rhi
  rate_bound : ∀ t ≥ 0, |r₁ t| ≤ R₁
  accel_bound : ∀ t ≥ 0, |r₂ t| ≤ R₂
  disturbance_bound : ∀ t ≥ 0, |d t| ≤ dbar
  initial_energy : errorEnergy k₀ (x₀.1-r 0)
    (x₀.2.1-x₀.2.2-2*r₁ 0+2*k₁*(x₀.1-r 0)) ≤ cap
  disturbance_cap : dbar^2/(16*κ*κd) ≤ cap
  height_positive : 0 < rlo-sqrt (2*cap/k₀)
  forward : 2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀)) < wlo
  speed_order : wlo ≤ whi
  crown : vmin ≤ wlo-(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))
  lower_face_bound : (1-β)*wlo^2+2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))*wlo+
    (R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))^2 ≤ g*(H+(rlo-sqrt (2*cap/k₀)))
  upper_face_bound : g*(H+(rhi+sqrt (2*cap/k₀))) ≤ (1-β)*whi^2-
    2*(R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))*whi+
    (R₁+sqrt (2*cap)*sqrt (1+k₁^2/k₀))^2
  initial_speed : wlo ≤ x₀.2.2 ∧ x₀.2.2 ≤ whi

def GlobalTrackingData.hlo (c : GlobalTrackingData) := c.rlo-sqrt (2*c.cap/c.k₀)
def GlobalTrackingData.hhi (c : GlobalTrackingData) := c.rhi+sqrt (2*c.cap/c.k₀)
def GlobalTrackingData.Q (c : GlobalTrackingData) := c.R₁+sqrt (2*c.cap)*sqrt (1+c.k₁^2/c.k₀)
def GlobalTrackingData.vlo (c : GlobalTrackingData) := c.wlo-2*c.Q
def GlobalTrackingData.vhi (c : GlobalTrackingData) := c.whi+2*c.Q
def GlobalTrackingData.safeBox (c : GlobalTrackingData) : Set MechanicalState :=
  Icc c.hlo c.hhi ×ˢ (Icc c.vlo c.vhi ×ˢ Icc c.wlo c.whi)
def GlobalTrackingData.outerBox (c : GlobalTrackingData) : Set MechanicalState :=
  Icc (c.hlo/2) (c.hhi+1) ×ˢ (Icc (c.vlo-1) (c.vhi+1) ×ˢ Icc (c.wlo-1) (c.whi+1))
def GlobalTrackingData.parameterBox (c : GlobalTrackingData) : Set ReferenceParameters :=
  Icc c.rlo c.rhi ×ˢ (Icc (-c.R₁) c.R₁ ×ˢ (Icc (-c.R₂) c.R₂ ×ˢ Icc (-c.dbar) c.dbar))

def GlobalTrackingData.jointField (c : GlobalTrackingData)
    (y : ReferenceParameters × MechanicalState) : MechanicalState :=
  let p := y.1
  let x := y.2
  let u := robustInput c.H c.g c.α c.β x.1 x.2.1 x.2.2
    (acceleration c.k₀ c.k₁ c.k₂ (x.1-p.1) (heightRate x.2.1 x.2.2) p.2.1 p.2.2.1)
    c.κd (x.2.1-x.2.2-2*p.2.1+2*c.k₁*(x.1-p.1))
  (heightRate x.2.1 x.2.2,
    rise c.g (c.α+p.2.2.2) x.1 x.2.1 x.2.2 u,
    fall c.H c.g c.β x.1 x.2.1 x.2.2)

/-- Clamping time only defines harmless data before zero. Forward dynamics use
the given reference and disturbance without any input clipping. -/
def GlobalTrackingData.parameters (c : GlobalTrackingData) (t : ℝ) : ReferenceParameters :=
  (c.r (max 0 t), c.r₁ (max 0 t), c.r₂ (max 0 t), c.d (max 0 t))
def GlobalTrackingData.field (c : GlobalTrackingData) (t : ℝ) (x : MechanicalState) :=
  c.jointField (c.parameters t,x)

theorem GlobalTrackingData.parameters_mem (c : GlobalTrackingData) (t : ℝ) :
    c.parameters t ∈ c.parameterBox := by
  exact ⟨c.ref_bounds _ (le_max_left _ _), abs_le.mp (c.rate_bound _ (le_max_left _ _)),
    abs_le.mp (c.accel_bound _ (le_max_left _ _)),
    abs_le.mp (c.disturbance_bound _ (le_max_left _ _))⟩

theorem GlobalTrackingData.parameters_continuous (c : GlobalTrackingData) :
    Continuous c.parameters := by
  have hr : ContinuousOn c.r (Ici 0) := fun t ht =>
    (c.dr t ht).continuousAt.continuousWithinAt
  have hr₁ : ContinuousOn c.r₁ (Ici 0) := fun t ht =>
    (c.dr₁ t ht).continuousAt.continuousWithinAt
  have hm : Continuous (fun t : ℝ => max 0 t) := continuous_const.max continuous_id
  exact (hr.comp_continuous hm (fun t => (show max 0 t ∈ Ici 0 from (le_max_left (0 : ℝ) t)))).prodMk
    ((hr₁.comp_continuous hm (fun t => (show max 0 t ∈ Ici 0 from (le_max_left (0 : ℝ) t)))).prodMk
      ((c.r₂_cont.comp_continuous hm (fun t => (show max 0 t ∈ Ici 0 from (le_max_left (0 : ℝ) t)))).prodMk
        (c.d_cont.comp_continuous hm (fun t => (show max 0 t ∈ Ici 0 from (le_max_left (0 : ℝ) t))))))

theorem GlobalTrackingData.jointField_smooth (c : GlobalTrackingData) :
    ContDiffOn ℝ 1 c.jointField {y | 0 < y.2.1} := by
  intro y hy
  have hh : y.2.1 ≠ 0 := ne_of_gt hy
  have hH : c.H+y.2.1 ≠ 0 := ne_of_gt (add_pos c.H_pos hy)
  apply ContDiffAt.contDiffWithinAt
  unfold jointField robustInput nominalInput acceleration heightRate rise fall crownSq
  fun_prop (disch := first | assumption | norm_num)

theorem GlobalTrackingData.safeBox_interior (c : GlobalTrackingData) :
    c.safeBox ⊆ interior c.outerBox := by
  intro x hx
  rcases hx with ⟨hh,hv,hw⟩
  change x ∈ interior (Icc (c.hlo/2) (c.hhi+1) ×ˢ
    (Icc (c.vlo-1) (c.vhi+1) ×ˢ Icc (c.wlo-1) (c.whi+1)))
  simp only [interior_prod_eq,interior_Icc,mem_prod,mem_Ioo]
  have hpos : 0 < c.hlo := c.height_positive
  exact ⟨⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hh.1],by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hh.2]⟩,
    ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hv.1],by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hv.2]⟩,
    ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hw.1],by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hw.2]⟩⟩

theorem GlobalTrackingData.box_of_energy_speed (c : GlobalTrackingData)
    (t : ℝ) (ht : 0 ≤ t) (x : MechanicalState)
    (hE : errorEnergy c.k₀ (x.1-c.r t)
      (x.2.1-x.2.2-2*c.r₁ t+2*c.k₁*(x.1-c.r t)) ≤ c.cap)
    (hw : c.wlo ≤ x.2.2 ∧ x.2.2 ≤ c.whi) : x ∈ c.safeBox := by
  have hb := trajectory_enclosure (h:=fun _ => x.1) (v:=fun _ => x.2.1)
    (w:=fun _ => x.2.2) c.k₀_pos hE (c.ref_bounds t ht) (c.rate_bound t ht)
  have hq := abs_le.mp hb.2.2
  change (c.hlo ≤ x.1 ∧ x.1 ≤ c.hhi) ∧
    (c.vlo ≤ x.2.1 ∧ x.2.1 ≤ c.vhi) ∧ c.wlo ≤ x.2.2 ∧ x.2.2 ≤ c.whi
  refine ⟨⟨hb.1,hb.2.1⟩,⟨?_,?_⟩,hw.1,hw.2⟩ <;>
    dsimp [vlo,vhi,Q,heightRate] at * <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

def GlobalTrackingData.project (c : GlobalTrackingData) (x : MechanicalState) : MechanicalState :=
  (max (c.hlo/2) (min (c.hhi+1) x.1),
   max (c.vlo-1) (min (c.vhi+1) x.2.1),
   max (c.wlo-1) (min (c.whi+1) x.2.2))

theorem GlobalTrackingData.project_lipschitz (c : GlobalTrackingData) :
    LipschitzWith 1 c.project := by
  have hh : LipschitzWith 1 (fun x : MechanicalState =>
      max (c.hlo/2) (min (c.hhi+1) x.1)) :=
    (LipschitzWith.prod_fst.const_min _).const_max _
  have hv : LipschitzWith 1 (fun x : MechanicalState => x.2.1) := by
    simpa using! LipschitzWith.prod_fst.comp (LipschitzWith.prod_snd (α:=ℝ) (β:=ℝ×ℝ))
  have hw : LipschitzWith 1 (fun x : MechanicalState => x.2.2) := by
    simpa using! LipschitzWith.prod_snd.comp (LipschitzWith.prod_snd (α:=ℝ) (β:=ℝ×ℝ))
  simpa only [max_self] using! hh.prodMk
    (((hv.const_min (c.vhi+1)).const_max (c.vlo-1)).prodMk
      ((hw.const_min (c.whi+1)).const_max (c.wlo-1)))

theorem GlobalTrackingData.initial_mem (c : GlobalTrackingData) : c.x₀ ∈ c.safeBox :=
  c.box_of_energy_speed 0 le_rfl c.x₀ c.initial_energy c.initial_speed

theorem GlobalTrackingData.project_mem (c : GlobalTrackingData) (x : MechanicalState) :
    c.project x ∈ c.outerBox := by
  have hx := c.initial_mem
  rcases hx with ⟨hh,hv,hw⟩
  have hp : 0 < c.hlo := c.height_positive
  exact ⟨⟨le_max_left _ _,max_le (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hh.1,hh.2]) (min_le_left _ _)⟩,
    ⟨le_max_left _ _,max_le (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hv.1,hv.2]) (min_le_left _ _)⟩,
    ⟨le_max_left _ _,max_le (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hw.1,hw.2]) (min_le_left _ _)⟩⟩

theorem GlobalTrackingData.project_eq (c : GlobalTrackingData) (x : MechanicalState)
    (hx : x ∈ c.outerBox) : c.project x = x := by
  rcases hx with ⟨hh,hv,hw⟩
  simp only [project,min_eq_right hh.2,max_eq_right hh.1,
    min_eq_right hv.2,max_eq_right hv.1,min_eq_right hw.2,max_eq_right hw.1]

theorem GlobalTrackingData.field_bounds (c : GlobalTrackingData) :
    ∃ L : ℝ≥0, ∃ C : ℝ,
      (∀ t, LipschitzOnWith L (c.field t) c.outerBox) ∧
      (∀ x ∈ c.outerBox, Continuous (fun t => c.field t x)) ∧
      ∀ t x, x ∈ c.outerBox → ‖c.field t x‖ ≤ C := by
  have hP : IsCompact c.parameterBox := isCompact_Icc.prod
    (isCompact_Icc.prod (isCompact_Icc.prod isCompact_Icc))
  have hB : IsCompact c.outerBox := isCompact_Icc.prod (isCompact_Icc.prod isCompact_Icc)
  have hcP : Convex ℝ c.parameterBox := (convex_Icc _ _).prod
    ((convex_Icc _ _).prod ((convex_Icc _ _).prod (convex_Icc _ _)))
  have hcB : Convex ℝ c.outerBox := (convex_Icc _ _).prod
    ((convex_Icc _ _).prod (convex_Icc _ _))
  have hsub : c.parameterBox ×ˢ c.outerBox ⊆ {y | 0 < y.2.1} := by
    intro y hy
    have hp : 0 < c.hlo := c.height_positive
    have hl : c.hlo/2 ≤ y.2.1 := hy.2.1.1
    change 0 < y.2.1
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  obtain ⟨L,C,hL,hC⟩ := smooth_compact_convex_bounds
    (isOpen_lt continuous_const (continuous_snd.fst)) c.jointField_smooth
    (hP.prod hB) (hcP.prod hcB) hsub
  refine ⟨L,C,?_,?_,?_⟩
  · intro t
    have hl := hL.comp (LipschitzWith.prodMk_left (c.parameters t)).lipschitzOnWith
      (fun x hx => ⟨c.parameters_mem t,hx⟩)
    simpa only [mul_one,Function.comp_def] using! hl
  · intro x hx
    exact (hL.continuousOn.comp_continuous
      (c.parameters_continuous.prodMk continuous_const)
      (fun t => ⟨c.parameters_mem t,hx⟩))
  · intro t x hx
    exact hC _ ⟨c.parameters_mem t,hx⟩

/-- This packages a finite prefix of the constructed solution for reuse of the
existing mechanical tracking theorem. Only the outer box is assumed here. -/
def GlobalTrackingData.toClassical (c : GlobalTrackingData) {x : ℝ → MechanicalState} {T : ℝ}
    (hbox : ∀ t ∈ Icc 0 T, x t ∈ c.outerBox)
    (hd : ∀ t ∈ Icc 0 T, HasDerivAt x (c.field t (x t)) t) :
    ClassicalSolution c.H c.g c.α c.β c.k₀ c.k₁ c.k₂ c.κd T where
  h := fun t => (x t).1
  v := fun t => (x t).2.1
  w := fun t => (x t).2.2
  r := c.r
  r₁ := c.r₁
  r₂ := c.r₂
  d := c.d
  h_ne := by
    intro t ht
    have hp : 0 < c.hlo := c.height_positive
    exact ne_of_gt (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hbox t ht).1.1])
  Hh_ne := by
    intro t ht
    have hp : 0 < c.hlo := c.height_positive
    exact ne_of_gt (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(hbox t ht).1.1,c.H_pos])
  dh := by
    intro t ht
    simpa [field,jointField] using! hasFDerivAt_fst.comp_hasDerivAt t (hd t ht)
  dv := by
    intro t ht
    have hv := hasFDerivAt_fst.comp_hasDerivAt t
      (hasFDerivAt_snd.comp_hasDerivAt t (hd t ht))
    simpa [field,jointField,parameters,max_eq_right ht.1,requestedInput,heightError,velocityError] using! hv
  dw := by
    intro t ht
    simpa [field,jointField] using! hasFDerivAt_snd.comp_hasDerivAt t
      (hasFDerivAt_snd.comp_hasDerivAt t (hd t ht))
  dr := fun t ht => c.dr t ht.1
  dr₁ := fun t ht => c.dr₁ t ht.1

theorem GlobalTrackingData.prefix_energy (c : GlobalTrackingData)
    {x : ℝ → MechanicalState} {T : ℝ} (hx₀ : x 0 = c.x₀)
    (hbox : ∀ t ∈ Icc 0 T, x t ∈ c.outerBox)
    (hd : ∀ t ∈ Icc 0 T, HasDerivAt x (c.field t (x t)) t) :
    ∀ t ∈ Icc 0 T, (c.toClassical hbox hd).V t ≤ c.cap := by
  let sol := c.toClassical hbox hd
  have hinit : sol.V 0 ≤ c.cap := by
    simpa [ClassicalSolution.V,sol,toClassical,heightError,velocityError,hx₀] using! c.initial_energy
  have hcap0 : 0 ≤ c.cap := (energy_nonneg c.k₀_pos.le _ _).trans c.initial_energy
  rcases c.regime with hzero | hpos
  · have hdz : ∀ t ∈ Ico 0 T, sol.d t = 0 := by
      intro t ht
      have hb := c.disturbance_bound t ht.1
      rw [hzero] at hb
      exact abs_eq_zero.mp (le_antisymm hb (abs_nonneg _))
    have he := sol.nominal_damped_energy_bound c.k₀_pos.le c.κ_pos c.κ_le_k₁ c.κ_le_k₂
      c.κd_nonneg hdz
    intro t ht
    have henv := envelope_below_cap (C:=0) c.κ_pos ht.1 hinit (by simpa using! hcap0)
    exact (he t ht).trans (by simpa [envelope] using! henv)
  · have he := sol.energy_bound c.k₀_pos.le c.κ_pos c.κ_le_k₁ c.κ_le_k₂ hpos
      (fun t ht => c.disturbance_bound t ht.1)
    intro t ht
    have henv := envelope_below_cap (C:=c.dbar^2/(8*c.κd)) c.κ_pos ht.1 hinit
      (by convert! c.disturbance_cap using 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring)
    exact (he t ht).trans (by convert! henv using 1; unfold envelope; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring)

theorem GlobalTrackingData.prefix_bound (c : GlobalTrackingData)
    (x : ℝ → MechanicalState) (T : ℝ) (hT : 0 ≤ T) (hx₀ : x 0 = c.x₀)
    (hbox : ∀ t ∈ Icc 0 T, x t ∈ c.outerBox)
    (hd : ∀ t ∈ Icc 0 T, HasDerivAt x (c.field t (x t)) t) : x T ∈ c.safeBox := by
  let sol := c.toClassical hbox hd
  have hs := sol.physical_region_of_cap c.H_pos c.g_nonneg c.k₀_pos
    (c.prefix_energy hx₀ hbox hd)
    (fun t ht => c.ref_bounds t ht.1) (fun t ht => c.rate_bound t ht.1)
    c.height_positive c.forward c.speed_order c.crown c.lower_face_bound c.upper_face_bound
    (by simpa [sol,toClassical,hx₀] using! c.initial_speed) T ⟨hT,le_rfl⟩
  exact c.box_of_energy_speed T hT (x T) hs.1 ⟨hs.2.2.1,hs.2.2.2.1⟩

/-- Global existence for the actual controlled mechanical system, with continuous
bounded coefficient uncertainty. The initial state and reference are inputs;
the trajectory is constructed and the physical box follows as a conclusion. -/
theorem GlobalTrackingData.exists_global (c : GlobalTrackingData) :
    ∃ x : ℝ → MechanicalState, x 0 = c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      ∀ t ≥ 0, x t ∈ c.safeBox := by
  obtain ⟨L,C,hL,hcont,hC⟩ := c.field_bounds
  exact global_exists_of_retraction_and_prefix
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    c.project_lipschitz c.project_mem c.project_eq hL hcont hC c.x₀
    (c.safeBox_interior c.initial_mem) c.prefix_bound

/-- Forward uniqueness on the certified box. Equality is asserted only for
nonnegative times; the arbitrary backward extension is not part of the model. -/
theorem GlobalTrackingData.unique_on_nonnegative (c : GlobalTrackingData)
    {x y : ℝ → MechanicalState} (hx₀ : x 0 = c.x₀) (hy₀ : y 0 = c.x₀)
    (hdx : ∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t)
    (hdy : ∀ t ≥ 0, HasDerivAt y (c.field t (y t)) t)
    (hbx : ∀ t ≥ 0, x t ∈ c.safeBox) (hby : ∀ t ≥ 0, y t ∈ c.safeBox) :
    EqOn x y (Ici 0) := by
  obtain ⟨L,C,hL,hcont,hC⟩ := c.field_bounds
  intro T hT
  have heq := ODE_solution_unique_of_mem_Icc_right (a:=0) (b:=T) (s:=fun _ => c.outerBox)
    (fun t _ => hL t)
    (fun t ht => (hdx t ht.1).continuousAt.continuousWithinAt)
    (fun t ht => (hdx t ht.1).hasDerivWithinAt)
    (fun t ht => interior_subset (c.safeBox_interior (hbx t ht.1)))
    (fun t ht => (hdy t ht.1).continuousAt.continuousWithinAt)
    (fun t ht => (hdy t ht.1).hasDerivWithinAt)
    (fun t ht => interior_subset (c.safeBox_interior (hby t ht.1)))
    (hx₀.trans hy₀.symm)
  exact heq ⟨hT,le_rfl⟩

/-- The constructed trajectory satisfies the mechanical equations, the energy
cap, positive transport, and the requested crown margin for every t >= 0. -/
theorem GlobalTrackingData.exists_global_physical (c : GlobalTrackingData) :
    ∃ x : ℝ → MechanicalState, x 0 = c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      (∀ t ≥ 0, x t ∈ c.safeBox) ∧
      ∀ t ≥ 0,
        errorEnergy c.k₀ ((x t).1-c.r t)
          ((x t).2.1-(x t).2.2-2*c.r₁ t+2*c.k₁*((x t).1-c.r t)) ≤ c.cap ∧
        0 < (x t).1 ∧ c.wlo ≤ (x t).2.2 ∧ (x t).2.2 ≤ c.whi ∧
        0 < (x t).2.1 ∧ c.vmin ≤ ((x t).2.1+(x t).2.2)/2 := by
  obtain ⟨x,hx₀,hd,hbox⟩ := c.exists_global
  refine ⟨x,hx₀,hd,hbox,?_⟩
  intro T hT
  have hB : ∀ t ∈ Icc 0 T, x t ∈ c.outerBox :=
    fun t ht => interior_subset (c.safeBox_interior (hbox t ht.1))
  have hD := fun t (ht : t ∈ Icc 0 T) => hd t ht.1
  let sol := c.toClassical hB hD
  exact sol.physical_region_of_cap c.H_pos c.g_nonneg c.k₀_pos
    (c.prefix_energy hx₀ hB hD)
    (fun t ht => c.ref_bounds t ht.1) (fun t ht => c.rate_bound t ht.1)
    c.height_positive c.forward c.speed_order c.crown c.lower_face_bound c.upper_face_bound
    (by simpa [sol,toClassical,hx₀] using! c.initial_speed) T ⟨hT,le_rfl⟩

def GlobalTrackingData.stateEnergy (c : GlobalTrackingData) (t : ℝ) (x : MechanicalState) : ℝ :=
  errorEnergy c.k₀ (x.1-c.r t) (x.2.1-x.2.2-2*c.r₁ t+2*c.k₁*(x.1-c.r t))

/-- Global tracking with a constructed trajectory. The two implications keep
the undamped nominal case separate from the robust expression with κd > 0. -/
theorem GlobalTrackingData.exists_global_tracking (c : GlobalTrackingData) :
    ∃ x : ℝ → MechanicalState, x 0 = c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      (∀ t ≥ 0, x t ∈ c.safeBox) ∧
      (c.dbar = 0 → ∀ t ≥ 0,
        c.stateEnergy t (x t) ≤ exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀) ∧
      (0 < c.κd → ∀ t ≥ 0,
        c.stateEnergy t (x t) ≤ exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-exp (-2*c.κ*t))) := by
  obtain ⟨x,hx₀,hd,hbox⟩ := c.exists_global
  have hB (T : ℝ) : ∀ t ∈ Icc 0 T, x t ∈ c.outerBox :=
    fun t ht => interior_subset (c.safeBox_interior (hbox t ht.1))
  have hD (T : ℝ) := fun t (ht : t ∈ Icc 0 T) => hd t ht.1
  let sol (T : ℝ) := c.toClassical (hB T) (hD T)
  refine ⟨x,hx₀,hd,hbox,?_,?_⟩
  · intro hz T hT
    have hdz : ∀ t ∈ Ico 0 T, (sol T).d t = 0 := by
      intro t ht
      have hb := c.disturbance_bound t ht.1
      rw [hz] at hb
      exact abs_eq_zero.mp (le_antisymm hb (abs_nonneg _))
    have he := (sol T).nominal_damped_energy_bound c.k₀_pos.le c.κ_pos
      c.κ_le_k₁ c.κ_le_k₂ c.κd_nonneg hdz T ⟨hT,le_rfl⟩
    simpa [stateEnergy,ClassicalSolution.V,sol,toClassical,heightError,velocityError,hx₀] using! he
  · intro hp T hT
    have he := (sol T).energy_bound c.k₀_pos.le c.κ_pos c.κ_le_k₁ c.κ_le_k₂ hp
      (fun t ht => c.disturbance_bound t ht.1) T ⟨hT,le_rfl⟩
    simpa [stateEnergy,ClassicalSolution.V,sol,toClassical,heightError,velocityError,hx₀] using! he

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Real

/-- An explicit, nonstationary nominal instance: height is initially exact,
while the initial transport speed 10 differs from the steady speed sqrt(101).
This checks that the global theorem's hypotheses are jointly satisfiable. -/
def nominalGlobalExample : GlobalTrackingData where
  H := 100
  g := 1
  α := 1/4
  β := 0
  k₀ := 1
  k₁ := 1
  k₂ := 1
  κ := 1
  κd := 0
  dbar := 0
  cap := 0
  rlo := 1
  rhi := 1
  R₁ := 0
  R₂ := 0
  wlo := 5
  whi := 20
  vmin := 1
  r := fun _ => 1
  r₁ := fun _ => 0
  r₂ := fun _ => 0
  d := fun _ => 0
  x₀ := (1,10,10)
  H_pos := by norm_num
  g_nonneg := by norm_num
  k₀_pos := by norm_num
  κ_pos := by norm_num
  κ_le_k₁ := by norm_num
  κ_le_k₂ := by norm_num
  κd_nonneg := by norm_num
  regime := Or.inl rfl
  vmin_pos := by norm_num
  dr := fun t _ => hasDerivAt_const t 1
  dr₁ := fun t _ => hasDerivAt_const t 0
  r₂_cont := continuousOn_const
  d_cont := continuousOn_const
  ref_bounds := by intro t ht; norm_num
  rate_bound := by intro t ht; norm_num
  accel_bound := by intro t ht; norm_num
  disturbance_bound := by intro t ht; norm_num
  initial_energy := by norm_num [errorEnergy]
  disturbance_cap := by norm_num
  height_positive := by norm_num
  forward := by norm_num
  speed_order := by norm_num
  crown := by norm_num
  lower_face_bound := by norm_num
  upper_face_bound := by norm_num
  initial_speed := by norm_num

theorem nominal_example_global_exists :
    ∃ x : ℝ → MechanicalState, x 0 = (1,10,10) ∧
      (∀ t ≥ 0, HasDerivAt x (nominalGlobalExample.field t (x t)) t) ∧
      ∀ t ≥ 0, x t ∈ nominalGlobalExample.safeBox :=
  nominalGlobalExample.exists_global

/-- A genuinely uncertain instance, with nonzero continuous disturbance and
positive error cap, for the same geometry. -/
def robustGlobalExample : GlobalTrackingData :=
  { nominalGlobalExample with
    κd := 1
    dbar := 1/1000
    cap := 1/20000
    d := fun _ => 1/1000
    κd_nonneg := by norm_num
    regime := Or.inr (by norm_num)
    d_cont := continuousOn_const
    disturbance_bound := by
      intro t ht
      change |(1:ℝ)/1000| ≤ 1/1000
      exact le_of_eq (abs_of_nonneg (by positivity))
    initial_energy := by norm_num [nominalGlobalExample,errorEnergy]
    disturbance_cap := by norm_num [nominalGlobalExample]
    height_positive := by norm_num [nominalGlobalExample]
    forward := by
      have hs : sqrt 2 ≤ 2 := (Real.sqrt_le_iff).2 ⟨by norm_num,by norm_num⟩
      norm_num [nominalGlobalExample]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
    crown := by
      have hs : sqrt 2 ≤ 2 := (Real.sqrt_le_iff).2 ⟨by norm_num,by norm_num⟩
      norm_num [nominalGlobalExample]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
    lower_face_bound := by
      have hs : sqrt 2 ≤ 2 := (Real.sqrt_le_iff).2 ⟨by norm_num,by norm_num⟩
      have hsq : (sqrt 2)^2=2 := Real.sq_sqrt (by norm_num)
      norm_num [nominalGlobalExample]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
    upper_face_bound := by
      have hs : sqrt 2 ≤ 2 := (Real.sqrt_le_iff).2 ⟨by norm_num,by norm_num⟩
      have hsq : (sqrt 2)^2=2 := Real.sq_sqrt (by norm_num)
      norm_num [nominalGlobalExample]
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith }

theorem robust_example_global_exists :
    ∃ x : ℝ → MechanicalState, x 0 = (1,10,10) ∧
      (∀ t ≥ 0, HasDerivAt x (robustGlobalExample.field t (x t)) t) ∧
      ∀ t ≥ 0, x t ∈ robustGlobalExample.safeBox :=
  robustGlobalExample.exists_global

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Real

/-- The reverse inverse identity completes the affine input/height bijection. -/
theorem height_input_inverse (H g α β u : ℝ)
    (hg : g ≠ 0) (hβ : 1-β ≠ 0) (hαβ : 1-α-β ≠ 0) :
    steadyInput H g α β (heightFromInput H g α β u) = u := by
  unfold steadyInput heightFromInput
  field_simp
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem steady_input_antitone {H g α β : ℝ}
    (hg : 0 < g) (hβ : 0 < 1-β) (hαβ : 0 < 1-α-β) :
    StrictAnti (steadyInput H g α β) := by
  intro a b hab
  unfold steadyInput
  apply (div_lt_div_iff_of_pos_right hβ).mpr
  exact mul_lt_mul_of_pos_left (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith) hg

/-- Exact actuator interval, with the reversed height endpoints. -/
theorem steady_actuator_interval {H g α β r uLo uHi : ℝ}
    (hg : 0 < g) (hβ : 0 < 1-β) (hαβ : 0 < 1-α-β) :
    steadyInput H g α β r ∈ Icc uLo uHi ↔
      r ∈ Icc (heightFromInput H g α β uHi) (heightFromInput H g α β uLo) := by
  have hanti := steady_input_antitone (H:=H) hg hβ hαβ
  have hinv := height_input_inverse H g α β
  constructor
  · intro h
    constructor
    · by_contra hn
      have hc := hanti (lt_of_not_ge hn)
      rw [hinv uHi hg.ne' hβ.ne' hαβ.ne'] at hc
      exact (not_lt_of_ge h.2) hc
    · by_contra hn
      have hc := hanti (lt_of_not_ge hn)
      rw [hinv uLo hg.ne' hβ.ne' hαβ.ne'] at hc
      exact (not_lt_of_ge h.1) hc
  · rintro ⟨hl,hu⟩
    constructor
    · have h := hanti.antitone hu
      rwa [hinv uLo hg.ne' hβ.ne' hαβ.ne'] at h
    · have h := hanti.antitone hl
      rwa [hinv uHi hg.ne' hβ.ne' hαβ.ne'] at h

/-- Positive equilibrium uniqueness includes unequal-speed candidate states. -/
theorem positive_equilibrium_iff {H g α β r v w u : ℝ}
    (hH : 0 < H) (hg : 0 < g) (hβ : β < 1) (hr : 0 < r) (hv : 0 < v) :
    (heightRate v w = 0 ∧ rise g α r v w u = 0 ∧ fall H g β r v w = 0) ↔
      (v = sqrt (steadySpeedSq H g β r) ∧ w = v ∧ u = steadyInput H g α β r) := by
  have hden : H+r ≠ 0 := (add_pos hH hr).ne'
  have hb : 1-β ≠ 0 := (sub_pos.mpr hβ).ne'
  have hbpos : 0 < 1-β := sub_pos.mpr hβ
  constructor
  · rintro ⟨hq,hu,hf⟩
    have hw : w=v := by unfold heightRate at hq; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
    rw [hw] at hu hf
    obtain ⟨hs,hi⟩ := (steady_state_iff hr.ne' hden hb).mp ⟨hu,hf⟩
    refine ⟨?_,hw,hi⟩
    rw [←hs, sqrt_sq_eq_abs,abs_of_pos hv]
  · rintro ⟨hs,rfl,rfl⟩
    apply steady_is_equilibrium hr.ne' hden hb
    rw [hs,sq_sqrt]
    unfold steadySpeedSq
    positivity

theorem steady_input_coefficient_monotone {H g β r : ℝ}
    (hg : 0 ≤ g) (hβ : 0 < 1-β) (hHr : 0 ≤ H+r) :
    Monotone (fun α => steadyInput H g α β r) := by
  intro a b hab
  unfold steadyInput
  apply (div_le_div_iff_of_pos_right hβ).mpr
  apply mul_le_mul_of_nonneg_left _ hg
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_nonneg (sub_nonneg.mpr hab) hHr]

/-- Both coefficient endpoints are necessary and sufficient for all coefficients. -/
theorem steady_uncertain_endpoints {H g β r aLo aHi uLo uHi : ℝ}
    (hg : 0 ≤ g) (hβ : 0 < 1-β) (hHr : 0 ≤ H+r) (ha : aLo ≤ aHi) :
    (∀ α ∈ Icc aLo aHi, steadyInput H g α β r ∈ Icc uLo uHi) ↔
      (uLo ≤ steadyInput H g aLo β r ∧ steadyInput H g aHi β r ≤ uHi) := by
  have hm := steady_input_coefficient_monotone hg hβ hHr
  constructor
  · intro h
    exact ⟨(h aLo ⟨le_rfl,ha⟩).1,(h aHi ⟨ha,le_rfl⟩).2⟩
  · rintro ⟨hl,hu⟩ a ⟨hal,hau⟩
    exact ⟨hl.trans (hm hal),(hm hau).trans hu⟩

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Real

/-- Corollary 6.2 with the global trajectory constructed, not supplied.
Only data, a constant reference, zero disturbance bound and a decay rate are inputs. -/
theorem GlobalTrackingData.exists_global_convergent (c : GlobalTrackingData)
    (hd : c.dbar = 0) (hβ : c.β < 1) (r wr ρ : ℝ)
    (hr : ∀ t ≥ 0, c.r t = r) (hr₁ : ∀ t ≥ 0, c.r₁ t = 0)
    (hwr : 0 ≤ wr) (heq : (1-c.β)*wr^2=c.g*(c.H+r))
    (hρ0 : 0 < ρ) (hρ : ρ < (1-c.β)*(c.wlo+wr)/(c.H+c.hhi)) (hρκ : ρ ≤ c.κ) :
    let Ce := sqrt (2*c.stateEnergy 0 c.x₀/c.k₀)
    let Cq := sqrt (2*c.stateEnergy 0 c.x₀)*sqrt (1+c.k₁^2/c.k₀)
    let M := |c.x₀.2.2-wr|+((|c.g| *Ce+2*Cq*c.whi+Cq^2)/(c.H+c.hlo))/
      ((1-c.β)*(c.wlo+wr)/(c.H+c.hhi)-ρ)
    ∃ x : ℝ → MechanicalState, x 0 = c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      (∀ t ≥ 0, x t ∈ c.safeBox) ∧
      ∀ t ≥ 0, |(x t).1-r| ≤ Ce*exp (-ρ*t) ∧
        |(x t).2.2-wr| ≤ M*exp (-ρ*t) ∧
        |(x t).2.1-wr| ≤ (M+2*Cq)*exp (-ρ*t) := by
  dsimp only
  obtain ⟨x,hx,hdx,hbox,hdec,_⟩ := c.exists_global_tracking
  let Ce := sqrt (2*c.stateEnergy 0 c.x₀/c.k₀)
  let Cq := sqrt (2*c.stateEnergy 0 c.x₀)*sqrt (1+c.k₁^2/c.k₀)
  have he (t : ℝ) (ht : 0 ≤ t) :
      |(x t).1-r| ≤ Ce*exp (-c.κ*t) ∧
      |heightRate (x t).2.1 (x t).2.2| ≤ Cq*exp (-c.κ*t) := by
    have hh := error_decay_enclosure (k₁:=c.k₁) c.k₀_pos
      (energy_nonneg c.k₀_pos.le _ _) (hdec hd t ht)
    simp only [stateEnergy,hr t ht,hr₁ t ht,mul_zero,sub_zero] at hh
    convert! hh using 2 <;> dsimp [Ce,Cq,heightRate] <;> congr 1 <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hc : ContinuousOn x (Ici 0) := fun t ht => (hdx t ht).continuousAt.continuousWithinAt
  have hR : 0 ≤ c.R₁ := (abs_nonneg _).trans (c.rate_bound 0 le_rfl)
  have hQ : 0 ≤ c.Q := by dsimp [Q]; positivity
  have hwlo : 0 < c.wlo := by have := c.forward; change 2*c.Q < c.wlo at this; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hwd (t : ℝ) (ht : 0 ≤ t) : HasDerivAt (fun s => (x s).2.2)
      (internal c.H c.g c.β (x t).1 (x t).2.2 (heightRate (x t).2.1 (x t).2.2)) t := by
    have hw := hasFDerivAt_snd.comp_hasDerivAt t
      (hasFDerivAt_snd.comp_hasDerivAt t (hdx t ht))
    convert! hw using 1
    dsimp [field,jointField,internal,fall,crownSq,heightRate]
    have hden : c.H+(x t).1 ≠ 0 := (add_pos c.H_pos (lt_of_lt_of_le c.height_positive (hbox t ht).1.1)).ne'
    field_simp
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have result := constant_reference_fullstate_convergence
    (hc.fst) (hc.snd.snd) (add_pos c.H_pos c.height_positive) hβ hwr hwlo
    (show 0 ≤ Ce by positivity) (show 0 ≤ Cq by positivity) hρ0
    (fun t ht => (hbox t ht).1) (fun t ht => (hbox t ht).2.2) heq
    hwd (fun t ht => (he t ht).1) (fun t ht => (he t ht).2) hρ hρκ
  refine ⟨x,hx,hdx,hbox,?_⟩
  intro t ht
  have h := result.2 t ht
  rw [hx] at h
  have hid : (x t).2.2+2*heightRate (x t).2.1 (x t).2.2-wr = (x t).2.1-wr := by
    unfold heightRate; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [hid] at h
  exact h

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Real Filter
open scoped Topology

/-- C1 gluing at a single junction, proved from the two one-sided derivatives. -/
theorem derivative_glue {f g f' g' : ℝ → ℝ} (a : ℝ)
    (hf : ∀ x, HasDerivAt f (f' x) x) (hg : ∀ x, HasDerivAt g (g' x) x)
    (hval : f a=g a) (hslope : f' a=g' a) (x : ℝ) :
    HasDerivAt (fun t => if t ≤ a then f t else g t)
      (if x ≤ a then f' x else g' x) x := by
  rcases lt_trichotomy x a with hlt | he | hgt
  · rw [if_pos hlt.le]
    apply (hf x).congr_of_eventuallyEq
    filter_upwards [eventually_lt_nhds hlt] with t ht
    exact if_pos ht.le
  · subst x
    rw [if_pos le_rfl]
    have hl : HasDerivWithinAt (fun t => if t ≤ a then f t else g t) (f' a) (Iic a) a :=
      (hf a).hasDerivWithinAt.congr (fun t ht => if_pos ht) (if_pos le_rfl)
    have hr : HasDerivWithinAt (fun t => if t ≤ a then f t else g t) (f' a) (Ici a) a := by
      rw [hslope]
      apply (hg a).hasDerivWithinAt.congr
      · intro t ht
        by_cases h : t ≤ a
        · have : t=a := le_antisymm h ht
          simpa [this] using! hval
        · exact if_neg h
      · simpa using! hval
    have hu := hl.union hr
    rw [Iic_union_Ici] at hu
    exact hu.hasDerivAt (by simp)
  · rw [if_neg (not_le.mpr hgt)]
    apply (hg x).congr_of_eventuallyEq
    filter_upwards [eventually_gt_nhds hgt] with t ht
    exact if_neg (not_le.mpr ht)

def cappedQuintic (x : ℝ) := if x ≤ 0 then 0 else if x ≤ 1 then quintic x else 1
def cappedRate (x : ℝ) := if x ≤ 0 then 0 else if x ≤ 1 then quinticRate x else 0
def cappedAcceleration (x : ℝ) := if x ≤ 0 then 0 else if x ≤ 1 then quinticAcceleration x else 0

theorem capped_quintic_derivative (x : ℝ) :
    HasDerivAt cappedQuintic (cappedRate x) x := by
  apply derivative_glue 0 (fun t => hasDerivAt_const t 0)
    (derivative_glue 1 quintic_derivative (fun t => hasDerivAt_const t 1)
      (by norm_num [quintic]) (by norm_num [quinticRate]))
    (by norm_num [quintic]) (by norm_num [quinticRate])

theorem capped_quintic_second_derivative (x : ℝ) :
    HasDerivAt cappedRate (cappedAcceleration x) x := by
  apply derivative_glue 0 (fun t => hasDerivAt_const t 0)
    (derivative_glue 1 quintic_second_derivative (fun t => hasDerivAt_const t 0)
      (by norm_num [quinticRate]) (by norm_num [quinticAcceleration]))
    (by norm_num [quinticRate]) (by norm_num [quinticAcceleration])

theorem capped_acceleration_continuous : Continuous cappedAcceleration := by
  have hp : Continuous quinticAcceleration := by unfold quinticAcceleration; fun_prop
  have hinner : Continuous (fun x : ℝ => if x ≤ 1 then quinticAcceleration x else 0) := by
    apply Continuous.if _ hp continuous_const
    intro x hx
    have : x=1 := by simpa only [show {x : ℝ | x ≤ 1}=Iic 1 from rfl,frontier_Iic,mem_singleton_iff] using! hx
    simp [this,quinticAcceleration]
  apply Continuous.if _ continuous_const hinner
  intro x hx
  have : x=0 := by simpa only [show {x : ℝ | x ≤ 0}=Iic 0 from rfl,frontier_Iic,mem_singleton_iff] using! hx
  simp [this,quinticAcceleration]

/-- The constant extension is genuinely C2 across both junctions. -/
theorem capped_quintic_C2 : ContDiff ℝ 2 cappedQuintic := by
  have hd : deriv cappedQuintic=cappedRate := funext (fun x => (capped_quintic_derivative x).deriv)
  have hdd : deriv cappedRate=cappedAcceleration := funext (fun x => (capped_quintic_second_derivative x).deriv)
  rw [show (2 : WithTop ℕ∞)=1+1 from rfl,contDiff_succ_iff_deriv]
  refine ⟨fun x => (capped_quintic_derivative x).differentiableAt,by norm_num,?_⟩
  rw [hd,contDiff_one_iff_deriv,hdd]
  exact ⟨fun x => (capped_quintic_second_derivative x).differentiableAt,capped_acceleration_continuous⟩

theorem capped_quintic_bounds (x : ℝ) :
    |cappedRate x| ≤ 15/8 ∧ |cappedAcceleration x| ≤ 10/sqrt 3 := by
  by_cases hx : x ≤ 0
  · norm_num [cappedRate,cappedAcceleration,hx]; positivity
  · by_cases hx1 : x ≤ 1
    · simpa [cappedRate,cappedAcceleration,hx,hx1] using!
        And.intro (quintic_rate_bound ⟨(lt_of_not_ge hx).le,hx1⟩)
          (quintic_acceleration_bound ⟨(lt_of_not_ge hx).le,hx1⟩)
    · norm_num [cappedRate,cappedAcceleration,hx,hx1]; positivity

def transition (r₀ r₁ T t : ℝ) := r₀+(r₁-r₀)*cappedQuintic (t/T)

theorem transition_C2 (r₀ r₁ T : ℝ) : ContDiff ℝ 2 (transition r₀ r₁ T) := by
  unfold transition
  exact contDiff_const.add (contDiff_const.mul (capped_quintic_C2.comp (contDiff_id.div_const T)))

theorem transition_derivatives (r₀ r₁ T t : ℝ) :
    HasDerivAt (transition r₀ r₁ T) ((r₁-r₀)*cappedRate (t/T)/T) t ∧
    HasDerivAt (fun s => (r₁-r₀)*cappedRate (s/T)/T)
      ((r₁-r₀)*cappedAcceleration (t/T)/T^2) t := by
  constructor
  · convert! (((capped_quintic_derivative (t/T)).comp t ((hasDerivAt_id t).div_const T)).const_mul (r₁-r₀)).const_add r₀ using 1 <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  · convert! (((capped_quintic_second_derivative (t/T)).comp t ((hasDerivAt_id t).div_const T)).const_mul (r₁-r₀)).div_const T using 1 <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem transition_rate_bounds {r₀ r₁ T : ℝ} (hT : 0 < T) (t : ℝ) :
    |(r₁-r₀)*cappedRate (t/T)/T| ≤ (15/8)*|r₁-r₀|/T ∧
    |(r₁-r₀)*cappedAcceleration (t/T)/T^2| ≤ (10/sqrt 3)*|r₁-r₀|/T^2 := by
  obtain ⟨h₁,h₂⟩ := capped_quintic_bounds (t/T)
  simp only [abs_div,abs_mul,abs_of_pos hT,abs_of_nonneg (sq_nonneg T)]
  constructor
  · apply div_le_div_of_nonneg_right _ hT.le
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_le_mul_of_nonneg_left h₁ (abs_nonneg (r₁-r₀))]
  · apply div_le_div_of_nonneg_right _ (sq_nonneg T)
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_le_mul_of_nonneg_left h₂ (abs_nonneg (r₁-r₀))]

theorem transition_endpoints {r₀ r₁ T t : ℝ} (hT : 0 < T) :
    (t ≤ 0 → transition r₀ r₁ T t=r₀) ∧ (T ≤ t → transition r₀ r₁ T t=r₁) := by
  constructor
  · intro ht
    simp [transition,cappedQuintic,div_nonpos_of_nonpos_of_nonneg ht hT.le]
  · intro ht
    have hq : 1 ≤ t/T := (le_div_iff₀ hT).mpr (by simpa using! ht)
    by_cases he : t/T=1
    · norm_num [transition,cappedQuintic,he,quintic]
    · have hgt : 1 < t/T := lt_of_le_of_ne hq (Ne.symm he)
      simp [transition,cappedQuintic,show ¬t/T ≤ 0 by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith,not_le.mpr hgt]

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Real

def GlobalTrackingData.accelCap (c : GlobalTrackingData) := c.R₂+
  (c.k₁+c.k₂)*(sqrt (2*c.cap)*sqrt (1+c.k₁^2/c.k₀))+
  (c.k₀+c.k₁*c.k₂)*sqrt (2*c.cap/c.k₀)
def GlobalTrackingData.dampingCap (c : GlobalTrackingData) :=
  c.κd*c.vhi^4/c.hlo*sqrt (8*c.cap)
def GlobalTrackingData.command (c : GlobalTrackingData) (t : ℝ) (x : MechanicalState) :=
  robustInput c.H c.g c.α c.β x.1 x.2.1 x.2.2
    (acceleration c.k₀ c.k₁ c.k₂ (x.1-c.r t) (heightRate x.2.1 x.2.2) (c.r₁ t) (c.r₂ t))
    c.κd (x.2.1-x.2.2-2*c.r₁ t+2*c.k₁*(x.1-c.r t))

/-- Algebraic actuator certificate, containing no unknown trajectory. -/
def GlobalTrackingData.forceCertificate (c : GlobalTrackingData) (uLo uHi : ℝ) : Prop :=
  uLo ≤ lowerInputBound c.H c.g c.α c.β c.hlo c.hhi c.vhi (c.wlo-c.Q) c.whi c.accelCap c.dampingCap ∧
  upperInputBound c.H c.g c.α c.hlo c.hhi c.vlo (c.whi+c.Q) c.accelCap c.dampingCap ≤ uHi ∧
  0 ≤ lowerTensionBound c.H c.g c.β c.hlo c.hhi (c.wlo-c.Q) c.whi c.accelCap-
    c.dampingCap-c.dbar*c.vhi^2

theorem GlobalTrackingData.force_of_energy_box (c : GlobalTrackingData)
    (ha : c.α ≤ 1) (hb : 0 ≤ c.β) {uLo uHi t : ℝ} {x : MechanicalState}
    (hc : c.forceCertificate uLo uHi) (ht : 0 ≤ t) (hbox : x ∈ c.safeBox)
    (hE : c.stateEnergy t x ≤ c.cap) :
    uLo ≤ c.command t x ∧ c.command t x ≤ uHi ∧
      0 ≤ pickup (c.α+c.d t) x.2.1 (c.command t x) := by
  have hR : 0 ≤ c.R₁ := (abs_nonneg _).trans (c.rate_bound 0 le_rfl)
  have hQ : 0 ≤ c.Q := by dsimp [Q]; positivity
  have hf : 2*c.Q < c.wlo := c.forward
  have hvlo : 0 ≤ c.vlo := by dsimp [vlo]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hwlo : 0 ≤ c.wlo := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hslo : 0 ≤ c.wlo-c.Q := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hS : c.wlo-c.Q ≤ (x.2.1+x.2.2)/2 ∧ (x.2.1+x.2.2)/2 ≤ c.whi+c.Q := by
    have hv := hbox.2.1
    have hw := hbox.2.2
    change c.wlo-2*c.Q ≤ x.2.1 ∧ x.2.1 ≤ c.whi+2*c.Q at hv
    constructor <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hv.1,hv.2,hw.1,hw.2]
  have he := error_enclosure (k₁:=c.k₁) c.k₀_pos hE
  have hq : |heightRate x.2.1 x.2.2-c.r₁ t| ≤ sqrt (2*c.cap)*sqrt (1+c.k₁^2/c.k₀) := by
    convert! he.2.2 using 1 <;> congr 1 <;> unfold heightRate <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hA := acceleration_bound c.k₀_pos.le (c.κ_pos.le.trans c.κ_le_k₁)
    (c.κ_pos.le.trans c.κ_le_k₂) he.1 hq (c.accel_bound t ht)
  exact robust_force_feasibility c.H_pos c.g_nonneg ha hb c.height_positive
    hbox.1 (square_interval hvlo hbox.2.1) (square_interval hwlo hbox.2.2).2
    (square_interval hslo hS) hA c.κd_nonneg he.2.1 (c.disturbance_bound t ht)
    hc.1 hc.2.1 hc.2.2

/-- Global physical actuation: construct the trajectory and then certify its
actual unfiltered command and pickup tension at every nonnegative time. -/
theorem GlobalTrackingData.exists_global_admissible (c : GlobalTrackingData)
    (ha : c.α ≤ 1) (hb : 0 ≤ c.β) (uLo uHi : ℝ)
    (hc : c.forceCertificate uLo uHi) :
    ∃ x : ℝ → MechanicalState, x 0=c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      (∀ t ≥ 0, x t ∈ c.safeBox) ∧
      ∀ t ≥ 0, c.stateEnergy t (x t) ≤ c.cap ∧ 0 < (x t).1 ∧
        0 < (x t).2.1 ∧ c.vmin ≤ ((x t).2.1+(x t).2.2)/2 ∧
        uLo ≤ c.command t (x t) ∧ c.command t (x t) ≤ uHi ∧
        0 ≤ pickup (c.α+c.d t) (x t).2.1 (c.command t (x t)) := by
  obtain ⟨x,hx,hd,hbnd,hphys⟩ := c.exists_global_physical
  refine ⟨x,hx,hd,hbnd,?_⟩
  intro t ht
  have hp := hphys t ht
  have hu := c.force_of_energy_box ha hb hc ht (hbnd t ht) hp.1
  exact ⟨hp.1,hp.2.1,hp.2.2.2.2.1,hp.2.2.2.2.2,hu⟩

end
end ChainFountain


namespace ChainFountain
noncomputable section
open MeasureTheory Filter Real

/-- Proposition 3.1 for equations holding almost everywhere. The coefficient and
input may be measurable: no time derivative of either one is needed. This is a
chain-rule conclusion for an a.e. solution, not a measurable-input existence theorem. -/
theorem energy_balance_ae {H g lam β : ℝ} {α u h v w : ℝ → ℝ}
    {μ : Measure ℝ}
    (hh : ∀ᵐ t ∂μ, h t ≠ 0) (hH : ∀ᵐ t ∂μ, H+h t ≠ 0)
    (dh : ∀ᵐ t ∂μ, HasDerivAt h (heightRate (v t) (w t)) t)
    (dv : ∀ᵐ t ∂μ, HasDerivAt v (rise g (α t) (h t) (v t) (w t) (u t)) t)
    (dw : ∀ᵐ t ∂μ, HasDerivAt w (fall H g β (h t) (v t) (w t)) t) :
    ∀ᵐ t ∂μ, HasDerivAt (fun s => energy H g lam (h s) (v s) (w s))
      (lam*g*H*w t-lam*(1/2-α t)*(v t)^3-lam*(1/2-β)*(w t)^3-lam*u t*v t) t := by
  filter_upwards [hh,hH,dh,dv,dw] with t ht hHt hdt hvt hwt
  exact energy_hasDerivAt ht hHt hdt hvt hwt

/-- The localized quadratic generator inequality is algebraic; Dynkin's formula
and the stopped-process expectation inequality remain separate obligations. -/
theorem localized_generator_bound {k₀ k₁ k₂ κ κd G Gmax σ e z : ℝ}
    (hk₀ : 0 ≤ k₀) (hk₁ : κ ≤ k₁) (hk₂ : κ ≤ k₂) (hκd : 0 ≤ κd)
    (hG : G^2 ≤ Gmax^2) :
    k₀*e*errorRate k₁ e z+z/4*zRate k₀ k₂ κd G 0 e z+
      (1/2)*(σ*G)^2*(1/4) ≤ -2*κ*errorEnergy k₀ e z+σ^2*Gmax^2/8 := by
  rw [generator_identity]
  have hn := nominal_decay (e:=e) (z:=z) hk₀ hk₁ hk₂
  have hg := mul_le_mul_of_nonneg_left hG (sq_nonneg σ)
  have hd : 0 ≤ κd*G^2*z^2 := by positivity
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

def fastReference (t : ℝ) := (1/5 : ℝ)+(1/10)*sin (100*t)
def fastRate (t : ℝ) := 10*cos (100*t)
def fastAcceleration (t : ℝ) := -1000*sin (100*t)

theorem fast_reference_derivatives (t : ℝ) :
    HasDerivAt fastReference (fastRate t) t ∧ HasDerivAt fastRate (fastAcceleration t) t := by
  constructor
  · convert! ((((hasDerivAt_id t).const_mul 100).sin).const_mul (1/10)).const_add (1/5) using 1 <;>
      dsimp [fastReference,fastRate] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  · convert! (((hasDerivAt_id t).const_mul 100).cos).const_mul 10 using 1 <;>
      dsimp [fastRate,fastAcceleration] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem fast_reference_bounds (t : ℝ) :
    (1/10 : ℝ) ≤ fastReference t ∧ fastReference t ≤ 3/10 ∧
      |fastRate t| ≤ 10 ∧ |fastAcceleration t| ≤ 1000 := by
  have hs := abs_le.mp (abs_sin_le_one (100*t))
  have hc := abs_cos_le_one (100*t)
  refine ⟨?_,?_,?_,?_⟩
  · dsimp [fastReference]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hs.1]
  · dsimp [fastReference]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hs.2]
  · norm_num [fastRate,abs_mul]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
  · norm_num [fastAcceleration,abs_mul]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [abs_sin_le_one (100*t)]

/-- Appendix A.3, linked to the actual smooth positive bounded-rate reference. -/
theorem counterexample_reference_rate :
    fastReference 0=1/5 ∧ fastRate 0=10 ∧
      internal 2 (981/100) (1/50) (fastReference 0) 0 (fastRate 0) < 0 := by
  norm_num [fastReference,fastRate,internal]

end
end ChainFountain


namespace ChainFountain
noncomputable section
set_option maxHeartbeats 1000000

abbrev State₃ := ℝ × ℝ × ℝ
def heightProjection : State₃ →L[ℝ] ℝ := ContinuousLinearMap.fst ℝ ℝ (ℝ×ℝ)
def riseProjection : State₃ →L[ℝ] ℝ :=
  (ContinuousLinearMap.fst ℝ ℝ ℝ).comp (ContinuousLinearMap.snd ℝ ℝ (ℝ×ℝ))
def fallProjection : State₃ →L[ℝ] ℝ :=
  (ContinuousLinearMap.snd ℝ ℝ ℝ).comp (ContinuousLinearMap.snd ℝ ℝ (ℝ×ℝ))

def openLoopField (H g α β : ℝ) (x : State₃) : State₃ :=
  (heightRate x.2.1 x.2.2,rise g α x.1 x.2.1 x.2.2 0,fall H g β x.1 x.2.1 x.2.2)

/-- The matrix in equation (4.4), as a continuous linear map on product coordinates. -/
def paperJacobian (α β ρ ω : ℝ) : State₃ →L[ℝ] State₃ :=
  ((1/2 : ℝ) • riseProjection - (1/2 : ℝ) • fallProjection).prod
    (((-α*ω^2) • heightProjection - ((1-2*α)*ω) • riseProjection + ω • fallProjection).prod
      ((α*ρ*ω^2) • heightProjection - (ρ*ω) • riseProjection -
        ((1-2*β)*ρ*ω) • fallProjection))

/-- A genuine Frechet derivative of the mechanical field, under the equilibrium
balances. No derivative-identification hypothesis is assumed. -/
theorem open_loop_frechet_derivative {H g α β h s : ℝ}
    (hh : h ≠ 0) (hH : H+h ≠ 0)
    (he₁ : α*s^2=g*h) (he₂ : (1-β)*s^2=g*(H+h)) :
    HasFDerivAt (openLoopField H g α β)
      (paperJacobian α β (h/(H+h)) (s/h)) (h,s,s) := by
  let x : State₃ := (h,s,s)
  have dh := heightProjection.hasFDerivAt (x:=x)
  have dv := riseProjection.hasFDerivAt (x:=x)
  have dw := fallProjection.hasFDerivAt (x:=x)
  have ds := (dv.add dw).mul_const (1/2 : ℝ)
  have dS := ds.mul ds
  have dr := (((dS.sub ((dv.mul dv).const_mul (1-α))).sub (dh.const_mul g)).sub_const 0).mul ((hasFDerivAt_inv hh).comp x dh)
  have df := ((dS.neg.add ((dw.mul dw).const_mul β)).mul ((hasFDerivAt_inv hH).comp x (dh.const_add H))).const_add g
  have dq := (dv.sub dw).mul_const (1/2 : ℝ)
  have dF := dq.prodMk (dr.prodMk df)
  refine (dF.congr_of_eventuallyEq ?_).congr_fderiv ?_
  · apply Filter.Eventually.of_forall
    intro y
    ext <;> simp [openLoopField,heightRate,rise,fall,crownSq,heightProjection,riseProjection,fallProjection] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  · apply ContinuousLinearMap.ext
    intro y
    apply Prod.ext
    · simp [paperJacobian,heightProjection,riseProjection,fallProjection]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    · apply Prod.ext <;>
        simp [paperJacobian,heightProjection,riseProjection,fallProjection,x,
          ContinuousLinearMap.prod_apply,ContinuousLinearMap.comp_apply] <;>
        field_simp
      · (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
      · linear_combination 4*y.1*h*he₂ - 4*y.1*(H+h)*he₁

theorem paper_jacobian_action (α β ρ ω : ℝ) (y : State₃) :
    paperJacobian α β ρ ω y =
      (y.2.1/2-y.2.2/2,
       -α*ω^2*y.1-(1-2*α)*ω*y.2.1+ω*y.2.2,
       α*ρ*ω^2*y.1-ρ*ω*y.2.1-(1-2*β)*ρ*ω*y.2.2) := by
  simp [paperJacobian,heightProjection,riseProjection,fallProjection]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- Genuine derivative with respect to the physical input u, at a fixed state. -/
theorem input_vector_derivative (H g α β h v w u : ℝ) :
    HasDerivAt (fun U => (heightRate v w,rise g α h v w U,fall H g β h v w))
      (0,-1/h,0) u := by
  have hu := ((hasDerivAt_const u (crownSq v w-(1-α)*v^2-g*h)).sub
    (hasDerivAt_id u)).div_const h
  simpa [rise] using! (hasDerivAt_const u (heightRate v w)).prodMk
    (hu.prodMk (hasDerivAt_const u (fall H g β h v w)))

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Metric Real Filter
open scoped Topology

/-- Compactness turns a positive homogeneous quadratic function into a uniform
coercivity estimate. The minimum is proved to be positive, not assumed. -/
theorem quadratic_coercive {V : State₃ → ℝ}
    (hc : Continuous V) (hh : ∀ (a : ℝ) x, V (a • x) = a^2 * V x)
    (hp : ∀ x ≠ 0, 0 < V x) :
    ∃ m > 0, ∀ x, m * ‖x‖^2 ≤ V x := by
  have hne : (sphere (0 : State₃) 1).Nonempty := by
    refine ⟨(1,0,0), ?_⟩
    norm_num [mem_sphere, dist_eq_norm, Prod.norm_def]
  obtain ⟨u,hu,hmin⟩ := (isCompact_sphere (0 : State₃) 1).exists_isMinOn hne hc.continuousOn
  have hun : ‖u‖ = 1 := by simpa [mem_sphere,dist_zero_right] using! hu
  have hup : 0 < V u := hp u (by intro h; simp [h] at hun)
  refine ⟨V u,hup,fun x => ?_⟩
  by_cases hx : x = 0
  · have hz := hh 0 (0 : State₃)
    simpa [hx] using! hz.ge
  · have hn : 0 < ‖x‖ := norm_pos_iff.mpr hx
    have hs : ‖x‖⁻¹ • x ∈ sphere (0 : State₃) 1 := by
      simpa [mem_sphere,dist_zero_right] using! (norm_smul_inv_norm (𝕜:=ℝ) hx)
    have h := mul_le_mul_of_nonneg_left (hmin hs) (sq_nonneg ‖x‖)
    rw [hh] at h
    have he : ‖x‖^2 * (‖x‖⁻¹^2 * V x) = V x := by field_simp
    rw [he] at h
    simpa [mul_comm] using! h

abbrev QuadraticBilin := State₃ →L[ℝ] State₃ →L[ℝ] ℝ

theorem quadratic_bilin_bound (B : QuadraticBilin) (x y : State₃) :
    |B x y| ≤ ‖B‖ * ‖x‖ * ‖y‖ := by
  exact (B x).le_opNorm y |>.trans
    (mul_le_mul_of_nonneg_right (B.le_opNorm x) (norm_nonneg y))

/-- A strict quadratic certificate for the derivative survives the nonlinear
remainder. All constants are obtained from the actual Frechet derivative. -/
theorem nonlinear_quadratic_decay
    {F : State₃ → State₃} {A : State₃ →L[ℝ] State₃} (B : QuadraticBilin)
    (hF : HasFDerivAt F A 0) (hzero : F 0 = 0)
    (hpos : ∀ x ≠ 0, 0 < B x x)
    (hneg : ∀ x ≠ 0, B x (A x) + B (A x) x < 0) :
    ∃ m M κ r : ℝ, 0 < m ∧ 0 < M ∧ 0 < κ ∧ 0 < r ∧
      (∀ x, m*‖x‖^2 ≤ B x x ∧ B x x ≤ M*‖x‖^2) ∧
      ∀ x, ‖x‖ < r → B x (F x)+B (F x) x ≤ -2*κ*(B x x) := by
  obtain ⟨m,hm,hml⟩ := quadratic_coercive
    (B.continuous.clm_apply continuous_id)
    (by intro a x; simp [map_smul,smul_eq_mul]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring) hpos
  obtain ⟨q,hq,hql⟩ := quadratic_coercive
    ((B.continuous.clm_apply A.continuous).add
      ((B.continuous.comp A.continuous).clm_apply continuous_id)).neg
    (by intro a x; simp [map_smul,smul_eq_mul]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring)
    (fun x hx => neg_pos.mpr (hneg x hx))
  let M : ℝ := ‖B‖+1
  have hM : 0 < M := by dsimp [M]; positivity
  have hMv (x : State₃) : B x x ≤ M*‖x‖^2 := by
    have hb := quadratic_bilin_bound B x x
    have hba := le_abs_self (B x x)
    dsimp [M]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [sq_nonneg ‖x‖]
  have heps : 0 < q/(4*M) := by positivity
  obtain ⟨r,hr,hrem⟩ := Metric.eventually_nhds_iff.mp (hF.isLittleO.bound heps)
  refine ⟨m,M,q/(8*M),r,hm,hM,by positivity,hr,
    fun x => ⟨hml x,hMv x⟩,fun x hx => ?_⟩
  have he : ‖F x-A x‖ ≤ q/(4*M)*‖x‖ := by
    simpa [hzero,dist_zero_right] using! hrem (by simpa [dist_zero_right] using! hx)
  have b₁ := quadratic_bilin_bound B x (F x-A x)
  have b₂ := quadratic_bilin_bound B (F x-A x) x
  have hh₁ := mul_le_mul_of_nonneg_left he (mul_nonneg (norm_nonneg B) (norm_nonneg x))
  have hh₂ := mul_le_mul_of_nonneg_right
    (mul_le_mul_of_nonneg_left he (norm_nonneg B)) (norm_nonneg x)
  have hl := hql x
  dsimp only [Function.comp_apply,id_eq] at hl
  have heq : B x (F x)+B (F x) x = B x (A x)+B (A x) x +
      B x (F x-A x)+B (F x-A x) x := by simp [map_sub]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hlin : B x (F x)+B (F x) x ≤ -q/2*‖x‖^2 := by
    have hnM : ‖B‖ ≤ M := by dsimp [M]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
    have hcoef : 2*‖B‖*(q/(4*M)) ≤ q/2 := by
      calc
        2*‖B‖*(q/(4*M)) ≤ 2*M*(q/(4*M)) := by gcongr
        _ = q/2 := by field_simp <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    have hcs := mul_le_mul_of_nonneg_right hcoef (sq_nonneg ‖x‖)
    rw [heq]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [le_abs_self (B x (F x-A x)),le_abs_self (B (F x-A x) x)]
  have hc := mul_le_mul_of_nonneg_left (hMv x) (show 0 ≤ q/(4*M) by positivity)
  have hc' : q/(4*M)*(M*‖x‖^2) = q/4*‖x‖^2 := by field_simp <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [hc'] at hc
  have heκ : 2*(q/(8*M)) = q/(4*M) := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [neg_mul,heκ]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_nonneg hq.le (sq_nonneg ‖x‖)]

end
end ChainFountain


namespace ChainFountain
noncomputable section
set_option maxHeartbeats 800000

def linearSquare (L : State₃ →L[ℝ] ℝ) : QuadraticBilin := L.smulRight L

/-- An explicit sum-of-squares solution of the strict cubic Lyapunov problem.
No spectral-to-Lyapunov existence theorem is assumed. -/
def cubicBilin (a b c : ℝ) : QuadraticBilin :=
  linearSquare (a • fallProjection + (a^2) • riseProjection + (a*b-c) • heightProjection) +
  (a*c) • linearSquare (riseProjection + a • heightProjection) +
  (2*c*(a*b-c)) • linearSquare heightProjection +
  b • linearSquare (fallProjection + a • riseProjection) +
  (1+b) • linearSquare (b • riseProjection + c • heightProjection) +
  linearSquare (b • fallProjection + c • riseProjection) +
  (c*(a*b-c)) • linearSquare riseProjection

theorem cubic_bilin_squares (a b c : ℝ) (x : State₃) :
    cubicBilin a b c x x =
      (a*x.2.2+a^2*x.2.1+(a*b-c)*x.1)^2 + a*c*(x.2.1+a*x.1)^2 +
      2*c*(a*b-c)*x.1^2 + b*(x.2.2+a*x.2.1)^2 +
      (1+b)*(b*x.2.1+c*x.1)^2 + (b*x.2.2+c*x.2.1)^2 +
      c*(a*b-c)*x.2.1^2 := by
  simp [cubicBilin,linearSquare,heightProjection,riseProjection,fallProjection]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem cubic_bilin_positive {a b c : ℝ} (ha : 0<a) (hb : 0<b)
    (hc : 0<c) (hD : c<a*b) (x : State₃) (hx : x≠0) :
    0 < cubicBilin a b c x x := by
  rw [cubic_bilin_squares]
  have hD' : 0<a*b-c := sub_pos.mpr hD
  have h₁ : 0≤(a*x.2.2+a^2*x.2.1+(a*b-c)*x.1)^2 := sq_nonneg _
  have h₂ : 0≤ a*c*(x.2.1+a*x.1)^2 := by positivity
  have h₃ : 0≤2*c*(a*b-c)*x.1^2 := by positivity
  have h₄ : 0≤ b*(x.2.2+a*x.2.1)^2 := by positivity
  have h₅ : 0≤(1+b)*(b*x.2.1+c*x.1)^2 := by positivity
  have h₆ : 0≤(b*x.2.2+c*x.2.1)^2 := sq_nonneg _
  have h₇ : 0≤ c*(a*b-c)*x.2.1^2 := by positivity
  by_cases hx₁ : x.1=0
  · by_cases hx₂ : x.2.1=0
    · have hx₃ : x.2.2≠0 := by
        intro hh; apply hx; exact Prod.ext hx₁ (Prod.ext hx₂ hh)
      have h : 0 < (a*x.2.2+a^2*x.2.1+(a*b-c)*x.1)^2 := by
        simp only [hx₁,hx₂,mul_zero,add_zero]
        exact sq_pos_of_ne_zero (mul_ne_zero ha.ne' hx₃)
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
    · have h : 0 < c*(a*b-c)*x.2.1^2 := mul_pos (mul_pos hc hD') (sq_pos_of_ne_zero hx₂)
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  · have h : 0 < 2*c*(a*b-c)*x.1^2 := by positivity
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

def companionField (a b c : ℝ) (x : State₃) : State₃ :=
  (x.2.1,x.2.2,-c*x.1-b*x.2.1-a*x.2.2)

theorem cubic_bilin_dissipation (a b c : ℝ) (x : State₃) :
    cubicBilin a b c x (companionField a b c x) +
      cubicBilin a b c (companionField a b c x) x =
      -2*(a*b-c)*(a*c*x.1^2+b*x.2.1^2+b*x.2.2^2) := by
  simp [cubicBilin,linearSquare,companionField,heightProjection,riseProjection,fallProjection]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem cubic_bilin_strict_decay {a b c : ℝ} (ha : 0<a) (hb : 0<b)
    (hc : 0<c) (hD : c<a*b) (x : State₃) (hx : x≠0) :
    cubicBilin a b c x (companionField a b c x) +
      cubicBilin a b c (companionField a b c x) x < 0 := by
  rw [cubic_bilin_dissipation]
  have hn : 0 < a*c*x.1^2+b*x.2.1^2+b*x.2.2^2 := by
    have h₁ : 0≤ a*c*x.1^2 := by positivity
    have h₂ : 0≤ b*x.2.1^2 := by positivity
    have h₃ : 0≤ b*x.2.2^2 := by positivity
    by_cases hx₁ : x.1=0
    · by_cases hx₂ : x.2.1=0
      · have hx₃ : x.2.2≠0 := by intro hh; exact hx (Prod.ext hx₁ (Prod.ext hx₂ hh))
        have h : 0<b*x.2.2^2 := by positivity
        (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
      · have h : 0<b*x.2.1^2 := by positivity
        (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
    · have h : 0<a*c*x.1^2 := by positivity
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  exact mul_neg_of_neg_of_pos (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) hn

/-- The observability coordinates (height, its linearized first and second
derivatives) put the actual Jacobian into cubic companion form. -/
def observabilityMap (α β ρ ω : ℝ) : State₃ →L[ℝ] State₃ :=
  heightProjection.prod
    ((heightProjection.comp (paperJacobian α β ρ ω)).prod
      ((heightProjection.comp (paperJacobian α β ρ ω)).comp (paperJacobian α β ρ ω)))

theorem observability_intertwines (α β ρ ω : ℝ) (hrel : α=(1-β)*ρ) (x : State₃) :
    observabilityMap α β ρ ω (paperJacobian α β ρ ω x) =
      companionField (coeff₂ ρ ω) (coeff₁ α ρ ω) (coeff₀ α ρ ω)
        (observabilityMap α β ρ ω x) := by
  simp [observabilityMap,paperJacobian,heightProjection,riseProjection,fallProjection,
    companionField,coeff₂,coeff₁,coeff₀]
  rw [hrel]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem observability_injective {α β ρ ω : ℝ} (ha : 0<α) (hw : 0<ω)
    (hrel : α=(1-β)*ρ) : Function.Injective (observabilityMap α β ρ ω) := by
  apply (injective_iff_map_eq_zero _).mpr
  intro x hx
  have h₁ := congrArg Prod.fst hx
  have h₂ := congrArg (fun z : State₃ => z.2.1) hx
  have h₃ := congrArg (fun z : State₃ => z.2.2) hx
  simp [observabilityMap,paperJacobian,heightProjection,riseProjection,fallProjection] at h₁ h₂ h₃
  have hvw : x.2.1=x.2.2 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have he : 2*α*ω*x.2.2=0 := by
    rw [hrel] at h₃ ⊢
    rw [h₁,hvw] at h₃
    linear_combination h₃
  have hz : x.2.2=0 := (mul_eq_zero.mp he).resolve_left (by positivity)
  exact Prod.ext h₁ (Prod.ext (hvw.trans hz) hz)

def plantBilin (α β ρ ω : ℝ) : QuadraticBilin :=
  (cubicBilin (coeff₂ ρ ω) (coeff₁ α ρ ω) (coeff₀ α ρ ω)).bilinearComp
    (observabilityMap α β ρ ω) (observabilityMap α β ρ ω)

theorem plant_strict_lyapunov {α β ρ ω : ℝ}
    (ha : 0<α) (ha1 : α<1/2) (hr : 0<ρ) (hr1 : ρ<1) (hw : 0<ω)
    (hrel : α=(1-β)*ρ) :
    (∀ x≠0, 0<plantBilin α β ρ ω x x) ∧
    ∀ x≠0, plantBilin α β ρ ω x (paperJacobian α β ρ ω x) +
      plantBilin α β ρ ω (paperJacobian α β ρ ω x) x < 0 := by
  obtain ⟨h₂,h₁,h₀,hH⟩ := hurwitz_conditions ha ha1 hr hr1 hw
  have hinj := observability_injective ha hw hrel
  have hne (x : State₃) (hx : x≠0) : observabilityMap α β ρ ω x ≠ 0 := by
    intro h; apply hx; apply hinj; simpa using! h
  constructor
  · intro x hx
    simp only [plantBilin,ContinuousLinearMap.bilinearComp_apply]
    exact cubic_bilin_positive h₂ h₁ h₀ hH _ (hne x hx)
  · intro x hx
    simp only [plantBilin,ContinuousLinearMap.bilinearComp_apply]
    rw [observability_intertwines α β ρ ω hrel]
    exact cubic_bilin_strict_decay h₂ h₁ h₀ hH _ (hne x hx)

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Metric Real
open scoped Topology NNReal

/-- A finite-interval first-exit principle. Only continuity on the interval is
required; the curve is neither assumed to be safe nor defined by the ODE later. -/
theorem no_exit_on_Icc_of_prefix_bound
    {E : Type*} [TopologicalSpace E] {x : ℝ → E} {B K : Set E} {T : ℝ}
    (hT : 0 ≤ T) (hx : ContinuousOn x (Icc 0 T))
    (hB : IsClosed B) (hKB : K ⊆ interior B) (hx₀ : x 0 ∈ interior B)
    (hprefix : ∀ S ∈ Icc 0 T, (∀ t ∈ Icc 0 S, x t ∈ B) → x S ∈ K) :
    ∀ t ∈ Icc 0 T, x t ∈ K := by
  let p : ℝ → ℝ := fun t => max 0 (min T t)
  have hp : Continuous p := continuous_const.max (continuous_const.min continuous_id)
  have hpm (t : ℝ) : p t ∈ Icc 0 T :=
    ⟨le_max_left _ _, max_le hT (min_le_left _ _)⟩
  have hpeq (t : ℝ) (ht : t ∈ Icc 0 T) : p t = t := by
    simp only [p, min_eq_right ht.2, max_eq_right ht.1]
  have hstay := no_exit_of_prefix_bound (hx.comp_continuous hp hpm) hB hKB
    (show x (p 0) ∈ interior B by simpa [hpeq 0 ⟨le_rfl,hT⟩] using hx₀) (by
      intro S hS hb
      have hST : min S T ∈ Icc (0:ℝ) T := ⟨le_min hS hT, min_le_right _ _⟩
      have hh := hprefix (min S T) hST (by
        intro t ht
        have htT : t ≤ T := ht.2.trans (min_le_right _ _)
        have htS : t ≤ S := ht.2.trans (min_le_left _ _)
        simpa only [Function.comp_apply, hpeq t ⟨ht.1,htT⟩] using hb t ⟨ht.1,htS⟩)
      simpa only [Function.comp_apply, p, min_comm T S, max_eq_right (le_min hS hT)] using hh)
  intro t ht
  simpa only [Function.comp_apply, hpeq t ht] using hstay t ht.1

/-- An a priori prefix bound turns box-wise Lipschitz uniqueness into
uniqueness against arbitrary classical competitors on every finite interval. -/
theorem unique_on_Icc_of_prefix_bound
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    {F : ℝ → E → E} {B K : Set E} {L : ℝ≥0} {x₀ : E} {T : ℝ}
    (hB : IsClosed B) (hKB : K ⊆ interior B) (hx₀ : x₀ ∈ interior B)
    (hL : ∀ t, LipschitzOnWith L (F t) B)
    (hprefix : ∀ (z : ℝ → E) S, 0 ≤ S → z 0 = x₀ →
      (∀ t ∈ Icc 0 S, z t ∈ B) →
      (∀ t ∈ Icc 0 S, HasDerivAt z (F t (z t)) t) → z S ∈ K)
    {x y : ℝ → E} (hT : 0 ≤ T) (hx : x 0 = x₀) (hy : y 0 = x₀)
    (hdx : ∀ t ∈ Icc 0 T, HasDerivAt x (F t (x t)) t)
    (hdy : ∀ t ∈ Icc 0 T, HasDerivAt y (F t (y t)) t) :
    EqOn x y (Icc 0 T) := by
  have stay (z : ℝ → E) (hz : z 0 = x₀)
      (hd : ∀ t ∈ Icc 0 T, HasDerivAt z (F t (z t)) t) :
      ∀ t ∈ Icc 0 T, z t ∈ B := by
    have hc : ContinuousOn z (Icc 0 T) :=
      fun t ht => (hd t ht).continuousAt.continuousWithinAt
    have hs := no_exit_on_Icc_of_prefix_bound hT hc hB hKB (hz ▸ hx₀) (by
      intro S hS hb
      exact hprefix z S hS.1 hz hb (fun t ht => hd t ⟨ht.1,ht.2.trans hS.2⟩))
    exact fun t ht => interior_subset (hKB (hs t ht))
  exact ODE_solution_unique_of_mem_Icc_right (s := fun _ => B)
    (fun t _ => hL t)
    (fun t ht => (hdx t ht).continuousAt.continuousWithinAt)
    (fun t ht => (hdx t (Ico_subset_Icc_self ht)).hasDerivWithinAt)
    (fun t ht => stay x hx hdx t (Ico_subset_Icc_self ht))
    (fun t ht => (hdy t ht).continuousAt.continuousWithinAt)
    (fun t ht => (hdy t (Ico_subset_Icc_self ht)).hasDerivWithinAt)
    (fun t ht => stay y hy hdy t (Ico_subset_Icc_self ht)) (hx.trans hy.symm)

/-- Every classical mechanical solution from the certified initial data is
safe for its whole supplied interval; no box or positive-height premise. -/
theorem GlobalTrackingData.classical_safe_on_Icc (c : GlobalTrackingData)
    {x : ℝ → MechanicalState} {T : ℝ} (hT : 0 ≤ T) (hx : x 0 = c.x₀)
    (hd : ∀ t ∈ Icc 0 T, HasDerivAt x (c.field t (x t)) t) :
    ∀ t ∈ Icc 0 T, x t ∈ c.safeBox := by
  apply no_exit_on_Icc_of_prefix_bound hT
    (fun t ht => (hd t ht).continuousAt.continuousWithinAt)
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    (hx ▸ c.safeBox_interior c.initial_mem)
  intro S hS hb
  exact c.prefix_bound x S hS.1 hx hb (fun t ht => hd t ⟨ht.1,ht.2.trans hS.2⟩)

/-- Unrestricted finite-interval classical uniqueness, including the nominal
kappa_d = 0 regime. Competitors may have any arbitrary extension outside [0,T]. -/
theorem GlobalTrackingData.classical_unique_on_Icc (c : GlobalTrackingData)
    {x y : ℝ → MechanicalState} {T : ℝ} (hT : 0 ≤ T)
    (hx : x 0 = c.x₀) (hy : y 0 = c.x₀)
    (hdx : ∀ t ∈ Icc 0 T, HasDerivAt x (c.field t (x t)) t)
    (hdy : ∀ t ∈ Icc 0 T, HasDerivAt y (c.field t (y t)) t) :
    EqOn x y (Icc 0 T) := by
  obtain ⟨L,C,hL,hcont,hC⟩ := c.field_bounds
  exact unique_on_Icc_of_prefix_bound
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    (c.safeBox_interior c.initial_mem) hL c.prefix_bound hT hx hy hdx hdy

/-- Global tracking with uniqueness against every classical solution on any
finite forward interval, for both robust and undamped nominal gains. -/
theorem GlobalTrackingData.exists_unique_global_tracking (c : GlobalTrackingData) :
    ∃ x : ℝ → MechanicalState, x 0 = c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      (∀ t ≥ 0, x t ∈ c.safeBox) ∧
      (c.dbar = 0 → ∀ t ≥ 0,
        c.stateEnergy t (x t) ≤ exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀) ∧
      (0 < c.κd → ∀ t ≥ 0,
        c.stateEnergy t (x t) ≤ exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-exp (-2*c.κ*t))) ∧
      ∀ T ≥ 0, ∀ y : ℝ → MechanicalState, y 0 = c.x₀ →
        (∀ t ∈ Icc 0 T, HasDerivAt y (c.field t (y t)) t) → EqOn x y (Icc 0 T) := by
  obtain ⟨x,hx,hd,hb,hn,hr⟩ := c.exists_global_tracking
  refine ⟨x,hx,hd,hb,hn,hr,?_⟩
  intro T hT y hy hdy
  exact c.classical_unique_on_Icc hT hx hy (fun t ht => hd t ht.1) hdy

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Metric Real Filter
open scoped Topology NNReal
set_option maxHeartbeats 800000

def clipState (r : ℝ) (x : State₃) : State₃ :=
  (max (-r) (min r x.1),max (-r) (min r x.2.1),max (-r) (min r x.2.2))

theorem clip_state_lipschitz (r : ℝ) : LipschitzWith 1 (clipState r) := by
  have hh : LipschitzWith 1 (fun x : State₃ => max (-r) (min r x.1)) :=
    (LipschitzWith.prod_fst.const_min _).const_max _
  have hv : LipschitzWith 1 (fun x : State₃ => x.2.1) := by
    simpa using! LipschitzWith.prod_fst.comp (LipschitzWith.prod_snd (α:=ℝ) (β:=ℝ×ℝ))
  have hw : LipschitzWith 1 (fun x : State₃ => x.2.2) := by
    simpa using! LipschitzWith.prod_snd.comp (LipschitzWith.prod_snd (α:=ℝ) (β:=ℝ×ℝ))
  simpa only [max_self] using! hh.prodMk
    (((hv.const_min r).const_max (-r)).prodMk ((hw.const_min r).const_max (-r)))

theorem clip_state_mem {r : ℝ} (hr : 0≤ r) (x : State₃) :
    clipState r x ∈ closedBall 0 r := by
  have hc (s : ℝ) : |max (-r) (min r s)|≤ r :=
    abs_le.mpr ⟨le_max_left _ _,max_le (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) (min_le_left _ _)⟩
  simpa only [mem_closedBall,dist_zero_right,Prod.norm_def,Real.norm_eq_abs,clipState]
    using max_le (hc x.1) (max_le (hc x.2.1) (hc x.2.2))

theorem clip_state_eq {r : ℝ} {x : State₃} (hx : x ∈ closedBall 0 r) :
    clipState r x = x := by
  simp only [mem_closedBall,dist_zero_right,Prod.norm_def,Real.norm_eq_abs,max_le_iff,abs_le] at hx
  simp [clipState,min_eq_right hx.1.2,max_eq_right hx.1.1,
    min_eq_right hx.2.1.2,max_eq_right hx.2.1.1,
    min_eq_right hx.2.2.2,max_eq_right hx.2.2.1]

theorem quadratic_trajectory_estimate (B : QuadraticBilin)
    {F : State₃ → State₃} {κ T : ℝ} {x : ℝ → State₃} (hκ : 0<κ)
    (hd : ∀ t ∈ Icc 0 T, HasDerivAt x (F (x t)) t)
    (hdec : ∀ t ∈ Icc 0 T, B (x t) (F (x t))+B (F (x t)) (x t) ≤ -2*κ*(B (x t) (x t))) :
    ∀ t ∈ Icc 0 T, B (x t) (x t) ≤ exp (-2*κ*t)*(B (x 0) (x 0)) := by
  have hder (t : ℝ) (ht : t∈Icc 0 T) :
      HasDerivAt (fun s => B (x s) (x s)) (B (x t) (F (x t))+B (F (x t)) (x t)) t := by
    convert! (B.hasFDerivAt.comp_hasDerivAt t (hd t ht)).clm_apply (hd t ht) using 1
    exact add_comm _ _
  have he := scalar_comparison (C:=0) hκ
    (fun t ht => (hder t ht).continuousAt.continuousWithinAt)
    (fun t ht => (hder t (Ico_subset_Icc_self ht)).hasDerivWithinAt)
    (fun t ht => by simpa using! hdec t (Ico_subset_Icc_self ht))
  simpa [envelope] using! he

/-- Full nonlinear forward existence and exponential decay near an equilibrium.
The hypotheses are a C1 field and a strict quadratic certificate for its genuine
derivative. The solution, invariant neighbourhood and decay constants are built. -/
theorem local_exponential_exists_unique_of_quadratic
    {F : State₃ → State₃} {A : State₃ →L[ℝ] State₃} {R : ℝ}
    (hR : 0<R) (hsmooth : ContDiffOn ℝ 1 F (ball 0 R))
    (hF : HasFDerivAt F A 0) (hzero : F 0=0) (B : QuadraticBilin)
    (hpos : ∀ x≠0, 0<B x x)
    (hneg : ∀ x≠0, B x (A x)+B (A x) x<0) :
    ∃ δ C κ : ℝ, 0<δ ∧ 0<C ∧ 0<κ ∧
      ∀ x₀ : State₃, ‖x₀‖<δ → ∃ x : ℝ → State₃,
        x 0=x₀ ∧ (∀ t≥0, HasDerivAt x (F (x t)) t) ∧
        (∀ t≥0, x t∈ball 0 R ∧ ‖x t‖≤ C*exp (-κ*t)*‖x₀‖) ∧
        ∀ T ≥ 0, ∀ y : ℝ → State₃, y 0 = x₀ →
          (∀ t ∈ Icc 0 T, HasDerivAt y (F (y t)) t) → EqOn x y (Icc 0 T) := by
  obtain ⟨m,M,κ,r,hm,hM,hκ,hr,hbounds,hdec⟩ :=
    nonlinear_quadratic_decay B hF hzero hpos hneg
  let C := sqrt (M/m)
  have hC : 0<C := sqrt_pos.2 (div_pos hM hm)
  have hCsq : C^2=M/m := sq_sqrt (div_nonneg hM.le hm.le)
  have hMC : m*C^2=M := by rw [hCsq]; field_simp
  let ρ := min r R / 2
  have hρ : 0<ρ := by dsimp [ρ]; positivity
  have hρr : ρ<r := by dsimp [ρ]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [min_le_left r R]
  have hρR : ρ<R := by dsimp [ρ]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [min_le_right r R]
  let δ := min (ρ/2) (ρ/(2*C))
  have hδ : 0<δ := by dsimp [δ]; positivity
  refine ⟨δ,C,κ,hδ,hC,hκ,fun x₀ hx₀ => ?_⟩
  have hxρ : ‖x₀‖<ρ/2 := lt_of_lt_of_le hx₀ (min_le_left _ _)
  have hxC : C*‖x₀‖≤ρ/2 := by
    have hh := lt_of_lt_of_le hx₀ (min_le_right _ _)
    have := (lt_div_iff₀ (show 0<2*C by positivity)).mp hh
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hsub : closedBall (0:State₃) ρ ⊆ ball 0 R :=
    closedBall_subset_ball hρR
  obtain ⟨L,N,hL,hN⟩ := smooth_compact_convex_bounds isOpen_ball hsmooth
    (isCompact_closedBall (0:State₃) ρ) (convex_closedBall (0:State₃) ρ) hsub
  have hKsub : closedBall (0:State₃) (ρ/2) ⊆ interior (closedBall 0 ρ) := by
    rw [interior_closedBall (0:State₃) hρ.ne']
    exact closedBall_subset_ball (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith)
  have hinit : x₀ ∈ interior (closedBall (0:State₃) ρ) :=
    hKsub (by simpa [mem_closedBall,dist_zero_right] using! hxρ.le)
  have hprefix (x : ℝ → State₃) (T : ℝ) (_hT : 0≤ T) (h₀ : x 0=x₀)
      (hbox : ∀ t∈Icc 0 T, x t∈closedBall 0 ρ)
      (hd : ∀ t∈Icc 0 T, HasDerivAt x (F (x t)) t) : x T∈closedBall 0 (ρ/2) := by
    have he := quadratic_trajectory_estimate B hκ hd (fun t ht =>
      hdec _ (lt_of_le_of_lt (by simpa [mem_closedBall,dist_zero_right] using! hbox t ht) hρr))
    have ht : T∈Icc (0:ℝ) T := ⟨_hT,le_rfl⟩
    have hE := he T ht
    rw [h₀] at hE
    have e0 : 0≤ B x₀ x₀ := (mul_nonneg hm.le (sq_nonneg ‖x₀‖)).trans (hbounds x₀).1
    have ee : exp (-2*κ*T)≤1 := exp_le_one_iff.mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith)
    have hcap : B (x T) (x T) ≤ M*‖x₀‖^2 :=
      hE.trans ((mul_le_of_le_one_left e0 ee).trans (hbounds x₀).2)
    have hs : (C*‖x₀‖)^2 ≤ (ρ/2)^2 := sq_le_sq₀ (by positivity) (by positivity) |>.2 hxC
    have hs' := mul_le_mul_of_nonneg_left hs hm.le
    rw [mul_pow,← mul_assoc,hMC] at hs'
    have hmineq := (hbounds (x T)).1.trans hcap
    have hsmall : ‖x T‖≤ρ/2 := (sq_le_sq₀ (norm_nonneg _) (by positivity)).mp
      ((mul_le_mul_iff_right₀ hm).mp (hmineq.trans hs'))
    simpa [mem_closedBall,dist_zero_right] using! hsmall
  obtain ⟨x,h₀,hd,hstay⟩ := global_exists_of_retraction_and_prefix
    (F:=fun _ x => F x) isClosed_closedBall hKsub (clip_state_lipschitz ρ)
    (clip_state_mem hρ.le) (fun _ hx => clip_state_eq hx) (fun _ => hL)
    (fun _ _ => continuous_const) (fun _ x hx => hN x hx) x₀ hinit hprefix
  have hu : ∀ T ≥ 0, ∀ y : ℝ → State₃, y 0 = x₀ →
      (∀ t ∈ Icc 0 T, HasDerivAt y (F (y t)) t) → EqOn x y (Icc 0 T) := by
    intro T hT y hy hdy
    exact unique_on_Icc_of_prefix_bound (F := fun _ z => F z)
      isClosed_closedBall hKsub hinit (fun _ => hL) hprefix hT h₀ hy
      (fun t ht => hd t ht.1) hdy
  refine ⟨x,h₀,hd,(fun t ht => ⟨?_,?_⟩),hu⟩
  · exact hsub (closedBall_subset_closedBall (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) (hstay t ht))
  · have he := quadratic_trajectory_estimate B hκ
      (fun s hs => hd s hs.1) (fun s hs => hdec _ (by
        have hb : ‖x s‖≤ρ/2 := by simpa [mem_closedBall,dist_zero_right] using! hstay s hs.1
        (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith)) t ⟨ht,le_rfl⟩
    rw [h₀] at he
    have hV := (hbounds (x t)).1.trans (he.trans
      (mul_le_mul_of_nonneg_left (hbounds x₀).2 (exp_pos _).le))
    have heexp : exp (-2*κ*t)=(exp (-κ*t))^2 := by rw [pow_two,← exp_add]; congr 1 <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    rw [heexp] at hV
    have hprod : m*(C*exp (-κ*t)*‖x₀‖)^2 = (exp (-κ*t))^2*(M*‖x₀‖^2) := by
      calc
        _ = (m*C^2)*(exp (-κ*t))^2*‖x₀‖^2 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
        _ = _ := by rw [hMC]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    have hs : ‖x t‖^2 ≤ (C*exp (-κ*t)*‖x₀‖)^2 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
    exact (sq_le_sq₀ (norm_nonneg _) (by positivity)).mp hs

/-- Compatibility form of the nonlinear existence and decay theorem. -/
theorem local_exponential_exists_of_quadratic
    {F : State₃ → State₃} {A : State₃ →L[ℝ] State₃} {R : ℝ}
    (hR : 0<R) (hsmooth : ContDiffOn ℝ 1 F (ball 0 R))
    (hF : HasFDerivAt F A 0) (hzero : F 0=0) (B : QuadraticBilin)
    (hpos : ∀ x≠0, 0<B x x)
    (hneg : ∀ x≠0, B x (A x)+B (A x) x<0) :
    ∃ δ C κ : ℝ, 0<δ ∧ 0<C ∧ 0<κ ∧
      ∀ x₀ : State₃, ‖x₀‖<δ → ∃ x : ℝ → State₃,
        x 0=x₀ ∧ (∀ t≥0, HasDerivAt x (F (x t)) t) ∧
        ∀ t≥0, x t∈ball 0 R ∧ ‖x t‖≤ C*exp (-κ*t)*‖x₀‖ := by
  obtain ⟨δ,C,κ,hδ,hC,hκ,hsol⟩ :=
    local_exponential_exists_unique_of_quadratic hR hsmooth hF hzero B hpos hneg
  refine ⟨δ,C,κ,hδ,hC,hκ,?_⟩
  intro x₀ hx₀
  obtain ⟨x,hx,hd,hb,hu⟩ := hsol x₀ hx₀
  exact ⟨x,hx,hd,hb⟩

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Metric Real
set_option maxHeartbeats 800000

theorem open_loop_equilibrium_of_balances {H g α β h s : ℝ}
    (hh : h≠0) (hH : H+h≠0)
    (he₁ : α*s^2=g*h) (he₂ : (1-β)*s^2=g*(H+h)) :
    openLoopField H g α β (h,s,s)=0 := by
  apply Prod.ext
  · simp [openLoopField,heightRate]
  · apply Prod.ext
    · change (crownSq s s-(1-α)*s^2-g*h-0)/h=0
      apply (div_eq_zero_iff).mpr
      left
      unfold crownSq
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [he₁]
    · simp [openLoopField,fall,crownSq]
      field_simp
      linear_combination -he₂

/-- Theorem 4.1's nonlinear conclusion. For each sufficiently close initial
state an actual forward-global solution is constructed, remains in h>0, and
converges exponentially to the positive uncontrolled equilibrium. -/
theorem open_loop_local_exponential_unique {H g α β h s : ℝ}
    (hH : 0<H) (hh : 0<h) (hs : 0<s) (ha : 0<α) (hb : 0≤β)
    (hab : α+β<1/2)
    (he₁ : α*s^2=g*h) (he₂ : (1-β)*s^2=g*(H+h)) :
    ∃ δ C κ : ℝ, 0<δ ∧ 0<C ∧ 0<κ ∧
      ∀ x₀ : State₃, ‖x₀-(h,s,s)‖<δ → ∃ x : ℝ → State₃,
        x 0=x₀ ∧ (∀ t≥0, HasDerivAt x (openLoopField H g α β (x t)) t) ∧
        (∀ t≥0, 0<(x t).1 ∧ ‖x t-(h,s,s)‖≤ C*exp (-κ*t)*‖x₀-(h,s,s)‖) ∧
        ∀ T ≥ 0, ∀ z : ℝ → State₃, z 0 = x₀ →
          (∀ t ∈ Icc 0 T, HasDerivAt z (openLoopField H g α β (z t)) t) →
          EqOn x z (Icc 0 T) := by
  have hHp : 0<H+h := add_pos hH hh
  have hρ : 0<h/(H+h) := div_pos hh hHp
  have hρ1 : h/(H+h)<1 := (div_lt_one hHp).mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith)
  have hω : 0<s/h := div_pos hs hh
  have hrel : α=(1-β)*(h/(H+h)) := by
    rw [← mul_div_assoc]
    apply (eq_div_iff hHp.ne').mpr
    apply mul_right_cancel₀ (sq_pos_of_pos hs).ne'
    linear_combination (H+h)*he₁-h*he₂
  let A := paperJacobian α β (h/(H+h)) (s/h)
  let B := plantBilin α β (h/(H+h)) (s/h)
  let F : State₃ → State₃ := fun y => openLoopField H g α β ((h,s,s)+y)
  have hder : HasFDerivAt F A 0 := by
    have hc := (hasFDerivAt_id (𝕜:=ℝ) (0:State₃)).const_add (h,s,s)
    have hd := open_loop_frechet_derivative hh.ne' hHp.ne' he₁ he₂
    have hd' : HasFDerivAt (openLoopField H g α β) A ((h,s,s)+(0:State₃)) := by
      simpa [A] using! hd
    simpa [F,A] using! hd'.comp (0:State₃) hc
  have hz : F 0=0 := by
    simpa [F] using! open_loop_equilibrium_of_balances hh.ne' hHp.ne' he₁ he₂
  have hcoord (x : State₃) : |x.1|≤‖x‖ := by
    simpa [Prod.norm_def,Real.norm_eq_abs] using! (le_max_left |x.1| (max |x.2.1| |x.2.2|))
  have hpositive (y : State₃) (hy : y∈ball 0 (h/2)) : 0<h+y.1 := by
    have hn : ‖y‖<h/2 := by simpa [mem_ball,dist_zero_right] using! hy
    have hc := (abs_le.mp (hcoord y)).1
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hsm : ContDiffOn ℝ 1 F (ball 0 (h/2)) := by
    intro y hy
    have hp := hpositive y hy
    have hpH : 0<H+(h+y.1) := add_pos hH hp
    apply ContDiffAt.contDiffWithinAt
    dsimp [F,openLoopField,heightRate,rise,fall,crownSq]
    fun_prop (disch := first | exact hp.ne' | exact hpH.ne' | norm_num)
  have hly := plant_strict_lyapunov ha (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith) hρ hρ1 hω hrel
  obtain ⟨δ,C,κ,hδ,hC,hκ,hsol⟩ := local_exponential_exists_unique_of_quadratic
    (by positivity : 0<h/2) hsm hder hz B hly.1 hly.2
  refine ⟨δ,C,κ,hδ,hC,hκ,fun x₀ hx₀ => ?_⟩
  obtain ⟨y,hy₀,hyD,hyB,hyU⟩ := hsol (x₀-(h,s,s)) hx₀
  refine ⟨fun t => (h,s,s)+y t,by simp [hy₀],(fun t ht => ?_),(fun t ht => ?_),?_⟩
  · simpa [F] using! (hyD t ht).const_add (h,s,s)
  · exact ⟨hpositive (y t) (hyB t ht).1,by simpa using! (hyB t ht).2⟩

  · intro T hT z hz hzD
    have heq := hyU T hT (fun t => z t-(h,s,s)) (by simp [hz]) (by
      intro t ht
      simpa [F] using (hzD t ht).sub_const (h,s,s))
    intro t ht
    have hh := heq ht
    dsimp only at hh
    change (h,s,s)+y t=z t
    rw [hh]
    abel

/-- The nonlinear existence and exponential decay statement, with uniqueness
available in `open_loop_local_exponential_unique`. -/
theorem open_loop_local_exponential {H g α β h s : ℝ}
    (hH : 0<H) (hh : 0<h) (hs : 0<s) (ha : 0<α) (hb : 0≤β)
    (hab : α+β<1/2)
    (he₁ : α*s^2=g*h) (he₂ : (1-β)*s^2=g*(H+h)) :
    ∃ δ C κ : ℝ, 0<δ ∧ 0<C ∧ 0<κ ∧
      ∀ x₀ : State₃, ‖x₀-(h,s,s)‖<δ → ∃ x : ℝ → State₃,
        x 0=x₀ ∧ (∀ t≥0, HasDerivAt x (openLoopField H g α β (x t)) t) ∧
        ∀ t≥0, 0<(x t).1 ∧ ‖x t-(h,s,s)‖≤ C*exp (-κ*t)*‖x₀-(h,s,s)‖ := by
  obtain ⟨δ,C,κ,hδ,hC,hκ,hsol⟩ :=
    open_loop_local_exponential_unique hH hh hs ha hb hab he₁ he₂
  refine ⟨δ,C,κ,hδ,hC,hκ,?_⟩
  intro x₀ hx₀
  obtain ⟨x,hx,hd,hb,hu⟩ := hsol x₀ hx₀
  exact ⟨x,hx,hd,hb⟩

end
end ChainFountain

/-
Adapted from mathlib's PicardLindelof.lean (pinned v4.19.0).
Copyright (c) 2021 Yury Kudryashov. All rights reserved.
Released under Apache 2.0 license as described in LICENSE.
Original authors: Yury Kudryashov, Winston Yin.
Changes: measurable time dependence; Lebesgue integral fixed points.
-/

namespace ChainFountain
open Filter Function Set Metric TopologicalSpace intervalIntegral MeasureTheory
open MeasureTheory.MeasureSpace (volume)
open scoped Filter Topology NNReal ENNReal Nat Interval
noncomputable section
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- Bounded, uniformly state-Lipschitz Caratheodory data. The measurability
condition is on every continuous test curve and contains no solution assumption. -/
structure IntegralPicard (E : Type*) [NormedAddCommGroup E] [NormedSpace ℝ E] where
  toFun : ℝ → E → E
  tMin : ℝ
  tMax : ℝ
  t₀ : Icc tMin tMax
  x₀ : E
  C : ℝ≥0
  L : ℝ≥0
  lipschitz_all : ∀ t, LipschitzWith L (toFun t)
  measurable_curve : ∀ f : ℝ → E, Continuous f →
    AEStronglyMeasurable (fun t => toFun t (f t)) volume
  bound_all : ∀ t x, ‖toFun t x‖ ≤ C

namespace IntegralPicard
variable (v : IntegralPicard E)
instance : CoeFun (IntegralPicard E) fun _ => ℝ → E → E := ⟨toFun⟩

theorem tMin_le_tMax : v.tMin ≤ v.tMax :=
  v.t₀.2.1.trans v.t₀.2.2

protected theorem nonempty_Icc : (Icc v.tMin v.tMax).Nonempty :=
  nonempty_Icc.2 v.tMin_le_tMax

/-- The maximum of distances from `t₀` to the endpoints of `[tMin, tMax]`. -/
def tDist : ℝ :=
  max (v.tMax - v.t₀) (v.t₀ - v.tMin)

theorem tDist_nonneg : 0 ≤ v.tDist :=
  le_max_iff.2 <| Or.inl <| sub_nonneg.2 v.t₀.2.2

theorem dist_t₀_le (t : Icc v.tMin v.tMax) : dist t v.t₀ ≤ v.tDist := by
  rw [Subtype.dist_eq, Real.dist_eq]
  rcases le_total t v.t₀ with ht | ht
  · rw [abs_of_nonpos (sub_nonpos.2 <| Subtype.coe_le_coe.2 ht), neg_sub]
    exact (sub_le_sub_left t.2.1 _).trans (le_max_right _ _)
  · rw [abs_of_nonneg (sub_nonneg.2 <| Subtype.coe_le_coe.2 ht)]
    exact (sub_le_sub_right t.2.2 _).trans (le_max_left _ _)

/-- Projection $ℝ → [t_{\min}, t_{\max}]$ sending $(-∞, t_{\min}]$ to $t_{\min}$ and $[t_{\max}, ∞)$
to $t_{\max}$. -/
def proj : ℝ → Icc v.tMin v.tMax :=
  projIcc v.tMin v.tMax v.tMin_le_tMax

theorem proj_coe (t : Icc v.tMin v.tMax) : v.proj t = t :=
  projIcc_val _ _

theorem proj_of_mem {t : ℝ} (ht : t ∈ Icc v.tMin v.tMax) : ↑(v.proj t) = t := by
  simp only [proj, projIcc_of_mem v.tMin_le_tMax ht]

@[continuity, fun_prop]
theorem continuous_proj : Continuous v.proj :=
  continuous_projIcc

/-- The space of curves $γ \colon [t_{\min}, t_{\max}] \to E$ such that $γ(t₀) = x₀$ and $γ$ is
Lipschitz continuous with constant $C$. The map sending $γ$ to
$\mathbf Pγ(t)=x₀ + ∫_{t₀}^{t} v(τ, γ(τ))\,dτ$ is a contracting map on this space, and its fixed
point is a solution of the ODE $\dot x=v(t, x)$. -/
structure FunSpace where
  /-- The particular curve represented by this object. -/
  toFun : Icc v.tMin v.tMax → E
  map_t₀' : toFun v.t₀ = v.x₀
  lipschitz' : LipschitzWith v.C toFun

namespace FunSpace

variable {v}
variable (f : FunSpace v)

instance : CoeFun (FunSpace v) fun _ => Icc v.tMin v.tMax → E :=
  ⟨toFun⟩

instance : Inhabited v.FunSpace :=
  ⟨⟨fun _ => v.x₀, rfl, (LipschitzWith.const _).weaken (zero_le)⟩⟩

protected theorem lipschitz : LipschitzWith v.C f :=
  f.lipschitz'

protected theorem continuous : Continuous f :=
  f.lipschitz.continuous

/-- Each curve in `IntegralPicard.FunSpace` is continuous. -/
def toContinuousMap : v.FunSpace ↪ C(Icc v.tMin v.tMax, E) :=
  ⟨fun f => ⟨f, f.continuous⟩, fun f g h => by cases f; cases g; simpa using! h⟩

instance : MetricSpace v.FunSpace :=
  MetricSpace.induced toContinuousMap toContinuousMap.injective inferInstance

theorem isUniformInducing_toContinuousMap : IsUniformInducing (@toContinuousMap _ _ _ v) :=
  ⟨rfl⟩

theorem range_toContinuousMap :
    range toContinuousMap =
      {f : C(Icc v.tMin v.tMax, E) | f v.t₀ = v.x₀ ∧ LipschitzWith v.C f} := by
  ext f; constructor
  · rintro ⟨⟨f, hf₀, hf_lip⟩, rfl⟩; exact ⟨hf₀, hf_lip⟩
  · rcases f with ⟨f, hf⟩; rintro ⟨hf₀, hf_lip⟩; exact ⟨⟨f, hf₀, hf_lip⟩, rfl⟩

theorem map_t₀ : f v.t₀ = v.x₀ :=
  f.map_t₀'

/-- Only the continuous test curve is extended by projection. Time in the
measurable vector field is left untouched. -/
def vComp (t : ℝ) : E := v t (f (v.proj t))

theorem vComp_apply_coe (t : Icc v.tMin v.tMax) : f.vComp t = v t (f t) := by
  simp only [vComp, proj_coe]

theorem measurable_vComp : AEStronglyMeasurable f.vComp volume :=
  v.measurable_curve _ (f.continuous.comp v.continuous_proj)

theorem norm_vComp_le (t : ℝ) : ‖f.vComp t‖ ≤ v.C := v.bound_all _ _

theorem dist_apply_le_dist (f₁ f₂ : FunSpace v) (t : Icc v.tMin v.tMax) :
    dist (f₁ t) (f₂ t) ≤ dist f₁ f₂ :=
  @ContinuousMap.dist_apply_le_dist _ _ _ _ _ (toContinuousMap f₁) (toContinuousMap f₂) _

theorem dist_le_of_forall {f₁ f₂ : FunSpace v} {d : ℝ} (h : ∀ t, dist (f₁ t) (f₂ t) ≤ d) :
    dist f₁ f₂ ≤ d :=
  (@ContinuousMap.dist_le_iff_of_nonempty _ _ _ _ _ (toContinuousMap f₁) (toContinuousMap f₂) _
    v.nonempty_Icc.to_subtype).2 h

instance [CompleteSpace E] : CompleteSpace v.FunSpace := by
  refine (completeSpace_iff_isComplete_range isUniformInducing_toContinuousMap).2
      (IsClosed.isComplete ?_)
  rw [range_toContinuousMap, setOf_and]
  refine (isClosed_eq (continuous_eval_const _) continuous_const).inter ?_
  have : IsClosed {f : Icc v.tMin v.tMax → E | LipschitzWith v.C f} :=
    isClosed_setOf_lipschitzWith v.C
  exact this.preimage continuous_coeFun

theorem intervalIntegrable_vComp (t₁ t₂ : ℝ) : IntervalIntegrable f.vComp volume t₁ t₂ := by
  rw [intervalIntegrable_iff]
  exact Measure.integrableOn_of_bounded measure_Ioc_lt_top.ne f.measurable_vComp
    (Filter.Eventually.of_forall f.norm_vComp_le)

/-- The Picard-Lindelöf operator. This is a contracting map on `IntegralPicard.FunSpace v` such
that the fixed point of this map is the solution of the corresponding ODE.

More precisely, some iteration of this map is a contracting map. -/
def next (f : FunSpace v) : FunSpace v where
  toFun t := v.x₀ + ∫ τ : ℝ in v.t₀..t, f.vComp τ
  map_t₀' := by simp only [integral_same, add_zero]
  lipschitz' := LipschitzWith.of_dist_le_mul fun t₁ t₂ => by
    rw [dist_add_left, dist_eq_norm,
      integral_interval_sub_left (f.intervalIntegrable_vComp _ _) (f.intervalIntegrable_vComp _ _)]
    exact norm_integral_le_of_norm_le_const fun t _ => f.norm_vComp_le _

theorem next_apply (t : Icc v.tMin v.tMax) : f.next t = v.x₀ + ∫ τ : ℝ in v.t₀..t, f.vComp τ :=
  rfl

theorem dist_next_apply_le_of_le {f₁ f₂ : FunSpace v} {n : ℕ} {d : ℝ}
    (h : ∀ t, dist (f₁ t) (f₂ t) ≤ (v.L * |t.1 - v.t₀|) ^ n / n ! * d) (t : Icc v.tMin v.tMax) :
    dist (next f₁ t) (next f₂ t) ≤ (v.L * |t.1 - v.t₀|) ^ (n + 1) / (n + 1)! * d := by
  simp only [dist_eq_norm, next_apply, add_sub_add_left_eq_sub, ←
    intervalIntegral.integral_sub (intervalIntegrable_vComp _ _ _)
      (intervalIntegrable_vComp _ _ _),
    norm_integral_eq_norm_integral_uIoc] at *
  calc
    ‖∫ τ in Ι (v.t₀ : ℝ) t, f₁.vComp τ - f₂.vComp τ‖ ≤
        ∫ τ in Ι (v.t₀ : ℝ) t, v.L * ((v.L * |τ - v.t₀|) ^ n / n ! * d) := by
      refine norm_integral_le_of_norm_le (Continuous.integrableOn_uIoc (by fun_prop)) ?_
      refine (ae_restrict_mem measurableSet_Ioc).mono fun τ hτ ↦ ?_
      refine (v.lipschitz_all τ).norm_sub_le_of_le ((h _).trans_eq ?_)
      rw [v.proj_of_mem]
      exact uIcc_subset_Icc v.t₀.2 t.2 <| Ioc_subset_Icc_self hτ
    _ = (v.L * |t.1 - v.t₀|) ^ (n + 1) / (n + 1)! * d := by
      simp_rw [mul_pow, div_eq_mul_inv, mul_assoc, MeasureTheory.integral_const_mul,
        MeasureTheory.integral_mul_const, integral_pow_abs_sub_uIoc, div_eq_mul_inv,
        pow_succ' (v.L : ℝ), Nat.factorial_succ, Nat.cast_mul, Nat.cast_succ, mul_inv, mul_assoc]

theorem dist_iterate_next_apply_le (f₁ f₂ : FunSpace v) (n : ℕ) (t : Icc v.tMin v.tMax) :
    dist (next^[n] f₁ t) (next^[n] f₂ t) ≤ (v.L * |t.1 - v.t₀|) ^ n / n ! * dist f₁ f₂ := by
  induction n generalizing t with
  | zero =>
    rw [pow_zero, Nat.factorial_zero, Nat.cast_one, div_one, one_mul]
    exact dist_apply_le_dist f₁ f₂ t
  | succ n ihn =>
    rw [iterate_succ_apply', iterate_succ_apply']
    exact dist_next_apply_le_of_le ihn _

theorem dist_iterate_next_le (f₁ f₂ : FunSpace v) (n : ℕ) :
    dist (next^[n] f₁) (next^[n] f₂) ≤ (v.L * v.tDist) ^ n / n ! * dist f₁ f₂ := by
  refine dist_le_of_forall fun t => (dist_iterate_next_apply_le _ _ _ _).trans ?_
  have : |(t - v.t₀ : ℝ)| ≤ v.tDist := v.dist_t₀_le t
  gcongr

end FunSpace

theorem exists_contracting_iterate :
    ∃ (N : ℕ) (K : _), ContractingWith K (FunSpace.next : v.FunSpace → v.FunSpace)^[N] := by
  rcases ((FloorSemiring.tendsto_pow_div_factorial_atTop (v.L * v.tDist)).eventually
    (gt_mem_nhds zero_lt_one)).exists with ⟨N, hN⟩
  have : (0 : ℝ) ≤ (v.L * v.tDist) ^ N / N ! :=
    div_nonneg (pow_nonneg (mul_nonneg v.L.2 v.tDist_nonneg) _) (Nat.cast_nonneg _)
  exact ⟨N, ⟨_, this⟩, hN, LipschitzWith.of_dist_le_mul fun f g =>
    FunSpace.dist_iterate_next_le f g N⟩

theorem exists_fixed [CompleteSpace E] : ∃ f : v.FunSpace, f.next = f :=
  let ⟨_N, _K, hK⟩ := exists_contracting_iterate v
  ⟨_, hK.isFixedPt_fixedPoint_iterate⟩


/-- A true finite-horizon construction for measurable time dependence, in
Lebesgue integral form. No existing trajectory is supplied. -/
theorem exists_integral_solution [CompleteSpace E] :
    ∃ x : ℝ → E, LipschitzWith v.C x ∧ x v.t₀=v.x₀ ∧
      ∀ t∈Icc v.tMin v.tMax, x t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (x s) := by
  obtain ⟨f,hf⟩ := v.exists_fixed
  refine ⟨fun t => f (v.proj t), ?_, ?_, ?_⟩
  · simpa only [mul_one,Function.comp_def,IntegralPicard.proj] using!
      f.lipschitz.comp (LipschitzWith.projIcc v.tMin_le_tMax)
  · simpa only [v.proj_coe] using! f.map_t₀
  · intro t ht
    have hproj : v.proj t = ⟨t,ht⟩ := by apply Subtype.ext; exact v.proj_of_mem ht
    have hn := congrArg (fun f : v.FunSpace => f ⟨t,ht⟩) hf
    simpa [FunSpace.next_apply,FunSpace.vComp,hproj] using! hn.symm

end IntegralPicard
end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Metric Filter Function MeasureTheory intervalIntegral
open scoped Topology NNReal
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

theorem IntegralPicard.fixed_unique (v : IntegralPicard E) (f g : v.FunSpace)
    (hf : f.next=f) (hg : g.next=g) : f=g := by
  obtain ⟨N,K,hK⟩ := v.exists_contracting_iterate
  have hfN : (IntegralPicard.FunSpace.next^[N]) f=f := IsFixedPt.iterate hf N
  have hgN : (IntegralPicard.FunSpace.next^[N]) g=g := IsFixedPt.iterate hg N
  have hi := hK.2.dist_le_mul f g
  rw [hfN,hgN] at hi
  apply dist_le_zero.mp
  have hlt : (K:ℝ)<1 := hK.1
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [dist_nonneg (x:=f) (y:=g)]

/-- Uniqueness on a finite interval for the Lipschitz integral solutions just
constructed. This is proved by the factorial Picard estimate. -/
theorem IntegralPicard.integral_unique (v : IntegralPicard E) {x y : ℝ → E}
    (hxL : LipschitzWith v.C x) (hyL : LipschitzWith v.C y)
    (hx₀ : x v.t₀=v.x₀) (hy₀ : y v.t₀=v.x₀)
    (hx : ∀ t∈Icc v.tMin v.tMax, x t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (x s))
    (hy : ∀ t∈Icc v.tMin v.tMax, y t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (y s)) :
    EqOn x y (Icc v.tMin v.tMax) := by
  let f : v.FunSpace := ⟨fun t => x t,hx₀,by simpa using! hxL.comp (LipschitzWith.subtype_val _)⟩
  let g : v.FunSpace := ⟨fun t => y t,hy₀,by simpa using! hyL.comp (LipschitzWith.subtype_val _)⟩
  have hf : f.next=f := by
    apply IntegralPicard.FunSpace.toContinuousMap.injective
    apply ContinuousMap.ext
    intro t
    change v.x₀+∫ s in (v.t₀:ℝ)..(t:ℝ), v s (x (v.proj s)) = x t
    rw [hx t t.property]
    congr 1
    apply intervalIntegral.integral_congr
    intro s hs
    dsimp only
    rw [v.proj_of_mem (uIcc_subset_Icc v.t₀.property t.property hs)]
  have hg : g.next=g := by
    apply IntegralPicard.FunSpace.toContinuousMap.injective
    apply ContinuousMap.ext
    intro t
    change v.x₀+∫ s in (v.t₀:ℝ)..(t:ℝ), v s (y (v.proj s)) = y t
    rw [hy t t.property]
    congr 1
    apply intervalIntegral.integral_congr
    intro s hs
    dsimp only
    rw [v.proj_of_mem (uIcc_subset_Icc v.t₀.property t.property hs)]
  have he := v.fixed_unique f g hf hg
  intro t ht
  exact congrArg (fun z : v.FunSpace => z ⟨t,ht⟩) he

/-- Arbitrary measurable time dependence is allowed. The hypotheses contain
only the field and its global bounds; the Lipschitz integral solution is built
on the entire real line by gluing unique finite-horizon fixed points. -/
theorem bounded_measurable_global_integral_exists
    {F : ℝ → E → E} {L C : ℝ≥0}
    (hL : ∀ t, LipschitzWith L (F t))
    (hMeas : ∀ f : ℝ → E, Continuous f → AEStronglyMeasurable (fun t => F t (f t)) volume)
    (hC : ∀ t x, ‖F t x‖≤ C) (x₀ : E) :
    ∃ x : ℝ → E, LipschitzWith C x ∧ x 0=x₀ ∧
      ∀ t, x t=x₀+∫ s in (0:ℝ)..t, F s (x s) := by
  let data (a : ℝ) : IntegralPicard E :=
    { toFun := F, tMin := -|a|, tMax := |a|,
      t₀ := ⟨0,by constructor <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [abs_nonneg a]⟩,
      x₀ := x₀, C := C, L := L,
      lipschitz_all := hL, measurable_curve := hMeas, bound_all := hC }
  have hex (a : ℝ) := (data a).exists_integral_solution
  choose f hfL hf₀ hfI using hex
  have agree {a b : ℝ} (ha : 0≤ a) (hab : a≤ b) : EqOn (f a) (f b) (Icc (-a) a) := by
    have hb : 0≤ b := ha.trans hab
    have hfa : ∀ t∈Icc (data a).tMin (data a).tMax,
        f a t=(data a).x₀+∫ s in ((data a).t₀:ℝ)..t, (data a) s (f a s) := hfI a
    have hfb : ∀ t∈Icc (data a).tMin (data a).tMax,
        f b t=(data a).x₀+∫ s in ((data a).t₀:ℝ)..t, (data a) s (f b s) := by
      intro t ht
      apply hfI b
      dsimp [data] at ht ⊢
      rw [abs_of_nonneg ha] at ht
      rw [abs_of_nonneg hb]
      exact ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [ht.1],ht.2.trans hab⟩
    simpa [data,abs_of_nonneg ha] using! (data a).integral_unique
      (hfL a) (hfL b) (hf₀ a) (hf₀ b) hfa hfb
  let x : ℝ → E := fun t => f (|t|+1) t
  have heq {a : ℝ} (ha : 0≤ a) : EqOn x (f a) (Icc (-a) a) := by
    intro t ht
    by_cases hab : |t|+1≤ a
    · exact agree (by positivity) hab (abs_le.mp (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith : |t|≤|t|+1))
    · exact (agree ha (le_of_not_ge hab) ht).symm
  have hxL : LipschitzWith C x := by
    apply LipschitzWith.of_dist_le_mul
    intro t s
    let a := |t|+|s|+1
    have ha : 0≤ a := by dsimp [a]; positivity
    have ht : t∈Icc (-a) a := abs_le.mp (by dsimp [a]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [abs_nonneg s])
    have hs : s∈Icc (-a) a := abs_le.mp (by dsimp [a]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [abs_nonneg t])
    rw [heq ha ht,heq ha hs]
    exact (hfL a).dist_le_mul t s
  refine ⟨x,hxL,by simpa [x,data] using! hf₀ 1,fun t => ?_⟩
  let a := |t|+1
  have ha : 0≤ a := by dsimp [a]; positivity
  have ht : t∈Icc (-a) a := abs_le.mp (by dsimp [a]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith)
  have hzero : (0:ℝ)∈Icc (-a) a := ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith,ha⟩
  rw [heq ha ht]
  have hi := hfI a t (by simpa [data,abs_of_nonneg ha] using! ht)
  dsimp [data] at hi
  rw [hi]
  congr 1
  apply intervalIntegral.integral_congr
  intro s hs
  dsimp only
  rw [heq ha (uIcc_subset_Icc hzero ht hs)]

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Metric Filter MeasureTheory intervalIntegral
open scoped Topology NNReal ENNReal
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

/-- The almost-everywhere fundamental theorem for the Lebesgue primitive,
derived from the one-dimensional Vitali differentiation theorem. -/
theorem locally_integrable_primitive_ae_derivative {f : ℝ → E}
    (hf : LocallyIntegrable f volume) (a : ℝ) :
    ∀ᵐ t ∂volume, HasDerivAt (fun t => ∫ s in a..t, f s) (f t) t := by
  have hi (u v : ℝ) : IntervalIntegrable f volume u v := by
    rw [intervalIntegrable_iff]
    exact (hf.integrableOn_isCompact isCompact_uIcc).mono_set uIoc_subset_uIcc
  filter_upwards [(IsUnifLocDoublingMeasure.vitaliFamily (volume:Measure ℝ) 1).ae_tendsto_average hf]
    with t ht
  rw [hasDerivAt_iff_tendsto_slope,← nhdsLT_sup_nhdsGT,tendsto_sup]
  constructor
  · have hl := ht.comp (Real.tendsto_Icc_vitaliFamily_left t)
    apply hl.congr'
    filter_upwards [self_mem_nhdsWithin] with y (hy : y<t)
    simp only [Function.comp_apply,slope_def_module]
    rw [integral_interval_sub_left (hi a y) (hi a t),integral_symm y t]
    rw [setAverage_eq,Real.volume_real_Icc_of_le hy.le,integral_Icc_eq_integral_Ioc,
      ← integral_of_le hy.le]
    rw [show y-t=-(t-y) by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring,inv_neg,neg_smul,smul_neg,neg_neg]
  · have hr := ht.comp (Real.tendsto_Icc_vitaliFamily_right t)
    apply hr.congr'
    filter_upwards [self_mem_nhdsWithin] with y (hy : t<y)
    simp only [Function.comp_apply,slope_def_module]
    rw [integral_interval_sub_left (hi a y) (hi a t),setAverage_eq,
      Real.volume_real_Icc_of_le hy.le,integral_Icc_eq_integral_Ioc,← integral_of_le hy.le]

/-- Global Caratheodory existence in both integral and a.e. differential form
for bounded measurable-time, uniformly state-Lipschitz fields. -/
theorem bounded_measurable_global_ae_exists
    {F : ℝ → E → E} {L C : ℝ≥0}
    (hL : ∀ t, LipschitzWith L (F t))
    (hMeas : ∀ f : ℝ → E, Continuous f → AEStronglyMeasurable (fun t => F t (f t)) volume)
    (hC : ∀ t x, ‖F t x‖≤ C) (x₀ : E) :
    ∃ x : ℝ → E, LipschitzWith C x ∧ x 0=x₀ ∧
      (∀ t, x t=x₀+∫ s in (0:ℝ)..t, F s (x s)) ∧
      ∀ᵐ t ∂volume, HasDerivAt x (F t (x t)) t := by
  obtain ⟨x,hxL,hx₀,hxI⟩ := bounded_measurable_global_integral_exists hL hMeas hC x₀
  have hloc : LocallyIntegrable (fun t => F t (x t)) volume :=
    (memLp_top_of_bound (hMeas x hxL.continuous) C
      (Filter.Eventually.of_forall (fun t => hC t (x t)))).locallyIntegrable le_top
  refine ⟨x,hxL,hx₀,hxI,?_⟩
  filter_upwards [locally_integrable_primitive_ae_derivative hloc 0] with t ht
  convert! ht.const_add x₀ using 1
  exact funext hxI

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Filter MeasureTheory intervalIntegral
open scoped Topology NNReal

/-- Reverse FTC for a Lipschitz real function, proved by dominated convergence
of difference quotients. This excludes singular continuous counterexamples to
an a.e.-derivative-only comparison argument. -/
theorem lipschitz_integral_deriv {f : ℝ → ℝ} {L : ℝ≥0}
    (hf : LipschitzWith L f) {a b : ℝ} (hab : a≤ b) :
    ∫ t in a..b, deriv f t = f b-f a := by
  let q (ε t : ℝ) := ε⁻¹*(f (t+ε)-f t)
  have hbound {ε : ℝ} (hε : 0<ε) (t : ℝ) : ‖q ε t‖≤ L := by
    have hl := hf.norm_sub_le (t+ε) t
    simp only [add_sub_cancel_left,Real.norm_eq_abs,abs_of_pos hε] at hl
    dsimp [q]
    rw [abs_mul,abs_inv,abs_of_pos hε]
    calc
      ε⁻¹*‖f (t+ε)-f t‖ ≤ ε⁻¹*((L:ℝ)*ε) := mul_le_mul_of_nonneg_left hl (by positivity)
      _ = L := by field_simp
  have hlim : Tendsto (fun ε => ∫ t in Ioc a b, q ε t) (𝓝[>] 0)
      (𝓝 (∫ t in Ioc a b, deriv f t)) := by
    apply MeasureTheory.tendsto_integral_filter_of_dominated_convergence (fun _ => (L:ℝ))
    · apply Filter.Eventually.of_forall
      intro ε
      have hc : Continuous (q ε) := by
        dsimp [q]
        exact continuous_const.mul ((hf.continuous.comp (continuous_id.add continuous_const)).sub hf.continuous)
      exact hc.aestronglyMeasurable
    · filter_upwards [self_mem_nhdsWithin] with ε (hε:0<ε)
      exact Filter.Eventually.of_forall (hbound hε)
    · exact integrable_const _
    · filter_upwards [ae_restrict_of_ae hf.ae_differentiableAt_real] with t ht
      simpa [q,smul_eq_mul] using! ht.hasDerivAt.tendsto_slope_zero_right
  let P : ℝ → ℝ := fun t => ∫ s in (0:ℝ)..t, f s
  have hP (t : ℝ) : HasDerivAt P (f t) t :=
    integral_hasDerivAt_right (hf.continuous.intervalIntegrable _ _)
      hf.continuous.aestronglyMeasurable.stronglyMeasurableAtFilter hf.continuous.continuousAt
  have hboundary := (hP b).tendsto_slope_zero_right.sub (hP a).tendsto_slope_zero_right
  have heq (ε : ℝ) : (∫ t in Ioc a b, q ε t) =
      ε⁻¹*(P (b+ε)-P b)-ε⁻¹*(P (a+ε)-P a) := by
    rw [← integral_of_le hab]
    change (∫ t in a..b, ε⁻¹*(f (t+ε)-f t)) = _
    have hshift : IntervalIntegrable (fun t => f (t+ε)) volume a b :=
      (hf.continuous.comp (continuous_id.add continuous_const)).intervalIntegrable _ _
    rw [intervalIntegral.integral_const_mul,intervalIntegral.integral_sub
      hshift
      (hf.continuous.intervalIntegrable _ _),integral_comp_add_right]
    have hi (u v : ℝ) : IntervalIntegrable f volume u v := hf.continuous.intervalIntegrable u v
    rw [integral_interval_sub_interval_comm' (hi (a+ε) (b+ε)) (hi a b) (hi (a+ε) a)]
    dsimp [P]
    rw [integral_interval_sub_left (hi 0 (b+ε)) (hi 0 b),
      integral_interval_sub_left (hi 0 (a+ε)) (hi 0 a)]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hother : Tendsto (fun ε => ∫ t in Ioc a b, q ε t) (𝓝[>] 0) (𝓝 (f b-f a)) := by
    simpa only [heq,smul_eq_mul] using! hboundary
  rw [integral_of_le hab]
  exact tendsto_nhds_unique hlim hother

/-- A.e. derivative comparison for Lipschitz curves, with an actual integral
proof rather than an assumption that an a.e. inequality implies monotonicity. -/
theorem lipschitz_nonincreasing_of_ae_derivative {f f' : ℝ → ℝ} {L : ℝ≥0}
    (hf : LipschitzWith L f) {a b : ℝ} (hab : a≤ b)
    (hd : ∀ᵐ t ∂volume, t∈Icc a b → HasDerivAt f (f' t) t)
    (hneg : ∀ᵐ t ∂volume, t∈Icc a b → f' t≤0) : f b≤ f a := by
  have hle : ∫ t in a..b, deriv f t ≤ 0 := by
    rw [intervalIntegral.integral_of_le hab]
    apply integral_nonpos_of_ae
    filter_upwards [ae_restrict_of_ae hd,ae_restrict_of_ae hneg,ae_restrict_mem measurableSet_Ioc]
      with t ht hn hmem
    rw [(ht (Ioc_subset_Icc_self hmem)).deriv]
    exact hn (Ioc_subset_Icc_self hmem)
  rw [lipschitz_integral_deriv hf hab] at hle
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

theorem lipschitzOn_nonincreasing_of_ae_derivative {f f' : ℝ → ℝ} {L : ℝ≥0}
    {a b : ℝ} (hab : a≤ b) (hf : LipschitzOnWith L f (Icc a b))
    (hd : ∀ᵐ t ∂volume, t∈Ioo a b → HasDerivAt f (f' t) t)
    (hneg : ∀ᵐ t ∂volume, t∈Ioo a b → f' t≤0) : f b≤ f a := by
  by_cases heq : a=b
  · simpa [heq]
  have hab' : a<b := lt_of_le_of_ne hab heq
  let g : ℝ → ℝ := fun t => f (projIcc a b hab t)
  have hgl : LipschitzWith L g := by
    simpa only [mul_one,Function.comp_def,Set.restrict_apply] using!
      hf.to_restrict.comp (LipschitzWith.projIcc hab)
  have he (t : ℝ) (ht : t∈Ioo a b) : g =ᶠ[𝓝 t] f := by
    filter_upwards [Ioo_mem_nhds ht.1 ht.2] with s hs
    simp [g,projIcc_of_mem hab (Ioo_subset_Icc_self hs)]
  have hneq (c : ℝ) : ∀ᵐ t ∂volume, t≠c := by
    simp [ae_iff,measure_singleton]
  have hgd : ∀ᵐ t ∂volume, t∈Icc a b → HasDerivAt g (f' t) t := by
    filter_upwards [hd,hneq a,hneq b] with t ht hta htb hmem
    have ho : t∈Ioo a b := ⟨lt_of_le_of_ne hmem.1 (Ne.symm hta),lt_of_le_of_ne hmem.2 htb⟩
    exact (ht ho).congr_of_eventuallyEq (he t ho)
  have hgn : ∀ᵐ t ∂volume, t∈Icc a b → f' t≤0 := by
    filter_upwards [hneg,hneq a,hneq b] with t ht hta htb hmem
    exact ht ⟨lt_of_le_of_ne hmem.1 (Ne.symm hta),lt_of_le_of_ne hmem.2 htb⟩
  have h := lipschitz_nonincreasing_of_ae_derivative hgl hab hgd hgn
  simpa [g,projIcc_of_mem hab (left_mem_Icc.mpr hab),projIcc_of_mem hab (right_mem_Icc.mpr hab)] using! h

/-- A Lipschitz curve with a continuous a.e. derivative is classical. This is
used for the height/falling components, which have no direct disturbance term. -/
theorem lipschitz_ae_continuous_derivative {f g : ℝ → ℝ} {L : ℝ≥0}
    (hf : LipschitzWith L f) (hg : Continuous g)
    (hd : ∀ᵐ t ∂volume, HasDerivAt f (g t) t) :
    ∀ t, HasDerivAt f (g t) t := by
  have hie (a b : ℝ) : ∫ t in a..b, deriv f t = f b-f a := by
    rcases le_total a b with hab | hba
    · exact lipschitz_integral_deriv hf hab
    · rw [integral_symm,lipschitz_integral_deriv hf hba]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have heq (t : ℝ) : f t=f 0+∫ s in (0:ℝ)..t, g s := by
    have he : (∫ s in (0:ℝ)..t, deriv f s) = ∫ s in (0:ℝ)..t, g s := by
      apply intervalIntegral.integral_congr_ae
      filter_upwards [hd] with s hs _
      exact hs.deriv
    rw [hie] at he
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  intro t
  have hp := intervalIntegral.integral_hasDerivAt_right (hg.intervalIntegrable 0 t)
    hg.aestronglyMeasurable.stronglyMeasurableAtFilter hg.continuousAt
  convert! hp.const_add (f 0) using 1
  exact funext heq

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Metric Real Filter MeasureTheory
open scoped Topology NNReal

/-- A smooth function of a Lipschitz curve is Lipschitz on a compact interval.
The bound is obtained on a compact convex ball containing the curve. -/
theorem smooth_comp_lipschitzOn
    {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [ProperSpace E]
    [NormedAddCommGroup F] [NormedSpace ℝ F]
    {f : E → F} {x : ℝ → E} {K : ℝ≥0} {a b : ℝ}
    (hf : ContDiff ℝ 1 f) (hx : LipschitzOnWith K x (Icc a b)) :
    ∃ L : ℝ≥0, LipschitzOnWith L (fun t => f (x t)) (Icc a b) := by
  obtain ⟨N,hN⟩ := isCompact_Icc.exists_bound_of_continuousOn hx.continuousOn
  obtain ⟨L,C,hL,_⟩ := smooth_compact_convex_bounds isOpen_univ hf.contDiffOn
    (isCompact_closedBall (0:E) (max N 0)) (convex_closedBall (0:E) (max N 0)) (subset_univ _)
  refine ⟨L*K,hL.comp hx (fun t ht => ?_)⟩
  simpa only [mem_closedBall,dist_zero_right] using! (hN t ht).trans (le_max_left N 0)

/-- Scalar Gronwall comparison for Lipschitz curves whose differential inequality
holds only almost everywhere. The integrating-factor monotonicity is derived
from the proved Lipschitz FTC. -/
theorem scalar_comparison_ae {V V' : ℝ → ℝ} {T κ C : ℝ} {L : ℝ≥0}
    (hκ : 0<κ) (hV : LipschitzOnWith L V (Icc 0 T))
    (hd : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt V (V' t) t)
    (hb : ∀ᵐ t ∂volume, t∈Ioo 0 T → V' t≤ -2*κ*V t+C) :
    ∀ t∈Icc 0 T, V t≤ envelope (V 0) κ C t := by
  let W (t : ℝ) := (V t-C/(2*κ))*exp (2*κ*t)
  let W' (t : ℝ) := (V' t+2*κ*(V t-C/(2*κ)))*exp (2*κ*t)
  have hsm : ContDiff ℝ 1 (fun p : ℝ×ℝ => (p.2-C/(2*κ))*exp (2*κ*p.1)) := by fun_prop
  obtain ⟨LW,hLW⟩ := smooth_comp_lipschitzOn hsm (LipschitzWith.id.lipschitzOnWith.prodMk hV)
  have hWd : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt W (W' t) t := by
    filter_upwards [hd] with t ht hmem
    convert! ((ht hmem).sub_const (C/(2*κ))).mul
      (((hasDerivAt_id t).const_mul (2*κ)).exp) using 1 <;> dsimp [W,W'] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hWn : ∀ᵐ t ∂volume, t∈Ioo 0 T → W' t≤0 := by
    filter_upwards [hb] with t ht hmem
    have heq : 2*κ*(C/(2*κ))=C := by field_simp
    dsimp [W']
    apply mul_nonpos_of_nonpos_of_nonneg _ (exp_pos _).le
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [ht hmem]
  intro t ht
  have hsub : Icc (0:ℝ) t ⊆ Icc 0 T := Icc_subset_Icc le_rfl ht.2
  have hw := lipschitzOn_nonincreasing_of_ae_derivative ht.1 (hLW.mono hsub)
    (hWd.mono (fun s hs hmem => hs ⟨hmem.1,hmem.2.trans_le ht.2⟩))
    (hWn.mono (fun s hs hmem => hs ⟨hmem.1,hmem.2.trans_le ht.2⟩))
  change W t≤ W 0 at hw
  dsimp [W] at hw
  simp only [mul_zero,exp_zero,mul_one] at hw
  have hdiv : V t-C/(2*κ) ≤ (V 0-C/(2*κ))/exp (2*κ*t) :=
    (le_div_iff₀ (exp_pos _)).mpr hw
  have heq : envelope (V 0) κ C t = C/(2*κ)+(V 0-C/(2*κ))/exp (2*κ*t) := by
    unfold envelope
    rw [show -2*κ*t=-(2*κ*t) by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring,exp_neg]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [heq]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

/-- The robust energy envelope for genuinely a.e. error equations. -/
theorem robust_error_estimate_ae {e z G d : ℝ → ℝ} {T k₀ k₁ k₂ κ κd dbar : ℝ}
    {Le Lz : ℝ≥0} (hk₀ : 0≤ k₀) (hκ : 0<κ) (hk₁ : κ≤ k₁) (hk₂ : κ≤ k₂) (hκd : 0<κd)
    (hel : LipschitzOnWith Le e (Icc 0 T)) (hzl : LipschitzOnWith Lz z (Icc 0 T))
    (he : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt e (errorRate k₁ (e t) (z t)) t)
    (hz : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt z (zRate k₀ k₂ κd (G t) (d t) (e t) (z t)) t)
    (hb : ∀ᵐ t ∂volume, t∈Ioo 0 T → |d t|≤ dbar) :
    ∀ t∈Icc 0 T, errorEnergy k₀ (e t) (z t)≤
      exp (-2*κ*t)*errorEnergy k₀ (e 0) (z 0)+dbar^2/(16*κ*κd)*(1-exp (-2*κ*t)) := by
  have hsm : ContDiff ℝ 1 (fun p : ℝ×ℝ => errorEnergy k₀ p.1 p.2) := by
    unfold errorEnergy
    fun_prop (disch := norm_num)
  obtain ⟨L,hL⟩ := smooth_comp_lipschitzOn hsm (hel.prodMk hzl)
  have hd : ∀ᵐ t ∂volume, t∈Ioo 0 T →
      HasDerivAt (fun s => errorEnergy k₀ (e s) (z s))
        (-k₀*k₁*(e t)^2-k₂*(z t)^2/4-κd*(G t)^2*(z t)^2/4+G t*z t*d t/4) t := by
    filter_upwards [he,hz] with t het hzt hmem
    exact energy_hasDerivAt_errors (het hmem) (hzt hmem)
  have hi := scalar_comparison_ae hκ hL hd (by
    filter_upwards [hb] with t ht hmem
    exact robust_decay_uniform hk₀ hk₁ hk₂ hκd (ht hmem))
  intro t ht
  convert! hi t ht using 1
  unfold envelope
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Filter MeasureTheory Real
open scoped Topology

/-- Actual second derivative in the noise direction: this identifies the
Hessian term, separately from the semimartingale Ito formula. -/
theorem energy_noise_second_derivative (k₀ e z σ G : ℝ) :
    (∀ a : ℝ, HasDerivAt (fun b => errorEnergy k₀ e (z+σ*G*b))
      ((z+σ*G*a)*σ*G/4) a) ∧
    ∀ a : ℝ, HasDerivAt (fun b => (z+σ*G*b)*σ*G/4) ((σ*G)^2/4) a := by
  constructor
  · intro a
    have hd := (((hasDerivAt_id a).const_mul (σ*G)).const_add z).pow 2
    convert! (hd.div_const 8).const_add (k₀*e^2/2) using 1 <;>
      dsimp [errorEnergy] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  · intro a
    convert! (((((hasDerivAt_id a).const_mul (σ*G)).const_add z).mul_const σ).mul_const G).div_const 4 using 1 <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- Exact finite-partition square identity underlying the quadratic Ito rule. -/
theorem quadratic_partition_identity (z : ℕ → ℝ) (n : ℕ) :
    z n^2-z 0^2 = ∑ i∈Finset.range n,
      (2*z i*(z (i+1)-z i)+(z (i+1)-z i)^2) := by
  induction n with
  | zero => simp
  | succ n ih => rw [Finset.sum_range_succ,← ih]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- The quadratic change-of-variable identity follows from convergence of left
Riemann sums and squared increments. These convergence hypotheses are explicit;
this theorem does not assert that Brownian-driven solutions satisfy them. -/
theorem quadratic_ito_of_partition_limits {z : ℕ → ℕ → ℝ} {z₀ zT I Q : ℝ}
    (hstart : ∀ n, z n 0=z₀) (hend : ∀ n, z n n=zT)
    (hI : Tendsto (fun n => ∑ i∈Finset.range n, z n i*(z n (i+1)-z n i)) atTop (𝓝 I))
    (hQ : Tendsto (fun n => ∑ i∈Finset.range n, (z n (i+1)-z n i)^2) atTop (𝓝 Q)) :
    zT^2-z₀^2=2*I+Q := by
  have hid (n : ℕ) : zT^2-z₀^2 =
      2*(∑ i∈Finset.range n, z n i*(z n (i+1)-z n i))+
        ∑ i∈Finset.range n, (z n (i+1)-z n i)^2 := by
    have h := quadratic_partition_identity (z n) n
    rw [hstart,hend] at h
    simpa only [Finset.sum_add_distrib,← Finset.mul_sum,mul_assoc] using! h
  have hlim := (hI.const_mul 2).add hQ
  have hc : Tendsto (fun _ : ℕ => zT^2-z₀^2) atTop (𝓝 (2*I+Q)) :=
    hlim.congr (fun n => (hid n).symm)
  exact tendsto_nhds_unique tendsto_const_nhds hc

/-- Expectation of a genuine integrable martingale remains its initial value. -/
theorem martingale_zero_mean {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    [IsProbabilityMeasure μ] {ℱ : Filtration ℝ ‹MeasurableSpace Ω›}
    {M : ℝ → Ω → ℝ} (hM : Martingale M ℱ μ) (h₀ : ∀ ω, M 0 ω=0)
    {t : ℝ} (ht : 0≤ t) : ∫ ω, M t ω ∂μ = 0 := by
  have h := hM.setIntegral_eq ht (s:=univ) MeasurableSet.univ
  simpa [h₀] using! h.symm

/-- The stopped expectation estimate from an explicit Ito/martingale
decomposition. The martingale mean-zero property is proved from conditional
expectations. The decomposition and its stopped integrability are hypotheses;
construction of a Brownian stochastic integral is not hidden in this statement. -/
theorem stopped_energy_expectation {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    [IsProbabilityMeasure μ] {ℱ : Filtration ℝ ‹MeasurableSpace Ω›}
    {M : ℝ → Ω → ℝ} {W I S D : Ω → ℝ} {t V₀ κ C : ℝ}
    (ht : 0≤ t) (hM : Martingale M ℱ μ) (h₀ : ∀ ω, M 0 ω=0)
    (hW : Integrable W μ) (hI : Integrable I μ) (hS : Integrable S μ)
    (hdecomp : ∀ᵐ ω ∂μ, W ω=V₀+D ω+M t ω)
    (hbound : ∀ᵐ ω ∂μ, D ω≤ -2*κ*I ω+C*S ω) :
    (∫ ω, W ω ∂μ)+2*κ*(∫ ω, I ω ∂μ) ≤ V₀+C*(∫ ω, S ω ∂μ) := by
  have hpt : ∀ᵐ ω ∂μ, W ω+2*κ*I ω≤ V₀+C*S ω+M t ω := by
    filter_upwards [hdecomp,hbound] with ω hd hb
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have he := integral_mono_ae (hW.add (hI.const_mul (2*κ)))
    ((integrable_const V₀ |>.add (hS.const_mul C)).add (hM.integrable t)) hpt
  simp only [Pi.add_apply] at he
  rw [integral_add hW (hI.const_mul (2*κ)),
    integral_add (f:=fun ω => V₀+C*S ω) ((integrable_const V₀).add (hS.const_mul C)) (hM.integrable t),
    integral_add (integrable_const V₀) (hS.const_mul C),
    integral_const_mul,integral_const_mul,martingale_zero_mean hM h₀ ht] at he
  simpa using! he

/-- The crown diffusion is nonzero only when the noise intensity is nonzero.
This repairs the omitted sigma assumption in the prose boundary argument. -/
theorem crown_normal_diffusion_nonzero {σ v h : ℝ}
    (hσ : σ≠0) (hv : 0<v) (hh : 0<h) : (1/2:ℝ)*σ*(v^2/h)≠0 := by
  exact mul_ne_zero (mul_ne_zero (by norm_num) hσ)
    (div_ne_zero (pow_ne_zero 2 hv.ne') hh.ne')

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Metric Real Filter MeasureTheory
open scoped Topology NNReal

/-- Replace only the disturbance component of the reference/parameter signal.
The existing certificate supplies geometric and reference data; its original
continuous disturbance is irrelevant to the field defined here. -/
def GlobalTrackingData.measurableParameters (c : GlobalTrackingData) (d : ℝ → ℝ) (t : ℝ) :
    ReferenceParameters := ((c.parameters t).1,(c.parameters t).2.1,(c.parameters t).2.2.1,d t)

def GlobalTrackingData.measurableField (c : GlobalTrackingData) (d : ℝ → ℝ)
    (t : ℝ) (x : MechanicalState) : MechanicalState :=
  c.jointField (c.measurableParameters d t,x)

theorem GlobalTrackingData.joint_bounds (c : GlobalTrackingData) :
    ∃ L : ℝ≥0, ∃ N : ℝ, LipschitzOnWith L c.jointField (c.parameterBox ×ˢ c.outerBox) ∧
      ∀ y∈c.parameterBox ×ˢ c.outerBox, ‖c.jointField y‖≤ N := by
  have hP : IsCompact c.parameterBox := isCompact_Icc.prod
    (isCompact_Icc.prod (isCompact_Icc.prod isCompact_Icc))
  have hB : IsCompact c.outerBox := isCompact_Icc.prod (isCompact_Icc.prod isCompact_Icc)
  have hcP : Convex ℝ c.parameterBox := (convex_Icc _ _).prod
    ((convex_Icc _ _).prod ((convex_Icc _ _).prod (convex_Icc _ _)))
  have hcB : Convex ℝ c.outerBox := (convex_Icc _ _).prod
    ((convex_Icc _ _).prod (convex_Icc _ _))
  apply smooth_compact_convex_bounds
    (isOpen_lt continuous_const continuous_snd.fst) c.jointField_smooth
    (hP.prod hB) (hcP.prod hcB)
  intro y hy
  have hp : 0<c.hlo := c.height_positive
  have hl : c.hlo/2≤ y.2.1 := hy.2.1.1
  change 0<y.2.1
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

theorem GlobalTrackingData.measurable_parameters_mem (c : GlobalTrackingData) {d : ℝ → ℝ}
    (hb : ∀ t, |d t|≤ c.dbar) (t : ℝ) : c.measurableParameters d t∈c.parameterBox := by
  have hp := c.parameters_mem t
  exact ⟨hp.1,hp.2.1,hp.2.2.1,abs_le.mp (hb t)⟩

/-- The measured input enters the actual mechanical field. A globally bounded
extension constructs a global integral/a.e. curve. On a positive time interval
the extension is inactive, so this also proves local Caratheodory existence for
the original equations. Global inactivity still needs the a.e. region proof. -/
theorem GlobalTrackingData.exists_measurable_local (c : GlobalTrackingData) {d : ℝ → ℝ}
    (hdm : Measurable d) (hdb : ∀ t, |d t|≤ c.dbar) :
    ∃ x : ℝ → MechanicalState, ∃ C : ℝ≥0, ∃ ε : ℝ, 0<ε ∧
      LipschitzWith C x ∧ x 0=c.x₀ ∧
      (∀ t, x t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (c.project (x s))) ∧
      (∀ᵐ t ∂volume, HasDerivAt x (c.measurableField d t (c.project (x t))) t) ∧
      (∀ t∈Icc 0 ε, x t∈c.outerBox) ∧
      ∀ᵐ t ∂volume, t∈Icc 0 ε → HasDerivAt x (c.measurableField d t (x t)) t := by
  obtain ⟨L,N,hL,hN⟩ := c.joint_bounds
  let F := fun t x => c.measurableField d t (c.project x)
  have hfl : ∀ t, LipschitzWith L (F t) := by
    intro t
    have hh := hL.comp
      ((LipschitzWith.prodMk_left (c.measurableParameters d t)).comp c.project_lipschitz).lipschitzOnWith (s:=univ)
      (fun x _ => ⟨c.measurable_parameters_mem hdb t,c.project_mem x⟩)
    simpa [F,measurableField,lipschitzOnWith_univ] using! hh
  have hpm : Measurable (c.measurableParameters d) :=
    c.parameters_continuous.fst.measurable.prodMk
      (c.parameters_continuous.snd.fst.measurable.prodMk
        (c.parameters_continuous.snd.snd.fst.measurable.prodMk hdm))
  have hfm : ∀ f : ℝ → MechanicalState, Continuous f →
      AEStronglyMeasurable (fun t => F t (f t)) volume := by
    intro f hf
    let y (t : ℝ) : c.parameterBox ×ˢ c.outerBox :=
      ⟨(c.measurableParameters d t,c.project (f t)),
        c.measurable_parameters_mem hdb t,c.project_mem (f t)⟩
    have hy : Measurable y :=
      (hpm.prodMk (c.project_lipschitz.continuous.comp hf).measurable).subtype_mk
    have hc : Continuous (fun z : c.parameterBox ×ˢ c.outerBox => c.jointField z) :=
      hL.continuousOn.restrict
    exact (hc.measurable.comp hy).aestronglyMeasurable
  let C : ℝ≥0 := ⟨max N 0,le_max_right _ _⟩
  have hfc : ∀ t x, ‖F t x‖≤ C := fun t x =>
    (hN _ ⟨c.measurable_parameters_mem hdb t,c.project_mem x⟩).trans (le_max_left _ _)
  obtain ⟨x,hxL,hx₀,hxI,hxD⟩ := bounded_measurable_global_ae_exists hfl hfm hfc c.x₀
  have hi : c.x₀∈interior c.outerBox := c.safeBox_interior c.initial_mem
  obtain ⟨ρ,hρ,hρB⟩ := Metric.mem_nhds_iff.mp (mem_interior_iff_mem_nhds.mp hi)
  let ε := ρ/(2*(C+1))
  have hε : 0<ε := by dsimp [ε]; positivity
  have hstay (t : ℝ) (ht : t∈Icc 0 ε) : x t∈c.outerBox := by
    apply hρB
    rw [mem_ball,← hx₀]
    have hl := hxL.dist_le_mul t 0
    rw [Real.dist_eq,sub_zero,abs_of_nonneg ht.1] at hl
    have he : (C:ℝ)*ε<ρ := by
      dsimp [ε]
      rw [← mul_div_assoc]
      apply (div_lt_iff₀ (by positivity : 0<2*((C:ℝ)+1))).mpr
      (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [NNReal.coe_nonneg C]
    exact hl.trans_lt ((mul_le_mul_of_nonneg_left ht.2 C.property).trans_lt he)
  refine ⟨x,C,ε,hε,hxL,hx₀,hxI,hxD,hstay,?_⟩
  filter_upwards [hxD] with t ht hte
  simpa [F,c.project_eq (x t) (hstay t hte)] using! ht

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Metric Real Filter MeasureTheory
open scoped Topology NNReal
set_option maxHeartbeats 800000

theorem GlobalTrackingData.reference_lipschitz (c : GlobalTrackingData) (T : ℝ) :
    ∃ L₁ L₂ : ℝ≥0, LipschitzOnWith L₁ c.r (Icc 0 T) ∧
      LipschitzOnWith L₂ c.r₁ (Icc 0 T) := by
  have hR₁ : 0≤ c.R₁ := (abs_nonneg _).trans (c.rate_bound 0 le_rfl)
  have hR₂ : 0≤ c.R₂ := (abs_nonneg _).trans (c.accel_bound 0 le_rfl)
  refine ⟨⟨c.R₁,hR₁⟩,⟨c.R₂,hR₂⟩,?_,?_⟩
  · apply (convex_Icc (0:ℝ) T).lipschitzOnWith_of_nnnorm_deriv_le
      (fun t ht => (c.dr t ht.1).differentiableAt)
    intro t ht
    rw [(c.dr t ht.1).deriv]
    exact_mod_cast c.rate_bound t ht.1
  · apply (convex_Icc (0:ℝ) T).lipschitzOnWith_of_nnnorm_deriv_le
      (fun t ht => (c.dr₁ t ht.1).differentiableAt)
    intro t ht
    rw [(c.dr₁ t ht.1).deriv]
    exact_mod_cast c.accel_bound t ht.1

theorem GlobalTrackingData.errors_lipschitz (c : GlobalTrackingData)
    {x : ℝ → MechanicalState} {K : ℝ≥0} (hx : LipschitzWith K x) (T : ℝ) :
    ∃ Le Lz : ℝ≥0,
      LipschitzOnWith Le (heightError (fun t => (x t).1) c.r) (Icc 0 T) ∧
      LipschitzOnWith Lz (velocityError c.k₁ (fun t => (x t).1)
        (fun t => (x t).2.1) (fun t => (x t).2.2) c.r c.r₁) (Icc 0 T) := by
  obtain ⟨L₁,L₂,hr,hr₁⟩ := c.reference_lipschitz T
  have hp := hx.lipschitzOnWith.prodMk (hr.prodMk hr₁)
  have hse : ContDiff ℝ 1 (fun p : MechanicalState × (ℝ×ℝ) => p.1.1-p.2.1) := by fun_prop
  have hsz : ContDiff ℝ 1 (fun p : MechanicalState × (ℝ×ℝ) =>
      p.1.2.1-p.1.2.2-2*p.2.2+2*c.k₁*(p.1.1-p.2.1)) := by fun_prop
  obtain ⟨Le,he⟩ := smooth_comp_lipschitzOn hse hp
  obtain ⟨Lz,hz⟩ := smooth_comp_lipschitzOn hsz hp
  exact ⟨Le,Lz,he,hz⟩

theorem GlobalTrackingData.measurable_prefix_energy (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdb : ∀ t, |d t|≤ c.dbar)
    {x : ℝ → MechanicalState} {K : ℝ≥0} {T : ℝ} (hxL : LipschitzWith K x)
    (hx₀ : x 0=c.x₀) (hbox : ∀ t∈Icc 0 T, x t∈c.outerBox)
    (hxD : ∀ᵐ t ∂volume, HasDerivAt x (c.measurableField d t (c.project (x t))) t) :
    ∀ t∈Icc 0 T, c.stateEnergy t (x t)≤
      exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+c.dbar^2/(16*c.κ*c.κd)*(1-exp (-2*c.κ*t)) ∧
      c.stateEnergy t (x t)≤ c.cap := by
  let h := fun t => (x t).1
  let v := fun t => (x t).2.1
  let w := fun t => (x t).2.2
  obtain ⟨Le,Lz,hel,hzl⟩ := c.errors_lipschitz hxL T
  have heq : ∀ᵐ t ∂volume, t∈Ioo 0 T →
      HasDerivAt (heightError h c.r) (errorRate c.k₁ (heightError h c.r t)
        (velocityError c.k₁ h v w c.r c.r₁ t)) t ∧
      HasDerivAt (velocityError c.k₁ h v w c.r c.r₁)
        (zRate c.k₀ c.k₂ c.κd ((v t)^2/h t) (d t) (heightError h c.r t)
          (velocityError c.k₁ h v w c.r c.r₁ t)) t := by
    filter_upwards [hxD] with t hdt ht
    have hB := hbox t (Ioo_subset_Icc_self ht)
    rw [c.project_eq (x t) hB] at hdt
    have hp : 0<(x t).1 := by have hl := hB.1.1; have := c.height_positive; change 0<c.hlo at this; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
    have hHp : 0<c.H+(x t).1 := add_pos c.H_pos hp
    have dh : HasDerivAt h (heightRate (v t) (w t)) t := by
      simpa [h,v,w,measurableField,jointField] using! hasFDerivAt_fst.comp_hasDerivAt t hdt
    have dv : HasDerivAt v (rise c.g (c.α+d t) (h t) (v t) (w t)
        (requestedInput c.H c.g c.α c.β c.k₀ c.k₁ c.k₂ c.κd h v w c.r c.r₁ c.r₂ t)) t := by
      simpa [h,v,w,measurableField,measurableParameters,jointField,parameters,max_eq_right ht.1.le,
        requestedInput,heightError,velocityError] using!
        hasFDerivAt_fst.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t hdt)
    have dw : HasDerivAt w (fall c.H c.g c.β (h t) (v t) (w t)) t := by
      simpa [h,v,w,measurableField,jointField] using!
        hasFDerivAt_snd.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t hdt)
    exact closed_loop_error_equations hp.ne' hHp.ne' dh dv dw (c.dr t ht.1.le) (c.dr₁ t ht.1.le)
  have he := robust_error_estimate_ae c.k₀_pos.le c.κ_pos c.κ_le_k₁ c.κ_le_k₂ hκd
    hel hzl (heq.mono (fun t ht hmem => (ht hmem).1))
    (heq.mono (fun t ht hmem => (ht hmem).2)) (Filter.Eventually.of_forall (fun t _ => hdb t))
  intro t ht
  have he' : c.stateEnergy t (x t)≤
      exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+c.dbar^2/(16*c.κ*c.κd)*(1-exp (-2*c.κ*t)) := by
    simpa [stateEnergy,heightError,velocityError,h,v,w,hx₀] using! he t ht
  refine ⟨he',he'.trans ?_⟩
  have hcap : (c.dbar^2/(8*c.κd))/(2*c.κ)≤ c.cap := by
    convert! c.disturbance_cap using 1; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  convert! envelope_below_cap c.κ_pos ht.1 c.initial_energy hcap using 1
  unfold envelope stateEnergy
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- The falling speed is classical even under measurable pickup disturbances,
because its a.e. right hand side is a continuous function of the state. -/
theorem GlobalTrackingData.measurable_fall_classical (c : GlobalTrackingData)
    {d : ℝ → ℝ} {x : ℝ → MechanicalState} {K : ℝ≥0} (hxL : LipschitzWith K x)
    (hxD : ∀ᵐ t ∂volume, HasDerivAt x (c.measurableField d t (c.project (x t))) t) :
    ∀ t, HasDerivAt (fun s => (x s).2.2)
      (fall c.H c.g c.β (c.project (x t)).1 (c.project (x t)).2.1 (c.project (x t)).2.2) t := by
  have hwL : LipschitzWith K (fun t => (x t).2.2) := by
    simpa using! LipschitzWith.prod_snd.comp (LipschitzWith.prod_snd.comp hxL)
  have hpc : Continuous (fun t => c.project (x t)) := c.project_lipschitz.continuous.comp hxL.continuous
  have hden (t : ℝ) : c.H+(c.project (x t)).1≠0 := by
    have hl := (c.project_mem (x t)).1.1
    have hp : 0<c.hlo := c.height_positive
    exact ne_of_gt (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [c.H_pos])
  have hcont : Continuous (fun t =>
      fall c.H c.g c.β (c.project (x t)).1 (c.project (x t)).2.1 (c.project (x t)).2.2) := by
    unfold fall crownSq
    exact continuous_const.add
      (((((hpc.snd.fst.add hpc.snd.snd).div_const 2).pow 2).neg.add
        (continuous_const.mul (hpc.snd.snd.pow 2))).div
          (continuous_const.add hpc.fst) hden)
  apply lipschitz_ae_continuous_derivative hwL hcont
  filter_upwards [hxD] with t ht
  simpa [measurableField,jointField] using!
    hasFDerivAt_snd.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t ht)

theorem GlobalTrackingData.measurable_prefix_bound (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdb : ∀ t, |d t|≤ c.dbar)
    {x : ℝ → MechanicalState} {K : ℝ≥0} {T : ℝ} (hxL : LipschitzWith K x)
    (hT : 0≤ T) (hx₀ : x 0=c.x₀) (hbox : ∀ t∈Icc 0 T, x t∈c.outerBox)
    (hxD : ∀ᵐ t ∂volume, HasDerivAt x (c.measurableField d t (c.project (x t))) t) :
    x T∈c.safeBox := by
  have henergy := c.measurable_prefix_energy hκd hdb hxL hx₀ hbox hxD
  have he (t : ℝ) (ht : t∈Icc 0 T) := trajectory_enclosure
    (h:=fun s => (x s).1) (v:=fun s => (x s).2.1) (w:=fun s => (x s).2.2)
    (r:=c.r) (r₁:=c.r₁) (k₁:=c.k₁) (cap:=c.cap)
    (rlo:=c.rlo) (rhi:=c.rhi) (R₁:=c.R₁)
    c.k₀_pos (henergy t ht).2 (c.ref_bounds t ht.1) (c.rate_bound t ht.1)
  have hhc : ContinuousOn (fun t => (x t).1) (Icc 0 T) := hxL.continuous.fst.continuousOn
  have hwc : ContinuousOn (fun t => (x t).2.2) (Icc 0 T) := hxL.continuous.snd.snd.continuousOn
  have hvc : ContinuousOn (fun t => (x t).2.1) (Icc 0 T) := hxL.continuous.snd.fst.continuousOn
  have hqc : ContinuousOn (fun t => heightRate (x t).2.1 (x t).2.2) (Icc 0 T) :=
    (hvc.sub hwc).div_const 2
  have hden (t : ℝ) (ht : t∈Icc 0 T) : c.H+(x t).1≠0 := by
    have hl := (hbox t ht).1.1
    have hp : 0<c.hlo := c.height_positive
    exact ne_of_gt (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [c.H_pos])
  have hK (b : ℝ) : ContinuousOn
      (fun t => -((1-c.β)*((x t).2.2+b)+2*heightRate (x t).2.1 (x t).2.2)/(c.H+(x t).1))
      (Icc 0 T) :=
    ((continuousOn_const.mul (hwc.add continuousOn_const)).add
      (continuousOn_const.mul hqc)).neg.div (continuousOn_const.add hhc) hden
  have hwd := c.measurable_fall_classical hxL hxD
  have hwdActual (t : ℝ) (ht : t∈Icc 0 T) :
      HasDerivAt (fun s => (x s).2.2)
        (fall c.H c.g c.β (x t).1 (x t).2.1 (x t).2.2) t := by
    simpa only [c.project_eq (x t) (hbox t ht)] using! hwd t
  have hi (t : ℝ) (ht : t∈Ico 0 T) :
      HasDerivWithinAt (fun s => (x s).2.2)
        (internal c.H c.g c.β (x t).1 (x t).2.2
          (heightRate (x t).2.1 (x t).2.2)) (Ici t) t := by
    exact (mechanical_internal_equation
      (h:=fun s => (x s).1) (v:=fun s => (x s).2.1) (w:=fun s => (x s).2.2)
      (H:=c.H) (g:=c.g) (β:=c.β) (t:=t)
      (hden t (Ico_subset_Icc_self ht)) (hwdActual t (Ico_subset_Icc_self ht))).hasDerivWithinAt
  have hwinv := physical_region_invariant
    (h:=fun t => (x t).1) (w:=fun t => (x t).2.2)
    (q:=fun t => heightRate (x t).2.1 (x t).2.2)
    (H:=c.H) (g:=c.g) (β:=c.β) (T:=T) (hlo:=c.hlo) (hhi:=c.hhi)
    (Q:=c.Q) (wlo:=c.wlo) (whi:=c.whi) (vmin:=c.vmin)
    c.H_pos c.g_nonneg c.height_positive hwc
    hi
    (hK c.wlo) (hK c.whi) (fun t ht => ⟨(he t ht).1,(he t ht).2.1⟩)
    (fun t ht => (he t ht).2.2) c.forward c.speed_order c.crown
    c.lower_face_bound c.upper_face_bound (by simpa [hx₀] using! c.initial_speed) T ⟨hT,le_rfl⟩
  exact c.box_of_energy_speed T hT (x T) (henergy T ⟨hT,le_rfl⟩).2 ⟨hwinv.2.1,hwinv.2.2.1⟩

/-- Global physical existence and tracking for bounded measurable disturbances.
The trajectory is constructed from data, the projection is proved inactive for
all nonnegative times, and the original equations hold almost everywhere. -/
theorem GlobalTrackingData.exists_global_measurable_tracking (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : Measurable d) (hdb : ∀ t, |d t|≤ c.dbar) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      ∀ t≥0, c.stateEnergy t (x t)≤ c.cap ∧
        c.stateEnergy t (x t)≤ exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-exp (-2*c.κ*t)) := by
  obtain ⟨x,K,ε,hε,hxL,hx₀,hxI,hxD,hlocal,hlocalD⟩ := c.exists_measurable_local hdm hdb
  have hstay := no_exit_of_prefix_bound hxL.continuous
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    (hx₀ ▸ c.safeBox_interior c.initial_mem) (fun T hT hbox =>
      c.measurable_prefix_bound hκd hdb hxL hT hx₀ hbox hxD)
  refine ⟨x,K,hxL,hx₀,?_,hstay,?_⟩
  · filter_upwards [hxD] with t ht ht0
    simpa [c.project_eq (x t) (interior_subset (c.safeBox_interior (hstay t ht0)))] using! ht
  · intro t ht
    have he := c.measurable_prefix_energy hκd hdb hxL hx₀
      (fun s (hs : s∈Icc 0 t) => interior_subset (c.safeBox_interior (hstay s hs.1))) hxD t ⟨ht,le_rfl⟩
    exact ⟨he.2,he.1⟩

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Real MeasureTheory
open scoped NNReal

theorem GlobalTrackingData.force_of_energy_box_disturbance (c : GlobalTrackingData)
    (ha : c.α ≤ 1) (hb : 0 ≤ c.β) {uLo uHi t δ : ℝ} {x : MechanicalState}
    (hc : c.forceCertificate uLo uHi) (ht : 0 ≤ t) (hbox : x ∈ c.safeBox)
    (hE : c.stateEnergy t x ≤ c.cap) (hδ : |δ|≤ c.dbar) :
    uLo ≤ c.command t x ∧ c.command t x ≤ uHi ∧
      0 ≤ pickup (c.α+δ) x.2.1 (c.command t x) := by
  have hR : 0 ≤ c.R₁ := (abs_nonneg _).trans (c.rate_bound 0 le_rfl)
  have hQ : 0 ≤ c.Q := by dsimp [Q]; positivity
  have hf : 2*c.Q < c.wlo := c.forward
  have hvlo : 0 ≤ c.vlo := by dsimp [vlo]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hwlo : 0 ≤ c.wlo := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hslo : 0 ≤ c.wlo-c.Q := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hS : c.wlo-c.Q ≤ (x.2.1+x.2.2)/2 ∧ (x.2.1+x.2.2)/2 ≤ c.whi+c.Q := by
    have hv := hbox.2.1
    have hw := hbox.2.2
    change c.wlo-2*c.Q ≤ x.2.1 ∧ x.2.1 ≤ c.whi+2*c.Q at hv
    constructor <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [hv.1,hv.2,hw.1,hw.2]
  have he := error_enclosure (k₁:=c.k₁) c.k₀_pos hE
  have hq : |heightRate x.2.1 x.2.2-c.r₁ t| ≤ sqrt (2*c.cap)*sqrt (1+c.k₁^2/c.k₀) := by
    convert! he.2.2 using 1 <;> congr 1 <;> unfold heightRate <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hA := acceleration_bound c.k₀_pos.le (c.κ_pos.le.trans c.κ_le_k₁)
    (c.κ_pos.le.trans c.κ_le_k₂) he.1 hq (c.accel_bound t ht)
  exact robust_force_feasibility c.H_pos c.g_nonneg ha hb c.height_positive
    hbox.1 (square_interval hvlo hbox.2.1) (square_interval hwlo hbox.2.2).2
    (square_interval hslo hS) hA c.κd_nonneg he.2.1 hδ
    hc.1 hc.2.1 hc.2.2

/-- The global actuator and physical-domain certificate now allows a bounded
measurable disturbance. A solution is constructed, and no trajectory is an input. -/
theorem GlobalTrackingData.exists_global_measurable_admissible (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : Measurable d) (hdb : ∀ t, |d t|≤ c.dbar)
    (ha : c.α≤1) (hb : 0≤ c.β) (uLo uHi : ℝ) (hc : c.forceCertificate uLo uHi) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      ∀ t≥0, c.stateEnergy t (x t)≤ c.cap ∧ 0<(x t).1 ∧ 0<(x t).2.1 ∧
        c.vmin≤((x t).2.1+(x t).2.2)/2 ∧
        uLo≤ c.command t (x t) ∧ c.command t (x t)≤ uHi ∧
        0≤ pickup (c.α+d t) (x t).2.1 (c.command t (x t)) := by
  obtain ⟨x,K,hxL,hx₀,hxD,hbox,hE⟩ := c.exists_global_measurable_tracking hκd hdm hdb
  refine ⟨x,K,hxL,hx₀,hxD,hbox,fun t ht => ?_⟩
  have hB := hbox t ht
  have hEn := (hE t ht).1
  have hforce := c.force_of_energy_box_disturbance ha hb hc ht hB hEn (hdb t)
  have hh : 0<(x t).1 := lt_of_lt_of_le c.height_positive hB.1.1
  have hv : 0<(x t).2.1 := by
    have hvl := hB.2.1.1
    change c.wlo-2*c.Q≤(x t).2.1 at hvl
    have hf : 2*c.Q<c.wlo := c.forward
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hs : c.vmin≤((x t).2.1+(x t).2.2)/2 := by
    have hvl := hB.2.1.1
    change c.wlo-2*c.Q≤(x t).2.1 at hvl
    have hwl := hB.2.2.1
    have hcr : c.vmin≤ c.wlo-c.Q := c.crown
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  exact ⟨hEn,hh,hv,hs,hforce⟩

/-- The physical certificate also admits Lebesgue-a.e. measurable inputs. A
bounded Borel representative constructs the solution; the original disturbance
is recovered in the a.e. ODE, and its pointwise bound certifies pickup tension. -/
theorem GlobalTrackingData.exists_global_aemeasurable_admissible (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : AEMeasurable d volume) (hdb : ∀ t, |d t|≤ c.dbar)
    (ha : c.α≤1) (hb : 0≤ c.β) (uLo uHi : ℝ) (hc : c.forceCertificate uLo uHi) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      ∀ t≥0, c.stateEnergy t (x t)≤ c.cap ∧ 0<(x t).1 ∧ 0<(x t).2.1 ∧
        c.vmin≤((x t).2.1+(x t).2.2)/2 ∧
        uLo≤ c.command t (x t) ∧ c.command t (x t)≤ uHi ∧
        0≤ pickup (c.α+d t) (x t).2.1 (c.command t (x t)) := by
  have hb0 : 0≤ c.dbar := (abs_nonneg (d 0)).trans (hdb 0)
  have horder : -c.dbar≤ c.dbar := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  let b : ℝ → ℝ := fun t => max (-c.dbar) (min c.dbar (hdm.mk d t))
  have hbm : Measurable b := measurable_const.max (measurable_const.min hdm.measurable_mk)
  have hbb (t : ℝ) : |b t|≤ c.dbar := by
    apply abs_le.mpr
    exact ⟨le_max_left _ _,max_le horder (min_le_left _ _)⟩
  have heq : d =ᵐ[volume] b := by
    filter_upwards [hdm.ae_eq_mk] with t ht
    have hb := abs_le.mp (hdb t)
    simp only [b,← ht,min_eq_right hb.2,max_eq_right hb.1]
  obtain ⟨x,K,hxL,hx₀,hxD,hbox,hrest⟩ :=
    c.exists_global_measurable_admissible hκd hbm hbb ha hb uLo uHi hc
  refine ⟨x,K,hxL,hx₀,?_,hbox,fun t ht => ?_⟩
  · filter_upwards [hxD,heq] with t hdt he ht
    simpa only [measurableField,measurableParameters,← he] using! hdt ht
  · have hr := hrest t ht
    have hf := c.force_of_energy_box_disturbance ha hb hc ht (hbox t ht) hr.1 (hdb t)
    exact ⟨hr.1,hr.2.1,hr.2.2.1,hr.2.2.2.1,hf⟩

/-- The full robust envelope for a.e.-measurable pointwise-bounded disturbances. -/
theorem GlobalTrackingData.exists_global_aemeasurable_tracking (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : AEMeasurable d volume) (hdb : ∀ t, |d t|≤ c.dbar)
    :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      ∀ t≥0, c.stateEnergy t (x t)≤ c.cap ∧
        c.stateEnergy t (x t)≤ exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-exp (-2*c.κ*t)) := by
  have hb0 : 0≤ c.dbar := (abs_nonneg (d 0)).trans (hdb 0)
  have horder : -c.dbar≤ c.dbar := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  let b : ℝ → ℝ := fun t => max (-c.dbar) (min c.dbar (hdm.mk d t))
  have hbm : Measurable b := measurable_const.max (measurable_const.min hdm.measurable_mk)
  have hbb (t : ℝ) : |b t|≤ c.dbar := by
    apply abs_le.mpr
    exact ⟨le_max_left _ _,max_le horder (min_le_left _ _)⟩
  have heq : d =ᵐ[volume] b := by
    filter_upwards [hdm.ae_eq_mk] with t ht
    have hb := abs_le.mp (hdb t)
    simp only [b,← ht,min_eq_right hb.2,max_eq_right hb.1]
  obtain ⟨x,K,hxL,hx₀,hxD,hbox,hrest⟩ :=
    c.exists_global_measurable_tracking hκd hbm hbb
  refine ⟨x,K,hxL,hx₀,?_,hbox,hrest⟩
  filter_upwards [hxD,heq] with t hdt he ht
  simpa only [measurableField,measurableParameters,← he] using! hdt ht

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Real

/-- Explicit positive-branch solution of `w' = a (s²-w²)`. The formula is
defined on all real times; the theorem only asserts regularity for `t ≥ 0`. -/
def zeroFlow (a s w₀ t : ℝ) : ℝ :=
  s * (1 + ((w₀-s)/(w₀+s))*exp (-2*a*s*t)) /
    (1 - ((w₀-s)/(w₀+s))*exp (-2*a*s*t))

theorem zero_ratio_abs_lt_one {s w₀ : ℝ} (hs : 0<s) (hw : 0<w₀) :
    |(w₀-s)/(w₀+s)|<1 := by
  rw [abs_div,abs_of_pos (add_pos hw hs),div_lt_one (add_pos hw hs)]
  exact abs_lt.mpr ⟨by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith,by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith⟩

theorem zero_flow_den_pos {a s w₀ t : ℝ}
    (ha : 0<a) (hs : 0<s) (hw : 0<w₀) (ht : 0≤ t) :
    0<1-((w₀-s)/(w₀+s))*exp (-2*a*s*t) := by
  have he : exp (-2*a*s*t)≤1 := exp_le_one_iff.mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_nonneg (mul_nonneg ha.le hs.le) ht])
  have hq := zero_ratio_abs_lt_one hs hw
  have hprod : |((w₀-s)/(w₀+s))*exp (-2*a*s*t)|<1 := by
    rw [abs_mul,abs_of_pos (exp_pos _)]
    exact (mul_le_mul_of_nonneg_left he (abs_nonneg _)).trans_lt (by simpa using! hq)
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(abs_lt.mp hprod).2]

theorem zero_flow_pos {a s w₀ t : ℝ}
    (ha : 0<a) (hs : 0<s) (hw : 0<w₀) (ht : 0≤ t) :
    0<zeroFlow a s w₀ t := by
  have he : exp (-2*a*s*t)≤1 := exp_le_one_iff.mpr (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_nonneg (mul_nonneg ha.le hs.le) ht])
  have hq := zero_ratio_abs_lt_one hs hw
  have hp : |((w₀-s)/(w₀+s))*exp (-2*a*s*t)|<1 := by
    rw [abs_mul,abs_of_pos (exp_pos _)]
    exact (mul_le_mul_of_nonneg_left he (abs_nonneg _)).trans_lt (by simpa using! hq)
  exact div_pos (mul_pos hs (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith [(abs_lt.mp hp).1]))
    (zero_flow_den_pos ha hs hw ht)

theorem zero_flow_initial {a s w₀ : ℝ} (hs : 0<s) (hw : 0<w₀) :
    zeroFlow a s w₀ 0=w₀ := by
  have hd : w₀+s≠0 := (add_pos hw hs).ne'
  have hq : 1-(w₀-s)/(w₀+s)≠0 := by
    have hh := (abs_lt.mp (zero_ratio_abs_lt_one hs hw)).2
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  dsimp [zeroFlow]
  simp only [mul_zero,exp_zero,mul_one]
  field_simp [hs.ne']
  <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem zero_flow_derivative {a s w₀ t : ℝ}
    (ha : 0<a) (hs : 0<s) (hw : 0<w₀) (ht : 0≤ t) :
    HasDerivAt (zeroFlow a s w₀) (a*(s^2-(zeroFlow a s w₀ t)^2)) t := by
  have hd := (zero_flow_den_pos ha hs hw ht).ne'
  have de := (((hasDerivAt_id t).const_mul (-2*a*s)).exp).const_mul ((w₀-s)/(w₀+s))
  have dh := ((de.const_add 1).const_mul s).div (de.const_sub 1) hd
  convert! dh using 1
  dsimp only [zeroFlow, id_eq]
  generalize (w₀-s)/(w₀+s) = q at hd ⊢
  generalize exp (-2*a*s*t) = E at hd ⊢
  field_simp [hd]
  <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

/-- Global positive solution and the paper's exact exponential estimate, for
every positive initial speed. Existence is supplied by `zeroFlow`, not assumed. -/
theorem exists_global_zero_dynamics {H g β r s w₀ : ℝ}
    (hD : 0<H+r) (hβ : β<1) (hs : 0<s) (hw : 0<w₀)
    (heq : (1-β)*s^2=g*(H+r)) :
    ∃ w : ℝ → ℝ, w 0=w₀ ∧ ∀ t≥0,
      0<w t ∧ HasDerivAt w (internal H g β r (w t) 0) t ∧
      |w t-s|≤|w₀-s| *exp (-((1-β)*s/(H+r))*t) := by
  let a := (1-β)/(H+r)
  have ha : 0<a := div_pos (sub_pos.mpr hβ) hD
  let w := zeroFlow a s w₀
  have hd (t : ℝ) (ht : 0≤ t) := zero_flow_derivative ha hs hw ht
  have hp (t : ℝ) (ht : 0≤ t) : 0<w t := zero_flow_pos ha hs hw ht
  have hinit : w 0=w₀ := zero_flow_initial hs hw
  refine ⟨w,hinit,?_⟩
  intro t ht
  have hc : ContinuousOn w (Icc 0 t) :=
    fun u hu => (hd u hu.1).continuousAt.continuousWithinAt
  refine ⟨hp t ht,?_,?_⟩
  · convert! hd t ht using 1
    dsimp [internal,a]
    field_simp
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [heq]
  · have hdec := scalar_exponential_decay (y:=fun u => w u-s)
      (a:=fun u => a*(s+w u)) (f:=fun _ => 0) (T:=t)
      (ρ:=a*s) (δ:=0) (M:=|w₀-s|)
      (continuousOn_const.mul (continuousOn_const.add hc))
      (hc.sub continuousOn_const)
      (fun u hu => by
        convert! ((hd u hu.1).sub_const s).hasDerivWithinAt using 1 <;> dsimp [w] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring)
      (abs_nonneg _) (fun u hu => by
        change a*s+0≤ a*(s+w u)
        (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [mul_pos ha (hp u hu.1)])
      (by intro u hu; simp) (by simpa only [hinit] using! le_refl |w₀-s|) t ⟨ht,le_rfl⟩
    convert! hdec using 1 <;> dsimp [a] <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Polynomial

def transferNumerator (α ω h : ℝ) : ℝ[X] := C (-(1/(2*h))) * (X+C (2*α*ω))
def transferDenominator (α ρ ω : ℝ) : ℝ[X] :=
  X^3+C (coeff₂ ρ ω)*X^2+C (coeff₁ α ρ ω)*X+C (coeff₀ α ρ ω)

theorem transfer_denominator_eval (α ρ ω p : ℝ) :
    (transferDenominator α ρ ω).eval p=cubic α ρ ω p := by
  simp [transferDenominator,cubic]

theorem transfer_numerator_eval (α ω h p : ℝ) :
    (transferNumerator α ω h).eval p= -(p+2*α*ω)/(2*h) := by
  simp [transferNumerator]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring

theorem transfer_polynomial_degrees {α ρ ω h : ℝ} (hh : h≠0) :
    (transferNumerator α ω h).natDegree=1 ∧
    (transferDenominator α ρ ω).natDegree=3 := by
  constructor
  · unfold transferNumerator
    rw [natDegree_C_mul (by exact neg_ne_zero.mpr (one_div_ne_zero (mul_ne_zero (by norm_num) hh))),
      natDegree_X_add_C]
  · unfold transferDenominator
    compute_degree!

theorem transfer_relative_degree_two {α ρ ω h : ℝ} (hh : h≠0) :
    (transferDenominator α ρ ω).natDegree-(transferNumerator α ω h).natDegree=2 := by
  rw [(transfer_polynomial_degrees (α:=α) (ρ:=ρ) (ω:=ω) hh).1,(transfer_polynomial_degrees (α:=α) (ρ:=ρ) (ω:=ω) hh).2]

theorem transfer_static_gain_negative {α ρ ω h : ℝ}
    (ha : 0<α) (hr : ρ<1) (hw : 0<ω) (hh : 0<h) :
    (transferNumerator α ω h).eval 0/(transferDenominator α ρ ω).eval 0 < 0 := by
  rw [transfer_numerator_eval,transfer_denominator_eval]
  simp only [cubic,zero_pow (by decide : 3≠0),zero_pow (by decide : 2≠0),
    mul_zero,zero_add,add_zero]
  have hrp : 0<1-ρ := sub_pos.mpr hr
  have hc : 0<coeff₀ α ρ ω := by unfold coeff₀; positivity
  exact div_neg_of_neg_of_pos (div_neg_of_neg_of_pos (neg_neg_of_pos (by positivity)) (by positivity)) hc

theorem transfer_physical_zero {α g h s : ℝ} (hh : h≠0) (hs : s≠0)
    (heq : α*s^2=g*h) : -2*α*(s/h) = -2*g/s := by
  field_simp
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [heq]

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Real Filter MeasureTheory intervalIntegral
open scoped Topology NNReal

/-- A Lipschitz restriction has an integrable derivative and satisfies FTC.
The proof uses the constant extension outside the interval. -/
theorem lipschitzOn_integral_deriv {f : ℝ → ℝ} {L : ℝ≥0} {a b : ℝ}
    (hab : a≤ b) (hf : LipschitzOnWith L f (Icc a b)) :
    IntervalIntegrable (deriv f) volume a b ∧
      (∫ t in a..b, deriv f t)=f b-f a := by
  by_cases heq : a=b
  · subst b
    simp
  have hab' : a<b := lt_of_le_of_ne hab heq
  let g : ℝ → ℝ := fun t => f (projIcc a b hab t)
  have hgl : LipschitzWith L g := by
    simpa only [mul_one,Function.comp_def,Set.restrict_apply] using!
      hf.to_restrict.comp (LipschitzWith.projIcc hab)
  have he (t : ℝ) (ht : t∈Ioo a b) : g =ᶠ[𝓝 t] f := by
    filter_upwards [Ioo_mem_nhds ht.1 ht.2] with s hs
    simp [g,projIcc_of_mem hab (Ioo_subset_Icc_self hs)]
  have hne : ∀ᵐ t ∂volume, t≠b := by
    simp [ae_iff,measure_singleton]
  have hde : deriv f =ᵐ[volume.restrict (Ioc a b)] deriv g := by
    filter_upwards [ae_restrict_of_ae hne,ae_restrict_mem measurableSet_Ioc] with t htb ht
    exact ((he t ⟨ht.1,lt_of_le_of_ne ht.2 htb⟩).deriv_eq).symm
  have hgi : IntegrableOn (deriv g) (Ioc a b) := by
    apply (integrable_const (L:ℝ)).mono' (aestronglyMeasurable_deriv _ _)
    exact Eventually.of_forall (fun _ => norm_deriv_le_of_lipschitz hgl)
  have hi : IntervalIntegrable (deriv f) volume a b :=
    (intervalIntegrable_iff_integrableOn_Ioc_of_le hab).mpr (hgi.congr hde.symm)
  refine ⟨hi,?_⟩
  have hInt : (∫ t in a..b, deriv f t)=(∫ t in a..b, deriv g t) := by
    rw [integral_of_le hab,integral_of_le hab]
    exact integral_congr_ae hde
  rw [hInt,lipschitz_integral_deriv hgl hab]
  simp [g,projIcc_of_mem hab (left_mem_Icc.mpr hab),projIcc_of_mem hab (right_mem_Icc.mpr hab)]

/-- Dissipation integrated for a.e. derivatives; the FTC and derivative
integrability are proved from Lipschitz regularity, not assumed. -/
theorem weighted_integral_estimate_ae {V d : ℝ → ℝ} {L : ℝ≥0} {T κ κd : ℝ}
    (hT : 0≤ T) (hκ : 0<κ) (hκd : 0<κd)
    (hV : LipschitzOnWith L V (Icc 0 T))
    (hd : IntervalIntegrable (fun t => d t^2) volume 0 T)
    (hb : ∀ᵐ t ∂volume, t∈Ioo 0 T → deriv V t≤ -2*κ*V t+d t^2/(8*κd))
    (hVT : 0≤ V T) :
    (∫ t in (0:ℝ)..T, 2*V t)≤ V 0/κ+(1/(8*κ*κd))*(∫ t in (0:ℝ)..T, d t^2) := by
  obtain ⟨hVp,hFTC⟩ := lipschitzOn_integral_deriv hT hV
  have hVi : IntervalIntegrable V volume 0 T := hV.continuousOn.intervalIntegrable_of_Icc hT
  have hne : ∀ᵐ t ∂volume, t≠T := by
    simp [ae_iff,measure_singleton]
  have hi : (∫ t in (0:ℝ)..T, deriv V t)≤
      ∫ t in (0:ℝ)..T, -2*κ*V t+d t^2/(8*κd) := by
    rw [integral_of_le hT,integral_of_le hT]
    apply integral_mono_ae hVp.1 (((hVi.const_mul (-2*κ)).add (hd.div_const (8*κd))).1)
    filter_upwards [ae_restrict_of_ae hb,ae_restrict_of_ae hne,
      ae_restrict_mem measurableSet_Ioc] with t ht hn hm
    exact ht ⟨hm.1,lt_of_le_of_ne hm.2 hn⟩
  rw [hFTC,intervalIntegral.integral_add (hVi.const_mul (-2*κ)) (hd.div_const (8*κd)),
    intervalIntegral.integral_const_mul,intervalIntegral.integral_div] at hi
  rw [intervalIntegral.integral_const_mul]
  apply (mul_le_mul_iff_right₀ hκ).mp
  have hc₁ : κ*(V 0/κ)=V 0 := by field_simp
  have hc₂ : κ*(1/(8*κ*κd))=1/(8*κd) := by field_simp <;> (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  have hc₃ : κ*(1/(8*κ*κd)*(∫ t in (0:ℝ)..T, d t^2))=
      (∫ t in (0:ℝ)..T, d t^2)/(8*κd) := by
    rw [←mul_assoc,hc₂]; (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
  rw [mul_add,hc₁,hc₃]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [hi]

theorem robust_error_integral_ae {e z G d : ℝ → ℝ} {T k₀ k₁ k₂ κ κd : ℝ}
    {Le Lz : ℝ≥0} (hT : 0≤ T) (hk₀ : 0≤ k₀) (hκ : 0<κ)
    (hk₁ : κ≤ k₁) (hk₂ : κ≤ k₂) (hκd : 0<κd)
    (hel : LipschitzOnWith Le e (Icc 0 T)) (hzl : LipschitzOnWith Lz z (Icc 0 T))
    (he : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt e (errorRate k₁ (e t) (z t)) t)
    (hz : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt z (zRate k₀ k₂ κd (G t) (d t) (e t) (z t)) t)
    (hd : IntervalIntegrable (fun t => d t^2) volume 0 T) :
    (∫ t in (0:ℝ)..T, 2*errorEnergy k₀ (e t) (z t))≤
      errorEnergy k₀ (e 0) (z 0)/κ+(1/(8*κ*κd))*(∫ t in (0:ℝ)..T, d t^2) := by
  have hsm : ContDiff ℝ 1 (fun p : ℝ×ℝ => errorEnergy k₀ p.1 p.2) := by
    unfold errorEnergy
    fun_prop (disch := norm_num)
  obtain ⟨L,hL⟩ := smooth_comp_lipschitzOn hsm (hel.prodMk hzl)
  apply weighted_integral_estimate_ae hT hκ hκd hL hd _ (energy_nonneg hk₀ _ _)
  filter_upwards [he,hz] with t het hzt ht
  rw [(energy_hasDerivAt_errors (het ht) (hzt ht)).deriv]
  simpa only [sq_abs] using! robust_decay_uniform (G:=G t) (e:=e t) (z:=z t)
    hk₀ hk₁ hk₂ hκd (le_rfl : |d t|≤|d t|)

/-- Passing finite-horizon dissipation bounds to the entire half-line also
proves output integrability. It cannot be bypassed by a nonintegrable Bochner
integral evaluating to zero. -/
theorem halfline_integral_estimate {V d : ℝ → ℝ} {A B : ℝ}
    (hV : ContinuousOn V (Ici 0)) (hn : ∀ t≥0, 0≤ V t) (hB : 0≤ B)
    (hd : IntegrableOn (fun t => d t^2) (Ioi 0))
    (hbound : ∀ T≥0, (∫ t in (0:ℝ)..T, V t)≤ A+B*(∫ t in (0:ℝ)..T, d t^2)) :
    IntegrableOn V (Ioi 0) ∧ (∫ t in Ioi 0, V t)≤ A+B*(∫ t in Ioi 0, d t^2) := by
  have hfi (T : ℝ) : IntegrableOn V (Ioc 0 T) := by
    exact (hV.mono (fun _ ht => ht.1)).integrableOn_Icc.mono_set Ioc_subset_Icc_self
  have hle (T : ℝ) (hT : 0≤ T) : (∫ t in (0:ℝ)..T, d t^2)≤∫ t in Ioi 0, d t^2 := by
    rw [integral_of_le hT]
    exact setIntegral_mono_set hd (Eventually.of_forall (fun t => sq_nonneg (d t)))
      (Filter.Eventually.of_forall (fun t (ht : t∈Ioc (0:ℝ) T) => ht.1))
  have hVi : IntegrableOn V (Ioi 0) := by
    apply integrableOn_Ioi_of_intervalIntegral_norm_bounded
      (A+B*(∫ t in Ioi 0, d t^2)) 0 hfi tendsto_id
    filter_upwards [eventually_ge_atTop (0:ℝ)] with T hT
    have he : (∫ t in (0:ℝ)..T, ‖V t‖)=(∫ t in (0:ℝ)..T, V t) := by
      apply intervalIntegral.integral_congr
      intro t ht
      rw [uIcc_of_le hT] at ht
      exact Real.norm_of_nonneg (hn t ht.1)
    rw [he]
    exact (hbound T hT).trans (add_le_add (le_refl A) (mul_le_mul_of_nonneg_left (hle T hT) hB))
  refine ⟨hVi,?_⟩
  exact le_of_tendsto_of_tendsto
    (intervalIntegral_tendsto_integral_Ioi 0 hVi tendsto_id)
    (tendsto_const_nhds.add ((intervalIntegral_tendsto_integral_Ioi 0 hd tendsto_id).const_mul B))
    ((eventually_ge_atTop (0:ℝ)).mono (fun T hT => hbound T hT))

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Real Filter MeasureTheory
open scoped NNReal

def filteredCommand (H g β αlo αhi γ vmin uLo uHi : ℝ)
    (h v w desired : ℝ → ℝ) (t : ℝ) :=
  clip (max uLo (barrierLower αhi (v t)))
    (min uHi (barrierUpper H g β αlo (h t) (v t) (w t) γ ((v t+w t)/2-vmin)))
    (desired t)

/-- The robust least-change filter implies the crown comparison along an a.e.
mechanical trajectory on a regular interval. It does not assert existence of
the filtered trajectory or positivity of either leg separately. -/
theorem filtered_mechanical_crown_ae
    {H g β αlo αhi γ vmin uLo uHi T : ℝ}
    {h v w α desired : ℝ → ℝ} {Lv Lw : ℝ≥0}
    (hγ : 0<γ) (hα : αlo≤αhi)
    (hvL : LipschitzOnWith Lv v (Icc 0 T)) (hwL : LipschitzOnWith Lw w (Icc 0 T))
    (hh : ∀ t∈Icc 0 T, 0<h t)
    (hcoef : ∀ t∈Icc 0 T, α t∈Icc αlo αhi)
    (hfeas : ∀ t∈Icc 0 T, max uLo (barrierLower αhi (v t))≤
      min uHi (barrierUpper H g β αlo (h t) (v t) (w t) γ ((v t+w t)/2-vmin)))
    (dv : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt v
      (rise g (α t) (h t) (v t) (w t)
        (filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t)) t)
    (dw : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt w (fall H g β (h t) (v t) (w t)) t) :
    ∀ t∈Icc 0 T,
      ((v 0+w 0)/2-vmin)*exp (-γ*t)≤(v t+w t)/2-vmin ∧
      uLo≤ filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t ∧
      filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t≤ uHi ∧
      0≤ pickup (α t) (v t) (filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t) := by
  let u := filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired
  let B := fun t => (v t+w t)/2-vmin
  have hclip (t : ℝ) (ht : t∈Icc 0 T) := clip_mem (desired:=desired t) (hfeas t ht)
  have hupper (t : ℝ) (ht : t∈Icc 0 T) :
      u t≤ barrierUpper H g β αlo (h t) (v t) (w t) γ (B t) :=
    (hclip t ht).2.trans (min_le_right _ _)
  have hcrown (t : ℝ) (ht : t∈Icc 0 T) :
      0≤(rise g (α t) (h t) (v t) (w t) (u t)+fall H g β (h t) (v t) (w t))/2+γ*B t :=
    ((crown_endpoint_iff (hh t ht) hα).mpr (hupper t ht)) (α t) (hcoef t ht)
  have hsm : ContDiff ℝ 1 (fun p : ℝ×ℝ => -((p.1+p.2)/2-vmin)) := by fun_prop (disch := norm_num)
  obtain ⟨L,hL⟩ := smooth_comp_lipschitzOn hsm (hvL.prodMk hwL)
  have hd : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt (fun s => -B s)
      (-((rise g (α t) (h t) (v t) (w t) (u t)+fall H g β (h t) (v t) (w t))/2)) t := by
    filter_upwards [dv,dw] with t ht hv hmem
    exact ((((ht hmem).add (hv hmem)).div_const 2).sub_const vmin).neg
  have hi := scalar_comparison_ae (κ:=γ/2) (C:=0) (by positivity) hL hd (by
    apply Eventually.of_forall
    intro t ht
    have hh := hcrown t (Ioo_subset_Icc_self ht)
    dsimp [B] at hh ⊢
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith)
  intro t ht
  refine ⟨?_,(le_max_left _ _).trans (hclip t ht).1,
    (hclip t ht).2.trans (min_le_left _ _),?_⟩
  · have hb := hi t ht
    dsimp [envelope] at hb
    have heq : -2*(γ/2)*t= -γ*t := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> ring
    rw [heq] at hb
    simp only [zero_div,zero_mul,add_zero] at hb
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith
  · exact ((pickup_endpoint_iff hα).mpr ((le_max_right _ _).trans (hclip t ht).1))
      (α t) (hcoef t ht)

theorem filtered_command_least_change
    {H g β αlo αhi γ vmin uLo uHi t : ℝ} {h v w desired : ℝ → ℝ}
    (hfeas : max uLo (barrierLower αhi (v t))≤
      min uHi (barrierUpper H g β αlo (h t) (v t) (w t) γ ((v t+w t)/2-vmin)))
    {u : ℝ} (hu : uLo≤ u ∧ u≤ uHi ∧ barrierLower αhi (v t)≤ u ∧
      u≤ barrierUpper H g β αlo (h t) (v t) (w t) γ ((v t+w t)/2-vmin)) :
    (filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t-desired t)^2≤
      (u-desired t)^2 :=
  clip_nearest hfeas ⟨max_le hu.1 hu.2.2.1,le_min hu.2.1 hu.2.2.2⟩

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Real MeasureTheory Filter
open scoped NNReal

def fallingRateBound (H g β hlo shi whi : ℝ) := g+(shi^2+β*whi^2)/(H+hlo)
def risingRateBound (Mw A κd Gmax cz dbar : ℝ) := Mw+2*A+κd*Gmax^2*cz+Gmax*dbar

theorem falling_rate_bound {H g β h v w hlo shi whi : ℝ}
    (hg : 0≤ g) (hb : 0≤β) (hD : 0<H+hlo) (hh : hlo≤ h)
    (hs : |(v+w)/2|≤ shi) (hw : |w|≤ whi) :
    |fall H g β h v w|≤ fallingRateBound H g β hlo shi whi := by
  have hDp : 0<H+h := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hsq : crownSq v w≤ shi^2 := by
    dsimp [crownSq]
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [sq_le_sq₀ (abs_nonneg ((v+w)/2)) ((abs_nonneg _).trans hs) |>.mpr hs,
      sq_abs ((v+w)/2)]
  have hwq : w^2≤ whi^2 := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [sq_le_sq₀ (abs_nonneg w) ((abs_nonneg _).trans hw) |>.mpr hw,sq_abs w]
  have hnum : |-crownSq v w+β*w^2|≤ shi^2+β*whi^2 := by
    have h := abs_add_le (-crownSq v w) (β*w^2)
    have hcn : 0≤ crownSq v w := by dsimp [crownSq]; positivity
    rw [abs_neg,abs_of_nonneg hcn,abs_of_nonneg (mul_nonneg hb (sq_nonneg w))] at h
    have hm := mul_le_mul_of_nonneg_left hwq hb
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hdiv : |(-crownSq v w+β*w^2)/(H+h)|≤(shi^2+β*whi^2)/(H+hlo) := by
    rw [abs_div,abs_of_pos hDp]
    exact (div_le_div_of_nonneg_right hnum hDp.le).trans
      (div_le_div_of_nonneg_left (by positivity) hD (by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith))
  have h := abs_add_le g ((-crownSq v w+β*w^2)/(H+h))
  rw [abs_of_nonneg hg] at h
  exact h.trans (add_le_add (le_refl g) hdiv)

theorem rising_rate_bound {H g α β h v w A κd z d Mw Amax Gmax cz dbar : ℝ}
    (hh : h≠0) (hH : H+h≠0) (hκd : 0≤κd)
    (hw : |fall H g β h v w|≤ Mw) (hA : |A|≤ Amax)
    (hG : |v^2/h|≤ Gmax) (hz : |z|≤ cz) (hd : |d|≤ dbar) :
    |rise g (α+d) h v w (robustInput H g α β h v w A κd z)|≤
      risingRateBound Mw Amax κd Gmax cz dbar := by
  have hid := robust_acceleration H g α β h v w A κd z d hh hH
  have heq : rise g (α+d) h v w (robustInput H g α β h v w A κd z)=
      fall H g β h v w+2*A-κd*(v^2/h)^2*z+(v^2/h)*d := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hG0 : 0≤ Gmax := (abs_nonneg _).trans hG
  have hz0 : 0≤ cz := (abs_nonneg _).trans hz
  have hGq : (v^2/h)^2≤ Gmax^2 := by
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [sq_le_sq₀ (abs_nonneg (v^2/h)) hG0 |>.mpr hG,sq_abs (v^2/h)]
  have hz' := mul_le_mul (mul_le_mul_of_nonneg_left hGq hκd) hz (abs_nonneg z) (by positivity : 0≤κd*Gmax^2)
  have hd' := mul_le_mul hG hd (abs_nonneg d) hG0
  have h₁ := abs_add_le (fall H g β h v w) (2*A)
  have h₂ := abs_sub (fall H g β h v w+2*A) (κd*(v^2/h)^2*z)
  have h₃ := abs_add_le (fall H g β h v w+2*A-κd*(v^2/h)^2*z) ((v^2/h)*d)
  simp only [abs_mul,abs_of_nonneg hκd,abs_of_nonneg (sq_nonneg (v^2/h)),
    abs_of_pos (by norm_num : (0:ℝ)<2)] at h₁ h₂ h₃
  rw [heq]
  dsimp [risingRateBound]
  (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith

/-- The product norm is exactly the sup norm used in the paper. -/
theorem mechanical_sup_norm_bound {h' v' w' Q Mw Mv : ℝ}
    (hh : |h'|≤ Q) (hv : |v'|≤ Mv) (hw : |w'|≤ Mw) :
    ‖(h',v',w')‖ ≤ max Q (max Mw Mv) := by
  rw [Prod.norm_def,Prod.norm_def,Real.norm_eq_abs,Real.norm_eq_abs,Real.norm_eq_abs]
  exact max_le (hh.trans (le_max_left _ _))
    (max_le (hv.trans ((le_max_right Mw Mv).trans (le_max_right Q _)))
      (hw.trans ((le_max_left Mw Mv).trans (le_max_right Q _))))

/-- The displayed M bounds the actual closed-loop mechanical vector, including
both uncertainty and additional damping. -/
theorem mechanical_explicit_bound
    {H g α β h v w A κd z d hlo shi vhi whi Q Amax cz dbar : ℝ}
    (hg : 0≤ g) (hb : 0≤β) (hhlo : 0<hlo) (hD : 0<H+hlo) (hh : hlo≤ h)
    (hκd : 0≤κd) (hq : |heightRate v w|≤ Q) (hs : |(v+w)/2|≤ shi)
    (hv : |v|≤ vhi) (hw : |w|≤ whi) (hA : |A|≤ Amax) (hz : |z|≤ cz) (hd : |d|≤ dbar) :
    let Mw := fallingRateBound H g β hlo shi whi
    let Mv := risingRateBound Mw Amax κd (vhi^2/hlo) cz dbar
    ‖(heightRate v w,rise g (α+d) h v w (robustInput H g α β h v w A κd z),
      fall H g β h v w)‖ ≤ max Q (max Mw Mv) := by
  have hp : 0<h := hhlo.trans_le hh
  have hHp : 0<H+h := by (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> linarith
  have hvsq : v^2≤ vhi^2 := by
    (try dsimp only [Pi.neg_apply,Pi.sub_apply,Pi.add_apply,Pi.mul_apply,Pi.pow_apply] at *) <;> nlinarith [sq_le_sq₀ (abs_nonneg v) ((abs_nonneg v).trans hv) |>.mpr hv,sq_abs v]
  have hG : |v^2/h|≤ vhi^2/hlo := by
    rw [abs_of_nonneg (div_nonneg (sq_nonneg v) hp.le)]
    exact (div_le_div_of_nonneg_right hvsq hp.le).trans
      (div_le_div_of_nonneg_left (sq_nonneg _) hhlo hh)
  have hfw := falling_rate_bound hg hb hD hh hs hw
  exact mechanical_sup_norm_bound hq
    (rising_rate_bound hp.ne' hHp.ne' hκd hfw hA hG hz hd) hfw

/-- An a.e. derivative bound sharpens any prior local Lipschitz constant to M.
This is the integral justification of the paper's time-Lipschitz estimate. -/
theorem time_lipschitz_of_ae_bound {f : ℝ → ℝ} {L M : ℝ≥0} {a b : ℝ}
    (hf : LipschitzOnWith L f (Icc a b))
    (hb : ∀ᵐ t ∂volume, t∈Ioo a b → |deriv f t|≤ M) :
    LipschitzOnWith M f (Icc a b) := by
  apply LipschitzOnWith.of_dist_le_mul
  intro s hs t ht
  wlog hst : s≤ t generalizing s t
  · rw [dist_comm (f s),dist_comm s]
    exact this t ht s hs (le_of_not_ge hst)
  have hsub : Icc s t⊆Icc a b := Icc_subset_Icc hs.1 ht.2
  obtain ⟨hi,hFTC⟩ := lipschitzOn_integral_deriv hst (hf.mono hsub)
  have hne : ∀ᵐ u ∂volume, u≠t := by simp [ae_iff,measure_singleton]
  have hnorm : ‖∫ u in s..t, deriv f u‖≤(M:ℝ)*(t-s) := by
    rw [←abs_of_nonneg (sub_nonneg.mpr hst)]
    apply intervalIntegral.norm_integral_le_of_norm_le_const_ae
    filter_upwards [hb,hne] with u hu hnt hmem
    rw [uIoc_of_le hst] at hmem
    exact hu ⟨hs.1.trans_lt hmem.1,(lt_of_le_of_ne hmem.2 hnt).trans_le ht.2⟩
  rw [hFTC] at hnorm
  simpa [dist_eq_norm,Real.norm_eq_abs,abs_sub_comm (f s),abs_of_nonpos (sub_nonpos.mpr hst),
    neg_sub] using hnorm

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Real MeasureTheory Filter
open scoped NNReal

theorem GlobalTrackingData.measurable_energy_dissipation (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) {x : ℝ → MechanicalState}
    (hh : ∀ t≥0, 0<(x t).1)
    (hxD : ∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) :
    ∀ᵐ t ∂volume, 0≤ t →
      deriv (fun s => c.stateEnergy s (x s)) t≤
        -2*c.κ*c.stateEnergy t (x t)+d t^2/(8*c.κd) := by
  let h := fun t => (x t).1
  let v := fun t => (x t).2.1
  let w := fun t => (x t).2.2
  filter_upwards [hxD] with t hdt ht
  have dh : HasDerivAt h (heightRate (v t) (w t)) t := by
    simpa [h,v,w,measurableField,jointField] using! hasFDerivAt_fst.comp_hasDerivAt t (hdt ht)
  have dv : HasDerivAt v (rise c.g (c.α+d t) (h t) (v t) (w t)
      (requestedInput c.H c.g c.α c.β c.k₀ c.k₁ c.k₂ c.κd h v w c.r c.r₁ c.r₂ t)) t := by
    simpa [h,v,w,measurableField,measurableParameters,jointField,parameters,max_eq_right ht,
      requestedInput,heightError,velocityError] using!
      hasFDerivAt_fst.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t (hdt ht))
  have dw : HasDerivAt w (fall c.H c.g c.β (h t) (v t) (w t)) t := by
    simpa [h,v,w,measurableField,jointField] using!
      hasFDerivAt_snd.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t (hdt ht))
  obtain ⟨he,hz⟩ := closed_loop_error_equations (hh t ht).ne'
    (add_pos c.H_pos (hh t ht)).ne' dh dv dw (c.dr t ht) (c.dr₁ t ht)
  have hV := energy_hasDerivAt_errors he hz
  have heq : (fun s => c.stateEnergy s (x s))=
      fun s => errorEnergy c.k₀ (heightError h c.r s) (velocityError c.k₁ h v w c.r c.r₁ s) := rfl
  rw [heq,hV.deriv]
  simpa only [sq_abs] using! robust_decay_uniform
    (e:=heightError h c.r t) (z:=velocityError c.k₁ h v w c.r c.r₁ t) (G:=(v t)^2/h t)
    c.k₀_pos.le c.κ_le_k₁ c.κ_le_k₂ hκd (le_rfl : |d t|≤|d t|)

theorem GlobalTrackingData.measurable_energy_integral (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) {x : ℝ → MechanicalState} {K : ℝ≥0}
    (hxL : LipschitzWith K x) (hh : ∀ t≥0, 0<(x t).1)
    (hxD : ∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t)
    {T : ℝ} (hT : 0≤ T) (hd : IntervalIntegrable (fun t => d t^2) volume 0 T) :
    (∫ t in (0:ℝ)..T, 2*c.stateEnergy t (x t))≤
      c.stateEnergy 0 (x 0)/c.κ+(1/(8*c.κ*c.κd))*(∫ t in (0:ℝ)..T, d t^2) := by
  obtain ⟨Le,Lz,he,hz⟩ := c.errors_lipschitz hxL T
  have hsm : ContDiff ℝ 1 (fun p : ℝ×ℝ => errorEnergy c.k₀ p.1 p.2) := by
    unfold errorEnergy
    fun_prop (disch := norm_num)
  obtain ⟨L,hL⟩ := smooth_comp_lipschitzOn hsm (he.prodMk hz)
  exact weighted_integral_estimate_ae hT c.κ_pos hκd hL hd
    ((c.measurable_energy_dissipation hκd hh hxD).mono (fun t ht hmem => ht hmem.1.le))
    (energy_nonneg c.k₀_pos.le _ _)

/-- A global physical trajectory is constructed for the finite-energy bounded
measurable disturbance, and its entire weighted output energy is finite. -/
theorem GlobalTrackingData.exists_global_L2_tracking (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : AEMeasurable d volume)
    (hdb : ∀ t, |d t|≤ c.dbar) (hd : IntegrableOn (fun t => d t^2) (Ioi 0)) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      IntegrableOn (fun t => 2*c.stateEnergy t (x t)) (Ioi 0) ∧
      (∫ t in Ioi 0, 2*c.stateEnergy t (x t))≤
        c.stateEnergy 0 c.x₀/c.κ+(1/(8*c.κ*c.κd))*(∫ t in Ioi 0, d t^2) := by
  obtain ⟨x,K,hxL,hx₀,hxD,hbox,hE⟩ := c.exists_global_aemeasurable_tracking hκd hdm hdb
  have hh (t : ℝ) (ht : 0≤ t) : 0<(x t).1 :=
    c.height_positive.trans_le (hbox t ht).1.1
  have hcont : ContinuousOn (fun t => 2*c.stateEnergy t (x t)) (Ici 0) := by
    have hr : ContinuousOn c.r (Ici 0) := fun t ht => (c.dr t ht).continuousAt.continuousWithinAt
    have hr₁ : ContinuousOn c.r₁ (Ici 0) := fun t ht => (c.dr₁ t ht).continuousAt.continuousWithinAt
    have hc := hxL.continuous.continuousOn (s:=Ici (0:ℝ))
    unfold stateEnergy errorEnergy
    fun_prop
  have hbound (T : ℝ) (hT : 0≤ T) := c.measurable_energy_integral hκd hxL hh hxD hT
    ((intervalIntegrable_iff_integrableOn_Ioc_of_le hT).mpr (hd.mono_set Ioc_subset_Ioi_self))
  have hglobal := halfline_integral_estimate hcont
    (fun t _ => mul_nonneg (by norm_num) (energy_nonneg c.k₀_pos.le _ _))
    (div_nonneg zero_le_one (mul_nonneg (mul_nonneg (by norm_num) c.κ_pos.le) hκd.le))
    hd hbound
  exact ⟨x,K,hxL,hx₀,hxD,hbox,hglobal.1,by simpa [hx₀] using! hglobal.2⟩

/-- The half-line square-integral estimate is the usual L² norm gain. Both
signals are proved members of `MemLp 2`, so no nonintegrable zero-integral
convention can make this assertion vacuous. -/
theorem weighted_L2_gain {V d : ℝ → ℝ} {μ : Measure ℝ} {B : ℝ}
    (hV : AEStronglyMeasurable V μ) (hd : AEStronglyMeasurable d μ)
    (hn : ∀ᵐ t ∂μ, 0≤ V t) (hVi : Integrable V μ)
    (hdi : Integrable (fun t => d t^2) μ) (hB : 0≤ B)
    (hbound : (∫ t, V t ∂μ)≤ B*(∫ t, d t^2 ∂μ)) :
    MemLp (fun t => sqrt (V t)) 2 μ ∧ MemLp d 2 μ ∧
      sqrt (∫ t, (sqrt (V t))^2 ∂μ)≤ sqrt B*sqrt (∫ t, d t^2 ∂μ) := by
  have heq : (fun t => (sqrt (V t))^2)=ᵐ[μ] V := hn.mono (fun t ht => sq_sqrt ht)
  have hsq : Integrable (fun t => (sqrt (V t))^2) μ := hVi.congr heq.symm
  refine ⟨(memLp_two_iff_integrable_sq (Real.continuous_sqrt.comp_aestronglyMeasurable hV)).mpr hsq,
    (memLp_two_iff_integrable_sq hd).mpr hdi,?_⟩
  rw [integral_congr_ae heq,←sqrt_mul hB]
  exact sqrt_le_sqrt hbound

/-- Zero-initial-error L² gain for the actual globally constructed physical
trajectory, with the exact paper constant. -/
theorem GlobalTrackingData.exists_global_L2_gain (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : AEMeasurable d volume)
    (hdb : ∀ t, |d t|≤ c.dbar) (hd : IntegrableOn (fun t => d t^2) (Ioi 0))
    (hzero : c.stateEnergy 0 c.x₀=0) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      MemLp (fun t => sqrt (2*c.stateEnergy t (x t))) 2 (volume.restrict (Ioi 0)) ∧
      MemLp d 2 (volume.restrict (Ioi 0)) ∧
      sqrt (∫ t in Ioi 0, (sqrt (2*c.stateEnergy t (x t)))^2)≤
        sqrt (1/(8*c.κ*c.κd))*sqrt (∫ t in Ioi 0, d t^2) := by
  obtain ⟨x,K,hL,h₀,hD,hbox,hVi,hbound⟩ := c.exists_global_L2_tracking hκd hdm hdb hd
  have hn : ∀ᵐ t ∂(volume.restrict (Ioi 0)), 0≤2*c.stateEnergy t (x t) :=
    Eventually.of_forall (fun _ => mul_nonneg (by norm_num) (energy_nonneg c.k₀_pos.le _ _))
  have hB : 0≤1/(8*c.κ*c.κd) :=
    div_nonneg zero_le_one (mul_nonneg (mul_nonneg (by norm_num) c.κ_pos.le) hκd.le)
  have hb : (∫ t in Ioi 0, 2*c.stateEnergy t (x t))≤
      (1/(8*c.κ*c.κd))*(∫ t in Ioi 0, d t^2) := by simpa [hzero] using! hbound
  exact ⟨x,K,hL,h₀,hD,hbox,weighted_L2_gain hVi.aestronglyMeasurable
    hdm.aestronglyMeasurable.restrict hn hVi hd hB hb⟩

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Filter MeasureTheory Function Metric
open scoped NNReal Topology

/-- Uniqueness of integral solutions does not assume a Lipschitz trajectory.
The bounded integral equation itself supplies the required regularity. -/
theorem IntegralPicard.continuous_integral_unique
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    (v : IntegralPicard E) {x y : ℝ → E} (hx : Continuous x) (hy : Continuous y)
    (hxi : ∀ t∈Icc v.tMin v.tMax, x t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (x s))
    (hyi : ∀ t∈Icc v.tMin v.tMax, y t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (y s)) :
    ∀ t∈Icc v.tMin v.tMax, x t=y t := by
  have mk (z : ℝ → E) (hz : Continuous z)
      (hi : ∀ t∈Icc v.tMin v.tMax, z t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (z s)) :
      ∃ f : v.FunSpace, f.next=f ∧ ∀ t : Icc v.tMin v.tMax, f t=z t := by
    have hInt (a b : ℝ) : IntervalIntegrable (fun s => v s (z s)) volume a b := by
      rw [intervalIntegrable_iff]
      exact Measure.integrableOn_of_bounded measure_Ioc_lt_top.ne
        (v.measurable_curve z hz) (Eventually.of_forall (fun s => v.bound_all s (z s)))
    let f : v.FunSpace := {
      toFun := fun t => z t
      map_t₀' := by simpa using! hi v.t₀ v.t₀.2
      lipschitz' := LipschitzWith.of_dist_le_mul (fun a b => by
        rw [hi a a.2, hi b b.2, dist_add_left, dist_eq_norm,
          intervalIntegral.integral_interval_sub_left (hInt _ _) (hInt _ _)]
        exact intervalIntegral.norm_integral_le_of_norm_le_const
          (fun s _ => v.bound_all s (z s))) }
    refine ⟨f,?_,fun _ => rfl⟩
    apply IntegralPicard.FunSpace.toContinuousMap.injective
    apply ContinuousMap.ext
    intro t
    change v.x₀+∫ s in (v.t₀:ℝ)..(t:ℝ), v s (z (v.proj s))=z t
    rw [hi t t.2]
    congr 1
    apply intervalIntegral.integral_congr
    intro s hs
    have hmem : s∈Icc v.tMin v.tMax := (uIcc_subset_Icc v.t₀.2 t.2) hs
    dsimp only
    rw [v.proj_of_mem hmem]
  obtain ⟨f,hf,hfx⟩ := mk x hx hxi
  obtain ⟨g,hg,hgy⟩ := mk y hy hyi
  obtain ⟨n,K,hK⟩ := v.exists_contracting_iterate
  have hfg : f=g := hK.fixedPoint_unique' (IsFixedPt.iterate hf n) (IsFixedPt.iterate hg n)
  intro t ht
  rw [←hfx ⟨t,ht⟩,←hgy ⟨t,ht⟩,hfg]

/-- The actual projected mechanical field supplies bounded measurable Picard
 data uniformly on every finite interval. -/
theorem GlobalTrackingData.measurable_picard_data (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hd : Measurable d) (hb : ∀ t, |d t|≤ c.dbar) {T : ℝ} (hT : 0≤ T) :
    ∃ v : IntegralPicard MechanicalState,
      v.tMin=0 ∧ v.tMax=T ∧ (v.t₀:ℝ)=0 ∧ v.x₀=c.x₀ ∧
      ∀ t x, v t x=c.measurableField d t (c.project x) := by
  obtain ⟨L,N,hL,hN⟩ := c.joint_bounds
  let F := fun t x => c.measurableField d t (c.project x)
  have hfl : ∀ t, LipschitzWith L (F t) := by
    intro t
    have hh := hL.comp
      ((LipschitzWith.prodMk_left (c.measurableParameters d t)).comp c.project_lipschitz).lipschitzOnWith (s:=univ)
      (fun x _ => ⟨c.measurable_parameters_mem hb t,c.project_mem x⟩)
    simpa [F,GlobalTrackingData.measurableField,lipschitzOnWith_univ] using! hh
  have hpm : Measurable (c.measurableParameters d) :=
    c.parameters_continuous.fst.measurable.prodMk
      (c.parameters_continuous.snd.fst.measurable.prodMk
        (c.parameters_continuous.snd.snd.fst.measurable.prodMk hd))
  have hfm : ∀ f : ℝ → MechanicalState, Continuous f →
      AEStronglyMeasurable (fun t => F t (f t)) volume := by
    intro f hf
    let y (t : ℝ) : c.parameterBox ×ˢ c.outerBox :=
      ⟨(c.measurableParameters d t,c.project (f t)),c.measurable_parameters_mem hb t,c.project_mem _⟩
    have hy : Measurable y := (hpm.prodMk (c.project_lipschitz.continuous.comp hf).measurable).subtype_mk
    exact (hL.continuousOn.restrict.measurable.comp hy).aestronglyMeasurable
  let v : IntegralPicard MechanicalState := {
    toFun := F
    tMin := 0
    tMax := T
    t₀ := ⟨0,le_rfl,hT⟩
    x₀ := c.x₀
    C := ⟨max N 0,le_max_right _ _⟩
    L := L
    lipschitz_all := hfl
    measurable_curve := hfm
    bound_all := fun t x => (hN _ ⟨c.measurable_parameters_mem hb t,c.project_mem x⟩).trans
      (le_max_left _ _) }
  exact ⟨v,rfl,rfl,rfl,rfl,fun _ _ => rfl⟩

/-- A globally constructed physical solution is unique among all continuous
integral solutions of the ORIGINAL field. No safe-box, Lipschitz, or existence
hypothesis is imposed on the competing solution. This is the integral
Caratheodory formulation; the AC/a.e. equivalence is a separate FTC bridge. -/
theorem GlobalTrackingData.exists_unique_global_integral (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hd : Measurable d) (hb : ∀ t, |d t|≤ c.dbar) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      (∀ t≥0, x t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (x s)) ∧
      ∀ y : ℝ → MechanicalState, Continuous y →
        (∀ t≥0, y t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (y s)) →
        ∀ t≥0, y t=x t := by
  obtain ⟨x,K,ε,hε,hxL,hx₀,hxI,hxD,hlocal,hlocalD⟩ := c.exists_measurable_local hd hb
  have hstay := no_exit_of_prefix_bound hxL.continuous
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    (hx₀ ▸ c.safeBox_interior c.initial_mem) (fun T hT hbox =>
      c.measurable_prefix_bound hκd hb hxL hT hx₀ hbox hxD)
  have hxi (t : ℝ) (ht : 0≤ t) : x t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (x s) := by
    rw [hxI t]
    congr 1
    apply intervalIntegral.integral_congr
    intro s hs
    rw [uIcc_of_le ht] at hs
    dsimp only
    rw [c.project_eq (x s) (interior_subset (c.safeBox_interior (hstay s hs.1)))]
  refine ⟨x,K,hxL,hx₀,hstay,hxi,?_⟩
  intro y hy hyi
  have hprefix (T : ℝ) (hT : 0≤ T) (hyB : ∀ t∈Icc 0 T, y t∈c.outerBox) :
      ∀ t∈Icc 0 T, y t=x t := by
    obtain ⟨v,hmin,hmax,hzero,hinit,hfield⟩ := c.measurable_picard_data hd hb hT
    have hi (t : ℝ) (ht : t∈Icc v.tMin v.tMax) :
        y t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (y s) := by
      rw [hmin,hmax] at ht
      rw [hinit,hzero,hyi t ht.1]
      congr 1
      apply intervalIntegral.integral_congr
      intro s hs
      rw [uIcc_of_le ht.1] at hs
      dsimp only
      rw [hfield,c.project_eq (y s) (hyB s ⟨hs.1,hs.2.trans ht.2⟩)]
    have hj (t : ℝ) (ht : t∈Icc v.tMin v.tMax) :
        x t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (x s) := by
      simpa only [hinit,hzero,hfield] using! hxI t
    simpa only [hmin,hmax] using! v.continuous_integral_unique hy hxL.continuous hi hj
  have hy₀ : y 0=c.x₀ := by simpa using! hyi 0 le_rfl
  have hystay := no_exit_of_prefix_bound hy
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    (hy₀ ▸ c.safeBox_interior c.initial_mem) (fun T hT hbox => by
      rw [hprefix T hT hbox T ⟨hT,le_rfl⟩]; exact hstay T hT)
  intro t ht
  exact hprefix t ht (fun s hs => interior_subset (c.safeBox_interior (hystay s hs.1))) t ⟨ht,le_rfl⟩

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Filter MeasureTheory Function
open scoped Topology NNReal

/-- Lipschitz composition preserves genuine metric absolute continuity. -/
theorem ac_lipschitz_comp {E F : Type*} [PseudoMetricSpace E] [PseudoMetricSpace F]
    {f : ℝ → E} {g : E → F} {a b : ℝ} {K : ℝ≥0}
    (hf : AbsolutelyContinuousOnInterval f a b) (hg : LipschitzWith K g) :
    AbsolutelyContinuousOnInterval (g ∘ f) a b := by
  apply squeeze_zero (fun _ => Finset.sum_nonneg (fun _ _ => dist_nonneg))
    (fun _ => ?_) (by simpa using Tendsto.const_mul (K:ℝ) hf)
  rw [Finset.mul_sum]
  exact Finset.sum_le_sum (fun i _ => hg.dist_le_mul _ _)

/-- Absolute continuity is invariant under equality on the interval. -/
theorem ac_congr {E : Type*} [PseudoMetricSpace E] {f g : ℝ → E} {a b : ℝ}
    (hf : AbsolutelyContinuousOnInterval f a b) (he : EqOn g f (uIcc a b)) :
    AbsolutelyContinuousOnInterval g a b := by
  apply (absolutelyContinuousOnInterval_iff g a b).mpr
  intro ε hε
  obtain ⟨δ,hδ,hfδ⟩ := (absolutelyContinuousOnInterval_iff f a b).mp hf ε hε
  refine ⟨δ,hδ,?_⟩
  intro E hE hlen
  have hends := hE.1
  have heq : (∑ i ∈ Finset.range E.1, dist (g (E.2 i).1) (g (E.2 i).2)) =
      ∑ i ∈ Finset.range E.1, dist (f (E.2 i).1) (f (E.2 i).2) := by
    apply Finset.sum_congr rfl
    intro i hi
    rw [he (hends i hi).1,he (hends i hi).2]
  rw [heq]
  exact hfδ E hE hlen

/-- Product absolute continuity, using the product metric. -/
theorem ac_prod {E F : Type*} [PseudoMetricSpace E] [PseudoMetricSpace F]
    {f : ℝ → E} {g : ℝ → F} {a b : ℝ}
    (hf : AbsolutelyContinuousOnInterval f a b) (hg : AbsolutelyContinuousOnInterval g a b) :
    AbsolutelyContinuousOnInterval (fun t => (f t,g t)) a b := by
  apply squeeze_zero (fun _ => Finset.sum_nonneg (fun _ _ => dist_nonneg))
    (fun _ => ?_) (by simpa using Tendsto.add hf hg)
  rw [←Finset.sum_add_distrib]
  exact Finset.sum_le_sum (fun i _ => by
    rw [Prod.dist_eq]
    exact max_le_add_of_nonneg (dist_nonneg) (dist_nonneg))

/-- Reverse FTC for every real absolutely continuous curve, with its a.e.
derivative supplied by an equation. No Lipschitz regularity is assumed. -/
theorem ac_integral_eq_sub {f g : ℝ → ℝ} {a b : ℝ}
    (hf : AbsolutelyContinuousOnInterval f a b)
    (hd : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt f (g t) t) :
    IntervalIntegrable g volume a b ∧ (∫ t in a..b, g t)=f b-f a := by
  have he : deriv f =ᵐ[volume.restrict (uIoc a b)] g := by
    filter_upwards [ae_restrict_of_ae hd,ae_restrict_mem measurableSet_uIoc] with t ht hmem
    exact (ht (uIoc_subset_uIcc hmem)).deriv
  refine ⟨hf.intervalIntegrable_deriv.congr_ae he,?_⟩
  rw [←intervalIntegral.integral_congr_ae_restrict he,hf.integral_deriv_eq_sub]

/-- The complete scalar Caratheodory equivalence on a compact interval. -/
theorem ac_ae_iff_integral {f g : ℝ → ℝ} {a b : ℝ} (hab : a≤ b) :
    (AbsolutelyContinuousOnInterval f a b ∧
      ∀ᵐ t ∂volume, t∈Icc a b → HasDerivAt f (g t) t) ↔
    (IntervalIntegrable g volume a b ∧
      ∀ t∈Icc a b, f t=f a+∫ s in a..t, g s) := by
  constructor
  · rintro ⟨hf,hd⟩
    have hd' : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt f (g t) t := by
      simpa only [uIcc_of_le hab] using hd
    refine ⟨(ac_integral_eq_sub hf hd').1,?_⟩
    intro t ht
    have hsub : uIcc a t ⊆ uIcc a b := by
      rw [uIcc_of_le ht.1,uIcc_of_le hab]
      exact Icc_subset_Icc le_rfl ht.2
    have hd'' : ∀ᵐ s ∂volume, s∈uIcc a t → HasDerivAt f (g s) s := by
      filter_upwards [hd'] with s hs hmem using hs (hsub hmem)
    have hi := (ac_integral_eq_sub (hf.mono hsub) hd'').2
    linarith
  · rintro ⟨hg,he⟩
    have hprim := hg.absolutelyContinuousOnInterval_intervalIntegral (c:=a) (by simp)
    have hc : AbsolutelyContinuousOnInterval (fun _ : ℝ => f a) a b :=
      (LipschitzWith.const (f a)).lipschitzOnWith.absolutelyContinuousOnInterval
    refine ⟨ac_congr (hc.fun_add hprim) (by intro t ht; exact he t (by simpa only [uIcc_of_le hab] using ht)),?_⟩
    have hne (c : ℝ) : ∀ᵐ t ∂volume, t≠c := by
      simp [ae_iff, measure_singleton]
    filter_upwards [hg.ae_hasDerivAt_integral,hne a,hne b] with t ht hta htb hmem
    have hto : t∈Ioo a b := ⟨lt_of_le_of_ne hmem.1 (Ne.symm hta),lt_of_le_of_ne hmem.2 htb⟩
    have hp := (ht (by simpa [uIcc_of_le hab] using hmem) a (by simp)).const_add (f a)
    apply hp.congr_of_eventuallyEq
    filter_upwards [Ioo_mem_nhds hto.1 hto.2] with s hs
    exact he s (Ioo_subset_Icc_self hs)

/-- Reverse FTC in the three mechanical coordinates. This is an actual vector
integral, not three unrelated scalar conclusions. -/
theorem ac_state_integral_eq_sub {f g : ℝ → ℝ × (ℝ × ℝ)} {a b : ℝ}
    (hf : AbsolutelyContinuousOnInterval f a b)
    (hd : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt f (g t) t) :
    IntervalIntegrable g volume a b ∧ (∫ t in a..b, g t)=f b-f a := by
  have h₁ := ac_lipschitz_comp hf LipschitzWith.prod_fst
  have h₂ := ac_lipschitz_comp (ac_lipschitz_comp hf LipschitzWith.prod_snd) LipschitzWith.prod_fst
  have h₃ := ac_lipschitz_comp (ac_lipschitz_comp hf LipschitzWith.prod_snd) LipschitzWith.prod_snd
  have hd₁ : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt (fun s => (f s).1) (g t).1 t := by
    filter_upwards [hd] with t ht hmem
    exact hasFDerivAt_fst.comp_hasDerivAt t (ht hmem)
  have hd₂ : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt (fun s => (f s).2.1) (g t).2.1 t := by
    filter_upwards [hd] with t ht hmem
    exact hasFDerivAt_fst.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t (ht hmem))
  have hd₃ : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt (fun s => (f s).2.2) (g t).2.2 t := by
    filter_upwards [hd] with t ht hmem
    exact hasFDerivAt_snd.comp_hasDerivAt t (hasFDerivAt_snd.comp_hasDerivAt t (ht hmem))
  obtain ⟨hi₁,he₁⟩ := ac_integral_eq_sub h₁ hd₁
  obtain ⟨hi₂,he₂⟩ := ac_integral_eq_sub h₂ hd₂
  obtain ⟨hi₃,he₃⟩ := ac_integral_eq_sub h₃ hd₃
  have hi : IntervalIntegrable g volume a b :=
    ⟨hi₁.1.prodMk (hi₂.1.prodMk hi₃.1),hi₁.2.prodMk (hi₂.2.prodMk hi₃.2)⟩
  refine ⟨hi,?_⟩
  have hp₁ := (ContinuousLinearMap.fst ℝ ℝ (ℝ×ℝ)).intervalIntegral_comp_comm hi
  have hp₂ := ((ContinuousLinearMap.fst ℝ ℝ ℝ).comp
    (ContinuousLinearMap.snd ℝ ℝ (ℝ×ℝ))).intervalIntegral_comp_comm hi
  have hp₃ := ((ContinuousLinearMap.snd ℝ ℝ ℝ).comp
    (ContinuousLinearMap.snd ℝ ℝ (ℝ×ℝ))).intervalIntegral_comp_comm hi
  apply Prod.ext
  · exact hp₁.symm.trans he₁
  · exact Prod.ext (hp₂.symm.trans he₂) (hp₃.symm.trans he₃)

/-- Vector integral primitives are absolutely continuous in the mechanical
state space, including merely integrable right-hand sides. -/
theorem state_integral_ac {g : ℝ → ℝ × (ℝ × ℝ)} {a b : ℝ}
    (hg : IntervalIntegrable g volume a b) :
    AbsolutelyContinuousOnInterval (fun t => ∫ s in a..t, g s) a b := by
  have hi₁ : IntervalIntegrable (fun s => (g s).1) volume a b := ⟨hg.1.fst,hg.2.fst⟩
  have hi₂ : IntervalIntegrable (fun s => (g s).2.1) volume a b := ⟨hg.1.snd.fst,hg.2.snd.fst⟩
  have hi₃ : IntervalIntegrable (fun s => (g s).2.2) volume a b := ⟨hg.1.snd.snd,hg.2.snd.snd⟩
  apply ac_congr (ac_prod
    (hi₁.absolutelyContinuousOnInterval_intervalIntegral (c:=a) (by simp))
    (ac_prod (hi₂.absolutelyContinuousOnInterval_intervalIntegral (c:=a) (by simp))
      (hi₃.absolutelyContinuousOnInterval_intervalIntegral (c:=a) (by simp))))
  intro t ht
  have hit := hg.mono_set (uIcc_subset_uIcc_left ht)
  exact Prod.ext
    ((ContinuousLinearMap.fst ℝ ℝ (ℝ×ℝ)).intervalIntegral_comp_comm hit).symm
    (Prod.ext (((ContinuousLinearMap.fst ℝ ℝ ℝ).comp
      (ContinuousLinearMap.snd ℝ ℝ (ℝ×ℝ))).intervalIntegral_comp_comm hit).symm
      (((ContinuousLinearMap.snd ℝ ℝ ℝ).comp
      (ContinuousLinearMap.snd ℝ ℝ (ℝ×ℝ))).intervalIntegral_comp_comm hit).symm)

/-- The full AC/a.e.-integral equivalence for the mechanical state space.
There is no Lipschitz, continuity-of-the-field, or pre-existing FTC hypothesis. -/
theorem ac_state_ae_iff_integral {f g : ℝ → ℝ × (ℝ × ℝ)} {a b : ℝ} (hab : a≤ b) :
    (AbsolutelyContinuousOnInterval f a b ∧
      ∀ᵐ t ∂volume, t∈Icc a b → HasDerivAt f (g t) t) ↔
    (IntervalIntegrable g volume a b ∧
      ∀ t∈Icc a b, f t=f a+∫ s in a..t, g s) := by
  constructor
  · rintro ⟨hf,hd⟩
    have hd' : ∀ᵐ t ∂volume, t∈uIcc a b → HasDerivAt f (g t) t := by
      simpa only [uIcc_of_le hab] using hd
    refine ⟨(ac_state_integral_eq_sub hf hd').1,?_⟩
    intro t ht
    have hsub : uIcc a t ⊆ uIcc a b := by
      rw [uIcc_of_le ht.1,uIcc_of_le hab]
      exact Icc_subset_Icc le_rfl ht.2
    have hd'' : ∀ᵐ s ∂volume, s∈uIcc a t → HasDerivAt f (g s) s := by
      filter_upwards [hd'] with s hs hmem using hs (hsub hmem)
    rw [(ac_state_integral_eq_sub (hf.mono hsub) hd'').2]
    abel
  · rintro ⟨hg,he⟩
    have hc : AbsolutelyContinuousOnInterval (fun _ : ℝ => f a) a b :=
      (LipschitzWith.const (f a)).lipschitzOnWith.absolutelyContinuousOnInterval
    refine ⟨ac_congr (hc.fun_add (state_integral_ac hg)) ?_,?_⟩
    · intro t ht
      exact he t (by simpa only [uIcc_of_le hab] using ht)
    · have hne (c : ℝ) : ∀ᵐ t ∂volume, t≠c := by simp [ae_iff,measure_singleton]
      filter_upwards [hg.ae_hasDerivAt_integral,hne a,hne b] with t ht hta htb hmem
      have hto : t∈Ioo a b := ⟨lt_of_le_of_ne hmem.1 (Ne.symm hta),lt_of_le_of_ne hmem.2 htb⟩
      have hp := (ht (by simpa [uIcc_of_le hab] using hmem) a (by simp)).const_add (f a)
      apply hp.congr_of_eventuallyEq
      filter_upwards [Ioo_mem_nhds hto.1 hto.2] with s hs
      exact he s (Ioo_subset_Icc_self hs)

/-- A forward locally AC curve has a continuous extension to all real times,
constant before zero. No regularity at negative times is required of the curve. -/
theorem locally_ac_forward_extension {E : Type*} [NormedAddCommGroup E] {f : ℝ → E}
    (hf : ∀ T≥0, AbsolutelyContinuousOnInterval f 0 T) :
    Continuous (fun t => f (max 0 t)) := by
  rw [continuous_iff_continuousAt]
  intro t
  let N : ℝ := max 0 t+1
  have hN : 0≤ N := by dsimp [N]; positivity
  have hfc : ContinuousOn f (Icc 0 N) := by
    simpa only [uIcc_of_le hN] using AbsolutelyContinuousOnInterval.continuousOn (hf N hN)
  have hc : Continuous (fun s => f (projIcc 0 N hN s)) :=
    hfc.comp_continuous (continuous_subtype_val.comp continuous_projIcc)
      (fun s => (projIcc 0 N hN s).property)
  have htN : t<N := by dsimp [N]; linarith [le_max_right (0:ℝ) t]
  apply hc.continuousAt.congr_of_eventuallyEq
  filter_upwards [Iio_mem_nhds htN] with s hs
  by_cases hs0 : s≤0
  · rw [max_eq_left hs0,projIcc_of_le_left hN hs0]
  · have hs0' : 0≤ s := (not_le.mp hs0).le
    rw [max_eq_right hs0',projIcc_of_mem hN ⟨hs0',hs.le⟩]

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Filter MeasureTheory
open scoped NNReal Topology

/-- A forward locally absolutely continuous a.e. mechanical solution satisfies
the integral equation on every finite horizon, with integrability derived. -/
theorem forward_ac_integral {F : ℝ → MechanicalState → MechanicalState}
    {x : ℝ → MechanicalState} {x₀ : MechanicalState} (hx₀ : x 0=x₀)
    (hx : ∀ T≥0, AbsolutelyContinuousOnInterval x 0 T)
    (hd : ∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (F t (x t)) t) :
    ∀ t≥0, IntervalIntegrable (fun s => F s (x s)) volume 0 t ∧
      x t=x₀+∫ s in (0:ℝ)..t, F s (x s) := by
  intro t ht
  have hd' : ∀ᵐ s ∂volume, s∈uIcc 0 t → HasDerivAt x (F s (x s)) s := by
    filter_upwards [hd] with s hs hmem
    rw [uIcc_of_le ht] at hmem
    exact hs hmem.1
  obtain ⟨hi,he⟩ := ac_state_integral_eq_sub (hx t ht) hd'
  refine ⟨hi,?_⟩
  rw [he,hx₀]
  abel

/-- Global physical existence and unrestricted forward Caratheodory uniqueness
for every bounded measurable disturbance. Competing curves need only be locally
absolutely continuous for nonnegative times; no safe-box, Lipschitz, positive
height, or pre-given trajectory hypothesis is imposed on them. -/
theorem GlobalTrackingData.exists_unique_global_caratheodory (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : Measurable d) (hdb : ∀ t, |d t|≤ c.dbar) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ T≥0, AbsolutelyContinuousOnInterval x 0 T) ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      (∀ t≥0, x t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (x s)) ∧
      (∀ t≥0, c.stateEnergy t (x t)≤ c.cap ∧
        c.stateEnergy t (x t)≤ Real.exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-Real.exp (-2*c.κ*t))) ∧
      ∀ y : ℝ → MechanicalState, y 0=c.x₀ →
        (∀ T≥0, AbsolutelyContinuousOnInterval y 0 T) →
        (∀ᵐ t ∂volume, 0≤ t → HasDerivAt y (c.measurableField d t (y t)) t) →
        ∀ t≥0, y t=x t := by
  obtain ⟨u,Ku,huL,hu₀,huB,huI,huUnique⟩ := c.exists_unique_global_integral hκd hdm hdb
  obtain ⟨x,K,hxL,hx₀,hxD,hxB,hxE⟩ := c.exists_global_measurable_tracking hκd hdm hdb
  have hxAC : ∀ T≥0, AbsolutelyContinuousOnInterval x 0 T :=
    fun _ _ => hxL.lipschitzOnWith.absolutelyContinuousOnInterval
  have hxI := forward_ac_integral hx₀ hxAC hxD
  have hxu := huUnique x hxL.continuous (fun t ht => (hxI t ht).2)
  refine ⟨x,K,hxL,hx₀,hxAC,hxD,hxB,fun t ht => (hxI t ht).2,hxE,?_⟩
  intro y hy₀ hyAC hyD
  have hyI := forward_ac_integral hy₀ hyAC hyD
  let yext : ℝ → MechanicalState := fun t => y (max 0 t)
  have hyext : Continuous yext := locally_ac_forward_extension hyAC
  have hext (t : ℝ) (ht : 0≤ t) : yext t=y t := by simp [yext,max_eq_right ht]
  have hyextI (t : ℝ) (ht : 0≤ t) :
      yext t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (yext s) := by
    rw [hext t ht,(hyI t ht).2]
    congr 1
    apply intervalIntegral.integral_congr
    intro s hs
    rw [uIcc_of_le ht] at hs
    dsimp only
    rw [hext s hs.1]
  have hyu := huUnique yext hyext hyextI
  intro t ht
  rw [←hext t ht,hyu t ht,hxu t ht]

/-- The same unrestricted Caratheodory uniqueness for Lebesgue-a.e. measurable
inputs, retaining their original values in the a.e. ODE. -/
theorem GlobalTrackingData.exists_unique_global_aemeasurable_caratheodory (c : GlobalTrackingData)
    {d : ℝ → ℝ} (hκd : 0<c.κd) (hdm : AEMeasurable d volume) (hdb : ∀ t, |d t|≤ c.dbar) :
    ∃ x : ℝ → MechanicalState, ∃ K : ℝ≥0, LipschitzWith K x ∧ x 0=c.x₀ ∧
      (∀ T≥0, AbsolutelyContinuousOnInterval x 0 T) ∧
      (∀ᵐ t ∂volume, 0≤ t → HasDerivAt x (c.measurableField d t (x t)) t) ∧
      (∀ t≥0, x t∈c.safeBox) ∧
      (∀ t≥0, x t=c.x₀+∫ s in (0:ℝ)..t, c.measurableField d s (x s)) ∧
      (∀ t≥0, c.stateEnergy t (x t)≤ c.cap ∧
        c.stateEnergy t (x t)≤ Real.exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-Real.exp (-2*c.κ*t))) ∧
      ∀ y : ℝ → MechanicalState, y 0=c.x₀ →
        (∀ T≥0, AbsolutelyContinuousOnInterval y 0 T) →
        (∀ᵐ t ∂volume, 0≤ t → HasDerivAt y (c.measurableField d t (y t)) t) →
        ∀ t≥0, y t=x t := by
  have hb0 : 0≤ c.dbar := (abs_nonneg (d 0)).trans (hdb 0)
  have horder : -c.dbar≤ c.dbar := by linarith
  let b : ℝ → ℝ := fun t => max (-c.dbar) (min c.dbar (hdm.mk d t))
  have hbm : Measurable b := measurable_const.max (measurable_const.min hdm.measurable_mk)
  have hbb (t : ℝ) : |b t|≤ c.dbar := by
    apply abs_le.mpr
    exact ⟨le_max_left _ _,max_le horder (min_le_left _ _)⟩
  have heq : d =ᵐ[volume] b := by
    filter_upwards [hdm.ae_eq_mk] with t ht
    have hb := abs_le.mp (hdb t)
    simp only [b,← ht,min_eq_right hb.2,max_eq_right hb.1]
  obtain ⟨x,K,hxL,hx₀,hxAC,hxD,hxB,hxI,hxE,hunique⟩ :=
    c.exists_unique_global_caratheodory hκd hbm hbb
  have hxD' : ∀ᵐ t ∂volume, 0≤t → HasDerivAt x (c.measurableField d t (x t)) t := by
    filter_upwards [hxD,heq] with t ht he ht0
    simpa only [measurableField,measurableParameters,←he] using! ht ht0
  have hxI' := forward_ac_integral hx₀ hxAC hxD'
  refine ⟨x,K,hxL,hx₀,hxAC,hxD',hxB,fun t ht => (hxI' t ht).2,hxE,?_⟩
  intro y hy₀ hyAC hyD
  apply hunique y hy₀ hyAC
  filter_upwards [hyD,heq] with t ht he ht0
  simpa only [measurableField,measurableParameters,he] using! ht ht0

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Real Filter MeasureTheory
open scoped NNReal

/-- Scalar comparison for genuine absolutely continuous curves with an a.e.
differential inequality. Integrability and the reverse FTC are derived. -/
theorem scalar_comparison_ac {V V' : ℝ → ℝ} {T κ C : ℝ}
    (hκ : 0<κ) (hV : AbsolutelyContinuousOnInterval V 0 T)
    (hd : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt V (V' t) t)
    (hb : ∀ᵐ t ∂volume, t∈Ioo 0 T → V' t≤ -2*κ*V t+C) :
    ∀ t∈Icc 0 T, V t≤ envelope (V 0) κ C t := by
  by_cases hT : 0≤T
  swap
  · intro t ht
    linarith [ht.1,ht.2]
  let W (t : ℝ) := (V t-C/(2*κ))*exp (2*κ*t)
  let W' (t : ℝ) := (V' t+2*κ*(V t-C/(2*κ)))*exp (2*κ*t)
  have hWAC : AbsolutelyContinuousOnInterval W 0 T := by
    have he : ContDiff ℝ 1 (fun t : ℝ => exp (2*κ*t)) := by fun_prop
    obtain ⟨L,hL⟩ := smooth_comp_lipschitzOn he
      (LipschitzWith.id.lipschitzOnWith : LipschitzOnWith 1 (fun t : ℝ => t) (Icc 0 T))
    exact (hV.fun_sub ((LipschitzWith.const (C/(2*κ))).lipschitzOnWith.absolutelyContinuousOnInterval)).fun_mul
      (by rw [←uIcc_of_le hT] at hL; exact hL.absolutelyContinuousOnInterval)
  have hWd : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt W (W' t) t := by
    filter_upwards [hd] with t ht hmem
    convert! ((ht hmem).sub_const (C/(2*κ))).mul
      (((hasDerivAt_id t).const_mul (2*κ)).exp) using 1 <;> dsimp [W,W'] <;> ring
  have hWn : ∀ᵐ t ∂volume, t∈Ioo 0 T → W' t≤0 := by
    filter_upwards [hb] with t ht hmem
    have heq : 2*κ*(C/(2*κ))=C := by field_simp
    dsimp [W']
    apply mul_nonpos_of_nonpos_of_nonneg _ (exp_pos _).le
    nlinarith [ht hmem]
  intro t ht
  have hsub : Icc (0:ℝ) t ⊆ Icc 0 T := Icc_subset_Icc le_rfl ht.2
  have hsub' : uIcc (0:ℝ) t ⊆ uIcc 0 T := by
    rw [uIcc_of_le ht.1,uIcc_of_le (ht.1.trans ht.2)]
    exact hsub
  have hne (c : ℝ) : ∀ᵐ s ∂volume, s≠c := by simp [ae_iff,measure_singleton]
  have hWd' : ∀ᵐ s ∂volume, s∈uIcc 0 t → HasDerivAt W (W' s) s := by
    filter_upwards [hWd,hne 0,hne t] with s hs hs0 hst hmem
    rw [uIcc_of_le ht.1] at hmem
    exact hs ⟨lt_of_le_of_ne hmem.1 (Ne.symm hs0),(lt_of_le_of_ne hmem.2 hst).trans_le ht.2⟩
  obtain ⟨hi,hFTC⟩ := ac_integral_eq_sub (hWAC.mono hsub') hWd'
  have hint : (∫ s in (0:ℝ)..t, W' s)≤0 := by
    rw [intervalIntegral.integral_of_le ht.1]
    apply integral_nonpos_of_ae
    filter_upwards [ae_restrict_of_ae hWn,ae_restrict_of_ae (hne t),ae_restrict_mem measurableSet_Ioc] with s hs hst hmem
    exact hs ⟨hmem.1,(lt_of_le_of_ne hmem.2 hst).trans_le ht.2⟩
  have hw : W t≤W 0 := by linarith
  change W t≤ W 0 at hw
  dsimp [W] at hw
  simp only [mul_zero,exp_zero,mul_one] at hw
  have hdiv : V t-C/(2*κ) ≤ (V 0-C/(2*κ))/exp (2*κ*t) :=
    (le_div_iff₀ (exp_pos _)).mpr hw
  have heq : envelope (V 0) κ C t = C/(2*κ)+(V 0-C/(2*κ))/exp (2*κ*t) := by
    unfold envelope
    rw [show -2*κ*t=-(2*κ*t) by ring,exp_neg]
    ring
  rw [heq]
  linarith

/-- The feasible mechanical crown filter for arbitrary absolutely continuous
speed curves. This is a trajectory theorem, not filtered-loop existence. -/
theorem filtered_mechanical_crown_ac
    {H g β αlo αhi γ vmin uLo uHi T : ℝ}
    {h v w α desired : ℝ → ℝ}
    (hγ : 0<γ) (hα : αlo≤αhi)
    (hvL : AbsolutelyContinuousOnInterval v 0 T) (hwL : AbsolutelyContinuousOnInterval w 0 T)
    (hh : ∀ t∈Icc 0 T, 0<h t)
    (hcoef : ∀ t∈Icc 0 T, α t∈Icc αlo αhi)
    (hfeas : ∀ t∈Icc 0 T, max uLo (barrierLower αhi (v t))≤
      min uHi (barrierUpper H g β αlo (h t) (v t) (w t) γ ((v t+w t)/2-vmin)))
    (dv : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt v
      (rise g (α t) (h t) (v t) (w t)
        (filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t)) t)
    (dw : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt w (fall H g β (h t) (v t) (w t)) t) :
    ∀ t∈Icc 0 T,
      ((v 0+w 0)/2-vmin)*exp (-γ*t)≤(v t+w t)/2-vmin ∧
      uLo≤ filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t ∧
      filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t≤ uHi ∧
      0≤ pickup (α t) (v t) (filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired t) := by
  let u := filteredCommand H g β αlo αhi γ vmin uLo uHi h v w desired
  let B := fun t => (v t+w t)/2-vmin
  have hclip (t : ℝ) (ht : t∈Icc 0 T) := clip_mem (desired:=desired t) (hfeas t ht)
  have hupper (t : ℝ) (ht : t∈Icc 0 T) :
      u t≤ barrierUpper H g β αlo (h t) (v t) (w t) γ (B t) :=
    (hclip t ht).2.trans (min_le_right _ _)
  have hcrown (t : ℝ) (ht : t∈Icc 0 T) :
      0≤(rise g (α t) (h t) (v t) (w t) (u t)+fall H g β (h t) (v t) (w t))/2+γ*B t :=
    ((crown_endpoint_iff (hh t ht) hα).mpr (hupper t ht)) (α t) (hcoef t ht)
  have hL : AbsolutelyContinuousOnInterval (fun t => -B t) 0 T := by
    have hc := (LipschitzWith.const vmin).lipschitzOnWith.absolutelyContinuousOnInterval (a:=0) (b:=T)
    have hm := AbsolutelyContinuousOnInterval.const_mul (1/2:ℝ) (hvL.fun_add hwL)
    simpa only [B,div_eq_mul_inv,mul_comm,one_mul,Pi.neg_apply] using! (hm.fun_sub hc).neg
  have hd : ∀ᵐ t ∂volume, t∈Ioo 0 T → HasDerivAt (fun s => -B s)
      (-((rise g (α t) (h t) (v t) (w t) (u t)+fall H g β (h t) (v t) (w t))/2)) t := by
    filter_upwards [dv,dw] with t ht hv hmem
    exact ((((ht hmem).add (hv hmem)).div_const 2).sub_const vmin).neg
  have hi := scalar_comparison_ac (κ:=γ/2) (C:=0) (by positivity) hL hd (by
    apply Eventually.of_forall
    intro t ht
    have hh := hcrown t (Ioo_subset_Icc_self ht)
    dsimp [B] at hh ⊢
    linarith)
  intro t ht
  refine ⟨?_,(le_max_left _ _).trans (hclip t ht).1,
    (hclip t ht).2.trans (min_le_left _ _),?_⟩
  · have hb := hi t ht
    dsimp [envelope] at hb
    have heq : -2*(γ/2)*t= -γ*t := by ring
    rw [heq] at hb
    simp only [zero_div,zero_mul,add_zero] at hb
    dsimp [B] at hb
    nlinarith
  · exact ((pickup_endpoint_iff hα).mpr ((le_max_right _ _).trans (hclip t ht).1))
      (α t) (hcoef t ht)

end
end ChainFountain


namespace ChainFountain
noncomputable section
open Set Filter MeasureTheory
open scoped Topology NNReal

/-- Classical solutions from certified data are locally absolutely continuous.
The bound on the original vector field and first-exit safety supply regularity. -/
theorem GlobalTrackingData.classical_forward_ac (c : GlobalTrackingData)
    {x : ℝ → MechanicalState} (hx : x 0 = c.x₀)
    (hd : ∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) :
    ∀ T ≥ 0, AbsolutelyContinuousOnInterval x 0 T := by
  obtain ⟨L,C,hL,hcont,hC⟩ := c.field_bounds
  intro T hT
  have hb := c.classical_safe_on_Icc hT hx (fun t ht => hd t ht.1)
  have hl : LipschitzOnWith ⟨max C 0,le_max_right _ _⟩ x (Icc 0 T) := by
    apply (convex_Icc (0:ℝ) T).lipschitzOnWith_of_nnnorm_hasDerivWithin_le
      (fun t ht => (hd t ht.1).hasDerivWithinAt)
    intro t ht
    exact_mod_cast (hC t (x t) (interior_subset (c.safeBox_interior (hb t ht)))).trans
      (le_max_left C 0)
  rw [← uIcc_of_le hT] at hl
  exact hl.absolutelyContinuousOnInterval

/-- Unrestricted uniqueness of the continuous-data integral equation. The
nominal gain may vanish; the proof uses a safe reference solution, not robust
division by kappa_d and not safety assumed of the competitor. -/
theorem GlobalTrackingData.classical_integral_unique (c : GlobalTrackingData)
    {x y : ℝ → MechanicalState} (hx : Continuous x) (hy : Continuous y)
    (hxb : ∀ t ≥ 0, x t ∈ c.safeBox)
    (hxi : ∀ t ≥ 0, x t = c.x₀ + ∫ s in (0:ℝ)..t, c.field s (x s))
    (hyi : ∀ t ≥ 0, y t = c.x₀ + ∫ s in (0:ℝ)..t, c.field s (y s)) :
    ∀ t ≥ 0, y t = x t := by
  let d : ℝ → ℝ := fun t => c.d (max 0 t)
  have hdm : Measurable d := c.parameters_continuous.snd.snd.snd.measurable
  have hdb : ∀ t, |d t| ≤ c.dbar := fun t => c.disturbance_bound _ (le_max_left _ _)
  have hfield (t : ℝ) (z : MechanicalState) : c.measurableField d t z = c.field t z := rfl
  have hprefix (T : ℝ) (hT : 0 ≤ T) (hyB : ∀ t ∈ Icc 0 T, y t ∈ c.outerBox) :
      ∀ t ∈ Icc 0 T, y t = x t := by
    obtain ⟨v,hmin,hmax,hzero,hinit,hv⟩ := c.measurable_picard_data hdm hdb hT
    have mk (z : ℝ → MechanicalState)
        (hi : ∀ t ≥ 0, z t = c.x₀ + ∫ s in (0:ℝ)..t, c.field s (z s))
        (hb : ∀ t ∈ Icc 0 T, z t ∈ c.outerBox) :
        ∀ t ∈ Icc v.tMin v.tMax, z t = v.x₀ + ∫ s in (v.t₀:ℝ)..t, v s (z s) := by
      intro t ht
      rw [hmin,hmax] at ht
      rw [hinit,hzero,hi t ht.1]
      congr 1
      apply intervalIntegral.integral_congr
      intro s hs
      rw [uIcc_of_le ht.1] at hs
      dsimp only
      rw [hv,c.project_eq (z s) (hb s ⟨hs.1,hs.2.trans ht.2⟩),hfield]
    have hh := v.continuous_integral_unique hy hx (mk y hyi hyB)
      (mk x hxi (fun t ht => interior_subset (c.safeBox_interior (hxb t ht.1))))
    simpa only [hmin,hmax] using hh
  have hy₀ : y 0 = c.x₀ := by simpa using hyi 0 le_rfl
  have hystay := no_exit_of_prefix_bound hy
    (isClosed_Icc.prod (isClosed_Icc.prod isClosed_Icc)) c.safeBox_interior
    (hy₀ ▸ c.safeBox_interior c.initial_mem) (by
      intro T hT hb
      rw [hprefix T hT hb T ⟨hT,le_rfl⟩]
      exact hxb T hT)
  intro t ht
  exact hprefix t ht (fun s hs => interior_subset (c.safeBox_interior (hystay s hs.1)))
    t ⟨ht,le_rfl⟩

/-- The continuous-data tracking theorem, including kappa_d = 0, is unique
among all forward locally absolutely continuous a.e. mechanical solutions.
No prior existence, competitor state bounds, or negative-time regularity. -/
theorem GlobalTrackingData.exists_unique_classical_caratheodory (c : GlobalTrackingData) :
    ∃ x : ℝ → MechanicalState, x 0 = c.x₀ ∧
      (∀ t ≥ 0, HasDerivAt x (c.field t (x t)) t) ∧
      (∀ T ≥ 0, AbsolutelyContinuousOnInterval x 0 T) ∧
      (∀ t ≥ 0, x t ∈ c.safeBox) ∧
      (c.dbar = 0 → ∀ t ≥ 0,
        c.stateEnergy t (x t) ≤ Real.exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀) ∧
      (0 < c.κd → ∀ t ≥ 0,
        c.stateEnergy t (x t) ≤ Real.exp (-2*c.κ*t)*c.stateEnergy 0 c.x₀+
          c.dbar^2/(16*c.κ*c.κd)*(1-Real.exp (-2*c.κ*t))) ∧
      ∀ y : ℝ → MechanicalState, y 0 = c.x₀ →
        (∀ T ≥ 0, AbsolutelyContinuousOnInterval y 0 T) →
        (∀ᵐ t ∂volume, 0 ≤ t → HasDerivAt y (c.field t (y t)) t) →
        ∀ t ≥ 0, y t = x t := by
  obtain ⟨x,hx,hd,hb,hn,hr⟩ := c.exists_global_tracking
  have hac := c.classical_forward_ac hx hd
  have hxi := forward_ac_integral hx hac (Eventually.of_forall hd)
  refine ⟨x,hx,hd,hac,hb,hn,hr,?_⟩
  intro y hy hyAC hyD
  have hyi := forward_ac_integral hy hyAC hyD
  have ext (z : ℝ → MechanicalState)
      (hi : ∀ t ≥ 0, z t = c.x₀ + ∫ s in (0:ℝ)..t, c.field s (z s)) :
      ∀ t ≥ 0, z (max 0 t) = c.x₀ + ∫ s in (0:ℝ)..t, c.field s (z (max 0 s)) := by
    intro t ht
    rw [max_eq_right ht,hi t ht]
    congr 1
    apply intervalIntegral.integral_congr
    intro s hs
    rw [uIcc_of_le ht] at hs
    simp only [max_eq_right hs.1]
  have heq := c.classical_integral_unique
    (locally_ac_forward_extension hac) (locally_ac_forward_extension hyAC)
    (fun t ht => by simpa [max_eq_right ht] using hb t ht)
    (ext x (fun t ht => (hxi t ht).2)) (ext y (fun t ht => (hyi t ht).2))
  intro t ht
  simpa only [max_eq_right ht] using heq t ht

end
end ChainFountain

/-
Copyright (c) 2026 Latchezar Tomov. All rights reserved.
Released under Apache 2.0 license as described in LICENSE.
-/

namespace ChainFountainStochastic
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory MathFin
open MathFin.ItoIntegralL2 MathFin.ItoFormulaAdapted
open MathFin.ItoIntegralProcessLocalMartingaleGeneral
open scoped NNReal Topology

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
  {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
  (hBmeas : ∀ t, Measurable (B t)) (hBcont : ∀ ω, Continuous (fun t => B t ω))
  {σ b : ℝ≥0 → Ω → ℝ}
  (hσad : ∀ t, StronglyMeasurable[natFiltration hBmeas t] (σ t))
  (hσc : ∀ ω, Continuous (fun t => σ t ω))
  (hbad : ∀ t, StronglyMeasurable[natFiltration hBmeas t] (b t))
  (hbc : ∀ ω, Continuous (fun t => b t ω)) (z₀ : ℝ)

include hB hBcont hbad hbc in
/-- The quadratic Itô decomposition is derived from the constructed Brownian
stochastic integral. No partition-limit or martingale-decomposition hypothesis
occurs in the statement. The drift and diffusion coefficients may be unbounded.
This is a finite-horizon scalar Itô-process theorem, not SDE existence. -/
theorem quadratic_ito_localMartingale :
    ∃ M : ℝ≥0 → Ω → ℝ,
      (∀ᵐ ω ∂μ, ∀ t∈Icc 0 T,
        (localItoProcess (μ:=μ) T hBmeas hσad hσc z₀ b t ω)^2/8 = z₀^2/8 +
          (∫ s in Ioc 0 t,
            (localItoProcess (μ:=μ) T hBmeas hσad hσc z₀ b s ω)*b s ω/4 +
              (σ s ω)^2/8 ∂timeMeasure) + M t ω) ∧
      (∀ ω, Continuous (fun t => M t ω)) ∧
      IsLocalMartingale M (augFiltration (μ:=μ) hBmeas) μ := by
  have hf₁ (t x : ℝ) : HasDerivAt (fun _ : ℝ => x^2/8) 0 t := hasDerivAt_const _ _
  have hf₂ (t x : ℝ) : HasDerivAt (fun x : ℝ => x^2/8) (x/4) x := by
    convert! ((hasDerivAt_id x).pow 2).div_const 8 using 1 <;> simp [id_eq] <;> ring
  have hf₃ (t x : ℝ) : HasDerivAt (fun x : ℝ => x/4) (1/4) x := by
    simpa using (hasDerivAt_id x).div_const 4
  obtain ⟨M,hM,hMc,hMl⟩ := exists_localMartingale_ito_formula hB T hBmeas hBcont
    hσad hσc hbad hbc z₀ (f:=fun _ x => x^2/8) (f_t:=fun _ _ => 0)
    (f_x:=fun _ x => x/4) (f_xx:=fun _ _ => 1/4)
    hf₁ hf₂ hf₃ continuous_const (by fun_prop) continuous_const
  refine ⟨M,?_,hMc,hMl⟩
  filter_upwards [hM] with ω hω t ht
  have heq : (∫ s in Ioc 0 t,
      0+(localItoProcess (μ:=μ) T hBmeas hσad hσc z₀ b s ω)/4*b s ω+
        1/2*((1/4)*(σ s ω)^2) ∂timeMeasure)=
      ∫ s in Ioc 0 t,
        (localItoProcess (μ:=μ) T hBmeas hσad hσc z₀ b s ω)*b s ω/4+
          (σ s ω)^2/8 ∂timeMeasure := by
    apply integral_congr_ae
    exact Eventually.of_forall (fun _ => by ring)
  have hm := hω t ht
  rw [heq] at hm
  linarith

end
end ChainFountainStochastic

/-
The change-of-variables proof is adapted verbatim from MathFin, GyongyMimicry.lean,
commit 61d945b970561fcce6996fac0a5f18a424eb851f.
Copyright (c) 2026 Yang Ye. All rights reserved.
Released under Apache 2.0 license as described in LICENSE.
-/
namespace ChainFountainStochastic
noncomputable section
open Set Filter MeasureTheory MathFin MathFin.ItoIntegralL2
open scoped NNReal Topology

theorem timeMeasure_Ioc_eq_interval {g : ℝ≥0 → ℝ} (T : ℝ≥0) :
    ∫ s in Set.Ioc (0:ℝ≥0) T, g s ∂ItoIntegralL2.timeMeasure
      = ∫ x in (0)..(T:ℝ), g (Real.toNNReal x) := by
  have himg : ((↑) : ℝ≥0 → ℝ) '' Set.Ioc (0:ℝ≥0) T = Set.Ioc (0:ℝ) (T:ℝ) := by
    ext x
    simp only [Set.mem_image, Set.mem_Ioc]
    constructor
    · rintro ⟨y, ⟨hy1, hy2⟩, rfl⟩
      exact ⟨by exact_mod_cast hy1, by exact_mod_cast hy2⟩
    · rintro ⟨hx1, hx2⟩
      have hy : (Real.toNNReal x : ℝ) = x := Real.coe_toNNReal x hx1.le
      have hle : (Real.toNNReal x : ℝ) ≤ (T:ℝ) := by rw [hy]; exact hx2
      exact ⟨Real.toNNReal x, Set.mem_Ioc.2 ⟨Real.toNNReal_pos.2 hx1,
        NNReal.coe_le_coe.mp hle⟩, hy⟩
  have hrng : ((↑) : ℝ≥0 → ℝ) '' Set.Ioc (0:ℝ≥0) T ⊆ Set.range ((↑) : ℝ≥0 → ℝ) :=
    Set.image_subset_range _ _
  have hmap : MeasureTheory.Measure.map ((↑) : ℝ≥0 → ℝ)
      (ItoIntegralL2.timeMeasure.restrict (Set.Ioc (0:ℝ≥0) T))
      = MeasureTheory.volume.restrict (((↑) : ℝ≥0 → ℝ) '' Set.Ioc (0:ℝ≥0) T) := by
    rw [ItoIntegralL2.timeMeasure,
      MeasurableEmbedding.restrict_comap measurableEmbedding_nnrealCoe,
      MeasurableEmbedding.map_comap measurableEmbedding_nnrealCoe,
      Measure.restrict_restrict measurableEmbedding_nnrealCoe.measurableSet_range,
      Set.inter_eq_right.2 hrng]
  calc ∫ s in Set.Ioc (0:ℝ≥0) T, g s ∂ItoIntegralL2.timeMeasure
      = ∫ x, g (Real.toNNReal (↑x)) ∂(ItoIntegralL2.timeMeasure.restrict (Set.Ioc (0:ℝ≥0) T)) :=
        MeasureTheory.integral_congr_ae (Eventually.of_forall fun x => by
          simp only [Real.toNNReal_coe])
    _ = ∫ y, g (Real.toNNReal y) ∂(MeasureTheory.Measure.map ((↑) : ℝ≥0 → ℝ)
          (ItoIntegralL2.timeMeasure.restrict (Set.Ioc (0:ℝ≥0) T))) :=
          (measurableEmbedding_nnrealCoe.integral_map
            (fun y : ℝ => g (Real.toNNReal y))).symm
    _ = ∫ y, g (Real.toNNReal y) ∂(MeasureTheory.volume.restrict
          (((↑) : ℝ≥0 → ℝ) '' Set.Ioc (0:ℝ≥0) T)) := by rw [hmap]
    _ = ∫ x in ((↑) : ℝ≥0 → ℝ) '' Set.Ioc (0:ℝ≥0) T, g (Real.toNNReal x) ∂volume := rfl
    _ = ∫ x in Set.Ioc (0:ℝ) (T:ℝ), g (Real.toNNReal x) ∂volume := by rw [himg]
    _ = ∫ x in (0)..(T:ℝ), g (Real.toNNReal x) ∂volume :=
        (intervalIntegral.integral_of_le (NNReal.coe_nonneg T)).symm


/-- Ordinary FTC for the finite-variation height-error energy, expressed in
exactly the time measure used by the Brownian stochastic integral. -/
theorem finite_variation_energy {e e' : ℝ → ℝ} {k : ℝ} {T : ℝ≥0}
    (hd : ∀ t∈Icc (0:ℝ) T, HasDerivAt e (e' t) t)
    (hc : ContinuousOn e' (Icc (0:ℝ) T)) :
    k*(e T)^2/2 = k*(e 0)^2/2 + ∫ s in Ioc (0:ℝ≥0) T, k*e s*e' s ∂timeMeasure := by
  have he : ContinuousOn e (Icc (0:ℝ) T) := fun t ht => (hd t ht).continuousAt.continuousWithinAt
  have hD (t : ℝ) (ht : t∈Icc (0:ℝ) T) :
      HasDerivAt (fun s => k*(e s)^2/2) (k*e t*e' t) t := by
    convert! (((hd t ht).pow 2).const_mul k).div_const 2 using 1 <;> ring
  have hI : IntervalIntegrable (fun s => k*e s*e' s) volume 0 T :=
    ((continuousOn_const.mul he).mul hc).intervalIntegrable_of_Icc T.coe_nonneg
  have hFTC := intervalIntegral.integral_eq_sub_of_hasDerivAt
    (fun t ht => hD t (by simpa [uIcc_of_le T.coe_nonneg] using ht)) hI
  rw [timeMeasure_Ioc_eq_interval]
  have hi : (∫ t in (0:ℝ)..(T:ℝ), k*e (Real.toNNReal t)*e' (Real.toNNReal t))=
      ∫ t in (0:ℝ)..(T:ℝ), k*e t*e' t := by
    apply intervalIntegral.integral_congr
    intro t ht
    rw [uIcc_of_le T.coe_nonneg] at ht
    simp [Real.coe_toNNReal t ht.1]
  rw [hi,hFTC]
  ring

end
end ChainFountainStochastic

/-
Copyright (c) 2026 Latchezar Tomov. All rights reserved.
Released under Apache 2.0 license as described in LICENSE.
-/
namespace ChainFountainStochastic
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory MathFin
open MathFin.ItoIntegralL2 MathFin.ItoFormulaAdapted
open MathFin.ItoIntegralProcessLocalMartingaleGeneral
open scoped NNReal Topology

def trackingEnergy (k₀ e z : ℝ) := k₀*e^2/2+z^2/8
def trackingGenerator (k₀ k₁ k₂ κd σ e z G : ℝ) :=
  -k₀*k₁*e^2-k₂*z^2/4-κd*G^2*z^2/4+σ^2*G^2/8

/-- From the Brownian-driven error SDE to the actual energy decomposition.
The SDE is stated as its stochastic integral equation; an energy Itô formula,
quadratic-variation limit, or martingale decomposition is not assumed. -/
theorem tracking_energy_ito
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {a b z G : ℝ≥0 → Ω → ℝ} {e : ℝ → Ω → ℝ} {k₀ k₁ k₂ κd σ z₀ : ℝ}
    (ham : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hac : ∀ ω, Continuous (fun t => a t ω))
    (hbm : ∀ t, StronglyMeasurable[natFiltration hBm t] (b t))
    (hbc : ∀ ω, Continuous (fun t => b t ω))
    (hzc : ∀ ω, Continuous (fun t => z t ω))
    (he : ∀ ω t, 0≤ t → HasDerivAt (fun s => e s ω)
      (-k₁*e t ω+z (Real.toNNReal t) ω/2) t)
    (hab : ∀ t∈Icc 0 T, ∀ ω,
      a t ω=σ*G t ω ∧ b t ω= -2*k₀*e t ω-k₂*z t ω-κd*(G t ω)^2*z t ω)
    (hSDE : ∀ᵐ ω ∂μ, ∀ t∈Icc 0 T,
      z t ω=localItoProcess (μ:=μ) T hBm ham hac z₀ b t ω) :
    ∃ M : ℝ≥0 → Ω → ℝ,
      (∀ᵐ ω ∂μ, ∀ t∈Icc 0 T,
        trackingEnergy k₀ (e t ω) (z t ω)=trackingEnergy k₀ (e 0 ω) z₀+
          (∫ s in Ioc 0 t, trackingGenerator k₀ k₁ k₂ κd σ (e s ω) (z s ω) (G s ω)
            ∂timeMeasure)+M t ω) ∧
      (∀ ω, Continuous (fun t => M t ω)) ∧
      IsLocalMartingale M (augFiltration (μ:=μ) hBm) μ := by
  obtain ⟨M,hM,hMc,hMl⟩ := quadratic_ito_localMartingale hB T hBm hBc ham hac hbm hbc z₀
  refine ⟨M,?_,hMc,hMl⟩
  filter_upwards [hM,hSDE] with ω hMω hZω t ht
  have hec : ContinuousOn (fun s : ℝ => e s ω) (Ici 0) :=
    fun s hs => (he ω s hs).continuousAt.continuousWithinAt
  have hecn : Continuous (fun s : ℝ≥0 => e s ω) :=
    hec.comp_continuous NNReal.continuous_coe (fun s => s.coe_nonneg)
  have he'c : ContinuousOn (fun s : ℝ => -k₁*e s ω+z (Real.toNNReal s) ω/2)
      (Icc 0 (t:ℝ)) := by
    exact (continuousOn_const.mul (hec.mono (fun _ hs => hs.1))).add
      (((hzc ω).comp continuous_real_toNNReal).continuousOn.div_const 2)
  have hE := finite_variation_energy (k:=k₀)
    (fun s hs => he ω s hs.1) he'c
  have hZ := hMω t ht
  rw [←hZω t ht] at hZ
  have hconv : (∫ s in Ioc 0 t,
      (localItoProcess (μ:=μ) T hBm ham hac z₀ b s ω)*b s ω/4+(a s ω)^2/8
        ∂timeMeasure)=∫ s in Ioc 0 t, z s ω*b s ω/4+(a s ω)^2/8 ∂timeMeasure := by
    apply setIntegral_congr_fun measurableSet_Ioc
    intro s hs
    dsimp only
    rw [←hZω s ⟨zero_le,hs.2.trans ht.2⟩]
  rw [hconv] at hZ
  simp only [Real.toNNReal_coe] at hE
  have hi₁ : IntegrableOn (fun s : ℝ≥0 => k₀*e s ω*(-k₁*e s ω+z s ω/2))
      (Ioc 0 t) timeMeasure := by
    exact ((continuous_const.mul hecn).mul
      ((continuous_const.mul hecn).add ((hzc ω).div_const 2))).continuousOn.integrableOn_compact
        isCompact_Icc |>.mono_set Ioc_subset_Icc_self
  have hi₂ : IntegrableOn (fun s : ℝ≥0 => z s ω*b s ω/4+(a s ω)^2/8)
      (Ioc 0 t) timeMeasure := by
    exact (((hzc ω).mul (hbc ω)).div_const 4 |>.add ((hac ω).pow 2 |>.div_const 8)).continuousOn.integrableOn_compact
      isCompact_Icc |>.mono_set Ioc_subset_Icc_self
  have hsum : (∫ s in Ioc 0 t, trackingGenerator k₀ k₁ k₂ κd σ (e s ω) (z s ω) (G s ω)
      ∂timeMeasure)=(∫ s in Ioc 0 t, k₀*e s ω*(-k₁*e s ω+z s ω/2) ∂timeMeasure)+
      ∫ s in Ioc 0 t, z s ω*b s ω/4+(a s ω)^2/8 ∂timeMeasure := by
    rw [←integral_add hi₁ hi₂]
    apply setIntegral_congr_fun measurableSet_Ioc
    intro s hs
    obtain ⟨ha,hb⟩ := hab s ⟨zero_le,hs.2.trans ht.2⟩ ω
    dsimp only
    rw [ha,hb]
    dsimp [trackingGenerator]
    ring
  rw [hsum]
  dsimp [trackingEnergy]
  linarith

end
end ChainFountainStochastic

/-
Copyright (c) 2026 Latchezar Tomov. All rights reserved.
Released under Apache 2.0 license as described in LICENSE.
-/
namespace ChainFountainStochastic
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory MathFin
open MathFin.ItoIntegralL2 MathFin.ItoFormulaAdapted
open MathFin.ItoIntegralProcessLocalMartingaleGeneral
open scoped NNReal Topology

/-- Transfer the proved finite-horizon Itô local martingale to a stopped,
everywhere continuous adapted residual, then derive the true martingale
property from a bound. No optional-stopping axiom is assumed. -/
theorem bounded_stopped_residual_martingale
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {ℱ : Filtration ℝ≥0 ‹MeasurableSpace Ω›} {Y R : ℝ≥0 → Ω → ℝ} {T : ℝ≥0}
    (hY : IsLocalMartingale Y ℱ μ)
    (hR : StronglyAdapted ℱ R) (hRc : ∀ ω, Continuous (fun t => R t ω))
    (heq : ∀ᵐ ω ∂μ, ∀ t∈Icc 0 T, Y t ω=R t ω)
    {τ : Ω → WithTop ℝ≥0} (hτ : IsStoppingTime ℱ τ)
    (hτpos : ∀ ω, ⊥<τ ω) (hτT : ∀ ω, τ ω≤ T)
    {C : ℝ} (hbound : ∀ t ω, ‖stoppedProcess R τ t ω‖≤ C) :
    Martingale (stoppedProcess R τ) ℱ μ := by
  have hloc := (isStable_martingale (𝓕:=ℱ) (P:=μ)).locally Y hY τ hτ
  have had := hR.stoppedProcess_indicator (fun ω => (hRc ω).isCadlag.right_continuous) hτ
  have hcad := isStable_isCadlag (𝓕:=ℱ) R (fun ω => (hRc ω).isCadlag) τ hτ
  rw [stoppedProcess_indicator_eq hτpos] at hloc had hcad
  have hind : ∀ᵐ ω ∂μ, ∀ t, stoppedProcess Y τ t ω=stoppedProcess R τ t ω := by
    filter_upwards [heq] with ω hω t
    apply hω
    refine ⟨zero_le,?_⟩
    exact WithTop.untopA_le ((min_le_right _ _).trans (hτT ω))
  exact bounded_localMartingale_is_martingale
    (isLocalMartingale_congr_ae hloc had hcad hind) had hbound

/-- Stopped continuous adapted processes are integrable when bounded.
This will discharge, rather than assume, the integrability used in expectations. -/
theorem stopped_process_integrable
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {ℱ : Filtration ℝ≥0 ‹MeasurableSpace Ω›} {X : ℝ≥0 → Ω → ℝ}
    (hX : StronglyAdapted ℱ X) (hXc : ∀ ω, Continuous (fun t => X t ω))
    {τ : Ω → WithTop ℝ≥0} (hτ : IsStoppingTime ℱ τ) (hτpos : ∀ ω, ⊥<τ ω)
    {C : ℝ} (hbound : ∀ t ω, ‖stoppedProcess X τ t ω‖≤ C) (t : ℝ≥0) :
    Integrable (stoppedProcess X τ t) μ := by
  have had := hX.stoppedProcess_indicator (fun ω => (hXc ω).isCadlag.right_continuous) hτ
  rw [stoppedProcess_indicator_eq hτpos] at had
  exact (integrable_const C).mono' ((had t).mono (ℱ.le t)).aestronglyMeasurable
    (Eventually.of_forall (hbound t))

/-- Exact expectation estimate for a stopped energy residual that is a genuine
martingale. Unlike the older theorem, all three scalar integrability conditions
are discharged from adaptedness, path continuity, and localization bounds. -/
theorem stopped_dissipation_expectation
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {ℱ : Filtration ℝ≥0 ‹MeasurableSpace Ω›} {V I S R : ℝ≥0 → Ω → ℝ}
    {τ : Ω → WithTop ℝ≥0} (hτ : IsStoppingTime ℱ τ) (hτpos : ∀ ω, ⊥<τ ω)
    (hV : StronglyAdapted ℱ V) (hVc : ∀ ω, Continuous (fun t => V t ω))
    (hI : StronglyAdapted ℱ I) (hIc : ∀ ω, Continuous (fun t => I t ω))
    (hS : StronglyAdapted ℱ S) (hSc : ∀ ω, Continuous (fun t => S t ω))
    {CV CI CS : ℝ}
    (hVB : ∀ t ω, ‖stoppedProcess V τ t ω‖≤ CV)
    (hIB : ∀ t ω, ‖stoppedProcess I τ t ω‖≤ CI)
    (hSB : ∀ t ω, ‖stoppedProcess S τ t ω‖≤ CS)
    (hM : Martingale (stoppedProcess R τ) ℱ μ) (hR0 : ∀ ω, R 0 ω=0)
    {V₀ κ C : ℝ}
    (hineq : ∀ᵐ ω ∂μ, ∀ t,
      stoppedProcess V τ t ω+2*κ*stoppedProcess I τ t ω≤
        V₀+C*stoppedProcess S τ t ω+stoppedProcess R τ t ω) (t : ℝ≥0) :
    (∫ ω, stoppedProcess V τ t ω ∂μ)+2*κ*(∫ ω, stoppedProcess I τ t ω ∂μ)≤
      V₀+C*(∫ ω, stoppedProcess S τ t ω ∂μ) := by
  have hv := stopped_process_integrable (μ:=μ) hV hVc hτ hτpos hVB t
  have hi := stopped_process_integrable (μ:=μ) hI hIc hτ hτpos hIB t
  have hs := stopped_process_integrable (μ:=μ) hS hSc hτ hτpos hSB t
  have hzero : (∫ ω, stoppedProcess R τ t ω ∂μ)=0 := by
    have hm := hM.setIntegral_eq (zero_le : (0:ℝ≥0)≤ t) (s:=univ) MeasurableSet.univ
    have h₀ (ω : Ω) : stoppedProcess R τ 0 ω=0 := by
      exact (stoppedProcess_eq_of_le (u:=R) (τ:=τ) (i:=0) (ω:=ω) (by exact bot_le)).trans (hR0 ω)
    simpa [h₀] using hm.symm
  have hle := integral_mono_ae (hv.add (hi.const_mul (2*κ)))
    (((integrable_const V₀).add (hs.const_mul C)).add (hM.integrable t))
    (hineq.mono (fun ω hω => hω t))
  simp only [Pi.add_apply] at hle
  have hleft := integral_add hv (hi.const_mul (2*κ))
  have hright := integral_add ((integrable_const V₀).add (hs.const_mul C)) (hM.integrable t)
  have hmiddle := integral_add (integrable_const V₀) (hs.const_mul C)
  simp only [Pi.add_apply] at hleft hright hmiddle
  rw [hleft,hright,hmiddle,integral_const_mul,integral_const_mul,hzero] at hle
  simpa using hle

end
end ChainFountainStochastic

namespace ChainFountainStochastic
noncomputable section
open Set Filter MeasureTheory MathFin
open scoped NNReal Topology

/-- The normalized distance from the deterministic initial mechanical state. -/
def physicalGauge {Ω : Type*} (X : ℝ≥0 → Ω → ℝ × (ℝ × ℝ))
    (x₀ : ℝ × (ℝ × ℝ)) (R : ℝ) (t : ℝ≥0) (ω : Ω) := ‖X t ω-x₀‖/R

/-- First exit from the open mechanical ball, capped by a deterministic horizon.
Choosing the closed ball inside the regular physical domain gives physical localization. -/
def physicalExit {Ω : Type*} (X : ℝ≥0 → Ω → ℝ × (ℝ × ℝ))
    (x₀ : ℝ × (ℝ × ℝ)) (R : ℝ) (T : ℝ≥0) (ω : Ω) : WithTop ℝ≥0 :=
  min (exitTime (physicalGauge X x₀ R) 1 ω) T

/-- The actual physical first exit is a positive bounded stopping time, and
continuity keeps the stopped mechanical state in the closed localization ball. -/
theorem physical_exit_properties
    {Ω : Type*} [MeasurableSpace Ω] {ℱ : Filtration ℝ≥0 ‹MeasurableSpace Ω›}
    {X : ℝ≥0 → Ω → ℝ × (ℝ × ℝ)} {x₀ : ℝ × (ℝ × ℝ)} {R : ℝ} {T : ℝ≥0}
    (hX : StronglyAdapted ℱ X) (hXc : ∀ ω, Continuous (fun t => X t ω))
    (hX₀ : ∀ ω, X 0 ω=x₀) (hR : 0<R) (hT : 0<T) :
    IsStoppingTime ℱ (physicalExit X x₀ R T) ∧
    (∀ ω, ⊥<physicalExit X x₀ R T ω) ∧
    (∀ ω, physicalExit X x₀ R T ω≤ T) ∧
    (∀ t ω, stoppedProcess X (physicalExit X x₀ R T) t ω∈Metric.closedBall x₀ R) := by
  have hGc : ∀ ω, Continuous (fun t => physicalGauge X x₀ R t ω) :=
    fun ω => (((hXc ω).sub continuous_const).norm).div_const R
  have hGm : ∀ t, Measurable[ℱ t] (physicalGauge X x₀ R t) :=
    fun t => (((hX t).sub stronglyMeasurable_const).norm.div stronglyMeasurable_const).measurable
  have hτ := isStoppingTime_exitTime_of_measurable hGm hGc 1
  have hpos (ω : Ω) : ⊥<exitTime (physicalGauge X x₀ R) 1 ω := by
    apply lt_of_not_ge
    intro hn
    obtain ⟨s,hs,hg⟩ := (exitTime_le_iff hGc 1 0 ω).mp hn
    have hs0 : s=0 := le_antisymm hs.2 zero_le
    norm_num [hs0,physicalGauge,hX₀] at hg
  refine ⟨hτ.min (isStoppingTime_const ℱ T),?_,fun _ => min_le_right _ _,?_⟩
  · intro ω
    exact lt_min (hpos ω) (by change ((0:ℝ≥0):WithTop ℝ≥0)<(T:WithTop ℝ≥0); exact WithTop.coe_lt_coe.mpr hT)
  · intro t ω
    have hb := abs_le_of_le_exitTime hGc (hpos ω)
      (s:=(min (t:WithTop ℝ≥0) (physicalExit X x₀ R T ω)).untopA)
      (by rw [coe_untopA_min]; exact (min_le_right _ _).trans (min_le_left _ _))
    have hq := (le_abs_self _).trans hb
    rw [physicalGauge] at hq
    have hn := (div_le_iff₀ hR).mp hq
    simpa only [Nat.cast_one,one_mul,Metric.mem_closedBall,dist_eq_norm,stoppedProcess] using hn

/-- Before the deterministic cap, the stopping event is exactly the event
that the mechanical path has reached the boundary or exterior of the ball. -/
theorem physical_exit_le_iff
    {Ω : Type*} {X : ℝ≥0 → Ω → ℝ × (ℝ × ℝ)} {x₀ : ℝ × (ℝ × ℝ)} {R : ℝ}
    (hXc : ∀ ω, Continuous (fun t => X t ω)) (hR : 0<R)
    {T t : ℝ≥0} (ht : t<T) (ω : Ω) :
    physicalExit X x₀ R T ω≤ t ↔ ∃ s∈Icc 0 t, R≤ dist (X s ω) x₀ := by
  have hGc : ∀ ω, Continuous (fun t => physicalGauge X x₀ R t ω) :=
    fun ω => (((hXc ω).sub continuous_const).norm).div_const R
  have hnot : ¬(T:WithTop ℝ≥0)≤ t := by exact_mod_cast not_le.mpr ht
  rw [physicalExit,min_le_iff,or_iff_left hnot,exitTime_le_iff hGc]
  congr! 2 with s
  rw [physicalGauge,abs_of_nonneg (div_nonneg (norm_nonneg _) hR.le),le_div_iff₀ hR]
  simp only [Nat.cast_one,one_mul,dist_eq_norm]

/-- Interior physical states of the reduced model, with a strict crown margin. -/
def physicalDomain (vmin : ℝ) : Set (ℝ×(ℝ×ℝ)) :=
  {x | 0<x.1 ∧ 0<x.2.1 ∧ 0<x.2.2 ∧ vmin<(x.2.1+x.2.2)/2}

theorem physicalDomain_isOpen (vmin : ℝ) : IsOpen (physicalDomain vmin) := by
  exact (isOpen_lt continuous_const continuous_fst).inter
    ((isOpen_lt continuous_const (continuous_fst.comp continuous_snd)).inter
      ((isOpen_lt continuous_const (continuous_snd.comp continuous_snd)).inter
        (isOpen_lt continuous_const
          (((continuous_fst.comp continuous_snd).add (continuous_snd.comp continuous_snd)).div_const 2))))

/-- Every strictly physical initial state has a compact localization ball
entirely inside the physical domain. -/
theorem exists_physical_localization_ball {x₀ : ℝ×(ℝ×ℝ)} {vmin : ℝ}
    (hx₀ : x₀∈physicalDomain vmin) :
    ∃ R : ℝ, 0<R ∧ IsCompact (Metric.closedBall x₀ R) ∧
      Metric.closedBall x₀ R⊆physicalDomain vmin := by
  obtain ⟨ε,hε,hsub⟩ := Metric.mem_nhds_iff.mp ((physicalDomain_isOpen vmin).mem_nhds hx₀)
  exact ⟨ε/2,half_pos hε,isCompact_closedBall x₀ (ε/2),
    (Metric.closedBall_subset_ball (half_lt_self hε)).trans hsub⟩

/-- Actual physical-domain safety up to the constructed first exit. -/
theorem stopped_state_physical
    {Ω : Type*} [MeasurableSpace Ω] {ℱ : Filtration ℝ≥0 ‹MeasurableSpace Ω›}
    {X : ℝ≥0 → Ω → ℝ×(ℝ×ℝ)} {x₀ : ℝ×(ℝ×ℝ)} {R vmin : ℝ} {T : ℝ≥0}
    (hX : StronglyAdapted ℱ X) (hXc : ∀ ω, Continuous (fun t => X t ω))
    (hX₀ : ∀ ω, X 0 ω=x₀) (hR : 0<R) (hT : 0<T)
    (hball : Metric.closedBall x₀ R⊆physicalDomain vmin) :
    ∀ t ω, stoppedProcess X (physicalExit X x₀ R T) t ω∈physicalDomain vmin := by
  intro t ω
  exact hball ((physical_exit_properties hX hXc hX₀ hR hT).2.2.2 t ω)

end
end ChainFountainStochastic

namespace ChainFountainStochastic
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory MathFin
open MathFin.ItoIntegralL2 MathFin.AdaptedDrift
open scoped NNReal Topology

/-- Time integrals of continuous adapted rates are adapted, without a global
bound on the rate. Progressive measurability supplies the parameter integral. -/
theorem continuous_drift_adapted
    {Ω : Type*} [MeasurableSpace Ω] {ℱ : Filtration ℝ≥0 ‹MeasurableSpace Ω›}
    {b : ℝ≥0 → Ω → ℝ} (hb : StronglyAdapted ℱ b)
    (hbc : ∀ ω, Continuous (fun t => b t ω)) : StronglyAdapted ℱ (driftPath b) := by
  have hp := hb.isStronglyProgressive_of_continuous hbc
  intro t
  letI : MeasurableSpace Ω := ℱ t
  let clip : ℝ≥0 × Ω → Iic t × Ω := fun p => (⟨min p.1 t,by exact min_le_right p.1 t⟩,p.2)
  have hclip : Measurable clip :=
    ((measurable_fst.min measurable_const).subtype_mk).prodMk measurable_snd
  have hm : StronglyMeasurable (fun p : ℝ≥0 × Ω => b (min p.1 t) p.2) :=
    (hp t).comp_measurable hclip
  have hi : StronglyMeasurable (fun ω => ∫ s in Ioc 0 t, b (min s t) ω ∂timeMeasure) :=
    hm.integral_prod_left
  convert! hi using 1
  funext ω
  apply setIntegral_congr_fun measurableSet_Ioc
  intro s hs
  simp only [min_eq_left hs.2]

/-- Path continuity of the time primitive needs only local integrability,
which follows from continuity of its rate. -/
theorem continuous_drift_paths
    {Ω : Type*} {b : ℝ≥0 → Ω → ℝ}
    (hbc : ∀ ω, Continuous (fun t => b t ω)) (ω : Ω) :
    Continuous (fun t => driftPath b t ω) := by
  have hc := (hbc ω).comp continuous_real_toNNReal
  have hP := (intervalIntegral.differentiable_integral_of_continuous (a:=0) hc).continuous
  have hPN := hP.comp NNReal.continuous_coe
  apply hPN.congr
  intro t
  exact (timeMeasure_Ioc_eq_interval (g:=fun s => b s ω) t).symm

/-- A bound on a finite prefix suffices to bound its time integral. -/
theorem drift_prefix_bound {Ω : Type*} {b : ℝ≥0 → Ω → ℝ} {C : ℝ}
    (u : ℝ≥0) (ω : Ω) (hb : ∀ s∈Icc 0 u, |b s ω|≤ C) :
    |driftPath b u ω|≤ C*u := by
  rw [driftPath,←Real.norm_eq_abs]
  refine (norm_setIntegral_le_of_norm_le_const
    (by rw [timeMeasure_Ioc]; exact ENNReal.ofReal_lt_top)
    (fun s hs => (Real.norm_eq_abs _).trans_le (hb s (Ioc_subset_Icc_self hs)))).trans_eq ?_
  simp only [measureReal_def,timeMeasure_Ioc,NNReal.coe_zero,sub_zero,
    ENNReal.toReal_ofReal u.coe_nonneg]

/-- The integrated generator inequality on a finite prefix. -/
theorem drift_dissipation_prefix {Ω : Type*} {V J : ℝ≥0 → Ω → ℝ} {κ C : ℝ}
    (hVc : ∀ ω, Continuous (fun t => V t ω))
    (hJc : ∀ ω, Continuous (fun t => J t ω)) (u : ℝ≥0) (ω : Ω)
    (hgen : ∀ s∈Icc 0 u, J s ω≤ -2*κ*V s ω+C) :
    driftPath J u ω+2*κ*driftPath V u ω≤ C*u := by
  have hVi : IntegrableOn (fun s => V s ω) (Ioc 0 u) timeMeasure :=
    ((hVc ω).continuousOn.integrableOn_compact isCompact_Icc).mono_set Ioc_subset_Icc_self
  have hJi : IntegrableOn (fun s => J s ω) (Ioc 0 u) timeMeasure :=
    ((hJc ω).continuousOn.integrableOn_compact isCompact_Icc).mono_set Ioc_subset_Icc_self
  letI : IsFiniteMeasure (timeMeasure.restrict (Ioc 0 u)) :=
    ⟨by rw [Measure.restrict_apply_univ,timeMeasure_Ioc]; exact ENNReal.ofReal_lt_top⟩
  have hle := integral_mono_ae (hJi.add (hVi.const_mul (2*κ)))
    (integrable_const C) (by
      filter_upwards [ae_restrict_mem measurableSet_Ioc] with s hs
      have h := hgen s (Ioc_subset_Icc_self hs)
      change J s ω+2*κ*V s ω≤ C
      linarith)
  simp only [Pi.add_apply] at hle
  rw [integral_add hJi (hVi.const_mul (2*κ)),integral_const_mul,integral_const] at hle
  simpa only [driftPath,smul_eq_mul,Measure.restrict_apply_univ,measureReal_def,timeMeasure_Ioc,NNReal.coe_zero,
    sub_zero,ENNReal.toReal_ofReal u.coe_nonneg,mul_comm] using hle

/-- Dynkin's dissipation estimate assembled with the actual first physical
exit. Adaptedness, path continuity, integrability, martingale promotion, and
the integrated generator inequality are proved here, not assumed. -/
theorem physical_stopped_generator_expectation
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {ℱ : Filtration ℝ≥0 ‹MeasurableSpace Ω›}
    {X : ℝ≥0 → Ω → ℝ × (ℝ × ℝ)} {x₀ : ℝ × (ℝ × ℝ)} {R : ℝ} {T : ℝ≥0}
    (hX : StronglyAdapted ℱ X) (hXc : ∀ ω, Continuous (fun t => X t ω))
    (hX₀ : ∀ ω, X 0 ω=x₀) (hR : 0<R) (hT : 0<T)
    {V J M : ℝ≥0 → Ω → ℝ} {V₀ κ C CV CJ : ℝ}
    (hV : StronglyAdapted ℱ V) (hVc : ∀ ω, Continuous (fun t => V t ω))
    (hJ : StronglyAdapted ℱ J) (hJc : ∀ ω, Continuous (fun t => J t ω))
    (hV₀ : ∀ ω, V 0 ω=V₀) (hCV : 0≤ CV) (hCJ : 0≤ CJ)
    (hVB : ∀ t∈Icc 0 T, ∀ ω, X t ω∈Metric.closedBall x₀ R → ‖V t ω‖≤ CV)
    (hJB : ∀ t∈Icc 0 T, ∀ ω, X t ω∈Metric.closedBall x₀ R → ‖J t ω‖≤ CJ)
    (hgen : ∀ t∈Icc 0 T, ∀ ω, X t ω∈Metric.closedBall x₀ R → J t ω≤ -2*κ*V t ω+C)
    (hM : IsLocalMartingale M ℱ μ)
    (hIto : ∀ᵐ ω ∂μ, ∀ t∈Icc 0 T, V t ω=V₀+driftPath J t ω+M t ω)
    (t : ℝ≥0) :
    (∫ ω, stoppedProcess V (physicalExit X x₀ R T) t ω ∂μ)+
        2*κ*(∫ ω, stoppedProcess (driftPath V) (physicalExit X x₀ R T) t ω ∂μ)≤
      V₀+C*(∫ ω, stoppedProcess (fun (s:ℝ≥0) (_:Ω) => (s:ℝ)) (physicalExit X x₀ R T) t ω ∂μ) := by
  let τ := physicalExit X x₀ R T
  obtain ⟨hτ,hτpos,hτT,hXB⟩ := physical_exit_properties hX hXc hX₀ hR hT
  let residual := fun s ω => V s ω-V₀-driftPath J s ω
  have hRa : StronglyAdapted ℱ residual := fun s =>
    ((hV s).sub stronglyMeasurable_const).sub (continuous_drift_adapted hJ hJc s)
  have hRc : ∀ ω, Continuous (fun s => residual s ω) := fun ω =>
    ((hVc ω).sub continuous_const).sub (continuous_drift_paths hJc ω)
  have htime (s : ℝ≥0) (ω : Ω) :
      (min (s:WithTop ℝ≥0) (τ ω)).untopA≤ T ∧
      (((min (s:WithTop ℝ≥0) (τ ω)).untopA:ℝ≥0):WithTop ℝ≥0)≤τ ω := by
    exact ⟨WithTop.untopA_le ((min_le_right _ _).trans (hτT ω)),
      by rw [coe_untopA_min]; exact min_le_right _ _⟩
  have hprefix (u : ℝ≥0) (ω : Ω) (hu : (u:WithTop ℝ≥0)≤τ ω) :
      ∀ s∈Icc 0 u, X s ω∈Metric.closedBall x₀ R := by
    intro s hs
    have hsτ : (s:WithTop ℝ≥0)≤τ ω := (WithTop.coe_le_coe.mpr hs.2).trans hu
    have h := hXB s ω
    rw [stoppedProcess_eq_of_le hsτ] at h
    exact h
  have hJint (u : ℝ≥0) (ω : Ω) (huT : u≤ T) (hu : (u:WithTop ℝ≥0)≤τ ω) :
      |driftPath J u ω|≤ CJ*T := by
    apply (drift_prefix_bound u ω (fun s hs => ?_)).trans
      (mul_le_mul_of_nonneg_left (by exact_mod_cast huT) hCJ)
    exact (Real.norm_eq_abs _).symm.trans_le
      (hJB s ⟨zero_le,hs.2.trans huT⟩ ω (hprefix u ω hu s hs))
  have hVstop : ∀ s ω, ‖stoppedProcess V τ s ω‖≤ CV := by
    intro s ω
    exact hVB _ ⟨zero_le,(htime s ω).1⟩ ω
      (hprefix _ ω (htime s ω).2 _ ⟨zero_le,le_rfl⟩)
  have hIstop : ∀ s ω, ‖stoppedProcess (driftPath V) τ s ω‖≤ CV*T := by
    intro s ω
    rw [Real.norm_eq_abs]
    apply (drift_prefix_bound _ ω (fun q hq => ?_)).trans
      (mul_le_mul_of_nonneg_left (by exact_mod_cast (htime s ω).1) hCV)
    exact (Real.norm_eq_abs _).symm.trans_le
      (hVB q ⟨zero_le,hq.2.trans (htime s ω).1⟩ ω
        (hprefix _ ω (htime s ω).2 q hq))
  have hSstop : ∀ s ω, ‖stoppedProcess (fun (q:ℝ≥0) (_:Ω) => (q:ℝ)) τ s ω‖≤(T:ℝ) := by
    intro s ω
    simpa only [stoppedProcess,Real.norm_eq_abs,abs_of_nonneg (NNReal.coe_nonneg _)] using
      (show ((min (s:WithTop ℝ≥0) (τ ω)).untopA:ℝ)≤ T by exact_mod_cast (htime s ω).1)
  have hRstop : ∀ s ω, ‖stoppedProcess residual τ s ω‖≤ CV+|V₀|+CJ*T := by
    intro s ω
    let u := (min (s:WithTop ℝ≥0) (τ ω)).untopA
    have hvi := hVstop s ω
    have hji := hJint u ω (htime s ω).1 (htime s ω).2
    change ‖V u ω-V₀-driftPath J u ω‖≤ CV+|V₀|+CJ*T
    have hn₁ := norm_sub_le (V u ω-V₀) (driftPath J u ω)
    have hn₂ := norm_sub_le (V u ω) V₀
    simp only [Real.norm_eq_abs] at hn₁ hn₂ hvi ⊢
    change |V u ω|≤ CV at hvi
    linarith
  have heq : ∀ᵐ ω ∂μ, ∀ s∈Icc 0 T, M s ω=residual s ω := by
    filter_upwards [hIto] with ω hω s hs
    dsimp [residual]
    linarith [hω s hs]
  have hmart := bounded_stopped_residual_martingale hM hRa hRc heq hτ hτpos hτT hRstop
  have hR₀ (ω : Ω) : residual 0 ω=0 := by simp [residual,driftPath,hV₀]
  have hineq : ∀ᵐ ω ∂μ, ∀ s,
      stoppedProcess V τ s ω+2*κ*stoppedProcess (driftPath V) τ s ω≤
        V₀+C*stoppedProcess (fun (q:ℝ≥0) (_:Ω) => (q:ℝ)) τ s ω+stoppedProcess residual τ s ω := by
    apply Eventually.of_forall
    intro ω s
    have hi := drift_dissipation_prefix hVc hJc _ ω (fun q hq =>
      hgen q ⟨zero_le,hq.2.trans (htime s ω).1⟩ ω (hprefix _ ω (htime s ω).2 q hq))
    dsimp only [stoppedProcess,residual]
    linarith
  exact stopped_dissipation_expectation hτ hτpos hV hVc
    (continuous_drift_adapted hV hVc) (continuous_drift_paths hVc)
    (fun _ => stronglyMeasurable_const) (fun _ => NNReal.continuous_coe)
    hVstop hIstop hSstop hmart hR₀ hineq t

end
end ChainFountainStochastic

namespace ChainFountainStochastic
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory MathFin ChainFountain
open MathFin.ItoIntegralL2 MathFin.ItoFormulaAdapted MathFin.AdaptedDrift
open MathFin.ItoIntegralProcessLocalMartingaleGeneral
open scoped NNReal Topology

/-- Addition of a genuinely differentiable finite-variation coordinate to an
Itô process. The stochastic integral is unchanged; its new drift is derived by
ordinary FTC and linearity of the time integral. -/
theorem ito_add_finite_variation
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {B : ℝ≥0 → Ω → ℝ} (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    {a b : ℝ≥0 → Ω → ℝ}
    (ham : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hac : ∀ ω, Continuous (fun t => a t ω))
    (hbc : ∀ ω, Continuous (fun t => b t ω))
    {c c' : ℝ → Ω → ℝ} {v : ℝ≥0 → Ω → ℝ} {v₀ c₀ : ℝ}
    (hc₀ : ∀ ω, c 0 ω=c₀)
    (hcd : ∀ ω, ∀ t∈Icc (0:ℝ) T, HasDerivAt (fun s => c s ω) (c' t ω) t)
    (hcc : ∀ ω, ContinuousOn (fun t => c' t ω) (Icc (0:ℝ) T))
    (hSDE : ∀ᵐ ω ∂μ, ∀ t∈Icc 0 T,
      v t ω=localItoProcess (μ:=μ) T hBm ham hac v₀ b t ω) :
    ∀ᵐ ω ∂μ, ∀ t∈Icc 0 T,
      v t ω+c t ω=localItoProcess (μ:=μ) T hBm ham hac (v₀+c₀)
        (fun s ω => b s ω+c' s ω) t ω := by
  filter_upwards [hSDE] with ω hω t ht
  have hsub : Icc (0:ℝ) t ⊆ Icc (0:ℝ) T :=
    Icc_subset_Icc le_rfl (by exact_mod_cast ht.2)
  have hci : IntervalIntegrable (fun s => c' s ω) volume 0 t :=
    ((hcc ω).mono hsub).intervalIntegrable_of_Icc t.coe_nonneg
  have hFTC := intervalIntegral.integral_eq_sub_of_hasDerivAt
    (fun s hs => hcd ω s (hsub (by simpa [uIcc_of_le t.coe_nonneg] using hs))) hci
  have hi : (∫ s in Ioc (0:ℝ≥0) t, c' s ω ∂timeMeasure)=c t ω-c₀ := by
    rw [timeMeasure_Ioc_eq_interval]
    have heq : (∫ s in (0:ℝ)..(t:ℝ), c' (Real.toNNReal s) ω)=
        ∫ s in (0:ℝ)..(t:ℝ), c' s ω := by
      apply intervalIntegral.integral_congr
      intro s hs
      rw [uIcc_of_le t.coe_nonneg] at hs
      simp only [Real.coe_toNNReal s hs.1]
    rw [heq,hFTC,hc₀]
  have hib : IntegrableOn (fun s => b s ω) (Ioc 0 t) timeMeasure :=
    ((hbc ω).continuousOn.integrableOn_compact isCompact_Icc).mono_set Ioc_subset_Icc_self
  have hic : IntegrableOn (fun s : ℝ≥0 => c' s ω) (Ioc 0 t) timeMeasure := by
    have hcNN : ContinuousOn (fun s : ℝ≥0 => c' s ω) (Icc 0 t) :=
      ((hcc ω).mono hsub).comp NNReal.continuous_coe.continuousOn
        (fun s hs => ⟨s.coe_nonneg,by exact_mod_cast hs.2⟩)
    exact (hcNN.integrableOn_compact isCompact_Icc).mono_set Ioc_subset_Icc_self
  rw [hω t ht]
  simp only [localItoProcess,driftPath]
  rw [integral_add hib hic,hi]
  ring

/-- The mechanical feedback cancels the drift after the actual coordinate
change. The noise coefficient is unchanged because only v is diffusive. -/
theorem mechanical_error_drift (H g α β k₀ k₁ k₂ κd h v w r r₁ r₂ : ℝ)
    (hh : h≠0) (hH : H+h≠0) :
    rise g α h v w
      (robustInput H g α β h v w (acceleration k₀ k₁ k₂ (h-r) (heightRate v w) r₁ r₂)
        κd (v-w-2*r₁+2*k₁*(h-r))) -
      fall H g β h v w-2*r₂+2*k₁*(heightRate v w-r₁) =
    -2*k₀*(h-r)-k₂*(v-w-2*r₁+2*k₁*(h-r))-
      κd*(v^2/h)^2*(v-w-2*r₁+2*k₁*(h-r)) := by
  have ha := robust_acceleration H g α β h v w
    (acceleration k₀ k₁ k₂ (h-r) (heightRate v w) r₁ r₂)
    κd (v-w-2*r₁+2*k₁*(h-r)) 0 hh hH
  have hz := transformed_z_rate k₀ k₁ k₂ (h-r) (heightRate v w) r₁ r₂ κd (v^2/h) 0
    (v-w-2*r₁+2*k₁*(h-r)) (by unfold heightRate; ring)
  simp only [add_zero,mul_zero,zRate] at ha hz
  linarith


def mechanicalCorrection {Ω : Type*} (k₁ : ℝ) (h w : ℝ → Ω → ℝ)
    (r r₁ : ℝ → ℝ) (t : ℝ) (ω : Ω) := -w t ω-2*r₁ t+2*k₁*(h t ω-r t)

def mechanicalCorrectionRate {Ω : Type*} (H g β k₁ : ℝ) (h w : ℝ → Ω → ℝ)
    (v : ℝ≥0 → Ω → ℝ) (r₁ r₂ : ℝ → ℝ) (t : ℝ) (ω : Ω) :=
  -fall H g β (h t ω) (v (Real.toNNReal t) ω) (w t ω)-2*r₂ t+
    2*k₁*(heightRate (v (Real.toNNReal t) ω) (w t ω)-r₁ t)

def mechanicalZ {Ω : Type*} (k₁ : ℝ) (h w : ℝ → Ω → ℝ)
    (v : ℝ≥0 → Ω → ℝ) (r r₁ : ℝ → ℝ) (t : ℝ≥0) (ω : Ω) :=
  v t ω+mechanicalCorrection k₁ h w r r₁ t ω

/-- Actual mechanical SDE to error SDE. The v-equation is a Brownian stochastic
integral equation, while h and w satisfy the mechanical finite-variation ODEs.
Neither the transformed SDE nor its drift cancellation is assumed. -/
theorem mechanical_sde_error_coordinates
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {B : ℝ≥0 → Ω → ℝ} (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    {a b v : ℝ≥0 → Ω → ℝ} {h w : ℝ → Ω → ℝ} {r r₁ r₂ : ℝ → ℝ}
    {H g α β k₀ k₁ k₂ κd v₀ c₀ : ℝ}
    (ham : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hac : ∀ ω, Continuous (fun t => a t ω))
    (hbc : ∀ ω, Continuous (fun t => b t ω))
    (hc₀ : ∀ ω, mechanicalCorrection k₁ h w r r₁ 0 ω=c₀)
    (dh : ∀ ω t, 0≤ t → HasDerivAt (fun s => h s ω)
      (heightRate (v (Real.toNNReal t) ω) (w t ω)) t)
    (dw : ∀ ω t, 0≤ t → HasDerivAt (fun s => w s ω)
      (fall H g β (h t ω) (v (Real.toNNReal t) ω) (w t ω)) t)
    (dr : ∀ t, 0≤ t → HasDerivAt r (r₁ t) t)
    (dr₁ : ∀ t, 0≤ t → HasDerivAt r₁ (r₂ t) t)
    (hcc : ∀ ω, ContinuousOn (fun t => mechanicalCorrectionRate H g β k₁ h w v r₁ r₂ t ω)
      (Icc (0:ℝ) T))
    (hh : ∀ t∈Icc 0 T, ∀ ω, h t ω≠0)
    (hH : ∀ t∈Icc 0 T, ∀ ω, H+h t ω≠0)
    (hb : ∀ t∈Icc 0 T, ∀ ω, b t ω=rise g α (h t ω) (v t ω) (w t ω)
      (robustInput H g α β (h t ω) (v t ω) (w t ω)
        (acceleration k₀ k₁ k₂ (h t ω-r t) (heightRate (v t ω) (w t ω)) (r₁ t) (r₂ t))
        κd (mechanicalZ k₁ h w v r r₁ t ω)))
    (hv : ∀ᵐ ω ∂μ, ∀ t∈Icc 0 T,
      v t ω=localItoProcess (μ:=μ) T hBm ham hac v₀ b t ω) :
    (∀ ω t, 0≤ t → HasDerivAt (fun s => h s ω-r s)
      (-k₁*(h t ω-r t)+mechanicalZ k₁ h w v r r₁ (Real.toNNReal t) ω/2) t) ∧
    (∀ᵐ ω ∂μ, ∀ t∈Icc 0 T,
      mechanicalZ k₁ h w v r r₁ t ω=
        localItoProcess (μ:=μ) T hBm ham hac (v₀+c₀)
          (fun s ω => b s ω+mechanicalCorrectionRate H g β k₁ h w v r₁ r₂ s ω) t ω) ∧
    (∀ t∈Icc 0 T, ∀ ω,
      b t ω+mechanicalCorrectionRate H g β k₁ h w v r₁ r₂ t ω=
        -2*k₀*(h t ω-r t)-k₂*mechanicalZ k₁ h w v r r₁ t ω-
          κd*((v t ω)^2/h t ω)^2*mechanicalZ k₁ h w v r r₁ t ω) := by
  have hcd (ω : Ω) (t : ℝ) (ht : 0≤ t) :
      HasDerivAt (fun s => mechanicalCorrection k₁ h w r r₁ s ω)
        (mechanicalCorrectionRate H g β k₁ h w v r₁ r₂ t ω) t := by
    exact (((dw ω t ht).neg.sub ((dr₁ t ht).const_mul 2)).add
      (((dh ω t ht).sub (dr t ht)).const_mul (2*k₁)))
  refine ⟨?_,ito_add_finite_variation T hBm ham hac hbc hc₀
    (fun ω t ht => hcd ω t ht.1) hcc hv,?_⟩
  · intro ω t ht
    convert! (dh ω t ht).sub (dr t ht) using 1
    simp only [mechanicalZ,mechanicalCorrection,Real.coe_toNNReal t ht,heightRate]
    ring
  · intro t ht ω
    rw [hb t ht ω]
    dsimp only [mechanicalCorrectionRate,mechanicalZ,mechanicalCorrection]
    simp only [Real.toNNReal_coe]
    have hid := mechanical_error_drift H g α β k₀ k₁ k₂ κd (h t ω) (v t ω) (w t ω)
      (r t) (r₁ t) (r₂ t) (hh t ht ω) (hH t ht ω)
    convert! hid using 1 <;> ring_nf

/-- Energy Itô decomposition starting from the original mechanical SDE.
The coordinate transformation and the Itô formula are both derived. -/
theorem mechanical_tracking_energy_ito
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    {a b v : ℝ≥0 → Ω → ℝ} {h w : ℝ → Ω → ℝ} {r r₁ r₂ : ℝ → ℝ}
    {H g α β k₀ k₁ k₂ κd σ v₀ c₀ : ℝ}
    (ham : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hac : ∀ ω, Continuous (fun t => a t ω))
    (hbc : ∀ ω, Continuous (fun t => b t ω))
    (hc₀ : ∀ ω, mechanicalCorrection k₁ h w r r₁ 0 ω=c₀)
    (dh : ∀ ω t, 0≤ t → HasDerivAt (fun s => h s ω)
      (heightRate (v (Real.toNNReal t) ω) (w t ω)) t)
    (dw : ∀ ω t, 0≤ t → HasDerivAt (fun s => w s ω)
      (fall H g β (h t ω) (v (Real.toNNReal t) ω) (w t ω)) t)
    (dr : ∀ t, 0≤ t → HasDerivAt r (r₁ t) t)
    (dr₁ : ∀ t, 0≤ t → HasDerivAt r₁ (r₂ t) t)
    (hcc : ∀ ω, ContinuousOn (fun t => mechanicalCorrectionRate H g β k₁ h w v r₁ r₂ t ω)
      (Icc (0:ℝ) T))
    (hh : ∀ t∈Icc 0 T, ∀ ω, h t ω≠0)
    (hH : ∀ t∈Icc 0 T, ∀ ω, H+h t ω≠0)
    (hb : ∀ t∈Icc 0 T, ∀ ω, b t ω=rise g α (h t ω) (v t ω) (w t ω)
      (robustInput H g α β (h t ω) (v t ω) (w t ω)
        (acceleration k₀ k₁ k₂ (h t ω-r t) (heightRate (v t ω) (w t ω)) (r₁ t) (r₂ t))
        κd (mechanicalZ k₁ h w v r r₁ t ω)))
    (hv : ∀ᵐ ω ∂μ, ∀ t∈Icc 0 T,
      v t ω=localItoProcess (μ:=μ) T hBm ham hac v₀ b t ω)
    (hBc : ∀ ω, Continuous (fun t => B t ω))
    (hbnewm : ∀ t, StronglyMeasurable[natFiltration hBm t]
      (fun ω => b t ω+mechanicalCorrectionRate H g β k₁ h w v r₁ r₂ t ω))
    (hbnewc : ∀ ω, Continuous
      (fun t : ℝ≥0 => b t ω+mechanicalCorrectionRate H g β k₁ h w v r₁ r₂ t ω))
    (hzc : ∀ ω, Continuous (fun t => mechanicalZ k₁ h w v r r₁ t ω))
    (ha : ∀ t∈Icc 0 T, ∀ ω, a t ω=σ*((v t ω)^2/h t ω)) :
    ∃ M : ℝ≥0 → Ω → ℝ,
      (∀ᵐ ω ∂μ, ∀ t∈Icc 0 T,
        trackingEnergy k₀ (h t ω-r t) (mechanicalZ k₁ h w v r r₁ t ω)=
          trackingEnergy k₀ (h 0 ω-r 0) (v₀+c₀)+
            (∫ s in Ioc 0 t,
              trackingGenerator k₀ k₁ k₂ κd σ (h s ω-r s)
                (mechanicalZ k₁ h w v r r₁ s ω) ((v s ω)^2/h s ω) ∂timeMeasure)+M t ω) ∧
      (∀ ω, Continuous (fun t => M t ω)) ∧
      IsLocalMartingale M (augFiltration (μ:=μ) hBm) μ := by
  obtain ⟨he,hz,hdrift⟩ := mechanical_sde_error_coordinates T hBm ham hac hbc hc₀
    dh dw dr dr₁ hcc hh hH hb hv
  exact tracking_energy_ito (e:=fun t ω => h t ω-r t)
    (z:=mechanicalZ k₁ h w v r r₁) (G:=fun t ω => (v t ω)^2/h t ω)
    (k₀:=k₀) (k₁:=k₁) (k₂:=k₂) (κd:=κd) (σ:=σ) (z₀:=v₀+c₀)
    hB T hBm hBc ham hac hbnewm hbnewc hzc he
    (fun t ht ω => ⟨ha t ht ω,hdrift t ht ω⟩) hz

/-- The localized generator inequality, derived from the mechanical gains. -/
theorem tracking_generator_le {k₀ k₁ k₂ κd σ κ e z G CG : ℝ}
    (hk₀ : 0≤ k₀) (hκ₁ : κ≤ k₁) (hκ₂ : κ≤ k₂) (hκd : 0≤κd)
    (hG : |G|≤ CG) :
    trackingGenerator k₀ k₁ k₂ κd σ e z G≤ -2*κ*trackingEnergy k₀ e z+σ^2*CG^2/8 := by
  have hsq : G^2≤ CG^2 := by nlinarith [sq_nonneg (CG-|G|),sq_abs G,abs_nonneg G]
  have hn := ChainFountain.nominal_decay (e:=e) (z:=z) hk₀ hκ₁ hκ₂
  have hnoise := mul_le_mul_of_nonneg_left hsq (sq_nonneg σ)
  have hd : 0≤κd*G^2*z^2 := by positivity
  dsimp [trackingGenerator,trackingEnergy,ChainFountain.errorEnergy] at *
  nlinarith

/-- An explicit absolute generator bound follows from energy and diffusion
bounds on the localization region; it need not be added as an assumption. -/
theorem tracking_generator_abs_le {k₀ k₁ k₂ κd σ e z G CV CG : ℝ}
    (hk₀ : 0≤ k₀) (hk₁ : 0≤ k₁) (hk₂ : 0≤ k₂) (hκd : 0≤κd)
    (hV : trackingEnergy k₀ e z≤ CV) (hG : |G|≤ CG) :
    |trackingGenerator k₀ k₁ k₂ κd σ e z G|≤
      2*(k₁+k₂+κd*CG^2)*CV+σ^2*CG^2/8 := by
  have hsq : G^2≤ CG^2 := by nlinarith [sq_nonneg (CG-|G|),sq_abs G,abs_nonneg G]
  have he : k₀*e^2≤2*CV := by dsimp [trackingEnergy] at hV; nlinarith [sq_nonneg z]
  have hz : z^2≤8*CV := by dsimp [trackingEnergy] at hV; nlinarith [mul_nonneg hk₀ (sq_nonneg e)]
  have h₁ := mul_le_mul_of_nonneg_left he hk₁
  have h₂ := mul_le_mul_of_nonneg_left hz hk₂
  have h₃a := mul_le_mul_of_nonneg_left hsq (sq_nonneg z)
  have h₃b := mul_le_mul_of_nonneg_left hz (sq_nonneg CG)
  have h₃ := mul_le_mul_of_nonneg_left (show G^2*z^2≤ CG^2*(8*CV) by nlinarith) hκd
  have hσ := mul_le_mul_of_nonneg_left hsq (sq_nonneg σ)
  have hcv : 0≤ CV := (by dsimp [trackingEnergy]; positivity : 0≤ trackingEnergy k₀ e z).trans hV
  have hpos : 0≤2*(k₁+k₂+κd*CG^2)*CV := by positivity
  have hD : 0≤ k₀*k₁*e^2+k₂*z^2/4+κd*G^2*z^2/4 := by positivity
  rw [abs_le]
  dsimp [trackingGenerator]
  constructor <;> nlinarith [sq_nonneg σ,mul_nonneg (sq_nonneg σ) (sq_nonneg G),
    mul_nonneg (sq_nonneg σ) (sq_nonneg CG)]

/-- The stopped energy estimate from the original mechanical Brownian SDE,
with the actual first physical exit, explicit generator bounds, and derived
martingale/integrability obligations. -/
theorem mechanical_stopped_energy_estimate
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    {a b v : ℝ≥0 → Ω → ℝ} {h w : ℝ → Ω → ℝ} {r r₁ r₂ : ℝ → ℝ}
    {H g α β k₀ k₁ k₂ κd σ v₀ c₀ : ℝ}
    (ham : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hac : ∀ ω, Continuous (fun t => a t ω))
    (hbc : ∀ ω, Continuous (fun t => b t ω))
    (hc₀ : ∀ ω, mechanicalCorrection k₁ h w r r₁ 0 ω=c₀)
    (dh : ∀ ω t, 0≤ t → HasDerivAt (fun s => h s ω)
      (heightRate (v (Real.toNNReal t) ω) (w t ω)) t)
    (dw : ∀ ω t, 0≤ t → HasDerivAt (fun s => w s ω)
      (fall H g β (h t ω) (v (Real.toNNReal t) ω) (w t ω)) t)
    (dr : ∀ t, 0≤ t → HasDerivAt r (r₁ t) t)
    (dr₁ : ∀ t, 0≤ t → HasDerivAt r₁ (r₂ t) t)
    (hcc : ∀ ω, ContinuousOn (fun t => mechanicalCorrectionRate H g β k₁ h w v r₁ r₂ t ω)
      (Icc (0:ℝ) T))
    (hh : ∀ t∈Icc 0 T, ∀ ω, h t ω≠0)
    (hH : ∀ t∈Icc 0 T, ∀ ω, H+h t ω≠0)
    (hb : ∀ t∈Icc 0 T, ∀ ω, b t ω=rise g α (h t ω) (v t ω) (w t ω)
      (robustInput H g α β (h t ω) (v t ω) (w t ω)
        (acceleration k₀ k₁ k₂ (h t ω-r t) (heightRate (v t ω) (w t ω)) (r₁ t) (r₂ t))
        κd (mechanicalZ k₁ h w v r r₁ t ω)))
    (hv : ∀ᵐ ω ∂μ, ∀ t∈Icc 0 T,
      v t ω=localItoProcess (μ:=μ) T hBm ham hac v₀ b t ω)
    (hBc : ∀ ω, Continuous (fun t => B t ω))
    (hbnewm : ∀ t, StronglyMeasurable[natFiltration hBm t]
      (fun ω => b t ω+mechanicalCorrectionRate H g β k₁ h w v r₁ r₂ t ω))
    (hbnewc : ∀ ω, Continuous
      (fun t : ℝ≥0 => b t ω+mechanicalCorrectionRate H g β k₁ h w v r₁ r₂ t ω))
    (hzc : ∀ ω, Continuous (fun t => mechanicalZ k₁ h w v r r₁ t ω))
    (ha : ∀ t∈Icc 0 T, ∀ ω, a t ω=σ*((v t ω)^2/h t ω))
    {h₀ w₀ R κ CV CG : ℝ} (hT : 0<T) (hR : 0<R)
    (hk₀ : 0≤ k₀) (hκ : 0≤κ) (hκ₁ : κ≤ k₁) (hκ₂ : κ≤ k₂) (hκd : 0≤κd)
    (hCV : 0≤ CV)
    (hState : StronglyAdapted (augFiltration (μ:=μ) hBm)
      (fun t ω => (h t ω,v t ω,w t ω)))
    (hStateC : ∀ ω, Continuous (fun t : ℝ≥0 => (h t ω,v t ω,w t ω)))
    (hState₀ : ∀ ω, (h 0 ω,v 0 ω,w 0 ω)=(h₀,v₀,w₀))
    (hGc : ∀ ω, Continuous (fun t : ℝ≥0 => (v t ω)^2/h t ω))
    (hVcap : ∀ t∈Icc 0 T, ∀ ω,
      (h t ω,v t ω,w t ω)∈Metric.closedBall (h₀,v₀,w₀) R →
        trackingEnergy k₀ (h t ω-r t) (mechanicalZ k₁ h w v r r₁ t ω)≤ CV)
    (hGcap : ∀ t∈Icc 0 T, ∀ ω,
      (h t ω,v t ω,w t ω)∈Metric.closedBall (h₀,v₀,w₀) R → |(v t ω)^2/h t ω|≤ CG)
    (t : ℝ≥0) :
    let X := fun (s:ℝ≥0) ω => (h s ω,v s ω,w s ω)
    let V := fun (s:ℝ≥0) ω => trackingEnergy k₀ (h s ω-r s) (mechanicalZ k₁ h w v r r₁ s ω)
    let τ := physicalExit X (h₀,v₀,w₀) R T
    (∫ ω, stoppedProcess V τ t ω ∂μ)+2*κ*(∫ ω, stoppedProcess (driftPath V) τ t ω ∂μ)≤
      trackingEnergy k₀ (h₀-r 0) (v₀+c₀)+σ^2*CG^2/8*
        (∫ ω, stoppedProcess (fun (s:ℝ≥0) (_:Ω) => (s:ℝ)) τ t ω ∂μ) := by
  let X := fun (s:ℝ≥0) ω => (h s ω,v s ω,w s ω)
  let E := fun (s:ℝ≥0) ω => h s ω-r s
  let Z := mechanicalZ k₁ h w v r r₁
  let G := fun (s:ℝ≥0) ω => (v s ω)^2/h s ω
  let V := fun (s:ℝ≥0) ω => trackingEnergy k₀ (E s ω) (Z s ω)
  let J := fun (s:ℝ≥0) ω => trackingGenerator k₀ k₁ k₂ κd σ (E s ω) (Z s ω) (G s ω)
  let ℱ := augFiltration (μ:=μ) hBm
  have hk₁ : 0≤ k₁ := hκ.trans hκ₁
  have hk₂ : 0≤ k₂ := hκ.trans hκ₂
  have hEm (s : ℝ≥0) : StronglyMeasurable[ℱ s] (E s) :=
    (hState s).fst.sub stronglyMeasurable_const
  have hZm (s : ℝ≥0) : StronglyMeasurable[ℱ s] (Z s) :=
    (hState s).snd.fst.add (((hState s).snd.snd.neg.sub stronglyMeasurable_const).add
      ((hEm s).const_mul (2*k₁)))
  have hGm (s : ℝ≥0) : StronglyMeasurable[ℱ s] (G s) :=
    ((hState s).snd.fst.pow 2).div (hState s).fst
  have hVm : StronglyAdapted ℱ V := fun s =>
    (((hEm s).pow 2).const_mul k₀ |>.div stronglyMeasurable_const).add
      (((hZm s).pow 2).div stronglyMeasurable_const)
  have hJm : StronglyAdapted ℱ J := fun s =>
    ((((hEm s).pow 2).const_mul (-k₀*k₁)).sub
      (((hZm s).pow 2).const_mul k₂ |>.div stronglyMeasurable_const) |>.sub
      ((((hGm s).pow 2).const_mul κd |>.mul ((hZm s).pow 2)).div stronglyMeasurable_const )).add (((hGm s).pow 2).const_mul (σ^2) |>.div stronglyMeasurable_const)
  have hrC : Continuous (fun s : ℝ≥0 => r s) :=
    (show ContinuousOn r (Ici 0) from fun s hs => (dr s hs).continuousAt.continuousWithinAt).comp_continuous NNReal.continuous_coe (fun s => s.coe_nonneg)
  have hEc (ω : Ω) : Continuous (fun s => E s ω) := (hStateC ω).fst.sub hrC
  have hVc : ∀ ω, Continuous (fun s => V s ω) := fun ω =>
    (((hEc ω).pow 2).const_mul k₀ |>.div_const 2).add (((hzc ω).pow 2).div_const 8)
  have hJc : ∀ ω, Continuous (fun s => J s ω) := fun ω =>
    ((((hEc ω).pow 2).const_mul (-k₀*k₁)).sub
      (((hzc ω).pow 2).const_mul k₂ |>.div_const 4) |>.sub
      ((((hGc ω).pow 2).const_mul κd |>.mul ((hzc ω).pow 2)).div_const 4 )).add (((hGc ω).pow 2).const_mul (σ^2) |>.div_const 8)
  have hh₀ (ω : Ω) : h 0 ω=h₀ := congrArg Prod.fst (hState₀ ω)
  have hv₀ (ω : Ω) : v 0 ω=v₀ := congrArg (fun x : ℝ×(ℝ×ℝ) => x.2.1) (hState₀ ω)
  have hV₀ (ω : Ω) : V 0 ω=trackingEnergy k₀ (h₀-r 0) (v₀+c₀) := by
    change trackingEnergy k₀ (h 0 ω-r 0) (v 0 ω+mechanicalCorrection k₁ h w r r₁ 0 ω)=_
    rw [hh₀,hv₀,hc₀]
  let CJ := 2*(k₁+k₂+κd*CG^2)*CV+σ^2*CG^2/8
  have hCJ : 0≤ CJ := by dsimp [CJ]; positivity
  have hVB (s : ℝ≥0) (hs : s∈Icc 0 T) (ω : Ω)
      (hmem : X s ω∈Metric.closedBall (h₀,v₀,w₀) R) : ‖V s ω‖≤ CV := by
    have hvpos : 0≤ V s ω := by dsimp [V,trackingEnergy]; positivity
    simpa only [Real.norm_eq_abs,abs_of_nonneg hvpos] using hVcap s hs ω hmem
  have hJB (s : ℝ≥0) (hs : s∈Icc 0 T) (ω : Ω)
      (hmem : X s ω∈Metric.closedBall (h₀,v₀,w₀) R) : ‖J s ω‖≤ CJ := by
    exact (Real.norm_eq_abs _).trans_le
      (tracking_generator_abs_le hk₀ hk₁ hk₂ hκd (hVcap s hs ω hmem) (hGcap s hs ω hmem))
  have hgen (s : ℝ≥0) (hs : s∈Icc 0 T) (ω : Ω)
      (hmem : X s ω∈Metric.closedBall (h₀,v₀,w₀) R) :
      J s ω≤ -2*κ*V s ω+σ^2*CG^2/8 :=
    tracking_generator_le hk₀ hκ₁ hκ₂ hκd (hGcap s hs ω hmem)
  obtain ⟨M,hIto,hMc,hMl⟩ := mechanical_tracking_energy_ito hB T hBm ham hac hbc hc₀
    dh dw dr dr₁ hcc hh hH hb hv hBc hbnewm hbnewc hzc ha
  have hIto' : ∀ᵐ ω ∂μ, ∀ s∈Icc 0 T,
      V s ω=trackingEnergy k₀ (h₀-r 0) (v₀+c₀)+driftPath J s ω+M s ω := by
    filter_upwards [hIto] with ω hω s hs
    simpa only [hh₀ ω] using! hω s hs
  exact physical_stopped_generator_expectation hState hStateC hState₀ hR hT
    hVm hVc hJm hJc hV₀ hCV hCJ hVB hJB hgen hMl hIto' t

end
end ChainFountainStochastic

/-
Copyright (c) 2026 Robert Martin. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Robert Martin
Adapted to arbitrary measurable Brownian processes for the chain-fountain companion.
Source: MathFin commit 61d945b970561fcce6996fac0a5f18a424eb851f.
-/


/-! # Arbitrarily early downward Brownian excursions

Normalized evaluations at times `(n+1)⁻²` all have the standard Gaussian law.
Their negative limsup event belongs to the Brownian germ sigma algebra. The
zero-one law and bounded convergence show that this event has probability one.
No independence between these overlapping evaluations is claimed or needed.

## Result

Public entry points include `brownianProbeTime`, `brownianProbe`, `brownianNegativeGerm`,
`brownianProbeTime_pos`.
-/


namespace ChainFountainStochastic.BrownianExcursions

open Set Filter MeasureTheory ProbabilityTheory
open scoped NNReal Topology

/-- The `n`-th probe time `(1/(n+1))^2`. -/
noncomputable def brownianProbeTime (n : ℕ) : ℝ≥0 := (1/((n : ℝ≥0)+1))^2

/-- The Brownian evaluation at `brownianProbeTime n`, normalized by the factor `n+1`. -/
noncomputable def brownianProbe (n : ℕ) (ω : ℝ≥0 → ℝ) : ℝ :=
  ((n : ℝ)+1)*brownian (brownianProbeTime n) ω

/-- The set of paths whose normalized probes `brownianProbe n` fall below `-1` for infinitely
many `n`. -/
def brownianNegativeGerm : Set (ℝ≥0 → ℝ) :=
  {ω | ∀ N : ℕ, ∃ n : ℕ, N ≤ n ∧ brownianProbe n ω < -1}

theorem brownianProbeTime_pos (n : ℕ) : 0 < brownianProbeTime n := by
  unfold brownianProbeTime
  positivity

theorem brownianProbeTime_tendsto : Tendsto brownianProbeTime atTop (𝓝 0) := by
  change Tendsto (fun n : ℕ => (1/((n : ℝ≥0)+1))^2) atTop (𝓝 0)
  simpa only [zero_pow (by norm_num : (2 : ℕ) ≠ 0)] using
    (tendsto_one_div_add_atTop_nhds_zero_nat (𝕜 := ℝ≥0)).pow 2

theorem brownianProbe_hasLaw (n : ℕ) :
    HasLaw (brownianProbe n) (gaussianReal 0 1) gaussianLimit := by
  have hh := gaussianReal_const_mul (hasLaw_brownian_eval (t := brownianProbeTime n)) ((n : ℝ)+1)
  have hv : (NNReal.mk (((n : ℝ)+1)^2) (sq_nonneg _))*brownianProbeTime n = 1 := by
    apply NNReal.coe_injective
    simp only [NNReal.coe_mul,NNReal.coe_mk,brownianProbeTime,NNReal.coe_pow,
      NNReal.coe_div,NNReal.coe_one,NNReal.coe_add,NNReal.coe_natCast]
    field_simp
  change HasLaw (fun ω => ((n : ℝ)+1)*brownian (brownianProbeTime n) ω)
      (gaussianReal 0 1) gaussianLimit
  simpa only [mul_zero,hv] using hh

theorem brownianNegativeGerm_tail (M : ℕ) :
    brownianNegativeGerm = {ω | ∀ N : ℕ, ∃ n : ℕ, max N M ≤ n ∧ brownianProbe n ω < -1} := by
  ext ω
  constructor
  · intro h N
    exact h (max N M)
  · intro h N
    obtain ⟨n,hn,hneg⟩ := h N
    exact ⟨n,(le_max_left _ _).trans hn,hneg⟩

theorem brownianNegativeGerm_measurable_germ :
    MeasurableSet[⨅ s > (0 : ℝ≥0), Filtration.natural brownian
      (fun t => (measurable_brownian t).stronglyMeasurable) s] brownianNegativeGerm := by
  rw [MeasurableSpace.measurableSet_iInf]
  intro s
  rw [MeasurableSpace.measurableSet_iInf]
  intro hs
  obtain ⟨M,hM⟩ := eventually_atTop.mp
    (brownianProbeTime_tendsto.eventually (Iio_mem_nhds hs))
  rw [brownianNegativeGerm_tail M]
  simp only [ofPred_forall,ofPred_exists]
  apply MeasurableSet.iInter
  intro N
  apply MeasurableSet.iUnion
  intro n
  by_cases hn : max N M ≤ n
  · simp only [hn,true_and]
    have hmn : M ≤ n := (le_max_right _ _).trans hn
    have hW := (Filtration.stronglyAdapted_natural
      (fun t => (measurable_brownian t).stronglyMeasurable) (brownianProbeTime n)).mono
        ((Filtration.natural brownian (fun t => (measurable_brownian t).stronglyMeasurable)).mono
          (hM n hmn).le)
    exact measurableSet_lt (hW.measurable.const_mul _) measurable_const
  · simp only [hn,false_and,ofPred_false]
    exact @MeasurableSet.empty _ (Filtration.natural brownian
      (fun t => (measurable_brownian t).stronglyMeasurable) s)

theorem brownianNegativeGerm_measurable : MeasurableSet brownianNegativeGerm := by
  have hle : (⨅ s > (0 : ℝ≥0), Filtration.natural brownian
      (fun t => (measurable_brownian t).stronglyMeasurable) s) ≤
      (inferInstance : MeasurableSpace (ℝ≥0 → ℝ)) :=
    (iInf_le_of_le (1 : ℝ≥0) (iInf_le_of_le (by norm_num : (0 : ℝ≥0) < 1) le_rfl)).trans
      ((Filtration.natural brownian (fun t => (measurable_brownian t).stronglyMeasurable)).le 1)
  exact hle _ brownianNegativeGerm_measurable_germ

/-- The continuous test function `max 0 (min 1 (-x-1))`, valued in `[0,1]` and zero on
`-1 ≤ x`. -/
noncomputable def negativeProbeTest (x : ℝ) : ℝ := max 0 (min 1 (-x-1))

theorem negativeProbeTest_continuous : Continuous negativeProbeTest := by
  unfold negativeProbeTest
  fun_prop

theorem negativeProbeTest_bounds (x : ℝ) : 0 ≤ negativeProbeTest x ∧ negativeProbeTest x ≤ 1 :=
  ⟨le_max_left _ _,max_le (by norm_num) (min_le_left _ _)⟩

theorem negativeProbeTest_zero {x : ℝ} (hx : -1 ≤ x) : negativeProbeTest x = 0 := by
  unfold negativeProbeTest
  rw [max_eq_left]
  exact (min_le_right _ _).trans (by linarith)

theorem negativeProbeTest_integral_pos : 0 < ∫ x, negativeProbeTest x ∂gaussianReal 0 1 := by
  letI : (gaussianReal 0 1).IsOpenPosMeasure :=
    (gaussianReal_absolutelyContinuous' 0 (by norm_num : (1 : ℝ≥0) ≠ 0)).isOpenPosMeasure
  have hi : Integrable negativeProbeTest (gaussianReal 0 1) :=
    (integrable_const (1 : ℝ)).mono_nonneg negativeProbeTest_continuous.aestronglyMeasurable
      (Eventually.of_forall (fun x => (negativeProbeTest_bounds x).1))
      (Eventually.of_forall (fun x => (negativeProbeTest_bounds x).2))
  exact integral_pos_of_integrable_nonneg_nonzero negativeProbeTest_continuous hi
    (fun x ↦ (negativeProbeTest_bounds x).1)
    (by norm_num [negativeProbeTest] : negativeProbeTest (-2) ≠ 0)

theorem brownianNegativeGerm_prob_one : gaussianLimit brownianNegativeGerm = 1 := by
  rcases isBrownianReal_brownian.indep_zero measurable_brownian continuous_brownian
    brownianNegativeGerm_measurable_germ with hz | ho
  · have hae : ∀ᵐ ω ∂gaussianLimit, ω ∉ brownianNegativeGerm := by
      rw [ae_iff]
      simpa only [not_not,ofPred_mem_eq] using hz
    have hlim : ∀ᵐ ω ∂gaussianLimit,
        Tendsto (fun n => negativeProbeTest (brownianProbe n ω)) atTop (𝓝 0) := by
      filter_upwards [hae] with ω hω
      have hnot : ¬ ∀ N : ℕ, ∃ n : ℕ, N ≤ n ∧ brownianProbe n ω < -1 := hω
      push Not at hnot
      obtain ⟨N,hN⟩ := hnot
      have he : (fun n => negativeProbeTest (brownianProbe n ω)) =ᶠ[atTop] fun _ => 0 := by
        filter_upwards [eventually_ge_atTop N] with n hn
        exact negativeProbeTest_zero (hN n hn)
      exact tendsto_const_nhds.congr' he.symm
    have hi : Tendsto (fun n => ∫ ω, negativeProbeTest (brownianProbe n ω) ∂gaussianLimit)
        atTop (𝓝 (∫ _ : (ℝ≥0 → ℝ), (0 : ℝ) ∂gaussianLimit)) := by
      apply tendsto_integral_of_dominated_convergence (fun _ => (1 : ℝ))
      · intro n
        exact (negativeProbeTest_continuous.measurable.comp
          ((measurable_brownian _).const_mul _)).aestronglyMeasurable
      · exact integrable_const 1
      · intro n
        apply Eventually.of_forall
        intro ω
        rw [Real.norm_eq_abs,abs_of_nonneg (negativeProbeTest_bounds _).1]
        exact (negativeProbeTest_bounds _).2
      · exact hlim
    have he (n : ℕ) : (∫ ω, negativeProbeTest (brownianProbe n ω) ∂gaussianLimit) =
        ∫ x, negativeProbeTest x ∂gaussianReal 0 1 :=
      (brownianProbe_hasLaw n).integral_comp negativeProbeTest_continuous.aestronglyMeasurable
    simp only [he,integral_zero] at hi
    have hzI : (∫ x, negativeProbeTest x ∂gaussianReal 0 1) = 0 :=
      tendsto_nhds_unique tendsto_const_nhds hi
    exact (negativeProbeTest_integral_pos.ne' hzI).elim
  · exact ho

theorem brownianNegativeGerm_ae : ∀ᵐ ω ∂gaussianLimit, ω ∈ brownianNegativeGerm :=
  (mem_ae_iff_prob_eq_one brownianNegativeGerm_measurable).mpr brownianNegativeGerm_prob_one

theorem brownian_downward_excursion_of_germ {ω : ℝ≥0 → ℝ}
    (hω : ω ∈ brownianNegativeGerm) (μ σ : ℝ) (hσ : 0 < σ)
    {δ : ℝ≥0} (hδ : 0 < δ) :
    ∃ t : ℝ≥0, 0 < t ∧ t < δ ∧ μ*(t : ℝ)+σ*brownian t ω < 0 := by
  have hd : Tendsto (fun n : ℕ => μ/((n : ℝ)+1)) atTop (𝓝 0) := by
    simpa only [mul_zero,mul_one_div] using
      (tendsto_one_div_add_atTop_nhds_zero_nat (𝕜 := ℝ)).const_mul μ
  obtain ⟨N,hN⟩ := eventually_atTop.mp
    ((brownianProbeTime_tendsto.eventually (Iio_mem_nhds hδ)).and
      (hd.eventually (Iio_mem_nhds hσ)))
  obtain ⟨n,hn,hneg⟩ := hω N
  obtain ⟨ht,hm⟩ := hN n hn
  refine ⟨brownianProbeTime n,brownianProbeTime_pos n,ht,?_⟩
  have hnp : 0 < (n : ℝ)+1 := by positivity
  have he : (μ*(brownianProbeTime n : ℝ)+σ*brownian (brownianProbeTime n) ω)*((n : ℝ)+1) =
      μ/((n : ℝ)+1)+σ*brownianProbe n ω := by
    simp only [brownianProbeTime,NNReal.coe_pow,NNReal.coe_div,NNReal.coe_one,
      NNReal.coe_add,NNReal.coe_natCast,brownianProbe]
    field_simp
  apply (mul_lt_mul_iff_left₀ hnp).mp
  rw [he,zero_mul]
  nlinarith [mul_lt_mul_of_pos_left hneg hσ]

/-- One probability-one event supplies every fixed drift, positive volatility,
and positive time window. -/
theorem brownian_downward_excursions_ae : ∀ᵐ ω ∂gaussianLimit,
    ∀ μ σ : ℝ, 0 < σ → ∀ δ : ℝ≥0, 0 < δ →
      ∃ t : ℝ≥0, 0 < t ∧ t < δ ∧ μ*(t : ℝ)+σ*brownian t ω < 0 := by
  filter_upwards [brownianNegativeGerm_ae] with ω hω
  exact fun μ σ hσ _ hδ => brownian_downward_excursion_of_germ hω μ σ hσ hδ

/-- Countable raw-path event, suitable for transfer by the Brownian path law. -/
def negativeProbeEvent : Set (ℝ≥0 → ℝ) :=
  {f | ∀ N : ℕ, ∃ n : ℕ, N≤ n ∧ ((n:ℝ)+1)*f (brownianProbeTime n) < -1}

theorem negativeProbeEvent_measurable : MeasurableSet negativeProbeEvent := by
  unfold negativeProbeEvent
  measurability

/-- A proved excursion event for an arbitrary Brownian process on an arbitrary
probability space. The proof uses the zero-one law and Gaussian marginals,
not the incomplete external iterated-logarithm module. -/
theorem negativeProbes_ae {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) :
    ∀ᵐ ω ∂μ, (fun t => B t ω)∈negativeProbeEvent := by
  have hp : Measurable (fun f : ℝ≥0 → ℝ => f∈negativeProbeEvent) :=
    measurableSet_setOfPred.mp negativeProbeEvent_measurable
  have hraw : ∀ᵐ f ∂gaussianLimit, f∈negativeProbeEvent :=
    (hasLaw_brownian.ae_iff hp).mp brownianNegativeGerm_ae
  exact ((hB.hasLaw_gaussianLimit (measurable_pi_lambda _ hBm).aemeasurable).ae_iff hp).mpr hraw

theorem raw_downward_excursion {f : ℝ≥0 → ℝ} (hf : f∈negativeProbeEvent)
    (drift σ : ℝ) (hσ : 0<σ) {δ : ℝ≥0} (hδ : 0<δ) :
    ∃ t : ℝ≥0, 0<t ∧ t<δ ∧ drift*(t:ℝ)+σ*f t<0 := by
  have hd : Tendsto (fun n : ℕ => drift/((n:ℝ)+1)) atTop (𝓝 0) := by
    simpa only [mul_zero,mul_one_div] using
      (tendsto_one_div_add_atTop_nhds_zero_nat (𝕜:=ℝ)).const_mul drift
  obtain ⟨N,hN⟩ := eventually_atTop.mp
    ((brownianProbeTime_tendsto.eventually (Iio_mem_nhds hδ)).and
      (hd.eventually (Iio_mem_nhds hσ)))
  obtain ⟨n,hn,hneg⟩ := hf N
  obtain ⟨ht,hm⟩ := hN n hn
  refine ⟨brownianProbeTime n,brownianProbeTime_pos n,ht,?_⟩
  have hnp : 0<(n:ℝ)+1 := by positivity
  have he : (drift*(brownianProbeTime n:ℝ)+σ*f (brownianProbeTime n))*((n:ℝ)+1)=
      drift/((n:ℝ)+1)+σ*(((n:ℝ)+1)*f (brownianProbeTime n)) := by
    simp only [brownianProbeTime,NNReal.coe_pow,NNReal.coe_div,NNReal.coe_one,
      NNReal.coe_add,NNReal.coe_natCast]
    field_simp
  apply (mul_lt_mul_iff_left₀ hnp).mp
  rw [he,zero_mul]
  nlinarith [mul_lt_mul_of_pos_left hneg hσ]

/-- Every pathwise O(t) perturbation of a positive multiple of Brownian motion
has negative values arbitrarily soon. The quantifier over perturbations is
inside one probability-one event, so random drift bounds are permitted. -/
theorem brownian_bounded_drift_excursions {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) :
    ∀ᵐ ω ∂μ, ∀ σ : ℝ, 0<σ → ∀ A : ℝ≥0 → ℝ, ∀ K : ℝ,
      ∀ δ : ℝ≥0, 0<δ → (∀ t∈Icc 0 δ, A t≤ K*t) →
        ∀ ε : ℝ≥0, 0<ε → ∃ t : ℝ≥0, 0<t ∧ t<ε ∧ t<δ ∧ A t+σ*B t ω<0 := by
  filter_upwards [negativeProbes_ae hB hBm] with ω hω
  intro σ hσ A K δ hδ hA ε hε
  obtain ⟨t,ht,htm,hn⟩ := raw_downward_excursion hω K σ hσ (lt_min hε hδ)
  have hte := htm.trans_le (min_le_left _ _)
  have htd := htm.trans_le (min_le_right _ _)
  exact ⟨t,ht,hte,htd,by linarith [hA t ⟨ht.le,htd.le⟩]⟩

end ChainFountainStochastic.BrownianExcursions

/-
Copyright (c) 2026 Raphael Coelho. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors of adapted upstream proofs: Raphael Coelho.

Modified: simultaneous-in-time drift identity, continuous strong realization
and actual trajectory coefficient composition.
Drift uniform-convergence argument adapted from Raphael Coelho's
MathFin.Foundations.ItoIntegralProcessContinuousModification and
MathFin.Foundations.DriftProcessModification, Apache 2.0,
commit 61d945b970561fcce6996fac0a5f18a424eb851f.
-/
namespace ChainFountainStochastic.SDEContinuous
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology
open scoped NNReal ENNReal
open MathFin MathFin.SDEExistence MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM
  MathFin.ItoIntegralProcess MathFin.ItoIntegralProcessGeneral
  MathFin.ItoIntegralProcessContinuousModification


variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}

/-- Coefficients are the actual pointwise composition, as predictable L2 classes. -/
theorem lipComp_coe (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    {f : ℝ → ℝ} {L : ℝ≥0} (hf : LipschitzWith L f)
    (X : Lp ℝ 2 (trimMeasure_T (μ := μ) T hBm)) :
    ⇑(lipComp T hBm f L hf X) =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => f (X z) := by
  filter_upwards [Lp.coeFn_add (Lp.const 2 (trimMeasure_T (μ:=μ) T hBm) (f 0))
    ((lipschitz_sub_const hf).compLp (by simp) X),
    Lp.coeFn_const (p:=2) (μ:=trimMeasure_T (μ:=μ) T hBm) (c:=f 0),
    (lipschitz_sub_const hf).coeFn_compLp (by simp) X] with z ha hc hx
  change ⇑(Lp.const 2 (trimMeasure_T (μ:=μ) T hBm) (f 0) + (lipschitz_sub_const hf).compLp (by simp) X) z = _
  rw [ha,Pi.add_apply,hc,hx]
  dsimp only [Function.const_apply,Function.comp_apply]
  ring

/-- Transfer a predictable product-null equality to almost every path. -/
theorem ae_path_of_trim_eq (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    {f g : ℝ≥0 × Ω → ℝ} (he : f =ᵐ[trimMeasure_T (μ:=μ) T hBm] g) :
    ∀ᵐ ω ∂μ, ∀ᵐ s ∂timeMeasure_T T, f (s,ω)=g (s,ω) := by
  have hp : f =ᵐ[(timeMeasure_T T).prod μ] g :=
    ae_of_ae_trim (natFiltration hBm).predictable_le_prod he
  exact Measure.ae_ae_of_ae_prod (Measure.measurePreserving_swap.quasiMeasurePreserving.ae hp)

/-- Uniform control of consecutive elementary drifts. -/
theorem drift_consecutive_norm_le (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (V : ℕ → TBoundedSP T hBm) (ω : Ω) {t : ℝ≥0} (ht : t ≤ T) (a : ℕ) :
    ‖driftSimpleProcess hBm (V a).val t ω - driftSimpleProcess hBm (V (a+1)).val t ω‖
      ≤ ⨆ j : Iic T, |driftSimpleProcess hBm (V a - V (a+1)).val (j:ℝ≥0) ω| := by
  have hc : ((V a - V (a+1)).val : SimpleProcess ℝ (natFiltration hBm)) =
      (V a).val - (V (a+1)).val := rfl
  rw [show driftSimpleProcess hBm (V a).val t ω - driftSimpleProcess hBm (V (a+1)).val t ω
      = driftSimpleProcess hBm (V a - V (a+1)).val t ω by
        rw [hc]; exact (congrFun (driftSimpleProcess_sub hBm (V a).val (V (a+1)).val t) ω).symm,
      Real.norm_eq_abs]
  exact drift_norm_le_iSup_Iic hBm (V a - V (a+1)).val ω ht

/-- The predictable drift realization has continuous paths on one full-measure event. -/
theorem drift_mod_continuousOn (T : ℝ≥0) (hBmeas : ∀ t, Measurable (B t))
    (φ : Lp ℝ 2 (trimMeasure_T (μ := μ) T hBmeas)) :
    ∀ᵐ ω ∂μ, ContinuousOn (fun t ↦ driftContinuousMod T hBmeas φ t ω) (Set.Icc 0 T) := by
  set V := (approxSeq T hBmeas φ).choose with hVdef
  have hV := (approxSeq T hBmeas φ).choose_spec
  filter_upwards [drift_ae_eventually_sup_lt T hBmeas φ V hV,
    driftContinuousMod_tendsto T hBmeas φ] with ω hω htends
  rw [show (Set.Icc 0 T : Set ℝ≥0) = Set.Iic T from by
    ext x; simp only [Set.mem_Icc, Set.mem_Iic, zero_le, true_and]]
  obtain ⟨N, hN⟩ := eventually_atTop.mp hω
  have huniform : TendstoUniformlyOn (fun n t ↦ driftSimpleProcess hBmeas (V n).val t ω)
      (fun t ↦ driftContinuousMod T hBmeas φ t ω) atTop (Set.Iic T) := by
    rw [Metric.tendstoUniformlyOn_iff]
    intro ε hε
    have htend0 : Tendsto (fun n ↦ 4 * (3 / 4 : ℝ) ^ n) atTop (𝓝 0) := by
      rw [show (0 : ℝ) = 4 * 0 from by ring]
      exact (tendsto_pow_atTop_nhds_zero_of_lt_one (by norm_num) (by norm_num)).const_mul 4
    filter_upwards [eventually_ge_atTop N, htend0.eventually_lt_const hε] with n hn hnε
    intro t ht
    rw [Set.mem_Iic] at ht
    rw [dist_comm]
    -- the uniform bound: dist (fₙ t ω) (X t ω) ≤ 4·(3/4)ⁿ
    have htendsto : Tendsto (fun k ↦ driftSimpleProcess hBmeas (V (k + n)).val t ω) atTop
        (𝓝 (driftContinuousMod T hBmeas φ t ω)) := (htends t ht).comp (tendsto_add_atTop_nat n)
    have hstep : ∀ k, dist (driftSimpleProcess hBmeas (V (k + n)).val t ω)
        (driftSimpleProcess hBmeas (V (k + 1 + n)).val t ω) ≤ (3 / 4 : ℝ) ^ n * (3 / 4 : ℝ) ^ k := by
      intro k
      rw [show k + 1 + n = (k + n) + 1 from by ring, dist_eq_norm]
      refine (drift_consecutive_norm_le T hBmeas V ω ht (k + n)).trans ?_
      exact (hN (k + n) (hn.trans (Nat.le_add_left n k))).le.trans
        (le_of_eq (by rw [pow_add]; ring))
    have h0 :=
      dist_le_of_le_geometric_of_tendsto₀ (3 / 4) ((3 / 4 : ℝ) ^ n) (by norm_num) hstep htendsto
    simp only [zero_add] at h0
    refine lt_of_le_of_lt (h0.trans (le_of_eq ?_)) hnε
    rw [show (1 : ℝ) - 3 / 4 = 1 / 4 from by norm_num]; ring
  have hcont : ∀ᶠ n in atTop,
      ContinuousOn (fun t ↦ driftSimpleProcess hBmeas (V n).val t ω) (Set.Iic T) :=
    Eventually.of_forall fun n ↦
      (driftSimpleProcess_continuous hBmeas (V n).val ω).continuousOn
  exact huniform.continuousOn hcont.frequently

/-- The drift integral identity holds at every time on one probability-one event. -/
theorem drift_mod_integral_all_times (T : ℝ≥0) (hBmeas : ∀ t, Measurable (B t))
    (g : Lp ℝ 2 (trimMeasure_T (μ := μ) T hBmeas)) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → driftContinuousMod T hBmeas g t ω
      = ∫ s in Set.Ioc (0 : ℝ≥0) t, ⇑g (s, ω) ∂timeMeasure := by
  set V := (approxSeq T hBmeas g).choose with hVdef
  have hV := (approxSeq T hBmeas g).choose_spec
  have hg_prod : MemLp (⇑g) 2 ((timeMeasure_T T).prod μ) :=
    ⟨aestronglyMeasurable_of_aestronglyMeasurable_trim (natFiltration hBmeas).predictable_le_prod
      (Lp.aestronglyMeasurable g),
     by rw [← eLpNorm_trim_ae (natFiltration hBmeas).predictable_le_prod
         (Lp.aestronglyMeasurable g)]
        exact (Lp.memLp g).2⟩
  have hg_slice : ∀ᵐ ω ∂μ, MemLp (fun s ↦ ⇑g (s, ω)) 2 (timeMeasure_T T) := by
    filter_upwards [hg_prod.1.prodMk_right, hg_prod.integrable_sq.prod_left_ae] with ω hω1 hω2
    exact (memLp_two_iff_integrable_sq hω1).mpr hω2
  -- the ω-slice energy and its L¹(μ) decay
  set D : ℕ → Ω → ℝ := fun n ω ↦
    ∫ s in Set.Ioc (0 : ℝ≥0) T, (⇑(V n).val s ω - ⇑g (s, ω)) ^ 2 ∂timeMeasure with hDdef
  have hDnn : ∀ n, 0 ≤ᵐ[μ] D n := fun n ↦ ae_of_all _ fun ω ↦ integral_nonneg fun s ↦ sq_nonneg _
  have hDint : ∀ n, Integrable (D n) μ :=
    fun n ↦ (drift_slice_sq_integrable T hBmeas g (V n)).integral_prod_right
  have hD0 : Tendsto (fun n ↦ ∫ ω, D n ω ∂μ) atTop (𝓝 0) := by
    have heq : ∀ n, (∫ ω, D n ω ∂μ) = ‖simpleAssembly_T (μ := μ) T hBmeas (V n) - g‖ ^ 2 :=
      fun n ↦ drift_slice_energy_eq T hBmeas g (V n)
    simp_rw [heq]
    have h0 : Tendsto (fun n ↦ ‖simpleAssembly_T (μ := μ) T hBmeas (V n) - g‖) atTop (𝓝 0) :=
      squeeze_zero (fun n ↦ norm_nonneg _) hV
        (tendsto_pow_atTop_nhds_zero_of_lt_one (by norm_num) (by norm_num))
    simpa using h0.pow 2
  -- L¹ decay ⟹ convergence in measure ⟹ a.e.-convergent subsequence
  have hDeLp : Tendsto (fun n ↦ eLpNorm (D n - fun _ ↦ (0 : ℝ)) 1 μ) atTop (𝓝 0) := by
    have hrw : ∀ n, eLpNorm (D n - fun _ ↦ (0 : ℝ)) 1 μ = ENNReal.ofReal (∫ ω, D n ω ∂μ) := by
      intro n
      have hsub : (D n - fun _ ↦ (0 : ℝ)) = D n := by funext ω; simp
      have hlint : (∫⁻ ω, ‖D n ω‖ₑ ∂μ) = ∫⁻ ω, ENNReal.ofReal (D n ω) ∂μ := by
        refine lintegral_congr_ae ?_
        filter_upwards [hDnn n] with ω hω
        rw [Real.enorm_eq_ofReal_abs, abs_of_nonneg hω]
      rw [hsub, eLpNorm_one_eq_lintegral_enorm, hlint,
        ← ofReal_integral_eq_lintegral_ofReal (hDint n) (hDnn n)]
    rw [tendsto_congr hrw, ← ENNReal.ofReal_zero]
    exact (ENNReal.continuous_ofReal.tendsto 0).comp hD0
  have hDmeasure : TendstoInMeasure μ D atTop (fun _ ↦ (0 : ℝ)) :=
    tendstoInMeasure_of_tendsto_eLpNorm one_ne_zero (fun n ↦ (hDint n).aestronglyMeasurable)
      aestronglyMeasurable_const hDeLp
  obtain ⟨ns, hns_mono, hns_ae⟩ := hDmeasure.exists_seq_tendsto_ae
  -- combine, a.e. ω
  filter_upwards [hns_ae, hg_slice, driftContinuousMod_tendsto T hBmeas g] with ω hωD hωg hωlim
  intro t ht
  haveI : IsFiniteMeasure (timeMeasure.restrict (Set.Ioc (0 : ℝ≥0) t)) :=
    ⟨by rw [Measure.restrict_apply_univ, timeMeasure_Ioc]; exact ENNReal.ofReal_lt_top⟩
  have hlim_sub : Tendsto (fun k ↦ driftSimpleProcess hBmeas (V (ns k)).val t ω) atTop
      (𝓝 (driftContinuousMod T hBmeas g t ω)) := (hωlim t ht).comp hns_mono.tendsto_atTop
  have hlim_int : Tendsto (fun k ↦ driftSimpleProcess hBmeas (V (ns k)).val t ω) atTop
      (𝓝 (∫ s in Set.Ioc (0 : ℝ≥0) t, ⇑g (s, ω) ∂timeMeasure)) := by
    rw [tendsto_iff_dist_tendsto_zero]
    refine squeeze_zero (fun k ↦ dist_nonneg) (fun k ↦ ?_)
      (g := fun k ↦ Real.sqrt ((T : ℝ) * D (ns k) ω)) ?_
    · -- dist bound via interval Cauchy–Schwarz
      have hVt : MemLp (fun s ↦ ⇑(V (ns k)).val s ω) 2 (timeMeasure.restrict (Set.Ioc 0 t)) :=
        (memLp_slice T hBmeas (V (ns k)).val ω).mono_measure
          (Measure.restrict_mono (Set.Ioc_subset_Ioc_right ht) le_rfl)
      have hgt : MemLp (fun s ↦ ⇑g (s, ω)) 2 (timeMeasure.restrict (Set.Ioc 0 t)) :=
        hωg.mono_measure (Measure.restrict_mono (Set.Ioc_subset_Ioc_right ht) le_rfl)
      have hfT : MemLp (fun s ↦ ⇑(V (ns k)).val s ω - ⇑g (s, ω)) 2
          (timeMeasure.restrict (Set.Ioc (0 : ℝ≥0) T)) :=
        (memLp_slice T hBmeas (V (ns k)).val ω).sub hωg
      rw [Real.dist_eq, ← Real.sqrt_sq_eq_abs]
      refine Real.sqrt_le_sqrt ?_
      rw [driftSimpleProcess_eq_setIntegral,
        ← integral_sub (hVt.integrable (by norm_num)) (hgt.integrable (by norm_num))]
      calc (∫ s in Set.Ioc (0 : ℝ≥0) t, (⇑(V (ns k)).val s ω - ⇑g (s, ω)) ∂timeMeasure) ^ 2
          ≤ (timeMeasure.restrict (Set.Ioc (0 : ℝ≥0) t)).real Set.univ
              * ∫ s in Set.Ioc (0 : ℝ≥0) t, (⇑(V (ns k)).val s ω - ⇑g (s, ω)) ^ 2 ∂timeMeasure :=
            sq_integral_le_measureReal_mul (hVt.sub hgt)
        _ ≤ (T : ℝ) * D (ns k) ω := by
            rw [measureReal_def, Measure.restrict_apply_univ, timeMeasure_Ioc,
              ENNReal.toReal_ofReal (by rw [NNReal.coe_zero, sub_zero]; exact t.coe_nonneg),
              NNReal.coe_zero, sub_zero]
            refine mul_le_mul (by exact_mod_cast ht) ?_ (integral_nonneg fun s ↦ sq_nonneg _)
              T.coe_nonneg
            exact setIntegral_mono_set hfT.integrable_sq (ae_of_all _ fun s ↦ sq_nonneg _)
              (Set.Ioc_subset_Ioc_right ht).eventuallyLE
    · rw [← Real.sqrt_zero, ← mul_zero (T : ℝ)]
      exact (Real.continuous_sqrt.tendsto _).comp (tendsto_const_nhds.mul hωD)
  exact tendsto_nhds_unique hlim_sub hlim_int

/-- Both continuous integral realizations start at zero, path by path. -/
theorem integral_mod_zero (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (φ : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) (ω : Ω) :
    driftContinuousMod T hBm φ 0 ω = 0 ∧ itoContinuousMod T hBm φ 0 ω = 0 := by
  constructor
  · simpa [driftContinuousMod,driftSimpleProcess] using
      (tendsto_const_nhds : Tendsto (fun _ : ℕ => (0:ℝ)) atTop (𝓝 0)).limUnder_eq
  · simpa [itoContinuousMod,itoSimpleProcess_apply] using
      (tendsto_const_nhds : Tendsto (fun _ : ℕ => (0:ℝ)) atTop (𝓝 0)).limUnder_eq

/-- Strong finite-horizon solution with the actual trajectory coefficients.
Continuity and the integral identity hold for all times on a single conull event.
The stochastic integral is the constructed predictable-L2 Ito integral. -/
structure ScalarStrongSolution (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (b σ : ℝ → ℝ) (x₀ : ℝ) (Y : ℝ≥0 → Ω → ℝ) : Prop where
  predictable : IsStronglyPredictable (natFiltration hBm) Y
  continuous : ∀ᵐ ω ∂μ, ContinuousOn (fun t => Y t ω) (Icc 0 T)
  initial : ∀ ω, Y 0 ω = x₀
  state_memLp : MemLp (Function.uncurry Y) 2 (trimMeasure_T (μ:=μ) T hBm)
  drift_memLp : MemLp (fun z : ℝ≥0 × Ω => b (Y z.1 z.2)) 2 (trimMeasure_T (μ:=μ) T hBm)
  diffusion_memLp : MemLp (fun z : ℝ≥0 × Ω => σ (Y z.1 z.2)) 2 (trimMeasure_T (μ:=μ) T hBm)
  equation : ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T →
    Y t ω = x₀ + (∫ s in Ioc (0:ℝ≥0) t, b (Y s ω) ∂timeMeasure) +
      itoContinuousMod T hBm (diffusion_memLp.toLp (fun z => σ (Y z.1 z.2))) t ω

set_option backward.isDefEq.respectTransparency true in
set_option maxHeartbeats 400000 in
/-- Realize any Picard fixed point as a continuous adapted strong solution.
In particular, composition is proved for the new trajectory, rather than
silently identifying an arbitrary representative of the L2 class with it. -/
theorem realize_picard_fixed_point (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {b σ : ℝ → ℝ} {Lb Lσ : ℝ≥0} (hb : LipschitzWith Lb b) (hσ : LipschitzWith Lσ σ)
    (x₀ : ℝ) (X : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm))
    (hfix : picardMap hB T hBm hBc hb hσ (Lp.const 2 _ x₀) X = X) :
    ∃ Y : ℝ≥0 → Ω → ℝ, ScalarStrongSolution (μ:=μ) T hBm b σ x₀ Y ∧
      ⇑X =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry Y := by
  let φ := lipComp T hBm b Lb hb X
  let ψ := lipComp T hBm σ Lσ hσ X
  let Y : ℝ≥0 → Ω → ℝ := fun t ω =>
    x₀ + driftContinuousMod T hBm φ t ω + itoContinuousMod T hBm ψ t ω
  have hI : ⇑(itoProcessAssembled hB T hBm hBc ψ)
      =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry (itoContinuousMod T hBm ψ) :=
    (memLp_itoContinuousMod hB T hBm hBc ψ).coeFn_toLp
  have hX : ⇑X =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry Y := by
    have he : ⇑(picardMap hB T hBm hBc hb hσ (Lp.const 2 _ x₀) X)
        =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry Y := by
      filter_upwards [Lp.coeFn_add
        (Lp.const 2 _ x₀ + driftProcessAssembled (μ:=μ) T hBm φ)
        (itoProcessAssembled hB T hBm hBc ψ),
        Lp.coeFn_add (Lp.const 2 _ x₀) (driftProcessAssembled (μ:=μ) T hBm φ),
        Lp.coeFn_const (p:=2) (μ:=trimMeasure_T (μ:=μ) T hBm) (c:=x₀),
        driftProcessAssembled_coeFn T hBm φ,
        hI] with z h1 h2 h0 hd hi
      change (Lp.const 2 (trimMeasure_T (μ:=μ) T hBm) x₀ +
        driftProcessAssembled (μ:=μ) T hBm φ +
        itoProcessAssembled hB T hBm hBc ψ : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) z = Y z.1 z.2
      simp only [h1,h2,h0,hd,hi,Pi.add_apply,Function.const_apply,Y,Function.uncurry]
    rwa [hfix] at he
  have hφ : ⇑φ =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => b (Y z.1 z.2) := by
    filter_upwards [lipComp_coe T hBm hb X,hX] with z hc hz
    exact hc.trans (congrArg b hz)
  have hψ : ⇑ψ =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => σ (Y z.1 z.2) := by
    filter_upwards [lipComp_coe T hBm hσ X,hX] with z hc hz
    exact hc.trans (congrArg σ hz)
  have hYm : MemLp (Function.uncurry Y) 2 (trimMeasure_T (μ:=μ) T hBm) := (Lp.memLp X).ae_eq hX
  have hφm : MemLp (fun z : ℝ≥0 × Ω => b (Y z.1 z.2)) 2 (trimMeasure_T (μ:=μ) T hBm) := (Lp.memLp φ).ae_eq hφ
  have hψm : MemLp (fun z : ℝ≥0 × Ω => σ (Y z.1 z.2)) 2 (trimMeasure_T (μ:=μ) T hBm) := (Lp.memLp ψ).ae_eq hψ
  have hψclass : hψm.toLp (fun z : ℝ≥0 × Ω => σ (Y z.1 z.2)) = ψ := by
    exact (MemLp.toLp_congr hψm (Lp.memLp ψ) hψ.symm).trans
      (Lp.toLp_coeFn ψ (Lp.memLp ψ))
  refine ⟨Y,⟨?_,?_,?_,hYm,hφm,hψm,?_⟩,hX⟩
  · change StronglyMeasurable[(natFiltration hBm).predictable]
      (fun z : ℝ≥0 × Ω => x₀ + driftContinuousMod T hBm φ z.1 z.2 + itoContinuousMod T hBm ψ z.1 z.2)
    exact (stronglyMeasurable_const.add (driftContinuousMod_isStronglyPredictable T hBm φ)).add
      (itoContinuousMod_isStronglyPredictable hB T hBm hBc ψ)
  · filter_upwards [drift_mod_continuousOn T hBm φ,
      itoContinuousMod_continuousOn hB T hBm hBc ψ] with ω hd hi
    exact (continuousOn_const.add hd).add hi
  · intro ω
    dsimp only [Y]
    rw [(integral_mod_zero T hBm φ ω).1,(integral_mod_zero T hBm ψ ω).2]
    ring
  · rw [hψclass]
    filter_upwards [drift_mod_integral_all_times T hBm φ,ae_path_of_trim_eq T hBm hφ]
      with ω hd hc
    intro t ht
    change x₀ + driftContinuousMod T hBm φ t ω + itoContinuousMod T hBm ψ t ω = _
    rw [hd t ht]
    congr 2
    exact integral_congr_ae (hc.filter_mono
      (ae_mono (Measure.restrict_mono (Ioc_subset_Ioc_right ht) le_rfl)))

/-- A genuine scalar strong solution is constructed from Lipschitz coefficients
and deterministic initial data on every horizon in the contraction regime. -/
theorem exists_scalar_strong_solution (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {b σ : ℝ → ℝ} {Lb Lσ : ℝ≥0} (hb : LipschitzWith Lb b) (hσ : LipschitzWith Lσ σ)
    (x₀ : ℝ) (hc : (T:ℝ)*Lb + Real.sqrt (T:ℝ)*Lσ < 1) :
    ∃ Y : ℝ≥0 → Ω → ℝ, ScalarStrongSolution (μ:=μ) T hBm b σ x₀ Y := by
  obtain ⟨X,hX,hu⟩ := picardMap_exists_unique_fixedPoint hB T hBm hBc hb hσ
    (Lp.const 2 _ x₀) hc
  obtain ⟨Y,hY,hrep⟩ := realize_picard_fixed_point hB T hBm hBc hb hσ x₀ X hX
  exact ⟨Y,hY⟩

end
end ChainFountainStochastic.SDEContinuous

namespace ChainFountainStochastic.SDEContinuous
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology
open scoped NNReal ENNReal
open MathFin MathFin.SDEExistence MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM
  MathFin.ItoIntegralProcess MathFin.ItoIntegralProcessGeneral
  MathFin.ItoIntegralProcessContinuousModification
set_option backward.isDefEq.respectTransparency true
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}

/-- All-times equality of predictable processes induces equality of their L2 classes. -/
theorem trim_eq_of_ae_paths (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    {Y Z : ℝ≥0 → Ω → ℝ} (hY : IsStronglyPredictable (natFiltration hBm) Y)
    (hZ : IsStronglyPredictable (natFiltration hBm) Z)
    (he : ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = Z t ω) :
    Function.uncurry Y =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry Z := by
  have hYm : Measurable (Function.uncurry Y) :=
    hY.measurable.mono (natFiltration hBm).predictable_le_prod le_rfl
  have hZm : Measurable (Function.uncurry Z) :=
    hZ.measurable.mono (natFiltration hBm).predictable_le_prod le_rfl
  have hs : (fun z : Ω × ℝ≥0 => Y z.2 z.1) =ᵐ[μ.prod (timeMeasure_T T)]
      (fun z : Ω × ℝ≥0 => Z z.2 z.1) := by
    apply (Measure.ae_prod_iff_ae_ae
      (measurableSet_eq_fun (hYm.comp measurable_swap) (hZm.comp measurable_swap))).2
    filter_upwards [he] with ω hω
    filter_upwards [show ∀ᵐ t ∂timeMeasure_T T, t ∈ Ioc 0 T from
      ae_restrict_mem measurableSet_Ioc] with t ht
    exact hω t ht.2
  exact ae_eq_trim_of_measurable (natFiltration hBm).predictable_le_prod
    hY.measurable hZ.measurable
    (Measure.measurePreserving_swap.quasiMeasurePreserving.ae hs)

/-- The Picard operator has the stated continuous integral representative. -/
theorem picardMap_coe (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {b σ : ℝ → ℝ} {Lb Lσ : ℝ≥0} (hb : LipschitzWith Lb b) (hσ : LipschitzWith Lσ σ)
    (x₀ : ℝ) (X : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) :
    ⇑(picardMap hB T hBm hBc hb hσ (Lp.const 2 _ x₀) X)
      =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => x₀ +
      driftContinuousMod T hBm (lipComp T hBm b Lb hb X) z.1 z.2 +
      itoContinuousMod T hBm (lipComp T hBm σ Lσ hσ X) z.1 z.2 := by
  let φ := lipComp T hBm b Lb hb X
  let ψ := lipComp T hBm σ Lσ hσ X
  have hI : ⇑(itoProcessAssembled hB T hBm hBc ψ)
      =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry (itoContinuousMod T hBm ψ) :=
    (memLp_itoContinuousMod hB T hBm hBc ψ).coeFn_toLp
  filter_upwards [Lp.coeFn_add
    (Lp.const 2 _ x₀ + driftProcessAssembled (μ:=μ) T hBm φ)
    (itoProcessAssembled hB T hBm hBc ψ),
    Lp.coeFn_add (Lp.const 2 _ x₀) (driftProcessAssembled (μ:=μ) T hBm φ),
    Lp.coeFn_const (p:=2) (μ:=trimMeasure_T (μ:=μ) T hBm) (c:=x₀),
    driftProcessAssembled_coeFn T hBm φ,hI] with z h1 h2 h0 hd hi
  change (Lp.const 2 (trimMeasure_T (μ:=μ) T hBm) x₀ +
    driftProcessAssembled (μ:=μ) T hBm φ + itoProcessAssembled hB T hBm hBc ψ :
    Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) z = _
  simp only [h1,h2,h0,hd,hi,Pi.add_apply,Function.const_apply,Function.uncurry]
  rfl

/-- The integral identity determines the canonical Picard representative for every
strong solution, not only the solution constructed by Banach's theorem. -/
theorem ScalarStrongSolution.canonical_equation (_hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t))
    {b σ : ℝ → ℝ} {Lb Lσ : ℝ≥0} (hb : LipschitzWith Lb b) (hσ : LipschitzWith Lσ σ)
    (x₀ : ℝ) {Y : ℝ≥0 → Ω → ℝ} (hY : ScalarStrongSolution (μ:=μ) T hBm b σ x₀ Y) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = x₀ +
      driftContinuousMod T hBm (lipComp T hBm b Lb hb (hY.state_memLp.toLp (Function.uncurry Y))) t ω +
      itoContinuousMod T hBm (lipComp T hBm σ Lσ hσ (hY.state_memLp.toLp (Function.uncurry Y))) t ω := by
  let X := hY.state_memLp.toLp (Function.uncurry Y)
  let φ := lipComp T hBm b Lb hb X
  let ψ := lipComp T hBm σ Lσ hσ X
  have hφ : ⇑φ =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => b (Y z.1 z.2) := by
    filter_upwards [lipComp_coe T hBm hb X,hY.state_memLp.coeFn_toLp] with z hc hz
    exact hc.trans (congrArg b hz)
  have hψ : ⇑ψ =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => σ (Y z.1 z.2) := by
    filter_upwards [lipComp_coe T hBm hσ X,hY.state_memLp.coeFn_toLp] with z hc hz
    exact hc.trans (congrArg σ hz)
  have hψclass : hY.diffusion_memLp.toLp (fun z : ℝ≥0 × Ω => σ (Y z.1 z.2)) = ψ :=
    (MemLp.toLp_congr hY.diffusion_memLp (Lp.memLp ψ) hψ.symm).trans
      (Lp.toLp_coeFn ψ (Lp.memLp ψ))
  filter_upwards [hY.equation,drift_mod_integral_all_times T hBm φ,
    ae_path_of_trim_eq T hBm hφ] with ω he hd hc
  intro t ht
  change Y t ω = x₀ + driftContinuousMod T hBm φ t ω + itoContinuousMod T hBm ψ t ω
  rw [he t ht,hψclass,hd t ht]
  congr 2
  exact (integral_congr_ae (hc.filter_mono
    (ae_mono (Measure.restrict_mono (Ioc_subset_Ioc_right ht) le_rfl)))).symm

/-- Every square-integrable predictable strong solution is a Picard fixed point. -/
theorem ScalarStrongSolution.fixed_point (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {b σ : ℝ → ℝ} {Lb Lσ : ℝ≥0} (hb : LipschitzWith Lb b) (hσ : LipschitzWith Lσ σ)
    (x₀ : ℝ) {Y : ℝ≥0 → Ω → ℝ} (hY : ScalarStrongSolution (μ:=μ) T hBm b σ x₀ Y) :
    picardMap hB T hBm hBc hb hσ (Lp.const 2 _ x₀)
      (hY.state_memLp.toLp (Function.uncurry Y)) = hY.state_memLp.toLp (Function.uncurry Y) := by
  let X := hY.state_memLp.toLp (Function.uncurry Y)
  have hp : IsStronglyPredictable (natFiltration hBm) (fun t ω => x₀ +
      driftContinuousMod T hBm (lipComp T hBm b Lb hb X) t ω +
      itoContinuousMod T hBm (lipComp T hBm σ Lσ hσ X) t ω) :=
    (stronglyMeasurable_const.add (driftContinuousMod_isStronglyPredictable T hBm _)).add
      (itoContinuousMod_isStronglyPredictable hB T hBm hBc _)
  have he := trim_eq_of_ae_paths T hBm hY.predictable hp
    (hY.canonical_equation hB T hBm hb hσ x₀)
  exact Lp.ext ((picardMap_coe hB T hBm hBc hb hσ x₀ X).trans
    (he.symm.trans hY.state_memLp.coeFn_toLp.symm))

/-- Pathwise uniqueness on the whole horizon, on one probability-one event. -/
theorem scalar_strong_solution_unique (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {b σ : ℝ → ℝ} {Lb Lσ : ℝ≥0} (hb : LipschitzWith Lb b) (hσ : LipschitzWith Lσ σ)
    (x₀ : ℝ) (hc : (T:ℝ)*Lb + Real.sqrt (T:ℝ)*Lσ < 1)
    {Y Z : ℝ≥0 → Ω → ℝ} (hY : ScalarStrongSolution (μ:=μ) T hBm b σ x₀ Y)
    (hZ : ScalarStrongSolution (μ:=μ) T hBm b σ x₀ Z) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = Z t ω := by
  obtain ⟨X,hX,hu⟩ := picardMap_exists_unique_fixedPoint hB T hBm hBc hb hσ
    (Lp.const 2 _ x₀) hc
  have he : hY.state_memLp.toLp (Function.uncurry Y) = hZ.state_memLp.toLp (Function.uncurry Z) :=
    (hu _ (hY.fixed_point hB T hBm hBc hb hσ x₀)).trans
      (hu _ (hZ.fixed_point hB T hBm hBc hb hσ x₀)).symm
  filter_upwards [hY.canonical_equation hB T hBm hb hσ x₀,
    hZ.canonical_equation hB T hBm hb hσ x₀] with ω hy hz
  intro t ht
  rw [hy t ht,hz t ht,he]

/-- Locally, a positive contraction horizon always exists for finite Lipschitz constants. -/
theorem exists_positive_contraction_horizon (Lb Lσ : ℝ≥0) :
    ∃ T : ℝ≥0, 0 < T ∧ (T:ℝ)*Lb + Real.sqrt (T:ℝ)*Lσ < 1 := by
  have hq : Continuous (fun t : ℝ≥0 => (t:ℝ)*Lb + Real.sqrt (t:ℝ)*Lσ) := by fun_prop
  have hnear : ∀ᶠ t : ℝ≥0 in 𝓝 0, (t:ℝ)*Lb + Real.sqrt (t:ℝ)*Lσ < 1 :=
    (hq.tendsto 0).eventually (by simpa using (gt_mem_nhds (by norm_num : (0:ℝ)<1)))
  obtain ⟨ε,hε,hεq⟩ := Metric.eventually_nhds_iff.mp hnear
  let T : ℝ≥0 := ⟨ε/2,by positivity⟩
  refine ⟨T,?_,hεq ?_⟩
  · change (0:ℝ) < ε/2
    exact half_pos hε
  · change |ε/2-(0:ℝ)| < ε
    rw [sub_zero,abs_of_pos (half_pos hε)]
    linarith

/-- A scalar strong solution is constructed on a positive horizon and is unique
among all predictable square-integrable strong solutions on that horizon. -/
theorem exists_unique_local_scalar_strong_solution (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {b σ : ℝ → ℝ} {Lb Lσ : ℝ≥0} (hb : LipschitzWith Lb b) (hσ : LipschitzWith Lσ σ)
    (x₀ : ℝ) : ∃ T : ℝ≥0, 0 < T ∧ ∃ Y : ℝ≥0 → Ω → ℝ,
      ScalarStrongSolution (μ:=μ) T hBm b σ x₀ Y ∧
      ∀ Z, ScalarStrongSolution (μ:=μ) T hBm b σ x₀ Z →
        ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = Z t ω := by
  obtain ⟨T,hT,hc⟩ := exists_positive_contraction_horizon Lb Lσ
  obtain ⟨Y,hY⟩ := exists_scalar_strong_solution hB T hBm hBc hb hσ x₀ hc
  exact ⟨T,hT,Y,hY,fun Z hZ => scalar_strong_solution_unique hB T hBm hBc hb hσ x₀ hc hY hZ⟩
end
end ChainFountainStochastic.SDEContinuous

namespace ChainFountainStochastic.VectorLp
noncomputable section
open MeasureTheory Filter Set
open scoped ENNReal NNReal
set_option backward.isDefEq.respectTransparency true
variable {α : Type*} [mα : MeasurableSpace α] (μ : Measure α)
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Coordinate projection on predictable or ordinary vector L2 spaces. -/
def evalLp (i : ι) : Lp (ι → ℝ) 2 μ →L[ℝ] Lp ℝ 2 μ :=
  (ContinuousLinearMap.proj i : (ι → ℝ) →L[ℝ] ℝ).compLpL 2 μ

/-- Coordinate injection on vector L2 spaces. -/
def singleLp (i : ι) : Lp ℝ 2 μ →L[ℝ] Lp (ι → ℝ) 2 μ :=
  (ContinuousLinearMap.single ℝ (fun _ : ι => ℝ) i).compLpL 2 μ

theorem evalLp_coe (i : ι) (X : Lp (ι → ℝ) 2 μ) :
    ⇑(evalLp μ i X) =ᵐ[μ] fun a => X a i :=
  (ContinuousLinearMap.proj i : (ι → ℝ) →L[ℝ] ℝ).coeFn_compLpL X

theorem singleLp_coe (i : ι) (X : Lp ℝ 2 μ) :
    ⇑(singleLp μ i X) =ᵐ[μ] fun a => Pi.single i (X a) :=
  (ContinuousLinearMap.single ℝ (fun _ : ι => ℝ) i).coeFn_compLpL X

theorem evalLp_norm_le (i : ι) (X : Lp (ι → ℝ) 2 μ) : ‖evalLp μ i X‖ ≤ ‖X‖ := by
  apply Lp.norm_le_norm_of_ae_le
  filter_upwards [evalLp_coe μ i X] with a ha
  rw [ha]
  exact norm_le_pi_norm (X a) i

theorem singleLp_norm_le (i : ι) (X : Lp ℝ 2 μ) : ‖singleLp μ i X‖ ≤ ‖X‖ := by
  apply Lp.norm_le_norm_of_ae_le
  filter_upwards [singleLp_coe μ i X] with a ha
  rw [ha,Pi.norm_single]

/-- Assemble scalar L2 coordinates without identifying arbitrary representatives. -/
def assembleLp (X : ι → Lp ℝ 2 μ) : Lp (ι → ℝ) 2 μ := ∑ i, singleLp μ i (X i)

theorem assembleLp_coe (X : ι → Lp ℝ 2 μ) :
    ⇑(assembleLp μ X) =ᵐ[μ] fun a i => X i a := by
  have hc : ∀ᵐ a ∂μ, ∀ i, singleLp μ i (X i) a = Pi.single i (X i a) :=
    ae_all_iff.mpr (fun i => singleLp_coe μ i (X i))
  filter_upwards [Lp.coeFn_fun_finsetSum Finset.univ (fun i => singleLp μ i (X i)),hc] with a ha hc
  change (∑ i, singleLp μ i (X i) : Lp (ι → ℝ) 2 μ) a = _
  rw [ha]
  simp_rw [hc]
  ext i
  simp

theorem assembleLp_sub (X Y : ι → Lp ℝ 2 μ) :
    assembleLp μ (fun i => X i-Y i) = assembleLp μ X-assembleLp μ Y := by
  simp [assembleLp,map_sub,Finset.sum_sub_distrib]

theorem assembleLp_norm_le (X : ι → Lp ℝ 2 μ) :
    ‖assembleLp μ X‖ ≤ ∑ i, ‖X i‖ := by
  exact (norm_sum_le _ _).trans (Finset.sum_le_sum fun i _ => singleLp_norm_le μ i (X i))

/-- Lifting one scalar operator to a coupled finite-dimensional L2 state costs
only the dimension in this sup-norm estimate. No coordinate independence is used. -/
def liftOperator (A : Lp ℝ 2 μ → Lp ℝ 2 μ) (X : Lp (ι → ℝ) 2 μ) : Lp (ι → ℝ) 2 μ :=
  assembleLp μ (fun i => A (evalLp μ i X))

theorem liftOperator_sub_norm_le {q : ℝ} (hq : 0 ≤ q)
    {A : Lp ℝ 2 μ → Lp ℝ 2 μ}
    (hA : ∀ X Y, ‖A X-A Y‖ ≤ q*‖X-Y‖) (X Y : Lp (ι → ℝ) 2 μ) :
    ‖liftOperator μ A X-liftOperator μ A Y‖ ≤ (Fintype.card ι : ℝ)*q*‖X-Y‖ := by
  rw [liftOperator,liftOperator,←assembleLp_sub]
  calc
    _ ≤ ∑ i, ‖A (evalLp μ i X)-A (evalLp μ i Y)‖ := assembleLp_norm_le μ _
    _ ≤ ∑ i : ι, q*‖X-Y‖ := Finset.sum_le_sum fun i _ =>
      (hA _ _).trans (mul_le_mul_of_nonneg_left
        (by rw [←map_sub]; exact evalLp_norm_le μ i (X-Y)) hq)
    _ = _ := by simp; ring

section Coefficients
variable {E : Type*} [NormedAddCommGroup E]
variable [IsFiniteMeasure μ]
variable {clock : α → ℝ≥0} (hm : StronglyMeasurable clock)
variable {f : ℝ≥0 → E → E} (hf : Continuous (Function.uncurry f))
variable {L : ℝ≥0} (hL : ∀ t, LipschitzWith L (f t))
variable {M : ℝ} (hM : ∀ a, ‖f (clock a) 0‖ ≤ M)

include hm hf hL hM

/-- Time-dependent Lipschitz composition preserves L2. -/
theorem coefficient_memLp (X : Lp E 2 μ) : MemLp (fun a => f (clock a) (X a)) 2 μ := by
  have hzero : MemLp (fun a => f (clock a) 0) 2 μ :=
    MemLp.of_bound (hf.comp_stronglyMeasurable (hm.prodMk stronglyMeasurable_const)).aestronglyMeasurable
      M (ae_of_all _ hM)
  have hdiff : MemLp (fun a => f (clock a) (X a)-f (clock a) 0) 2 μ := by
    refine (Lp.memLp X).of_le_mul (c := (L:ℝ))
      ((hf.comp_stronglyMeasurable (hm.prodMk (Lp.stronglyMeasurable X))).sub
        (hf.comp_stronglyMeasurable (hm.prodMk stronglyMeasurable_const))).aestronglyMeasurable ?_
    exact ae_of_all _ (fun a => by simpa using (hL (clock a)).norm_sub_le (X a) 0)
  simpa only [Pi.add_def,sub_add_cancel] using hdiff.add hzero

/-- The Nemytskii operator for the actual time-dependent coefficient. -/
def coefficientLp (X : Lp E 2 μ) : Lp E 2 μ :=
  (coefficient_memLp μ hm hf hL hM X).toLp (fun a => f (clock a) (X a))

theorem coefficientLp_coe (X : Lp E 2 μ) :
    ⇑(coefficientLp μ hm hf hL hM X) =ᵐ[μ] fun a => f (clock a) (X a) :=
  (coefficient_memLp μ hm hf hL hM X).coeFn_toLp

theorem coefficientLp_sub_norm_le (X Y : Lp E 2 μ) :
    ‖coefficientLp μ hm hf hL hM X-coefficientLp μ hm hf hL hM Y‖ ≤ L*‖X-Y‖ := by
  apply Lp.norm_le_mul_norm_of_ae_le_mul
  filter_upwards [coefficientLp_coe μ hm hf hL hM X,coefficientLp_coe μ hm hf hL hM Y,
    Lp.coeFn_sub (coefficientLp μ hm hf hL hM X) (coefficientLp μ hm hf hL hM Y),
    Lp.coeFn_sub X Y] with a hx hy hsub hxy
  simp only [hsub,Pi.sub_apply,hx,hy,hxy]
  exact (hL (clock a)).norm_sub_le (X a) (Y a)
end Coefficients
end
end ChainFountainStochastic.VectorLp

namespace ChainFountainStochastic.VectorSDE
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology
open scoped NNReal ENNReal
open MathFin MathFin.SDEExistence MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM
  MathFin.ItoIntegralProcess MathFin.ItoIntegralProcessGeneral
  MathFin.ItoIntegralProcessContinuousModification
open VectorLp SDEContinuous
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 500000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Jointly continuous time-dependent, spatially Lipschitz coupled coefficients.
The bound is only at the spatial origin; the fields need not be bounded. -/
structure Coefficients (ι : Type*) [Fintype ι] where
  drift : ℝ≥0 → (ι → ℝ) → (ι → ℝ)
  diffusion : ℝ≥0 → (ι → ℝ) → (ι → ℝ)
  drift_continuous : Continuous (Function.uncurry drift)
  diffusion_continuous : Continuous (Function.uncurry diffusion)
  Lb : ℝ≥0
  Lσ : ℝ≥0
  drift_lipschitz : ∀ t, LipschitzWith Lb (drift t)
  diffusion_lipschitz : ∀ t, LipschitzWith Lσ (diffusion t)
  bound : ℝ
  drift_zero : ∀ t, ‖drift t 0‖ ≤ bound
  diffusion_zero : ∀ t, ‖diffusion t 0‖ ≤ bound

/-- Deterministic time is measurable for the predictable sigma algebra. -/
theorem clock_predictable (hBm : ∀ t, Measurable (B t)) :
    StronglyMeasurable[(natFiltration hBm).predictable]
      (Prod.fst : ℝ≥0 × Ω → ℝ≥0) := by
  exact StronglyAdapted.isStronglyPredictable_of_leftContinuous
    (fun _ => stronglyMeasurable_const) (fun _ _ => continuous_id.continuousWithinAt)

abbrev ProcessLp (T : ℝ≥0) (hBm : ∀ t, Measurable (B t)) :=
  Lp (ι → ℝ) 2 (trimMeasure_T (μ:=μ) T hBm)

def Coefficients.driftLp (c : Coefficients ι) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (X : ProcessLp (μ:=μ) (ι:=ι) T hBm) :=
  coefficientLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.drift_continuous c.drift_lipschitz
    (fun z : ℝ≥0 × Ω => c.drift_zero z.1) X

def Coefficients.diffusionLp (c : Coefficients ι) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (X : ProcessLp (μ:=μ) (ι:=ι) T hBm) :=
  coefficientLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.diffusion_continuous c.diffusion_lipschitz
    (fun z : ℝ≥0 × Ω => c.diffusion_zero z.1) X

def vectorDrift (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (φ : ProcessLp (μ:=μ) (ι:=ι) T hBm) (t : ℝ≥0) (ω : Ω) (i : ι) : ℝ :=
  driftContinuousMod T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ) t ω

def vectorIto (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (ψ : ProcessLp (μ:=μ) (ι:=ι) T hBm) (t : ℝ≥0) (ω : Ω) (i : ι) : ℝ :=
  itoContinuousMod T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i ψ) t ω

def picard (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (X : ProcessLp (μ:=μ) (ι:=ι) T hBm) :=
  Lp.const 2 _ x₀ +
    liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (driftProcessAssembled (μ:=μ) T hBm) (c.driftLp T hBm X) +
    liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (itoProcessAssembled hB T hBm hBc) (c.diffusionLp T hBm X)

def contractionFactor (c : Coefficients ι) (T : ℝ≥0) : ℝ :=
  (Fintype.card ι : ℝ) * ((T:ℝ)*c.Lb + Real.sqrt (T:ℝ)*c.Lσ)

theorem picard_sub_norm_le (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (X Y : ProcessLp (μ:=μ) (ι:=ι) T hBm) :
    ‖picard hB T hBm hBc c x₀ X-picard hB T hBm hBc c x₀ Y‖
      ≤ contractionFactor c T * ‖X-Y‖ := by
  have hd : ∀ U V : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm),
      ‖driftProcessAssembled (μ:=μ) T hBm U-driftProcessAssembled (μ:=μ) T hBm V‖
        ≤ (T:ℝ)*‖U-V‖ := fun U V => by
    rw [←map_sub]; exact driftProcessAssembled_norm_le T hBm _
  have hi : ∀ U V : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm),
      ‖itoProcessAssembled hB T hBm hBc U-itoProcessAssembled hB T hBm hBc V‖
        ≤ Real.sqrt (T:ℝ)*‖U-V‖ := fun U V => by
    rw [←itoProcessAssembled_sub]; exact itoProcessAssembled_norm_le hB T hBm hBc _
  have hbd := coefficientLp_sub_norm_le (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.drift_continuous
    c.drift_lipschitz (fun z : ℝ≥0 × Ω => c.drift_zero z.1) X Y
  have hsd := coefficientLp_sub_norm_le (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.diffusion_continuous
    c.diffusion_lipschitz (fun z : ℝ≥0 × Ω => c.diffusion_zero z.1) X Y
  rw [picard,picard,show ∀ a b d e f : ProcessLp (μ:=μ) (ι:=ι) T hBm,
    (a+b+d)-(a+e+f)=(b-e)+(d-f) from fun _ _ _ _ _ => by abel]
  calc
    _ ≤ _ := norm_add_le _ _
    _ ≤ (Fintype.card ι:ℝ)*(T:ℝ)*‖c.driftLp T hBm X-c.driftLp T hBm Y‖ +
        (Fintype.card ι:ℝ)*Real.sqrt (T:ℝ)*‖c.diffusionLp T hBm X-c.diffusionLp T hBm Y‖ :=
      add_le_add (liftOperator_sub_norm_le (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) T.coe_nonneg hd _ _)
        (liftOperator_sub_norm_le (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (Real.sqrt_nonneg _) hi _ _)
    _ ≤ (Fintype.card ι:ℝ)*(T:ℝ)*(c.Lb*‖X-Y‖) +
        (Fintype.card ι:ℝ)*Real.sqrt (T:ℝ)*(c.Lσ*‖X-Y‖) :=
      add_le_add (mul_le_mul_of_nonneg_left hbd (by positivity))
        (mul_le_mul_of_nonneg_left hsd (by positivity))
    _ = _ := by dsimp [contractionFactor]; ring

/-- Banach's theorem for the full coupled vector state. -/
theorem picard_exists_unique_fixedPoint (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (hc : contractionFactor c T < 1) :
    ∃! X, picard hB T hBm hBc c x₀ X = X := by
  have hq : 0 ≤ contractionFactor c T := by dsimp [contractionFactor]; positivity
  have hcontract : ContractingWith (Real.toNNReal (contractionFactor c T))
      (picard hB T hBm hBc c x₀) := by
    refine ⟨?_,LipschitzWith.of_dist_le_mul fun X Y => ?_⟩
    · rw [←NNReal.coe_lt_coe,Real.coe_toNNReal _ hq,NNReal.coe_one]; exact hc
    · rw [dist_eq_norm,dist_eq_norm,Real.coe_toNNReal _ hq]
      exact picard_sub_norm_le hB T hBm hBc c x₀ X Y
  exact ⟨hcontract.fixedPoint _,hcontract.fixedPoint_isFixedPt,
    fun _ he => hcontract.fixedPoint_unique he⟩

theorem picard_coe (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (X : ProcessLp (μ:=μ) (ι:=ι) T hBm) :
    ⇑(picard hB T hBm hBc c x₀ X) =ᵐ[trimMeasure_T (μ:=μ) T hBm]
      fun z => x₀ + vectorDrift T hBm (c.driftLp T hBm X) z.1 z.2 +
        vectorIto T hBm (c.diffusionLp T hBm X) z.1 z.2 := by
  let φ := c.driftLp T hBm X
  let ψ := c.diffusionLp T hBm X
  have hd : ⇑(liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (driftProcessAssembled (μ:=μ) T hBm) φ)
      =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry (vectorDrift T hBm φ) := by
    filter_upwards [assembleLp_coe (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (fun i => driftProcessAssembled (μ:=μ) T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ)),
      ae_all_iff.mpr (fun i : ι => driftProcessAssembled_coeFn T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ))] with z hz hi
    exact hz.trans (funext hi)
  have hi : ⇑(liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (itoProcessAssembled hB T hBm hBc) ψ)
      =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry (vectorIto T hBm ψ) := by
    have he : ∀ i : ι, ⇑(itoProcessAssembled hB T hBm hBc (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i ψ))
        =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry (itoContinuousMod T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i ψ)) :=
      fun i => (memLp_itoContinuousMod hB T hBm hBc (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i ψ)).coeFn_toLp
    filter_upwards [assembleLp_coe (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (fun i => itoProcessAssembled hB T hBm hBc (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i ψ)),
      ae_all_iff.mpr he] with z hz hi
    exact hz.trans (funext hi)
  filter_upwards [Lp.coeFn_add
    (Lp.const 2 _ x₀+liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (driftProcessAssembled (μ:=μ) T hBm) φ)
    (liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (itoProcessAssembled hB T hBm hBc) ψ),
    Lp.coeFn_add (Lp.const 2 _ x₀) (liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (driftProcessAssembled (μ:=μ) T hBm) φ),
    Lp.coeFn_const (p:=2) (μ:=trimMeasure_T (μ:=μ) T hBm) (c:=x₀),hd,hi]
    with z h1 h2 h0 hd hi
  change (Lp.const 2 _ x₀+liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (driftProcessAssembled (μ:=μ) T hBm) φ+
    liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (itoProcessAssembled hB T hBm hBc) ψ : ProcessLp (μ:=μ) (ι:=ι) T hBm) z = _
  simp only [h1,h2,h0,hd,hi,Pi.add_apply,Function.const_apply,Function.uncurry]
  rfl

/-- A continuous predictable solution of the actual coupled time-dependent SDE.
All coordinates use the same Brownian motion; each coefficient may depend on
the entire state. The equation holds at all times on one conull event. -/
structure StrongSolution (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (c : Coefficients ι) (x₀ : ι → ℝ) (Y : ℝ≥0 → Ω → (ι → ℝ)) : Prop where
  predictable : IsStronglyPredictable (natFiltration hBm) Y
  continuous : ∀ᵐ ω ∂μ, ContinuousOn (fun t => Y t ω) (Icc 0 T)
  initial : ∀ ω, Y 0 ω = x₀
  state_memLp : MemLp (Function.uncurry Y) 2 (trimMeasure_T (μ:=μ) T hBm)
  drift_memLp : MemLp (fun z : ℝ≥0 × Ω => c.drift z.1 (Y z.1 z.2)) 2 (trimMeasure_T (μ:=μ) T hBm)
  diffusion_memLp : MemLp (fun z : ℝ≥0 × Ω => c.diffusion z.1 (Y z.1 z.2)) 2 (trimMeasure_T (μ:=μ) T hBm)
  equation : ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → ∀ i : ι,
    Y t ω i = x₀ i + (∫ s in Ioc (0:ℝ≥0) t, c.drift s (Y s ω) i ∂timeMeasure) +
      vectorIto T hBm (diffusion_memLp.toLp (fun z => c.diffusion z.1 (Y z.1 z.2))) t ω i

theorem vectorDrift_predictable (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (φ : ProcessLp (μ:=μ) (ι:=ι) T hBm) :
    IsStronglyPredictable (natFiltration hBm) (vectorDrift T hBm φ) := by
  letI : MeasurableSpace (ℝ≥0 × Ω) := (natFiltration hBm).predictable
  exact (measurable_pi_lambda _ (fun i =>
    (driftContinuousMod_isStronglyPredictable T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ)).measurable)).stronglyMeasurable

theorem vectorIto_predictable (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (ψ : ProcessLp (μ:=μ) (ι:=ι) T hBm) :
    IsStronglyPredictable (natFiltration hBm) (vectorIto T hBm ψ) := by
  letI : MeasurableSpace (ℝ≥0 × Ω) := (natFiltration hBm).predictable
  exact (measurable_pi_lambda _ (fun i =>
    (itoContinuousMod_isStronglyPredictable hB T hBm hBc (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i ψ)).measurable)).stronglyMeasurable

theorem vectorDrift_continuous (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (φ : ProcessLp (μ:=μ) (ι:=ι) T hBm) :
    ∀ᵐ ω ∂μ, ContinuousOn (fun t => vectorDrift T hBm φ t ω) (Icc 0 T) := by
  filter_upwards [ae_all_iff.mpr (fun i : ι => drift_mod_continuousOn T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ))]
    with ω hω
  exact continuousOn_pi.2 hω

theorem vectorIto_continuous (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (ψ : ProcessLp (μ:=μ) (ι:=ι) T hBm) :
    ∀ᵐ ω ∂μ, ContinuousOn (fun t => vectorIto T hBm ψ t ω) (Icc 0 T) := by
  filter_upwards [ae_all_iff.mpr (fun i : ι =>
    itoContinuousMod_continuousOn hB T hBm hBc (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i ψ))] with ω hω
  exact continuousOn_pi.2 hω

/-- One conull event carries every coordinate drift identity at every time. -/
theorem vectorDrift_integral_all_times (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (φ : ProcessLp (μ:=μ) (ι:=ι) T hBm) {f : ℝ≥0 × Ω → (ι → ℝ)}
    (hf : ⇑φ =ᵐ[trimMeasure_T (μ:=μ) T hBm] f) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → ∀ i : ι,
      vectorDrift T hBm φ t ω i = ∫ s in Ioc (0:ℝ≥0) t, f (s,ω) i ∂timeMeasure := by
  have he : ∀ i : ι, ⇑(evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ) =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => f z i := by
    intro i
    filter_upwards [evalLp_coe (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ,hf] with z hi hz
    exact hi.trans (congrFun hz i)
  filter_upwards [ae_all_iff.mpr (fun i : ι => drift_mod_integral_all_times T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ)),
    ae_all_iff.mpr (fun i : ι => ae_path_of_trim_eq T hBm (he i))] with ω hd he
  intro t ht i
  change driftContinuousMod T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ) t ω = _
  rw [hd i t ht]
  exact integral_congr_ae ((he i).filter_mono
    (ae_mono (Measure.restrict_mono (Ioc_subset_Ioc_right ht) le_rfl)))

/-- Realize the coupled vector fixed point with its actual trajectory coefficients. -/
theorem realize_fixed_point (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (X : ProcessLp (μ:=μ) (ι:=ι) T hBm)
    (hfix : picard hB T hBm hBc c x₀ X = X) :
    ∃ Y : ℝ≥0 → Ω → (ι → ℝ), StrongSolution (μ:=μ) T hBm c x₀ Y ∧
      ⇑X =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry Y := by
  let φ := c.driftLp T hBm X
  let ψ := c.diffusionLp T hBm X
  let Y : ℝ≥0 → Ω → (ι → ℝ) := fun t ω =>
    x₀ + vectorDrift T hBm φ t ω + vectorIto T hBm ψ t ω
  have hX : ⇑X =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry Y := by
    filter_upwards [picard_coe hB T hBm hBc c x₀ X] with z hz
    rw [hfix] at hz
    exact hz
  have hφ : ⇑φ =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => c.drift z.1 (Y z.1 z.2) := by
    filter_upwards [coefficientLp_coe (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.drift_continuous
      c.drift_lipschitz (fun z : ℝ≥0 × Ω => c.drift_zero z.1) X,hX] with z hc hz
    exact hc.trans (congrArg (c.drift z.1) hz)
  have hψ : ⇑ψ =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => c.diffusion z.1 (Y z.1 z.2) := by
    filter_upwards [coefficientLp_coe (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.diffusion_continuous
      c.diffusion_lipschitz (fun z : ℝ≥0 × Ω => c.diffusion_zero z.1) X,hX] with z hc hz
    exact hc.trans (congrArg (c.diffusion z.1) hz)
  have hYm := (Lp.memLp X).ae_eq hX
  have hφm := (Lp.memLp φ).ae_eq hφ
  have hψm := (Lp.memLp ψ).ae_eq hψ
  have hψclass : hψm.toLp (fun z : ℝ≥0 × Ω => c.diffusion z.1 (Y z.1 z.2)) = ψ :=
    (MemLp.toLp_congr hψm (Lp.memLp ψ) hψ.symm).trans (Lp.toLp_coeFn ψ (Lp.memLp ψ))
  refine ⟨Y,⟨?_,?_,?_,hYm,hφm,hψm,?_⟩,hX⟩
  · exact (stronglyMeasurable_const.add (vectorDrift_predictable T hBm φ)).add
      (vectorIto_predictable hB T hBm hBc ψ)
  · filter_upwards [vectorDrift_continuous T hBm φ,vectorIto_continuous hB T hBm hBc ψ]
      with ω hd hi
    exact (continuousOn_const.add hd).add hi
  · intro ω
    ext i
    change x₀ i + driftContinuousMod T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ) 0 ω +
      itoContinuousMod T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i ψ) 0 ω = x₀ i
    rw [(integral_mod_zero T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ) ω).1,
      (integral_mod_zero T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i ψ) ω).2]
    ring
  · rw [hψclass]
    filter_upwards [vectorDrift_integral_all_times T hBm φ hφ] with ω hd
    intro t ht i
    change x₀ i + vectorDrift T hBm φ t ω i + vectorIto T hBm ψ t ω i = _
    rw [hd t ht i]

theorem exists_strong_solution (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (hc : contractionFactor c T < 1) :
    ∃ Y, StrongSolution (μ:=μ) T hBm c x₀ Y := by
  obtain ⟨X,hX,_⟩ := picard_exists_unique_fixedPoint hB T hBm hBc c x₀ hc
  obtain ⟨Y,hY,_⟩ := realize_fixed_point hB T hBm hBc c x₀ X hX
  exact ⟨Y,hY⟩

theorem trim_eq_of_ae_vector_paths (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    {Y Z : ℝ≥0 → Ω → (ι → ℝ)} (hY : IsStronglyPredictable (natFiltration hBm) Y)
    (hZ : IsStronglyPredictable (natFiltration hBm) Z)
    (he : ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = Z t ω) :
    Function.uncurry Y =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry Z := by
  have hec : ∀ i : ι, (fun z : ℝ≥0 × Ω => Y z.1 z.2 i)
      =ᵐ[trimMeasure_T (μ:=μ) T hBm] (fun z => Z z.1 z.2 i) := by
    intro i
    apply trim_eq_of_ae_paths (μ:=μ) T hBm (Y:=fun t ω => Y t ω i) (Z:=fun t ω => Z t ω i)
      ((continuous_apply i).comp_stronglyMeasurable hY)
      ((continuous_apply i).comp_stronglyMeasurable hZ)
    filter_upwards [he] with ω hω
    exact fun t ht => congrFun (hω t ht) i
  filter_upwards [ae_all_iff.mpr hec] with z hz
  exact funext hz

theorem StrongSolution.canonical_equation (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (c : Coefficients ι) (x₀ : ι → ℝ) {Y : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = x₀ +
      vectorDrift T hBm (c.driftLp T hBm (hY.state_memLp.toLp (Function.uncurry Y))) t ω +
      vectorIto T hBm (c.diffusionLp T hBm (hY.state_memLp.toLp (Function.uncurry Y))) t ω := by
  let X := hY.state_memLp.toLp (Function.uncurry Y)
  let φ := c.driftLp T hBm X
  let ψ := c.diffusionLp T hBm X
  have hφ : ⇑φ =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => c.drift z.1 (Y z.1 z.2) := by
    filter_upwards [coefficientLp_coe (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.drift_continuous
      c.drift_lipschitz (fun z : ℝ≥0 × Ω => c.drift_zero z.1) X,hY.state_memLp.coeFn_toLp] with z hc hz
    exact hc.trans (congrArg (c.drift z.1) hz)
  have hψ : ⇑ψ =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => c.diffusion z.1 (Y z.1 z.2) := by
    filter_upwards [coefficientLp_coe (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.diffusion_continuous
      c.diffusion_lipschitz (fun z : ℝ≥0 × Ω => c.diffusion_zero z.1) X,hY.state_memLp.coeFn_toLp] with z hc hz
    exact hc.trans (congrArg (c.diffusion z.1) hz)
  have hψclass : hY.diffusion_memLp.toLp (fun z : ℝ≥0 × Ω => c.diffusion z.1 (Y z.1 z.2)) = ψ :=
    (MemLp.toLp_congr hY.diffusion_memLp (Lp.memLp ψ) hψ.symm).trans
      (Lp.toLp_coeFn ψ (Lp.memLp ψ))
  filter_upwards [hY.equation,vectorDrift_integral_all_times T hBm φ hφ] with ω he hd
  intro t ht
  ext i
  change Y t ω i = x₀ i + vectorDrift T hBm φ t ω i + vectorIto T hBm ψ t ω i
  rw [he t ht i,hψclass,hd t ht i]

theorem StrongSolution.fixed_point (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) {Y : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y) :
    picard hB T hBm hBc c x₀ (hY.state_memLp.toLp (Function.uncurry Y)) =
      hY.state_memLp.toLp (Function.uncurry Y) := by
  let X := hY.state_memLp.toLp (Function.uncurry Y)
  have hp : IsStronglyPredictable (natFiltration hBm) (fun t ω => x₀ +
      vectorDrift T hBm (c.driftLp T hBm X) t ω + vectorIto T hBm (c.diffusionLp T hBm X) t ω) :=
    (stronglyMeasurable_const.add (vectorDrift_predictable T hBm _)).add
      (vectorIto_predictable hB T hBm hBc _)
  have he := trim_eq_of_ae_vector_paths T hBm hY.predictable hp (hY.canonical_equation T hBm c x₀)
  exact Lp.ext ((picard_coe hB T hBm hBc c x₀ X).trans
    (he.symm.trans hY.state_memLp.coeFn_toLp.symm))

/-- Pathwise uniqueness for all times, among predictable L2 strong solutions. -/
theorem strong_solution_unique (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (hc : contractionFactor c T < 1)
    {Y Z : ℝ≥0 → Ω → (ι → ℝ)} (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hZ : StrongSolution (μ:=μ) T hBm c x₀ Z) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = Z t ω := by
  obtain ⟨_,_,hu⟩ := picard_exists_unique_fixedPoint hB T hBm hBc c x₀ hc
  have he : hY.state_memLp.toLp (Function.uncurry Y) = hZ.state_memLp.toLp (Function.uncurry Z) :=
    (hu _ (hY.fixed_point hB T hBm hBc c x₀)).trans
      (hu _ (hZ.fixed_point hB T hBm hBc c x₀)).symm
  filter_upwards [hY.canonical_equation T hBm c x₀,hZ.canonical_equation T hBm c x₀] with ω hy hz
  intro t ht
  rw [hy t ht,hz t ht,he]

/-- A coupled finite-dimensional, time-dependent strong SDE always has a
positive existence horizon, with pathwise uniqueness in the predictable L2 class. -/
theorem exists_unique_local_strong_solution (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) :
    ∃ T : ℝ≥0, 0 < T ∧ ∃ Y, StrongSolution (μ:=μ) T hBm c x₀ Y ∧
      ∀ Z, StrongSolution (μ:=μ) T hBm c x₀ Z →
        ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = Z t ω := by
  obtain ⟨T,hT,hc⟩ := exists_positive_contraction_horizon
    ((Fintype.card ι : ℝ≥0)*c.Lb) ((Fintype.card ι : ℝ≥0)*c.Lσ)
  have hc' : contractionFactor c T < 1 := by
    convert hc using 1 <;> simp only [contractionFactor,NNReal.coe_mul,NNReal.coe_natCast] <;> ring
  obtain ⟨Y,hY⟩ := exists_strong_solution hB T hBm hBc c x₀ hc'
  exact ⟨T,hT,Y,hY,fun Z hZ => strong_solution_unique hB T hBm hBc c x₀ hc' hY hZ⟩

end
end ChainFountainStochastic.VectorSDE

namespace ChainFountainStochastic.MechanicalCutoff
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology ChainFountain VectorSDE
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 700000

abbrev State := Fin 3 → ℝ

def boxClamp (lo hi x : State) : State := fun i => max (lo i) (min (hi i) (x i))

theorem boxClamp_lipschitz (lo hi : State) : LipschitzWith 1 (boxClamp lo hi) := by
  apply LipschitzWith.of_dist_le_mul
  intro x y
  rw [NNReal.coe_one,one_mul,dist_pi_le_iff dist_nonneg]
  intro i
  simpa only [boxClamp,Function.eval,NNReal.coe_one,one_mul] using
    (((LipschitzWith.eval i).const_min (hi i)).const_max (lo i)).dist_le_mul x y

theorem boxClamp_mem {lo hi : State} (h : lo ≤ hi) (x : State) :
    boxClamp lo hi x ∈ Icc lo hi :=
  ⟨fun i => le_max_left _ _,fun i => max_le (h i) (min_le_left _ _)⟩

theorem boxClamp_eq {lo hi x : State} (h : x ∈ Icc lo hi) : boxClamp lo hi x = x := by
  ext i
  simp only [boxClamp,min_eq_right (h.2 i),max_eq_right (h.1 i)]

/-- Smooth drift and diffusion on a compact parameter/state box have jointly
continuous globally Lipschitz cutoff extensions, with proved origin bounds. -/
theorem exists_cutoff_coefficients
    {b σ : State × State → State} {U : Set (State × State)}
    (hU : IsOpen U) (hb : ContDiffOn ℝ 1 b U) (hσ : ContDiffOn ℝ 1 σ U)
    (p : ℝ≥0 → State) (hp : Continuous p) (plo phi lo hi : State)
    (hlo : lo ≤ hi) (hpmem : ∀ t, p t ∈ Icc plo phi)
    (hsub : (Icc plo phi ×ˢ Icc lo hi) ⊆ U) :
    ∃ c : Coefficients (Fin 3),
      (∀ t x, c.drift t x = b (p t,boxClamp lo hi x)) ∧
      (∀ t x, c.diffusion t x = σ (p t,boxClamp lo hi x)) ∧
      (∀ t x, ‖c.drift t x‖ ≤ c.bound ∧ ‖c.diffusion t x‖ ≤ c.bound) := by
  obtain ⟨Lb,Cb,hbL,hbC⟩ := smooth_compact_convex_bounds hU hb
    (isCompact_Icc.prod isCompact_Icc) ((convex_Icc _ _).prod (convex_Icc _ _)) hsub
  obtain ⟨Lσ,Cσ,hσL,hσC⟩ := smooth_compact_convex_bounds hU hσ
    (isCompact_Icc.prod isCompact_Icc) ((convex_Icc _ _).prod (convex_Icc _ _)) hsub
  have hm (z : ℝ≥0 × State) : (p z.1,boxClamp lo hi z.2) ∈ Icc plo phi ×ˢ Icc lo hi :=
    ⟨hpmem z.1,boxClamp_mem hlo z.2⟩
  have hcont : Continuous (fun z : ℝ≥0 × State => (p z.1,boxClamp lo hi z.2)) :=
    (hp.comp continuous_fst).prodMk ((boxClamp_lipschitz lo hi).continuous.comp continuous_snd)
  have hemb (t : ℝ≥0) : LipschitzWith 1 (fun x : State => (p t,boxClamp lo hi x)) := by
    simpa only [mul_one,Function.comp_def] using (LipschitzWith.prodMk_left (p t)).comp (boxClamp_lipschitz lo hi)
  have hbLip (t : ℝ≥0) : LipschitzWith Lb (fun x => b (p t,boxClamp lo hi x)) := by
    simpa only [mul_one,Function.comp_def,lipschitzOnWith_univ] using
      hbL.comp ((hemb t).lipschitzOnWith (s:=univ)) (fun x _ => hm (t,x))
  have hσLip (t : ℝ≥0) : LipschitzWith Lσ (fun x => σ (p t,boxClamp lo hi x)) := by
    simpa only [mul_one,Function.comp_def,lipschitzOnWith_univ] using
      hσL.comp ((hemb t).lipschitzOnWith (s:=univ)) (fun x _ => hm (t,x))
  refine ⟨{
    drift := fun t x => b (p t,boxClamp lo hi x)
    diffusion := fun t x => σ (p t,boxClamp lo hi x)
    drift_continuous := hbL.continuousOn.comp_continuous hcont hm
    diffusion_continuous := hσL.continuousOn.comp_continuous hcont hm
    Lb := Lb
    Lσ := Lσ
    drift_lipschitz := hbLip
    diffusion_lipschitz := hσLip
    bound := max Cb Cσ
    drift_zero := fun t => (hbC _ (hm (t,0))).trans (le_max_left _ _)
    diffusion_zero := fun t => (hσC _ (hm (t,0))).trans (le_max_right _ _)
  },fun _ _ => rfl,fun _ _ => rfl,fun t x =>
    ⟨(hbC _ (hm (t,x))).trans (le_max_left _ _),
      (hσC _ (hm (t,x))).trans (le_max_right _ _)⟩⟩

structure Parameters where
  H : ℝ
  g : ℝ
  α : ℝ
  β : ℝ
  k₀ : ℝ
  k₁ : ℝ
  k₂ : ℝ
  κd : ℝ
  noise : ℝ
  H_pos : 0 < H

/-- Original feedback mechanical drift in coordinates (height, rise speed, fall speed).
The parameter vector contains reference position, velocity and acceleration. -/
def Parameters.drift (d : Parameters) (y : State × State) : State :=
  let p := y.1
  let x := y.2
  let u := robustInput d.H d.g d.α d.β (x 0) (x 1) (x 2)
    (acceleration d.k₀ d.k₁ d.k₂ (x 0-p 0) (heightRate (x 1) (x 2)) (p 1) (p 2))
    d.κd (x 1-x 2-2*p 1+2*d.k₁*(x 0-p 0))
  ![heightRate (x 1) (x 2),rise d.g d.α (x 0) (x 1) (x 2) u,
    fall d.H d.g d.β (x 0) (x 1) (x 2)]

/-- The single physical Brownian input acts on rise speed, with coefficient sigma v²/h. -/
def Parameters.diffusion (d : Parameters) (y : State × State) : State :=
  ![0,d.noise*(y.2 1)^2/(y.2 0),0]

theorem Parameters.drift_smooth (d : Parameters) :
    ContDiffOn ℝ 1 d.drift {y | 0 < y.2 0} := by
  intro y hy
  have hh : y.2 0 ≠ 0 := ne_of_gt hy
  have hH : d.H+y.2 0 ≠ 0 := ne_of_gt (add_pos d.H_pos hy)
  apply ContDiffAt.contDiffWithinAt
  apply contDiffAt_pi.2
  intro i
  fin_cases i <;>
    dsimp [Parameters.drift] <;>
    simp only [robustInput,nominalInput,acceleration,heightRate,rise,fall,crownSq] <;>
    fun_prop (disch := first | assumption | norm_num)

theorem Parameters.diffusion_smooth (d : Parameters) :
    ContDiffOn ℝ 1 d.diffusion {y | 0 < y.2 0} := by
  intro y hy
  have hh : y.2 0 ≠ 0 := ne_of_gt hy
  apply ContDiffAt.contDiffWithinAt
  apply contDiffAt_pi.2
  intro i
  fin_cases i <;>
    dsimp [Parameters.diffusion] <;>
    fun_prop (disch := assumption)

/-- The actual rational mechanical fields admit compatible cutoff extensions
on every finite state box separated from height zero. -/
theorem Parameters.exists_cutoff (d : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi lo hi : State) (hlo : lo ≤ hi) (hh : 0 < lo 0)
    (hpmem : ∀ t, p t ∈ Icc plo phi) :
    ∃ c : Coefficients (Fin 3),
      (∀ t x, c.drift t x = d.drift (p t,boxClamp lo hi x)) ∧
      (∀ t x, c.diffusion t x = d.diffusion (p t,boxClamp lo hi x)) ∧
      (∀ t x, x ∈ Icc lo hi → c.drift t x = d.drift (p t,x)) ∧
      (∀ t x, x ∈ Icc lo hi → c.diffusion t x = d.diffusion (p t,x)) ∧
      (∀ t x, ‖c.drift t x‖ ≤ c.bound ∧ ‖c.diffusion t x‖ ≤ c.bound) := by
  obtain ⟨c,hb,hσ,hbound⟩ := exists_cutoff_coefficients
    (isOpen_lt continuous_const ((continuous_apply 0).comp continuous_snd))
    d.drift_smooth d.diffusion_smooth p hp plo phi lo hi hlo hpmem
    (fun y hy => lt_of_lt_of_le hh (hy.2.1 0))
  exact ⟨c,hb,hσ,fun t x hx => by rw [hb,boxClamp_eq hx],
    (fun t x hx => by rw [hσ,boxClamp_eq hx]),hbound⟩

/-- A strong solution is constructed for the mechanical cutoff; no trajectory
or existence hypothesis is supplied. Coefficients agree with the original
mechanical SDE throughout the chosen positive-height box. -/
theorem exists_unique_mechanical_cutoff_solution
    {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω} [IsProbabilityMeasure μ]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (d : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi lo hi : State) (hlo : lo ≤ hi) (hh : 0 < lo 0)
    (hpmem : ∀ t, p t ∈ Icc plo phi) (x₀ : State) :
    ∃ c : Coefficients (Fin 3),
      (∀ t x, x ∈ Icc lo hi → c.drift t x = d.drift (p t,x)) ∧
      (∀ t x, x ∈ Icc lo hi → c.diffusion t x = d.diffusion (p t,x)) ∧
      (∀ t x, ‖c.drift t x‖ ≤ c.bound ∧ ‖c.diffusion t x‖ ≤ c.bound) ∧
      ∃ T : ℝ≥0, 0 < T ∧ ∃ Y, StrongSolution (μ:=μ) T hBm c x₀ Y ∧
        ∀ Z, StrongSolution (μ:=μ) T hBm c x₀ Z →
          ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = Z t ω := by
  obtain ⟨c,_,_,hb,hσ,hbound⟩ := d.exists_cutoff p hp plo phi lo hi hlo hh hpmem
  exact ⟨c,hb,hσ,hbound,exists_unique_local_strong_solution hB hBm hBc c x₀⟩

end
end ChainFountainStochastic.MechanicalCutoff


namespace ChainFountainStochastic.LocalIntegralBridge
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM
  MathFin.ItoIntegralProcessContinuousModification MathFin.ItoIntegralProcessGeneral
  MathFin.ItoIntegralPredictable MathFin.ItoIntegralLocalised
  MathFin.ItoIntegralProcessLocalMartingaleGeneral
open MathFin.LocalisationInMeasure MathFin.ItoIntegralRiemannBridge
  MathFin.QuadraticVariationL2
open VectorSDE VectorLp
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 600000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}

/-- The predictable L2 integral and the localized predictable integral coincide
at all times on one conull event. Continuity is required only almost surely. -/
theorem continuousMod_eq_predIto
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {a : ℝ≥0 → Ω → ℝ} (hp : IsStronglyPredictable (natFiltration hBm) a)
    (hc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => a t ω) (Icc 0 T))
    {C : ℝ} (hb : ∀ t ω, |a t ω| ≤ C)
    (φ : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm))
    (hφ : ⇑φ =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry a) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      itoContinuousMod T hBm φ t ω = predItoIntegral (μ:=μ) T hBm hp t ω := by
  have he : φ = processToLpPredictable (μ:=μ) T hBm hp hb :=
    Lp.ext (hφ.trans (processToLpPredictable_coeFn T hBm hp hb).symm)
  rw [he]
  exact ae_forall_eq_of_tendstoInMeasure
    (itoContinuousMod_continuousOn hB T hBm hBc _)
    (ae_continuousOn_predItoIntegral hB T hBm hBc hp hc)
    (fun _ ht => tendstoInMeasure_riemannσ_of_predictable hB T hBm hBc hp hc hb ht.2)
    (fun _ ht => tendstoInMeasure_riemannσ_predItoIntegral hB T hBm hBc hp hc ht.2)

/-- Prefix locality of the stochastic integral. The agreement event is allowed
to depend on the whole path; no uncountable intersection of null sets is used. -/
theorem predIto_prefix_locality
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {a b : ℝ≥0 → Ω → ℝ}
    (ha : IsStronglyPredictable (natFiltration hBm) a)
    (hb : IsStronglyPredictable (natFiltration hBm) b)
    (hac : ∀ᵐ ω ∂μ, ContinuousOn (fun t => a t ω) (Icc 0 T))
    (hbc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => b t ω) (Icc 0 T)) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, (∀ s ∈ Icc 0 t, a s ω = b s ω) →
      predItoIntegral (μ:=μ) T hBm ha t ω = predItoIntegral (μ:=μ) T hBm hb t ω := by
  refine ae_forall_eq_of_continuousOn_of_antitone
    (A := fun t => {ω | ∀ s ∈ Icc 0 t, a s ω = b s ω})
    (ae_continuousOn_predItoIntegral hB T hBm hBc ha hac)
    (ae_continuousOn_predItoIntegral hB T hBm hBc hb hbc)
    (fun _ _ hst _ h s hs => h s ⟨hs.1,hs.2.trans hst⟩) ?_
  intro t ht
  refine ae_eq_of_tendstoInMeasure_of_eqOn
    (tendstoInMeasure_riemannσ_predItoIntegral hB T hBm hBc ha hac ht.2)
    (tendstoInMeasure_riemannσ_predItoIntegral hB T hBm hBc hb hbc ht.2) ?_
  intro n ω hω
  exact riemannσ_congr (fun s hs => hω s ⟨hs.1,hs.2⟩) n

/-- The same single conull event supports every random prefix, whether or not
the prefix is a stopping time. This is locality of integrals, not uniqueness of SDEs. -/
theorem predIto_random_prefix_locality
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {a b : ℝ≥0 → Ω → ℝ}
    (ha : IsStronglyPredictable (natFiltration hBm) a)
    (hb : IsStronglyPredictable (natFiltration hBm) b)
    (hac : ∀ᵐ ω ∂μ, ContinuousOn (fun t => a t ω) (Icc 0 T))
    (hbc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => b t ω) (Icc 0 T)) :
    ∀ᵐ ω ∂μ, ∀ τ : ℝ≥0, τ ≤ T →
      (∀ s ∈ Icc 0 τ, a s ω = b s ω) → ∀ t ∈ Icc 0 τ,
      predItoIntegral (μ:=μ) T hBm ha t ω = predItoIntegral (μ:=μ) T hBm hb t ω := by
  filter_upwards [predIto_prefix_locality hB T hBm hBc ha hb hac hbc] with ω hω
  intro τ hτ he t ht
  exact hω t ⟨ht.1,ht.2.trans hτ⟩ (fun s hs => he s ⟨hs.1,hs.2.trans ht.2⟩)

/-- The localized predictable integral of zero vanishes simultaneously at all times. -/
theorem predIto_zero (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω)) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      predItoIntegral (μ:=μ) T hBm (show IsStronglyPredictable (natFiltration hBm)
        (fun _ _ => (0:ℝ)) from stronglyMeasurable_const) t ω = 0 := by
  have hp : IsStronglyPredictable (natFiltration hBm) (fun _ _ => (0:ℝ)) := stronglyMeasurable_const
  have hc : ∀ᵐ ω ∂μ, ContinuousOn (fun _ : ℝ≥0 => (0:ℝ)) (Icc 0 T) :=
    ae_of_all _ (fun _ => continuousOn_const)
  have he := continuousMod_eq_predIto hB T hBm hBc hp hc (C:=0)
    (fun _ _ => by simp) 0 (Lp.coeFn_zero ℝ 2 _)
  have hz : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      itoContinuousMod T hBm (0 : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) t ω = 0 := by
    apply ae_forall_eq_of_continuousOn
      (itoContinuousMod_continuousOn hB T hBm hBc _) hc
    intro t ht
    have hm := itoContinuousMod_modification hB T hBm hBc
      (0 : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) ht.2
    have hm0 : (fun ω => itoContinuousMod T hBm (0 : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) t ω) =ᵐ[μ] ⇑(0 : Lp ℝ 2 μ) := by
      simpa only [map_zero] using hm
    exact hm0.trans (Lp.coeFn_zero ℝ 2 μ)
  filter_upwards [he,hz] with ω he hz
  intro t ht
  exact (he t ht).symm.trans (hz t ht)

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The actual time-dependent diffusion along a predictable vector state is predictable. -/
theorem diffusion_predictable (hBm : ∀ t, Measurable (B t))
    (c : Coefficients ι) {Y : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : IsStronglyPredictable (natFiltration hBm) Y) (i : ι) :
    IsStronglyPredictable (natFiltration hBm) (fun t ω => c.diffusion t (Y t ω) i) :=
  (continuous_apply i).comp_stronglyMeasurable
    (c.diffusion_continuous.comp_stronglyMeasurable ((clock_predictable hBm).prodMk hY))

/-- Every coordinate of a bounded-coefficient strong solution satisfies the
localized predictable Ito equation, with its actual diffusion coefficient. -/
theorem strong_solution_predIto_equation
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) {Y : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hbound : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, ∀ i : ι,
      Y t ω i = x₀ i + (∫ s in Ioc (0:ℝ≥0) t, c.drift s (Y s ω) i ∂timeMeasure) +
        predItoIntegral (μ:=μ) T hBm (diffusion_predictable hBm c hY.predictable i) t ω := by
  let ψ := hY.diffusion_memLp.toLp (fun z : ℝ≥0 × Ω => c.diffusion z.1 (Y z.1 z.2))
  have he (i : ι) : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      vectorIto T hBm ψ t ω i =
        predItoIntegral (μ:=μ) T hBm (diffusion_predictable hBm c hY.predictable i) t ω := by
    apply continuousMod_eq_predIto hB T hBm hBc (diffusion_predictable hBm c hY.predictable i)
    · filter_upwards [hY.continuous] with ω hω
      exact (continuous_apply i).comp_continuousOn
        (c.diffusion_continuous.comp_continuousOn (continuousOn_id.prodMk hω))
    · intro t ω
      exact (norm_le_pi_norm (c.diffusion t (Y t ω)) i).trans (hbound t (Y t ω))
    · filter_upwards [evalLp_coe (mα := (natFiltration hBm).predictable)
        (trimMeasure_T (μ:=μ) T hBm) i ψ,hY.diffusion_memLp.coeFn_toLp] with z hz hψ
      exact hz.trans (congrFun hψ i)
  filter_upwards [hY.equation,ae_all_iff.mpr he] with ω hω hi
  intro t ht i
  exact (hω t ht.2 i).trans (by rw [hi i t ht])

/-- A coordinate with zero diffusion along a whole prefix satisfies the
ordinary drift integral equation on that prefix, even when the prefix is random. -/
theorem strong_solution_finite_variation_coordinate
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) {Y : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hbound : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound) (i : ι) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      (∀ s ∈ Icc 0 t, c.diffusion s (Y s ω) i = 0) →
      Y t ω i = x₀ i + (∫ s in Ioc (0:ℝ≥0) t, c.drift s (Y s ω) i ∂timeMeasure) := by
  have hc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => c.diffusion t (Y t ω) i) (Icc 0 T) := by
    filter_upwards [hY.continuous] with ω hω
    exact (continuous_apply i).comp_continuousOn
      (c.diffusion_continuous.comp_continuousOn (continuousOn_id.prodMk hω))
  have hp0 : IsStronglyPredictable (natFiltration hBm) (fun _ _ => (0:ℝ)) := stronglyMeasurable_const
  filter_upwards [strong_solution_predIto_equation hB T hBm hBc c x₀ hY hbound,
    predIto_prefix_locality hB T hBm hBc (diffusion_predictable hBm c hY.predictable i) hp0 hc
      (ae_of_all _ fun _ => continuousOn_const),predIto_zero hB T hBm hBc] with ω he hl hz
  intro t ht hzero
  simpa only [hl t ht hzero,hz t ht,add_zero] using he t ht i

/-- A strong vector solution has a genuine continuous local-martingale
decomposition, coordinate by coordinate, for the null-augmented filtration. -/
theorem strong_solution_localMartingale_decomposition
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) {Y : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y) :
    ∃ M : ℝ≥0 → Ω → (ι → ℝ),
      (∀ ω, Continuous (fun t => M t ω)) ∧
      (∀ i, IsLocalMartingale (fun t ω => M t ω i) (augFiltration (μ:=μ) hBm) μ) ∧
      StronglyAdapted (augFiltration (μ:=μ) hBm) M ∧
      (∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, ∀ i : ι,
        Y t ω i = x₀ i + (∫ s in Ioc (0:ℝ≥0) t, c.drift s (Y s ω) i ∂timeMeasure) + M t ω i) := by
  let ψ := hY.diffusion_memLp.toLp (fun z : ℝ≥0 × Ω => c.diffusion z.1 (Y z.1 z.2))
  have hex (i : ι) := exists_continuous_localMartingale_modification hB T hBm hBc
    (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i ψ)
  choose M hMe hMc hMl hMa using hex
  have he (i : ι) : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, M i t ω = vectorIto T hBm ψ t ω i := by
    apply ae_forall_eq_of_continuousOn (ae_of_all _ fun ω => (hMc i ω).continuousOn)
      (itoContinuousMod_continuousOn hB T hBm hBc _)
    intro t ht
    exact (hMe i t ht.2).trans (itoContinuousMod_modification hB T hBm hBc _ ht.2).symm
  refine ⟨fun t ω i => M i t ω,?_,hMl,?_,?_⟩
  · intro ω
    exact continuous_pi (fun i => hMc i ω)
  · intro t
    letI : MeasurableSpace Ω := augFiltration (μ:=μ) hBm t
    exact (measurable_pi_lambda _ (fun i => (hMa i t).measurable)).stronglyMeasurable
  · filter_upwards [hY.equation,ae_all_iff.mpr he] with ω hω hi
    intro t ht i
    exact (hω t ht.2 i).trans (by rw [hi i t ht])

end
end ChainFountainStochastic.LocalIntegralBridge


namespace ChainFountainStochastic.ConstructedExit
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoLocalMartingale
  MathFin.ItoIntegralProcessLocalMartingaleGeneral
open VectorSDE MechanicalCutoff LocalIntegralBridge
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 600000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}

/-- Repair almost-sure path continuity using the null augmentation, retain the
deterministic initial state on every path, and freeze the process at the horizon.
No continuity or adaptedness is asserted for the original exceptional paths. -/
theorem exists_continuous_adapted_version
    {E : Type*} [NormedAddCommGroup E] [MeasurableSpace E] [BorelSpace E]
    {ℱ : Filtration ℝ≥0 mΩ} {Y : ℝ≥0 → Ω → E} {x₀ : E} {T : ℝ≥0}
    (hY : StronglyAdapted ℱ Y)
    (hc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => Y t ω) (Icc 0 T))
    (h₀ : ∀ ω, Y 0 ω = x₀) :
    ∃ X : ℝ≥0 → Ω → E,
      StronglyAdapted (nullAugmentation ℱ μ) X ∧
      (∀ ω, Continuous (fun t => X t ω)) ∧
      (∀ ω, X 0 ω = x₀) ∧
      (∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, X t ω = Y t ω) := by
  classical
  obtain ⟨G,hG,hGc,hGood⟩ := exists_nullsAlg_of_ae hc
  let X : ℝ≥0 → Ω → E := fun t ω => if ω ∈ G then Y (min t T) ω else x₀
  refine ⟨X,?_,?_,?_,?_⟩
  · intro t
    letI : MeasurableSpace Ω := nullAugmentation ℱ μ t
    have hGt : MeasurableSet[nullAugmentation ℱ μ t] G :=
      (le_sup_right : nullsAlg mΩ μ ≤ ℱ t ⊔ nullsAlg mΩ μ) G hG
    have hYX : StronglyMeasurable[nullAugmentation ℱ μ t] (Y (min t T)) :=
      (hY (min t T)).mono ((ℱ.mono (min_le_left t T)).trans
        (le_sup_left : ℱ t ≤ ℱ t ⊔ nullsAlg mΩ μ))
    exact StronglyMeasurable.ite hGt hYX stronglyMeasurable_const
  · intro ω
    by_cases hω : ω ∈ G
    · simpa only [X,if_pos hω,Function.comp_def,id_eq] using (hGood ω hω).comp_continuous
        (continuous_id.min continuous_const) (fun t => ⟨zero_le,min_le_right t T⟩)
    · simpa only [X,if_neg hω] using (continuous_const : Continuous (fun _ : ℝ≥0 => x₀))
  · intro ω
    simp [X,h₀]
  · have hGae : ∀ᵐ ω ∂μ, ω ∈ G := by rw [ae_iff]; exact hGc
    filter_upwards [hGae] with ω hω
    intro t ht
    simp only [X,if_pos hω,min_eq_left ht.2]

/-- First exit from a norm ball, capped at the finite construction horizon. -/
def normExit {E : Type*} [NormedAddCommGroup E]
    (X : ℝ≥0 → Ω → E) (x₀ : E) (R : ℝ) (T : ℝ≥0) (ω : Ω) : WithTop ℝ≥0 :=
  min (exitTime (fun t ω => ‖X t ω-x₀‖/R) 1 ω) T

/-- The actual exit of a continuous adapted finite-dimensional process is a
positive bounded stopping time and its stopped path stays in the closed ball. -/
theorem normExit_properties
    {E : Type*} [NormedAddCommGroup E] [MeasurableSpace E] [BorelSpace E]
    {ℱ : Filtration ℝ≥0 mΩ} {X : ℝ≥0 → Ω → E} {x₀ : E} {R : ℝ} {T : ℝ≥0}
    (hX : StronglyAdapted ℱ X) (hc : ∀ ω, Continuous (fun t => X t ω))
    (h₀ : ∀ ω, X 0 ω = x₀) (hR : 0 < R) (hT : 0 < T) :
    IsStoppingTime ℱ (normExit X x₀ R T) ∧
      (∀ ω, ⊥ < normExit X x₀ R T ω) ∧
      (∀ ω, normExit X x₀ R T ω ≤ T) ∧
      (∀ t ω, stoppedProcess X (normExit X x₀ R T) t ω ∈ Metric.closedBall x₀ R) := by
  let G : ℝ≥0 → Ω → ℝ := fun t ω => ‖X t ω-x₀‖/R
  have hGc : ∀ ω, Continuous (fun t => G t ω) :=
    fun ω => (((hc ω).sub continuous_const).norm).div_const R
  have hGm : ∀ t, Measurable[ℱ t] (G t) :=
    fun t => (((hX t).sub stronglyMeasurable_const).norm.div stronglyMeasurable_const).measurable
  have hτ := isStoppingTime_exitTime_of_measurable hGm hGc 1
  have hpos (ω : Ω) : ⊥ < exitTime G 1 ω := by
    apply lt_of_not_ge
    intro hn
    obtain ⟨s,hs,hg⟩ := (exitTime_le_iff hGc 1 0 ω).mp hn
    have hs0 : s = 0 := le_antisymm hs.2 zero_le
    norm_num [hs0,G,h₀] at hg
  refine ⟨hτ.min (isStoppingTime_const ℱ T),?_,fun _ => min_le_right _ _,?_⟩
  · intro ω
    exact lt_min (hpos ω) (by
      change ((0:ℝ≥0):WithTop ℝ≥0) < (T:WithTop ℝ≥0)
      exact WithTop.coe_lt_coe.mpr hT)
  · intro t ω
    have hb := abs_le_of_le_exitTime hGc (hpos ω)
      (s := (min (t:WithTop ℝ≥0) (normExit X x₀ R T ω)).untopA)
      (by rw [coe_untopA_min]; exact (min_le_right _ _).trans (min_le_left _ _))
    have hq := (le_abs_self _).trans hb
    change ‖X _ ω-x₀‖/R ≤ (1:ℕ) at hq
    have hn := (div_le_iff₀ hR).mp hq
    simpa only [Nat.cast_one,one_mul,Metric.mem_closedBall,dist_eq_norm,stoppedProcess] using hn

/-- Before the horizon the exit event is precisely a hit of the ball boundary
or exterior. This fixes the meaning of the constructed stopping time. -/
theorem normExit_le_iff
    {E : Type*} [NormedAddCommGroup E] {X : ℝ≥0 → Ω → E} {x₀ : E} {R : ℝ}
    (hc : ∀ ω, Continuous (fun t => X t ω)) (hR : 0 < R)
    {T t : ℝ≥0} (ht : t < T) (ω : Ω) :
    normExit X x₀ R T ω ≤ t ↔ ∃ s ∈ Icc 0 t, R ≤ dist (X s ω) x₀ := by
  have hGc : ∀ ω, Continuous (fun t => ‖X t ω-x₀‖/R) :=
    fun ω => (((hc ω).sub continuous_const).norm).div_const R
  have hnot : ¬ (T:WithTop ℝ≥0) ≤ t := by exact_mod_cast not_le.mpr ht
  rw [normExit,min_le_iff,or_iff_left hnot,exitTime_le_iff hGc]
  congr! 2 with s
  rw [abs_of_nonneg (div_nonneg (norm_nonneg _) hR.le),le_div_iff₀ hR]
  simp only [Nat.cast_one,one_mul,dist_eq_norm]

/-- On a common conull event the original strong solution remains inside the
localization ball up to the exit of its continuous adapted representative. -/
theorem original_state_mem_before_exit
    {E : Type*} [NormedAddCommGroup E]
    {X Y : ℝ≥0 → Ω → E} {x₀ : E} {R : ℝ} {T : ℝ≥0}
    (hτ : ∀ ω, normExit X x₀ R T ω ≤ T)
    (hb : ∀ t ω, stoppedProcess X (normExit X x₀ R T) t ω ∈ Metric.closedBall x₀ R)
    (he : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, X t ω = Y t ω) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ normExit X x₀ R T ω →
      Y t ω ∈ Metric.closedBall x₀ R := by
  filter_upwards [he] with ω hω
  intro t ht
  have htT : t ≤ T := WithTop.coe_le_coe.mp (ht.trans (hτ ω))
  rw [←hω t ⟨zero_le,htT⟩]
  simpa only [stoppedProcess_eq_of_le ht] using hb t ω

/-- The construction supplies a positive genuine stopping time for the
original mechanical fields. The integral solution is constructed, and the
coefficients agree with the original fields up to this random exit. This does
not assert compatibility of solutions obtained from different cutoffs. -/
theorem exists_constructed_mechanical_exit
    [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
    (hB : IsPreBrownianReal B μ) (hBm : ∀ t, Measurable (B t))
    (hBc : ∀ ω, Continuous (fun t => B t ω))
    (d : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi lo hi : State) (hlo : lo ≤ hi) (hh : 0 < lo 0)
    (hpmem : ∀ t, p t ∈ Icc plo phi) (x₀ : State) (R : ℝ) (hR : 0 < R)
    (hball : Metric.closedBall x₀ R ⊆ Icc lo hi) :
    ∃ c : Coefficients (Fin 3), ∃ T : ℝ≥0, 0 < T ∧
      ∃ Y X : ℝ≥0 → Ω → State,
        StrongSolution (μ:=μ) T hBm c x₀ Y ∧
        StronglyAdapted (augFiltration (μ:=μ) hBm) X ∧
        (∀ ω, Continuous (fun t => X t ω)) ∧
        (∀ ω, X 0 ω = x₀) ∧
        (∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, X t ω = Y t ω) ∧
        IsStoppingTime (augFiltration (μ:=μ) hBm) (normExit X x₀ R T) ∧
        (∀ ω, ⊥ < normExit X x₀ R T ω) ∧
        (∀ ω, normExit X x₀ R T ω ≤ T) ∧
        (∀ t ω, stoppedProcess X (normExit X x₀ R T) t ω ∈ Icc lo hi) ∧
        (∀ᵐ ω ∂μ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ normExit X x₀ R T ω →
          c.drift t (Y t ω) = d.drift (p t,Y t ω) ∧
          c.diffusion t (Y t ω) = d.diffusion (p t,Y t ω)) ∧
        (∃ hpred : IsStronglyPredictable (natFiltration hBm) Y,
          ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ normExit X x₀ R T ω → ∀ i : Fin 3,
          Y t ω i = x₀ i + (∫ s in Ioc (0:ℝ≥0) t, d.drift (p s,Y s ω) i ∂timeMeasure) +
            MathFin.ItoIntegralLocalised.predItoIntegral (μ:=μ) T hBm
              (diffusion_predictable hBm c hpred i) t ω) := by
  obtain ⟨c,_,_,hb,hσ,hbound⟩ := d.exists_cutoff p hp plo phi lo hi hlo hh hpmem
  obtain ⟨T,hT,Y,hY,_⟩ := exists_unique_local_strong_solution hB hBm hBc c x₀
  obtain ⟨X,hXm,hXc,hX₀,hXY⟩ := exists_continuous_adapted_version
    hY.predictable.stronglyAdapted hY.continuous hY.initial
  obtain ⟨hτ,hpos,hcap,hstop⟩ := normExit_properties hXm hXc hX₀ hR hT
  refine ⟨c,T,hT,Y,X,hY,hXm,hXc,hX₀,hXY,hτ,hpos,hcap,
    (fun t ω => hball (hstop t ω)),?_,?_⟩
  · filter_upwards [original_state_mem_before_exit hcap hstop hXY] with ω hω
    intro t ht
    exact ⟨hb t (Y t ω) (hball (hω t ht)),hσ t (Y t ω) (hball (hω t ht))⟩
  · refine ⟨hY.predictable,?_⟩
    filter_upwards [strong_solution_predIto_equation hB T hBm hBc c x₀ hY
      (fun t x => (hbound t x).2), original_state_mem_before_exit hcap hstop hXY]
      with ω he hm
    intro t ht i
    have htT : t ≤ T := WithTop.coe_le_coe.mp (ht.trans (hcap ω))
    have hi : (∫ s in Ioc (0:ℝ≥0) t, c.drift s (Y s ω) i ∂timeMeasure) =
        ∫ s in Ioc (0:ℝ≥0) t, d.drift (p s,Y s ω) i ∂timeMeasure := by
      apply setIntegral_congr_fun measurableSet_Ioc
      intro s hs
      exact congrFun (hb s (Y s ω) (hball (hm s ((WithTop.coe_le_coe.mpr hs.2).trans ht)))) i
    simpa only [hi] using he t ⟨zero_le,htT⟩ i

/-- Every positive-height initial state admits explicit finite cutoff boxes
containing a ball about that state. No pre-existing trajectory is required. -/
theorem exists_initial_localization_box (x₀ : State) (hh : 0 < x₀ 0) :
    ∃ lo hi : State, ∃ R : ℝ, 0 < R ∧ lo ≤ hi ∧ 0 < lo 0 ∧
      Metric.closedBall x₀ R ⊆ Icc lo hi := by
  let R := x₀ 0 / 2
  let lo : State := fun i => x₀ i - R
  let hi : State := fun i => x₀ i + R
  have hR : 0 < R := half_pos hh
  refine ⟨lo,hi,R,hR,(fun i => by dsimp [lo,hi]; linarith),?_,?_⟩
  · dsimp [lo,R]
    linarith
  · intro x hx
    have hn : ‖x-x₀‖ ≤ R := by simpa only [Metric.mem_closedBall,dist_eq_norm] using hx
    have hcoord (i : Fin 3) : |x i-x₀ i| ≤ R :=
      (norm_le_pi_norm (x-x₀) i).trans hn
    exact ⟨fun i => by have := (abs_le.mp (hcoord i)).1; dsimp [lo]; linarith,
      fun i => by have := (abs_le.mp (hcoord i)).2; dsimp [hi]; linarith⟩

end
end ChainFountainStochastic.ConstructedExit


namespace ChainFountainStochastic.GaussianTail
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin Asymptotics
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 600000

/-- The normal density divided by the positive threshold tends to zero. -/
theorem density_div_tendsto_zero :
    Tendsto (fun x : ℝ => gaussianPDFReal 0 1 x / x) atTop (𝓝 0) := by
  apply squeeze_zero'
    (eventually_gt_atTop 0 |>.mono fun x hx => div_nonneg (gaussianPDFReal_nonneg _ _ _) hx.le)
    (eventually_gt_atTop 0 |>.mono fun x hx =>
      div_le_div_of_nonneg_right (gaussianPDFReal_zero_one_le_one x) hx.le)
  simpa only [one_div] using (tendsto_inv_atTop_zero : Tendsto (fun x : ℝ => x⁻¹) atTop (𝓝 0))

/-- The correctly normalized Mills asymptotic, derived from the derivatives of
the normal density and CDF using L'Hopital's rule. -/
theorem tail_ratio_tendsto_one :
    Tendsto (fun x : ℝ => (1 - Phi x) / (gaussianPDFReal 0 1 x / x)) atTop (𝓝 1) := by
  have hf : ∀ᶠ x : ℝ in atTop,
      HasDerivAt (fun x => 1 - Phi x) (-gaussianPDFReal 0 1 x) x :=
    Eventually.of_forall fun x => by simpa using (hasDerivAt_Phi x).const_sub 1
  have hg : ∀ᶠ x : ℝ in atTop,
      HasDerivAt (fun x => gaussianPDFReal 0 1 x / x)
        (-(1 + (x⁻¹)^2) * gaussianPDFReal 0 1 x) x := by
    filter_upwards [eventually_gt_atTop (0:ℝ)] with x hx
    convert (hasDerivAt_gaussianPDFReal_zero_one x).div (hasDerivAt_id x) hx.ne' using 1 <;> (try simp only [id_eq]) <;>
      (first | rfl | (field_simp [hx.ne']; ring))
  have hgn : ∀ᶠ x : ℝ in atTop,
      -(1 + (x⁻¹)^2) * gaussianPDFReal 0 1 x ≠ 0 :=
    Eventually.of_forall fun x => mul_ne_zero (neg_ne_zero.mpr (by positivity))
      (gaussianPDFReal_pos 0 1 x (by norm_num)).ne'
  have hf0 : Tendsto (fun x : ℝ => 1 - Phi x) atTop (𝓝 0) := by
    simpa using (tendsto_const_nhds : Tendsto (fun _ : ℝ => (1:ℝ)) atTop (𝓝 1)).sub tendsto_Phi_atTop
  have hratio : Tendsto
      (fun x : ℝ => (-gaussianPDFReal 0 1 x) /
        (-(1 + (x⁻¹)^2) * gaussianPDFReal 0 1 x)) atTop (𝓝 1) := by
    have h := (tendsto_const_nhds : Tendsto (fun _ : ℝ => (1:ℝ)) atTop (𝓝 1)).div
      (tendsto_const_nhds.add ((tendsto_inv_atTop_zero :
        Tendsto (fun x : ℝ => x⁻¹) atTop (𝓝 0)).pow 2)) (by norm_num : (1:ℝ) + 0^2 ≠ 0)
    convert h using 1
    · ext x
      have hp := (gaussianPDFReal_pos 0 1 x (by norm_num)).ne'
      rw [Pi.div_apply,neg_mul,neg_div_neg_eq,div_mul_eq_div_div_swap,div_self hp]
    · norm_num
  exact HasDerivAt.lhopital_zero_atTop hf hg hgn hf0 density_div_tendsto_zero hratio

/-- Equivalent form of the Gaussian upper-tail asymptotic. -/
theorem tail_isEquivalent_density_div :
    (fun x : ℝ => 1 - Phi x) ~[atTop] (fun x => gaussianPDFReal 0 1 x / x) :=
  isEquivalent_of_tendsto_one tail_ratio_tendsto_one

/-- The result applies to the probability of a standard normal upper tail. -/
theorem gaussianReal_tail_isEquivalent :
    (fun x : ℝ => (gaussianReal 0 1).real (Ioi x)) ~[atTop]
      (fun x => gaussianPDFReal 0 1 x / x) := by
  simpa only [Measure.real,gaussianReal_Ioi_toReal,Phi_neg] using tail_isEquivalent_density_div

/-- Explicit normalization: the leading constant is `1 / sqrt (2*pi)`. -/
theorem gaussianReal_tail_isEquivalent_exp :
    (fun x : ℝ => (gaussianReal 0 1).real (Ioi x)) ~[atTop]
      (fun x => Real.exp (-(x^2) / 2) / (Real.sqrt (2 * Real.pi) * x)) := by
  convert gaussianReal_tail_isEquivalent using 1
  ext x
  simp only [gaussianPDFReal_def,NNReal.coe_one,mul_one,sub_zero]
  ring

end
end ChainFountainStochastic.GaussianTail


namespace ChainFountainStochastic.PrefixLimits
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM
open VectorSDE
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 600000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}

/-- Lebesgue measure on the nonnegative time axis has full topological support. -/
theorem timeMeasure_open_pos : Measure.IsOpenPosMeasure timeMeasure := by
  constructor
  intro U hU hne
  obtain ⟨x,hx⟩ := hne
  obtain ⟨ε,hε,hεU⟩ := Metric.isOpen_iff.mp hU x hx
  let δ : ℝ≥0 := ⟨ε/2,le_of_lt (half_pos hε)⟩
  have hsub : Ioc x (x+δ) ⊆ U := by
    intro t ht
    apply hεU
    have hxt : (x:ℝ) ≤ (t:ℝ) := ht.1.le
    rw [Metric.mem_ball,NNReal.dist_eq,abs_of_nonneg (sub_nonneg.mpr hxt)]
    have hupper : (t:ℝ) ≤ (x:ℝ)+ε/2 := ht.2
    linarith
  have hpos : 0 < timeMeasure (Ioc x (x+δ)) := by
    rw [timeMeasure_Ioc]
    apply ENNReal.ofReal_pos.mpr
    simp only [NNReal.coe_add]
    change 0 < (x:ℝ)+ε/2-x
    linarith
  exact ne_of_gt (hpos.trans_le (measure_mono hsub))

/-- A trimmed product almost-everywhere statement holds on almost every
sample path for almost every time. No measurability of the predicate is needed. -/
theorem ae_path_of_trim (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    {P : ℝ≥0 × Ω → Prop}
    (h : ∀ᵐ z ∂trimMeasure_T (μ:=μ) T hBm, P z) :
    ∀ᵐ ω ∂μ, ∀ᵐ t ∂timeMeasure_T T, P (t,ω) := by
  have hp : ∀ᵐ z ∂(timeMeasure_T T).prod μ, P z :=
    ae_of_ae_trim (natFiltration hBm).predictable_le_prod h
  exact Measure.ae_ae_of_ae_prod
    (Measure.measurePreserving_swap.quasiMeasurePreserving.ae hp)

/-- Agreement on an arbitrary random prefix survives an L2 limit whenever
the limit and comparison paths are continuous. The time-zero value is explicit,
because product Lebesgue measure alone cannot determine it. -/
theorem prefix_agreement_of_tendsto_Lp
    {ι : Type*} [Fintype ι] [DecidableEq ι]
    (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (Xn : ℕ → ProcessLp (μ:=μ) (ι:=ι) T hBm)
    (X : ProcessLp (μ:=μ) (ι:=ι) T hBm)
    (hlim : Tendsto Xn atTop (𝓝 X))
    {Yn : ℕ → ℝ≥0 → Ω → (ι → ℝ)} {Y Z : ℝ≥0 → Ω → (ι → ℝ)}
    (hn : ∀ n, ⇑(Xn n) =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry (Yn n))
    (hX : ⇑X =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry Y)
    (hYc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => Y t ω) (Icc 0 T))
    (hZc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => Z t ω) (Icc 0 T))
    (hzero : ∀ ω, Y 0 ω = Z 0 ω)
    (τ : Ω → ℝ≥0)
    (he : ∀ n, ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω → Yn n t ω = Z t ω) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω → Y t ω = Z t ω := by
  letI : Measure.IsOpenPosMeasure timeMeasure := timeMeasure_open_pos
  obtain ⟨ns,_,hns⟩ := (tendstoInMeasure_of_tendsto_Lp hlim).exists_seq_tendsto_ae
  have hpath : ∀ᵐ ω ∂μ, ∀ᵐ t ∂timeMeasure_T T,
      Tendsto (fun k => Yn (ns k) t ω) atTop (𝓝 (Y t ω)) := by
    refine ae_path_of_trim (μ:=μ) T hBm
      (P := fun z => Tendsto (fun k => Yn (ns k) z.1 z.2) atTop (𝓝 (Y z.1 z.2))) ?_
    filter_upwards [hns,ae_all_iff.mpr hn,hX] with z hz hn hX
    simpa only [hn,hX,Function.uncurry] using hz
  filter_upwards [hpath,hYc,hZc,ae_all_iff.mpr he] with ω hp hY hZ he
  intro t ht hτ
  rcases eq_zero_or_pos t with rfl | htp
  · exact hzero ω
  have hp' : ∀ᵐ s ∂timeMeasure.restrict (Ioc 0 t),
      Tendsto (fun k => Yn (ns k) s ω) atTop (𝓝 (Y s ω)) :=
    ae_restrict_of_ae_restrict_of_subset (Ioc_subset_Ioc_right ht.2) hp
  have heq : (fun s => Y s ω) =ᵐ[timeMeasure.restrict (Ioc 0 t)] (fun s => Z s ω) := by
    filter_upwards [hp',ae_restrict_mem measurableSet_Ioc] with s hs hsI
    have he' : ∀ k, Yn (ns k) s ω = Z s ω :=
      fun k => he (ns k) s ⟨zero_le,hsI.2.trans ht.2⟩ (hsI.2.trans hτ)
    exact tendsto_nhds_unique hs (by simpa only [he'] using
      (tendsto_const_nhds : Tendsto (fun _ : ℕ => Z s ω) atTop (𝓝 (Z s ω))))
  exact Measure.eqOn_Ioc_of_ae_eq timeMeasure heq
    (hY.mono (Ioc_subset_Icc_self.trans (Icc_subset_Icc_right ht.2)))
    (hZ.mono (Ioc_subset_Icc_self.trans (Icc_subset_Icc_right ht.2))) ⟨htp,le_rfl⟩

end
end ChainFountainStochastic.PrefixLimits


namespace ChainFountainStochastic.StoppedUniqueness
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM
  MathFin.ItoIntegralProcessContinuousModification MathFin.ItoIntegralProcessGeneral
  MathFin.ItoIntegralLocalised MathFin.LocalisationInMeasure
open VectorSDE VectorLp LocalIntegralBridge PrefixLimits
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 900000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The continuous predictable representative of one coupled Picard step. -/
def picardPath (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (c : Coefficients ι) (x₀ : ι → ℝ) (X : ProcessLp (μ:=μ) (ι:=ι) T hBm) :=
  fun t ω => x₀ + vectorDrift T hBm (c.driftLp T hBm X) t ω +
    vectorIto T hBm (c.diffusionLp T hBm X) t ω

theorem picardPath_predictable
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (X : ProcessLp (μ:=μ) (ι:=ι) T hBm) :
    IsStronglyPredictable (natFiltration hBm) (picardPath T hBm c x₀ X) :=
  (stronglyMeasurable_const.add (vectorDrift_predictable T hBm _)).add
    (vectorIto_predictable hB T hBm hBc _)

theorem picardPath_continuous
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (X : ProcessLp (μ:=μ) (ι:=ι) T hBm) :
    ∀ᵐ ω ∂μ, ContinuousOn (fun t => picardPath T hBm c x₀ X t ω) (Icc 0 T) := by
  filter_upwards [vectorDrift_continuous T hBm (c.driftLp T hBm X),
    vectorIto_continuous hB T hBm hBc (c.diffusionLp T hBm X)] with ω hd hi
  exact (continuousOn_const.add hd).add hi

/-- A Picard step uses the actual coefficients of any continuous predictable
representative of its input class. -/
theorem picardPath_equation
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (X : ProcessLp (μ:=μ) (ι:=ι) T hBm)
    {U : ℝ≥0 → Ω → (ι → ℝ)}
    (hUp : IsStronglyPredictable (natFiltration hBm) U)
    (hUc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => U t ω) (Icc 0 T))
    (hX : ⇑X =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry U)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, ∀ i : ι,
      picardPath T hBm c x₀ X t ω i = x₀ i +
        (∫ s in Ioc (0:ℝ≥0) t, c.drift s (U s ω) i ∂timeMeasure) +
        predItoIntegral (μ:=μ) T hBm (diffusion_predictable hBm c hUp i) t ω := by
  have hd : ⇑(c.driftLp T hBm X) =ᵐ[trimMeasure_T (μ:=μ) T hBm]
      fun z => c.drift z.1 (U z.1 z.2) := by
    filter_upwards [coefficientLp_coe (mα := (natFiltration hBm).predictable)
      (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.drift_continuous
      c.drift_lipschitz (fun z : ℝ≥0 × Ω => c.drift_zero z.1) X,hX] with z hz hX
    exact hz.trans (congrArg (c.drift z.1) hX)
  have hs : ⇑(c.diffusionLp T hBm X) =ᵐ[trimMeasure_T (μ:=μ) T hBm]
      fun z => c.diffusion z.1 (U z.1 z.2) := by
    filter_upwards [coefficientLp_coe (mα := (natFiltration hBm).predictable)
      (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.diffusion_continuous
      c.diffusion_lipschitz (fun z : ℝ≥0 × Ω => c.diffusion_zero z.1) X,hX] with z hz hX
    exact hz.trans (congrArg (c.diffusion z.1) hX)
  have hi (i : ι) : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      vectorIto T hBm (c.diffusionLp T hBm X) t ω i =
        predItoIntegral (μ:=μ) T hBm (diffusion_predictable hBm c hUp i) t ω := by
    apply continuousMod_eq_predIto hB T hBm hBc (diffusion_predictable hBm c hUp i)
    · filter_upwards [hUc] with ω hω
      exact (continuous_apply i).comp_continuousOn
        (c.diffusion_continuous.comp_continuousOn (continuousOn_id.prodMk hω))
    · intro t ω
      exact (norm_le_pi_norm (c.diffusion t (U t ω)) i).trans (hb t (U t ω))
    · filter_upwards [evalLp_coe (mα := (natFiltration hBm).predictable)
        (trimMeasure_T (μ:=μ) T hBm) i (c.diffusionLp T hBm X),hs] with z hz hs
      exact hz.trans (congrFun hs i)
  filter_upwards [vectorDrift_integral_all_times T hBm (c.driftLp T hBm X) hd,
    ae_all_iff.mpr hi] with ω hd hi
  intro t ht i
  change x₀ i + vectorDrift T hBm (c.driftLp T hBm X) t ω i +
    vectorIto T hBm (c.diffusionLp T hBm X) t ω i = _
  rw [hd t ht.2 i,hi i t ht]

/-- If an input already agrees with a solution on a random prefix, one Picard
step preserves that agreement, provided the two coefficient fields agree along
the comparison solution there. This is proved using integral locality. -/
theorem picardPath_preserves_prefix
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c d : Coefficients ι) (x₀ : ι → ℝ)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖d.diffusion t x‖ ≤ d.bound)
    {Z U : ℝ≥0 → Ω → (ι → ℝ)} (hZ : StrongSolution (μ:=μ) T hBm d x₀ Z)
    (X : ProcessLp (μ:=μ) (ι:=ι) T hBm)
    (hUp : IsStronglyPredictable (natFiltration hBm) U)
    (hUc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => U t ω) (Icc 0 T))
    (hX : ⇑X =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry U)
    (τ : Ω → ℝ≥0)
    (hcoeff : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω →
      c.drift t (Z t ω) = d.drift t (Z t ω) ∧
      c.diffusion t (Z t ω) = d.diffusion t (Z t ω))
    (he : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω → U t ω = Z t ω) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω →
      picardPath T hBm c x₀ X t ω = Z t ω := by
  have hlocal (i : ι) := predIto_prefix_locality hB T hBm hBc
    (diffusion_predictable hBm c hUp i) (diffusion_predictable hBm d hZ.predictable i)
    (hUc.mono fun ω hω => (continuous_apply i).comp_continuousOn
      (c.diffusion_continuous.comp_continuousOn (continuousOn_id.prodMk hω)))
    (hZ.continuous.mono fun ω hω => (continuous_apply i).comp_continuousOn
      (d.diffusion_continuous.comp_continuousOn (continuousOn_id.prodMk hω)))
  filter_upwards [picardPath_equation hB T hBm hBc c x₀ X hUp hUc hX hb,
    strong_solution_predIto_equation hB T hBm hBc d x₀ hZ hd,
    ae_all_iff.mpr hlocal,hcoeff,he] with ω hP hZ hl hc he
  intro t ht hτ
  ext i
  rw [hP t ht i,hZ t ht i]
  have hpre (s : ℝ≥0) (hs : s ∈ Icc 0 t) : s ∈ Icc 0 T ∧ s ≤ τ ω :=
    ⟨⟨hs.1,hs.2.trans ht.2⟩,hs.2.trans hτ⟩
  have hi := hl i t ht (fun s hs => by
    rw [he s (hpre s hs).1 (hpre s hs).2]
    exact congrFun (hc s (hpre s hs).1 (hpre s hs).2).2 i)
  rw [hi]
  congr 2
  apply setIntegral_congr_fun measurableSet_Ioc
  intro s hs
  have hs' : s ∈ Icc 0 t := ⟨hs.1.le,hs.2⟩
  change c.drift s (U s ω) i = d.drift s (Z s ω) i
  rw [he s (hpre s hs').1 (hpre s hs').2]
  exact congrFun (hc s (hpre s hs').1 (hpre s hs').2).1 i

/-- Pathwise uniqueness before any random prefix on which the coefficient
fields agree along the comparison solution. Neither the equality of solutions
nor a stopped energy estimate is assumed. -/
theorem strong_solution_prefix_unique
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c d : Coefficients ι) (x₀ : ι → ℝ)
    (hc : contractionFactor c T < 1)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖d.diffusion t x‖ ≤ d.bound)
    {Y Z : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hZ : StrongSolution (μ:=μ) T hBm d x₀ Z)
    (τ : Ω → ℝ≥0)
    (hcoeff : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω →
      c.drift t (Z t ω) = d.drift t (Z t ω) ∧
      c.diffusion t (Z t ω) = d.diffusion t (Z t ω)) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω → Y t ω = Z t ω := by
  let f := picard hB T hBm hBc c x₀
  let Z₀ := hZ.state_memLp.toLp (Function.uncurry Z)
  let Yn (n : ℕ) := picardPath T hBm c x₀ (f^[n] Z₀)
  have hcoe (n : ℕ) : ⇑(f^[n+1] Z₀) =ᵐ[trimMeasure_T (μ:=μ) T hBm]
      Function.uncurry (Yn n) := by
    unfold Yn picardPath Function.uncurry
    simpa only [Function.iterate_succ_apply',f] using
      picard_coe hB T hBm hBc c x₀ (f^[n] Z₀)
  have he (n : ℕ) : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω → Yn n t ω = Z t ω := by
    induction n with
    | zero =>
      exact picardPath_preserves_prefix hB T hBm hBc c d x₀ hb hd hZ Z₀
        hZ.predictable hZ.continuous hZ.state_memLp.coeFn_toLp τ hcoeff
        (ae_of_all _ fun _ _ _ _ => rfl)
    | succ n ih =>
      exact picardPath_preserves_prefix hB T hBm hBc c d x₀ hb hd hZ (f^[n+1] Z₀)
        (picardPath_predictable hB T hBm hBc c x₀ _) (picardPath_continuous hB T hBm hBc c x₀ _)
        (hcoe n) τ hcoeff ih
  have hq : 0 ≤ contractionFactor c T := by dsimp [contractionFactor]; positivity
  have hf : ContractingWith (Real.toNNReal (contractionFactor c T)) f := by
    refine ⟨?_,LipschitzWith.of_dist_le_mul fun X Y => ?_⟩
    · rw [←NNReal.coe_lt_coe,Real.coe_toNNReal _ hq,NNReal.coe_one]; exact hc
    · rw [dist_eq_norm,dist_eq_norm,Real.coe_toNNReal _ hq]
      exact picard_sub_norm_le hB T hBm hBc c x₀ X Y
  have hfix : hf.fixedPoint f = hY.state_memLp.toLp (Function.uncurry Y) :=
    (hf.fixedPoint_unique (hY.fixed_point hB T hBm hBc c x₀)).symm
  have hlim : Tendsto (fun n => f^[n+1] Z₀) atTop
      (𝓝 (hY.state_memLp.toLp (Function.uncurry Y))) := by
    rw [←hfix]
    exact (hf.tendsto_iterate_fixedPoint Z₀).comp (tendsto_add_atTop_nat 1)
  exact prefix_agreement_of_tendsto_Lp T hBm (fun n => f^[n+1] Z₀) _ hlim
    hcoe hY.state_memLp.coeFn_toLp hY.continuous hZ.continuous
    (fun ω => (hY.initial ω).trans (hZ.initial ω).symm) τ he

end
end ChainFountainStochastic.StoppedUniqueness


namespace ChainFountainStochastic.CutoffCompatibility
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralProcessLocalMartingaleGeneral
open VectorSDE MechanicalCutoff ConstructedExit StoppedUniqueness
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 900000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}

/-- Two globally Lipschitz coefficient fields admit a common positive
contraction horizon. The time is constructed from their continuity at zero. -/
theorem exists_common_contraction_horizon
    {ι : Type*} [Fintype ι] (c d : Coefficients ι) :
    ∃ T : ℝ≥0, 0 < T ∧ contractionFactor c T < 1 ∧ contractionFactor d T < 1 := by
  have hcont (a : Coefficients ι) : Continuous (contractionFactor a) := by
    change Continuous (fun T : ℝ≥0 => (Fintype.card ι : ℝ) *
      ((T:ℝ)*a.Lb + Real.sqrt (T:ℝ)*a.Lσ))
    fun_prop
  have hnear (a : Coefficients ι) : ∀ᶠ t : ℝ≥0 in 𝓝 0, contractionFactor a t < 1 :=
    (hcont a).tendsto 0 |>.eventually (by
      simpa [contractionFactor] using (gt_mem_nhds (by norm_num : (0:ℝ) < 1)))
  obtain ⟨ε,hε,he⟩ := Metric.eventually_nhds_iff.mp ((hnear c).and (hnear d))
  let T : ℝ≥0 := ⟨ε/2,(half_pos hε).le⟩
  have hT : 0 < T := half_pos hε
  have hd : dist T 0 < ε := by
    rw [NNReal.dist_eq,NNReal.coe_zero,sub_zero,abs_of_nonneg T.coe_nonneg]
    change ε/2 < ε
    linarith
  exact ⟨T,hT,(he hd).1,(he hd).2⟩

/-- Equality before the smaller of two genuine exits forces the exits to
coincide. This uses first hitting, rather than only a stopping-time label. -/
theorem normExit_eq_of_prefix_eq
    {E : Type*} [NormedAddCommGroup E]
    {X Z : ℝ≥0 → Ω → E} {x₀ : E} {R : ℝ} {T : ℝ≥0}
    (hX : ∀ ω, Continuous (fun t => X t ω))
    (hZ : ∀ ω, Continuous (fun t => Z t ω)) (hR : 0 < R)
    (ω : Ω)
    (he : ∀ t ∈ Icc 0 T,
      (t:WithTop ℝ≥0) ≤ min (normExit X x₀ R T ω) (normExit Z x₀ R T ω) → X t ω = Z t ω) :
    normExit X x₀ R T ω = normExit Z x₀ R T ω := by
  have hn (A C : ℝ≥0 → Ω → E)
      (hA : ∀ ω, Continuous (fun t => A t ω))
      (hC : ∀ ω, Continuous (fun t => C t ω))
      (heq : ∀ t ∈ Icc 0 T,
        (t:WithTop ℝ≥0) ≤ min (normExit A x₀ R T ω) (normExit C x₀ R T ω) → A t ω = C t ω) :
      ¬ normExit A x₀ R T ω < normExit C x₀ R T ω := by
    intro hlt
    have hcap : normExit C x₀ R T ω ≤ T := min_le_right _ _
    have hAt : normExit A x₀ R T ω < T := hlt.trans_le hcap
    have hfinite : normExit A x₀ R T ω ≠ ⊤ := ne_of_lt (hAt.trans (WithTop.coe_lt_top T))
    let u := (normExit A x₀ R T ω).untopA
    have hu : (u:WithTop ℝ≥0) = normExit A x₀ R T ω := by
      dsimp [u]
      rw [WithTop.untopA_eq_untop hfinite]
      exact WithTop.coe_untop _ _
    have huT : u < T := WithTop.coe_lt_coe.mp (hu.symm ▸ hAt)
    have hle : normExit A x₀ R T ω ≤ (u:WithTop ℝ≥0) := hu.ge
    obtain ⟨s,hs,hb⟩ := (normExit_le_iff hA hR huT ω).mp hle
    have hsA : (s:WithTop ℝ≥0) ≤ normExit A x₀ R T ω := hu ▸ WithTop.coe_le_coe.mpr hs.2
    have heq' := heq s ⟨hs.1,hs.2.trans huT.le⟩ (le_min hsA (hsA.trans hlt.le))
    have hCle : normExit C x₀ R T ω ≤ (u:WithTop ℝ≥0) :=
      (normExit_le_iff hC hR huT ω).mpr ⟨s,hs,by rwa [←heq']⟩
    exact not_le.mpr hlt (hu ▸ hCle)
  exact le_antisymm (not_lt.mp (hn Z X hZ hX (fun t ht hs =>
    (he t ht (by simpa only [min_comm] using hs)).symm))) (not_lt.mp (hn X Z hX hZ he))

/-- Before the norm-ball exit of a continuous version, two bounded-diffusion
strong solutions agree whenever their fields agree on that ball. -/
theorem strong_solutions_agree_before_normExit
    [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c d : Coefficients (Fin 3)) (x₀ : State) (hc : contractionFactor c T < 1)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖d.diffusion t x‖ ≤ d.bound)
    {Y Z XZ : ℝ≥0 → Ω → State}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hZ : StrongSolution (μ:=μ) T hBm d x₀ Z)
    {R : ℝ}
    (hstop : ∀ t ω, stoppedProcess XZ (normExit XZ x₀ R T) t ω ∈ Metric.closedBall x₀ R)
    (hXZ : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, XZ t ω = Z t ω)
    (hcoeff : ∀ t x, x ∈ Metric.closedBall x₀ R →
      c.drift t x = d.drift t x ∧ c.diffusion t x = d.diffusion t x) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ normExit XZ x₀ R T ω → Y t ω = Z t ω := by
  have hcap (ω : Ω) : normExit XZ x₀ R T ω ≤ T := min_le_right _ _
  have hfin (ω : Ω) : normExit XZ x₀ R T ω ≠ ⊤ :=
    ne_of_lt ((hcap ω).trans_lt (WithTop.coe_lt_top T))
  let τ := fun ω => (normExit XZ x₀ R T ω).untopA
  have hτ (ω : Ω) : (τ ω:WithTop ℝ≥0) = normExit XZ x₀ R T ω := by
    dsimp [τ]
    rw [WithTop.untopA_eq_untop (hfin ω)]
    exact WithTop.coe_untop _ _
  have hm := original_state_mem_before_exit hcap hstop hXZ
  have he := strong_solution_prefix_unique hB T hBm hBc c d x₀ hc hb hd hY hZ τ
    (by
      filter_upwards [hm] with ω hω
      intro t ht hle
      exact hcoeff t (Z t ω) (hω t (hτ ω ▸ WithTop.coe_le_coe.mpr hle)))
  filter_upwards [he] with ω hω
  intro t ht
  exact hω t ⟨zero_le,WithTop.coe_le_coe.mp (ht.trans (hcap ω))⟩
    (WithTop.coe_le_coe.mp ((hτ ω).symm ▸ ht))

/-- Local cutoff compatibility includes equality of the actual random exits
and indistinguishability of the stopped continuous versions. -/
theorem continuous_versions_stopped_eq
    [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hT : 0 < T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c d : Coefficients (Fin 3)) (x₀ : State) (hc : contractionFactor c T < 1)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖d.diffusion t x‖ ≤ d.bound)
    {Y Z XY XZ : ℝ≥0 → Ω → State}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hZ : StrongSolution (μ:=μ) T hBm d x₀ Z)
    (hXYa : StronglyAdapted (augFiltration (μ:=μ) hBm) XY)
    (hXZa : StronglyAdapted (augFiltration (μ:=μ) hBm) XZ)
    (hXYc : ∀ ω, Continuous (fun t => XY t ω))
    (hXZc : ∀ ω, Continuous (fun t => XZ t ω))
    (hXY₀ : ∀ ω, XY 0 ω = x₀) (hXZ₀ : ∀ ω, XZ 0 ω = x₀)
    (hXY : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, XY t ω = Y t ω)
    (hXZ : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, XZ t ω = Z t ω)
    (R : ℝ) (hR : 0 < R)
    (hcoeff : ∀ t x, x ∈ Metric.closedBall x₀ R →
      c.drift t x = d.drift t x ∧ c.diffusion t x = d.diffusion t x) :
    ∀ᵐ ω ∂μ, normExit XY x₀ R T ω = normExit XZ x₀ R T ω ∧
      ∀ t, stoppedProcess XY (normExit XY x₀ R T) t ω =
        stoppedProcess XZ (normExit XZ x₀ R T) t ω := by
  obtain ⟨_,_,hcapZ,hstopZ⟩ := normExit_properties hXZa hXZc hXZ₀ hR hT
  have he := strong_solutions_agree_before_normExit hB T hBm hBc c d x₀ hc hb hd
    hY hZ hstopZ hXZ hcoeff
  filter_upwards [he,hXY,hXZ] with ω he hXY hXZ
  have heXZ (t : ℝ≥0) (ht : (t:WithTop ℝ≥0) ≤ normExit XZ x₀ R T ω) : XY t ω = XZ t ω := by
    have htT : t ∈ Icc 0 T := ⟨zero_le,WithTop.coe_le_coe.mp (ht.trans (hcapZ ω))⟩
    exact (hXY t htT).trans ((he t ht).trans (hXZ t htT).symm)
  have hτ := normExit_eq_of_prefix_eq hXYc hXZc hR ω
    (fun t _ ht => heXZ t (ht.trans (min_le_right _ _)))
  refine ⟨hτ,?_⟩
  intro t
  change XY (min (t:WithTop ℝ≥0) (normExit XY x₀ R T ω)).untopA ω =
    XZ (min (t:WithTop ℝ≥0) (normExit XZ x₀ R T ω)).untopA ω
  rw [hτ]
  apply heXZ
  rw [coe_untopA_min]
  exact min_le_right _ _

/-- Two actual mechanical cutoff constructions on different positive-height
boxes give the same stopped trajectory in every common ball, on a constructed
common positive horizon. All solutions and stopping times are conclusions. -/
theorem exists_compatible_mechanical_cutoff_solutions
    [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
    (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (a : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi lo₁ hi₁ lo₂ hi₂ : State)
    (hlo₁ : lo₁ ≤ hi₁) (hh₁ : 0 < lo₁ 0)
    (hlo₂ : lo₂ ≤ hi₂) (hh₂ : 0 < lo₂ 0)
    (hpmem : ∀ t, p t ∈ Icc plo phi) (x₀ : State)
    (R : ℝ) (hR : 0 < R)
    (hball₁ : Metric.closedBall x₀ R ⊆ Icc lo₁ hi₁)
    (hball₂ : Metric.closedBall x₀ R ⊆ Icc lo₂ hi₂) :
    ∃ c d : Coefficients (Fin 3),
      (∀ t x, x ∈ Icc lo₁ hi₁ → c.drift t x = a.drift (p t,x) ∧
        c.diffusion t x = a.diffusion (p t,x)) ∧
      (∀ t x, x ∈ Icc lo₂ hi₂ → d.drift t x = a.drift (p t,x) ∧
        d.diffusion t x = a.diffusion (p t,x)) ∧
      ∃ T : ℝ≥0, 0 < T ∧ ∃ Y Z XY XZ : ℝ≥0 → Ω → State,
        StrongSolution (μ:=μ) T hBm c x₀ Y ∧
        StrongSolution (μ:=μ) T hBm d x₀ Z ∧
        StronglyAdapted (augFiltration (μ:=μ) hBm) XY ∧
        StronglyAdapted (augFiltration (μ:=μ) hBm) XZ ∧
        (∀ ω, Continuous (fun t => XY t ω)) ∧
        (∀ ω, Continuous (fun t => XZ t ω)) ∧
        (∀ ω, XY 0 ω = x₀ ∧ XZ 0 ω = x₀) ∧
        (∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, XY t ω = Y t ω ∧ XZ t ω = Z t ω) ∧
        IsStoppingTime (augFiltration (μ:=μ) hBm) (normExit XY x₀ R T) ∧
        IsStoppingTime (augFiltration (μ:=μ) hBm) (normExit XZ x₀ R T) ∧
        (∀ ω, ⊥ < normExit XY x₀ R T ω ∧ ⊥ < normExit XZ x₀ R T ω) ∧
        (∀ᵐ ω ∂μ, normExit XY x₀ R T ω = normExit XZ x₀ R T ω ∧
          ∀ t, stoppedProcess XY (normExit XY x₀ R T) t ω =
            stoppedProcess XZ (normExit XZ x₀ R T) t ω) := by
  obtain ⟨c,_,_,hcb,hcσ,hcbd⟩ := a.exists_cutoff p hp plo phi lo₁ hi₁ hlo₁ hh₁ hpmem
  obtain ⟨d,_,_,hdb,hdσ,hdbd⟩ := a.exists_cutoff p hp plo phi lo₂ hi₂ hlo₂ hh₂ hpmem
  obtain ⟨T,hT,hc,hd⟩ := exists_common_contraction_horizon c d
  obtain ⟨Y,hY⟩ := exists_strong_solution hB T hBm hBc c x₀ hc
  obtain ⟨Z,hZ⟩ := exists_strong_solution hB T hBm hBc d x₀ hd
  obtain ⟨XY,hXYa,hXYc,hXY₀,hXY⟩ := exists_continuous_adapted_version
    hY.predictable.stronglyAdapted hY.continuous hY.initial
  obtain ⟨XZ,hXZa,hXZc,hXZ₀,hXZ⟩ := exists_continuous_adapted_version
    hZ.predictable.stronglyAdapted hZ.continuous hZ.initial
  obtain ⟨hτY,hposY,_,_⟩ := normExit_properties hXYa hXYc hXY₀ hR hT
  obtain ⟨hτZ,hposZ,_,_⟩ := normExit_properties hXZa hXZc hXZ₀ hR hT
  refine ⟨c,d,(fun t x hx => ⟨hcb t x hx,hcσ t x hx⟩),
    (fun t x hx => ⟨hdb t x hx,hdσ t x hx⟩),T,hT,Y,Z,XY,XZ,hY,hZ,
    hXYa,hXZa,hXYc,hXZc,(fun ω => ⟨hXY₀ ω,hXZ₀ ω⟩),?_,hτY,hτZ,
    (fun ω => ⟨hposY ω,hposZ ω⟩),?_⟩
  · filter_upwards [hXY,hXZ] with ω hy hz
    exact fun t ht => ⟨hy t ht,hz t ht⟩
  · apply continuous_versions_stopped_eq hB T hT hBm hBc c d x₀ hc
      (fun t x => (hcbd t x).2) (fun t x => (hdbd t x).2)
      hY hZ hXYa hXZa hXYc hXZc hXY₀ hXZ₀ hXY hXZ R hR
    intro t x hx
    exact ⟨(hcb t x (hball₁ hx)).trans (hdb t x (hball₂ hx)).symm,
      (hcσ t x (hball₁ hx)).trans (hdσ t x (hball₂ hx)).symm⟩

end
end ChainFountainStochastic.CutoffCompatibility


namespace ChainFountainStochastic.CausalFixedPoint
noncomputable section
open Set
open scoped NNReal
set_option maxHeartbeats 600000
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

/-- Extend a fixed prefix by applying Banach on the closed affine space of
extensions of that prefix. Future values are set by the larger projection. -/
theorem extend_prefix (P Q : E →L[ℝ] E) (F : E → E)
    (hPQ : ∀ x, P (Q x) = P x)
    (hcausal : ∀ x y, P x = P y → P (F x) = P (F y))
    (q : ℝ≥0) (hq : q < 1)
    (hcontract : ∀ x y, P x = P y → ‖Q (F x) - Q (F y)‖ ≤ q * ‖x-y‖)
    (y : E) (hy : P (F y) = y) (hPy : P y = y) :
    ∃ x : E, Q (F x) = x ∧ P x = y := by
  let S : Set E := {x | P x = y}
  have hclosed : IsClosed S := isClosed_eq P.continuous continuous_const
  letI : CompleteSpace S := hclosed.completeSpace_coe
  letI : Nonempty S := ⟨⟨y,hPy⟩⟩
  let f : S → S := fun x => ⟨Q (F x), by
    change P (Q (F x)) = y
    rw [hPQ, hcausal x y (x.property.trans hPy.symm), hy]⟩
  have hf : ContractingWith q f := by
    refine ⟨hq,LipschitzWith.of_dist_le_mul fun x z => ?_⟩
    change dist (Q (F x)) (Q (F z)) ≤ q * dist (x:E) (z:E)
    simp only [dist_eq_norm]
    exact hcontract x z (x.property.trans z.property.symm)
  let x : S := hf.fixedPoint f
  refine ⟨(x:E),?_,x.property⟩
  exact congrArg Subtype.val hf.fixedPoint_isFixedPt

/-- A causal map has a fixed point if every piece of a finite time partition
is contractive after fixing its past. No smallness of the full horizon is assumed. -/
theorem exists_fixed_point (N : ℕ) (P : ℕ → E →L[ℝ] E) (F : E → E)
    (hzero : ∀ x, P 0 x = 0) (hfull : ∀ x, P N x = x)
    (habsorb : ∀ m n, m ≤ n → ∀ x, P m (P n x) = P m x)
    (hcausal : ∀ n, n ≤ N → ∀ x y, P n x = P n y → P n (F x) = P n (F y))
    (q : ℝ≥0) (hq : q < 1)
    (hcontract : ∀ n, n < N → ∀ x y, P n x = P n y →
      ‖P (n+1) (F x) - P (n+1) (F y)‖ ≤ q * ‖x-y‖) :
    ∃ x, F x = x := by
  have hex : ∀ n, n ≤ N → ∃ x, P n (F x) = x ∧ P n x = x := by
    intro n
    induction n with
    | zero => exact fun _ => ⟨0,hzero _,hzero _⟩
    | succ n ih =>
      intro hn
      obtain ⟨y,hy,hPy⟩ := ih (Nat.le_of_succ_le hn)
      obtain ⟨x,hx,_⟩ := extend_prefix (P n) (P (n+1)) F
        (habsorb n (n+1) (Nat.le_succ _))
        (hcausal n (Nat.le_of_succ_le hn)) q hq
        (hcontract n (Nat.lt_of_succ_le hn)) y hy hPy
      refine ⟨x,hx,?_⟩
      rw [←hx,habsorb (n+1) (n+1) le_rfl]
  obtain ⟨x,hx,_⟩ := hex N le_rfl
  exact ⟨x,by simpa only [hfull] using hx⟩

/-- The same finite causal partition also proves uniqueness of the fixed point. -/
theorem fixed_point_unique (N : ℕ) (P : ℕ → E →L[ℝ] E) (F : E → E)
    (hzero : ∀ x, P 0 x = 0) (hfull : ∀ x, P N x = x)
    (habsorb : ∀ m n, m ≤ n → ∀ x, P m (P n x) = P m x)
    (hcausal : ∀ n, n ≤ N → ∀ x y, P n x = P n y → P n (F x) = P n (F y))
    (q : ℝ≥0) (hq : q < 1)
    (hcontract : ∀ n, n < N → ∀ x y, P n x = P n y →
      ‖P (n+1) (F x) - P (n+1) (F y)‖ ≤ q * ‖x-y‖)
    {x y : E} (hx : F x = x) (hy : F y = y) : x = y := by
  have he : ∀ n, n ≤ N → P n x = P n y := by
    intro n
    induction n with
    | zero => exact fun _ => (hzero x).trans (hzero y).symm
    | succ n ih =>
      intro hn
      have hprev : P n (P (n+1) x) = P n (P (n+1) y) := by
        rw [habsorb n (n+1) (Nat.le_succ _),habsorb n (n+1) (Nat.le_succ _)]
        exact ih (Nat.le_of_succ_le hn)
      have hx' : P (n+1) (F (P (n+1) x)) = P (n+1) x :=
        (hcausal (n+1) hn _ _ (habsorb _ _ le_rfl x)).trans (congrArg (P (n+1)) hx)
      have hy' : P (n+1) (F (P (n+1) y)) = P (n+1) y :=
        (hcausal (n+1) hn _ _ (habsorb _ _ le_rfl y)).trans (congrArg (P (n+1)) hy)
      have h := hcontract n (Nat.lt_of_succ_le hn) _ _ hprev
      rw [hx',hy'] at h
      apply sub_eq_zero.mp
      apply norm_eq_zero.mp
      have hq' : (q:ℝ) < 1 := hq
      nlinarith [norm_nonneg (P (n+1) x-P (n+1) y)]
  simpa only [hfull] using he N le_rfl

end
end ChainFountainStochastic.CausalFixedPoint

/-
Indicator-CLM construction adapted from Raphael Coelho's MathFin
ItoIntegralProcessIsometry.lean (Apache 2.0), commit
61d945b970561fcce6996fac0a5f18a424eb851f; generalized to vector-valued L2.
-/

namespace ChainFountainStochastic.TimeProjection
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM
open VectorSDE VectorLp
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 700000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

abbrev band (t : ℝ≥0) : Set (ℝ≥0 × Ω) := Ioc 0 t ×ˢ univ

theorem measurable_band (t : ℝ≥0) (hBm : ∀ u, Measurable (B u)) :
    MeasurableSet[(natFiltration hBm).predictable] (band (Ω:=Ω) t) :=
  MeasureTheory.measurableSet_predictable_Ioc_prod _ _ MeasurableSet.univ

/-- Continuous projection onto the part of a predictable L2 process before t. -/
def cut (T t : ℝ≥0) (hBm : ∀ u, Measurable (B u)) :
    Lp E 2 (trimMeasure_T (μ:=μ) T hBm) →L[ℝ] Lp E 2 (trimMeasure_T (μ:=μ) T hBm) :=
  LinearMap.mkContinuous
    { toFun := fun X => ((Lp.memLp X).indicator (measurable_band t hBm)).toLp ((band t).indicator X)
      map_add' := fun X Y => by
        apply Lp.ext
        filter_upwards [((Lp.memLp (X+Y)).indicator (measurable_band t hBm)).coeFn_toLp,
          Lp.coeFn_add (((Lp.memLp X).indicator (measurable_band t hBm)).toLp _)
            (((Lp.memLp Y).indicator (measurable_band t hBm)).toLp _),
          ((Lp.memLp X).indicator (measurable_band t hBm)).coeFn_toLp,
          ((Lp.memLp Y).indicator (measurable_band t hBm)).coeFn_toLp,Lp.coeFn_add X Y]
          with z h1 h2 h3 h4 h5
        rw [h1,h2,Pi.add_apply,h3,h4]
        by_cases hz : z ∈ band t
        · simp only [Set.indicator_of_mem hz]
          exact h5
        · simp only [Set.indicator_of_notMem hz,zero_add]
      map_smul' := fun c X => by
        apply Lp.ext
        filter_upwards [((Lp.memLp (c • X)).indicator (measurable_band t hBm)).coeFn_toLp,
          Lp.coeFn_smul c (((Lp.memLp X).indicator (measurable_band t hBm)).toLp _),
          ((Lp.memLp X).indicator (measurable_band t hBm)).coeFn_toLp,Lp.coeFn_smul c X]
          with z h1 h2 h3 h4
        rw [h1,RingHom.id_apply,h2,Pi.smul_apply,h3]
        by_cases hz : z ∈ band t <;> simp [hz,h4] }
    1 (fun X => by
      simp only [LinearMap.coe_mk,AddHom.coe_mk,one_mul]
      rw [Lp.norm_toLp,Lp.norm_def]
      exact ENNReal.toReal_mono (Lp.memLp X).2.ne (eLpNorm_indicator_le _))

theorem cut_coe (T t : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (X : Lp E 2 (trimMeasure_T (μ:=μ) T hBm)) :
    ⇑(cut T t hBm X) =ᵐ[trimMeasure_T (μ:=μ) T hBm] (band t).indicator X :=
  ((Lp.memLp X).indicator (measurable_band t hBm)).coeFn_toLp

theorem cut_zero (T : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (X : Lp E 2 (trimMeasure_T (μ:=μ) T hBm)) : cut T 0 hBm X = 0 := by
  apply Lp.ext
  filter_upwards [cut_coe T 0 hBm X,Lp.coeFn_zero (E:=E) (p:=2) (μ:=trimMeasure_T (μ:=μ) T hBm)] with z hz h0
  change cut T 0 hBm X z = (0 : Lp E 2 (trimMeasure_T (μ:=μ) T hBm)) z
  rw [h0]
  simpa [band] using hz

theorem cut_full (T : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (X : Lp E 2 (trimMeasure_T (μ:=μ) T hBm)) : cut T T hBm X = X := by
  apply Lp.ext
  have hb : ∀ᵐ z ∂trimMeasure_T (μ:=μ) T hBm, z ∈ band T := by
    rw [trimMeasure_T_eq_restrict]
    exact ae_restrict_mem (measurable_band T hBm)
  filter_upwards [cut_coe T T hBm X,hb] with z hz hb
  simpa [hb] using hz

theorem cut_absorb (T s t : ℝ≥0) (hBm : ∀ u, Measurable (B u)) (hst : s ≤ t)
    (X : Lp E 2 (trimMeasure_T (μ:=μ) T hBm)) :
    cut T s hBm (cut T t hBm X) = cut T s hBm X := by
  apply Lp.ext
  filter_upwards [cut_coe T s hBm (cut T t hBm X),cut_coe T t hBm X,cut_coe T s hBm X]
    with z h1 h2 h3
  by_cases hs : z ∈ band s
  · have ht : z ∈ band t := ⟨⟨hs.1.1,hs.1.2.trans hst⟩,mem_univ _⟩
    simp_all
  · simp_all

theorem cut_eq_iff (T t : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (X Y : Lp E 2 (trimMeasure_T (μ:=μ) T hBm)) :
    cut T t hBm X = cut T t hBm Y ↔
      ∀ᵐ z ∂trimMeasure_T (μ:=μ) T hBm, z ∈ band t → X z = Y z := by
  constructor
  · intro he
    filter_upwards [cut_coe T t hBm X,cut_coe T t hBm Y] with z hx hy hz
    rw [he] at hx
    simpa [hz] using hx.symm.trans hy
  · intro he
    apply Lp.ext
    filter_upwards [cut_coe T t hBm X,cut_coe T t hBm Y,he] with z hx hy he
    by_cases hz : z ∈ band t <;> simp_all

/-- The square norm of a scalar projected process is its prefix energy. -/
theorem cut_norm_sq (T t : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (X : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) :
    ‖cut T t hBm X‖^2 = ∫ z in band t, (X z)^2 ∂trimMeasure_T (μ:=μ) T hBm := by
  rw [lp_two_norm_sq,←integral_indicator (measurable_band t hBm)]
  apply integral_congr_ae
  filter_upwards [cut_coe T t hBm X] with z hz
  rw [hz]
  by_cases ht : z ∈ band t <;> simp [ht]

/-- Restricting the predictable measure to a smaller time band gives exactly
that smaller horizon measure. -/
theorem trim_restrict_eq (T t : ℝ≥0) (hBm : ∀ u, Measurable (B u)) (ht : t ≤ T) :
    (trimMeasure_T (μ:=μ) T hBm).restrict (band t) = trimMeasure_T (μ:=μ) t hBm := by
  rw [trimMeasure_T_eq_restrict,Measure.restrict_restrict_of_subset]
  · exact (trimMeasure_T_eq_restrict t hBm).symm
  · exact fun z hz => ⟨⟨hz.1.1,hz.1.2.trans ht⟩,mem_univ _⟩

theorem memLp_product (T : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (X : Lp E 2 (trimMeasure_T (μ:=μ) T hBm)) :
    MemLp (⇑X) 2 ((timeMeasure_T T).prod μ) := by
  refine ⟨(Lp.stronglyMeasurable X).mono (natFiltration hBm).predictable_le_prod |>.aestronglyMeasurable,?_⟩
  rw [← eLpNorm_trim (natFiltration hBm).predictable_le_prod (Lp.stronglyMeasurable X)]
  exact (Lp.memLp X).2

/-- Prefix energy is the integral of the square energies of its time slices. -/
theorem cut_norm_sq_eq_integral (T t : ℝ≥0) (hBm : ∀ u, Measurable (B u)) (ht : t ≤ T)
    (X : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) :
    ‖cut T t hBm X‖^2 = ∫ u, ∫ ω, (X (u,ω))^2 ∂μ ∂timeMeasure_T t := by
  have hm : MemLp (⇑X) 2 ((timeMeasure_T t).prod μ) :=
    (memLp_product T hBm X).mono_measure
      (Measure.prod_mono (Measure.restrict_mono (Ioc_subset_Ioc_right ht) le_rfl) le_rfl)
  rw [cut_norm_sq,trim_restrict_eq T t hBm ht]
  have htrim : (∫ z, (X z)^2 ∂trimMeasure_T (μ:=μ) t hBm) =
      ∫ z, (X z)^2 ∂(timeMeasure_T t).prod μ :=
    (integral_trim (μ:=(timeMeasure_T t).prod μ)
      (natFiltration hBm).predictable_le_prod ((Lp.stronglyMeasurable X).pow 2)).symm
  rw [htrim]
  exact integral_prod _ hm.integrable_sq

theorem cut_eq_zero_iff (T t : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (X : Lp E 2 (trimMeasure_T (μ:=μ) T hBm)) :
    cut T t hBm X = 0 ↔ ∀ᵐ z ∂trimMeasure_T (μ:=μ) T hBm, z ∈ band t → X z = 0 := by
  rw [← map_zero (cut T t hBm),cut_eq_iff]
  constructor <;> intro he
  · filter_upwards [he,Lp.coeFn_zero (E:=E) (p:=2) (μ:=trimMeasure_T (μ:=μ) T hBm)] with z hz h0
    exact fun ht => (hz ht).trans h0
  · filter_upwards [he,Lp.coeFn_zero (E:=E) (p:=2) (μ:=trimMeasure_T (μ:=μ) T hBm)] with z hz h0
    exact fun ht => (hz ht).trans h0.symm

/-- The prefix energy formula is invariant under choice of representative. -/
theorem cut_energy_of_rep (T t : ℝ≥0) (hBm : ∀ u, Measurable (B u)) (ht : t ≤ T)
    (X : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) {f : ℝ≥0 → Ω → ℝ}
    (hf : ⇑X =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry f) :
    ‖cut T t hBm X‖^2 = ∫ u, ∫ ω, (f u ω)^2 ∂μ ∂timeMeasure_T t := by
  rw [cut_norm_sq_eq_integral T t hBm ht]
  have hp := Measure.ae_ae_of_ae_prod (ae_of_ae_trim (natFiltration hBm).predictable_le_prod hf)
  have hp' := hp.filter_mono (ae_mono (Measure.restrict_mono (Ioc_subset_Ioc_right ht) le_rfl))
  apply integral_congr_ae
  filter_upwards [hp'] with u hu
  exact integral_congr_ae (hu.mono fun ω hω => congrArg (fun x : ℝ => x^2) hω)

/-- A process vanishing before s costs only the length t-s in the outer
energy integral. The bound is used for both drift and stochastic integration. -/
theorem cut_sq_le (T s t : ℝ≥0) (hBm : ∀ u, Measurable (B u)) (hst : s ≤ t) (ht : t ≤ T)
    (X : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) {f : ℝ≥0 → Ω → ℝ}
    (hf : ⇑X =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry f)
    (M : ℝ) (hM : 0 ≤ M)
    (hbound : ∀ u, u ≤ t → (∫ ω, (f u ω)^2 ∂μ) ≤ M)
    (hzero : ∀ u, u ≤ s → ∀ᵐ ω ∂μ, f u ω = 0) :
    ‖cut T t hBm X‖^2 ≤ ((t:ℝ)-(s:ℝ))*M := by
  rw [cut_energy_of_rep T t hBm ht X hf]
  calc
    _ ≤ ∫ u, (Ioc s t).indicator (fun _ => M) u ∂timeMeasure_T t := by
      apply integral_mono_of_nonneg (ae_of_all _ fun _ => integral_nonneg fun _ => sq_nonneg _)
        ((integrable_const M).indicator measurableSet_Ioc)
      filter_upwards [ae_restrict_mem (μ:=timeMeasure) measurableSet_Ioc] with u hu
      by_cases hs : u ≤ s
      · have hz : (∫ ω, (f u ω)^2 ∂μ) = 0 := by
          apply integral_eq_zero_of_ae
          filter_upwards [hzero u hs] with ω hω
          simp [hω]
        rw [hz,indicator_of_notMem (by exact fun h => not_lt_of_ge hs h.1)]
      · rw [indicator_of_mem (show u ∈ Ioc s t from ⟨lt_of_not_ge hs,hu.2⟩)]
        exact hbound u hu.2
    _ = ((t:ℝ)-(s:ℝ))*M := by
      rw [integral_indicator measurableSet_Ioc,integral_const,smul_eq_mul]
      congr 1
      rw [measureReal_def,Measure.restrict_apply_univ,timeMeasure_T,
        Measure.restrict_apply measurableSet_Ioc,
        inter_eq_left.mpr (Ioc_subset_Ioc_left (show (0:ℝ≥0) ≤ s from zero_le)),timeMeasure_Ioc,
        ENNReal.toReal_ofReal (sub_nonneg.mpr (show (s:ℝ) ≤ (t:ℝ) from hst))]

/-- Time projection commutes with continuous linear coordinate maps. -/
theorem cut_compLp {F : Type*} [NormedAddCommGroup F] [NormedSpace ℝ F]
    (T t : ℝ≥0) (hBm : ∀ u, Measurable (B u)) (L : E →L[ℝ] F)
    (X : Lp E 2 (trimMeasure_T (μ:=μ) T hBm)) :
    cut T t hBm (L.compLpL 2 _ X) = L.compLpL 2 _ (cut T t hBm X) := by
  apply Lp.ext
  filter_upwards [cut_coe T t hBm (L.compLpL 2 _ X),L.coeFn_compLpL X,
    L.coeFn_compLpL (cut T t hBm X),cut_coe T t hBm X] with z h1 h2 h3 h4
  rw [h1,h3,h4]
  by_cases hz : z ∈ band t
  · simpa only [indicator_of_mem hz] using h2
  · simp only [indicator_of_notMem hz,map_zero]

theorem cut_assemble {ι : Type*} [Fintype ι] [DecidableEq ι]
    (T t : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (X : ι → Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) :
    cut T t hBm (assembleLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) X) = assembleLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (fun i => cut T t hBm (X i)) := by
  simp only [assembleLp,map_sum,singleLp]
  apply Finset.sum_congr rfl
  intro i _
  exact cut_compLp T t hBm _ _

end
end ChainFountainStochastic.TimeProjection


namespace ChainFountainStochastic.IntervalOperators
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM MathFin.SDEExistence
open MathFin.ItoIntegralProcessGeneral MathFin.ItoIntegralProcessContinuousModification
open TimeProjection SDEContinuous VectorSDE
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 900000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}

/-- The drift slice energy is controlled by the full input energy. -/
theorem drift_slice_energy_le (T : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (g : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) {t : ℝ≥0} (ht : t ≤ T) :
    (∫ ω, (driftContinuousMod T hBm g t ω)^2 ∂μ) ≤ (T:ℝ)*‖g‖^2 := by
  have hg := memLp_product T hBm g
  have hs : ∀ᵐ ω ∂μ, MemLp (fun u => g (u,ω)) 2 (timeMeasure_T T) := by
    filter_upwards [hg.1.prodMk_right,hg.integrable_sq.prod_left_ae] with ω h1 h2
    exact (memLp_two_iff_integrable_sq h1).mpr h2
  have hp : ∀ᵐ ω ∂μ, (driftContinuousMod T hBm g t ω)^2 ≤
      (T:ℝ)*(∫ u, (g (u,ω))^2 ∂timeMeasure_T T) := by
    filter_upwards [hs,driftContinuousMod_eq_setIntegral T hBm g ht] with ω hs he
    rw [he]
    haveI : IsFiniteMeasure (timeMeasure.restrict (Ioc (0:ℝ≥0) t)) :=
      ⟨by rw [Measure.restrict_apply_univ,timeMeasure_Ioc]; exact ENNReal.ofReal_lt_top⟩
    have hCS := sq_integral_le_measureReal_mul
      (ν:=timeMeasure.restrict (Ioc (0:ℝ≥0) t))
      (f:=fun u => g (u,ω))
      (hs.mono_measure (Measure.restrict_mono (Ioc_subset_Ioc_right ht) le_rfl))
    rw [Measure.restrict_apply_univ,timeMeasure_Ioc,NNReal.coe_zero,sub_zero,
      ENNReal.toReal_ofReal t.coe_nonneg] at hCS
    refine hCS.trans (mul_le_mul (show (t:ℝ) ≤ (T:ℝ) from ht) ?_
      (integral_nonneg fun _ => sq_nonneg _) T.coe_nonneg)
    exact setIntegral_mono_set hs.integrable_sq (ae_of_all _ fun _ => sq_nonneg _)
      (Ioc_subset_Ioc_right ht).eventuallyLE
  have htotal : (∫ u, ∫ ω, (g (u,ω))^2 ∂μ ∂timeMeasure_T T) = ‖g‖^2 := by
    simpa only [cut_full] using (cut_norm_sq_eq_integral T T hBm le_rfl g).symm
  calc
    _ ≤ ∫ ω, (T:ℝ)*(∫ u, (g (u,ω))^2 ∂timeMeasure_T T) ∂μ :=
      integral_mono_of_nonneg (ae_of_all _ fun _ => sq_nonneg _)
        (hg.integrable_sq.integral_prod_right.const_mul _) hp
    _ = _ := by rw [integral_const_mul,←integral_integral_swap hg.integrable_sq,htotal]

/-- A zero input prefix has a zero drift prefix, for every time a.e. -/
theorem drift_zero_prefix (T s : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (g : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) (hg : cut T s hBm g = 0)
    {t : ℝ≥0} (hts : t ≤ s) (htT : t ≤ T) :
    ∀ᵐ ω ∂μ, driftContinuousMod T hBm g t ω = 0 := by
  have hp := PrefixLimits.ae_path_of_trim (μ:=μ) T hBm
    ((cut_eq_zero_iff T s hBm g).mp hg)
  filter_upwards [hp,driftContinuousMod_eq_setIntegral T hBm g htT] with ω hp he
  rw [he]
  apply integral_eq_zero_of_ae
  have hp' := hp.filter_mono (ae_mono (Measure.restrict_mono (Ioc_subset_Ioc_right htT) le_rfl))
  filter_upwards [hp',ae_restrict_mem (μ:=timeMeasure) measurableSet_Ioc] with u hu huI
  exact hu ⟨⟨huI.1,huI.2.trans hts⟩,mem_univ _⟩

/-- The Itô slice energy is bounded by the full predictable input energy. -/
theorem ito_slice_energy_le (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ u, Measurable (B u)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (g : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) {t : ℝ≥0} (ht : t ≤ T) :
    (∫ ω, (itoContinuousMod T hBm g t ω)^2 ∂μ) ≤ ‖g‖^2 := by
  have he : (∫ ω, (itoContinuousMod T hBm g t ω)^2 ∂μ) =
      ‖itoProcessCLM hB T t hBm g‖^2 := by
    rw [lp_two_norm_sq]
    apply integral_congr_ae
    filter_upwards [itoContinuousMod_modification hB T hBm hBc g ht] with ω hω
    rw [hω]
  rw [he]
  exact pow_le_pow_left₀ (norm_nonneg _) (itoProcessCLM_norm_le hB T t hBm g) 2

/-- Itô isometry proves zero-prefix locality for arbitrary L2 inputs. -/
theorem ito_zero_prefix (hB : IsPreBrownianReal B μ) (T s : ℝ≥0)
    (hBm : ∀ u, Measurable (B u)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (g : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) (hg : cut T s hBm g = 0)
    {t : ℝ≥0} (hts : t ≤ s) (htT : t ≤ T) :
    ∀ᵐ ω ∂μ, itoContinuousMod T hBm g t ω = 0 := by
  have hc : cut T t hBm g = 0 := by
    rw [←cut_absorb T t s hBm hts,hg,map_zero]
  have hs : ‖itoProcessCLM hB T t hBm g‖^2 = 0 := by
    rw [itoProcessCLM_norm_sq hB htT hBm,←cut_norm_sq T t hBm,hc,norm_zero,zero_pow (by decide : 2 ≠ 0)]
  have hz : itoProcessCLM hB T t hBm g = 0 := norm_eq_zero.mp (by nlinarith [norm_nonneg (itoProcessCLM hB T t hBm g)])
  filter_upwards [itoContinuousMod_modification hB T hBm hBc g htT,
    Lp.coeFn_zero (E:=ℝ) (p:=2) (μ:=μ)] with ω he h0
  exact he.trans (hz ▸ h0)

/-- Short-interval drift contraction after fixing the earlier input prefix. -/
theorem drift_interval_norm_le (T s t : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    (hst : s ≤ t) (ht : t ≤ T) (g : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm))
    (hg : cut T s hBm g = 0) :
    ‖cut T t hBm (driftProcessAssembled (μ:=μ) T hBm g)‖ ≤
      Real.sqrt ((t:ℝ)-(s:ℝ))*Real.sqrt (T:ℝ)*‖g‖ := by
  have hs := cut_sq_le T s t hBm hst ht (driftProcessAssembled (μ:=μ) T hBm g)
    (driftProcessAssembled_coeFn T hBm g) ((T:ℝ)*‖g‖^2) (by positivity)
    (fun u hu => drift_slice_energy_le T hBm g (hu.trans ht))
    (fun u hu => drift_zero_prefix T s hBm g hg hu (hu.trans (hst.trans ht)))
  have hh := Real.sqrt_le_sqrt hs
  rw [Real.sqrt_sq (norm_nonneg _),Real.sqrt_mul (sub_nonneg.mpr (show (s:ℝ) ≤ (t:ℝ) from hst)),
    Real.sqrt_mul T.coe_nonneg,Real.sqrt_sq (norm_nonneg _)] at hh
  simpa only [mul_assoc] using hh

/-- Short-interval Itô contraction after fixing the earlier input prefix. -/
theorem ito_interval_norm_le (hB : IsPreBrownianReal B μ) (T s t : ℝ≥0)
    (hBm : ∀ u, Measurable (B u)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (hst : s ≤ t) (ht : t ≤ T) (g : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm))
    (hg : cut T s hBm g = 0) :
    ‖cut T t hBm (itoProcessAssembled hB T hBm hBc g)‖ ≤
      Real.sqrt ((t:ℝ)-(s:ℝ))*‖g‖ := by
  have hs := cut_sq_le T s t hBm hst ht (itoProcessAssembled hB T hBm hBc g)
    (memLp_itoContinuousMod hB T hBm hBc g).coeFn_toLp (‖g‖^2) (sq_nonneg _)
    (fun u hu => ito_slice_energy_le hB T hBm hBc g (hu.trans ht))
    (fun u hu => ito_zero_prefix hB T s hBm hBc g hg hu (hu.trans (hst.trans ht)))
  have hh := Real.sqrt_le_sqrt hs
  rwa [Real.sqrt_sq (norm_nonneg _),Real.sqrt_mul (sub_nonneg.mpr (show (s:ℝ) ≤ (t:ℝ) from hst)),
    Real.sqrt_sq (norm_nonneg _)] at hh

end
end ChainFountainStochastic.IntervalOperators


namespace ChainFountainStochastic.FinitePicard
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM MathFin.SDEExistence
open MathFin.ItoIntegralProcessContinuousModification
open TimeProjection IntervalOperators VectorSDE VectorLp
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1000000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Time-dependent coefficient composition preserves equality of pasts. -/
theorem cut_coefficient_eq (T s : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    {f : ℝ≥0 → (ι → ℝ) → (ι → ℝ)} (hf : Continuous (Function.uncurry f))
    {L : ℝ≥0} (hL : ∀ t, LipschitzWith L (f t)) {M : ℝ} (hM : ∀ t, ‖f t 0‖ ≤ M)
    (X Y : ProcessLp (μ:=μ) (ι:=ι) T hBm) (he : cut T s hBm X = cut T s hBm Y) :
    cut T s hBm (coefficientLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) hf hL (fun z => hM z.1) X) =
      cut T s hBm (coefficientLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) hf hL (fun z => hM z.1) Y) := by
  apply (cut_eq_iff T s hBm _ _).mpr
  filter_upwards [(cut_eq_iff T s hBm X Y).mp he,
    coefficientLp_coe (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) hf hL (fun z => hM z.1) X,
    coefficientLp_coe (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) hf hL (fun z => hM z.1) Y] with z he hx hy hz
  rw [hx,hy,he hz]

/-- Scalar interval estimates lift to a coupled vector process. -/
theorem cut_lift_sub_norm_le (T s t : ℝ≥0) (hBm : ∀ u, Measurable (B u))
    {A : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm) → Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)}
    (hsub : ∀ X Y, A (X-Y) = A X-A Y) {q : ℝ} (hq : 0 ≤ q)
    (hA : ∀ g, cut T s hBm g = 0 → ‖cut T t hBm (A g)‖ ≤ q*‖g‖)
    (X Y : ProcessLp (μ:=μ) (ι:=ι) T hBm) (he : cut T s hBm X = cut T s hBm Y) :
    ‖cut T t hBm (liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) A X) - cut T t hBm (liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) A Y)‖ ≤
      (Fintype.card ι:ℝ)*q*‖X-Y‖ := by
  letI : MeasurableSpace (ℝ≥0 × Ω) := (natFiltration hBm).predictable
  rw [←map_sub,liftOperator,liftOperator,←assembleLp_sub,cut_assemble]
  calc
    _ ≤ ∑ i, ‖cut T t hBm (A (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i X)-A (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i Y))‖ := assembleLp_norm_le (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) _
    _ ≤ ∑ i : ι, q*‖X-Y‖ := by
      apply Finset.sum_le_sum
      intro i _
      rw [←hsub,←map_sub]
      have hz : cut T s hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i (X-Y)) = 0 := by
        change cut T s hBm ((ContinuousLinearMap.proj i : (ι → ℝ) →L[ℝ] ℝ).compLpL 2 _ (X-Y)) = 0
        rw [cut_compLp,map_sub,he,sub_self,map_zero]
      exact (hA _ hz).trans (mul_le_mul_of_nonneg_left (evalLp_norm_le (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i (X-Y)) hq)
    _ = _ := by simp; ring

/-- The Picard operator is contractive on a short new interval after its past
is fixed, even when the total horizon T is arbitrarily large. -/
theorem picard_interval_norm_le (hB : IsPreBrownianReal B μ) (T s t : ℝ≥0)
    (hBm : ∀ u, Measurable (B u)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (hst : s ≤ t) (ht : t ≤ T)
    (X Y : ProcessLp (μ:=μ) (ι:=ι) T hBm) (he : cut T s hBm X = cut T s hBm Y) :
    ‖cut T t hBm (picard hB T hBm hBc c x₀ X) - cut T t hBm (picard hB T hBm hBc c x₀ Y)‖ ≤
      ((Fintype.card ι:ℝ)*Real.sqrt ((t:ℝ)-(s:ℝ))*(Real.sqrt (T:ℝ)*c.Lb+c.Lσ))*‖X-Y‖ := by
  have hd := cut_coefficient_eq T s hBm c.drift_continuous c.drift_lipschitz c.drift_zero X Y he
  have hi := cut_coefficient_eq T s hBm c.diffusion_continuous c.diffusion_lipschitz c.diffusion_zero X Y he
  have hdn := cut_lift_sub_norm_le T s t hBm (q:=Real.sqrt ((t:ℝ)-(s:ℝ))*Real.sqrt (T:ℝ))
    (fun U V => map_sub (driftProcessAssembled (μ:=μ) T hBm) U V)
    (mul_nonneg (Real.sqrt_nonneg _) (Real.sqrt_nonneg _))
    (fun g hg => by simpa only [mul_assoc] using drift_interval_norm_le T s t hBm hst ht g hg)
    (c.driftLp T hBm X) (c.driftLp T hBm Y) hd
  have hin := cut_lift_sub_norm_le T s t hBm (q:=Real.sqrt ((t:ℝ)-(s:ℝ))) (itoProcessAssembled_sub hB T hBm hBc)
    (Real.sqrt_nonneg _) (fun g hg => ito_interval_norm_le hB T s t hBm hBc hst ht g hg)
    (c.diffusionLp T hBm X) (c.diffusionLp T hBm Y) hi
  have hbd := coefficientLp_sub_norm_le (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.drift_continuous
    c.drift_lipschitz (fun z => c.drift_zero z.1) X Y
  have hsd := coefficientLp_sub_norm_le (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.diffusion_continuous
    c.diffusion_lipschitz (fun z => c.diffusion_zero z.1) X Y
  rw [picard,picard,map_add,map_add,map_add,map_add]
  rw [show ∀ a b d e f : ProcessLp (μ:=μ) (ι:=ι) T hBm,
    (a+b+d)-(a+e+f)=(b-e)+(d-f) from fun _ _ _ _ _ => by abel]
  calc
    _ ≤ _ := norm_add_le _ _
    _ ≤ (Fintype.card ι:ℝ)*(Real.sqrt ((t:ℝ)-(s:ℝ))*Real.sqrt (T:ℝ))*‖c.driftLp T hBm X-c.driftLp T hBm Y‖ +
      (Fintype.card ι:ℝ)*Real.sqrt ((t:ℝ)-(s:ℝ))*‖c.diffusionLp T hBm X-c.diffusionLp T hBm Y‖ := add_le_add hdn hin
    _ ≤ (Fintype.card ι:ℝ)*(Real.sqrt ((t:ℝ)-(s:ℝ))*Real.sqrt (T:ℝ))*(c.Lb*‖X-Y‖) +
      (Fintype.card ι:ℝ)*Real.sqrt ((t:ℝ)-(s:ℝ))*(c.Lσ*‖X-Y‖) :=
      add_le_add (mul_le_mul_of_nonneg_left hbd (by positivity))
        (mul_le_mul_of_nonneg_left hsd (by positivity))
    _ = _ := by ring

/-- Predictable L2 Picard iteration is causal at every deterministic time. -/
theorem picard_causal (hB : IsPreBrownianReal B μ) (T s : ℝ≥0)
    (hBm : ∀ u, Measurable (B u)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (hs : s ≤ T)
    (X Y : ProcessLp (μ:=μ) (ι:=ι) T hBm) (he : cut T s hBm X = cut T s hBm Y) :
    cut T s hBm (picard hB T hBm hBc c x₀ X) = cut T s hBm (picard hB T hBm hBc c x₀ Y) := by
  have h := picard_interval_norm_le hB T s s hBm hBc c x₀ le_rfl hs X Y he
  simp only [sub_self,Real.sqrt_zero,mul_zero,zero_mul] at h
  exact sub_eq_zero.mp (norm_eq_zero.mp (le_antisymm h (norm_nonneg _)))

end
end ChainFountainStochastic.FinitePicard


namespace ChainFountainStochastic.FiniteHorizon
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM MathFin.SDEExistence
open TimeProjection FinitePicard VectorSDE SDEContinuous
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1000000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Construct a finite time partition whose individual Picard steps contract.
The full deterministic horizon is arbitrary. -/
theorem exists_contracting_partition (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ u, Measurable (B u)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) :
    ∃ (N : ℕ) (P : ℕ → ProcessLp (μ:=μ) (ι:=ι) T hBm →L[ℝ] ProcessLp (μ:=μ) (ι:=ι) T hBm)
      (q : ℝ≥0), q < 1 ∧
      (∀ X, P 0 X = 0) ∧ (∀ X, P N X = X) ∧
      (∀ m n, m ≤ n → ∀ X, P m (P n X) = P m X) ∧
      (∀ n, n ≤ N → ∀ X Y, P n X = P n Y →
        P n (picard hB T hBm hBc c x₀ X) = P n (picard hB T hBm hBc c x₀ Y)) ∧
      (∀ n, n < N → ∀ X Y, P n X = P n Y →
        ‖P (n+1) (picard hB T hBm hBc c x₀ X) - P (n+1) (picard hB T hBm hBc c x₀ Y)‖ ≤ q*‖X-Y‖) := by
  let K : ℝ := (Fintype.card ι:ℝ)*(Real.sqrt (T:ℝ)*c.Lb+c.Lσ)
  have hK : 0 ≤ K := by dsimp [K]; positivity
  obtain ⟨δ,hδ,hq⟩ := exists_positive_contraction_horizon (0:ℝ≥0) (⟨K,hK⟩:ℝ≥0)
  have hq' : Real.sqrt (δ:ℝ)*K < 1 := by
    change (δ:ℝ)*0 + Real.sqrt (δ:ℝ)*K < 1 at hq
    simpa only [mul_zero,zero_add] using hq
  have hq0 : 0 ≤ Real.sqrt (δ:ℝ)*K := mul_nonneg (Real.sqrt_nonneg _) hK
  let q := Real.toNNReal (Real.sqrt (δ:ℝ)*K)
  have hqcoe : (q:ℝ) = Real.sqrt (δ:ℝ)*K := Real.coe_toNNReal _ hq0
  obtain ⟨N,hN⟩ := exists_nat_ge ((T:ℝ)/(δ:ℝ))
  have hNδ : T ≤ (N:ℝ≥0)*δ := by
    exact_mod_cast (div_le_iff₀ (show (0:ℝ) < δ from hδ)).mp hN
  let τ : ℕ → ℝ≥0 := fun n => min T ((n:ℝ≥0)*δ)
  have hτ0 : τ 0 = 0 := by simp [τ]
  have hτN : τ N = T := min_eq_left hNδ
  have hτT (n : ℕ) : τ n ≤ T := min_le_left _ _
  have hmono {m n : ℕ} (h : m ≤ n) : τ m ≤ τ n :=
    min_le_min_left T (mul_le_mul_of_nonneg_right (Nat.cast_le.mpr h) (show (0:ℝ≥0) ≤ δ from zero_le))
  have hstep (n : ℕ) : (τ (n+1):ℝ)-(τ n:ℝ) ≤ (δ:ℝ) := by
    simp only [τ,NNReal.coe_min,NNReal.coe_mul,NNReal.coe_natCast,Nat.cast_add,Nat.cast_one,NNReal.coe_add,NNReal.coe_one]
    simp only [min_def]
    split_ifs <;> nlinarith [δ.coe_nonneg]
  let P := fun n => cut (E:=ι → ℝ) (μ:=μ) T (τ n) hBm
  refine ⟨N,P,q,?_,?_,?_,?_,?_,?_⟩
  · change (q:ℝ) < 1
    rw [hqcoe]
    exact hq'
  · intro X; dsimp [P]; rw [hτ0,cut_zero]
  · intro X; dsimp [P]; rw [hτN,cut_full]
  · intro m n h X; exact cut_absorb T (τ m) (τ n) hBm (hmono h) X
  · intro n _ X Y he
    exact picard_causal hB T (τ n) hBm hBc c x₀ (hτT n) X Y he
  · intro n _ X Y he
    have hb := picard_interval_norm_le hB T (τ n) (τ (n+1)) hBm hBc c x₀
      (hmono (Nat.le_succ _)) (hτT _) X Y he
    apply hb.trans
    apply mul_le_mul_of_nonneg_right _ (norm_nonneg _)
    rw [hqcoe]
    have hs := mul_le_mul_of_nonneg_right (Real.sqrt_le_sqrt (hstep n)) hK
    convert hs using 1 <;> dsimp [K] <;> ring

/-- Existence and uniqueness of the coupled predictable-L2 Picard fixed point
on every finite deterministic horizon. There is no full-horizon smallness assumption. -/
theorem picard_exists_unique_all_horizons (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ u, Measurable (B u)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) :
    ∃! X, picard hB T hBm hBc c x₀ X = X := by
  obtain ⟨N,P,q,hq,hzero,hfull,hab,hca,hco⟩ := exists_contracting_partition hB T hBm hBc c x₀
  obtain ⟨X,hX⟩ := CausalFixedPoint.exists_fixed_point N P _ hzero hfull hab hca q hq hco
  exact ⟨X,hX,fun Y hY => CausalFixedPoint.fixed_point_unique N P _ hzero hfull hab hca q hq hco hY hX⟩

/-- Actual continuous predictable strong solutions exist on every finite
horizon, with the coefficients evaluated along the constructed trajectory. -/
theorem exists_strong_solution_all_horizons (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ u, Measurable (B u)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) :
    ∃ Y, StrongSolution (μ:=μ) T hBm c x₀ Y := by
  obtain ⟨X,hX,_⟩ := picard_exists_unique_all_horizons hB T hBm hBc c x₀
  obtain ⟨Y,hY,_⟩ := realize_fixed_point hB T hBm hBc c x₀ X hX
  exact ⟨Y,hY⟩

/-- All-times pathwise uniqueness in the predictable L2 class, on every finite horizon. -/
theorem strong_solution_unique_all_horizons (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ u, Measurable (B u)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ)
    {Y Z : ℝ≥0 → Ω → (ι → ℝ)} (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hZ : StrongSolution (μ:=μ) T hBm c x₀ Z) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = Z t ω := by
  obtain ⟨_,_,hu⟩ := picard_exists_unique_all_horizons hB T hBm hBc c x₀
  have he : hY.state_memLp.toLp (Function.uncurry Y) = hZ.state_memLp.toLp (Function.uncurry Z) :=
    (hu _ (hY.fixed_point hB T hBm hBc c x₀)).trans (hu _ (hZ.fixed_point hB T hBm hBc c x₀)).symm
  filter_upwards [hY.canonical_equation T hBm c x₀,hZ.canonical_equation T hBm c x₀] with ω hy hz
  intro t ht
  rw [hy t ht,hz t ht,he]

end
end ChainFountainStochastic.FiniteHorizon


namespace ChainFountainStochastic.MechanicalFiniteHorizon
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoLocalMartingale
  MathFin.ItoIntegralProcessLocalMartingaleGeneral
open VectorSDE MechanicalCutoff LocalIntegralBridge ConstructedExit FiniteHorizon
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 900000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}

/-- One actual mechanical cutoff field admits a unique strong solution on
every finite deterministic horizon. No supplied trajectory is assumed. -/
theorem exists_unique_mechanical_cutoff_all_horizons
    {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω} [IsProbabilityMeasure μ]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (d : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi lo hi : State) (hlo : lo ≤ hi) (hh : 0 < lo 0)
    (hpmem : ∀ t, p t ∈ Icc plo phi) (x₀ : State) :
    ∃ c : Coefficients (Fin 3),
      (∀ t x, x ∈ Icc lo hi → c.drift t x = d.drift (p t,x)) ∧
      (∀ t x, x ∈ Icc lo hi → c.diffusion t x = d.diffusion (p t,x)) ∧
      (∀ t x, ‖c.drift t x‖ ≤ c.bound ∧ ‖c.diffusion t x‖ ≤ c.bound) ∧
      ∀ T : ℝ≥0, ∃ Y, StrongSolution (μ:=μ) T hBm c x₀ Y ∧
        ∀ Z, StrongSolution (μ:=μ) T hBm c x₀ Z →
          ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = Z t ω := by
  obtain ⟨c,_,_,hb,hσ,hbound⟩ := d.exists_cutoff p hp plo phi lo hi hlo hh hpmem
  refine ⟨c,hb,hσ,hbound,?_⟩
  intro T
  obtain ⟨Y,hY⟩ := exists_strong_solution_all_horizons hB T hBm hBc c x₀
  exact ⟨Y,hY,fun Z hZ => strong_solution_unique_all_horizons hB T hBm hBc c x₀ hY hZ⟩

/-- On any prescribed positive finite horizon, construct the mechanical cutoff
solution, its continuous adapted version and genuine positive capped exit.
The original mechanical equation holds before that exit. -/
theorem exists_constructed_mechanical_exit_all_horizons
    [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
    (T : ℝ≥0) (hT : 0 < T)
    (hB : IsPreBrownianReal B μ) (hBm : ∀ t, Measurable (B t))
    (hBc : ∀ ω, Continuous (fun t => B t ω))
    (d : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi lo hi : State) (hlo : lo ≤ hi) (hh : 0 < lo 0)
    (hpmem : ∀ t, p t ∈ Icc plo phi) (x₀ : State) (R : ℝ) (hR : 0 < R)
    (hball : Metric.closedBall x₀ R ⊆ Icc lo hi) :
    ∃ c : Coefficients (Fin 3),
      ∃ Y X : ℝ≥0 → Ω → State,
        StrongSolution (μ:=μ) T hBm c x₀ Y ∧
        StronglyAdapted (augFiltration (μ:=μ) hBm) X ∧
        (∀ ω, Continuous (fun t => X t ω)) ∧
        (∀ ω, X 0 ω = x₀) ∧
        (∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, X t ω = Y t ω) ∧
        IsStoppingTime (augFiltration (μ:=μ) hBm) (normExit X x₀ R T) ∧
        (∀ ω, ⊥ < normExit X x₀ R T ω) ∧
        (∀ ω, normExit X x₀ R T ω ≤ T) ∧
        (∀ t ω, stoppedProcess X (normExit X x₀ R T) t ω ∈ Icc lo hi) ∧
        (∀ᵐ ω ∂μ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ normExit X x₀ R T ω →
          c.drift t (Y t ω) = d.drift (p t,Y t ω) ∧
          c.diffusion t (Y t ω) = d.diffusion (p t,Y t ω)) ∧
        (∃ hpred : IsStronglyPredictable (natFiltration hBm) Y,
          ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ normExit X x₀ R T ω → ∀ i : Fin 3,
          Y t ω i = x₀ i + (∫ s in Ioc (0:ℝ≥0) t, d.drift (p s,Y s ω) i ∂timeMeasure) +
            MathFin.ItoIntegralLocalised.predItoIntegral (μ:=μ) T hBm
              (diffusion_predictable hBm c hpred i) t ω) := by
  obtain ⟨c,_,_,hb,hσ,hbound⟩ := d.exists_cutoff p hp plo phi lo hi hlo hh hpmem
  obtain ⟨Y,hY⟩ := exists_strong_solution_all_horizons hB T hBm hBc c x₀
  obtain ⟨X,hXm,hXc,hX₀,hXY⟩ := exists_continuous_adapted_version
    hY.predictable.stronglyAdapted hY.continuous hY.initial
  obtain ⟨hτ,hpos,hcap,hstop⟩ := normExit_properties hXm hXc hX₀ hR hT
  refine ⟨c,Y,X,hY,hXm,hXc,hX₀,hXY,hτ,hpos,hcap,
    (fun t ω => hball (hstop t ω)),?_,?_⟩
  · filter_upwards [original_state_mem_before_exit hcap hstop hXY] with ω hω
    intro t ht
    exact ⟨hb t (Y t ω) (hball (hω t ht)),hσ t (Y t ω) (hball (hω t ht))⟩
  · refine ⟨hY.predictable,?_⟩
    filter_upwards [strong_solution_predIto_equation hB T hBm hBc c x₀ hY
      (fun t x => (hbound t x).2), original_state_mem_before_exit hcap hstop hXY]
      with ω he hm
    intro t ht i
    have htT : t ≤ T := WithTop.coe_le_coe.mp (ht.trans (hcap ω))
    have hi : (∫ s in Ioc (0:ℝ≥0) t, c.drift s (Y s ω) i ∂timeMeasure) =
        ∫ s in Ioc (0:ℝ≥0) t, d.drift (p s,Y s ω) i ∂timeMeasure := by
      apply setIntegral_congr_fun measurableSet_Ioc
      intro s hs
      exact congrFun (hb s (Y s ω) (hball (hm s ((WithTop.coe_le_coe.mpr hs.2).trans ht)))) i
    simpa only [hi] using he t ⟨zero_le,htT⟩ i

end
end ChainFountainStochastic.MechanicalFiniteHorizon


namespace ChainFountainStochastic.CausalConvergence
noncomputable section
open Filter Topology
open scoped NNReal
set_option maxHeartbeats 900000

/-- A nonnegative sequence with a strict contraction and a vanishing additive
error converges to zero. No boundedness of the sequence is assumed. -/
theorem tendsto_zero_of_contracting_error {u v : ℕ → ℝ} {q : ℝ}
    (hu : ∀ n, 0 ≤ u n) (hq0 : 0 ≤ q) (hq : q < 1)
    (hv : Tendsto v atTop (𝓝 0))
    (hstep : ∀ n, u (n+1) ≤ q*u n + v n) : Tendsto u atTop (𝓝 0) := by
  apply tendsto_order.2
  constructor
  · intro a ha
    exact Filter.Eventually.of_forall fun n => ha.trans_le (hu n)
  · intro ε hε
    have hb : 0 < ε/2 := half_pos hε
    have he : 0 < (1-q)*(ε/2) := mul_pos (sub_pos.mpr hq) hb
    obtain ⟨N,hN⟩ := eventually_atTop.1 (hv.eventually (gt_mem_nhds he))
    have hbound : ∀ k, u (N+k) ≤ q^k*u N + ε/2 := by
      intro k
      induction k with
      | zero => simp only [Nat.add_zero,pow_zero,one_mul]; linarith
      | succ k ih =>
        have h := hstep (N+k)
        have hvk := hN (N+k) (Nat.le_add_right _ _)
        have hm := mul_le_mul_of_nonneg_left ih hq0
        rw [pow_succ]
        simpa only [Nat.add_assoc] using (show u (N+k+1) ≤ q^k*q*u N+ε/2 by nlinarith)
    have hp : Tendsto (fun k : ℕ => q^k*u N) atTop (𝓝 0) := by
      simpa using (tendsto_pow_atTop_nhds_zero_of_lt_one hq0 hq).mul_const (u N)
    obtain ⟨K,hK⟩ := eventually_atTop.1 (hp.eventually (gt_mem_nhds hb))
    refine eventually_atTop.2 ⟨N+K,fun n hn => ?_⟩
    have hNn : N ≤ n := (Nat.le_add_right N K).trans hn
    have hKn : K ≤ n-N := by omega
    have heq : N+(n-N) = n := Nat.add_sub_of_le hNn
    have h := hbound (n-N)
    rw [heq] at h
    linarith [hK (n-N) hKn]

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- A causal short-increment contraction gives a triangular estimate: the
next-prefix error contracts, with a controlled error from the preceding prefix. -/
theorem prefix_error_bound (P Q : E →L[ℝ] E) (F : E → E)
    (hPP : ∀ x, P (P x) = P x) (hQQ : ∀ x, Q (Q x) = Q x)
    (hPQ : ∀ x, P (Q x) = P x)
    (hcausal : ∀ x y, Q x = Q y → Q (F x) = Q (F y))
    {L q : ℝ} (hL : ∀ x y, ‖F x-F y‖ ≤ L*‖x-y‖) (hq : 0 ≤ q)
    (hcontract : ∀ x y, P x = P y → ‖Q (F x)-Q (F y)‖ ≤ q*‖x-y‖)
    (x y : E) :
    ‖Q (F x)-Q (F y)‖ ≤ q*‖Q x-Q y‖ + (‖Q‖*L+q)*‖P x-P y‖ := by
  let z := Q x + P (y-x)
  have hPz : P z = P (Q y) := by
    dsimp [z]
    rw [map_add,hPP,hPQ,hPQ,map_sub]
    abel
  have hx : Q (F x) = Q (F (Q x)) := hcausal _ _ (hQQ x).symm
  have hy : Q (F y) = Q (F (Q y)) := hcausal _ _ (hQQ y).symm
  have hdiff : Q x-z = -(P (y-x)) := by dsimp [z]; abel
  have hnorm : ‖P (y-x)‖ = ‖P x-P y‖ := by rw [map_sub,norm_sub_rev]
  have hnear : ‖Q (F (Q x))-Q (F z)‖ ≤ (‖Q‖*L)*‖P x-P y‖ := by
    calc
      _ = ‖Q (F (Q x)-F z)‖ := by rw [map_sub]
      _ ≤ ‖Q‖*‖F (Q x)-F z‖ := Q.le_opNorm _
      _ ≤ ‖Q‖*(L*‖Q x-z‖) := mul_le_mul_of_nonneg_left (hL _ _) (norm_nonneg _)
      _ = _ := by rw [hdiff,norm_neg,hnorm]; ring
  have hz : ‖z-Q y‖ ≤ ‖Q x-Q y‖+‖P x-P y‖ := by
    calc
      _ = ‖(Q x-Q y)+P (y-x)‖ := by congr 1; dsimp [z]; abel
      _ ≤ _ := norm_add_le _ _
      _ = _ := by rw [hnorm]
  rw [hx,hy]
  calc
    _ ≤ ‖Q (F (Q x))-Q (F z)‖+‖Q (F z)-Q (F (Q y))‖ := norm_sub_le_norm_sub_add_norm_sub _ _ _
    _ ≤ (‖Q‖*L)*‖P x-P y‖+q*‖z-Q y‖ := add_le_add hnear (hcontract z (Q y) hPz)
    _ ≤ (‖Q‖*L)*‖P x-P y‖+q*(‖Q x-Q y‖+‖P x-P y‖) :=
      add_le_add_right (mul_le_mul_of_nonneg_left hz hq) _
    _ = _ := by ring

/-- Picard iterates of a globally Lipschitz causal map converge to its fixed
point whenever a finite partition has contracting increments. The map itself
need not contract on the full horizon. -/
theorem tendsto_iterate_of_causal_partition (N : ℕ) (P : ℕ → E →L[ℝ] E)
    (F : E → E) (hzero : ∀ x, P 0 x = 0) (hfull : ∀ x, P N x = x)
    (habsorb : ∀ m n, m ≤ n → ∀ x, P m (P n x) = P m x)
    (hcausal : ∀ n, n ≤ N → ∀ x y, P n x = P n y → P n (F x) = P n (F y))
    (L : ℝ) (hL : ∀ x y, ‖F x-F y‖ ≤ L*‖x-y‖)
    (q : ℝ≥0) (hq : q < 1)
    (hcontract : ∀ n, n < N → ∀ x y, P n x = P n y →
      ‖P (n+1) (F x)-P (n+1) (F y)‖ ≤ q*‖x-y‖)
    (x y : E) (hy : F y = y) : Tendsto (fun k => F^[k] x) atTop (𝓝 y) := by
  have hp : ∀ n, n ≤ N → Tendsto (fun k => ‖P n (F^[k] x)-P n y‖) atTop (𝓝 0) := by
    intro n
    induction n with
    | zero => intro _; simpa only [hzero,sub_self,norm_zero] using tendsto_const_nhds
    | succ n ih =>
      intro hn
      have hv := (ih (Nat.le_of_succ_le hn)).const_mul (‖P (n+1)‖*L+(q:ℝ))
      apply tendsto_zero_of_contracting_error (fun _ => norm_nonneg _) q.coe_nonneg hq
        (by simpa using hv)
      intro k
      have h := prefix_error_bound (P n) (P (n+1)) F
        (habsorb n n le_rfl) (habsorb (n+1) (n+1) le_rfl)
        (habsorb n (n+1) (Nat.le_succ _)) (hcausal (n+1) hn) hL q.coe_nonneg
        (hcontract n (Nat.lt_of_succ_le hn)) (F^[k] x) y
      simpa only [Function.iterate_succ_apply',hy] using h
  have h := hp N le_rfl
  simpa only [hfull] using (tendsto_iff_norm_sub_tendsto_zero).2 h

end
end ChainFountainStochastic.CausalConvergence


namespace ChainFountainStochastic.FiniteStoppedUniqueness
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM
open VectorSDE VectorLp PrefixLimits StoppedUniqueness FiniteHorizon
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 900000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The actual coupled Picard iteration converges on every finite horizon,
from every predictable square-integrable initial iterate. -/
theorem picard_iterates_converge
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ)
    (X Y : ProcessLp (μ:=μ) (ι:=ι) T hBm)
    (hY : picard hB T hBm hBc c x₀ Y = Y) :
    Tendsto (fun n => (picard hB T hBm hBc c x₀)^[n] X) atTop (𝓝 Y) := by
  obtain ⟨N,P,q,hq,hzero,hfull,hab,hca,hco⟩ :=
    exists_contracting_partition hB T hBm hBc c x₀
  exact CausalConvergence.tendsto_iterate_of_causal_partition N P _ hzero hfull hab hca
    (contractionFactor c T) (picard_sub_norm_le hB T hBm hBc c x₀) q hq hco X Y hY

/-- Pathwise uniqueness before any random prefix on which the coefficient
fields agree along the comparison solution. Neither the equality of solutions
nor a stopped energy estimate is assumed. -/
theorem strong_solution_prefix_unique_all_horizons
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c d : Coefficients ι) (x₀ : ι → ℝ)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖d.diffusion t x‖ ≤ d.bound)
    {Y Z : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hZ : StrongSolution (μ:=μ) T hBm d x₀ Z)
    (τ : Ω → ℝ≥0)
    (hcoeff : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω →
      c.drift t (Z t ω) = d.drift t (Z t ω) ∧
      c.diffusion t (Z t ω) = d.diffusion t (Z t ω)) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω → Y t ω = Z t ω := by
  let f := picard hB T hBm hBc c x₀
  let Z₀ := hZ.state_memLp.toLp (Function.uncurry Z)
  let Yn (n : ℕ) := picardPath T hBm c x₀ (f^[n] Z₀)
  have hcoe (n : ℕ) : ⇑(f^[n+1] Z₀) =ᵐ[trimMeasure_T (μ:=μ) T hBm]
      Function.uncurry (Yn n) := by
    unfold Yn picardPath Function.uncurry
    simpa only [Function.iterate_succ_apply',f] using
      picard_coe hB T hBm hBc c x₀ (f^[n] Z₀)
  have he (n : ℕ) : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω → Yn n t ω = Z t ω := by
    induction n with
    | zero =>
      exact picardPath_preserves_prefix hB T hBm hBc c d x₀ hb hd hZ Z₀
        hZ.predictable hZ.continuous hZ.state_memLp.coeFn_toLp τ hcoeff
        (ae_of_all _ fun _ _ _ _ => rfl)
    | succ n ih =>
      exact picardPath_preserves_prefix hB T hBm hBc c d x₀ hb hd hZ (f^[n+1] Z₀)
        (picardPath_predictable hB T hBm hBc c x₀ _) (picardPath_continuous hB T hBm hBc c x₀ _)
        (hcoe n) τ hcoeff ih
  have hlim : Tendsto (fun n => f^[n+1] Z₀) atTop
      (𝓝 (hY.state_memLp.toLp (Function.uncurry Y))) :=
    (picard_iterates_converge hB T hBm hBc c x₀ Z₀ _
      (hY.fixed_point hB T hBm hBc c x₀)).comp (tendsto_add_atTop_nat 1)
  exact prefix_agreement_of_tendsto_Lp T hBm (fun n => f^[n+1] Z₀) _ hlim
    hcoe hY.state_memLp.coeFn_toLp hY.continuous hZ.continuous
    (fun ω => (hY.initial ω).trans (hZ.initial ω).symm) τ he


end
end ChainFountainStochastic.FiniteStoppedUniqueness


namespace ChainFountainStochastic.FiniteCutoffCompatibility
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralProcessLocalMartingaleGeneral
open VectorSDE MechanicalCutoff ConstructedExit CutoffCompatibility
open FiniteStoppedUniqueness FiniteHorizon
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 900000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}

/-- Before the norm-ball exit of a continuous version, two bounded-diffusion
strong solutions agree whenever their fields agree on that ball. -/
theorem strong_solutions_agree_before_normExit_all_horizons
    [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c d : Coefficients (Fin 3)) (x₀ : State)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖d.diffusion t x‖ ≤ d.bound)
    {Y Z XZ : ℝ≥0 → Ω → State}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hZ : StrongSolution (μ:=μ) T hBm d x₀ Z)
    {R : ℝ}
    (hstop : ∀ t ω, stoppedProcess XZ (normExit XZ x₀ R T) t ω ∈ Metric.closedBall x₀ R)
    (hXZ : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, XZ t ω = Z t ω)
    (hcoeff : ∀ t x, x ∈ Metric.closedBall x₀ R →
      c.drift t x = d.drift t x ∧ c.diffusion t x = d.diffusion t x) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ normExit XZ x₀ R T ω → Y t ω = Z t ω := by
  have hcap (ω : Ω) : normExit XZ x₀ R T ω ≤ T := min_le_right _ _
  have hfin (ω : Ω) : normExit XZ x₀ R T ω ≠ ⊤ :=
    ne_of_lt ((hcap ω).trans_lt (WithTop.coe_lt_top T))
  let τ := fun ω => (normExit XZ x₀ R T ω).untopA
  have hτ (ω : Ω) : (τ ω:WithTop ℝ≥0) = normExit XZ x₀ R T ω := by
    dsimp [τ]
    rw [WithTop.untopA_eq_untop (hfin ω)]
    exact WithTop.coe_untop _ _
  have hm := original_state_mem_before_exit hcap hstop hXZ
  have he := strong_solution_prefix_unique_all_horizons hB T hBm hBc c d x₀ hb hd hY hZ τ
    (by
      filter_upwards [hm] with ω hω
      intro t ht hle
      exact hcoeff t (Z t ω) (hω t (hτ ω ▸ WithTop.coe_le_coe.mpr hle)))
  filter_upwards [he] with ω hω
  intro t ht
  exact hω t ⟨zero_le,WithTop.coe_le_coe.mp (ht.trans (hcap ω))⟩
    (WithTop.coe_le_coe.mp ((hτ ω).symm ▸ ht))

/-- Arbitrary-finite-horizon cutoff compatibility includes equality of the actual random exits
and indistinguishability of the stopped continuous versions. -/
theorem continuous_versions_stopped_eq_all_horizons
    [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hT : 0 < T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c d : Coefficients (Fin 3)) (x₀ : State)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖d.diffusion t x‖ ≤ d.bound)
    {Y Z XY XZ : ℝ≥0 → Ω → State}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hZ : StrongSolution (μ:=μ) T hBm d x₀ Z)
    (hXYa : StronglyAdapted (augFiltration (μ:=μ) hBm) XY)
    (hXZa : StronglyAdapted (augFiltration (μ:=μ) hBm) XZ)
    (hXYc : ∀ ω, Continuous (fun t => XY t ω))
    (hXZc : ∀ ω, Continuous (fun t => XZ t ω))
    (hXY₀ : ∀ ω, XY 0 ω = x₀) (hXZ₀ : ∀ ω, XZ 0 ω = x₀)
    (hXY : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, XY t ω = Y t ω)
    (hXZ : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, XZ t ω = Z t ω)
    (R : ℝ) (hR : 0 < R)
    (hcoeff : ∀ t x, x ∈ Metric.closedBall x₀ R →
      c.drift t x = d.drift t x ∧ c.diffusion t x = d.diffusion t x) :
    ∀ᵐ ω ∂μ, normExit XY x₀ R T ω = normExit XZ x₀ R T ω ∧
      ∀ t, stoppedProcess XY (normExit XY x₀ R T) t ω =
        stoppedProcess XZ (normExit XZ x₀ R T) t ω := by
  obtain ⟨_,_,hcapZ,hstopZ⟩ := normExit_properties hXZa hXZc hXZ₀ hR hT
  have he := strong_solutions_agree_before_normExit_all_horizons hB T hBm hBc c d x₀ hb hd
    hY hZ hstopZ hXZ hcoeff
  filter_upwards [he,hXY,hXZ] with ω he hXY hXZ
  have heXZ (t : ℝ≥0) (ht : (t:WithTop ℝ≥0) ≤ normExit XZ x₀ R T ω) : XY t ω = XZ t ω := by
    have htT : t ∈ Icc 0 T := ⟨zero_le,WithTop.coe_le_coe.mp (ht.trans (hcapZ ω))⟩
    exact (hXY t htT).trans ((he t ht).trans (hXZ t htT).symm)
  have hτ := normExit_eq_of_prefix_eq hXYc hXZc hR ω
    (fun t _ ht => heXZ t (ht.trans (min_le_right _ _)))
  refine ⟨hτ,?_⟩
  intro t
  change XY (min (t:WithTop ℝ≥0) (normExit XY x₀ R T ω)).untopA ω =
    XZ (min (t:WithTop ℝ≥0) (normExit XZ x₀ R T ω)).untopA ω
  rw [hτ]
  apply heXZ
  rw [coe_untopA_min]
  exact min_le_right _ _

/-- Two actual mechanical cutoff constructions on different positive-height
boxes give the same stopped trajectory in every common ball, on a constructed
arbitrary prescribed positive horizon. All solutions and stopping times are conclusions. -/
theorem exists_compatible_mechanical_cutoff_solutions_all_horizons
    [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hT : 0 < T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (a : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi lo₁ hi₁ lo₂ hi₂ : State)
    (hlo₁ : lo₁ ≤ hi₁) (hh₁ : 0 < lo₁ 0)
    (hlo₂ : lo₂ ≤ hi₂) (hh₂ : 0 < lo₂ 0)
    (hpmem : ∀ t, p t ∈ Icc plo phi) (x₀ : State)
    (R : ℝ) (hR : 0 < R)
    (hball₁ : Metric.closedBall x₀ R ⊆ Icc lo₁ hi₁)
    (hball₂ : Metric.closedBall x₀ R ⊆ Icc lo₂ hi₂) :
    ∃ c d : Coefficients (Fin 3),
      (∀ t x, x ∈ Icc lo₁ hi₁ → c.drift t x = a.drift (p t,x) ∧
        c.diffusion t x = a.diffusion (p t,x)) ∧
      (∀ t x, x ∈ Icc lo₂ hi₂ → d.drift t x = a.drift (p t,x) ∧
        d.diffusion t x = a.diffusion (p t,x)) ∧
      ∃ Y Z XY XZ : ℝ≥0 → Ω → State,
        StrongSolution (μ:=μ) T hBm c x₀ Y ∧
        StrongSolution (μ:=μ) T hBm d x₀ Z ∧
        StronglyAdapted (augFiltration (μ:=μ) hBm) XY ∧
        StronglyAdapted (augFiltration (μ:=μ) hBm) XZ ∧
        (∀ ω, Continuous (fun t => XY t ω)) ∧
        (∀ ω, Continuous (fun t => XZ t ω)) ∧
        (∀ ω, XY 0 ω = x₀ ∧ XZ 0 ω = x₀) ∧
        (∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, XY t ω = Y t ω ∧ XZ t ω = Z t ω) ∧
        IsStoppingTime (augFiltration (μ:=μ) hBm) (normExit XY x₀ R T) ∧
        IsStoppingTime (augFiltration (μ:=μ) hBm) (normExit XZ x₀ R T) ∧
        (∀ ω, ⊥ < normExit XY x₀ R T ω ∧ ⊥ < normExit XZ x₀ R T ω) ∧
        (∀ᵐ ω ∂μ, normExit XY x₀ R T ω = normExit XZ x₀ R T ω ∧
          ∀ t, stoppedProcess XY (normExit XY x₀ R T) t ω =
            stoppedProcess XZ (normExit XZ x₀ R T) t ω) := by
  obtain ⟨c,_,_,hcb,hcσ,hcbd⟩ := a.exists_cutoff p hp plo phi lo₁ hi₁ hlo₁ hh₁ hpmem
  obtain ⟨d,_,_,hdb,hdσ,hdbd⟩ := a.exists_cutoff p hp plo phi lo₂ hi₂ hlo₂ hh₂ hpmem
  obtain ⟨Y,hY⟩ := exists_strong_solution_all_horizons hB T hBm hBc c x₀
  obtain ⟨Z,hZ⟩ := exists_strong_solution_all_horizons hB T hBm hBc d x₀
  obtain ⟨XY,hXYa,hXYc,hXY₀,hXY⟩ := exists_continuous_adapted_version
    hY.predictable.stronglyAdapted hY.continuous hY.initial
  obtain ⟨XZ,hXZa,hXZc,hXZ₀,hXZ⟩ := exists_continuous_adapted_version
    hZ.predictable.stronglyAdapted hZ.continuous hZ.initial
  obtain ⟨hτY,hposY,_,_⟩ := normExit_properties hXYa hXYc hXY₀ hR hT
  obtain ⟨hτZ,hposZ,_,_⟩ := normExit_properties hXZa hXZc hXZ₀ hR hT
  refine ⟨c,d,(fun t x hx => ⟨hcb t x hx,hcσ t x hx⟩),
    (fun t x hx => ⟨hdb t x hx,hdσ t x hx⟩),Y,Z,XY,XZ,hY,hZ,
    hXYa,hXZa,hXYc,hXZc,(fun ω => ⟨hXY₀ ω,hXZ₀ ω⟩),?_,hτY,hτZ,
    (fun ω => ⟨hposY ω,hposZ ω⟩),?_⟩
  · filter_upwards [hXY,hXZ] with ω hy hz
    exact fun t ht => ⟨hy t ht,hz t ht⟩
  · apply continuous_versions_stopped_eq_all_horizons hB T hT hBm hBc c d x₀
      (fun t x => (hcbd t x).2) (fun t x => (hdbd t x).2)
      hY hZ hXYa hXZa hXYc hXZc hXY₀ hXZ₀ hXY hXZ R hR
    intro t x hx
    exact ⟨(hcb t x (hball₁ hx)).trans (hdb t x (hball₂ hx)).symm,
      (hcσ t x (hball₁ hx)).trans (hdσ t x (hball₂ hx)).symm⟩


end
end ChainFountainStochastic.FiniteCutoffCompatibility


namespace ChainFountainStochastic.HorizonConsistency
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM MathFin.ItoIntegralLocalised
open MathFin.LocalisationInMeasure
open VectorSDE VectorLp LocalIntegralBridge TimeProjection FiniteHorizon
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1000000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The localized predictable integral is consistent between horizons on one
conull event, because both versions are limits of the same Riemann sums. -/
theorem predIto_horizon_consistency
    (hB : IsPreBrownianReal B μ) (S T : ℝ≥0) (hST : S ≤ T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {a : ℝ≥0 → Ω → ℝ} (hp : IsStronglyPredictable (natFiltration hBm) a)
    (hc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => a t ω) (Icc 0 T)) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 S,
      predItoIntegral (μ:=μ) S hBm hp t ω = predItoIntegral (μ:=μ) T hBm hp t ω := by
  have hcS := hc.mono fun _ h => h.mono (Icc_subset_Icc_right hST)
  exact ae_forall_eq_of_tendstoInMeasure
    (ae_continuousOn_predItoIntegral hB S hBm hBc hp hcS)
    ((ae_continuousOn_predItoIntegral hB T hBm hBc hp hc).mono
      fun _ h => h.mono (Icc_subset_Icc_right hST))
    (fun _ ht => tendstoInMeasure_riemannσ_predItoIntegral hB S hBm hBc hp hcS ht.2)
    (fun _ ht => tendstoInMeasure_riemannσ_predItoIntegral hB T hBm hBc hp hc (ht.2.trans hST))

/-- A bounded-diffusion strong solution restricts to every smaller horizon.
The stochastic-integral consistency is proved, not assumed. -/
theorem strong_solution_restrict
    (hB : IsPreBrownianReal B μ) (S T : ℝ≥0) (hST : S ≤ T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    {Y : ℝ≥0 → Ω → (ι → ℝ)} (hY : StrongSolution (μ:=μ) T hBm c x₀ Y) :
    StrongSolution (μ:=μ) S hBm c x₀ Y := by
  have hm : trimMeasure_T (μ:=μ) S hBm ≤ trimMeasure_T (μ:=μ) T hBm := by
    rw [←trim_restrict_eq T S hBm hST]
    exact Measure.restrict_le_self
  have hψ := hY.diffusion_memLp.mono_measure hm
  have he (i : ι) : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 S,
      vectorIto S hBm (hψ.toLp (fun z => c.diffusion z.1 (Y z.1 z.2))) t ω i =
        predItoIntegral (μ:=μ) T hBm (diffusion_predictable hBm c hY.predictable i) t ω := by
    have hc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => c.diffusion t (Y t ω) i) (Icc 0 T) :=
      hY.continuous.mono fun _ h => (continuous_apply i).comp_continuousOn
        (c.diffusion_continuous.comp_continuousOn (continuousOn_id.prodMk h))
    have hi := continuousMod_eq_predIto hB S hBm hBc
      (diffusion_predictable hBm c hY.predictable i)
      (hc.mono fun _ h => h.mono (Icc_subset_Icc_right hST))
      (fun t ω => (norm_le_pi_norm (c.diffusion t (Y t ω)) i).trans (hb t (Y t ω)))
      (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) S hBm) i
        (hψ.toLp (fun z => c.diffusion z.1 (Y z.1 z.2)))) (by
        filter_upwards [evalLp_coe (mα := (natFiltration hBm).predictable)
          (trimMeasure_T (μ:=μ) S hBm) i (hψ.toLp _),hψ.coeFn_toLp] with z hz hψ
        exact hz.trans (congrFun hψ i))
    filter_upwards [hi,predIto_horizon_consistency hB S T hST hBm hBc
      (diffusion_predictable hBm c hY.predictable i) hc] with ω hi he
    exact fun t ht => (hi t ht).trans (he t ht)
  refine ⟨hY.predictable,hY.continuous.mono (fun _ h => h.mono (Icc_subset_Icc_right hST)),
    hY.initial,hY.state_memLp.mono_measure hm,hY.drift_memLp.mono_measure hm,hψ,?_⟩
  filter_upwards [strong_solution_predIto_equation hB T hBm hBc c x₀ hY hb,
    ae_all_iff.mpr he] with ω hω he
  intro t ht i
  rw [he i t ⟨zero_le,ht⟩]
  exact hω t ⟨zero_le,ht.trans hST⟩ i

/-- All-times equality of predictable paths on a finite interval implies
 equality in its predictable L2 measure. -/
theorem predictable_ae_eq_of_path_eq (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    {Y Z : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : IsStronglyPredictable (natFiltration hBm) Y)
    (hZ : IsStronglyPredictable (natFiltration hBm) Z)
    (he : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, Y t ω = Z t ω) :
    Function.uncurry Y =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry Z := by
  apply StronglyMeasurable.ae_eq_trim_of_stronglyMeasurable
    (natFiltration hBm).predictable_le_prod hY hZ
  apply (Measure.ae_prod_iff_ae_ae ((hY.mono (natFiltration hBm).predictable_le_prod).measurableSet_eq_fun
    (hZ.mono (natFiltration hBm).predictable_le_prod))).2
  filter_upwards [ae_restrict_mem measurableSet_Ioc] with t ht
  filter_upwards [he] with ω hω
  exact hω t ⟨ht.1.le,ht.2⟩

/-- Strong-solution properties transfer to an indistinguishable predictable
version with the same pathwise initial value. -/
theorem strong_solution_congr (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (c : Coefficients ι) (x₀ : ι → ℝ)
    {Y Z : ℝ≥0 → Ω → (ι → ℝ)} (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hp : IsStronglyPredictable (natFiltration hBm) Z) (h₀ : ∀ ω, Z 0 ω = x₀)
    (he : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, Y t ω = Z t ω) :
    StrongSolution (μ:=μ) T hBm c x₀ Z := by
  have hLp := predictable_ae_eq_of_path_eq T hBm hY.predictable hp he
  have hd : (fun z : ℝ≥0 × Ω => c.drift z.1 (Y z.1 z.2)) =ᵐ[trimMeasure_T (μ:=μ) T hBm]
      (fun z => c.drift z.1 (Z z.1 z.2)) := hLp.mono fun z hz => congrArg (c.drift z.1) hz
  have hs : (fun z : ℝ≥0 × Ω => c.diffusion z.1 (Y z.1 z.2)) =ᵐ[trimMeasure_T (μ:=μ) T hBm]
      (fun z => c.diffusion z.1 (Z z.1 z.2)) := hLp.mono fun z hz => congrArg (c.diffusion z.1) hz
  have hψ := hY.diffusion_memLp.ae_eq hs
  have hclass := MemLp.toLp_congr hY.diffusion_memLp hψ hs
  refine ⟨hp,?_,h₀,hY.state_memLp.ae_eq hLp,hY.drift_memLp.ae_eq hd,hψ,?_⟩
  · filter_upwards [hY.continuous,he] with ω hc he
    exact hc.congr (fun t ht => (he t ht).symm)
  · filter_upwards [hY.equation,he] with ω hω he
    intro t ht i
    rw [←hclass,←he t ⟨zero_le,ht⟩,hω t ht i]
    congr 2
    apply setIntegral_congr_fun measurableSet_Ioc
    intro s hs
    change c.drift s (Y s ω) i = c.drift s (Z s ω) i
    rw [he s ⟨hs.1.le,hs.2.trans ht⟩]

end
end ChainFountainStochastic.HorizonConsistency


namespace ChainFountainStochastic.GlobalCutoffSDE
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM MathFin.ItoLocalMartingale
open VectorSDE FiniteHorizon HorizonConsistency ConstructedExit MechanicalCutoff
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1000000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- One predictable process solves the SDE on every finite interval. Unlike
separate finite-horizon existences, the witness is chosen before the horizon. -/
def GlobalStrongSolution (hBm : ∀ t, Measurable (B t)) (c : Coefficients ι)
    (x₀ : ι → ℝ) (Y : ℝ≥0 → Ω → (ι → ℝ)) : Prop :=
  ∀ T : ℝ≥0, StrongSolution (μ:=μ) T hBm c x₀ Y

/-- Glue the actual finite-horizon strong solutions into a single global
predictable process. Consistency and the measurable limit are both proved. -/
theorem exists_global_strong_solution
    (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound) :
    ∃ Y, GlobalStrongSolution (μ:=μ) hBm c x₀ Y := by
  have hex (n : ℕ) := exists_strong_solution_all_horizons hB (n:ℝ≥0) hBm hBc c x₀
  choose U hU using hex
  have hco (n m : ℕ) : ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ min (n:ℝ≥0) (m:ℝ≥0) →
      U n t ω = U m t ω :=
    strong_solution_unique_all_horizons hB _ hBm hBc c x₀
      (strong_solution_restrict hB _ _ (min_le_left _ _) hBm hBc c x₀ hb (hU n))
      (strong_solution_restrict hB _ _ (min_le_right _ _) hBm hBc c x₀ hb (hU m))
  let Y : ℝ≥0 → Ω → (ι → ℝ) := fun t ω => limUnder atTop (fun n => U n t ω)
  have hp : IsStronglyPredictable (natFiltration hBm) Y :=
    by
      letI : MeasurableSpace (ℝ≥0 × Ω) := (natFiltration hBm).predictable
      exact StronglyMeasurable.limUnder (fun n => (hU n).predictable)
  have he : ∀ᵐ ω ∂μ, ∀ n : ℕ, ∀ t ∈ Icc 0 (n:ℝ≥0), Y t ω = U n t ω := by
    filter_upwards [ae_all_iff.mpr (fun n => ae_all_iff.mpr (hco n))] with ω hω
    intro n t ht
    apply Tendsto.limUnder_eq
    apply tendsto_const_nhds.congr'
    refine eventually_atTop.2 ⟨n,fun m hm => ?_⟩
    exact hω n m t (le_min ht.2 (ht.2.trans (Nat.cast_le.mpr hm)))
  have h₀ (ω : Ω) : Y 0 ω = x₀ := by
    apply Tendsto.limUnder_eq
    simpa only [(hU _).initial ω] using
      (tendsto_const_nhds : Tendsto (fun _ : ℕ => x₀) atTop (𝓝 x₀))
  refine ⟨Y,fun T => ?_⟩
  obtain ⟨N,hN⟩ := exists_nat_ge T
  exact strong_solution_congr T hBm c x₀
    (strong_solution_restrict hB T N hN hBm hBc c x₀ hb (hU N)) hp h₀
    (he.mono fun ω hω t ht => (hω N t ⟨ht.1,ht.2.trans hN⟩).symm)

/-- Global uniqueness holds on one event of probability one simultaneously
for all nonnegative times. -/
theorem global_strong_solution_unique
    (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ)
    {Y Z : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y)
    (hZ : GlobalStrongSolution (μ:=μ) hBm c x₀ Z) :
    ∀ᵐ ω ∂μ, ∀ t, Y t ω = Z t ω := by
  filter_upwards [ae_all_iff.mpr (fun n : ℕ =>
    strong_solution_unique_all_horizons hB n hBm hBc c x₀ (hY n) (hZ n))] with ω hω
  intro t
  obtain ⟨N,hN⟩ := exists_nat_ge t
  exact hω N t hN

/-- Global path continuity follows from the countable family of finite
interval statements; there is no uncountable intersection of conull events. -/
theorem global_strong_solution_continuous
    (hBm : ∀ t, Measurable (B t)) (c : Coefficients ι) (x₀ : ι → ℝ)
    {Y : ℝ≥0 → Ω → (ι → ℝ)} (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y) :
    ∀ᵐ ω ∂μ, Continuous (fun t => Y t ω) := by
  filter_upwards [ae_all_iff.mpr (fun n : ℕ => (hY n).continuous)] with ω hω
  rw [continuous_iff_continuousAt]
  intro t
  obtain ⟨N,hN⟩ := exists_nat_gt t
  apply (hω N t ⟨zero_le,hN.le⟩).continuousAt
  have he : Icc (0:ℝ≥0) (N:ℝ≥0) = Iic (N:ℝ≥0) := by ext s; simp
  rw [he]
  exact Iic_mem_nhds hN

/-- A global strong solution has an everywhere-continuous adapted version
under the null-augmented filtration, equal at every time almost surely. -/
theorem exists_global_continuous_adapted_version
    (hBm : ∀ t, Measurable (B t)) (c : Coefficients ι) (x₀ : ι → ℝ)
    {Y : ℝ≥0 → Ω → (ι → ℝ)} (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y) :
    ∃ X : ℝ≥0 → Ω → (ι → ℝ),
      StronglyAdapted (MathFin.ItoIntegralProcessLocalMartingaleGeneral.augFiltration (μ:=μ) hBm) X ∧
      (∀ ω, Continuous (fun t => X t ω)) ∧ (∀ ω, X 0 ω = x₀) ∧
      (∀ᵐ ω ∂μ, ∀ t, X t ω = Y t ω) := by
  classical
  obtain ⟨G,hG,hGc,hGood⟩ := MathFin.ItoLocalMartingale.exists_nullsAlg_of_ae
    (global_strong_solution_continuous hBm c x₀ hY)
  let X : ℝ≥0 → Ω → (ι → ℝ) := fun t ω => if ω ∈ G then Y t ω else x₀
  let ℱ := natFiltration hBm
  refine ⟨X,?_,?_,?_,?_⟩
  · intro t
    letI : MeasurableSpace Ω := nullAugmentation ℱ μ t
    have hGt : MeasurableSet[nullAugmentation ℱ μ t] G :=
      (le_sup_right : nullsAlg mΩ μ ≤ ℱ t ⊔ nullsAlg mΩ μ) G hG
    have hYm : StronglyMeasurable[nullAugmentation ℱ μ t] (Y t) :=
      ((hY 0).predictable.stronglyAdapted t).mono le_sup_left
    exact StronglyMeasurable.ite hGt hYm stronglyMeasurable_const
  · intro ω
    by_cases hω : ω ∈ G
    · simpa only [X,if_pos hω] using hGood ω hω
    · simpa only [X,if_neg hω] using (continuous_const : Continuous (fun _ : ℝ≥0 => x₀))
  · intro ω
    simp [X,(hY 0).initial ω]
  · have hGae : ∀ᵐ ω ∂μ, ω ∈ G := by rw [ae_iff]; exact hGc
    filter_upwards [hGae] with ω hω
    exact fun t => if_pos hω

/-- Every actual mechanical cutoff has one globally defined strong solution,
pathwise unique among processes solving its equation on every finite interval. -/
theorem exists_unique_global_mechanical_cutoff
    (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (a : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi lo hi : State) (hlo : lo ≤ hi) (hh : 0 < lo 0)
    (hpmem : ∀ t, p t ∈ Icc plo phi) (x₀ : State) :
    ∃ c : Coefficients (Fin 3),
      (∀ t x, x ∈ Icc lo hi → c.drift t x = a.drift (p t,x) ∧
        c.diffusion t x = a.diffusion (p t,x)) ∧
      ∃ Y, GlobalStrongSolution (μ:=μ) hBm c x₀ Y ∧
        (∀ Z, GlobalStrongSolution (μ:=μ) hBm c x₀ Z → ∀ᵐ ω ∂μ, ∀ t, Y t ω = Z t ω) ∧
        ∃ X, StronglyAdapted (MathFin.ItoIntegralProcessLocalMartingaleGeneral.augFiltration (μ:=μ) hBm) X ∧
          (∀ ω, Continuous (fun t => X t ω)) ∧ (∀ ω, X 0 ω = x₀) ∧
          (∀ᵐ ω ∂μ, ∀ t, X t ω = Y t ω) := by
  obtain ⟨c,_,_,hb,hσ,hbound⟩ := a.exists_cutoff p hp plo phi lo hi hlo hh hpmem
  obtain ⟨Y,hY⟩ := exists_global_strong_solution hB hBm hBc c x₀ (fun t x => (hbound t x).2)
  refine ⟨c,(fun t x hx => ⟨hb t x hx,hσ t x hx⟩),Y,hY,
    fun Z hZ => global_strong_solution_unique hB hBm hBc c x₀ hY hZ,?_⟩
  exact exists_global_continuous_adapted_version hBm c x₀ hY

end
end ChainFountainStochastic.GlobalCutoffSDE


namespace ChainFountainStochastic.GlobalLocalization
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralProcessLocalMartingaleGeneral
open VectorSDE GlobalCutoffSDE FiniteStoppedUniqueness ConstructedExit MechanicalCutoff
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1000000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Global prefix uniqueness allows an infinite-valued random prefix. All
finite-horizon null sets are combined countably before choosing the time. -/
theorem global_prefix_unique
    (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c d : Coefficients ι) (x₀ : ι → ℝ)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖d.diffusion t x‖ ≤ d.bound)
    {Y Z : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y)
    (hZ : GlobalStrongSolution (μ:=μ) hBm d x₀ Z)
    (τ : Ω → WithTop ℝ≥0)
    (hcoeff : ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ τ ω →
      c.drift t (Z t ω) = d.drift t (Z t ω) ∧
      c.diffusion t (Z t ω) = d.diffusion t (Z t ω)) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ τ ω → Y t ω = Z t ω := by
  have he (N : ℕ) : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 (N:ℝ≥0), (t:WithTop ℝ≥0) ≤ τ ω →
      Y t ω = Z t ω := by
    let τN := fun ω => (min ((N:ℝ≥0):WithTop ℝ≥0) (τ ω)).untopA
    have hτN (ω : Ω) : (τN ω:WithTop ℝ≥0) = min ((N:ℝ≥0):WithTop ℝ≥0) (τ ω) :=
      coe_untopA_min _ _
    have hc : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 (N:ℝ≥0), t ≤ τN ω →
        c.drift t (Z t ω) = d.drift t (Z t ω) ∧
        c.diffusion t (Z t ω) = d.diffusion t (Z t ω) := by
      filter_upwards [hcoeff] with ω hω
      intro t _ ht
      exact hω t ((WithTop.coe_le_coe.mpr ht).trans (by rw [hτN]; exact min_le_right _ _))
    filter_upwards [strong_solution_prefix_unique_all_horizons hB N hBm hBc c d x₀ hb hd
      (hY N) (hZ N) τN hc] with ω hω
    intro t ht hτ
    apply hω t ht
    apply WithTop.coe_le_coe.mp
    rw [hτN]
    exact le_min (WithTop.coe_le_coe.mpr ht.2) hτ
  filter_upwards [ae_all_iff.mpr he] with ω hω
  intro t ht
  obtain ⟨N,hN⟩ := exists_nat_ge t
  exact hω N t ⟨zero_le,hN⟩ ht

/-- The uncapped first exit from a continuous gauge sublevel. The value top
means the path never reaches the boundary. -/
def gaugeExit {E : Type*} (X : ℝ≥0 → Ω → E) (g : E → ℝ) : Ω → WithTop ℝ≥0 :=
  exitTime (fun t ω => g (X t ω)) 1

/-- A genuine positive stopping time without a deterministic cap; its stopped
path remains in the closed gauge sublevel. -/
theorem gaugeExit_properties
    {E : Type*} [NormedAddCommGroup E] [MeasurableSpace E] [BorelSpace E]
    {ℱ : Filtration ℝ≥0 mΩ} {X : ℝ≥0 → Ω → E} {g : E → ℝ} {x₀ : E}
    (hX : StronglyAdapted ℱ X) (hXc : ∀ ω, Continuous (fun t => X t ω))
    (hg : Continuous g) (h₀ : ∀ ω, X 0 ω = x₀) (hi : |g x₀| < 1) :
    IsStoppingTime ℱ (gaugeExit X g) ∧ (∀ ω, ⊥ < gaugeExit X g ω) ∧
      (∀ t ω, |g (stoppedProcess X (gaugeExit X g) t ω)| ≤ 1) := by
  have hc : ∀ ω, Continuous (fun t => g (X t ω)) := fun ω => hg.comp (hXc ω)
  have hm : ∀ t, Measurable[ℱ t] (fun ω => g (X t ω)) :=
    fun t => (hg.comp_stronglyMeasurable (hX t)).measurable
  have hpos (ω : Ω) : ⊥ < gaugeExit X g ω := by
    apply lt_of_not_ge
    intro hn
    obtain ⟨s,hs,hg⟩ := (exitTime_le_iff hc 1 0 ω).mp hn
    have hs0 : s = 0 := le_antisymm hs.2 zero_le
    have hg' : 1 ≤ |g x₀| := by simpa only [hs0,h₀,Nat.cast_one] using hg
    exact not_le.mpr hi hg'
  refine ⟨isStoppingTime_exitTime_of_measurable hm hc 1,hpos,?_⟩
  intro t ω
  simpa only [stoppedProcess,Nat.cast_one] using abs_le_of_le_exitTime hc (hpos ω)
    (s := (min (t:WithTop ℝ≥0) (gaugeExit X g ω)).untopA)
    (by rw [coe_untopA_min]; exact min_le_right _ _)

/-- Equality before the smaller genuine gauge exit forces equality of the
uncapped exit times, including the case of infinite exits. -/
theorem gaugeExit_eq_of_prefix_eq
    {E : Type*} [TopologicalSpace E] {X Z : ℝ≥0 → Ω → E} {g : E → ℝ}
    (hXc : ∀ ω, Continuous (fun t => X t ω))
    (hZc : ∀ ω, Continuous (fun t => Z t ω)) (hg : Continuous g)
    (ω : Ω)
    (he : ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ min (gaugeExit X g ω) (gaugeExit Z g ω) → X t ω = Z t ω) :
    gaugeExit X g ω = gaugeExit Z g ω := by
  have hn (A C : ℝ≥0 → Ω → E)
      (hA : ∀ ω, Continuous (fun t => A t ω))
      (hC : ∀ ω, Continuous (fun t => C t ω))
      (heq : ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ min (gaugeExit A g ω) (gaugeExit C g ω) → A t ω = C t ω) :
      ¬ gaugeExit A g ω < gaugeExit C g ω := by
    intro hlt
    have hfinite : gaugeExit A g ω ≠ ⊤ := ne_of_lt (hlt.trans_le le_top)
    let u := (gaugeExit A g ω).untopA
    have hu : (u:WithTop ℝ≥0) = gaugeExit A g ω := by
      dsimp [u]
      rw [WithTop.untopA_eq_untop hfinite]
      exact WithTop.coe_untop _ _
    obtain ⟨s,hs,hb⟩ := (exitTime_le_iff (fun ω => hg.comp (hA ω)) 1 u ω).mp hu.ge
    have hsA : (s:WithTop ℝ≥0) ≤ gaugeExit A g ω := hu ▸ WithTop.coe_le_coe.mpr hs.2
    have hsame := heq s (le_min hsA (hsA.trans hlt.le))
    have hCle : gaugeExit C g ω ≤ (u:WithTop ℝ≥0) :=
      (exitTime_le_iff (fun ω => hg.comp (hC ω)) 1 u ω).mpr ⟨s,hs,by simpa only [Function.comp_apply,hsame] using hb⟩
    exact not_le.mpr hlt (hu ▸ hCle)
  exact le_antisymm (not_lt.mp (hn Z X hZc hXc (fun t ht =>
    (he t (by simpa only [min_comm] using ht)).symm))) (not_lt.mp (hn X Z hXc hZc he))

/-- Global cutoff compatibility up to the actual uncapped exit of any common
continuous gauge region. The exits and stopped paths are indistinguishable. -/
theorem global_versions_stopped_eq
    (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c d : Coefficients ι) (x₀ : ι → ℝ)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖d.diffusion t x‖ ≤ d.bound)
    {Y Z XY XZ : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y)
    (hZ : GlobalStrongSolution (μ:=μ) hBm d x₀ Z)
    (hXYa : StronglyAdapted (augFiltration (μ:=μ) hBm) XY)
    (hXZa : StronglyAdapted (augFiltration (μ:=μ) hBm) XZ)
    (hXYc : ∀ ω, Continuous (fun t => XY t ω))
    (hXZc : ∀ ω, Continuous (fun t => XZ t ω))
    (hXY₀ : ∀ ω, XY 0 ω = x₀) (hXZ₀ : ∀ ω, XZ 0 ω = x₀)
    (hXY : ∀ᵐ ω ∂μ, ∀ t, XY t ω = Y t ω)
    (hXZ : ∀ᵐ ω ∂μ, ∀ t, XZ t ω = Z t ω)
    (g : (ι → ℝ) → ℝ) (hg : Continuous g) (hi : |g x₀| < 1)
    (hcoeff : ∀ t x, |g x| ≤ 1 → c.drift t x = d.drift t x ∧ c.diffusion t x = d.diffusion t x) :
    ∀ᵐ ω ∂μ, gaugeExit XY g ω = gaugeExit XZ g ω ∧
      ∀ t, stoppedProcess XY (gaugeExit XY g) t ω = stoppedProcess XZ (gaugeExit XZ g) t ω := by
  have hs := (gaugeExit_properties hXZa hXZc hg hXZ₀ hi).2.2
  have hc : ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ gaugeExit XZ g ω →
      c.drift t (Z t ω) = d.drift t (Z t ω) ∧ c.diffusion t (Z t ω) = d.diffusion t (Z t ω) := by
    filter_upwards [hXZ] with ω hω
    intro t ht
    apply hcoeff
    rw [←hω t]
    simpa only [stoppedProcess_eq_of_le ht] using hs t ω
  filter_upwards [global_prefix_unique hB hBm hBc c d x₀ hb hd hY hZ (gaugeExit XZ g) hc,
    hXY,hXZ] with ω he hXY hXZ
  have hsame (t : ℝ≥0) (ht : (t:WithTop ℝ≥0) ≤ gaugeExit XZ g ω) : XY t ω = XZ t ω :=
    (hXY t).trans ((he t ht).trans (hXZ t).symm)
  have hτ := gaugeExit_eq_of_prefix_eq hXYc hXZc hg ω
    (fun t ht => hsame t (ht.trans (min_le_right _ _)))
  refine ⟨hτ,fun t => ?_⟩
  change XY (min (t:WithTop ℝ≥0) (gaugeExit XY g ω)).untopA ω =
    XZ (min (t:WithTop ℝ≥0) (gaugeExit XZ g ω)).untopA ω
  rw [hτ]
  apply hsame
  rw [coe_untopA_min]
  exact min_le_right _ _

/-- Two actual mechanical cutoffs have globally constructed strong solutions
with identical uncapped exits and stopped paths in any common gauge region.
All trajectories, continuous versions and stopping times are conclusions. -/
theorem exists_compatible_global_mechanical_cutoffs
    (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (a : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi lo₁ hi₁ lo₂ hi₂ : State)
    (hlo₁ : lo₁ ≤ hi₁) (hh₁ : 0 < lo₁ 0) (hlo₂ : lo₂ ≤ hi₂) (hh₂ : 0 < lo₂ 0)
    (hpmem : ∀ t, p t ∈ Icc plo phi) (x₀ : State)
    (g : State → ℝ) (hg : Continuous g) (hi : |g x₀| < 1)
    (hbox₁ : ∀ x, |g x| ≤ 1 → x ∈ Icc lo₁ hi₁)
    (hbox₂ : ∀ x, |g x| ≤ 1 → x ∈ Icc lo₂ hi₂) :
    ∃ c d : Coefficients (Fin 3),
      (∀ t x, x ∈ Icc lo₁ hi₁ → c.drift t x = a.drift (p t,x) ∧ c.diffusion t x = a.diffusion (p t,x)) ∧
      (∀ t x, x ∈ Icc lo₂ hi₂ → d.drift t x = a.drift (p t,x) ∧ d.diffusion t x = a.diffusion (p t,x)) ∧
      ∃ Y Z XY XZ : ℝ≥0 → Ω → State,
        GlobalStrongSolution (μ:=μ) hBm c x₀ Y ∧ GlobalStrongSolution (μ:=μ) hBm d x₀ Z ∧
        StronglyAdapted (augFiltration (μ:=μ) hBm) XY ∧ StronglyAdapted (augFiltration (μ:=μ) hBm) XZ ∧
        (∀ ω, Continuous (fun t => XY t ω)) ∧ (∀ ω, Continuous (fun t => XZ t ω)) ∧
        (∀ ω, XY 0 ω = x₀ ∧ XZ 0 ω = x₀) ∧
        (∀ᵐ ω ∂μ, ∀ t, XY t ω = Y t ω ∧ XZ t ω = Z t ω) ∧
        IsStoppingTime (augFiltration (μ:=μ) hBm) (gaugeExit XY g) ∧
        IsStoppingTime (augFiltration (μ:=μ) hBm) (gaugeExit XZ g) ∧
        (∀ ω, ⊥ < gaugeExit XY g ω ∧ ⊥ < gaugeExit XZ g ω) ∧
        (∀ᵐ ω ∂μ, gaugeExit XY g ω = gaugeExit XZ g ω ∧
          ∀ t, stoppedProcess XY (gaugeExit XY g) t ω = stoppedProcess XZ (gaugeExit XZ g) t ω) := by
  obtain ⟨c,_,_,hcb,hcσ,hcbound⟩ := a.exists_cutoff p hp plo phi lo₁ hi₁ hlo₁ hh₁ hpmem
  obtain ⟨d,_,_,hdb,hdσ,hdbound⟩ := a.exists_cutoff p hp plo phi lo₂ hi₂ hlo₂ hh₂ hpmem
  obtain ⟨Y,hY⟩ := exists_global_strong_solution hB hBm hBc c x₀ (fun t x => (hcbound t x).2)
  obtain ⟨Z,hZ⟩ := exists_global_strong_solution hB hBm hBc d x₀ (fun t x => (hdbound t x).2)
  obtain ⟨XY,hXYa,hXYc,hXY₀,hXY⟩ := exists_global_continuous_adapted_version hBm c x₀ hY
  obtain ⟨XZ,hXZa,hXZc,hXZ₀,hXZ⟩ := exists_global_continuous_adapted_version hBm d x₀ hZ
  obtain ⟨hτY,hposY,_⟩ := gaugeExit_properties hXYa hXYc hg hXY₀ hi
  obtain ⟨hτZ,hposZ,_⟩ := gaugeExit_properties hXZa hXZc hg hXZ₀ hi
  refine ⟨c,d,(fun t x hx => ⟨hcb t x hx,hcσ t x hx⟩),(fun t x hx => ⟨hdb t x hx,hdσ t x hx⟩),
    Y,Z,XY,XZ,hY,hZ,hXYa,hXZa,hXYc,hXZc,(fun ω => ⟨hXY₀ ω,hXZ₀ ω⟩),?_,hτY,hτZ,
    (fun ω => ⟨hposY ω,hposZ ω⟩),?_⟩
  · filter_upwards [hXY,hXZ] with ω hXY hXZ
    exact fun t => ⟨hXY t,hXZ t⟩
  · apply global_versions_stopped_eq hB hBm hBc c d x₀
      (fun t x => (hcbound t x).2) (fun t x => (hdbound t x).2)
      hY hZ hXYa hXZa hXYc hXZc hXY₀ hXZ₀ hXY hXZ g hg hi
    intro t x hx
    exact ⟨(hcb t x (hbox₁ x hx)).trans (hdb t x (hbox₂ x hx)).symm,
      (hcσ t x (hbox₁ x hx)).trans (hdσ t x (hbox₂ x hx)).symm⟩

end
end ChainFountainStochastic.GlobalLocalization


namespace ChainFountainStochastic.MechanicalExhaustion
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MechanicalCutoff GlobalLocalization
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 800000

/-- A continuous gauge whose unit sublevel is a compact positive-height box
intersected with a norm ball. The lower height bound decreases as the radius grows. -/
def gauge (r : ℝ) (x : State) : ℝ := max (‖x‖ / r) (2-r*x 0)

theorem gauge_continuous (r : ℝ) : Continuous (gauge r) := by
  unfold gauge
  fun_prop

theorem gauge_nonneg {r : ℝ} (hr : 0 < r) (x : State) : 0 ≤ gauge r x :=
  (div_nonneg (norm_nonneg x) hr.le).trans (le_max_left _ _)

theorem gauge_le_iff {r : ℝ} (hr : 0 < r) (x : State) :
    |gauge r x| ≤ 1 ↔ ‖x‖ ≤ r ∧ 1 ≤ r*x 0 := by
  rw [abs_of_nonneg (gauge_nonneg hr x),gauge,max_le_iff,div_le_iff₀ hr]
  constructor <;> rintro ⟨h₁,h₂⟩ <;> constructor <;> linarith

theorem gauge_lt_iff {r : ℝ} (hr : 0 < r) (x : State) :
    |gauge r x| < 1 ↔ ‖x‖ < r ∧ 1 < r*x 0 := by
  rw [abs_of_nonneg (gauge_nonneg hr x),gauge,max_lt_iff,div_lt_iff₀ hr]
  constructor <;> rintro ⟨h₁,h₂⟩ <;> constructor <;> linarith

theorem height_pos_of_gauge_le {r : ℝ} (hr : 0 < r) {x : State}
    (hx : |gauge r x| ≤ 1) : 0 < x 0 := by
  have h := (gauge_le_iff hr x).mp hx
  nlinarith

theorem gauge_strict_nesting {r s : ℝ} (hr : 0 < r) (hrs : r < s)
    {x : State} (hx : |gauge r x| ≤ 1) : |gauge s x| < 1 := by
  have h := (gauge_le_iff hr x).mp hx
  have hp := height_pos_of_gauge_le hr hx
  apply (gauge_lt_iff (hr.trans hrs) x).mpr
  constructor
  · exact h.1.trans_lt hrs
  · nlinarith

/-- Explicit cutoff box for each gauge sublevel. -/
def lower (r : ℝ) : State := ![1/r,-r,-r]
def upper (r : ℝ) : State := fun _ => r

theorem gauge_sublevel_box {r : ℝ} (hr : 0 < r) {x : State}
    (hx : |gauge r x| ≤ 1) : x ∈ Icc (lower r) (upper r) := by
  obtain ⟨hn,hh⟩ := (gauge_le_iff hr x).mp hx
  have hc (i : Fin 3) : |x i| ≤ r := (norm_le_pi_norm x i).trans hn
  refine ⟨?_,fun i => (le_abs_self _).trans (hc i)⟩
  intro i
  fin_cases i
  · change 1/r ≤ x 0
    exact (div_le_iff₀ hr).mpr (by nlinarith)
  · exact (abs_le.mp (hc 1)).1
  · exact (abs_le.mp (hc 2)).1

theorem gauge_sublevel_compact {r : ℝ} (hr : 0 < r) :
    IsCompact {x : State | |gauge r x| ≤ 1} := by
  apply (isCompact_closedBall (0:State) r).of_isClosed_subset
  · exact isClosed_le (gauge_continuous r).abs continuous_const
  · intro x hx
    simpa only [Metric.mem_closedBall,dist_zero_right] using ((gauge_le_iff hr x).mp hx).1

/-- Every admissible initial state lies strictly inside a first gauge region. -/
theorem exists_initial_radius (x₀ : State) (hh : 0 < x₀ 0) :
    ∃ R : ℝ, 1 < R ∧ |gauge R x₀| < 1 := by
  obtain ⟨R,hR⟩ := exists_gt (max 1 (max ‖x₀‖ (1/(x₀ 0))))
  have h1 : 1 < R := (le_max_left _ _).trans_lt hR
  have hn : ‖x₀‖ < R := (le_max_left _ _).trans (le_max_right _ _) |>.trans_lt hR
  have hi : 1/(x₀ 0) < R := (le_max_right _ _).trans (le_max_right _ _) |>.trans_lt hR
  refine ⟨R,h1,(gauge_lt_iff (by linarith) x₀).mpr ⟨hn,?_⟩⟩
  exact (div_lt_iff₀ hh).mp hi

/-- Every compact subset of positive height lies strictly inside one member
of the explicitly constructed exhaustion. -/
theorem compact_subset_gauge (R : ℝ) {K : Set State} (hK : IsCompact K)
    (hpos : ∀ x ∈ K, 0 < x 0) :
    ∃ n : ℕ, ∀ x ∈ K, |gauge ((n:ℝ)+R) x| < 1 := by
  by_cases he : K.Nonempty
  · obtain ⟨x,hx,hmin⟩ := hK.exists_isMinOn he (continuous_apply 0).continuousOn
    obtain ⟨C,hC⟩ := hK.bddAbove_image continuous_norm.continuousOn
    obtain ⟨n,hn⟩ := exists_nat_gt (max 0 (max C (1/(x 0))) - R)
    have hr : 0 < (n:ℝ)+R := by have := le_max_left 0 (max C (1/(x 0))); linarith
    have hc : C < (n:ℝ)+R := by have := (le_max_left C (1/(x 0))).trans (le_max_right 0 _); linarith
    have hh : 1/(x 0) < (n:ℝ)+R := by have := (le_max_right C (1/(x 0))).trans (le_max_right 0 _); linarith
    have hh' := (div_lt_iff₀ (hpos x hx)).mp hh
    refine ⟨n,fun y hy => (gauge_lt_iff hr y).mpr ⟨(hC (mem_image_of_mem _ hy)).trans_lt hc,?_⟩⟩
    have hm : x 0 ≤ y 0 := hmin hy
    nlinarith
  · exact ⟨0,fun x hx => False.elim (he ⟨x,hx⟩)⟩

/-- The gauge cutoff boxes are nonempty, separated from height zero, and
nested; these hypotheses are proved from the radius rather than supplied. -/
theorem cutoff_box_valid {r : ℝ} (hr : 1 < r) :
    lower r ≤ upper r ∧ 0 < lower r 0 := by
  have hpos : 0 < r := by linarith
  refine ⟨?_,by change 0 < 1/r; positivity⟩
  intro i
  fin_cases i
  · change 1/r ≤ r
    apply (div_le_iff₀ hpos).mpr
    nlinarith
  · change -r ≤ r; linarith
  · change -r ≤ r; linarith

end
end ChainFountainStochastic.MechanicalExhaustion

namespace ChainFountainStochastic.GaugeExit
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open GlobalLocalization
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
variable {Ω E : Type*} [TopologicalSpace E]

/-- The first exit is attained when finite; it is not merely an arbitrary
stopping time bounded by an exit. -/
theorem boundary_of_finite {X : ℝ≥0 → Ω → E} {g : E → ℝ}
    (hX : ∀ ω, Continuous (fun t => X t ω)) (hg : Continuous g)
    (ω : Ω) (hf : gaugeExit X g ω ≠ ⊤) :
    1 ≤ |g (X (gaugeExit X g ω).untopA ω)| := by
  let u := (gaugeExit X g ω).untopA
  have hu : (u:WithTop ℝ≥0) = gaugeExit X g ω := by
    dsimp [u]; rw [WithTop.untopA_eq_untop hf]; exact WithTop.coe_untop _ _
  obtain ⟨s,hs,hb⟩ := (exitTime_le_iff (fun ω => hg.comp (hX ω)) 1 u ω).mp hu.ge
  have hτs : gaugeExit X g ω ≤ (s:WithTop ℝ≥0) :=
    (exitTime_le_iff (fun ω => hg.comp (hX ω)) 1 s ω).mpr ⟨s,⟨zero_le,le_rfl⟩,hb⟩
  have hus : u ≤ s := WithTop.coe_le_coe.mp (hu.symm ▸ hτs)
  have he : s = u := le_antisymm hs.2 hus
  simpa only [he,Nat.cast_one,Function.comp_apply,u] using hb

/-- Strict interior membership before the actual exit. -/
theorem interior_before {X : ℝ≥0 → Ω → E} {g : E → ℝ}
    (hX : ∀ ω, Continuous (fun t => X t ω)) (hg : Continuous g)
    (ω : Ω) {t : ℝ≥0} (ht : (t:WithTop ℝ≥0) < gaugeExit X g ω) :
    |g (X t ω)| < 1 := by
  by_contra hn
  have hb : 1 ≤ |g (X t ω)| := not_lt.mp hn
  exact not_le.mpr ht ((exitTime_le_iff (fun ω => hg.comp (hX ω)) 1 t ω).mpr
    ⟨t,⟨zero_le,le_rfl⟩,by simpa only [Function.comp_apply,Nat.cast_one] using hb⟩)

/-- Strict nesting of the closed regions gives strictly ordered finite exits
of the same continuous path. -/
theorem strict_mono {X : ℝ≥0 → Ω → E} {g h : E → ℝ}
    (hX : ∀ ω, Continuous (fun t => X t ω)) (hg : Continuous g) (hh : Continuous h)
    (hpos : ∀ ω, ⊥ < gaugeExit X g ω)
    (hsub : ∀ x, |g x| ≤ 1 → |h x| < 1) (ω : Ω) :
    gaugeExit X g ω ≤ gaugeExit X h ω ∧
      (gaugeExit X g ω ≠ ⊤ → gaugeExit X g ω < gaugeExit X h ω) := by
  by_cases hf : gaugeExit X h ω = ⊤
  · rw [hf]
    exact ⟨le_top,fun hn => lt_top_iff_ne_top.mpr hn⟩
  · have hn : ¬ gaugeExit X h ω ≤ gaugeExit X g ω := by
      intro hle
      have hu : (((gaugeExit X h ω).untopA):WithTop ℝ≥0) = gaugeExit X h ω := by
        rw [WithTop.untopA_eq_untop hf]; exact WithTop.coe_untop _ _
      have hin : |g (X (gaugeExit X h ω).untopA ω)| ≤ 1 :=
        by
          simpa only [Function.comp_apply,Nat.cast_one] using
            abs_le_of_le_exitTime (fun ω => hg.comp (hX ω)) (hpos ω) (s := (gaugeExit X h ω).untopA) (hu.symm ▸ hle)
      exact not_le.mpr (hsub _ hin) (boundary_of_finite hX hh ω hf)
    exact ⟨(not_le.mp hn).le,fun _ => not_le.mp hn⟩

end
end ChainFountainStochastic.GaugeExit

namespace ChainFountainStochastic.CutoffExhaustion
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralProcessLocalMartingaleGeneral
open VectorSDE GlobalCutoffSDE MechanicalCutoff MechanicalExhaustion GlobalLocalization
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1000000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}

/-- A sequence of actual globally constructed cutoffs, including their strong
solutions and continuous adapted representatives. Compatibility is proved by
`exists_family`; it is not an input to the mechanical existence theorem. -/
structure Family (hBm : ∀ t, Measurable (B t)) (a : Parameters)
    (p : ℝ≥0 → State) (x₀ : State) where
  R : ℝ
  radius_gt : 1 < R
  initial_inside : |gauge R x₀| < 1
  c : ℕ → Coefficients (Fin 3)
  drift_bound : ∀ n t x, ‖(c n).drift t x‖ ≤ (c n).bound
  clamped_drift : ∀ n t x, (c n).drift t x = a.drift (p t,boxClamp (lower ((n:ℝ)+R)) (upper ((n:ℝ)+R)) x)
  clamped_diffusion : ∀ n t x, (c n).diffusion t x = a.diffusion (p t,boxClamp (lower ((n:ℝ)+R)) (upper ((n:ℝ)+R)) x)
  bound : ∀ n t x, ‖(c n).diffusion t x‖ ≤ (c n).bound
  agrees : ∀ (n : ℕ) t x, |gauge ((n:ℝ)+R) x| ≤ 1 →
    (c n).drift t x = a.drift (p t,x) ∧ (c n).diffusion t x = a.diffusion (p t,x)
  Y : ℕ → ℝ≥0 → Ω → State
  strong : ∀ n, GlobalStrongSolution (μ:=μ) hBm (c n) x₀ (Y n)
  X : ℕ → ℝ≥0 → Ω → State
  adapted : ∀ n, StronglyAdapted (augFiltration (μ:=μ) hBm) (X n)
  continuous : ∀ n ω, Continuous (fun t => X n t ω)
  initial : ∀ n ω, X n 0 ω = x₀
  version : ∀ n, ∀ᵐ ω ∂μ, ∀ t, X n t ω = Y n t ω
  compatible : ∀ᵐ ω ∂μ, ∀ n m : ℕ, n ≤ m →
    gaugeExit (X n) (gauge ((n:ℝ)+R)) ω = gaugeExit (X m) (gauge ((n:ℝ)+R)) ω ∧
    ∀ t, stoppedProcess (X n) (gaugeExit (X n) (gauge ((n:ℝ)+R))) t ω =
      stoppedProcess (X m) (gaugeExit (X m) (gauge ((n:ℝ)+R))) t ω

theorem radius_initial_inside {R : ℝ} (hR : 1 < R) {x₀ : State}
    (hi : |gauge R x₀| < 1) (n : ℕ) : |gauge ((n:ℝ)+R) x₀| < 1 := by
  by_cases hn : n = 0
  · simpa only [hn,Nat.cast_zero,zero_add] using hi
  · have hnpos : (0:ℝ) < n := by exact_mod_cast Nat.pos_of_ne_zero hn
    exact gauge_strict_nesting (by linarith : 0 < R) (by linarith : R < (n:ℝ)+R) hi.le

theorem radius_nesting {R : ℝ} (hR : 1 < R) {n m : ℕ} (hnm : n ≤ m)
    {x : State} (hx : |gauge ((n:ℝ)+R) x| ≤ 1) : |gauge ((m:ℝ)+R) x| ≤ 1 := by
  rcases hnm.eq_or_lt with he | hl
  · simpa only [he] using hx
  · have hlt : (n:ℝ) < (m:ℝ) := by exact_mod_cast hl
    exact (gauge_strict_nesting (by positivity : 0 < (n:ℝ)+R)
      (by linarith : (n:ℝ)+R < (m:ℝ)+R) hx).le

/-- Construct the full countable family from positive initial height and the
actual mechanical coefficients. No trajectories or exit sequence are supplied. -/
theorem exists_family
    (hB : IsPreBrownianReal B μ) (hBm : ∀ t, Measurable (B t))
    (hBc : ∀ ω, Continuous (fun t => B t ω))
    (a : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi : State) (hpmem : ∀ t, p t ∈ Icc plo phi)
    (x₀ : State) (hh : 0 < x₀ 0) : Nonempty (Family (μ:=μ) hBm a p x₀) := by
  obtain ⟨R,hR,hi⟩ := exists_initial_radius x₀ hh
  have hrad (n : ℕ) : 1 < (n:ℝ)+R := by have := Nat.cast_nonneg (α:=ℝ) n; linarith
  have hpos (n : ℕ) : 0 < (n:ℝ)+R := by linarith [hrad n]
  have hex (n : ℕ) := a.exists_cutoff p hp plo phi
    (lower ((n:ℝ)+R)) (upper ((n:ℝ)+R))
    (cutoff_box_valid (hrad n)).1 (cutoff_box_valid (hrad n)).2 hpmem
  choose c hcl hcs hca hcb hbound using hex
  have hsol (n : ℕ) := exists_global_strong_solution hB hBm hBc (c n) x₀
    (fun t x => (hbound n t x).2)
  choose Y hY using hsol
  choose X hXa hXc hX₀ hXY using fun n => exists_global_continuous_adapted_version hBm (c n) x₀ (hY n)
  have hagree (n : ℕ) (t : ℝ≥0) (x : State) (hx : |gauge ((n:ℝ)+R) x| ≤ 1) :
      (c n).drift t x = a.drift (p t,x) ∧ (c n).diffusion t x = a.diffusion (p t,x) :=
    ⟨hca n t x (gauge_sublevel_box (hpos n) hx),hcb n t x (gauge_sublevel_box (hpos n) hx)⟩
  have hco (n m : ℕ) : ∀ᵐ ω ∂μ, n ≤ m →
      gaugeExit (X n) (gauge ((n:ℝ)+R)) ω = gaugeExit (X m) (gauge ((n:ℝ)+R)) ω ∧
      ∀ t, stoppedProcess (X n) (gaugeExit (X n) (gauge ((n:ℝ)+R))) t ω =
        stoppedProcess (X m) (gaugeExit (X m) (gauge ((n:ℝ)+R))) t ω := by
    by_cases hnm : n ≤ m
    · have he := global_versions_stopped_eq hB hBm hBc (c n) (c m) x₀
        (fun t x => (hbound n t x).2) (fun t x => (hbound m t x).2)
        (hY n) (hY m) (hXa n) (hXa m) (hXc n) (hXc m) (hX₀ n) (hX₀ m)
        (hXY n) (hXY m) (gauge ((n:ℝ)+R)) (gauge_continuous _)
        (radius_initial_inside hR hi n) (fun t x hx =>
          ⟨(hagree n t x hx).1.trans (hagree m t x (radius_nesting hR hnm hx)).1.symm,
           (hagree n t x hx).2.trans (hagree m t x (radius_nesting hR hnm hx)).2.symm⟩)
      exact he.mono (fun _ h _ => h)
    · exact ae_of_all _ (fun _ h => (hnm h).elim)
  exact ⟨{
    R := R
    radius_gt := hR
    initial_inside := hi
    c := c
    drift_bound := fun n t x => (hbound n t x).1
    clamped_drift := hcl
    clamped_diffusion := hcs
    bound := fun n t x => (hbound n t x).2
    agrees := hagree
    Y := Y
    strong := hY
    X := X
    adapted := hXa
    continuous := hXc
    initial := hX₀
    version := hXY
    compatible := ae_all_iff.mpr (fun n => ae_all_iff.mpr (hco n)) }⟩

variable {hBm : ∀ t, Measurable (B t)} {a : Parameters} {p : ℝ≥0 → State} {x₀ : State}

def Family.exit (F : Family (μ:=μ) hBm a p x₀) (n : ℕ) : Ω → WithTop ℝ≥0 :=
  gaugeExit (F.X n) (gauge ((n:ℝ)+F.R))

theorem Family.exit_properties (F : Family (μ:=μ) hBm a p x₀) (n : ℕ) :
    IsStoppingTime (augFiltration (μ:=μ) hBm) (F.exit n) ∧
      (∀ ω, ⊥ < F.exit n ω) ∧
      ∀ t ω, |gauge ((n:ℝ)+F.R) (stoppedProcess (F.X n) (F.exit n) t ω)| ≤ 1 :=
  gaugeExit_properties (F.adapted n) (F.continuous n) (gauge_continuous _)
    (F.initial n) (radius_initial_inside F.radius_gt F.initial_inside n)

/-- Countably many null sets are removed once, before choosing either the
localization index or the real time. -/
theorem Family.prefix_agreement (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ, ∀ n m : ℕ, n ≤ m → ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ F.exit n ω →
      F.X n t ω = F.X m t ω := by
  filter_upwards [F.compatible] with ω hω
  intro n m hnm t ht
  obtain ⟨hτ,he⟩ := hω n m hnm
  have ht' : (t:WithTop ℝ≥0) ≤ gaugeExit (F.X m) (gauge ((n:ℝ)+F.R)) ω := hτ ▸ ht
  change (t:WithTop ℝ≥0) ≤ gaugeExit (F.X n) (gauge ((n:ℝ)+F.R)) ω at ht
  simpa only [stoppedProcess_eq_of_le ht,stoppedProcess_eq_of_le ht'] using he t

/-- The genuine exits increase, strictly until infinity. -/
theorem Family.exits_increase (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ, Monotone (fun n => F.exit n ω) ∧
      ∀ n, F.exit n ω ≠ ⊤ → F.exit n ω < F.exit (n+1) ω := by
  filter_upwards [F.compatible] with ω hω
  have hstrict (n m : ℕ) (hnm : n < m) : F.exit n ω ≤ F.exit m ω ∧
      (F.exit n ω ≠ ⊤ → F.exit n ω < F.exit m ω) := by
    have he := (hω n m hnm.le).1
    have hp := (gaugeExit_properties (F.adapted m) (F.continuous m) (gauge_continuous ((n:ℝ)+F.R))
      (F.initial m) (radius_initial_inside F.radius_gt F.initial_inside n)).2.1
    have hn : 0 < (n:ℝ)+F.R := by have := F.radius_gt; positivity
    have hm : (n:ℝ)+F.R < (m:ℝ)+F.R := by
      have hnmc : (n:ℝ) < (m:ℝ) := by exact_mod_cast hnm
      linarith
    simpa only [Family.exit,he] using GaugeExit.strict_mono (F.continuous m)
      (gauge_continuous ((n:ℝ)+F.R)) (gauge_continuous ((m:ℝ)+F.R)) hp
      (fun x hx => gauge_strict_nesting hn hm hx) ω
  refine ⟨?_,fun n => (hstrict n (n+1) (Nat.lt_succ_self n)).2⟩
  intro n m hnm
  rcases hnm.eq_or_lt with rfl | hlt
  · exact le_rfl
  · exact (hstrict n m hlt).1

end
end ChainFountainStochastic.CutoffExhaustion

namespace ChainFountainStochastic.CutoffExhaustion
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralProcessLocalMartingaleGeneral
open VectorSDE GlobalCutoffSDE MechanicalCutoff MechanicalExhaustion GlobalLocalization
open CutoffExhaustion LocalIntegralBridge
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1000000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {hBm : ∀ t, Measurable (B t)} {a : Parameters} {p : ℝ≥0 → State} {x₀ : State}

/-- The maximal lifetime is the supremum of the constructed genuine exits. -/
def Family.lifetime (F : Family (μ:=μ) hBm a p x₀) (ω : Ω) : WithTop ℝ≥0 :=
  ⨆ n, F.exit n ω

/-- A measurable pointwise limit glues the natural-filtration predictable
solutions. Its value after the lifetime is irrelevant to the local SDE. -/
def Family.process (F : Family (μ:=μ) hBm a p x₀) (t : ℝ≥0) (ω : Ω) : State :=
  limUnder atTop (fun n => F.Y n t ω)

theorem Family.lifetime_stopping (F : Family (μ:=μ) hBm a p x₀) :
    IsStoppingTime (augFiltration (μ:=μ) hBm) F.lifetime := by
  intro t
  have he : {ω | F.lifetime ω ≤ (t:WithTop ℝ≥0)} =
      ⋂ n : ℕ, {ω | F.exit n ω ≤ (t:WithTop ℝ≥0)} := by
    ext ω; simp only [Family.lifetime,mem_setOf_eq,iSup_le_iff,mem_iInter]
  rw [he]
  exact MeasurableSet.iInter (fun n => (F.exit_properties n).1 t)

theorem Family.lifetime_positive (F : Family (μ:=μ) hBm a p x₀) (ω : Ω) :
    ⊥ < F.lifetime ω :=
  ((F.exit_properties 0).2.1 ω).trans_le (le_iSup (fun n => F.exit n ω) 0)

theorem Family.process_predictable (F : Family (μ:=μ) hBm a p x₀) :
    IsStronglyPredictable (natFiltration hBm) F.process := by
  letI : MeasurableSpace (ℝ≥0 × Ω) := (natFiltration hBm).predictable
  exact StronglyMeasurable.limUnder (fun n => (F.strong n 0).predictable)

theorem Family.process_initial (F : Family (μ:=μ) hBm a p x₀) (ω : Ω) :
    F.process 0 ω = x₀ := by
  apply Tendsto.limUnder_eq
  simpa only [(F.strong _ 0).initial ω] using
    (tendsto_const_nhds : Tendsto (fun _ : ℕ => x₀) atTop (𝓝 x₀))

/-- The glued process agrees with each actual cutoff solution all the way to
its genuine exit, on a single conull event for all indices and all times. -/
theorem Family.process_eq_before_exit (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ, ∀ n : ℕ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ F.exit n ω →
      F.process t ω = F.X n t ω ∧ F.process t ω = F.Y n t ω := by
  filter_upwards [F.prefix_agreement,ae_all_iff.mpr F.version] with ω hco hv
  intro n t ht
  have he : F.process t ω = F.X n t ω := by
    apply Tendsto.limUnder_eq
    apply tendsto_const_nhds.congr'
    refine eventually_atTop.2 ⟨n,fun m hm => ?_⟩
    exact (hco n m hm t ht).trans (hv m t)
  exact ⟨he,he.trans (hv n t)⟩

/-- The path is continuous and has strictly positive height before its
lifetime, without any pre-existing solution hypothesis. -/
theorem Family.process_regular (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ, ContinuousOn (fun t => F.process t ω) {t | (t:WithTop ℝ≥0) < F.lifetime ω} ∧
      ∀ t : ℝ≥0, (t:WithTop ℝ≥0) < F.lifetime ω → 0 < F.process t ω 0 := by
  filter_upwards [F.process_eq_before_exit] with ω he
  have hlocal (t : ℝ≥0) (ht : (t:WithTop ℝ≥0) < F.lifetime ω) :
      ∃ n, (t:WithTop ℝ≥0) < F.exit n ω := lt_iSup_iff.mp ht
  refine ⟨?_,?_⟩
  · intro t ht
    obtain ⟨n,hn⟩ := hlocal t ht
    apply ContinuousAt.continuousWithinAt
    apply (F.continuous n ω).continuousAt.congr_of_eventuallyEq
    have ho : IsOpen {s : ℝ≥0 | (s:WithTop ℝ≥0) < F.exit n ω} :=
      isOpen_lt WithTop.continuous_coe continuous_const
    filter_upwards [ho.mem_nhds hn] with s hs
    exact (he n s hs.le).1
  · intro t ht
    obtain ⟨n,hn⟩ := hlocal t ht
    rw [(he n t hn.le).1]
    have hr : 0 < (n:ℝ)+F.R := by have := F.radius_gt; positivity
    exact height_pos_of_gauge_le hr
      (GaugeExit.interior_before (F.continuous n) (gauge_continuous _) ω hn).le

/-- If the lifetime is finite, every localization exits strictly before it.
This excludes a spurious finite terminal index in the gluing construction. -/
theorem Family.exit_lt_lifetime (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ, F.lifetime ω ≠ ⊤ → ∀ n, F.exit n ω < F.lifetime ω := by
  filter_upwards [F.exits_increase] with ω hω hf n
  have hn : F.exit n ω ≠ ⊤ := by
    intro he
    have hl : F.exit n ω ≤ F.lifetime ω := le_iSup (fun m => F.exit m ω) n
    rw [he] at hl
    exact hf (top_le_iff.mp hl)
  exact (hω.2 n hn).trans_le (le_iSup (fun m => F.exit m ω) (n+1))

/-- Explosion alternative in the positive-height domain: on finite lifetime
no compact subset can contain any final segment of the trajectory. The compact
set is quantified after the common conull event. -/
theorem Family.explosion_alternative (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ, F.lifetime ω ≠ ⊤ → ∀ K : Set State, IsCompact K →
      (∀ x ∈ K, 0 < x 0) → ∀ t : ℝ≥0, (t:WithTop ℝ≥0) < F.lifetime ω →
      ∃ s : ℝ≥0, t ≤ s ∧ (s:WithTop ℝ≥0) < F.lifetime ω ∧ F.process s ω ∉ K := by
  filter_upwards [F.exits_increase,F.exit_lt_lifetime,F.process_eq_before_exit] with ω hmono hstrict he
  intro hf K hK hKpos t ht
  obtain ⟨N,hN⟩ := compact_subset_gauge F.R hK hKpos
  obtain ⟨j,hj⟩ := (lt_iSup_iff.mp ht : ∃ j, (t:WithTop ℝ≥0) < F.exit j ω)
  let m := max (N+1) j
  have hm : N < m := (Nat.lt_succ_self N).trans_le (le_max_left _ _)
  have hmf : F.exit m ω ≠ ⊤ := ne_of_lt ((hstrict hf m).trans_le le_top)
  let s := (F.exit m ω).untopA
  have hs : (s:WithTop ℝ≥0) = F.exit m ω := by
    dsimp [s]; rw [WithTop.untopA_eq_untop hmf]; exact WithTop.coe_untop _ _
  refine ⟨s,WithTop.coe_le_coe.mp (hs.symm ▸ (hj.le.trans (hmono.1 (le_max_right _ _)))),
    hs.symm ▸ hstrict hf m,?_⟩
  intro hmem
  have hr : 0 < (N:ℝ)+F.R := by have := F.radius_gt; positivity
  have hrad : (N:ℝ)+F.R < (m:ℝ)+F.R := by
    have hnm : (N:ℝ) < (m:ℝ) := by exact_mod_cast hm
    linarith
  have hin := gauge_strict_nesting hr hrad (hN _ hmem).le
  have hb := GaugeExit.boundary_of_finite (F.continuous m) (gauge_continuous ((m:ℝ)+F.R)) ω hmf
  have hp := (he m s hs.le).1
  change F.process s ω = F.X m (F.exit m ω).untopA ω at hp
  rw [hp] at hin
  exact not_le.mpr hin hb

/-- A finite-lifetime trajectory has no continuous continuation through its
terminal time with positive height. This is a proved maximality property. -/
theorem Family.no_positive_continuous_extension (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ, ∀ z : ℝ≥0, F.lifetime ω = (z:WithTop ℝ≥0) →
      ¬ ∃ Z : ℝ≥0 → State, ContinuousOn Z (Icc 0 z) ∧
        (∀ t ∈ Icc 0 z, 0 < Z t 0) ∧
        ∀ t < z, Z t = F.process t ω := by
  filter_upwards [F.explosion_alternative] with ω hex
  intro z hz ⟨Z,hZc,hZpos,hZe⟩
  let K := Z '' Icc 0 z
  have hK : IsCompact K := isCompact_Icc.image_of_continuousOn hZc
  have hKpos : ∀ x ∈ K, 0 < x 0 := by
    rintro x ⟨t,ht,rfl⟩
    exact hZpos t ht
  obtain ⟨s,hs,hsz,hout⟩ := hex (hz ▸ WithTop.coe_ne_top) K hK hKpos 0
    (F.lifetime_positive ω)
  have hsz' : s < z := WithTop.coe_lt_coe.mp (hz ▸ hsz)
  apply hout
  rw [←hZe s hsz']
  exact mem_image_of_mem Z ⟨zero_le,hsz'.le⟩

/-- Both actual mechanical fields agree with the localized integrands along
the glued solution. -/
theorem Family.coefficients_before_exit (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ, ∀ n : ℕ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ F.exit n ω →
      (F.c n).drift t (F.Y n t ω) = a.drift (p t,F.process t ω) ∧
      (F.c n).diffusion t (F.Y n t ω) = a.diffusion (p t,F.process t ω) := by
  filter_upwards [F.process_eq_before_exit] with ω he
  intro n t ht
  have hb := (F.exit_properties n).2.2 t ω
  rw [stoppedProcess_eq_of_le ht] at hb
  rw [←(he n t ht).1] at hb
  rw [←(he n t ht).2]
  exact F.agrees n t _ hb

/-- Local mechanical stochastic integral equation on every integer horizon.
The diffusion integrand is predictable, bounded, and proved above to equal the
original singular diffusion before the genuine exit. -/
theorem Family.local_mechanical_equation (F : Family (μ:=μ) hBm a p x₀)
    (hB : IsPreBrownianReal B μ) (hBc : ∀ ω, Continuous (fun t => B t ω)) :
    ∀ᵐ ω ∂μ, ∀ n N : ℕ, ∀ t ∈ Icc 0 (N:ℝ≥0), (t:WithTop ℝ≥0) ≤ F.exit n ω → ∀ i : Fin 3,
      F.process t ω i = x₀ i + (∫ s in Ioc (0:ℝ≥0) t,
        a.drift (p s,F.process s ω) i ∂timeMeasure) +
        MathFin.ItoIntegralLocalised.predItoIntegral (μ:=μ) N hBm
          (diffusion_predictable hBm (F.c n) (F.strong n N).predictable i) t ω := by
  have hsol (n N : ℕ) := strong_solution_predIto_equation hB N hBm hBc (F.c n) x₀
    (F.strong n N) (F.bound n)
  filter_upwards [ae_all_iff.mpr (fun n => ae_all_iff.mpr (hsol n)),
    F.coefficients_before_exit,F.process_eq_before_exit] with ω he hc hp
  intro n N t ht hτ i
  have hi : (∫ s in Ioc (0:ℝ≥0) t, (F.c n).drift s (F.Y n s ω) i ∂timeMeasure) =
      ∫ s in Ioc (0:ℝ≥0) t, a.drift (p s,F.process s ω) i ∂timeMeasure := by
    apply setIntegral_congr_fun measurableSet_Ioc
    intro s hs
    exact congrFun (hc n s ((WithTop.coe_le_coe.mpr hs.2).trans hτ)).1 i
  rw [(hp n t hτ).2,←hi]
  exact he n N t ht i

end
end ChainFountainStochastic.CutoffExhaustion

namespace ChainFountainStochastic.CutoffExhaustion
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralProcessLocalMartingaleGeneral
open VectorSDE GlobalCutoffSDE MechanicalCutoff MechanicalExhaustion GlobalLocalization
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1000000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {hBm : ∀ t, Measurable (B t)} {a : Parameters} {p : ℝ≥0 → State} {x₀ : State}

/-- Comparison of two independently chosen cutoff exhaustions. -/
theorem Family.cross_prefix (F G : Family (μ:=μ) hBm a p x₀)
    (hB : IsPreBrownianReal B μ) (hBc : ∀ ω, Continuous (fun t => B t ω)) :
    ∀ᵐ ω ∂μ, ∀ n m : ℕ, (n:ℝ)+F.R < (m:ℝ)+G.R →
      F.exit n ω ≤ G.exit m ω ∧
      ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ F.exit n ω → F.X n t ω = G.X m t ω := by
  have hpair (n m : ℕ) : ∀ᵐ ω ∂μ, (n:ℝ)+F.R < (m:ℝ)+G.R →
      F.exit n ω ≤ G.exit m ω ∧
      ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ F.exit n ω → F.X n t ω = G.X m t ω := by
    by_cases hrad : (n:ℝ)+F.R < (m:ℝ)+G.R
    · have hn : 0 < (n:ℝ)+F.R := by have := F.radius_gt; positivity
      have hsub : ∀ x, |gauge ((n:ℝ)+F.R) x| ≤ 1 → |gauge ((m:ℝ)+G.R) x| < 1 :=
        fun x hx => gauge_strict_nesting hn hrad hx
      have hp := (gaugeExit_properties (G.adapted m) (G.continuous m)
        (gauge_continuous ((n:ℝ)+F.R)) (G.initial m)
        (radius_initial_inside F.radius_gt F.initial_inside n)).2.1
      have he := global_versions_stopped_eq hB hBm hBc (F.c n) (G.c m) x₀
        (F.bound n) (G.bound m) (F.strong n) (G.strong m) (F.adapted n) (G.adapted m)
        (F.continuous n) (G.continuous m) (F.initial n) (G.initial m) (F.version n) (G.version m)
        (gauge ((n:ℝ)+F.R)) (gauge_continuous _) (radius_initial_inside F.radius_gt F.initial_inside n)
        (fun t x hx => ⟨(F.agrees n t x hx).1.trans (G.agrees m t x (hsub x hx).le).1.symm,
          (F.agrees n t x hx).2.trans (G.agrees m t x (hsub x hx).le).2.symm⟩)
      filter_upwards [he] with ω hω _
      have horder := (GaugeExit.strict_mono (G.continuous m) (gauge_continuous _)
        (gauge_continuous _) hp hsub ω).1
      refine ⟨by change F.exit n ω ≤ G.exit m ω; exact hω.1.trans_le horder,?_⟩
      intro t ht
      change (t:WithTop ℝ≥0) ≤ gaugeExit (F.X n) (gauge ((n:ℝ)+F.R)) ω at ht
      have ht' := hω.1 ▸ ht
      simpa only [stoppedProcess_eq_of_le ht,stoppedProcess_eq_of_le ht'] using hω.2 t
    · exact ae_of_all _ (fun _ h => (hrad h).elim)
  exact ae_all_iff.mpr (fun n => ae_all_iff.mpr (hpair n))

/-- The maximal lifetime and the path before it are independent of the
initial radius, all coefficient extensions, and all chosen solution versions. -/
theorem Family.maximal_unique (F G : Family (μ:=μ) hBm a p x₀)
    (hB : IsPreBrownianReal B μ) (hBc : ∀ ω, Continuous (fun t => B t ω)) :
    ∀ᵐ ω ∂μ, F.lifetime ω = G.lifetime ω ∧
      ∀ t : ℝ≥0, (t:WithTop ℝ≥0) < F.lifetime ω → F.process t ω = G.process t ω := by
  filter_upwards [F.cross_prefix G hB hBc,G.cross_prefix F hB hBc,
    F.process_eq_before_exit,G.process_eq_before_exit] with ω hFG hGF hF hG
  have hle : F.lifetime ω ≤ G.lifetime ω := by
    apply iSup_le
    intro n
    obtain ⟨m,hm⟩ := exists_nat_gt ((n:ℝ)+F.R-G.R)
    exact (hFG n m (by linarith)).1.trans (le_iSup (fun m => G.exit m ω) m)
  have hge : G.lifetime ω ≤ F.lifetime ω := by
    apply iSup_le
    intro m
    obtain ⟨n,hn⟩ := exists_nat_gt ((m:ℝ)+G.R-F.R)
    exact (hGF m n (by linarith)).1.trans (le_iSup (fun n => F.exit n ω) n)
  refine ⟨le_antisymm hle hge,?_⟩
  intro t ht
  obtain ⟨n,hn⟩ := (lt_iSup_iff.mp ht : ∃ n, (t:WithTop ℝ≥0) < F.exit n ω)
  obtain ⟨m,hm⟩ := exists_nat_gt ((n:ℝ)+F.R-G.R)
  have hc := hFG n m (by linarith)
  exact (hF n t hn.le).1.trans ((hc.2 t hn.le).trans (hG m t (hn.le.trans hc.1)).1.symm)

/-- End-to-end existence for the original singular mechanical fields on
positive height. The family, process, stopping lifetime, local equations and
explosion alternative are all constructed from the model and initial data. -/
theorem exists_maximal_mechanical_solution
    (hB : IsPreBrownianReal B μ) (hBm : ∀ t, Measurable (B t))
    (hBc : ∀ ω, Continuous (fun t => B t ω))
    (a : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi : State) (hpmem : ∀ t, p t ∈ Icc plo phi)
    (x₀ : State) (hh : 0 < x₀ 0) :
    ∃ F : Family (μ:=μ) hBm a p x₀,
      IsStronglyPredictable (natFiltration hBm) F.process ∧
      (∀ ω, F.process 0 ω = x₀) ∧
      IsStoppingTime (augFiltration (μ:=μ) hBm) F.lifetime ∧
      (∀ ω, ⊥ < F.lifetime ω) ∧
      (∀ᵐ ω ∂μ, ContinuousOn (fun t => F.process t ω) {t | (t:WithTop ℝ≥0) < F.lifetime ω} ∧
        ∀ t : ℝ≥0, (t:WithTop ℝ≥0) < F.lifetime ω → 0 < F.process t ω 0) ∧
      (∀ᵐ ω ∂μ, F.lifetime ω ≠ ⊤ → ∀ K : Set State, IsCompact K →
        (∀ x ∈ K, 0 < x 0) → ∀ t : ℝ≥0, (t:WithTop ℝ≥0) < F.lifetime ω →
        ∃ s : ℝ≥0, t ≤ s ∧ (s:WithTop ℝ≥0) < F.lifetime ω ∧ F.process s ω ∉ K) ∧
      (∀ᵐ ω ∂μ, ∀ n N : ℕ, ∀ t ∈ Icc 0 (N:ℝ≥0), (t:WithTop ℝ≥0) ≤ F.exit n ω → ∀ i : Fin 3,
        F.process t ω i = x₀ i + (∫ s in Ioc (0:ℝ≥0) t,
          a.drift (p s,F.process s ω) i ∂timeMeasure) +
          MathFin.ItoIntegralLocalised.predItoIntegral (μ:=μ) N hBm
            (LocalIntegralBridge.diffusion_predictable hBm (F.c n) (F.strong n N).predictable i) t ω) ∧
      ∀ G : Family (μ:=μ) hBm a p x₀, ∀ᵐ ω ∂μ, F.lifetime ω = G.lifetime ω ∧
        ∀ t : ℝ≥0, (t:WithTop ℝ≥0) < F.lifetime ω → F.process t ω = G.process t ω := by
  obtain ⟨F⟩ := exists_family hB hBm hBc a p hp plo phi hpmem x₀ hh
  exact ⟨F,F.process_predictable,F.process_initial,F.lifetime_stopping,F.lifetime_positive,
    F.process_regular,F.explosion_alternative,F.local_mechanical_equation hB hBc,
    fun G => F.maximal_unique G hB hBc⟩

end
end ChainFountainStochastic.CutoffExhaustion

namespace ChainFountainStochastic.ConullBrownian
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralLocalised MathFin.LocalisationInMeasure
open MathFin.ItoIntegralRiemannBridge
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 800000
variable {Ω Ω' : Type*} {mΩ : MeasurableSpace Ω} {mΩ' : MeasurableSpace Ω'}
  {μ : Measure Ω} {ν : Measure Ω'}

/-- Extract an actual measurable conull subset of an almost-sure property.
No completeness of the ambient probability space is assumed. -/
theorem exists_measurable_conull {P : Ω → Prop} (hP : ∀ᵐ ω ∂μ, P ω) :
    ∃ G : Set Ω, MeasurableSet G ∧ (∀ᵐ ω ∂μ, ω ∈ G) ∧ ∀ ω ∈ G, P ω := by
  let N := toMeasurable μ {ω | ¬ P ω}
  have hN : μ N = 0 := by
    dsimp [N]
    rw [measure_toMeasurable]
    exact ae_iff.mp hP
  refine ⟨Nᶜ,(measurableSet_toMeasurable _ _).compl,?_,?_⟩
  · rw [ae_iff]
    change μ {a | ¬ a ∈ Nᶜ} = 0
    simpa only [mem_compl_iff,not_not,Set.setOf_mem_eq] using hN
  · intro ω hω
    by_contra hn
    exact hω (subset_toMeasurable μ {ω | ¬ P ω} hn)

/-- Restricting to a measurable conull subtype preserves the entire measure. -/
theorem conull_subtype_preserving {G : Set Ω} (hG : MeasurableSet G)
    (hGa : ∀ᵐ ω ∂μ, ω ∈ G) :
    MeasurePreserving ((↑) : G → Ω) (μ.comap ((↑) : G → Ω)) μ := by
  refine ⟨measurable_subtype_coe,?_⟩
  rw [map_comap_subtype_coe hG,Measure.restrict_eq_self_of_ae_mem hGa]

/-- Brownian finite-dimensional laws are preserved on a conull realization. -/
theorem preBrownian_pullback {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ)
    {f : Ω' → Ω} (hf : MeasurePreserving f ν μ) :
    IsPreBrownianReal (fun t ω => B t (f ω)) ν where
  hasLaw I := (hB.hasLaw I).comp hf.hasLaw

/-- Natural filtrations commute exactly with sample-space pullback. -/
theorem natFiltration_pullback {B : ℝ≥0 → Ω → ℝ} (hBm : ∀ t, Measurable (B t))
    {f : Ω' → Ω} (hf : Measurable f) (t : ℝ≥0) :
    natFiltration (fun s => (hBm s).comp hf) t = (natFiltration hBm t).comap f := by
  simp only [natFiltration,Filtration.natural,MeasurableSpace.comap_iSup,MeasurableSpace.comap_comp]

theorem adapted_pullback {E : Type*} [TopologicalSpace E]
    {B : ℝ≥0 → Ω → ℝ} (hBm : ∀ t, Measurable (B t)) {f : Ω' → Ω} (hf : Measurable f)
    {A : ℝ≥0 → Ω → E} (hA : StronglyAdapted (natFiltration hBm) A) :
    StronglyAdapted (natFiltration (fun s => (hBm s).comp hf)) (fun t ω => A t (f ω)) := by
  intro t
  have hfm : @Measurable Ω' Ω (natFiltration (fun s => (hBm s).comp hf) t) (natFiltration hBm t) f := by
    rw [measurable_iff_comap_le,natFiltration_pullback hBm hf t]
  exact (hA t).comp_measurable hfm

/-- Convergence in probability is unchanged by a measure-preserving embedding,
including restriction to a measurable conull subtype. -/
theorem tendstoInMeasure_pullback {f : Ω' → Ω} (hf : MeasurableEmbedding f)
    (hm : MeasurePreserving f ν μ) {E : Type*} [EDist E] {u : ℕ → Ω → E} {v : Ω → E}
    (hu : TendstoInMeasure μ u atTop v) :
    TendstoInMeasure ν (fun n ω => u n (f ω)) atTop (fun ω => v (f ω)) := by
  intro ε hε
  simpa only [←hm.map_eq,hf.map_apply,preimage_setOf_eq] using hu ε hε

/-- The localized predictable integral pulls back to the continuous-adapted
Itô integral once all paths of the integrand are continuous on the conull
realization. Equality holds simultaneously for all times on the horizon. -/
theorem predIto_pullback [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {f : Ω' → Ω} (hf : MeasurableEmbedding f) (hm : MeasurePreserving f ν μ)
    {A : ℝ≥0 → Ω → ℝ} (hA : IsStronglyPredictable (natFiltration hBm) A)
    (hAc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => A t ω) (Icc 0 T))
    (hAf : ∀ ω, Continuous (fun t => A t (f ω))) :
    ∀ᵐ ω ∂ν, ∀ t ∈ Icc 0 T,
      predItoIntegral (μ:=μ) T hBm hA t (f ω) =
        localItoIntegral (μ:=ν) T (fun s => (hBm s).comp hf.measurable)
          (adapted_pullback hBm hf.measurable hA.stronglyAdapted) hAf t ω := by
  have hB' := preBrownian_pullback hB hm
  have hBm' := fun s => (hBm s).comp hf.measurable
  have hBc' : ∀ ω, Continuous (fun t => B t (f ω)) := fun ω => hBc (f ω)
  have hA' := adapted_pullback hBm hf.measurable hA.stronglyAdapted
  apply ae_forall_eq_of_tendstoInMeasure
    (hm.quasiMeasurePreserving.tendsto_ae.eventually (ae_continuousOn_predItoIntegral hB T hBm hBc hA hAc))
    (ae_continuousOn_localItoIntegral hB' T hBm' hBc' hA' hAf)
    (fun t ht => tendstoInMeasure_pullback hf hm
      (tendstoInMeasure_riemannσ_predItoIntegral hB T hBm hBc hA hAc ht.2))
  intro t ht
  exact tendstoInMeasure_riemannσ_localItoIntegral hB' T hBm' hBc' hA' hAf ht.2

end
end ChainFountainStochastic.ConullBrownian

namespace ChainFountainStochastic.RegularRealization
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralLocalised MathFin.ItoFormulaAdapted MathFin.AdaptedDrift
open VectorSDE GlobalCutoffSDE MechanicalCutoff CutoffExhaustion LocalIntegralBridge ConullBrownian
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1000000
variable {Ω Ω' : Type*} {mΩ : MeasurableSpace Ω} {mΩ' : MeasurableSpace Ω'}
  {μ : Measure Ω} {ν : Measure Ω'} [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
  {B : ℝ≥0 → Ω → ℝ}

/-- The actual cutoff diffusion vanishes identically in the height and
fall-speed coordinates, including outside the region where the cutoff is inactive. -/
theorem cutoff_zero_diffusion {hBm : ∀ t, Measurable (B t)}
    {a : Parameters} {p : ℝ≥0 → State} {x₀ : State}
    (F : Family (μ:=μ) hBm a p x₀) (n : ℕ) (t : ℝ≥0) (x : State) :
    (F.c n).diffusion t x 0 = 0 ∧ (F.c n).diffusion t x 2 = 0 := by
  rw [F.clamped_diffusion]
  simp [Parameters.diffusion]

/-- The two non-diffusive coordinates of the constructed cutoff satisfy
ordinary integral equations globally on one event of probability one. -/
theorem finite_variation_equations {hBm : ∀ t, Measurable (B t)}
    (hB : IsPreBrownianReal B μ) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {a : Parameters} {p : ℝ≥0 → State} {x₀ : State}
    (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ, ∀ n : ℕ, ∀ t : ℝ≥0,
      F.Y n t ω 0 = x₀ 0 + driftPath (fun s ω => (F.c n).drift s (F.Y n s ω) 0) t ω ∧
      F.Y n t ω 2 = x₀ 2 + driftPath (fun s ω => (F.c n).drift s (F.Y n s ω) 2) t ω := by
  have he (n N : ℕ) : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 (N:ℝ≥0),
      F.Y n t ω 0 = x₀ 0 + driftPath (fun s ω => (F.c n).drift s (F.Y n s ω) 0) t ω ∧
      F.Y n t ω 2 = x₀ 2 + driftPath (fun s ω => (F.c n).drift s (F.Y n s ω) 2) t ω := by
    filter_upwards [strong_solution_finite_variation_coordinate hB N hBm hBc (F.c n) x₀
      (F.strong n N) (F.bound n) 0,
      strong_solution_finite_variation_coordinate hB N hBm hBc (F.c n) x₀
      (F.strong n N) (F.bound n) 2] with ω h0 h2
    intro t ht
    exact ⟨h0 t ht (fun s _ => (cutoff_zero_diffusion F n s _).1),
      h2 t ht (fun s _ => (cutoff_zero_diffusion F n s _).2)⟩
  filter_upwards [ae_all_iff.mpr (fun n => ae_all_iff.mpr (he n))] with ω hω
  intro n t
  obtain ⟨N,hN⟩ := exists_nat_ge t
  exact hω n N t ⟨zero_le,hN⟩

/-- A conull realization makes all cutoff state paths continuous and the two
finite-variation equations true on every sample path. This uses no new path
regularity assumption and leaves all probability laws unchanged. -/
theorem exists_regular_realization {hBm : ∀ t, Measurable (B t)}
    (hB : IsPreBrownianReal B μ) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {a : Parameters} {p : ℝ≥0 → State} {x₀ : State}
    (F : Family (μ:=μ) hBm a p x₀) :
    ∃ G : Set Ω, MeasurableSet G ∧ (∀ᵐ ω ∂μ, ω ∈ G) ∧
      ∀ ω ∈ G, ∀ n : ℕ, Continuous (fun t => F.Y n t ω) ∧
        ∀ t : ℝ≥0,
          F.Y n t ω 0 = x₀ 0 + driftPath (fun s ω => (F.c n).drift s (F.Y n s ω) 0) t ω ∧
          F.Y n t ω 2 = x₀ 2 + driftPath (fun s ω => (F.c n).drift s (F.Y n s ω) 2) t ω := by
  apply exists_measurable_conull
  filter_upwards [finite_variation_equations hB hBc F,
    ae_all_iff.mpr (fun n => global_strong_solution_continuous hBm (F.c n) x₀ (F.strong n))]
    with ω hFV hcont
  exact fun n => ⟨hcont n,hFV n⟩

/-- The constructed strong solution becomes exactly the continuous-adapted
Itô-process interface on a measure-preserving conull realization. The stochastic
integral identification is proved by common Riemann sums. -/
theorem strong_solution_pullback_equation
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients (Fin 3)) (x₀ : State) {Y : ℝ≥0 → Ω → State}
    (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    {f : Ω' → Ω} (hf : MeasurableEmbedding f) (hm : MeasurePreserving f ν μ)
    (hYf : ∀ ω, Continuous (fun t => Y t (f ω))) (i : Fin 3) :
    ∃ (ham : ∀ t, StronglyMeasurable[natFiltration (fun s => (hBm s).comp hf.measurable) t]
          (fun ω => c.diffusion t (Y t (f ω)) i))
      (hac : ∀ ω, Continuous (fun t => c.diffusion t (Y t (f ω)) i)),
      ∀ᵐ ω ∂ν, ∀ t ∈ Icc 0 T,
        Y t (f ω) i = localItoProcess (μ:=ν) T (fun s => (hBm s).comp hf.measurable)
          ham hac (x₀ i) (fun s ω => c.drift s (Y s (f ω)) i) t ω := by
  have ha := diffusion_predictable hBm c (hY T).predictable i
  have ham := adapted_pullback hBm hf.measurable ha.stronglyAdapted
  have hac : ∀ ω, Continuous (fun t => c.diffusion t (Y t (f ω)) i) := fun ω =>
    (continuous_apply i).comp (c.diffusion_continuous.comp (continuous_id.prodMk (hYf ω)))
  have hAc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => c.diffusion t (Y t ω) i) (Icc 0 T) := by
    filter_upwards [(hY T).continuous] with ω hω
    exact (continuous_apply i).comp_continuousOn
      (c.diffusion_continuous.comp_continuousOn (continuousOn_id.prodMk hω))
  refine ⟨ham,hac,?_⟩
  filter_upwards [hm.quasiMeasurePreserving.tendsto_ae.eventually
      (strong_solution_predIto_equation hB T hBm hBc c x₀ (hY T) hb),
    predIto_pullback hB T hBm hBc hf hm ha hAc hac] with ω he hi
  intro t ht
  simpa only [hi t ht,localItoProcess,driftPath] using he t ht i

end
end ChainFountainStochastic.RegularRealization

namespace ChainFountainStochastic
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory MathFin
open MathFin.ItoIntegralL2 MathFin.ItoFormulaAdapted
open MathFin.ItoIntegralProcessLocalMartingaleGeneral
open scoped NNReal Topology

/-- Quadratic energy decomposition for a general scalar Itô coordinate and a
finite-variation coordinate. Mechanical drift cancellation is applied only
inside the localization region, so no global physical equations are assumed. -/
theorem general_energy_ito
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {a b z : ℝ≥0 → Ω → ℝ} {e e' : ℝ → Ω → ℝ} {k₀ z₀ : ℝ}
    (ham : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hac : ∀ ω, Continuous (fun t => a t ω))
    (hbm : ∀ t, StronglyMeasurable[natFiltration hBm t] (b t))
    (hbc : ∀ ω, Continuous (fun t => b t ω))
    (hzc : ∀ ω, Continuous (fun t => z t ω))
    (he : ∀ ω t, 0 ≤ t → HasDerivAt (fun s => e s ω) (e' t ω) t)
    (hec : ∀ ω, Continuous (fun t : ℝ≥0 => e' t ω))
    (hSDE : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      z t ω = localItoProcess (μ:=μ) T hBm ham hac z₀ b t ω) :
    ∃ M : ℝ≥0 → Ω → ℝ,
      (∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
        trackingEnergy k₀ (e t ω) (z t ω) = trackingEnergy k₀ (e 0 ω) z₀ +
          (∫ s in Ioc 0 t, k₀*e s ω*e' s ω + z s ω*b s ω/4 + (a s ω)^2/8 ∂timeMeasure) + M t ω) ∧
      (∀ ω, Continuous (fun t => M t ω)) ∧
      IsLocalMartingale M (augFiltration (μ:=μ) hBm) μ := by
  obtain ⟨M,hM,hMc,hMl⟩ := quadratic_ito_localMartingale hB T hBm hBc ham hac hbm hbc z₀
  refine ⟨M,?_,hMc,hMl⟩
  filter_upwards [hM,hSDE] with ω hMω hZω t ht
  have hecn : Continuous (fun s : ℝ≥0 => e s ω) :=
    (show ContinuousOn (fun s : ℝ => e s ω) (Ici 0) from
      fun s hs => (he ω s hs).continuousAt.continuousWithinAt).comp_continuous
        NNReal.continuous_coe (fun s => s.coe_nonneg)
  have he'c : ContinuousOn (fun s : ℝ => e' s ω) (Icc 0 (t:ℝ)) := by
    apply ((hec ω).comp continuous_real_toNNReal).continuousOn.congr
    intro s hs
    simp only [Function.comp_apply, Real.coe_toNNReal s hs.1]
  have hE := finite_variation_energy (k:=k₀) (fun s hs => he ω s hs.1) he'c
  have hZ := hMω t ht
  rw [←hZω t ht] at hZ
  have hconv : (∫ s in Ioc 0 t, (localItoProcess (μ:=μ) T hBm ham hac z₀ b s ω)*b s ω/4 +
      (a s ω)^2/8 ∂timeMeasure) = ∫ s in Ioc 0 t, z s ω*b s ω/4 + (a s ω)^2/8 ∂timeMeasure := by
    apply setIntegral_congr_fun measurableSet_Ioc
    intro s hs
    dsimp only
    rw [←hZω s ⟨zero_le,hs.2.trans ht.2⟩]
  rw [hconv] at hZ
  have hi₁ : IntegrableOn (fun s : ℝ≥0 => k₀*e s ω*e' s ω) (Ioc 0 t) timeMeasure :=
    (((hecn.const_mul k₀).mul (hec ω)).continuousOn.integrableOn_compact isCompact_Icc).mono_set Ioc_subset_Icc_self
  have hi₂ : IntegrableOn (fun s : ℝ≥0 => z s ω*b s ω/4+(a s ω)^2/8) (Ioc 0 t) timeMeasure := by
    exact (((hzc ω).mul (hbc ω)).div_const 4 |>.add ((hac ω).pow 2 |>.div_const 8)).continuousOn.integrableOn_compact
      isCompact_Icc |>.mono_set Ioc_subset_Icc_self
  have hsum : (∫ s in Ioc 0 t, k₀*e s ω*e' s ω+z s ω*b s ω/4+(a s ω)^2/8 ∂timeMeasure) =
      (∫ s in Ioc 0 t, k₀*e s ω*e' s ω ∂timeMeasure)+
        ∫ s in Ioc 0 t, z s ω*b s ω/4+(a s ω)^2/8 ∂timeMeasure := by
    rw [←integral_add hi₁ hi₂]
    apply integral_congr_ae
    exact ae_of_all _ (fun _ => by ring)
  rw [hsum]
  dsimp [trackingEnergy]
  linarith

end
end ChainFountainStochastic

namespace ChainFountainStochastic.ConstructedEnergy
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory MathFin ChainFountain
open MathFin.ItoIntegralL2 MathFin.ItoFormulaAdapted MathFin.AdaptedDrift
open MathFin.ItoIntegralProcessLocalMartingaleGeneral
open VectorSDE GlobalCutoffSDE MechanicalCutoff CutoffExhaustion ConullBrownian RegularRealization
open scoped NNReal Topology
set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 2000000

def errorZ (a : Parameters) (p x : State) : ℝ :=
  x 1-x 2-2*p 1+2*a.k₁*(x 0-p 0)

def energy (a : Parameters) (p x : State) : ℝ :=
  trackingEnergy a.k₀ (x 0-p 0) (errorZ a p x)

def cutoffGenerator (a : Parameters) (p : ℝ≥0 → State)
    (c : Coefficients (Fin 3)) (t : ℝ≥0) (x : State) : ℝ :=
  a.k₀*(x 0-p t 0)*(c.drift t x 0-p t 1)+
    errorZ a (p t) x*(c.drift t x 1-c.drift t x 2-2*p t 2+
      2*a.k₁*(c.drift t x 0-p t 1))/4+(c.diffusion t x 1)^2/8

/-- The globally regular cutoff generator is the physical generator wherever
its coefficients agree with the mechanical system. -/
theorem cutoffGenerator_eq (a : Parameters) (p : ℝ≥0 → State)
    (c : Coefficients (Fin 3)) (t : ℝ≥0) (x : State)
    (hx : 0 < x 0)
    (hc : c.drift t x = a.drift (p t,x) ∧ c.diffusion t x = a.diffusion (p t,x)) :
    cutoffGenerator a p c t x = trackingGenerator a.k₀ a.k₁ a.k₂ a.κd a.noise
      (x 0-p t 0) (errorZ a (p t) x) ((x 1)^2/x 0) := by
  have hd := mechanical_error_drift a.H a.g a.α a.β a.k₀ a.k₁ a.k₂ a.κd
    (x 0) (x 1) (x 2) (p t 0) (p t 1) (p t 2) (ne_of_gt hx)
    (ne_of_gt (add_pos_of_nonneg_of_pos a.H_pos.le hx))
  have he : heightRate (x 1) (x 2)-p t 1 =
      -a.k₁*(x 0-p t 0)+errorZ a (p t) x/2 := by
    dsimp [heightRate,errorZ]; ring
  dsimp only [cutoffGenerator]
  rw [hc.1,hc.2]
  dsimp only [Parameters.drift,Parameters.diffusion]
  simp only [Matrix.cons_val_zero,Matrix.cons_val_one,Matrix.cons_val_two,Matrix.vecHead,Matrix.vecTail,Function.comp_apply,Fin.succ_zero_eq_one]
  rw [hd,he]
  dsimp [trackingGenerator,errorZ]
  ring

/-- A real-time finite-variation extension of a continuous NNReal drift. -/
def fvLift {Ω : Type*} (b : ℝ≥0 → Ω → ℝ) (x₀ : ℝ) (t : ℝ) (ω : Ω) :=
  x₀+∫ s in 0..t, b (Real.toNNReal s) ω

theorem fvLift_deriv {Ω : Type*} {b : ℝ≥0 → Ω → ℝ}
    (hb : ∀ ω, Continuous (fun t => b t ω)) (x₀ t : ℝ) (ω : Ω) :
    HasDerivAt (fun s => fvLift b x₀ s ω) (b (Real.toNNReal t) ω) t := by
  have hc := (hb ω).comp continuous_real_toNNReal
  simpa only [fvLift,zero_add,Function.comp_def,Pi.add_def] using (hasDerivAt_const t x₀).add
    (intervalIntegral.integral_hasDerivAt_right (hc.intervalIntegrable 0 t)
      hc.stronglyMeasurable.stronglyMeasurableAtFilter hc.continuousAt)

theorem fvLift_eq {Ω : Type*} (b : ℝ≥0 → Ω → ℝ) (x₀ : ℝ) (t : ℝ≥0) (ω : Ω) :
    fvLift b x₀ t ω = x₀+driftPath b t ω := by
  rw [fvLift,driftPath,timeMeasure_Ioc_eq_interval]

/-- Energy decomposition of an actual constructed cutoff solution on a
measure-preserving continuous realization. The transformed SDE, the finite
variation derivatives, and the Itô identity are all derived. -/
theorem cutoff_energy_ito
    {Ω Ω' : Type*} [MeasurableSpace Ω] [MeasurableSpace Ω']
    {μ : Measure Ω} {ν : Measure Ω'} [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (a : Parameters) (r : ℝ → State)
    (hp : Continuous (fun t : ℝ≥0 => r t))
    (dr : ∀ t, 0 ≤ t → HasDerivAt (fun s => r s 0) (r t 1) t)
    (dr₁ : ∀ t, 0 ≤ t → HasDerivAt (fun s => r s 1) (r t 2) t)
    (c : Coefficients (Fin 3)) (x₀ : State) {Y : ℝ≥0 → Ω → State}
    (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    {f : Ω' → Ω} (hf : MeasurableEmbedding f) (hm : MeasurePreserving f ν μ)
    (hYf : ∀ ω, Continuous (fun t => Y t (f ω)))
    (hFV : ∀ ω t,
      Y t (f ω) 0 = x₀ 0+driftPath (fun s ω => c.drift s (Y s (f ω)) 0) t ω ∧
      Y t (f ω) 2 = x₀ 2+driftPath (fun s ω => c.drift s (Y s (f ω)) 2) t ω) :
    ∃ M : ℝ≥0 → Ω' → ℝ,
      (∀ᵐ ω ∂ν, ∀ t ∈ Icc 0 T,
        energy a (r t) (Y t (f ω)) = energy a (r 0) x₀+
          (∫ s in Ioc 0 t, cutoffGenerator a (fun u => r u) c s (Y s (f ω)) ∂timeMeasure)+M t ω) ∧
      (∀ ω, Continuous (fun t => M t ω)) ∧
      IsLocalMartingale M (augFiltration (μ:=ν) (fun s => (hBm s).comp hf.measurable)) ν := by
  let X := fun t ω => Y t (f ω)
  let d := fun t ω => c.drift t (X t ω)
  have hdC (ω : Ω') : Continuous (fun t => d t ω) :=
    c.drift_continuous.comp (continuous_id.prodMk (hYf ω))
  have hd₀ (ω : Ω') : Continuous (fun t => d t ω 0) := (continuous_apply 0).comp (hdC ω)
  have hd₂ (ω : Ω') : Continuous (fun t => d t ω 2) := (continuous_apply 2).comp (hdC ω)
  have hXa := adapted_pullback hBm hf.measurable (hY 0).predictable.stronglyAdapted
  have hda t : StronglyMeasurable[natFiltration (fun s => (hBm s).comp hf.measurable) t] (d t) :=
    (c.drift_continuous.comp (continuous_const.prodMk continuous_id)).comp_stronglyMeasurable (hXa t)
  have hdai t i := (continuous_apply i).comp_stronglyMeasurable (hda t)
  let H := fvLift (fun t ω => d t ω 0) (x₀ 0)
  let W := fvLift (fun t ω => d t ω 2) (x₀ 2)
  have hH (t : ℝ≥0) ω : H t ω = X t ω 0 :=
    (fvLift_eq _ _ t ω).trans (hFV ω t).1.symm
  have hW (t : ℝ≥0) ω : W t ω = X t ω 2 :=
    (fvLift_eq _ _ t ω).trans (hFV ω t).2.symm
  let e := fun t ω => H t ω-r t 0
  let e' := fun t ω => d (Real.toNNReal t) ω 0-r t 1
  let q := fun t ω => -W t ω-2*r t 1+2*a.k₁*e t ω
  let q' := fun t ω => -d (Real.toNNReal t) ω 2-2*r t 2+2*a.k₁*e' t ω
  let z := fun (t : ℝ≥0) ω => X t ω 1+q t ω
  let b := fun (t : ℝ≥0) ω => d t ω 1+q' t ω
  have he ω t ht : HasDerivAt (fun s => e s ω) (e' t ω) t :=
    (fvLift_deriv hd₀ (x₀ 0) t ω).sub (dr t ht)
  have hq ω t ht : HasDerivAt (fun s => q s ω) (q' t ω) t :=
    (((fvLift_deriv hd₂ (x₀ 2) t ω).neg.sub ((dr₁ t ht).const_mul 2)).add
      ((he ω t ht).const_mul (2*a.k₁)))
  have he'C ω : Continuous (fun t : ℝ≥0 => e' t ω) := by
    simpa only [e',Real.toNNReal_coe,Function.comp_def,Pi.sub_def] using (hd₀ ω).sub ((continuous_apply 1).comp hp)
  have hqC ω : Continuous (fun t : ℝ≥0 => q' t ω) := by
    simpa only [q',Real.toNNReal_coe,Function.comp_def,Pi.sub_def,Pi.add_def,Pi.neg_def] using
      ((hd₂ ω).neg.sub (((continuous_apply 2).comp hp).const_mul 2)).add ((he'C ω).const_mul (2*a.k₁))
  have hzval t ω : z t ω = errorZ a (r t) (X t ω) := by
    dsimp only [z,q,e]
    rw [hH,hW]
    dsimp only [errorZ]; ring
  have hzC ω : Continuous (fun t => z t ω) := by
    have hx (i : Fin 3) : Continuous (fun t => X t ω i) := (continuous_apply i).comp (hYf ω)
    have hr (i : Fin 3) : Continuous (fun t : ℝ≥0 => r t i) := (continuous_apply i).comp hp
    simp_rw [hzval,errorZ]
    exact (((hx 1).sub (hx 2)).sub ((hr 1).const_mul 2)).add
      (((hx 0).sub (hr 0)).const_mul (2*a.k₁))
  have hbC ω : Continuous (fun t => b t ω) :=
    ((continuous_apply 1).comp (hdC ω)).add (hqC ω)
  have hba t : StronglyMeasurable[natFiltration (fun s => (hBm s).comp hf.measurable) t] (b t) := by
    dsimp only [b,q',e']
    simp only [Real.toNNReal_coe]
    fun_prop
  obtain ⟨ham,hac,hv⟩ := strong_solution_pullback_equation hB T hBm hBc c x₀ hY hb hf hm hYf 1
  have hq₀ ω : q 0 ω = -x₀ 2-2*r 0 1+2*a.k₁*(x₀ 0-r 0 0) := by
    simp [q,e,H,W,fvLift]
  have hqCc ω : ContinuousOn (fun t : ℝ => q' t ω) (Icc 0 (T:ℝ)) := by
    apply ((hqC ω).comp continuous_real_toNNReal).continuousOn.congr
    intro s hs
    simp only [Function.comp_apply,Real.coe_toNNReal s hs.1]
  have hz := ito_add_finite_variation T (fun s => (hBm s).comp hf.measurable) ham hac
    (fun ω => (continuous_apply 1).comp (hdC ω)) hq₀ (fun ω t ht => hq ω t ht.1) hqCc hv
  obtain ⟨M,hM,hMc,hMl⟩ := general_energy_ito (preBrownian_pullback hB hm) T
    (fun s => (hBm s).comp hf.measurable) (fun ω => hBc (f ω))
    ham hac hba hbC hzC he he'C hz
  refine ⟨M,?_,hMc,hMl⟩
  filter_upwards [hM] with ω hMω t ht
  have h := hMω t ht
  have hzin : x₀ 1+(-x₀ 2-2*r 0 1+2*a.k₁*(x₀ 0-r 0 0)) = errorZ a (r 0) x₀ := by
    dsimp only [errorZ]; ring
  have he₀ : e 0 ω = x₀ 0-r 0 0 := by simp [e,H,fvLift]
  rw [hzin,he₀,hzval] at h
  have hi : (∫ s in Ioc 0 t, a.k₀*e s ω*e' s ω+z s ω*b s ω/4+
      (c.diffusion s (Y s (f ω)) 1)^2/8 ∂timeMeasure) =
      ∫ s in Ioc 0 t, cutoffGenerator a (fun u => r u) c s (Y s (f ω)) ∂timeMeasure := by
    apply setIntegral_congr_fun measurableSet_Ioc
    intro s hs
    dsimp only [e]
    rw [hH,hzval]
    dsimp only [e',b,q',X,d,cutoffGenerator]
    simp only [Real.toNNReal_coe]
    ring
  rw [hi] at h
  simpa only [energy,e,hH,X] using h

end
end ChainFountainStochastic.ConstructedEnergy

namespace ChainFountainStochastic
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory MathFin
open MathFin.ItoIntegralL2 MathFin.AdaptedDrift
open scoped NNReal Topology

/-- A continuous adapted energy with a local-martingale decomposition obeys
Dynkin's dissipation estimate at any bounded positive stopping time. Only
bounds on the stopped prefix are needed. -/
theorem stopped_generator_expectation
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {ℱ : Filtration ℝ≥0 ‹MeasurableSpace Ω›} {T : ℝ≥0}
    {τ : Ω → WithTop ℝ≥0} (hτ : IsStoppingTime ℱ τ)
    (hτpos : ∀ ω, 0 < τ ω) (hτT : ∀ ω, τ ω ≤ (T:WithTop ℝ≥0))
    {V J M : ℝ≥0 → Ω → ℝ} {V₀ κ C CV CJ : ℝ}
    (hV : StronglyAdapted ℱ V) (hVc : ∀ ω, Continuous (fun t => V t ω))
    (hJ : StronglyAdapted ℱ J) (hJc : ∀ ω, Continuous (fun t => J t ω))
    (hV₀ : ∀ ω, V 0 ω=V₀) (hCV : 0≤ CV) (hCJ : 0≤ CJ)
    (hVB : ∀ t∈Icc 0 T, ∀ ω, (t:WithTop ℝ≥0)≤τ ω → ‖V t ω‖≤ CV)
    (hJB : ∀ t∈Icc 0 T, ∀ ω, (t:WithTop ℝ≥0)≤τ ω → ‖J t ω‖≤ CJ)
    (hgen : ∀ t∈Icc 0 T, ∀ ω, (t:WithTop ℝ≥0)≤τ ω → J t ω≤ -2*κ*V t ω+C)
    (hM : IsLocalMartingale M ℱ μ)
    (hIto : ∀ᵐ ω ∂μ, ∀ t∈Icc 0 T, V t ω=V₀+driftPath J t ω+M t ω)
    (t : ℝ≥0) :
    (∫ ω, stoppedProcess V τ t ω ∂μ)+
        2*κ*(∫ ω, stoppedProcess (driftPath V) τ t ω ∂μ)≤
      V₀+C*(∫ ω, stoppedProcess (fun (s:ℝ≥0) (_:Ω) => (s:ℝ)) τ t ω ∂μ) := by
  let residual := fun s ω => V s ω-V₀-driftPath J s ω
  have hRa : StronglyAdapted ℱ residual := fun s =>
    ((hV s).sub stronglyMeasurable_const).sub (continuous_drift_adapted hJ hJc s)
  have hRc : ∀ ω, Continuous (fun s => residual s ω) := fun ω =>
    ((hVc ω).sub continuous_const).sub (continuous_drift_paths hJc ω)
  have htime (s : ℝ≥0) (ω : Ω) :
      (min (s:WithTop ℝ≥0) (τ ω)).untopA≤ T ∧
      (((min (s:WithTop ℝ≥0) (τ ω)).untopA:ℝ≥0):WithTop ℝ≥0)≤τ ω := by
    exact ⟨WithTop.untopA_le ((min_le_right _ _).trans (hτT ω)),
      by rw [coe_untopA_min]; exact min_le_right _ _⟩
  have hJint (u : ℝ≥0) (ω : Ω) (huT : u≤ T) (hu : (u:WithTop ℝ≥0)≤τ ω) :
      |driftPath J u ω|≤ CJ*T := by
    apply (drift_prefix_bound u ω (fun s hs => ?_)).trans
      (mul_le_mul_of_nonneg_left (by exact_mod_cast huT) hCJ)
    exact (Real.norm_eq_abs _).symm.trans_le
      (hJB s ⟨zero_le,hs.2.trans huT⟩ ω ((WithTop.coe_le_coe.mpr hs.2).trans hu))
  have hVstop : ∀ s ω, ‖stoppedProcess V τ s ω‖≤ CV := by
    intro s ω
    exact hVB _ ⟨zero_le,(htime s ω).1⟩ ω
      (htime s ω).2
  have hIstop : ∀ s ω, ‖stoppedProcess (driftPath V) τ s ω‖≤ CV*T := by
    intro s ω
    rw [Real.norm_eq_abs]
    apply (drift_prefix_bound _ ω (fun q hq => ?_)).trans
      (mul_le_mul_of_nonneg_left (by exact_mod_cast (htime s ω).1) hCV)
    exact (Real.norm_eq_abs _).symm.trans_le
      (hVB q ⟨zero_le,hq.2.trans (htime s ω).1⟩ ω
        ((WithTop.coe_le_coe.mpr hq.2).trans (htime s ω).2))
  have hSstop : ∀ s ω, ‖stoppedProcess (fun (q:ℝ≥0) (_:Ω) => (q:ℝ)) τ s ω‖≤(T:ℝ) := by
    intro s ω
    simpa only [stoppedProcess,Real.norm_eq_abs,abs_of_nonneg (NNReal.coe_nonneg _)] using
      (show ((min (s:WithTop ℝ≥0) (τ ω)).untopA:ℝ)≤ T by exact_mod_cast (htime s ω).1)
  have hRstop : ∀ s ω, ‖stoppedProcess residual τ s ω‖≤ CV+|V₀|+CJ*T := by
    intro s ω
    let u := (min (s:WithTop ℝ≥0) (τ ω)).untopA
    have hvi := hVstop s ω
    have hji := hJint u ω (htime s ω).1 (htime s ω).2
    change ‖V u ω-V₀-driftPath J u ω‖≤ CV+|V₀|+CJ*T
    have hn₁ := norm_sub_le (V u ω-V₀) (driftPath J u ω)
    have hn₂ := norm_sub_le (V u ω) V₀
    simp only [Real.norm_eq_abs] at hn₁ hn₂ hvi ⊢
    change |V u ω|≤ CV at hvi
    linarith
  have heq : ∀ᵐ ω ∂μ, ∀ s∈Icc 0 T, M s ω=residual s ω := by
    filter_upwards [hIto] with ω hω s hs
    dsimp [residual]
    linarith [hω s hs]
  have hmart := bounded_stopped_residual_martingale hM hRa hRc heq hτ hτpos hτT hRstop
  have hR₀ (ω : Ω) : residual 0 ω=0 := by simp [residual,driftPath,hV₀]
  have hineq : ∀ᵐ ω ∂μ, ∀ s,
      stoppedProcess V τ s ω+2*κ*stoppedProcess (driftPath V) τ s ω≤
        V₀+C*stoppedProcess (fun (q:ℝ≥0) (_:Ω) => (q:ℝ)) τ s ω+stoppedProcess residual τ s ω := by
    apply Eventually.of_forall
    intro ω s
    have hi := drift_dissipation_prefix hVc hJc _ ω (fun q hq =>
      hgen q ⟨zero_le,hq.2.trans (htime s ω).1⟩ ω ((WithTop.coe_le_coe.mpr hq.2).trans (htime s ω).2))
    dsimp only [stoppedProcess,residual]
    linarith
  exact stopped_dissipation_expectation hτ hτpos hV hVc
    (continuous_drift_adapted hV hVc) (continuous_drift_paths hVc)
    (fun _ => stronglyMeasurable_const) (fun _ => NNReal.continuous_coe)
    hVstop hIstop hSstop hmart hR₀ hineq t

end
end ChainFountainStochastic

namespace ChainFountainStochastic.ConstructedEnergy
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory MathFin ChainFountain
open MathFin.ItoIntegralL2 MathFin.ItoFormulaAdapted MathFin.AdaptedDrift
open MathFin.ItoIntegralProcessLocalMartingaleGeneral
open VectorSDE GlobalCutoffSDE MechanicalCutoff CutoffExhaustion ConullBrownian RegularRealization
open GlobalLocalization MechanicalExhaustion
open scoped NNReal Topology
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 200000


/-- A compact exhaustion level gives an explicit physical diffusion bound. -/
theorem noise_bound {ρ : ℝ} (hρ : 0 < ρ) {x : State} (hx : |gauge ρ x| ≤ 1) :
    |(x 1)^2/x 0| ≤ ρ^3 := by
  obtain ⟨hn,hh⟩ := (gauge_le_iff hρ x).mp hx
  have hheight := height_pos_of_gauge_le hρ hx
  have hv : |x 1| ≤ ρ := (norm_le_pi_norm x 1).trans hn
  have hv2 : (x 1)^2 ≤ ρ^2 := by
    simpa only [sq_abs] using (sq_le_sq₀ (abs_nonneg (x 1)) hρ.le).mpr hv
  rw [abs_of_nonneg (div_nonneg (sq_nonneg _) hheight.le),div_le_iff₀ hheight]
  have hm := mul_le_mul_of_nonneg_left hh (sq_nonneg ρ)
  nlinarith

theorem energy_continuous (a : Parameters) : Continuous (fun y : State × State => energy a y.1 y.2) := by
  unfold energy trackingEnergy errorZ
  fun_prop

theorem cutoffGenerator_continuous (a : Parameters) (p : ℝ≥0 → State)
    (hp : Continuous p) (c : Coefficients (Fin 3)) :
    Continuous (fun y : ℝ≥0 × State => cutoffGenerator a p c y.1 y.2) := by
  have hd := c.drift_continuous
  have hs := c.diffusion_continuous
  unfold cutoffGenerator errorZ
  fun_prop

/-- The Dynkin dissipation estimate for the actually constructed cutoff SDE.
No energy identity, martingale compensator, or random trajectory is supplied:
all of them are derived from its strong solution and finite-variation coordinates. -/
theorem cutoff_energy_expectation
    {Ω Ω' : Type*} [MeasurableSpace Ω] [MeasurableSpace Ω']
    {μ : Measure Ω} {ν : Measure Ω'} [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hT : 0 < T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (a : Parameters) (r : ℝ → State)
    (hp : Continuous (fun t : ℝ≥0 => r t))
    (dr : ∀ t, 0 ≤ t → HasDerivAt (fun s => r s 0) (r t 1) t)
    (dr₁ : ∀ t, 0 ≤ t → HasDerivAt (fun s => r s 1) (r t 2) t)
    (c : Coefficients (Fin 3)) (x₀ : State) {Y : ℝ≥0 → Ω → State}
    (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    {f : Ω' → Ω} (hf : MeasurableEmbedding f) (hm : MeasurePreserving f ν μ)
    (hYf : ∀ ω, Continuous (fun t => Y t (f ω)))
    (hFV : ∀ ω t,
      Y t (f ω) 0 = x₀ 0+driftPath (fun s ω => c.drift s (Y s (f ω)) 0) t ω ∧
      Y t (f ω) 2 = x₀ 2+driftPath (fun s ω => c.drift s (Y s (f ω)) 2) t ω)
    {ρ κ : ℝ} (hρ : 0 < ρ) (hi : |gauge ρ x₀| < 1)
    (hc : ∀ t x, |gauge ρ x| ≤ 1 →
      c.drift t x = a.drift (r t,x) ∧ c.diffusion t x = a.diffusion (r t,x))
    (hk₀ : 0 ≤ a.k₀) (hk₁ : 0 ≤ a.k₁) (hk₂ : 0 ≤ a.k₂) (hκd : 0 ≤ a.κd)
    (hκ₁ : κ ≤ a.k₁) (hκ₂ : κ ≤ a.k₂) (t : ℝ≥0) :
    let X := fun t ω => Y t (f ω)
    let V := fun (t : ℝ≥0) ω => energy a (r t) (X t ω)
    let τ := fun ω => min (gaugeExit X (gauge ρ) ω) (T:WithTop ℝ≥0)
    (∫ ω, stoppedProcess V τ t ω ∂ν)+
      2*κ*(∫ ω, stoppedProcess (driftPath V) τ t ω ∂ν) ≤
      energy a (r 0) x₀+(a.noise^2*(ρ^3)^2/8)*
        (∫ ω, stoppedProcess (fun (s:ℝ≥0) (_:Ω') => (s:ℝ)) τ t ω ∂ν) := by
  let X := fun t ω => Y t (f ω)
  let V := fun (t : ℝ≥0) ω => energy a (r t) (X t ω)
  let J := fun (t : ℝ≥0) ω => cutoffGenerator a (fun u => r u) c t (X t ω)
  let τ := fun ω => min (gaugeExit X (gauge ρ) ω) (T:WithTop ℝ≥0)
  change (∫ ω, stoppedProcess V τ t ω ∂ν)+2*κ*(∫ ω, stoppedProcess (driftPath V) τ t ω ∂ν) ≤ _
  let ℱ := augFiltration (μ:=ν) (fun s => (hBm s).comp hf.measurable)
  have hXa : StronglyAdapted ℱ X := fun s =>
    (adapted_pullback hBm hf.measurable (hY 0).predictable.stronglyAdapted s).mono
      (show _ ≤ ℱ s from le_sup_left)
  have hX₀ ω : X 0 ω = x₀ := (hY 0).initial (f ω)
  obtain ⟨he,hep,heb⟩ := gaugeExit_properties hXa hYf (gauge_continuous ρ) hX₀ hi
  have hτ : IsStoppingTime ℱ τ := he.min (isStoppingTime_const ℱ T)
  have hτpos ω : 0 < τ ω := lt_min (hep ω) (WithTop.coe_lt_coe.mpr hT)
  have hτT ω : τ ω ≤ (T:WithTop ℝ≥0) := min_le_right _ _
  have hin (s : ℝ≥0) ω (hs : (s:WithTop ℝ≥0) ≤ τ ω) : |gauge ρ (X s ω)| ≤ 1 := by
    have hb' := heb s ω
    rw [stoppedProcess_eq_of_le (hs.trans (min_le_left _ _))] at hb'
    exact hb'
  have hVc ω : Continuous (fun s => V s ω) :=
    (energy_continuous a).comp (hp.prodMk (hYf ω))
  have hVa : StronglyAdapted ℱ V := fun s =>
    ((energy_continuous a).comp (continuous_const.prodMk continuous_id)).comp_stronglyMeasurable (hXa s)
  have hJc ω : Continuous (fun s => J s ω) :=
    (cutoffGenerator_continuous a _ hp c).comp (continuous_id.prodMk (hYf ω))
  have hJa : StronglyAdapted ℱ J := fun s =>
    ((cutoffGenerator_continuous a _ hp c).comp (continuous_const.prodMk continuous_id)).comp_stronglyMeasurable (hXa s)
  have hV₀ ω : V 0 ω = energy a (r 0) x₀ := by dsimp [V]; rw [hX₀]
  have hcont : Continuous (fun y : ℝ≥0 × State => |energy a (r y.1) y.2|) :=
    ((energy_continuous a).comp ((hp.comp continuous_fst).prodMk continuous_snd)).abs
  obtain ⟨D,hD⟩ := ((isCompact_Icc : IsCompact (Icc (0:ℝ≥0) T)).prod (gauge_sublevel_compact hρ)).bddAbove_image hcont.continuousOn
  let CV := max 0 D
  have hCV : 0 ≤ CV := le_max_left _ _
  have hVB s (hs : s ∈ Icc 0 T) ω (hsτ : (s:WithTop ℝ≥0) ≤ τ ω) : ‖V s ω‖ ≤ CV := by
    rw [Real.norm_eq_abs]
    apply le_trans (hD (show |energy a (r s) (X s ω)| ∈ _ from
      ⟨(s,X s ω),⟨hs,hin s ω hsτ⟩,rfl⟩))
    exact le_max_right _ _
  let CJ := 2*(a.k₁+a.k₂+a.κd*(ρ^3)^2)*CV+a.noise^2*(ρ^3)^2/8
  have hCJ : 0 ≤ CJ := by dsimp [CJ]; positivity
  have hJid (s : ℝ≥0) ω (hsτ : (s:WithTop ℝ≥0) ≤ τ ω) : J s ω =
      trackingGenerator a.k₀ a.k₁ a.k₂ a.κd a.noise (X s ω 0-r s 0)
        (errorZ a (r s) (X s ω)) ((X s ω 1)^2/X s ω 0) :=
    cutoffGenerator_eq a _ c s _ (height_pos_of_gauge_le hρ (hin s ω hsτ)) (hc s _ (hin s ω hsτ))
  have hJB s (hs : s ∈ Icc 0 T) ω (hsτ : (s:WithTop ℝ≥0) ≤ τ ω) : ‖J s ω‖ ≤ CJ := by
    rw [Real.norm_eq_abs,hJid s ω hsτ]
    exact tracking_generator_abs_le hk₀ hk₁ hk₂ hκd
      ((le_abs_self _).trans ((Real.norm_eq_abs _).symm.trans_le (hVB s hs ω hsτ)))
      (noise_bound hρ (hin s ω hsτ))
  have hgen s (_ : s ∈ Icc 0 T) ω (hsτ : (s:WithTop ℝ≥0) ≤ τ ω) :
      J s ω ≤ -2*κ*V s ω+a.noise^2*(ρ^3)^2/8 := by
    rw [hJid s ω hsτ]
    exact tracking_generator_le hk₀ hκ₁ hκ₂ hκd (noise_bound hρ (hin s ω hsτ))
  obtain ⟨M,hIto,hMc,hMl⟩ := cutoff_energy_ito hB T hBm hBc a r hp dr dr₁ c x₀ hY hb hf hm hYf hFV
  exact stopped_generator_expectation hτ hτpos hτT hVa hVc hJa hJc hV₀ hCV hCJ
    hVB hJB hgen hMl hIto t

end
end ChainFountainStochastic.ConstructedEnergy

namespace ChainFountainStochastic.CutoffExhaustion
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory MathFin ChainFountain
open MathFin.ItoIntegralL2 MathFin.ItoFormulaAdapted MathFin.AdaptedDrift
open VectorSDE GlobalCutoffSDE MechanicalCutoff ConullBrownian RegularRealization
open ConstructedEnergy GlobalLocalization MechanicalExhaustion
open scoped NNReal Topology
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1500000
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
  {B : ℝ≥0 → Ω → ℝ}

/-- The energy estimate holds on the ORIGINAL probability space for every
member of the constructed compact exhaustion. Its continuous realization,
Itô decomposition and martingale expectation are all proved, not assumed. -/
theorem Family.stopped_energy_expectation
    {hBm : ∀ t, Measurable (B t)}
    (hB : IsPreBrownianReal B μ) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {a : Parameters} {r : ℝ → State} {x₀ : State}
    (F : Family (μ:=μ) hBm a (fun t => r t) x₀)
    (hp : Continuous (fun t : ℝ≥0 => r t))
    (dr : ∀ t, 0 ≤ t → HasDerivAt (fun s => r s 0) (r t 1) t)
    (dr₁ : ∀ t, 0 ≤ t → HasDerivAt (fun s => r s 1) (r t 2) t)
    {κ : ℝ} (hk₀ : 0 ≤ a.k₀) (hk₁ : 0 ≤ a.k₁) (hk₂ : 0 ≤ a.k₂) (hκd : 0 ≤ a.κd)
    (hκ₁ : κ ≤ a.k₁) (hκ₂ : κ ≤ a.k₂)
    (n : ℕ) (T : ℝ≥0) (hT : 0 < T) (t : ℝ≥0) :
    let V := fun (s : ℝ≥0) ω => energy a (r s) (F.X n s ω)
    let τ := fun ω => min (F.exit n ω) (T:WithTop ℝ≥0)
    (∫ ω, stoppedProcess V τ t ω ∂μ)+
      2*κ*(∫ ω, stoppedProcess (driftPath V) τ t ω ∂μ) ≤
      energy a (r 0) x₀+(a.noise^2*(((n:ℝ)+F.R)^3)^2/8)*
        (∫ ω, stoppedProcess (fun (s:ℝ≥0) (_:Ω) => (s:ℝ)) τ t ω ∂μ) := by
  obtain ⟨G,hG,hGa,hgood⟩ := exists_measurable_conull (by
    filter_upwards [finite_variation_equations hB hBc F,
      ae_all_iff.mpr (fun n => global_strong_solution_continuous hBm (F.c n) x₀ (F.strong n)),
      ae_all_iff.mpr F.version] with ω hfv hcont hver
    exact show ∀ n : ℕ, Continuous (fun t => F.Y n t ω) ∧
      (∀ t, F.Y n t ω 0 = x₀ 0+driftPath (fun s ω => (F.c n).drift s (F.Y n s ω) 0) t ω ∧
        F.Y n t ω 2 = x₀ 2+driftPath (fun s ω => (F.c n).drift s (F.Y n s ω) 2) t ω) ∧
      (∀ t, F.X n t ω = F.Y n t ω) from fun n => ⟨hcont n,hfv n,hver n⟩)
  let ν := μ.comap ((↑) : G → Ω)
  have hm : MeasurePreserving ((↑) : G → Ω) ν μ := conull_subtype_preserving hG hGa
  letI : IsProbabilityMeasure ν := hm.hasLaw.isProbabilityMeasure
  have hf : MeasurableEmbedding ((↑) : G → Ω) := MeasurableEmbedding.subtype_coe hG
  have hcont (ω : G) : Continuous (fun s => F.Y n s ω.val) := (hgood ω.val ω.property n).1
  have hfv (ω : G) (s : ℝ≥0) := (hgood ω.val ω.property n).2.1 s
  have hv (ω : G) (s : ℝ≥0) : F.Y n s ω.val = F.X n s ω.val :=
    ((hgood ω.val ω.property n).2.2 s).symm
  have hρ : 0 < (n:ℝ)+F.R := by have := F.radius_gt; positivity
  have hi := radius_initial_inside F.radius_gt F.initial_inside n
  have he := cutoff_energy_expectation hB T hT hBm hBc a r hp dr dr₁ (F.c n) x₀
    (F.strong n) (F.bound n) hf hm hcont hfv hρ hi (F.agrees n)
    hk₀ hk₁ hk₂ hκd hκ₁ hκ₂ t
  have hX : (fun s (ω : G) => F.Y n s ω.val) = (fun s (ω : G) => F.X n s ω.val) :=
    funext (fun s => funext (fun ω => hv ω s))
  dsimp only at he ⊢
  rw [hX] at he
  have hex (ω : G) : gaugeExit (fun s (ω : G) => F.X n s ω.val)
      (gauge ((n:ℝ)+F.R)) ω = F.exit n ω.val := rfl
  simp_rw [hex] at he
  simp only [stoppedProcess,driftPath] at he ⊢
  simp_rw [hv] at he
  let u := fun (ω : Ω) => (min (t:WithTop ℝ≥0) (min (F.exit n ω) (T:WithTop ℝ≥0))).untopA
  have h₁ := hm.integral_comp hf (fun ω => energy a (r (u ω)) (F.X n (u ω) ω))
  have h₂ := hm.integral_comp hf (fun ω => ∫ s in Ioc 0 (u ω), energy a (r s) (F.X n s ω) ∂timeMeasure)
  have h₃ := hm.integral_comp hf (fun ω => (u ω:ℝ))
  dsimp only [u] at h₁ h₂ h₃
  rw [h₁,h₂,h₃] at he
  exact he

/-- The same estimate applies to the maximal process stopped at each
constructed exhaustion exit. No extension beyond its random lifetime enters
the estimate. -/
theorem Family.maximal_stopped_energy_expectation
    {hBm : ∀ t, Measurable (B t)}
    (hB : IsPreBrownianReal B μ) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {a : Parameters} {r : ℝ → State} {x₀ : State}
    (F : Family (μ:=μ) hBm a (fun t => r t) x₀)
    (hp : Continuous (fun t : ℝ≥0 => r t))
    (dr : ∀ t, 0 ≤ t → HasDerivAt (fun s => r s 0) (r t 1) t)
    (dr₁ : ∀ t, 0 ≤ t → HasDerivAt (fun s => r s 1) (r t 2) t)
    {κ : ℝ} (hk₀ : 0 ≤ a.k₀) (hk₁ : 0 ≤ a.k₁) (hk₂ : 0 ≤ a.k₂) (hκd : 0 ≤ a.κd)
    (hκ₁ : κ ≤ a.k₁) (hκ₂ : κ ≤ a.k₂)
    (n : ℕ) (T : ℝ≥0) (hT : 0 < T) (t : ℝ≥0) :
    let V := fun (s : ℝ≥0) ω => energy a (r s) (F.process s ω)
    let τ := fun ω => min (F.exit n ω) (T:WithTop ℝ≥0)
    (∫ ω, stoppedProcess V τ t ω ∂μ)+
      2*κ*(∫ ω, stoppedProcess (driftPath V) τ t ω ∂μ) ≤
      energy a (r 0) x₀+(a.noise^2*(((n:ℝ)+F.R)^3)^2/8)*
        (∫ ω, stoppedProcess (fun (s:ℝ≥0) (_:Ω) => (s:ℝ)) τ t ω ∂μ) := by
  have he := F.stopped_energy_expectation hB hBc hp dr dr₁ hk₀ hk₁ hk₂ hκd hκ₁ hκ₂ n T hT t
  let τ := fun ω => min (F.exit n ω) (T:WithTop ℝ≥0)
  have htime ω : (((min (t:WithTop ℝ≥0) (τ ω)).untopA:ℝ≥0):WithTop ℝ≥0) ≤ F.exit n ω := by
    rw [coe_untopA_min]
    exact (min_le_right _ _).trans (min_le_left _ _)
  have hV : (∫ ω, stoppedProcess (fun (s:ℝ≥0) ω => energy a (r s) (F.process s ω)) τ t ω ∂μ) =
      ∫ ω, stoppedProcess (fun (s:ℝ≥0) ω => energy a (r s) (F.X n s ω)) τ t ω ∂μ := by
    apply integral_congr_ae
    filter_upwards [F.process_eq_before_exit] with ω hω
    dsimp only [stoppedProcess]
    rw [(hω n _ (htime ω)).1]
  have hI : (∫ ω, stoppedProcess (driftPath (fun (s:ℝ≥0) ω => energy a (r s) (F.process s ω))) τ t ω ∂μ) =
      ∫ ω, stoppedProcess (driftPath (fun (s:ℝ≥0) ω => energy a (r s) (F.X n s ω))) τ t ω ∂μ := by
    apply integral_congr_ae
    filter_upwards [F.process_eq_before_exit] with ω hω
    dsimp only [stoppedProcess,driftPath]
    apply setIntegral_congr_fun measurableSet_Ioc
    intro s hs
    dsimp only
    rw [(hω n s ((WithTop.coe_le_coe.mpr hs.2).trans (htime ω))).1]
  dsimp only at he ⊢
  rw [hV,hI]
  exact he

/-- End-to-end construction from model data: a predictable maximal local
solution with positive stopping lifetime, explosion alternative, and the
stopped energy estimate for every compact-exhaustion level and horizon. -/
theorem exists_maximal_solution_with_stopped_energy
    (hB : IsPreBrownianReal B μ) (hBm : ∀ t, Measurable (B t))
    (hBc : ∀ ω, Continuous (fun t => B t ω))
    (a : Parameters) (r : ℝ → State)
    (hp : Continuous (fun t : ℝ≥0 => r t))
    (dr : ∀ t, 0 ≤ t → HasDerivAt (fun s => r s 0) (r t 1) t)
    (dr₁ : ∀ t, 0 ≤ t → HasDerivAt (fun s => r s 1) (r t 2) t)
    (plo phi : State) (hpmem : ∀ t : ℝ≥0, r t ∈ Icc plo phi)
    (x₀ : State) (hh : 0 < x₀ 0)
    {κ : ℝ} (hk₀ : 0 ≤ a.k₀) (hk₁ : 0 ≤ a.k₁) (hk₂ : 0 ≤ a.k₂) (hκd : 0 ≤ a.κd)
    (hκ₁ : κ ≤ a.k₁) (hκ₂ : κ ≤ a.k₂) :
    ∃ F : Family (μ:=μ) hBm a (fun t => r t) x₀,
      IsStronglyPredictable (natFiltration hBm) F.process ∧
      IsStoppingTime (MathFin.ItoIntegralProcessLocalMartingaleGeneral.augFiltration (μ:=μ) hBm) F.lifetime ∧
      (∀ ω, 0 < F.lifetime ω) ∧
      (∀ᵐ ω ∂μ, F.lifetime ω ≠ ⊤ → ∀ K : Set State, IsCompact K →
        (∀ x ∈ K, 0 < x 0) → ∀ t : ℝ≥0, (t:WithTop ℝ≥0) < F.lifetime ω →
        ∃ s : ℝ≥0, t ≤ s ∧ (s:WithTop ℝ≥0) < F.lifetime ω ∧ F.process s ω ∉ K) ∧
      ∀ (n : ℕ) (T : ℝ≥0), 0 < T → ∀ t : ℝ≥0,
        let V := fun (s : ℝ≥0) ω => energy a (r s) (F.process s ω)
        let τ := fun ω => min (F.exit n ω) (T:WithTop ℝ≥0)
        (∫ ω, stoppedProcess V τ t ω ∂μ)+
          2*κ*(∫ ω, stoppedProcess (driftPath V) τ t ω ∂μ) ≤
          energy a (r 0) x₀+(a.noise^2*(((n:ℝ)+F.R)^3)^2/8)*
            (∫ ω, stoppedProcess (fun (s:ℝ≥0) (_:Ω) => (s:ℝ)) τ t ω ∂μ) := by
  obtain ⟨F⟩ := exists_family hB hBm hBc a (fun t => r t) hp plo phi hpmem x₀ hh
  exact ⟨F,F.process_predictable,F.lifetime_stopping,F.lifetime_positive,F.explosion_alternative,
    fun n T hT t => F.maximal_stopped_energy_expectation hB hBc hp dr dr₁
      hk₀ hk₁ hk₂ hκd hκ₁ hκ₂ n T hT t⟩

end
end ChainFountainStochastic.CutoffExhaustion


namespace ChainFountainStochastic.BrownianMaximal
noncomputable section
open MeasureTheory ProbabilityTheory Real Filter Set
open scoped NNReal ENNReal
set_option maxHeartbeats 600000
set_option backward.isDefEq.respectTransparency true
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {P : Measure Ω}
  {X : ℝ≥0 → Ω → ℝ}

/-- The Wald exponential has expectation one at each deterministic time. -/
theorem wald_integral (hX : IsPreBrownianReal X P) (θ : ℝ) (T : ℝ≥0) :
    ∫ ω, exp (θ * X T ω - θ^2 * (T : ℝ) / 2) ∂P = 1 := by
  simp_rw [exp_sub, div_eq_mul_inv]
  rw [integral_mul_const]
  have h := (hX.hasLaw_eval T).integral_comp
    (show AEStronglyMeasurable (fun x : ℝ => exp (θ*x)) (gaussianReal 0 T) from
      (by fun_prop : Continuous (fun x : ℝ => exp (θ*x))).aestronglyMeasurable)
  change (∫ ω, exp (θ * X T ω) ∂P) * (exp (θ^2 * (T:ℝ) * 2⁻¹))⁻¹ = 1
  dsimp only [Function.comp_def] at h
  rw [h, integral_exp_mul_gaussianReal_zero]
  simp [div_eq_mul_inv, exp_ne_zero]

/-- Exponential maximal bound, obtained from the Wald martingale and Doob's
maximal inequality. This proof does not use a reflection principle. -/
theorem maximal_exponential (hX : IsPreBrownianReal X P)
    (hm : ∀ t, Measurable (X t)) (hc : ∀ ω, Continuous (X · ω))
    (T : ℝ≥0) (a θ : ℝ) (hθ : 0 ≤ θ) :
    P.real {ω | (a : EReal) ≤ ⨆ s ≤ T, (X s ω : EReal)} ≤
      exp (-θ*a + θ^2 * (T:ℝ)/2) := by
  haveI := (hX.hasLaw ∅).isProbabilityMeasure
  letI := hX.isFilteredPreBrownian hm
  let W := fun t ω => exp (θ * X t ω - θ^2 * (t:ℝ)/2)
  have hw : Martingale W (Filtration.natural X (fun t => (hm t).stronglyMeasurable)) P :=
    IsFilteredPreBrownian.waldExponential_isMartingale θ
  have hwc : ∀ ω, Continuous (W · ω) := fun ω => by dsimp [W]; fun_prop
  let ε := exp (θ*a - θ^2*(T:ℝ)/2)
  have hmax := maximal_ineq hw.submartingale
    (show 0 ≤ W from fun t ω => (exp_pos _).le) ε T
    (fun ω => (hwc ω).isRightContinuous)
  have htotal : ∫ ω, W T ω ∂P = 1 := wald_integral hX θ T
  have hbound : ε * P.real {ω | ε ≤ ⨆ s : Iic T, W s ω} ≤ 1 :=
    hmax.trans ((setIntegral_le_integral (hw.integrable T)
      (ae_of_all _ fun ω => (exp_pos _).le)).trans_eq htotal)
  have hsub : {ω | (a : EReal) ≤ ⨆ s ≤ T, (X s ω : EReal)} ⊆
      {ω | ε ≤ ⨆ s : Iic T, W s ω} := by
    intro ω hω
    obtain ⟨s, hs, hsm⟩ := isCompact_Icc.exists_isMaxOn
      (nonempty_Icc.mpr (show (0:ℝ≥0) ≤ T from bot_le)) (hc ω).continuousOn
    have ha : a ≤ X s ω := by
      apply EReal.coe_le_coe_iff.mp
      exact hω.trans (iSup_le fun (u : ℝ≥0) => iSup_le fun (hu : u ≤ T) =>
        EReal.coe_le_coe (hsm ⟨bot_le,hu⟩))
    have hb : BddAbove (range fun s : Iic T => W s ω) := by
      have he : range (fun s : Iic T => W s ω) = (W · ω) '' Icc 0 T := by
        ext y; simp only [mem_range,mem_image,mem_Icc]
        constructor
        · rintro ⟨u,rfl⟩; exact ⟨u,⟨bot_le,u.property⟩,rfl⟩
        · rintro ⟨u,hu,rfl⟩; exact ⟨⟨u,hu.2⟩,rfl⟩
      rw [he]
      exact (isCompact_Icc.image (hwc ω)).bddAbove
    apply le_trans (b := W s ω) _ (le_ciSup hb ⟨s,hs.2⟩)
    apply exp_le_exp.mpr
    have ht : (s:ℝ) ≤ T := hs.2
    nlinarith [mul_le_mul_of_nonneg_left ha hθ, sq_nonneg θ]
  have hp : ε * P.real {ω | (a:EReal) ≤ ⨆ s ≤ T, (X s ω:EReal)} ≤ 1 :=
    (mul_le_mul_of_nonneg_left (measureReal_mono hsub) (exp_pos _).le).trans hbound
  have he : 0 < ε := exp_pos _
  calc
    _ ≤ 1 / ε := (le_div_iff₀ he).mpr (by simpa [mul_comm] using hp)
    _ = _ := by rw [one_div, ← exp_neg]; congr 1; ring

/-- The sharp Gaussian exponential upper bound for a Brownian running maximum. -/
theorem maximal_gaussian (hX : IsBrownianReal X P) {T : ℝ≥0} (hT : 0 < T)
    {a : ℝ} (ha : 0 ≤ a) :
    P.real {ω | (a : EReal) ≤ ⨆ s ≤ T, (X s ω : EReal)} ≤
      exp (-(a^2)/(2*(T:ℝ))) := by
  have h := maximal_exponential hX.isBrownianReal_mk.toIsPreBrownianReal
    hX.measurable_mk hX.continuous_mk T a (a/T) (by positivity)
  have hsets : {ω | (a:EReal) ≤ ⨆ s ≤ T, (hX.toIsPreBrownianReal.mk X s ω:EReal)} =ᵐ[P]
      {ω | (a:EReal) ≤ ⨆ s ≤ T, (X s ω:EReal)} := by
    filter_upwards [hX.mk_ae_forall_eq] with ω hω
    change ((a:EReal) ≤ ⨆ s ≤ T, (hX.toIsPreBrownianReal.mk X s ω:EReal)) =
      ((a:EReal) ≤ ⨆ s ≤ T, (X s ω:EReal))
    simp only [hω]
  rw [measureReal_congr hsets] at h
  convert h using 1
  congr 1
  have ht : (T:ℝ) ≠ 0 := ne_of_gt hT
  field_simp
  <;> ring

end
end ChainFountainStochastic.BrownianMaximal

/-
Copyright (c) 2026 Joris van Winden. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Adapted for ChainFountain: replace the unfinished reflection/tail route by a
proved exponential maximal inequality, and correct the normal-tail constant.
-/

namespace ChainFountainStochastic.BrownianLIL
noncomputable section
open Filter MeasureTheory ProbabilityTheory Real
open scoped ENNReal NNReal
set_option maxHeartbeats 1000000
set_option backward.isDefEq.respectTransparency false
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {P : Measure Ω}
variable {X : ℝ≥0 → Ω → ℝ}

/-- Correctly normalized Gaussian tail, transferred along a Gaussian law. -/
theorem standard_tail {Z : Ω → ℝ} (hZ : HasLaw Z (gaussianReal 0 1) P) :
    Asymptotics.IsEquivalent atTop (fun x => P.real {ω | x ≤ Z ω})
      (fun x => (1 / sqrt (2*Real.pi)) * (1/x * exp (-1/2*x^2))) := by
  haveI : NullSingletonClass (gaussianReal 0 1) := nullSingletonClass_gaussianReal (by norm_num)
  have he : (fun x : ℝ => P.real {ω | x ≤ Z ω}) =
      (fun x => (gaussianReal 0 1).real (Set.Ioi x)) := by
    funext x
    rw [Measure.real, hZ.measure_eq (measurableSet_Ici)]
    exact (measureReal_congr Ioi_ae_eq_Ici).symm
  rw [he]
  convert GaussianTail.gaussianReal_tail_isEquivalent_exp using 1
  ext x
  rw [show -1/2*x^2 = -(x^2)/2 by ring]
  ring

theorem upper_atTop (hX : IsBrownianReal X P) :
    ∀ᵐ ω ∂P, limsup (fun t ↦ ((X t ω) / √(2 * t * log (log t))).toEReal) atTop ≤ 1 := by
  -- Introduce notation
  have := (hX.hasLaw ∅).isProbabilityMeasure
  let M := fun t ω ↦ (⨆ s ≤ t, (X s ω : EReal))
  let f := fun (t : ℝ≥0) ↦ √(2 * t * log (log t))
  have fmono : MonotoneOn f (Set.Ici (⟨(exp 1),by positivity⟩)) := by
    intro x hx y hy hxy
    have hx0 : (0 < x) := by apply lt_of_lt_of_le (exp_pos _) hx
    have hx1 : (1 ≤ log x) := by
      rwa [← exp_le_exp, exp_log (by positivity)]
    apply sqrt_le_sqrt
    apply mul_le_mul (by bound) _ (log_nonneg hx1) (by bound)
    apply log_le_log (by positivity)
    apply log_le_log hx0 hxy
  -- Rewrite limsup inequality in terms of quantifiers which do not depend on `ω`
  simp_rw [ae_le_const_iff_forall_gt_measure_zero, ← not_lt, ← ae_iff]
  suffices h : ∀ c : ℝ≥0, 1 < c → ∀ᵐ (ω : Ω) ∂P, ∀ᶠ (t : ℝ≥0) in atTop,
      X t ω < c * f t by
    intro _ hc
    rcases EReal.lt_iff_exists_real_btwn.mp hc with ⟨b,hb⟩
    lift b to ℝ≥0 using by positivity [by exact_mod_cast hb.1]
    filter_upwards [h b <| by exact_mod_cast hb.1] with _ hω
    apply lt_of_le_of_lt _ hb.2
    apply limsup_le_of_le (hf := by isBoundedDefault)
    filter_upwards [hω] with t ht
    apply EReal.coe_le_coe <| div_le_of_le_mul₀ (by positivity) (by positivity) _
    exact le_of_lt ht
  intro c hc
  -- Prepare for application of Borel-Cantellli
  suffices h : ∀ᵐ ω ∂P, ∀ᶠ n : ℕ in atTop, ω ∉ {ω | (c : ℝ) * f (c ^ n) ≤ M (c ^ (n + 1)) ω} by
    filter_upwards [h] with ω hω
    -- Make a function which relates t to n
    choose n htn1 htn2 using
      fun t ↦ exists_nat_pow_near (x := max 1 t) (y := c) (by bound) (by bound)
    have h_tt1 : Tendsto (fun t ↦ n t) atTop atTop := by
      apply Tendsto.atTop_of_add_const 1
      rw [tendsto_atTop]
      intro m
      filter_upwards [eventually_ge_atTop 1, eventually_ge_atTop (c ^ m)] with t ht1 ht2
      specialize htn2 t
      rw [max_eq_right ht1] at htn2
      rw [← pow_le_pow_iff_right₀ (hc)]
      apply le_of_lt <| lt_of_le_of_lt ht2 htn2
    have h_tt2 := (tendsto_pow_atTop_atTop_of_one_lt hc).comp h_tt1
    filter_upwards [h_tt1.eventually hω, eventually_ge_atTop 1,
      h_tt2.eventually_ge_atTop ⟨(exp 1),by positivity⟩] with t ht ht1 htn3
    specialize htn1 t
    specialize htn2 t
    rw [max_eq_right ht1] at htn1 htn2
    exact_mod_cast calc
      X t ω ≤ M (c ^ (n t + 1)) ω := le_iSup_of_le t <| le_iSup_of_le (by bound) (by rfl)
      _ < (c * f (c ^ (n t))) := lt_of_not_ge ht
      _ ≤ (c : ℝ) * (f t) := by
        apply mul_le_mul_of_nonneg_left _ <| le_of_lt <| by positivity
        apply EReal.coe_le_coe <| fmono htn3 (le_trans htn3 htn1) htn1
  apply ae_eventually_notMem
  conv in P _ => rw [← ofReal_measureReal]
  apply Summable.tsum_ofReal_ne_top
  apply Summable.of_nonneg_of_le (fun _ => measureReal_nonneg)
    (fun n => BrownianMaximal.maximal_gaussian hX
      (by positivity : 0 < c ^ (n+1)) (by positivity))
  apply summable_of_isBigO_nat (summable_nat_rpow_inv.2 hc)
  apply Asymptotics.IsBigO.of_bound ((log c) ^ (c:ℝ))⁻¹
  have hlarge : ∀ᶠ n : ℕ in atTop, 1 ≤ log ((c:ℝ)^n) :=
    ((tendsto_log_atTop.comp (tendsto_pow_atTop_atTop_of_one_lt
      (show (1:ℝ) < c from hc))).eventually_ge_atTop 1)
  filter_upwards [hlarge,eventually_ge_atTop 1] with n hnlog hn
  repeat rw [norm_of_nonneg (by positivity)]
  apply le_of_eq
  have hcpos : (0:ℝ) < c := by positivity
  have hcn : (c:ℝ)^n ≠ 0 := pow_ne_zero n hcpos.ne'
  have hexp : -(((c:ℝ) * f (c^n))^2) / (2 * (c:ℝ)^(n+1)) =
      -(c:ℝ)*log (log ((c:ℝ)^n)) := by
    dsimp [f]
    push_cast
    rw [mul_pow, sq_sqrt (by positivity [log_nonneg hnlog]), pow_succ]
    field_simp
    <;> ring
  push_cast
  rw [hexp]
  rw [neg_mul,exp_neg, mul_comm (c:ℝ),exp_mul,
    exp_log (lt_of_lt_of_le (by norm_num) hnlog),log_pow]
  rw [mul_rpow (by positivity : (0:ℝ) ≤ n) (log_pos (show (1:ℝ) < c from hc)).le]
  simp only [mul_inv_rev]
  rfl

theorem lower_atTop (hX : IsBrownianReal X P)
    (h_meas : ∀ t, Measurable (X t)) :
    ∀ᵐ ω ∂P, 1 ≤ limsup (fun t ↦ X t ω / √(2 * t * log (log t)) : ℝ≥0 → EReal) atTop := by
  have := (hX.hasLaw ∅).isProbabilityMeasure
  let f := fun (t : ℝ≥0) ↦ √(2 * t * log (log t))
  -- Rewrite the inequality into a nice form with the quantifier outside
  suffices h : ∀ (c : ℝ), 1 < c → 1 < log c → ∀ᵐ ω ∂P, √(1 - 1 / c) - (1 / √c : ℝ) ≤
      limsup (fun t ↦ (X t ω) / (f t) : ℝ≥0 → EReal) atTop by
    simp_rw [ae_const_le_iff_forall_lt_measure_zero, ← not_lt, ← ae_iff]
    have h' : Tendsto (fun (r : ℝ) ↦ √(1 - 1 / r) - (1 / √r)) atTop (nhds 1) := by
      rw [(by simp : nhds (1 : ℝ) = nhds (sqrt (1 - 0) - 0))]
      apply Tendsto.sub
      · apply Tendsto.sqrt
        apply Tendsto.sub (by aesop)
        apply Tendsto.const_div_atTop <| tendsto_id
      · apply Tendsto.const_div_atTop <| tendsto_sqrt_atTop
    intro c hc1
    wlog! hc0 : (0 < c) generalizing c with h
    · replace h := fun (c : ℝ) ↦ h c
      specialize h (1/2) (?_) (by norm_num)
      · apply EReal.coe_lt_coe; bound
      exact h.mono fun _ hω ↦ lt_trans (lt_of_le_of_lt hc0 (by norm_num)) hω
    · lift c to ℝ using by aesop;; norm_cast at hc0 hc1
      apply (eventually_const (f := atTop (α := ℝ))).1
      filter_upwards [eventually_gt_atTop 1, tendsto_log_atTop.eventually_gt_atTop 1,
      Eventually.of_forall h, h'.eventually <| lt_mem_nhds <| hc1] with r hr1 hlogr hrimp hrc
      filter_upwards [hrimp hr1 hlogr] with ω hω
      exact lt_of_lt_of_le (by exact_mod_cast hrc) hω
  intro c hc1 hlogc
  have hloglogc := log_pos hlogc
  lift c to ℝ≥0 using by positivity
  have hc0 : (0 < c) := by positivity [by exact_mod_cast hc1]
  -- Rewrite in terms of limsup of difference
  suffices h1 : ∀ᵐ ω ∂P, √(1 - 1 / c) ≤
      limsup (fun t ↦ ((X t ω - X (t / c) ω) / f t).toEReal) atTop by
    have h2 : ∀ᵐ ω ∂P,
        limsup (fun t ↦ (-X (t / c) ω / f (t)).toEReal) atTop
          ≤ (1 / √c).toEReal := by
      convert upper_atTop
        (X := fun t ω ↦ √c * (-X (t / c) ω)) _ using 1
      · funext ω
        simp_rw [← mul_div, EReal.coe_mul]
        rw [EReal.limsup_const_mul_of_nonneg_of_ne_top (by positivity) (by aesop)]
        rw [mul_comm, ← EReal.le_div_iff_mul_le (by positivity) (by aesop)]
        rfl
      · convert hX.neg.smul (c := (1 / c)) (by positivity) using 3 with t
        simp [div_eq_inv_mul]
    filter_upwards [h1, h2] with ω hω hω'
    simp_rw [neg_div, EReal.coe_neg, ← Pi.neg_def, EReal.limsup_neg, EReal.neg_le] at hω'
    grw [sub_eq_add_neg, (add_le_add hω hω'), EReal.le_limsup_add]
    apply le_of_eq
    simp_rw [← EReal.coe_div, ← div_sub_div_same,
      EReal.coe_sub, Pi.add_def]
    norm_cast
    aesop
  -- auxiliary definitions
  let g := fun (n : ℕ) ↦ √(2 * log (log (c ^ n)))
  let A := fun n ↦ {ω | sqrt (c ^ (n + 1) - c ^ n) * g (n + 1) ≤
    (X (c ^ (n + 1)) ω - X (c ^ n) ω)}
  -- prepare for application of Borel-Cantelli
  suffices h : P (limsup A atTop) = 1 by
    rw [← mem_ae_iff_prob_eq_one <| by measurability] at h
    filter_upwards [h] with ω hω
    rw [mem_limsup_iff_frequently_mem] at hω
    apply le_limsup_of_frequently_le'
    apply Tendsto.frequently_map _ (_ : Tendsto (fun n ↦ c ^ (n + 1)) atTop atTop) _ hω
    · simp_rw [pow_add]
      apply Tendsto.atTop_mul_const (by positivity)
      exact tendsto_pow_atTop_atTop_of_one_lt hc1
    intro n hn
    replace hn := hn.out
    unfold f A g at *
    push_cast at *
    -- simple rewrite
    simp_rw [log_pow, pow_add] at *
    push_cast at *
    rw [EReal.coe_le_coe_iff, le_div_iff₀ <| sqrt_pos_of_pos <| by bound]
    refine (le_of_eq ?_).trans (hn.trans (le_of_eq ?_))
    · rw [← sqrt_mul (by bound), ← sqrt_mul' _ (by bound)]
      field_simp
    · field_simp
  apply ProbabilityTheory.measure_limsup_eq_one (by measurability)
  all_goals unfold A
  · -- show independence
    rw [iIndepSet_iff_iIndep]
    have h' := hX.hasIndepIncrements
    rw [hasIndepIncrements_iff_nat] at h'
    specialize h' (fun n ↦ c ^ n) _
    · apply pow_right_monotone <| le_of_lt <| by exact_mod_cast hc1
    rw [iIndepFun_iff_iIndep] at h'
    apply iIndep_of_iIndep_of_le h' fun n ↦ ?_
    apply MeasurableSpace.generateFrom_singleton_le <| measurableSet_le (by measurability) _
    apply Measurable.of_comap_le (by rfl)
  -- convert to sum of reals
  conv in P _ => rw [← ofReal_measureReal]
  simp_rw [← ENNReal.ofNNReal_toNNReal, ENNReal.tsum_coe_eq_top_iff_not_summable_coe,
    coe_toNNReal (r := P.real _) (by positivity)]
  -- rewrite in terms of standard Gaussian
  suffices h : ¬(Summable (fun n ↦ P.real {ω | g n ≤ X 1 ω})) by
    rw [← summable_nat_add_iff 1 (G := ℝ)] at h
    refine fun h' ↦ h (h'.congr fun n ↦ ?_)
    -- remove .real
    simp_rw [Measure.real_def]
    rw [ENNReal.toReal_eq_toReal_iff' (by finiteness) (by finiteness)]
    have h_idd : IdentDistrib
        (fun ω ↦ X (c ^ (n + 1)) ω - X (c ^ n) ω)
        (fun ω ↦ sqrt (c ^ (n + 1) - c ^ n) * X 1 ω) P P := by
      apply (hX.hasLaw_sub _ _).identDistrib
      convert gaussianReal_const_mul (hX.hasLaw_eval 1) _ using 2
      · norm_num
      rw [NNReal.eq_iff]
      have h_le : (c : ℝ) ^ n ≤ c ^ (n + 1) := by bound
      simp [Real.dist_eq, abs_of_nonneg (sub_nonneg.2 h_le), sq_sqrt (sub_nonneg.2 h_le)]
    -- use identical distribution to show probabilites are equal
    convert h_idd.measure_mem_eq
      (s := {x | sqrt (c ^ (n + 1) - c ^ n) * g (n + 1) ≤ (x : ℝ)}) _
    · rfl
    · simp_rw [Set.preimage_ofPred_eq]
      congr! 2
      rw [← mul_le_mul_iff_of_pos_left _]
      rw [sqrt_pos, sub_pos, pow_add]
      apply lt_mul_of_one_lt_right (by positivity) (by bound)
    · measurability
  -- apply limit comparison test
  rw [Asymptotics.IsEquivalent.summable_iff_nat
      (g := fun n ↦ (1 / sqrt (2*Real.pi)) * ((1 / (g n)) * ((1 / n) * (1 / log c))))]; swap
  · -- show asymptotic equivalence
    apply ((standard_tail <| hX.hasLaw_eval 1).comp_tendsto _).trans_eventuallyEq
    · simp_rw [Function.comp_def]
      filter_upwards [eventually_ge_atTop 1] with n hn
      have he : exp (-1/2 * (g n)^2) = (1/(n:ℝ)) * (1/log c) := by
        dsimp [g]
        rw [log_pow, sq_sqrt (by bound)]
        field_simp
        rw [exp_neg, exp_log (by positivity)]
        field_simp
      rw [he]
    · apply tendsto_sqrt_atTop.comp
      apply Tendsto.const_mul_atTop (by norm_num)
      repeat apply tendsto_log_atTop.comp
      apply tendsto_pow_atTop_atTop_of_one_lt hc1
  rw [summable_mul_left_iff (by positivity)]
  -- show non-summability of elementary series
  -- get rid of constant
  simp_rw [← mul_assoc]
  rw [summable_mul_right_iff (by positivity)]
  -- apply Cauchy condensation test
  rw [← summable_condensed_iff_of_eventually_nonneg]
  rotate_left
  · exact Eventually.of_forall (fun _ ↦ by positivity)
  · -- antitone side condition
    filter_upwards [eventually_gt_atTop 1] with n hn1
    apply mul_le_mul _ (by bound) (by positivity) (by positivity)
    unfold g
    simp_rw [log_pow]
    repeat rw [log_mul (by positivity) (by positivity)]
    gcongr
    lia
  unfold g
  push_cast
  field_simp
  -- apply limit comparison test again
  rw [Asymptotics.IsEquivalent.summable_iff_nat
    (g := fun k : ℕ ↦ 1 / √(2 * log 2) * (1 / √k))]
  · -- non-summability of p-series
    rw [summable_mul_left_iff (by positivity)]
    simp_rw [sqrt_eq_rpow]
    rw [summable_one_div_nat_rpow]
    norm_num
  -- asymptotic equivalence
  simp_rw [one_div_mul_one_div, log_pow]
  apply Asymptotics.IsEquivalent.div (by rfl)
  apply Asymptotics.isEquivalent_of_tendsto_one
  rw [Pi.div_def]
  conv in _ / _ => rw [← sqrt_mul (by positivity), ← sqrt_div (by bound),
    log_mul (by positivity) (by positivity)]
  push_cast
  simp_rw [log_pow]
  ring_nf
  simp_rw [(by simp : nhds 1 = nhds (sqrt (1 + 0)))]
  apply Tendsto.sqrt
  apply Tendsto.add
  · apply Tendsto.congr' (f₁ := fun x ↦ 1) _ (by aesop)
    filter_upwards [eventually_gt_atTop 0] with n hn using by field_simp
  · field_simp
    apply Tendsto.const_div_atTop
    rw [tendsto_mul_const_atTop_iff_pos (tendsto_natCast_atTop_atTop)]
    positivity

/-- **Law of the iterated logarithm** for Brownian motion. -/
theorem limsup_atTop (hX : IsBrownianReal X P) :
    ∀ᵐ ω ∂P, limsup (fun t ↦ (X t ω) / √(2 * t * log (log t)) : ℝ≥0 → EReal) atTop = 1 := by
  have := (hX.hasLaw ∅).isProbabilityMeasure
  have h_up := upper_atTop hX.isBrownianReal_mk
  have h_low := lower_atTop hX.isBrownianReal_mk
    hX.measurable_mk
  have h_ae := hX.mk_ae_forall_eq
  filter_upwards [h_up, h_low, h_ae] with ω hω_up hω_low hω_ae
  convert eq_of_le_of_ge hω_up hω_low
  simp_rw [hω_ae]
  rfl


end
end ChainFountainStochastic.BrownianLIL


namespace ChainFountainStochastic.BrownianSmallTime
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Real
open scoped NNReal ENNReal Topology
set_option maxHeartbeats 600000
set_option backward.isDefEq.respectTransparency false
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {P : Measure Ω}
  {X : ℝ≥0 → Ω → ℝ}

/-- The small-time LIL normalization. -/
def scale (t : ℝ≥0) : ℝ := sqrt (2*(t:ℝ)*log (log (1/(t:ℝ))))

/-- Algebraic compatibility of the LIL normalization with Brownian time inversion. -/
theorem inversion_ratio (t : ℝ≥0) (ht : t ≠ 0) (x : ℝ) :
    x / scale t⁻¹ = ((t:ℝ)*x) / sqrt (2*(t:ℝ)*log (log (t:ℝ))) := by
  have htR : (t:ℝ) ≠ 0 := by exact_mod_cast ht
  have he : sqrt (2*(t:ℝ)*log (log (t:ℝ))) =
      (t:ℝ) * sqrt (2*(t:ℝ)⁻¹*log (log (t:ℝ))) := by
    calc
      _ = sqrt ((t:ℝ)^2 * (2*(t:ℝ)⁻¹*log (log (t:ℝ)))) := by
        congr 1
        field_simp
        <;> ring
      _ = _ := by rw [sqrt_mul (sq_nonneg (t:ℝ)),sqrt_sq t.coe_nonneg]
  simp only [scale,NNReal.coe_inv,one_div,inv_inv]
  rw [he]
  exact (mul_div_mul_left x _ htR).symm

/-- Sharp small-time upper LIL, on every probability space carrying Brownian motion. -/
theorem limsup_zero (hX : IsBrownianReal X P) :
    ∀ᵐ ω ∂P, limsup (fun t => (X t ω / scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = 1 := by
  filter_upwards [BrownianLIL.limsup_atTop hX.inv] with ω hω
  simp only [← EReal.coe_div] at hω
  rw [← inv_atTop₀]
  change limsup (fun t => (X t ω / scale t).toEReal)
    (map (fun t : ℝ≥0 => t⁻¹) atTop) = 1
  rw [← limsup_comp]
  apply (limsup_congr ?_).trans hω
  filter_upwards [eventually_gt_atTop (0:ℝ≥0)] with t ht
  simp only [Function.comp_def, inversion_ratio t ht.ne',one_div]

/-- Sharp small-time lower LIL. -/
theorem liminf_zero (hX : IsBrownianReal X P) :
    ∀ᵐ ω ∂P, liminf (fun t => (X t ω / scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = -1 := by
  filter_upwards [limsup_zero hX.neg] with ω hω
  change limsup (fun t => (-X t ω / scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = 1 at hω
  simp only [neg_div, EReal.coe_neg, ← Pi.neg_def, EReal.limsup_neg] at hω
  exact neg_injective (by simpa using hω)

/-- Both sharp limits hold on a single probability-one event. -/
theorem two_sided_zero (hX : IsBrownianReal X P) :
    ∀ᵐ ω ∂P,
      limsup (fun t => (X t ω / scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = 1 ∧
      liminf (fun t => (X t ω / scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = -1 :=
  (limsup_zero hX).and (liminf_zero hX)

end
end ChainFountainStochastic.BrownianSmallTime


namespace ChainFountainStochastic.LILDriftStability
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Real BrownianSmallTime
open scoped NNReal ENNReal Topology
set_option maxHeartbeats 600000
set_option backward.isDefEq.respectTransparency false

/-- The LIL scale dominates linear drift near zero. -/
theorem time_div_scale_zero :
    Tendsto (fun t : ℝ≥0 => (t:ℝ)/scale t) (𝓝[>] 0) (𝓝 0) := by
  have ht : Tendsto (fun t : ℝ≥0 => (t:ℝ)) (𝓝[>] 0) (𝓝 0) :=
    (NNReal.continuous_coe.tendsto 0).mono_left nhdsWithin_le_nhds
  have hlog : Tendsto (fun t : ℝ≥0 => log (log (1/(t:ℝ)))) (𝓝[>] 0) atTop := by
    simpa only [NNReal.coe_inv,one_div,Function.comp_def] using
      tendsto_log_atTop.comp (tendsto_log_atTop.comp
        (NNReal.tendsto_coe_atTop.mpr (tendsto_inv_nhdsGT_zero (𝕜:=ℝ≥0))))
  apply squeeze_zero' (Eventually.of_forall fun t => by positivity [sqrt_nonneg (2*(t:ℝ)*log (log (1/(t:ℝ))))])
    ?_ (by simpa using ht.sqrt)
  filter_upwards [hlog.eventually_ge_atTop 1,self_mem_nhdsWithin] with t hlog htpos
  have hp : (0:ℝ) < t := htpos
  have hs : sqrt (t:ℝ) ≤ scale t := by
    apply sqrt_le_sqrt
    nlinarith
  have hspos := lt_of_lt_of_le (sqrt_pos.mpr hp) hs
  apply (div_le_iff₀ hspos).mpr
  calc
    (t:ℝ) = sqrt (t:ℝ) * sqrt (t:ℝ) := (mul_self_sqrt t.coe_nonneg).symm
    _ ≤ _ := mul_le_mul_of_nonneg_left hs (sqrt_nonneg _)

/-- A pathwise O(t) perturbation is negligible at the sharp LIL scale.
The bound may depend on the sample path. -/
theorem bounded_drift_negligible {A : ℝ≥0 → ℝ} {K : ℝ}
    (hA : ∀ᶠ t in 𝓝[>] (0:ℝ≥0), |A t| ≤ K*(t:ℝ)) :
    Tendsto (fun t => A t/scale t) (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
  apply squeeze_zero_norm' ?_ (by simpa using time_div_scale_zero.const_mul K)
  filter_upwards [hA] with t ht
  rw [Real.norm_eq_abs, abs_div, abs_of_nonneg (show 0 ≤ scale t from sqrt_nonneg _)]
  calc
    _ ≤ (K*(t:ℝ))/scale t := div_le_div_of_nonneg_right ht (sqrt_nonneg _)
    _ = _ := by ring

/-- Addition of a real-valued term tending to zero preserves EReal limsup. -/
theorem limsup_add_zero {ι : Type*} {f : Filter ι} [NeBot f]
    {u : ι → EReal} {v : ι → ℝ} (hv : Tendsto v f (𝓝 0)) :
    limsup (fun t => u t + (v t:EReal)) f = limsup u f := by
  have he : Tendsto (fun t => (v t:EReal)) f (𝓝 0) := by
    simpa only [Function.comp_def,EReal.coe_zero] using
      continuous_coe_real_ereal.continuousAt.tendsto.comp hv
  have hsup := he.limsup_eq
  have hinf := he.liminf_eq
  apply le_antisymm
  · have h := EReal.limsup_add_le (u:=u) (v:=fun t => (v t:EReal)) (f:=f)
      (Or.inr (by rw [hsup]; simp)) (Or.inr (by rw [hsup]; simp))
    simpa only [hsup,add_zero,Pi.add_def] using h
  · have h := EReal.le_limsup_add (u:=u) (v:=fun t => (v t:EReal)) (f:=f)
    simpa only [hinf,add_zero,Pi.add_def] using h

/-- Addition of a real-valued term tending to zero preserves EReal liminf. -/
theorem liminf_add_zero {ι : Type*} {f : Filter ι} [NeBot f]
    {u : ι → EReal} {v : ι → ℝ} (hv : Tendsto v f (𝓝 0)) :
    liminf (fun t => u t + (v t:EReal)) f = liminf u f := by
  have he : Tendsto (fun t => (v t:EReal)) f (𝓝 0) := by
    simpa only [Function.comp_def,EReal.coe_zero] using
      continuous_coe_real_ereal.continuousAt.tendsto.comp hv
  have hsup := he.limsup_eq
  have hinf := he.liminf_eq
  apply le_antisymm
  · have h := EReal.liminf_add_le (u:=fun t => (v t:EReal)) (v:=u) (f:=f)
      (Or.inl (by rw [hsup]; simp)) (Or.inl (by rw [hsup]; simp))
    simpa only [hsup,zero_add,Pi.add_def,add_comm,add_zero] using h
  · have h := EReal.le_liminf_add (u:=u) (v:=fun t => (v t:EReal)) (f:=f)
    simpa only [hinf,add_zero,Pi.add_def] using h

/-- On one probability-one event, every nonnegative constant diffusion and
every pathwise linearly bounded drift obey both sharp small-time LIL limits. -/
theorem affine_lil {Ω : Type*} [MeasurableSpace Ω] {P : Measure Ω}
    {B : ℝ≥0 → Ω → ℝ} (hB : IsBrownianReal B P) :
    ∀ᵐ ω ∂P, ∀ σ : ℝ, 0 ≤ σ → ∀ A : ℝ≥0 → ℝ, ∀ K : ℝ,
      (∀ᶠ t in 𝓝[>] (0:ℝ≥0), |A t| ≤ K*(t:ℝ)) →
      limsup (fun t => ((σ*B t ω+A t)/scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = σ ∧
      liminf (fun t => ((σ*B t ω+A t)/scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = -σ := by
  filter_upwards [two_sided_zero hB] with ω hω
  intro σ hσ A K hA
  have ha := bounded_drift_negligible hA
  have he (t : ℝ≥0) : ((σ*B t ω+A t)/scale t).toEReal =
      (σ:EReal)*(B t ω/scale t).toEReal + (A t/scale t).toEReal := by
    rw [add_div,mul_div_assoc,EReal.coe_add,EReal.coe_mul]
  simp_rw [he]
  rw [limsup_add_zero ha,liminf_add_zero ha,
    EReal.limsup_const_mul_of_nonneg_of_ne_top (by exact_mod_cast hσ) (by simp),
    EReal.liminf_const_mul_of_nonneg_of_ne_top (by exact_mod_cast hσ) (by simp),hω.1,hω.2]
  simp

end
end ChainFountainStochastic.LILDriftStability


namespace ChainFountainStochastic.ItoExponential
noncomputable section
open MeasureTheory ProbabilityTheory MathFin Filter Set Real
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM MathFin.ItoIntegralLocalised
open scoped NNReal ENNReal Topology
set_option maxHeartbeats 1000000
set_option backward.isDefEq.respectTransparency false
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
  {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ)
  (hBm : ∀ t, Measurable (B t))
  {a : ℝ≥0 → Ω → ℝ}
  (ha : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
  (hc : ∀ ω, Continuous (a · ω)) {C : ℝ} (hb : ∀ t ω, |a t ω| ≤ C)

include hc hb in
/-- The actual accumulated squared coefficient is bounded by its uniform bound. -/
theorem square_integral_le (T : ℝ≥0) (ω : Ω) :
    (∫ s in Ioc 0 T, (a s ω)^2 ∂timeMeasure) ≤ C^2*(T:ℝ) := by
  have hi : IntegrableOn (fun s => (a s ω)^2) (Ioc 0 T) timeMeasure :=
    ((hc ω).pow 2 |>.continuousOn.integrableOn_compact isCompact_Icc).mono_set Ioc_subset_Icc_self
  calc
    _ ≤ ∫ s in Ioc (0:ℝ≥0) T, C^2 ∂timeMeasure := by
      apply setIntegral_mono_on hi (integrableOn_const (by simp [timeMeasure_Ioc])) measurableSet_Ioc
      intro s hs
      simpa only [sq_abs] using pow_le_pow_left₀ (abs_nonneg (a s ω)) (hb s ω) 2
    _ = _ := by simp [Measure.real_def, timeMeasure_Ioc, mul_comm]

include hb in
theorem scaled_bound (q : ℝ) : ∀ t ω, |q * a t ω| ≤ |q| * C := by
  intro t ω
  rw [abs_mul]
  exact mul_le_mul_of_nonneg_left (hb t ω) (abs_nonneg q)

/-- Scalar multiplication commutes with the genuine terminal Ito integral. -/
theorem terminal_smul (q : ℝ) (T : ℝ≥0) :
    itoIntCont hB hBm (fun t => (ha t).const_mul q) (fun ω => (hc ω).const_mul q)
      (C:=|q| * C) (scaled_bound hb q) T =ᵐ[μ]
      fun ω => q * itoIntCont hB hBm ha hc hb T ω := by
  have he : processToLp (μ:=μ) T hBm (fun t => (ha t).const_mul q)
      (fun ω => (hc ω).const_mul q)
      (C:=|q| * C) (scaled_bound hb q) =
      q • processToLp (μ:=μ) T hBm ha hc hb := by
    apply Lp.ext
    filter_upwards [processToLp_coeFn (μ:=μ) T hBm (fun t => (ha t).const_mul q)
      (fun ω => (hc ω).const_mul q) (C:=|q| * C)
      (scaled_bound hb q),
      Lp.coeFn_smul q (processToLp (μ:=μ) T hBm ha hc hb),
      processToLp_coeFn (μ:=μ) T hBm ha hc hb] with z h₁ h₂ h₃
    simp only [Pi.smul_apply, smul_eq_mul, h₃] at h₂
    exact h₁.trans h₂.symm
  simp only [itoIntCont,he,map_smul]
  exact Lp.coeFn_smul q _

/-- A bounded continuous adapted coefficient has an integrable Doleans
exponential of mean one, derived from the proved predictable approximation. -/
theorem density_mean_one (T : ℝ≥0) :
    Integrable (contDoleansExp (itoIntCont hB hBm ha hc hb T) a T) μ ∧
      (∫ ω, contDoleansExp (itoIntCont hB hBm ha hc hb T) a T ω ∂μ) = 1 := by
  let hp := isStronglyPredictable_of_bdd_adapted_cont hBm ha hc
  obtain ⟨V,hV⟩ := exists_approxSeq (μ:=μ) hBm T hp hb
  have he := ZTpred_ae_eq_contDoleansExp hB hBm ha hc hb T
  exact ⟨((memLp_ZTpred_one hB hBm T hp hb V hV).integrable le_rfl).congr he,
    (integral_congr_ae he).symm.trans (integral_ZTpred_eq_one hB hBm T hp hb V hV)⟩

/-- Gaussian exponential moment bound for the genuine Ito integral of a
bounded, continuous adapted coefficient. -/
theorem terminal_mgf (q : ℝ) (T : ℝ≥0) :
    Integrable (fun ω => exp (q * itoIntCont hB hBm ha hc hb T ω)) μ ∧
    (∫ ω, exp (q * itoIntCont hB hBm ha hc hb T ω) ∂μ) ≤
      exp (q^2*C^2*(T:ℝ)/2) := by
  let θ := fun t ω => -q * a t ω
  let haθ := fun t => (ha t).const_mul (-q)
  let hcθ := fun ω => (hc ω).const_mul (-q)
  let hbθ := scaled_bound hb (-q)
  let Z := contDoleansExp (itoIntCont hB hBm haθ hcθ hbθ T) θ T
  obtain ⟨hZi,hZ1⟩ := density_mean_one hB hBm haθ hcθ hbθ T
  have hdom : ∀ᵐ ω ∂μ, exp (q * itoIntCont hB hBm ha hc hb T ω) ≤
      exp (q^2*C^2*(T:ℝ)/2) * Z ω := by
    filter_upwards [terminal_smul hB hBm ha hc hb (-q) T] with ω hω
    dsimp [Z,contDoleansExp]
    rw [hω,← exp_add]
    apply exp_le_exp.mpr
    have hs := square_integral_le hcθ hbθ T ω
    dsimp [θ] at *
    rw [abs_neg,mul_pow,sq_abs] at hs
    nlinarith
  have hi : Integrable (fun ω => exp (q * itoIntCont hB hBm ha hc hb T ω)) μ := by
    apply (hZi.const_mul (exp (q^2*C^2*(T:ℝ)/2))).mono'
    · exact Real.continuous_exp.comp_aestronglyMeasurable ((Lp.stronglyMeasurable _).aestronglyMeasurable.const_mul q)
    · simpa only [Real.norm_eq_abs,abs_of_pos (exp_pos _)] using hdom
  refine ⟨hi, (integral_mono_ae hi (hZi.const_mul _) hdom).trans_eq ?_⟩
  rw [integral_const_mul,hZ1,mul_one]

end
end ChainFountainStochastic.ItoExponential

/-
Copyright (c) 2026 Raphael Coelho. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Adapted for ChainFountain: retain the true martingale property and expose
modification at every frozen time, both already established by the construction.
-/

namespace ChainFountainStochastic.ItoContinuousMartingale
noncomputable section
open MeasureTheory ProbabilityTheory Filter Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM MathFin.ItoIntegralProcess
open MathFin.ItoIntegralProcessGeneral MathFin.ItoIntegralProcessContinuousModification
open MathFin.ItoLocalMartingale MathFin.ItoIntegralProcessLocalMartingaleGeneral
open scoped NNReal ENNReal
variable {Ω : Type*} {m0 : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ)
set_option maxHeartbeats 1000000
set_option backward.isDefEq.respectTransparency false

theorem exists_continuous_martingale_modification (T : ℝ≥0)
    (hBmeas : ∀ t, Measurable (B t)) (hBcont : ∀ ω, Continuous fun t : ℝ≥0 ↦ B t ω)
    (φ : Lp ℝ 2 (trimMeasure_T (μ := μ) T hBmeas)) :
    ∃ X : ℝ≥0 → Ω → ℝ,
      (∀ t, X t =ᵐ[μ] itoProcessCLM hB T (min t T) hBmeas φ) ∧
      (∀ ω, Continuous fun t ↦ X t ω) ∧
      Martingale X (augFiltration (μ := μ) hBmeas) μ ∧
      (∀ i, StronglyMeasurable[augFiltration (μ := μ) hBmeas i] (X i)) := by
  -- a co-null good set of the null σ-algebra: pointwise convergence and continuity on `[0, T]`
  obtain ⟨G, hGaug, hGnull, hGgood⟩ := exists_nullsAlg_of_ae (μ := μ)
    (p := fun ω ↦ (∀ t : ℝ≥0, t ≤ T → Tendsto
        (fun n ↦ itoSimpleProcess hBmeas ((approxSeq T hBmeas φ).choose n).val t ω) atTop
        (𝓝 (itoContinuousMod T hBmeas φ t ω)))
      ∧ ContinuousOn (fun t ↦ itoContinuousMod T hBmeas φ t ω) (Set.Icc 0 T)) <| by
    filter_upwards [itoContinuousMod_tendsto hB T hBmeas hBcont φ,
      itoContinuousMod_continuousOn hB T hBmeas hBcont φ] with ω h1 h2 using ⟨h1, h2⟩
  -- adaptedness to the augmented filtration: a pointwise limit of `G.indicator` of the simple
  -- integrals, each `natFiltration`-measurable
  have hadapt : ∀ i : ℝ≥0, StronglyMeasurable[natFiltration hBmeas i ⊔ nullsAlg m0 μ]
      (fun ω ↦ itoLocalMod G T i hBmeas φ ω) := by
    intro i
    refine stronglyMeasurable_of_tendsto atTop
      (f := fun n ↦ G.indicator
        (fun ω ↦ itoSimpleProcess hBmeas ((approxSeq T hBmeas φ).choose n).val (min i T) ω))
      (fun n ↦ ?_) ?_
    · exact (((itoSimpleProcess_isMartingale hB hBmeas
          ((approxSeq T hBmeas φ).choose n).val).1 (min i T)).mono
        (((natFiltration hBmeas).mono (min_le_left i T)).trans le_sup_left)).indicator
        ((le_sup_right : nullsAlg m0 μ ≤ natFiltration hBmeas i ⊔ nullsAlg m0 μ) _ hGaug)
    · refine tendsto_pi_nhds.mpr (fun ω ↦ ?_)
      by_cases hω : ω ∈ G
      · simp only [Set.indicator_of_mem hω, itoLocalMod]
        exact (hGgood ω hω).1 (min i T) (min_le_right i T)
      · simp only [Set.indicator_of_notMem hω, itoLocalMod]
        exact tendsto_const_nhds
  have hcont : ∀ ω, Continuous (fun t ↦ itoLocalMod G T t hBmeas φ ω) :=
    continuous_indicator_min fun ω hω ↦ (hGgood ω hω).2
  refine ⟨fun t ω ↦ itoLocalMod G T t hBmeas φ ω, fun t ↦ ?_, hcont, ?_, hadapt⟩
  · exact itoLocalMod_ae_eq hB T hBmeas hBcont hGnull φ t
  · exact ⟨hadapt, fun i j hij ↦
      condExp_itoLocalMod hB T hBmeas hBcont hGnull φ hij⟩

/-- A continuous true martingale representing the genuine bounded-coefficient
Ito integral, with its exponential moment estimate at every time. -/
theorem exists_integral_martingale (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
    {a : ℝ≥0 → Ω → ℝ}
    (ha : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hc : ∀ ω, Continuous (a · ω)) {C : ℝ} (hb : ∀ t ω, |a t ω| ≤ C) :
    ∃ X : ℝ≥0 → Ω → ℝ,
      (∀ t, X t =ᵐ[μ] itoIntCont hB hBm ha hc hb (min t T)) ∧
      (∀ ω, Continuous (X · ω)) ∧
      Martingale X (augFiltration (μ:=μ) hBm) μ ∧
      (∀ q t, Integrable (fun ω => Real.exp (q*X t ω)) μ ∧
        (∫ ω, Real.exp (q*X t ω) ∂μ) ≤ Real.exp (q^2*C^2*(t:ℝ)/2)) := by
  obtain ⟨X,hX,hcX,hmX,haX⟩ := exists_continuous_martingale_modification hB T hBm hBc
    (processToLp (μ:=μ) T hBm ha hc hb)
  have hv : ∀ t, X t =ᵐ[μ] itoIntCont hB hBm ha hc hb (min t T) := by
    intro t
    have h := hX t
    rw [itoProcessCLM_consist hB hBm le_rfl (min_le_right t T) ha hc hb,
      itoProcessCLM_terminal_eq] at h
    exact h
  refine ⟨X,hv,hcX,hmX,fun q t => ?_⟩
  have he : (fun ω => Real.exp (q * itoIntCont hB hBm ha hc hb (min t T) ω)) =ᵐ[μ]
      (fun ω => Real.exp (q * X t ω)) := by
    filter_upwards [hv t] with ω hω
    rw [hω]
  obtain ⟨hi,hb⟩ := ItoExponential.terminal_mgf hB hBm ha hc hb q (min t T)
  refine ⟨hi.congr he, ?_⟩
  rw [← integral_congr_ae he]
  apply hb.trans
  apply Real.exp_le_exp.mpr
  exact div_le_div_of_nonneg_right
    (mul_le_mul_of_nonneg_left (by exact_mod_cast min_le_left t T)
      (mul_nonneg (sq_nonneg q) (sq_nonneg C))) (by norm_num)

end
end ChainFountainStochastic.ItoContinuousMartingale


namespace ChainFountainStochastic.ItoMaximal
noncomputable section
open MeasureTheory ProbabilityTheory Real Filter Set
open scoped NNReal ENNReal
set_option maxHeartbeats 1000000
set_option backward.isDefEq.respectTransparency false
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {ℱ : Filtration ℝ≥0 mΩ} {X : ℝ≥0 → Ω → ℝ}
  (hM : Martingale X ℱ μ) (hc : ∀ ω, Continuous (X · ω))
  {C : ℝ}
  (he : ∀ q t, Integrable (fun ω => exp (q*X t ω)) μ ∧
    (∫ ω, exp (q*X t ω) ∂μ) ≤ exp (q^2*C^2*(t:ℝ)/2))

include hM hc he

/-- Doob's inequality turns terminal exponential moment estimates into a
uniform-in-time exponential estimate. -/
theorem maximal_exponential (T : ℝ≥0) (a q : ℝ) (hq : 0 ≤ q) :
    μ.real {ω | (a:EReal) ≤ ⨆ s ≤ T, (X s ω:EReal)} ≤
      exp (-q*a+q^2*C^2*(T:ℝ)/2) := by
  let W := fun t ω => exp (q*X t ω)
  have hw : Submartingale W ℱ μ :=
    (hM.smul q).submartingale_convex_comp convexOn_exp continuous_exp (fun t => (he q t).1)
  have hwc : ∀ ω, Continuous (W · ω) := fun ω => by dsimp [W]; fun_prop
  let ε := exp (q*a)
  have hmax := maximal_ineq hw (show 0 ≤ W from fun t ω => (exp_pos _).le) ε T
    (fun ω => (hwc ω).isRightContinuous)
  have hbound : ε * μ.real {ω | ε ≤ ⨆ s : Iic T, W s ω} ≤ exp (q^2*C^2*(T:ℝ)/2) :=
    hmax.trans ((setIntegral_le_integral (hw.integrable T)
      (ae_of_all _ fun ω => (exp_pos _).le)).trans (he q T).2)
  have hsub : {ω | (a:EReal) ≤ ⨆ s ≤ T, (X s ω:EReal)} ⊆
      {ω | ε ≤ ⨆ s : Iic T, W s ω} := by
    intro ω hω
    obtain ⟨s,hs,hsm⟩ := isCompact_Icc.exists_isMaxOn
      (nonempty_Icc.mpr (show (0:ℝ≥0) ≤ T from bot_le)) (hc ω).continuousOn
    have ha : a ≤ X s ω := EReal.coe_le_coe_iff.mp
      (hω.trans (iSup_le fun (u : ℝ≥0) => iSup_le fun (hu : u ≤ T) => EReal.coe_le_coe (hsm ⟨bot_le,hu⟩)))
    have hb : BddAbove (range fun s : Iic T => W s ω) := by
      have hr : range (fun s : Iic T => W s ω) = (W · ω) '' Icc 0 T := by
        ext y; simp only [mem_range,mem_image,mem_Icc]
        constructor
        · rintro ⟨u,rfl⟩; exact ⟨u,⟨bot_le,u.property⟩,rfl⟩
        · rintro ⟨u,hu,rfl⟩; exact ⟨⟨u,hu.2⟩,rfl⟩
      rw [hr]
      exact (isCompact_Icc.image (hwc ω)).bddAbove
    exact (exp_le_exp.mpr (mul_le_mul_of_nonneg_left ha hq)).trans (le_ciSup hb ⟨s,hs.2⟩)
  have hp := (mul_le_mul_of_nonneg_left (measureReal_mono hsub) (exp_pos _).le).trans hbound
  calc
    _ ≤ exp (q^2*C^2*(T:ℝ)/2) / ε := (le_div_iff₀ (exp_pos _)).mpr
      (by simpa [mul_comm] using hp)
    _ = _ := by rw [← exp_sub]; congr 1; ring

/-- Gaussian maximal estimate for a continuous martingale with bounded-
diffusion exponential moments. -/
theorem maximal_gaussian (hC : 0 < C) {T : ℝ≥0} (hT : 0 < T)
    {a : ℝ} (ha : 0 ≤ a) :
    μ.real {ω | (a:EReal) ≤ ⨆ s ≤ T, (X s ω:EReal)} ≤
      exp (-(a^2)/(2*C^2*(T:ℝ))) := by
  have h := maximal_exponential hM hc he T a (a/(C^2*T)) (by positivity)
  convert h using 1
  congr 1
  have ht : (T:ℝ) ≠ 0 := ne_of_gt hT
  field_simp
  <;> ring

end
end ChainFountainStochastic.ItoMaximal


namespace ChainFountainStochastic.ItoSmallTimeBound
noncomputable section
open MeasureTheory ProbabilityTheory Real Filter Set
open scoped NNReal ENNReal Topology
set_option maxHeartbeats 1000000
set_option backward.isDefEq.respectTransparency true
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ} {X : ℝ≥0 → Ω → ℝ} {C : ℝ}

/-- A Gaussian running-maximum estimate implies a coarse pathwise LIL upper
bound. Its constant need not be sharp: it will be applied to arbitrarily small
clipped residual coefficients. -/
theorem upper (hC : 0 < C)
    (hm : ∀ (T : ℝ≥0), 0 < T → ∀ a : ℝ, 0 ≤ a →
      μ.real {ω | (a:EReal) ≤ ⨆ s ≤ T, (X s ω:EReal)} ≤
        exp (-(a^2)/(2*C^2*(T:ℝ)))) :
    ∀ᵐ ω ∂μ, ∀ᶠ t in 𝓝[>] (0:ℝ≥0), X t ω / BrownianSmallTime.scale t ≤ 4*C := by
  let f := fun (t : ℝ≥0) => sqrt (2*(t:ℝ)*log (log (t:ℝ)))
  let M := fun t ω => ⨆ s ≤ t, (X s ω:EReal)
  have fmono : MonotoneOn f (Ici (⟨exp 1,by positivity⟩)) := by
    intro x hx y hy hxy
    have hx0 : (0 < x) := lt_of_lt_of_le (exp_pos _) hx
    have hx1 : 1 ≤ log x := by rwa [← exp_le_exp,exp_log (by positivity)]
    apply sqrt_le_sqrt
    apply mul_le_mul (by bound) _ (log_nonneg hx1) (by bound)
    exact log_le_log (by positivity) (log_le_log hx0 hxy)
  have hbc : ∀ᵐ ω ∂μ, ∀ᶠ n : ℕ in atTop,
      ω ∉ {ω | (2*C*f (2^n)/(2:ℝ)^n).toEReal ≤ M ((2:ℝ≥0)^n)⁻¹ ω} := by
    have hs : Summable (fun n : ℕ => μ.real
        {ω | (2*C*f (2^n)/(2:ℝ)^n).toEReal ≤ M (((2:ℝ≥0)^n)⁻¹) ω}) := by
      apply Summable.of_nonneg_of_le (fun _ => measureReal_nonneg)
        (fun n => hm ((2:ℝ≥0)^n)⁻¹ (by positivity) _ (by positivity))
      apply summable_of_isBigO_nat (summable_nat_rpow_inv.2 (by norm_num : (1:ℝ) < 4))
      apply Asymptotics.IsBigO.of_bound ((log 2)^4)⁻¹
      have hlarge : ∀ᶠ n : ℕ in atTop, 1 ≤ log ((2:ℝ)^n) :=
        (tendsto_log_atTop.comp (tendsto_pow_atTop_atTop_of_one_lt (by norm_num : (1:ℝ) < 2))).eventually_ge_atTop 1
      filter_upwards [hlarge,eventually_ge_atTop 1] with n hnlog hn
      repeat rw [norm_of_nonneg (by positivity)]
      apply le_of_eq
      have hn0 : (2:ℝ)^n ≠ 0 := by positivity
      have hx : -((2*C*f (2^n)/(2:ℝ)^n)^2)/(2*C^2*(((2:ℝ≥0)^n)⁻¹:ℝ≥0)) =
          -4*log (log ((2:ℝ)^n)) := by
        dsimp [f]
        push_cast
        rw [div_pow,mul_pow,mul_pow,sq_sqrt (by positivity [log_nonneg hnlog])]
        field_simp
        <;> ring
      rw [hx]
      rw [show (-4:ℝ)*log (log ((2:ℝ)^n)) = -(4*log (log ((2:ℝ)^n))) by ring,
        exp_neg,mul_comm (4:ℝ),exp_mul,exp_log (lt_of_lt_of_le (by norm_num) hnlog),log_pow]
      rw [mul_rpow (by positivity : (0:ℝ) ≤ n) (log_pos (by norm_num : (1:ℝ) < 2)).le]
      simp [Real.rpow_natCast,mul_inv_rev]
    apply ae_eventually_notMem
    simpa only [Measure.real_def, ENNReal.ofReal_toReal (measure_ne_top μ _)] using hs.tsum_ofReal_ne_top
  filter_upwards [hbc] with ω hω
  rw [← inv_atTop₀]
  change ∀ᶠ t in map (fun t : ℝ≥0 => t⁻¹) atTop,
    X t ω / BrownianSmallTime.scale t ≤ 4*C
  rw [eventually_map]
  choose n htn1 htn2 using fun t : ℝ≥0 =>
    exists_nat_pow_near (x:=max 1 t) (y:=2) (by bound) (by norm_num)
  have hnt : Tendsto n atTop atTop := by
    apply Tendsto.atTop_of_add_const 1
    rw [tendsto_atTop]
    intro m
    filter_upwards [eventually_ge_atTop 1,eventually_ge_atTop ((2:ℝ≥0)^m)] with t ht1 ht2
    have h := htn2 t
    rw [max_eq_right ht1] at h
    rw [← pow_le_pow_iff_right₀ (by norm_num : (1:ℝ≥0) < 2)]
    exact (ht2.trans_lt h).le
  have hpow := (tendsto_pow_atTop_atTop_of_one_lt (by norm_num : (1:ℝ≥0) < 2)).comp hnt
  filter_upwards [hnt.eventually hω,eventually_ge_atTop 1,
    hpow.eventually_ge_atTop ⟨exp 1,by positivity⟩] with t ht ht1 hn3
  have ht0 : 0 < t := lt_of_lt_of_le (by norm_num) ht1
  have h1 := htn1 t
  have h2 := htn2 t
  rw [max_eq_right ht1] at h1 h2
  have hxt : X t⁻¹ ω < 2*C*f (2^n t)/(2:ℝ)^n t := by
    apply EReal.coe_lt_coe_iff.mp
    have hle : (X t⁻¹ ω:EReal) ≤ M (((2:ℝ≥0)^n t)⁻¹) ω := by
      apply le_iSup_of_le t⁻¹
      exact le_iSup_of_le (inv_anti₀ (by positivity : (0:ℝ≥0) < 2^n t) h1) le_rfl
    exact hle.trans_lt (lt_of_not_ge ht)
  rw [BrownianSmallTime.inversion_ratio t ht0.ne']
  apply div_le_of_le_mul₀ (by positivity) (by positivity)
  have hp : (0:ℝ) < (2:ℝ)^n t := by positivity
  have htR : (t:ℝ) < 2*(2:ℝ)^n t := by exact_mod_cast (by simpa [pow_succ,mul_comm] using h2)
  have hff : f (2^n t) ≤ f t := fmono hn3 (hn3.trans h1) h1
  calc
    (t:ℝ)*X t⁻¹ ω ≤ (t:ℝ)*(2*C*f (2^n t)/(2:ℝ)^n t) :=
      mul_le_mul_of_nonneg_left hxt.le t.coe_nonneg
    _ ≤ (2*(2:ℝ)^n t)*(2*C*f (2^n t)/(2:ℝ)^n t) :=
      mul_le_mul_of_nonneg_right htR.le (by positivity)
    _ = 4*C*f (2^n t) := by field_simp; ring
    _ ≤ 4*C*f t := mul_le_mul_of_nonneg_left hff (by positivity)

open MathFin MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM
open MathFin.ItoIntegralProcessContinuousModification MathFin.ItoIntegralProcessGeneral
open MathFin.ItoIntegralPredictable MathFin.ItoIntegralLocalised
open MathFin.ItoIntegralProcessLocalMartingaleGeneral MathFin.LocalisationInMeasure

/-- The genuine predictable integral inherits the two-sided coarse bound. -/
theorem pred_integral (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hT : 0 < T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
    {a : ℝ≥0 → Ω → ℝ}
    (ha : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hc : ∀ ω, Continuous (a · ω))
    (hp : IsStronglyPredictable (natFiltration hBm) a)
    (hC : 0 < C) (hb : ∀ t ω, |a t ω| ≤ C) :
    ∀ᵐ ω ∂μ, ∀ᶠ t in 𝓝[>] (0:ℝ≥0),
      |predItoIntegral (μ:=μ) T hBm hp t ω / BrownianSmallTime.scale t| ≤ 4*C := by
  obtain ⟨X,hv,hcX,hmX,he⟩ := ItoContinuousMartingale.exists_integral_martingale hB T hBm hBc ha hc hb
  have heNeg : ∀ q t, Integrable (fun ω => exp (q * (-X t ω))) μ ∧
      (∫ ω, exp (q * (-X t ω)) ∂μ) ≤ exp (q^2*C^2*(t:ℝ)/2) := by
    intro q t
    simpa only [neg_mul,mul_neg,neg_sq] using he (-q) t
  have heq : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      X t ω = predItoIntegral (μ:=μ) T hBm hp t ω := by
    have hxc : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
        X t ω = itoContinuousMod T hBm (processToLp (μ:=μ) T hBm ha hc hb) t ω := by
      apply ae_forall_eq_of_continuousOn (ae_of_all _ fun ω => (hcX ω).continuousOn)
        (itoContinuousMod_continuousOn hB T hBm hBc _)
      intro t ht
      have h := itoContinuousMod_modification hB T hBm hBc
        (processToLp (μ:=μ) T hBm ha hc hb) ht.2
      rw [itoProcessCLM_consist hB hBm le_rfl ht.2 ha hc hb,itoProcessCLM_terminal_eq] at h
      have hv' : X t =ᵐ[μ] itoIntCont hB hBm ha hc hb t := by
        simpa only [min_eq_left ht.2] using hv t
      exact hv'.trans h.symm
    filter_upwards [hxc,LocalIntegralBridge.continuousMod_eq_predIto hB T hBm hBc hp
      (ae_of_all _ fun ω => (hc ω).continuousOn) hb _ (processToLp_coeFn T hBm ha hc hb)] with ω h1 h2
    exact fun t ht => (h1 t ht).trans (h2 t ht)
  filter_upwards [heq,
    upper hC (fun T hT a ha => ItoMaximal.maximal_gaussian hmX hcX he hC hT ha),
    upper (X:=fun t ω => -X t ω) hC (fun T hT a ha =>
      ItoMaximal.maximal_gaussian hmX.neg (fun ω => (hcX ω).neg) heNeg hC hT ha)] with ω heq hu hl
  filter_upwards [hu,hl,((eventually_lt_nhds hT).filter_mono nhdsWithin_le_nhds)] with t hu hl ht
  rw [← heq t ⟨bot_le,ht.le⟩]
  exact abs_le.mpr ⟨by simpa only [neg_div,neg_le] using hl,hu⟩

end
end ChainFountainStochastic.ItoSmallTimeBound


namespace ChainFountainStochastic.ItoLinearity
noncomputable section
open MeasureTheory ProbabilityTheory Real Filter Set MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM MathFin.ItoIntegralPredictable
open MathFin.ItoIntegralLocalised MathFin.LocalisationInMeasure
open MathFin.ItoIntegralProcessContinuousModification MathFin.ItoIntegralProcessGeneral
open MathFin.ItoIntegralRiemannBridge MathFin.QuadraticVariationL2
open scoped NNReal ENNReal Topology
set_option maxHeartbeats 1000000
set_option backward.isDefEq.respectTransparency true
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
  (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
  (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
  {a : ℝ≥0 → Ω → ℝ}
  (ha : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
  (hc : ∀ ω, Continuous (a · ω))
  (hp : IsStronglyPredictable (natFiltration hBm) a)
  {C : ℝ} (hb : ∀ t ω, |a t ω| ≤ C)

include hBc in
/-- Agreement of the localized predictable integral with the genuine terminal
L2 integral at an intermediate time. -/
theorem pred_terminal {t : ℝ≥0} (ht : t ≤ T) :
    predItoIntegral (μ:=μ) T hBm hp t =ᵐ[μ] itoIntCont hB hBm ha hc hb t := by
  have he := LocalIntegralBridge.continuousMod_eq_predIto hB T hBm hBc hp
    (ae_of_all _ fun ω => (hc ω).continuousOn) hb _ (processToLp_coeFn T hBm ha hc hb)
  have h := itoContinuousMod_modification hB T hBm hBc (processToLp (μ:=μ) T hBm ha hc hb) ht
  rw [itoProcessCLM_consist hB hBm le_rfl ht ha hc hb,itoProcessCLM_terminal_eq] at h
  filter_upwards [he,h] with ω he h
  exact (he t ⟨bot_le,ht⟩).symm.trans h

include hB hBc in
/-- Constant integrands integrate to the corresponding multiple of Brownian motion. -/
theorem pred_const (q : ℝ) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      predItoIntegral (μ:=μ) T hBm
        (show IsStronglyPredictable (natFiltration hBm) (fun _ _ => q) from stronglyMeasurable_const)
        t ω = q*B t ω := by
  have hsum (t : ℝ≥0) {n : ℕ} (hn : n ≠ 0) (ω : Ω) :
      riemannσ (B:=B) (fun _ _ => q) t n ω = q*(B t ω-B 0 ω) := by
    simp only [riemannσ,← Finset.mul_sum]
    rw [Finset.sum_range_sub (fun k => B (unifPart t n k) ω),unifPart_self t hn,unifPart_zero]
  have hconv (t : ℝ≥0) : TendstoInMeasure μ
      (fun n ω => riemannσ (B:=B) (fun _ _ => q) t n ω) atTop (fun ω => q*(B t ω-B 0 ω)) :=
    tendstoInMeasure_of_tendsto_ae
      (fun n => (Finset.measurable_sum _ fun k _ =>
        measurable_const.mul ((hBm _).sub (hBm _))).aestronglyMeasurable)
      (ae_of_all _ fun ω => tendsto_const_nhds.congr'
        ((eventually_ne_atTop 0).mono fun n hn => (hsum t hn ω).symm))
  filter_upwards [ae_forall_eq_of_tendstoInMeasure (T:=T)
    (Y':=fun t ω => q*(B t ω-B 0 ω))
    (ae_continuousOn_predItoIntegral hB T hBm hBc (show IsStronglyPredictable (natFiltration hBm) (fun _ _ => q) from stronglyMeasurable_const)
      (ae_of_all _ fun _ => continuousOn_const))
    (ae_of_all _ fun ω => (((hBc ω).sub continuous_const).const_mul q).continuousOn)
    (fun t ht => tendstoInMeasure_riemannσ_predItoIntegral hB T hBm hBc
      (show IsStronglyPredictable (natFiltration hBm) (fun _ _ => q) from stronglyMeasurable_const) (ae_of_all _ fun _ => continuousOn_const) ht.2)
    (fun t _ => hconv t), MathFin.ItoIntegralBrownian.eval_zero_ae hB hBm] with ω he hz t ht
  rw [he t ht,hz,Pi.zero_apply,sub_zero]

include hb in
/-- Uniform bound for the centered coefficient. -/
theorem centered_bound (q : ℝ) : ∀ t ω, |a t ω-q| ≤ C+|q| :=
  fun t ω => (abs_sub (a t ω) q).trans (add_le_add (hb t ω) le_rfl)

/-- Centering a bounded coefficient commutes with the genuine terminal integral. -/
theorem terminal_sub_const (q : ℝ) :
    itoIntCont hB hBm (fun t => (ha t).sub stronglyMeasurable_const)
      (fun ω => (hc ω).sub continuous_const) (centered_bound hb q) T =ᵐ[μ]
      fun ω => itoIntCont hB hBm ha hc hb T ω -
        itoIntCont hB hBm (fun _ => stronglyMeasurable_const) (fun _ => continuous_const)
          (θ:=fun _ _ => q) (C:=|q|) (fun _ _ => le_rfl) T ω := by
  have he : processToLp (μ:=μ) T hBm (fun t => (ha t).sub stronglyMeasurable_const)
      (fun ω => (hc ω).sub continuous_const) (centered_bound hb q) =
      processToLp (μ:=μ) T hBm ha hc hb - processToLp (μ:=μ) T hBm
        (fun _ => stronglyMeasurable_const) (fun _ => continuous_const)
        (σ:=fun _ _ => q) (C:=|q|) (fun _ _ => le_rfl) := by
    apply Lp.ext
    filter_upwards [processToLp_coeFn (μ:=μ) T hBm
      (fun t => (ha t).sub stronglyMeasurable_const) (fun ω => (hc ω).sub continuous_const)
      (centered_bound hb q), Lp.coeFn_sub (processToLp (μ:=μ) T hBm ha hc hb)
        (processToLp (μ:=μ) T hBm (fun _ => stronglyMeasurable_const) (fun _ => continuous_const)
          (σ:=fun _ _ => q) (C:=|q|) (fun _ _ => le_rfl)),
      processToLp_coeFn (μ:=μ) T hBm ha hc hb,
      processToLp_coeFn (μ:=μ) T hBm (fun _ => stronglyMeasurable_const) (fun _ => continuous_const)
        (σ:=fun _ _ => q) (C:=|q|) (fun _ _ => le_rfl)] with z h1 h2 h3 h4
    simp only [Pi.sub_apply,h3,h4] at h2
    exact h1.trans h2.symm
  simp only [itoIntCont,he,map_sub]
  exact Lp.coeFn_sub _ _

include hB hBc ha hc hb in
/-- The actual centered predictable integral, simultaneously at every time. -/
theorem pred_sub_const (q : ℝ) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      predItoIntegral (μ:=μ) T hBm (hp.sub (show IsStronglyPredictable (natFiltration hBm) (fun _ _ => q) from stronglyMeasurable_const)) t ω =
        predItoIntegral (μ:=μ) T hBm hp t ω-q*B t ω := by
  have hres := ae_continuousOn_predItoIntegral hB T hBm hBc (hp.sub (show IsStronglyPredictable (natFiltration hBm) (fun _ _ => q) from stronglyMeasurable_const))
    (ae_of_all _ fun ω => ((hc ω).sub continuous_const).continuousOn)
  have hcont := ae_continuousOn_predItoIntegral hB T hBm hBc hp
    (ae_of_all _ fun ω => (hc ω).continuousOn)
  apply ae_forall_eq_of_continuousOn hres
    (hcont.mono fun ω hω => hω.sub ((hBc ω).const_mul q).continuousOn)
  intro t ht
  filter_upwards [pred_terminal hB T hBm hBc ha hc hp hb ht.2,
    pred_terminal hB T hBm hBc (fun t => (ha t).sub stronglyMeasurable_const)
      (fun ω => (hc ω).sub continuous_const) (hp.sub (show IsStronglyPredictable (natFiltration hBm) (fun _ _ => q) from stronglyMeasurable_const)) (centered_bound hb q) ht.2,
    terminal_sub_const hB t hBm ha hc hb q,
    pred_terminal hB T hBm hBc (a:=fun _ _ => q)
      (fun _ => stronglyMeasurable_const) (fun _ => continuous_const) stronglyMeasurable_const
      (C:=|q|) (fun _ _ => le_rfl) ht.2,
    pred_const hB T hBm hBc q] with ω ha hr hs hc hq
  rw [hr,hs,← ha,← hc,hq t ht]
  rfl

end
end ChainFountainStochastic.ItoLinearity


namespace ChainFountainStochastic.ItoFreezing
noncomputable section
open MeasureTheory ProbabilityTheory Real Filter Set MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM MathFin.ItoIntegralPredictable
open MathFin.ItoIntegralBrownian
open MathFin.ItoIntegralLocalised MathFin.LocalisationInMeasure
open scoped NNReal ENNReal Topology
set_option maxHeartbeats 1000000
set_option backward.isDefEq.respectTransparency true
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
  (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hT : 0 < T)
  (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
  {a : ℝ≥0 → Ω → ℝ}
  (ha : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
  (hc : ∀ ω, Continuous (a · ω))
  (hp : IsStronglyPredictable (natFiltration hBm) a)

/-- Continuity at zero controls a whole sufficiently short prefix. -/
theorem small_prefix {f : ℝ≥0 → ℝ} (hf : ContinuousAt f 0) (hz : f 0 = 0)
    {ε : ℝ} (hε : 0 < ε) :
    ∀ᶠ t in 𝓝[>] (0:ℝ≥0), ∀ s ∈ Icc 0 t, |f s| ≤ ε := by
  have hh : ∀ᶠ s in 𝓝 (0:ℝ≥0), |f s| < ε := by
    have h := hf.abs.tendsto.eventually (gt_mem_nhds (by simpa [hz] using hε))
    exact h
  obtain ⟨δ,hδ,hd⟩ := exists_Ico_subset_of_mem_nhds hh (show ∃ δ : ℝ≥0, 0 < δ from ⟨1,by norm_num⟩)
  filter_upwards [((eventually_lt_nhds hδ).filter_mono nhdsWithin_le_nhds)] with t ht s hs
  exact (hd ⟨hs.1,hs.2.trans_lt ht⟩).le

include hB hT hBc ha hc in
/-- A continuous adapted coefficient vanishing at zero contributes o(LIL scale)
to its actual stochastic integral. No random time-change representation is assumed. -/
theorem zero_coefficient (hz : ∀ᵐ ω ∂μ, a 0 ω = 0) :
    ∀ᵐ ω ∂μ, Tendsto
      (fun t => predItoIntegral (μ:=μ) T hBm hp t ω / BrownianSmallTime.scale t)
      (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
  let e := fun n : ℕ => 1 / ((n:ℝ)+1)
  have ep : ∀ n, 0 < e n := fun n => by dsimp [e]; positivity
  let b := fun n t ω => clampM (e n) (a t ω)
  have bac : ∀ n ω, Continuous (b n · ω) := fun n ω => (continuous_clampM (e n)).comp (hc ω)
  have baa : ∀ n t, StronglyMeasurable[natFiltration hBm t] (b n t) :=
    fun n t => (continuous_clampM (e n)).comp_stronglyMeasurable (ha t)
  have bap : ∀ n, IsStronglyPredictable (natFiltration hBm) (b n) :=
    fun n => (continuous_clampM (e n)).comp_stronglyMeasurable hp
  have hab (n : ℕ) := ItoSmallTimeBound.pred_integral hB T hT hBm hBc
    (baa n) (bac n) (bap n) (ep n) (fun t ω => clampM_abs_le (ep n).le (a t ω))
  have hel (n : ℕ) := LocalIntegralBridge.predIto_prefix_locality hB T hBm hBc hp (bap n)
    (ae_of_all _ fun ω => (hc ω).continuousOn) (ae_of_all _ fun ω => (bac n ω).continuousOn)
  filter_upwards [ae_all_iff.mpr hab,ae_all_iff.mpr hel,hz] with ω hbound hlocal hz
  apply Metric.tendsto_nhds.mpr
  intro ε hε
  obtain ⟨n,hn⟩ := exists_nat_one_div_lt (show 0 < ε/4 by positivity)
  have hen : 4*e n < ε := by dsimp [e]; linarith
  filter_upwards [hbound n,small_prefix (hc ω).continuousAt hz (ep n),
    ((eventually_lt_nhds hT).filter_mono nhdsWithin_le_nhds)] with t ht hs htime
  have he := hlocal n t ⟨bot_le,htime.le⟩ (fun s hs' => (clampM_eq_self (hs s hs')).symm)
  simpa only [Real.dist_eq,sub_zero,he] using ht.trans_lt hen

include hB hT hBc ha hc in
/-- Freezing the actual bounded adapted coefficient at its deterministic
initial value is valid at the sharp small-time LIL scale. -/
theorem bounded_coefficient {C q : ℝ} (hb : ∀ t ω, |a t ω| ≤ C)
    (hz : ∀ᵐ ω ∂μ, a 0 ω = q) :
    ∀ᵐ ω ∂μ, Tendsto
      (fun t => (predItoIntegral (μ:=μ) T hBm hp t ω-q*B t ω) / BrownianSmallTime.scale t)
      (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
  have hpq : IsStronglyPredictable (natFiltration hBm) (fun t ω => a t ω-q) :=
    hp.sub (show IsStronglyPredictable (natFiltration hBm) (fun _ _ => q) from stronglyMeasurable_const)
  have hzero : ∀ᵐ ω ∂μ, a 0 ω-q = 0 := hz.mono fun ω hω => sub_eq_zero.mpr hω
  filter_upwards [zero_coefficient hB T hT hBm hBc (fun t => (ha t).sub stronglyMeasurable_const)
    (fun ω => (hc ω).sub continuous_const) hpq hzero,
    ItoLinearity.pred_sub_const hB T hBm hBc ha hc hp hb q] with ω hz he
  apply hz.congr'
  filter_upwards [((eventually_lt_nhds hT).filter_mono nhdsWithin_le_nhds)] with t ht
  rw [he t ⟨bot_le,ht.le⟩]

include hB hT hBc in
/-- The same freezing theorem for the localized continuous-adapted integral
used in the pulled-back strong SDE equation. -/
theorem local_bounded {C q : ℝ} (hb : ∀ t ω, |a t ω| ≤ C)
    (hz : ∀ᵐ ω ∂μ, a 0 ω = q) :
    ∀ᵐ ω ∂μ, Tendsto
      (fun t => (localItoIntegral (μ:=μ) T hBm ha hc t ω-q*B t ω) / BrownianSmallTime.scale t)
      (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
  let hp := isStronglyPredictable_of_bdd_adapted_cont hBm ha hc
  filter_upwards [bounded_coefficient hB T hT hBm hBc ha hc hp hb hz,
    ae_localItoIntegral_eq_itoContinuousMod hB T hBm hBc ha hc hb,
    LocalIntegralBridge.continuousMod_eq_predIto hB T hBm hBc hp
      (ae_of_all _ fun ω => (hc ω).continuousOn) hb _ (processToLp_coeFn T hBm ha hc hb)] with ω hr hl hp
  apply hr.congr'
  filter_upwards [((eventually_lt_nhds hT).filter_mono nhdsWithin_le_nhds)] with t ht
  rw [hl t ⟨bot_le,ht.le⟩,hp t ⟨bot_le,ht.le⟩]

end
end ChainFountainStochastic.ItoFreezing


namespace ChainFountainStochastic.ActualIntegralLIL
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Real MathFin BrownianSmallTime LILDriftStability
open MathFin.ItoIntegralL2 MathFin.ItoIntegralLocalised
open scoped NNReal ENNReal Topology
set_option maxHeartbeats 1000000
set_option backward.isDefEq.respectTransparency true

/-- Pathwise transfer of both LIL limits through a negligible remainder. -/
theorem transfer_nonneg {b x : ℝ≥0 → ℝ} {q : ℝ} (hq : 0 ≤ q)
    (hb : limsup (fun t => (b t/scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = 1 ∧
      liminf (fun t => (b t/scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = -1)
    (hr : Tendsto (fun t => (x t-q*b t)/scale t) (𝓝[>] (0:ℝ≥0)) (𝓝 0)) :
    limsup (fun t => (x t/scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = q ∧
      liminf (fun t => (x t/scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = -q := by
  have he (t : ℝ≥0) : (x t/scale t).toEReal =
      (q:EReal)*(b t/scale t).toEReal + ((x t-q*b t)/scale t).toEReal := by
    rw [← EReal.coe_mul,← EReal.coe_add]
    congr 1
    ring
  simp_rw [he]
  rw [limsup_add_zero hr,liminf_add_zero hr,
    EReal.limsup_const_mul_of_nonneg_of_ne_top (by exact_mod_cast hq) (by simp),
    EReal.liminf_const_mul_of_nonneg_of_ne_top (by exact_mod_cast hq) (by simp),hb.1,hb.2]
  simp

/-- A single Brownian probability-one event supports transfer for every real
initial coefficient and every path with a negligible normalized remainder. -/
theorem transfer {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω}
    {B : ℝ≥0 → Ω → ℝ} (hB : IsBrownianReal B μ) :
    ∀ᵐ ω ∂μ, ∀ q : ℝ, ∀ x : ℝ≥0 → ℝ,
      Tendsto (fun t => (x t-q*B t ω)/scale t) (𝓝[>] (0:ℝ≥0)) (𝓝 0) →
      limsup (fun t => (x t/scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = |q| ∧
      liminf (fun t => (x t/scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = -|q| := by
  filter_upwards [two_sided_zero hB,two_sided_zero hB.neg] with ω hp hn
  intro q x hr
  by_cases hq : 0 ≤ q
  · simpa only [abs_of_nonneg hq] using transfer_nonneg hq hp hr
  · have hq' : q ≤ 0 := (not_le.mp hq).le
    have hr' : Tendsto (fun t => (x t-(-q)*(-B t ω))/scale t) (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
      simpa only [neg_mul_neg] using hr
    simpa only [abs_of_nonpos hq'] using transfer_nonneg (neg_nonneg.mpr hq') hn hr'

/-- Sharp LIL for the actual stochastic integral with a bounded continuous
adapted coefficient, including a path-dependent O(t) drift. -/
theorem integral {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hT : 0 < T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
    {a : ℝ≥0 → Ω → ℝ}
    (ha : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hc : ∀ ω, Continuous (a · ω))
    (hp : IsStronglyPredictable (natFiltration hBm) a)
    {C q : ℝ} (hb : ∀ t ω, |a t ω| ≤ C) (hz : ∀ᵐ ω ∂μ, a 0 ω = q) :
    ∀ᵐ ω ∂μ, ∀ A : ℝ≥0 → ℝ, ∀ K : ℝ,
      (∀ᶠ t in 𝓝[>] (0:ℝ≥0), |A t| ≤ K*(t:ℝ)) →
      limsup (fun t => ((predItoIntegral (μ:=μ) T hBm hp t ω+A t)/scale t).toEReal)
        (𝓝[>] (0:ℝ≥0)) = |q| ∧
      liminf (fun t => ((predItoIntegral (μ:=μ) T hBm hp t ω+A t)/scale t).toEReal)
        (𝓝[>] (0:ℝ≥0)) = -|q| := by
  filter_upwards [transfer (show IsBrownianReal B μ from ⟨hB,ae_of_all _ hBc⟩),
    ItoFreezing.bounded_coefficient hB T hT hBm hBc ha hc hp hb hz] with ω ht hr
  intro A K hA
  apply ht q
  convert hr.add (bounded_drift_negligible hA) using 1
  · ext t
    ring
  · simp

end
end ChainFountainStochastic.ActualIntegralLIL


namespace ChainFountainStochastic.MechanicalSmallTime
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Real MathFin ChainFountain
open MathFin.ItoIntegralL2 MathFin.ItoIntegralLocalised MathFin.AdaptedDrift
open MathFin.ItoFormulaAdapted
open VectorSDE GlobalCutoffSDE MechanicalCutoff CutoffExhaustion
open ConullBrownian RegularRealization BrownianSmallTime
open scoped NNReal ENNReal Topology
set_option maxHeartbeats 1500000
set_option backward.isDefEq.respectTransparency true

/-- The leading stochastic term of an actual constructed coordinate on a
continuous measure-preserving realization. Its SDE equation is derived from
the global strong solution. -/
theorem coordinate_leading
    {Ω Ω' : Type*} [MeasurableSpace Ω] [MeasurableSpace Ω']
    {μ : Measure Ω} {ν : Measure Ω'} [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
    (c : Coefficients (Fin 3)) (x₀ : State) {Y : ℝ≥0 → Ω → State}
    (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖c.drift t x‖ ≤ c.bound)
    {f : Ω' → Ω} (hf : MeasurableEmbedding f) (hm : MeasurePreserving f ν μ)
    (hYf : ∀ ω, Continuous (fun t => Y t (f ω))) (i : Fin 3) :
    ∀ᵐ ω ∂ν, Tendsto
      (fun t => (Y t (f ω) i-x₀ i-c.diffusion 0 x₀ i*B t (f ω))/scale t)
      (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
  obtain ⟨ha,hc,he⟩ := strong_solution_pullback_equation hB 1 hBm hBc c x₀ hY hb hf hm hYf i
  have hab : ∀ t ω, |c.diffusion t (Y t (f ω)) i| ≤ c.bound :=
    fun t ω => (norm_le_pi_norm (c.diffusion t (Y t (f ω))) i).trans (hb t _)
  have hz : ∀ᵐ ω ∂ν, c.diffusion 0 (Y 0 (f ω)) i = c.diffusion 0 x₀ i :=
    ae_of_all _ fun ω => by rw [(hY 0).initial]
  have hl := ItoFreezing.local_bounded (preBrownian_pullback hB hm) 1 (by norm_num)
    (fun t => (hBm t).comp hf.measurable) (fun ω => hBc (f ω)) ha hc hab hz
  let d := fun t ω => c.drift t (Y t (f ω)) i
  have hdc : ∀ ω, Continuous (d · ω) := fun ω =>
    (continuous_apply i).comp (c.drift_continuous.comp (continuous_id.prodMk (hYf ω)))
  have hdb : ∀ t ω, |d t ω| ≤ c.bound :=
    fun t ω => (norm_le_pi_norm (c.drift t (Y t (f ω))) i).trans (hd t _)
  filter_upwards [he,hl] with ω he hl
  have hdt : Tendsto (fun t => driftPath d t ω/scale t) (𝓝[>] (0:ℝ≥0)) (𝓝 0) :=
    LILDriftStability.bounded_drift_negligible (Eventually.of_forall fun t => by
      simpa [driftPath] using abs_driftPath_sub_le hdc hdb (s:=0) (t:=t) (show 0 ≤ t from bot_le) ω)
  have hs : Tendsto (fun t =>
      (localItoIntegral (μ:=ν) 1 (fun t => (hBm t).comp hf.measurable) ha hc t ω-
        c.diffusion 0 x₀ i*B t (f ω))/scale t + driftPath d t ω/scale t)
      (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by simpa only [zero_add] using hl.add hdt
  apply hs.congr'
  filter_upwards [((eventually_lt_nhds (by norm_num : (0:ℝ≥0) < 1)).filter_mono nhdsWithin_le_nhds)] with t ht
  rw [he t ⟨bot_le,ht.le⟩]
  dsimp [localItoProcess,d]
  ring

/-- Leading term of the crown coordinate of an actual strong vector SDE. -/
theorem crown_leading_realization
    {Ω Ω' : Type*} [MeasurableSpace Ω] [MeasurableSpace Ω']
    {μ : Measure Ω} {ν : Measure Ω'} [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
    (c : Coefficients (Fin 3)) (x₀ : State) {Y : ℝ≥0 → Ω → State}
    (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖c.drift t x‖ ≤ c.bound)
    {f : Ω' → Ω} (hf : MeasurableEmbedding f) (hm : MeasurePreserving f ν μ)
    (hYf : ∀ ω, Continuous (fun t => Y t (f ω))) :
    ∀ᵐ ω ∂ν, Tendsto (fun t =>
      ((Y t (f ω) 1+Y t (f ω) 2-x₀ 1-x₀ 2)/2-
        ((c.diffusion 0 x₀ 1+c.diffusion 0 x₀ 2)/2)*B t (f ω))/scale t)
      (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
  filter_upwards [coordinate_leading hB hBm hBc c x₀ hY hb hd hf hm hYf 1,
    coordinate_leading hB hBm hBc c x₀ hY hb hd hf hm hYf 2] with ω h1 h2
  convert (h1.add h2).div_const 2 using 1
  · ext t
    ring
  · simp

/-- The crown expansion on the original probability space of the constructed
cutoff solution. Continuity is obtained on a conull realization and transported back. -/
theorem cutoff_crown_leading
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
    (c : Coefficients (Fin 3)) (x₀ : State) {Y : ℝ≥0 → Ω → State}
    (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖c.drift t x‖ ≤ c.bound) :
    ∀ᵐ ω ∂μ, Tendsto (fun t =>
      ((Y t ω 1+Y t ω 2-x₀ 1-x₀ 2)/2-
        ((c.diffusion 0 x₀ 1+c.diffusion 0 x₀ 2)/2)*B t ω)/scale t)
      (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
  obtain ⟨G,hG,hGa,hgood⟩ := exists_measurable_conull (global_strong_solution_continuous hBm c x₀ hY)
  let ν := μ.comap ((↑) : G → Ω)
  have hm : MeasurePreserving ((↑) : G → Ω) ν μ := conull_subtype_preserving hG hGa
  letI : IsProbabilityMeasure ν := hm.hasLaw.isProbabilityMeasure
  have hf : MeasurableEmbedding ((↑) : G → Ω) := MeasurableEmbedding.subtype_coe hG
  have he := crown_leading_realization hB hBm hBc c x₀ hY hb hd hf hm
    (fun ω => hgood ω.val ω.property)
  rw [← hm.map_eq,hf.ae_map_iff]
  exact he

/-- Every positive lifetime contains a deterministic neighbourhood of zero on
each sample path. The neighbourhood may depend on that path. -/
theorem eventually_before {τ : WithTop ℝ≥0} (hτ : 0 < τ) :
    ∀ᶠ t : ℝ≥0 in 𝓝[>] (0:ℝ≥0), (t:WithTop ℝ≥0) < τ := by
  by_cases he : τ = ⊤
  · exact Eventually.of_forall fun t => by rw [he]; exact WithTop.coe_lt_top t
  · have hu : (τ.untopA:WithTop ℝ≥0) = τ := by
      rw [WithTop.untopA_eq_untop he]
      exact WithTop.coe_untop _ _
    have hp : (0:ℝ≥0) < τ.untopA := WithTop.coe_lt_coe.mp (by simpa only [hu,WithTop.coe_zero] using hτ)
    filter_upwards [((eventually_lt_nhds hp).filter_mono nhdsWithin_le_nhds)] with t ht
    exact hu ▸ WithTop.coe_lt_coe.mpr ht

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
  {B : ℝ≥0 → Ω → ℝ} {hBm : ∀ t, Measurable (B t)}
  {a : Parameters} {p : ℝ≥0 → State} {x₀ : State}

/-- Mechanical coefficient in the crown's actual stochastic integral. -/
def crownDiffusion (a : Parameters) (x : State) : ℝ := a.noise*(x 1)^2/(2*x 0)

/-- The constructed maximal mechanical solution has the frozen leading
Brownian coefficient sigma*v0^2/(2*h0), before its genuine positive exit. -/
theorem maximal_crown_leading (hB : IsPreBrownianReal B μ)
    (hBc : ∀ ω, Continuous (B · ω)) (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ, Tendsto (fun t =>
      ((F.process t ω 1+F.process t ω 2-x₀ 1-x₀ 2)/2-
        crownDiffusion a x₀*B t ω)/scale t) (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
  have hd := (F.agrees 0 0 x₀ (by simpa using F.initial_inside.le)).2
  have hq : ((F.c 0).diffusion 0 x₀ 1+(F.c 0).diffusion 0 x₀ 2)/2 = crownDiffusion a x₀ := by
    rw [hd]
    simp [Parameters.diffusion,crownDiffusion]
    ring
  filter_upwards [cutoff_crown_leading hB hBm hBc (F.c 0) x₀ (F.strong 0)
    (F.bound 0) (F.drift_bound 0),F.process_eq_before_exit] with ω hl he
  rw [hq] at hl
  apply hl.congr'
  filter_upwards [eventually_before ((F.exit_properties 0).2.1 ω)] with t ht
  rw [(he 0 t ht.le).2]

/-- Both sharp small-time LIL limits for the actual constructed maximal
mechanical solution, on its original probability space. -/
theorem maximal_crown_lil (hB : IsPreBrownianReal B μ)
    (hBc : ∀ ω, Continuous (B · ω)) (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ,
      limsup (fun t => ((F.process t ω 1+F.process t ω 2-x₀ 1-x₀ 2)/2/scale t).toEReal)
        (𝓝[>] (0:ℝ≥0)) = |crownDiffusion a x₀| ∧
      liminf (fun t => ((F.process t ω 1+F.process t ω 2-x₀ 1-x₀ 2)/2/scale t).toEReal)
        (𝓝[>] (0:ℝ≥0)) = -|crownDiffusion a x₀| := by
  filter_upwards [maximal_crown_leading hB hBc F,
    ActualIntegralLIL.transfer (show IsBrownianReal B μ from ⟨hB,ae_of_all _ hBc⟩)] with ω hl ht
  exact ht (crownDiffusion a x₀) _ hl


/-- Exact unit normalization of the mechanical crown LIL. -/
theorem maximal_crown_normalized_lil (hB : IsPreBrownianReal B μ)
    (hBc : ∀ ω, Continuous (B · ω)) (F : Family (μ:=μ) hBm a p x₀)
    (hq : crownDiffusion a x₀ ≠ 0) :
    ∀ᵐ ω ∂μ,
      limsup (fun t => ((F.process t ω 1+F.process t ω 2-x₀ 1-x₀ 2)/2/
        (|crownDiffusion a x₀| * scale t)).toEReal) (𝓝[>] (0:ℝ≥0)) = 1 ∧
      liminf (fun t => ((F.process t ω 1+F.process t ω 2-x₀ 1-x₀ 2)/2/
        (|crownDiffusion a x₀| * scale t)).toEReal) (𝓝[>] (0:ℝ≥0)) = -1 := by
  filter_upwards [maximal_crown_lil hB hBc F] with ω hl
  have he (t : ℝ≥0) : ((F.process t ω 1+F.process t ω 2-x₀ 1-x₀ 2)/2/
        (|crownDiffusion a x₀| * scale t)).toEReal =
      (|crownDiffusion a x₀|⁻¹).toEReal*
        ((F.process t ω 1+F.process t ω 2-x₀ 1-x₀ 2)/2/scale t).toEReal := by
    rw [← EReal.coe_mul]
    congr 1
    ring
  simp_rw [he]
  rw [EReal.limsup_const_mul_of_nonneg_of_ne_top (by positivity) (by simp),
    EReal.liminf_const_mul_of_nonneg_of_ne_top (by positivity) (by simp),hl.1,hl.2]
  norm_cast
  constructor
  · exact inv_mul_cancel₀ (abs_ne_zero.mpr hq)
  · rw [mul_neg,inv_mul_cancel₀ (abs_ne_zero.mpr hq)]
    simp

/-- Nonzero physical noise and positive initial rise speed give a nonzero
crown diffusion at every positive-height initial state. -/
theorem crownDiffusion_ne_zero (hσ : a.noise ≠ 0) (hv : x₀ 1 ≠ 0) (hh : x₀ 0 ≠ 0) :
    crownDiffusion a x₀ ≠ 0 := by
  dsimp [crownDiffusion]
  exact div_ne_zero (mul_ne_zero hσ (pow_ne_zero 2 hv)) (mul_ne_zero (by norm_num) hh)

/-- A negative LIL lower limit forces negative values arbitrarily near zero. -/
theorem negative_germ {x : ℝ≥0 → ℝ} {q : ℝ} (hq : q ≠ 0)
    (hl : liminf (fun t => (x t/scale t).toEReal) (𝓝[>] (0:ℝ≥0)) = -|q|) :
    ∃ᶠ t in 𝓝[>] (0:ℝ≥0), x t < 0 := by
  have hf : ∃ᶠ t in 𝓝[>] (0:ℝ≥0), (x t/scale t).toEReal < 0 :=
    frequently_lt_of_liminf_lt (by isBoundedDefault) (by
      rw [hl]
      exact_mod_cast neg_neg_of_pos (abs_pos.mpr hq))
  apply hf.mono
  intro t ht
  have hr : x t/scale t < 0 := by exact_mod_cast ht
  rcases div_neg_iff.mp hr with h | h
  · exact (not_lt_of_ge (sqrt_nonneg _) h.2).elim
  · exact h.1

/-- Almost-sure failure of crown-boundary invariance for the actual maximal
mechanical SDE, at arbitrarily small positive times before its genuine exit. -/
theorem boundary_negative (hB : IsPreBrownianReal B μ)
    (hBc : ∀ ω, Continuous (B · ω)) (F : Family (μ:=μ) hBm a p x₀)
    (hσ : a.noise ≠ 0) (hv : x₀ 1 ≠ 0) (hh : x₀ 0 ≠ 0)
    {vmin : ℝ} (hboundary : (x₀ 1+x₀ 2)/2 = vmin) :
    ∀ᵐ ω ∂μ, ∀ ε : ℝ≥0, 0 < ε → ∃ t : ℝ≥0,
      0 < t ∧ t < ε ∧ (t:WithTop ℝ≥0) < F.exit 0 ω ∧
      (t:WithTop ℝ≥0) < F.lifetime ω ∧
      (F.process t ω 1+F.process t ω 2)/2-vmin < 0 := by
  filter_upwards [maximal_crown_lil hB hBc F] with ω hl
  have hn := negative_germ (crownDiffusion_ne_zero hσ hv hh) hl.2
  intro ε hε
  have hpos : ∀ᶠ t : ℝ≥0 in 𝓝[>] (0:ℝ≥0), 0 < t := self_mem_nhdsWithin
  obtain ⟨t,htneg,htpos,htε,htτ⟩ := (hn.and_eventually
    (hpos.and (((eventually_lt_nhds hε).filter_mono nhdsWithin_le_nhds).and
      (eventually_before ((F.exit_properties 0).2.1 ω))))).exists
  refine ⟨t,htpos,htε,htτ,htτ.trans_le (le_iSup (fun n => F.exit n ω) 0),?_⟩
  rw [← hboundary]
  linarith

/-- End-to-end existence with the sharp crown LIL from mechanical model data.
No stochastic trajectory or Brownian time-change representation is supplied. -/
theorem exists_mechanical_crown_lil (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
    (a : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi : State) (hpmem : ∀ t, p t ∈ Icc plo phi)
    (x₀ : State) (hh : 0 < x₀ 0) :
    ∃ F : Family (μ:=μ) hBm a p x₀,
      (∀ ω, 0 < F.lifetime ω) ∧
      ∀ᵐ ω ∂μ,
        limsup (fun t => ((F.process t ω 1+F.process t ω 2-x₀ 1-x₀ 2)/2/scale t).toEReal)
          (𝓝[>] (0:ℝ≥0)) = |crownDiffusion a x₀| ∧
        liminf (fun t => ((F.process t ω 1+F.process t ω 2-x₀ 1-x₀ 2)/2/scale t).toEReal)
          (𝓝[>] (0:ℝ≥0)) = -|crownDiffusion a x₀| := by
  obtain ⟨F⟩ := exists_family hB hBm hBc a p hp plo phi hpmem x₀ hh
  exact ⟨F,F.lifetime_positive,maximal_crown_lil hB hBc F⟩

end
end ChainFountainStochastic.MechanicalSmallTime
