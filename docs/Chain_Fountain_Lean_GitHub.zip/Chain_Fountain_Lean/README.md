# Chain fountain: completed article formalization, v0.19.0

Author: Latchezar Tomov.

The current complete entry point is `ChainFountainCompletion.lean`. It joins
the deterministic and stochastic baseline, zero-gravity reconstruction, and
the remaining article deductions. The default Lake target is this full entry point.

The release audit rebuilt the combined project with the pinned Lean 4.33.0-rc1
environment and checked the transitive axioms of **every project-owned kernel
declaration**, including generated helpers. The source inventory contains
**722 authored theorems in 116 source modules**. The kernel export has
1672 declarations; kernel-generated declarations are not additional paper claims.
Only `propext`, `Classical.choice`, and `Quot.sound` occur in their transitive
axiom dependencies. There are no project `sorry`, `admit`, or custom axioms.

## Reproduce the complete check

Install Lean 4, Git and Python 3, open this directory, and run:

```console
python verify.py
```

On Windows use `py -3 verify.py` or `Check-ChainFountain.ps1`.
The existing `--zero-gravity` flag is accepted for compatibility: zero gravity
is always included now. Use `--skip-download` only after the pinned dependencies
and Mathlib cache have been installed. No command updates the dependency pins.
For an already prepared environment, the full build and axiom audit are:

```console
python verification/check_completion.py
python verification/build_completion_map.py
```

The verification records are in `verification/completion/`. In particular,
`summary.json` records source hashes and the build result, `environment.json`
contains actual elaborated types, dependencies and transitive axioms, and
`claims.json` maps the completion claims to their formal entry points.
`Chain_Fountain_Completion_Map.html` is a standalone searchable map with source
proofs and exact hypotheses. Its green status requires the successful audit and
matching source hashes; it is not inferred from names or theorem counts.

## Completed article deductions

- Finite-source integral, exact first depletion, positive remaining supply,
  rational-flow decay, passive input and pickup tension.
- Spatial kinetic-energy integral, zero internal-tension work, actual external-force power, AC energy and genuine integrated power balance.
- Actual spatial angular-momentum and torque integrals, their integrability,
  phase invariance, zero force resultant and reaction torque.
- Hausdorff non-attraction of distinct compact spatial images, identical speed
  outputs, and arbitrarily close translated examples in a fixed spatial frame.
- Constructed global C2 arclength reparameterization, inverse coordinate,
  unit speed, preserved image and integrated-length period.
- Actual localized stochastic-integral freezing without a global coefficient
  bound, its two-sided LIL, and restriction before a positive random stop.

## Historical companions and scope

`Chain_Fountain_Live.lean` is the historical 557-theorem v0.16 single-file
baseline, not the current complete entry point. The unchanged
`browser-companion/Chain_Fountain_Mathlib_Live.lean` is the historical
350-theorem Mathlib-only browser companion tested with Lean 4.35.0 and
4.36.0-rc2. It excludes stochastic proofs and the v0.19 additions. Those
browser validations do not substitute for the full pinned-project audit.

The stochastic construction uses the Brownian natural filtration and its
augmentation as stated in the paper; it has a maximal local lifetime, not a
proved infinite lifetime. The shape result concerns a fixed spatial frame,
not equivalence modulo rigid motions or transverse stability. Model assumptions,
experimental validity and floating-point simulation are not certified by Lean.
General spatial PDE well-posedness, localized contact actuators and stochastic
shape dynamics remain separate research objectives, not claims of this release.

The mathematical proofs in the pre-existing modules are preserved. The new
completion modules, entry points, verification and correspondence documents
are the changes in v0.19. Three blanket Mathlib imports were replaced by
`ChainFountain.MathlibSupport`, using the explicit imports already exercised by
the browser companion. The current module headers were also adopted in 111
files; 9 eligible files already used them. The guarded migration preserved every
original declaration and proof body, and the 109 pre-existing modules retain
identical mathematical text. The source backups and machine-checked records
are in `verification/completion/module-header-originals/`,
`module-header-migration.json`, `baseline-preservation.json`, and
`import-compatibility-originals/`. The kernel exporter deliberately remains a
legacy importer so that private/generated declarations and theorem proof
values are loaded for the transitive axiom audit. Dependencies and their original attribution/license
notices are retained. This package contains sources and evidence, not dependency
caches or compiler binaries.
