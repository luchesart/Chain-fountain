module

public import ChainFountainStochastic.VectorLp
public import ChainFountainStochastic.SDEUniqueness

@[expose] public section
namespace ChainFountainStochastic.VectorSDE
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology
open scoped NNReal ENNReal
open MathFin MathFin.SDEExistence MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM
  MathFin.ItoIntegralProcess MathFin.ItoIntegralProcessGeneral
  MathFin.ItoIntegralProcessContinuousModification
open VectorLp SDEContinuous
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 500000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Jointly continuous time-dependent, spatially Lipschitz coupled coefficients.
The bound is only at the spatial origin; the fields need not be bounded. -/
structure Coefficients (ι : Type*) [Fintype ι] where
  drift : ℝ≥0 → (ι → ℝ) → (ι → ℝ)
  diffusion : ℝ≥0 → (ι → ℝ) → (ι → ℝ)
  drift_continuous : Continuous (Function.uncurry drift)
  diffusion_continuous : Continuous (Function.uncurry diffusion)
  Lb : ℝ≥0
  Lσ : ℝ≥0
  drift_lipschitz : ∀ t, LipschitzWith Lb (drift t)
  diffusion_lipschitz : ∀ t, LipschitzWith Lσ (diffusion t)
  bound : ℝ
  drift_zero : ∀ t, ‖drift t 0‖ ≤ bound
  diffusion_zero : ∀ t, ‖diffusion t 0‖ ≤ bound

/-- Deterministic time is measurable for the predictable sigma algebra. -/
theorem clock_predictable (hBm : ∀ t, Measurable (B t)) :
    StronglyMeasurable[(natFiltration hBm).predictable]
      (Prod.fst : ℝ≥0 × Ω → ℝ≥0) := by
  exact StronglyAdapted.isStronglyPredictable_of_leftContinuous
    (fun _ => stronglyMeasurable_const) (fun _ _ => continuous_id.continuousWithinAt)

abbrev ProcessLp (T : ℝ≥0) (hBm : ∀ t, Measurable (B t)) :=
  Lp (ι → ℝ) 2 (trimMeasure_T (μ:=μ) T hBm)

def Coefficients.driftLp (c : Coefficients ι) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (X : ProcessLp (μ:=μ) (ι:=ι) T hBm) :=
  coefficientLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.drift_continuous c.drift_lipschitz
    (fun z : ℝ≥0 × Ω => c.drift_zero z.1) X

def Coefficients.diffusionLp (c : Coefficients ι) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (X : ProcessLp (μ:=μ) (ι:=ι) T hBm) :=
  coefficientLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.diffusion_continuous c.diffusion_lipschitz
    (fun z : ℝ≥0 × Ω => c.diffusion_zero z.1) X

def vectorDrift (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (φ : ProcessLp (μ:=μ) (ι:=ι) T hBm) (t : ℝ≥0) (ω : Ω) (i : ι) : ℝ :=
  driftContinuousMod T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ) t ω

def vectorIto (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (ψ : ProcessLp (μ:=μ) (ι:=ι) T hBm) (t : ℝ≥0) (ω : Ω) (i : ι) : ℝ :=
  itoContinuousMod T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i ψ) t ω

def picard (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (X : ProcessLp (μ:=μ) (ι:=ι) T hBm) :=
  Lp.const 2 _ x₀ +
    liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (driftProcessAssembled (μ:=μ) T hBm) (c.driftLp T hBm X) +
    liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (itoProcessAssembled hB T hBm hBc) (c.diffusionLp T hBm X)

def contractionFactor (c : Coefficients ι) (T : ℝ≥0) : ℝ :=
  (Fintype.card ι : ℝ) * ((T:ℝ)*c.Lb + Real.sqrt (T:ℝ)*c.Lσ)

theorem picard_sub_norm_le (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (X Y : ProcessLp (μ:=μ) (ι:=ι) T hBm) :
    ‖picard hB T hBm hBc c x₀ X-picard hB T hBm hBc c x₀ Y‖
      ≤ contractionFactor c T * ‖X-Y‖ := by
  have hd : ∀ U V : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm),
      ‖driftProcessAssembled (μ:=μ) T hBm U-driftProcessAssembled (μ:=μ) T hBm V‖
        ≤ (T:ℝ)*‖U-V‖ := fun U V => by
    rw [←map_sub]; exact driftProcessAssembled_norm_le T hBm _
  have hi : ∀ U V : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm),
      ‖itoProcessAssembled hB T hBm hBc U-itoProcessAssembled hB T hBm hBc V‖
        ≤ Real.sqrt (T:ℝ)*‖U-V‖ := fun U V => by
    rw [←itoProcessAssembled_sub]; exact itoProcessAssembled_norm_le hB T hBm hBc _
  have hbd := coefficientLp_sub_norm_le (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.drift_continuous
    c.drift_lipschitz (fun z : ℝ≥0 × Ω => c.drift_zero z.1) X Y
  have hsd := coefficientLp_sub_norm_le (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.diffusion_continuous
    c.diffusion_lipschitz (fun z : ℝ≥0 × Ω => c.diffusion_zero z.1) X Y
  rw [picard,picard,show ∀ a b d e f : ProcessLp (μ:=μ) (ι:=ι) T hBm,
    (a+b+d)-(a+e+f)=(b-e)+(d-f) from fun _ _ _ _ _ => by abel]
  calc
    _ ≤ _ := norm_add_le _ _
    _ ≤ (Fintype.card ι:ℝ)*(T:ℝ)*‖c.driftLp T hBm X-c.driftLp T hBm Y‖ +
        (Fintype.card ι:ℝ)*Real.sqrt (T:ℝ)*‖c.diffusionLp T hBm X-c.diffusionLp T hBm Y‖ :=
      add_le_add (liftOperator_sub_norm_le (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) T.coe_nonneg hd _ _)
        (liftOperator_sub_norm_le (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (Real.sqrt_nonneg _) hi _ _)
    _ ≤ (Fintype.card ι:ℝ)*(T:ℝ)*(c.Lb*‖X-Y‖) +
        (Fintype.card ι:ℝ)*Real.sqrt (T:ℝ)*(c.Lσ*‖X-Y‖) :=
      add_le_add (mul_le_mul_of_nonneg_left hbd (by positivity))
        (mul_le_mul_of_nonneg_left hsd (by positivity))
    _ = _ := by dsimp [contractionFactor]; ring

/-- Banach's theorem for the full coupled vector state. -/
theorem picard_exists_unique_fixedPoint (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (hc : contractionFactor c T < 1) :
    ∃! X, picard hB T hBm hBc c x₀ X = X := by
  have hq : 0 ≤ contractionFactor c T := by dsimp [contractionFactor]; positivity
  have hcontract : ContractingWith (Real.toNNReal (contractionFactor c T))
      (picard hB T hBm hBc c x₀) := by
    refine ⟨?_,LipschitzWith.of_dist_le_mul fun X Y => ?_⟩
    · rw [←NNReal.coe_lt_coe,Real.coe_toNNReal _ hq,NNReal.coe_one]; exact hc
    · rw [dist_eq_norm,dist_eq_norm,Real.coe_toNNReal _ hq]
      exact picard_sub_norm_le hB T hBm hBc c x₀ X Y
  exact ⟨hcontract.fixedPoint _,hcontract.fixedPoint_isFixedPt,
    fun _ he => hcontract.fixedPoint_unique he⟩

theorem picard_coe (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (X : ProcessLp (μ:=μ) (ι:=ι) T hBm) :
    ⇑(picard hB T hBm hBc c x₀ X) =ᵐ[trimMeasure_T (μ:=μ) T hBm]
      fun z => x₀ + vectorDrift T hBm (c.driftLp T hBm X) z.1 z.2 +
        vectorIto T hBm (c.diffusionLp T hBm X) z.1 z.2 := by
  let φ := c.driftLp T hBm X
  let ψ := c.diffusionLp T hBm X
  have hd : ⇑(liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (driftProcessAssembled (μ:=μ) T hBm) φ)
      =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry (vectorDrift T hBm φ) := by
    filter_upwards [assembleLp_coe (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (fun i => driftProcessAssembled (μ:=μ) T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ)),
      ae_all_iff.mpr (fun i : ι => driftProcessAssembled_coeFn T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ))] with z hz hi
    exact hz.trans (funext hi)
  have hi : ⇑(liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (itoProcessAssembled hB T hBm hBc) ψ)
      =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry (vectorIto T hBm ψ) := by
    have he : ∀ i : ι, ⇑(itoProcessAssembled hB T hBm hBc (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i ψ))
        =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry (itoContinuousMod T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i ψ)) :=
      fun i => (memLp_itoContinuousMod hB T hBm hBc (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i ψ)).coeFn_toLp
    filter_upwards [assembleLp_coe (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (fun i => itoProcessAssembled hB T hBm hBc (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i ψ)),
      ae_all_iff.mpr he] with z hz hi
    exact hz.trans (funext hi)
  filter_upwards [Lp.coeFn_add
    (Lp.const 2 _ x₀+liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (driftProcessAssembled (μ:=μ) T hBm) φ)
    (liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (itoProcessAssembled hB T hBm hBc) ψ),
    Lp.coeFn_add (Lp.const 2 _ x₀) (liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (driftProcessAssembled (μ:=μ) T hBm) φ),
    Lp.coeFn_const (p:=2) (μ:=trimMeasure_T (μ:=μ) T hBm) (c:=x₀),hd,hi]
    with z h1 h2 h0 hd hi
  change (Lp.const 2 _ x₀+liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (driftProcessAssembled (μ:=μ) T hBm) φ+
    liftOperator (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (itoProcessAssembled hB T hBm hBc) ψ : ProcessLp (μ:=μ) (ι:=ι) T hBm) z = _
  simp only [h1,h2,h0,hd,hi,Pi.add_apply,Function.const_apply,Function.uncurry]
  rfl

/-- A continuous predictable solution of the actual coupled time-dependent SDE.
All coordinates use the same Brownian motion; each coefficient may depend on
the entire state. The equation holds at all times on one conull event. -/
structure StrongSolution (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (c : Coefficients ι) (x₀ : ι → ℝ) (Y : ℝ≥0 → Ω → (ι → ℝ)) : Prop where
  predictable : IsStronglyPredictable (natFiltration hBm) Y
  continuous : ∀ᵐ ω ∂μ, ContinuousOn (fun t => Y t ω) (Icc 0 T)
  initial : ∀ ω, Y 0 ω = x₀
  state_memLp : MemLp (Function.uncurry Y) 2 (trimMeasure_T (μ:=μ) T hBm)
  drift_memLp : MemLp (fun z : ℝ≥0 × Ω => c.drift z.1 (Y z.1 z.2)) 2 (trimMeasure_T (μ:=μ) T hBm)
  diffusion_memLp : MemLp (fun z : ℝ≥0 × Ω => c.diffusion z.1 (Y z.1 z.2)) 2 (trimMeasure_T (μ:=μ) T hBm)
  equation : ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → ∀ i : ι,
    Y t ω i = x₀ i + (∫ s in Ioc (0:ℝ≥0) t, c.drift s (Y s ω) i ∂timeMeasure) +
      vectorIto T hBm (diffusion_memLp.toLp (fun z => c.diffusion z.1 (Y z.1 z.2))) t ω i

theorem vectorDrift_predictable (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (φ : ProcessLp (μ:=μ) (ι:=ι) T hBm) :
    IsStronglyPredictable (natFiltration hBm) (vectorDrift T hBm φ) := by
  letI : MeasurableSpace (ℝ≥0 × Ω) := (natFiltration hBm).predictable
  exact (measurable_pi_lambda _ (fun i =>
    (driftContinuousMod_isStronglyPredictable T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ)).measurable)).stronglyMeasurable

theorem vectorIto_predictable (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (ψ : ProcessLp (μ:=μ) (ι:=ι) T hBm) :
    IsStronglyPredictable (natFiltration hBm) (vectorIto T hBm ψ) := by
  letI : MeasurableSpace (ℝ≥0 × Ω) := (natFiltration hBm).predictable
  exact (measurable_pi_lambda _ (fun i =>
    (itoContinuousMod_isStronglyPredictable hB T hBm hBc (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i ψ)).measurable)).stronglyMeasurable

theorem vectorDrift_continuous (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (φ : ProcessLp (μ:=μ) (ι:=ι) T hBm) :
    ∀ᵐ ω ∂μ, ContinuousOn (fun t => vectorDrift T hBm φ t ω) (Icc 0 T) := by
  filter_upwards [ae_all_iff.mpr (fun i : ι => drift_mod_continuousOn T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ))]
    with ω hω
  exact continuousOn_pi.2 hω

theorem vectorIto_continuous (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (ψ : ProcessLp (μ:=μ) (ι:=ι) T hBm) :
    ∀ᵐ ω ∂μ, ContinuousOn (fun t => vectorIto T hBm ψ t ω) (Icc 0 T) := by
  filter_upwards [ae_all_iff.mpr (fun i : ι =>
    itoContinuousMod_continuousOn hB T hBm hBc (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i ψ))] with ω hω
  exact continuousOn_pi.2 hω

/-- One conull event carries every coordinate drift identity at every time. -/
theorem vectorDrift_integral_all_times (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (φ : ProcessLp (μ:=μ) (ι:=ι) T hBm) {f : ℝ≥0 × Ω → (ι → ℝ)}
    (hf : ⇑φ =ᵐ[trimMeasure_T (μ:=μ) T hBm] f) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → ∀ i : ι,
      vectorDrift T hBm φ t ω i = ∫ s in Ioc (0:ℝ≥0) t, f (s,ω) i ∂timeMeasure := by
  have he : ∀ i : ι, ⇑(evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ) =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => f z i := by
    intro i
    filter_upwards [evalLp_coe (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ,hf] with z hi hz
    exact hi.trans (congrFun hz i)
  filter_upwards [ae_all_iff.mpr (fun i : ι => drift_mod_integral_all_times T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ)),
    ae_all_iff.mpr (fun i : ι => ae_path_of_trim_eq T hBm (he i))] with ω hd he
  intro t ht i
  change driftContinuousMod T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ) t ω = _
  rw [hd i t ht]
  exact integral_congr_ae ((he i).filter_mono
    (ae_mono (Measure.restrict_mono (Ioc_subset_Ioc_right ht) le_rfl)))

/-- Realize the coupled vector fixed point with its actual trajectory coefficients. -/
theorem realize_fixed_point (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (X : ProcessLp (μ:=μ) (ι:=ι) T hBm)
    (hfix : picard hB T hBm hBc c x₀ X = X) :
    ∃ Y : ℝ≥0 → Ω → (ι → ℝ), StrongSolution (μ:=μ) T hBm c x₀ Y ∧
      ⇑X =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry Y := by
  let φ := c.driftLp T hBm X
  let ψ := c.diffusionLp T hBm X
  let Y : ℝ≥0 → Ω → (ι → ℝ) := fun t ω =>
    x₀ + vectorDrift T hBm φ t ω + vectorIto T hBm ψ t ω
  have hX : ⇑X =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry Y := by
    filter_upwards [picard_coe hB T hBm hBc c x₀ X] with z hz
    rw [hfix] at hz
    exact hz
  have hφ : ⇑φ =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => c.drift z.1 (Y z.1 z.2) := by
    filter_upwards [coefficientLp_coe (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.drift_continuous
      c.drift_lipschitz (fun z : ℝ≥0 × Ω => c.drift_zero z.1) X,hX] with z hc hz
    exact hc.trans (congrArg (c.drift z.1) hz)
  have hψ : ⇑ψ =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => c.diffusion z.1 (Y z.1 z.2) := by
    filter_upwards [coefficientLp_coe (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.diffusion_continuous
      c.diffusion_lipschitz (fun z : ℝ≥0 × Ω => c.diffusion_zero z.1) X,hX] with z hc hz
    exact hc.trans (congrArg (c.diffusion z.1) hz)
  have hYm := (Lp.memLp X).ae_eq hX
  have hφm := (Lp.memLp φ).ae_eq hφ
  have hψm := (Lp.memLp ψ).ae_eq hψ
  have hψclass : hψm.toLp (fun z : ℝ≥0 × Ω => c.diffusion z.1 (Y z.1 z.2)) = ψ :=
    (MemLp.toLp_congr hψm (Lp.memLp ψ) hψ.symm).trans (Lp.toLp_coeFn ψ (Lp.memLp ψ))
  refine ⟨Y,⟨?_,?_,?_,hYm,hφm,hψm,?_⟩,hX⟩
  · exact (stronglyMeasurable_const.add (vectorDrift_predictable T hBm φ)).add
      (vectorIto_predictable hB T hBm hBc ψ)
  · filter_upwards [vectorDrift_continuous T hBm φ,vectorIto_continuous hB T hBm hBc ψ]
      with ω hd hi
    exact (continuousOn_const.add hd).add hi
  · intro ω
    ext i
    change x₀ i + driftContinuousMod T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ) 0 ω +
      itoContinuousMod T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i ψ) 0 ω = x₀ i
    rw [(integral_mod_zero T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i φ) ω).1,
      (integral_mod_zero T hBm (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i ψ) ω).2]
    ring
  · rw [hψclass]
    filter_upwards [vectorDrift_integral_all_times T hBm φ hφ] with ω hd
    intro t ht i
    change x₀ i + vectorDrift T hBm φ t ω i + vectorIto T hBm ψ t ω i = _
    rw [hd t ht i]

theorem exists_strong_solution (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (hc : contractionFactor c T < 1) :
    ∃ Y, StrongSolution (μ:=μ) T hBm c x₀ Y := by
  obtain ⟨X,hX,_⟩ := picard_exists_unique_fixedPoint hB T hBm hBc c x₀ hc
  obtain ⟨Y,hY,_⟩ := realize_fixed_point hB T hBm hBc c x₀ X hX
  exact ⟨Y,hY⟩

theorem trim_eq_of_ae_vector_paths (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    {Y Z : ℝ≥0 → Ω → (ι → ℝ)} (hY : IsStronglyPredictable (natFiltration hBm) Y)
    (hZ : IsStronglyPredictable (natFiltration hBm) Z)
    (he : ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = Z t ω) :
    Function.uncurry Y =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry Z := by
  have hec : ∀ i : ι, (fun z : ℝ≥0 × Ω => Y z.1 z.2 i)
      =ᵐ[trimMeasure_T (μ:=μ) T hBm] (fun z => Z z.1 z.2 i) := by
    intro i
    apply trim_eq_of_ae_paths (μ:=μ) T hBm (Y:=fun t ω => Y t ω i) (Z:=fun t ω => Z t ω i)
      ((continuous_apply i).comp_stronglyMeasurable hY)
      ((continuous_apply i).comp_stronglyMeasurable hZ)
    filter_upwards [he] with ω hω
    exact fun t ht => congrFun (hω t ht) i
  filter_upwards [ae_all_iff.mpr hec] with z hz
  exact funext hz

theorem StrongSolution.canonical_equation (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (c : Coefficients ι) (x₀ : ι → ℝ) {Y : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = x₀ +
      vectorDrift T hBm (c.driftLp T hBm (hY.state_memLp.toLp (Function.uncurry Y))) t ω +
      vectorIto T hBm (c.diffusionLp T hBm (hY.state_memLp.toLp (Function.uncurry Y))) t ω := by
  let X := hY.state_memLp.toLp (Function.uncurry Y)
  let φ := c.driftLp T hBm X
  let ψ := c.diffusionLp T hBm X
  have hφ : ⇑φ =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => c.drift z.1 (Y z.1 z.2) := by
    filter_upwards [coefficientLp_coe (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.drift_continuous
      c.drift_lipschitz (fun z : ℝ≥0 × Ω => c.drift_zero z.1) X,hY.state_memLp.coeFn_toLp] with z hc hz
    exact hc.trans (congrArg (c.drift z.1) hz)
  have hψ : ⇑ψ =ᵐ[trimMeasure_T (μ:=μ) T hBm] fun z => c.diffusion z.1 (Y z.1 z.2) := by
    filter_upwards [coefficientLp_coe (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) (clock_predictable hBm) c.diffusion_continuous
      c.diffusion_lipschitz (fun z : ℝ≥0 × Ω => c.diffusion_zero z.1) X,hY.state_memLp.coeFn_toLp] with z hc hz
    exact hc.trans (congrArg (c.diffusion z.1) hz)
  have hψclass : hY.diffusion_memLp.toLp (fun z : ℝ≥0 × Ω => c.diffusion z.1 (Y z.1 z.2)) = ψ :=
    (MemLp.toLp_congr hY.diffusion_memLp (Lp.memLp ψ) hψ.symm).trans
      (Lp.toLp_coeFn ψ (Lp.memLp ψ))
  filter_upwards [hY.equation,vectorDrift_integral_all_times T hBm φ hφ] with ω he hd
  intro t ht
  ext i
  change Y t ω i = x₀ i + vectorDrift T hBm φ t ω i + vectorIto T hBm ψ t ω i
  rw [he t ht i,hψclass,hd t ht i]

theorem StrongSolution.fixed_point (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) {Y : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y) :
    picard hB T hBm hBc c x₀ (hY.state_memLp.toLp (Function.uncurry Y)) =
      hY.state_memLp.toLp (Function.uncurry Y) := by
  let X := hY.state_memLp.toLp (Function.uncurry Y)
  have hp : IsStronglyPredictable (natFiltration hBm) (fun t ω => x₀ +
      vectorDrift T hBm (c.driftLp T hBm X) t ω + vectorIto T hBm (c.diffusionLp T hBm X) t ω) :=
    (stronglyMeasurable_const.add (vectorDrift_predictable T hBm _)).add
      (vectorIto_predictable hB T hBm hBc _)
  have he := trim_eq_of_ae_vector_paths T hBm hY.predictable hp (hY.canonical_equation T hBm c x₀)
  exact Lp.ext ((picard_coe hB T hBm hBc c x₀ X).trans
    (he.symm.trans hY.state_memLp.coeFn_toLp.symm))

/-- Pathwise uniqueness for all times, among predictable L2 strong solutions. -/
theorem strong_solution_unique (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) (hc : contractionFactor c T < 1)
    {Y Z : ℝ≥0 → Ω → (ι → ℝ)} (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hZ : StrongSolution (μ:=μ) T hBm c x₀ Z) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = Z t ω := by
  obtain ⟨_,_,hu⟩ := picard_exists_unique_fixedPoint hB T hBm hBc c x₀ hc
  have he : hY.state_memLp.toLp (Function.uncurry Y) = hZ.state_memLp.toLp (Function.uncurry Z) :=
    (hu _ (hY.fixed_point hB T hBm hBc c x₀)).trans
      (hu _ (hZ.fixed_point hB T hBm hBc c x₀)).symm
  filter_upwards [hY.canonical_equation T hBm c x₀,hZ.canonical_equation T hBm c x₀] with ω hy hz
  intro t ht
  rw [hy t ht,hz t ht,he]

/-- A coupled finite-dimensional, time-dependent strong SDE always has a
positive existence horizon, with pathwise uniqueness in the predictable L2 class. -/
theorem exists_unique_local_strong_solution (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) :
    ∃ T : ℝ≥0, 0 < T ∧ ∃ Y, StrongSolution (μ:=μ) T hBm c x₀ Y ∧
      ∀ Z, StrongSolution (μ:=μ) T hBm c x₀ Z →
        ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = Z t ω := by
  obtain ⟨T,hT,hc⟩ := exists_positive_contraction_horizon
    ((Fintype.card ι : ℝ≥0)*c.Lb) ((Fintype.card ι : ℝ≥0)*c.Lσ)
  have hc' : contractionFactor c T < 1 := by
    convert hc using 1 <;> simp only [contractionFactor,NNReal.coe_mul,NNReal.coe_natCast] <;> ring
  obtain ⟨Y,hY⟩ := exists_strong_solution hB T hBm hBc c x₀ hc'
  exact ⟨T,hT,Y,hY,fun Z hZ => strong_solution_unique hB T hBm hBc c x₀ hc' hY hZ⟩

end
end ChainFountainStochastic.VectorSDE
