module

public import ChainFountainStochastic.VectorSDE
public import MathFin.Foundations.ItoIntegralLocalisedPredictable

@[expose] public section

namespace ChainFountainStochastic.LocalIntegralBridge
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM
  MathFin.ItoIntegralProcessContinuousModification MathFin.ItoIntegralProcessGeneral
  MathFin.ItoIntegralPredictable MathFin.ItoIntegralLocalised
  MathFin.ItoIntegralProcessLocalMartingaleGeneral
open MathFin.LocalisationInMeasure MathFin.ItoIntegralRiemannBridge
  MathFin.QuadraticVariationL2
open VectorSDE VectorLp
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 600000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}

/-- The predictable L2 integral and the localized predictable integral coincide
at all times on one conull event. Continuity is required only almost surely. -/
theorem continuousMod_eq_predIto
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {a : ℝ≥0 → Ω → ℝ} (hp : IsStronglyPredictable (natFiltration hBm) a)
    (hc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => a t ω) (Icc 0 T))
    {C : ℝ} (hb : ∀ t ω, |a t ω| ≤ C)
    (φ : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm))
    (hφ : ⇑φ =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry a) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      itoContinuousMod T hBm φ t ω = predItoIntegral (μ:=μ) T hBm hp t ω := by
  have he : φ = processToLpPredictable (μ:=μ) T hBm hp hb :=
    Lp.ext (hφ.trans (processToLpPredictable_coeFn T hBm hp hb).symm)
  rw [he]
  exact ae_forall_eq_of_tendstoInMeasure
    (itoContinuousMod_continuousOn hB T hBm hBc _)
    (ae_continuousOn_predItoIntegral hB T hBm hBc hp hc)
    (fun _ ht => tendstoInMeasure_riemannσ_of_predictable hB T hBm hBc hp hc hb ht.2)
    (fun _ ht => tendstoInMeasure_riemannσ_predItoIntegral hB T hBm hBc hp hc ht.2)

/-- Prefix locality of the stochastic integral. The agreement event is allowed
to depend on the whole path; no uncountable intersection of null sets is used. -/
theorem predIto_prefix_locality
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {a b : ℝ≥0 → Ω → ℝ}
    (ha : IsStronglyPredictable (natFiltration hBm) a)
    (hb : IsStronglyPredictable (natFiltration hBm) b)
    (hac : ∀ᵐ ω ∂μ, ContinuousOn (fun t => a t ω) (Icc 0 T))
    (hbc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => b t ω) (Icc 0 T)) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, (∀ s ∈ Icc 0 t, a s ω = b s ω) →
      predItoIntegral (μ:=μ) T hBm ha t ω = predItoIntegral (μ:=μ) T hBm hb t ω := by
  refine ae_forall_eq_of_continuousOn_of_antitone
    (A := fun t => {ω | ∀ s ∈ Icc 0 t, a s ω = b s ω})
    (ae_continuousOn_predItoIntegral hB T hBm hBc ha hac)
    (ae_continuousOn_predItoIntegral hB T hBm hBc hb hbc)
    (fun _ _ hst _ h s hs => h s ⟨hs.1,hs.2.trans hst⟩) ?_
  intro t ht
  refine ae_eq_of_tendstoInMeasure_of_eqOn
    (tendstoInMeasure_riemannσ_predItoIntegral hB T hBm hBc ha hac ht.2)
    (tendstoInMeasure_riemannσ_predItoIntegral hB T hBm hBc hb hbc ht.2) ?_
  intro n ω hω
  exact riemannσ_congr (fun s hs => hω s ⟨hs.1,hs.2⟩) n

/-- The same single conull event supports every random prefix, whether or not
the prefix is a stopping time. This is locality of integrals, not uniqueness of SDEs. -/
theorem predIto_random_prefix_locality
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {a b : ℝ≥0 → Ω → ℝ}
    (ha : IsStronglyPredictable (natFiltration hBm) a)
    (hb : IsStronglyPredictable (natFiltration hBm) b)
    (hac : ∀ᵐ ω ∂μ, ContinuousOn (fun t => a t ω) (Icc 0 T))
    (hbc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => b t ω) (Icc 0 T)) :
    ∀ᵐ ω ∂μ, ∀ τ : ℝ≥0, τ ≤ T →
      (∀ s ∈ Icc 0 τ, a s ω = b s ω) → ∀ t ∈ Icc 0 τ,
      predItoIntegral (μ:=μ) T hBm ha t ω = predItoIntegral (μ:=μ) T hBm hb t ω := by
  filter_upwards [predIto_prefix_locality hB T hBm hBc ha hb hac hbc] with ω hω
  intro τ hτ he t ht
  exact hω t ⟨ht.1,ht.2.trans hτ⟩ (fun s hs => he s ⟨hs.1,hs.2.trans ht.2⟩)

/-- The localized predictable integral of zero vanishes simultaneously at all times. -/
theorem predIto_zero (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω)) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      predItoIntegral (μ:=μ) T hBm (show IsStronglyPredictable (natFiltration hBm)
        (fun _ _ => (0:ℝ)) from stronglyMeasurable_const) t ω = 0 := by
  have hp : IsStronglyPredictable (natFiltration hBm) (fun _ _ => (0:ℝ)) := stronglyMeasurable_const
  have hc : ∀ᵐ ω ∂μ, ContinuousOn (fun _ : ℝ≥0 => (0:ℝ)) (Icc 0 T) :=
    ae_of_all _ (fun _ => continuousOn_const)
  have he := continuousMod_eq_predIto hB T hBm hBc hp hc (C:=0)
    (fun _ _ => by simp) 0 (Lp.coeFn_zero ℝ 2 _)
  have hz : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      itoContinuousMod T hBm (0 : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) t ω = 0 := by
    apply ae_forall_eq_of_continuousOn
      (itoContinuousMod_continuousOn hB T hBm hBc _) hc
    intro t ht
    have hm := itoContinuousMod_modification hB T hBm hBc
      (0 : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) ht.2
    have hm0 : (fun ω => itoContinuousMod T hBm (0 : Lp ℝ 2 (trimMeasure_T (μ:=μ) T hBm)) t ω) =ᵐ[μ] ⇑(0 : Lp ℝ 2 μ) := by
      simpa only [map_zero] using hm
    exact hm0.trans (Lp.coeFn_zero ℝ 2 μ)
  filter_upwards [he,hz] with ω he hz
  intro t ht
  exact (he t ht).symm.trans (hz t ht)

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The actual time-dependent diffusion along a predictable vector state is predictable. -/
theorem diffusion_predictable (hBm : ∀ t, Measurable (B t))
    (c : Coefficients ι) {Y : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : IsStronglyPredictable (natFiltration hBm) Y) (i : ι) :
    IsStronglyPredictable (natFiltration hBm) (fun t ω => c.diffusion t (Y t ω) i) :=
  (continuous_apply i).comp_stronglyMeasurable
    (c.diffusion_continuous.comp_stronglyMeasurable ((clock_predictable hBm).prodMk hY))

/-- Every coordinate of a bounded-coefficient strong solution satisfies the
localized predictable Ito equation, with its actual diffusion coefficient. -/
theorem strong_solution_predIto_equation
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) {Y : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hbound : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, ∀ i : ι,
      Y t ω i = x₀ i + (∫ s in Ioc (0:ℝ≥0) t, c.drift s (Y s ω) i ∂timeMeasure) +
        predItoIntegral (μ:=μ) T hBm (diffusion_predictable hBm c hY.predictable i) t ω := by
  let ψ := hY.diffusion_memLp.toLp (fun z : ℝ≥0 × Ω => c.diffusion z.1 (Y z.1 z.2))
  have he (i : ι) : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      vectorIto T hBm ψ t ω i =
        predItoIntegral (μ:=μ) T hBm (diffusion_predictable hBm c hY.predictable i) t ω := by
    apply continuousMod_eq_predIto hB T hBm hBc (diffusion_predictable hBm c hY.predictable i)
    · filter_upwards [hY.continuous] with ω hω
      exact (continuous_apply i).comp_continuousOn
        (c.diffusion_continuous.comp_continuousOn (continuousOn_id.prodMk hω))
    · intro t ω
      exact (norm_le_pi_norm (c.diffusion t (Y t ω)) i).trans (hbound t (Y t ω))
    · filter_upwards [evalLp_coe (mα := (natFiltration hBm).predictable)
        (trimMeasure_T (μ:=μ) T hBm) i ψ,hY.diffusion_memLp.coeFn_toLp] with z hz hψ
      exact hz.trans (congrFun hψ i)
  filter_upwards [hY.equation,ae_all_iff.mpr he] with ω hω hi
  intro t ht i
  exact (hω t ht.2 i).trans (by rw [hi i t ht])

/-- A coordinate with zero diffusion along a whole prefix satisfies the
ordinary drift integral equation on that prefix, even when the prefix is random. -/
theorem strong_solution_finite_variation_coordinate
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) {Y : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hbound : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound) (i : ι) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      (∀ s ∈ Icc 0 t, c.diffusion s (Y s ω) i = 0) →
      Y t ω i = x₀ i + (∫ s in Ioc (0:ℝ≥0) t, c.drift s (Y s ω) i ∂timeMeasure) := by
  have hc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => c.diffusion t (Y t ω) i) (Icc 0 T) := by
    filter_upwards [hY.continuous] with ω hω
    exact (continuous_apply i).comp_continuousOn
      (c.diffusion_continuous.comp_continuousOn (continuousOn_id.prodMk hω))
  have hp0 : IsStronglyPredictable (natFiltration hBm) (fun _ _ => (0:ℝ)) := stronglyMeasurable_const
  filter_upwards [strong_solution_predIto_equation hB T hBm hBc c x₀ hY hbound,
    predIto_prefix_locality hB T hBm hBc (diffusion_predictable hBm c hY.predictable i) hp0 hc
      (ae_of_all _ fun _ => continuousOn_const),predIto_zero hB T hBm hBc] with ω he hl hz
  intro t ht hzero
  simpa only [hl t ht hzero,hz t ht,add_zero] using he t ht i

/-- A strong vector solution has a genuine continuous local-martingale
decomposition, coordinate by coordinate, for the null-augmented filtration. -/
theorem strong_solution_localMartingale_decomposition
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) {Y : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y) :
    ∃ M : ℝ≥0 → Ω → (ι → ℝ),
      (∀ ω, Continuous (fun t => M t ω)) ∧
      (∀ i, IsLocalMartingale (fun t ω => M t ω i) (augFiltration (μ:=μ) hBm) μ) ∧
      StronglyAdapted (augFiltration (μ:=μ) hBm) M ∧
      (∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, ∀ i : ι,
        Y t ω i = x₀ i + (∫ s in Ioc (0:ℝ≥0) t, c.drift s (Y s ω) i ∂timeMeasure) + M t ω i) := by
  let ψ := hY.diffusion_memLp.toLp (fun z : ℝ≥0 × Ω => c.diffusion z.1 (Y z.1 z.2))
  have hex (i : ι) := exists_continuous_localMartingale_modification hB T hBm hBc
    (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) T hBm) i ψ)
  choose M hMe hMc hMl hMa using hex
  have he (i : ι) : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, M i t ω = vectorIto T hBm ψ t ω i := by
    apply ae_forall_eq_of_continuousOn (ae_of_all _ fun ω => (hMc i ω).continuousOn)
      (itoContinuousMod_continuousOn hB T hBm hBc _)
    intro t ht
    exact (hMe i t ht.2).trans (itoContinuousMod_modification hB T hBm hBc _ ht.2).symm
  refine ⟨fun t ω i => M i t ω,?_,hMl,?_,?_⟩
  · intro ω
    exact continuous_pi (fun i => hMc i ω)
  · intro t
    letI : MeasurableSpace Ω := augFiltration (μ:=μ) hBm t
    exact (measurable_pi_lambda _ (fun i => (hMa i t).measurable)).stronglyMeasurable
  · filter_upwards [hY.equation,ae_all_iff.mpr he] with ω hω hi
    intro t ht i
    exact (hω t ht.2 i).trans (by rw [hi i t ht])

end
end ChainFountainStochastic.LocalIntegralBridge
