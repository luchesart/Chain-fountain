module

public import ChainFountainStochastic.MaximalMechanicalSDE

@[expose] public section
namespace ChainFountainStochastic.CutoffExhaustion
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralProcessLocalMartingaleGeneral
open VectorSDE GlobalCutoffSDE MechanicalCutoff MechanicalExhaustion GlobalLocalization
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1000000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {hBm : ∀ t, Measurable (B t)} {a : Parameters} {p : ℝ≥0 → State} {x₀ : State}

/-- Comparison of two independently chosen cutoff exhaustions. -/
theorem Family.cross_prefix (F G : Family (μ:=μ) hBm a p x₀)
    (hB : IsPreBrownianReal B μ) (hBc : ∀ ω, Continuous (fun t => B t ω)) :
    ∀ᵐ ω ∂μ, ∀ n m : ℕ, (n:ℝ)+F.R < (m:ℝ)+G.R →
      F.exit n ω ≤ G.exit m ω ∧
      ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ F.exit n ω → F.X n t ω = G.X m t ω := by
  have hpair (n m : ℕ) : ∀ᵐ ω ∂μ, (n:ℝ)+F.R < (m:ℝ)+G.R →
      F.exit n ω ≤ G.exit m ω ∧
      ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ F.exit n ω → F.X n t ω = G.X m t ω := by
    by_cases hrad : (n:ℝ)+F.R < (m:ℝ)+G.R
    · have hn : 0 < (n:ℝ)+F.R := by have := F.radius_gt; positivity
      have hsub : ∀ x, |gauge ((n:ℝ)+F.R) x| ≤ 1 → |gauge ((m:ℝ)+G.R) x| < 1 :=
        fun x hx => gauge_strict_nesting hn hrad hx
      have hp := (gaugeExit_properties (G.adapted m) (G.continuous m)
        (gauge_continuous ((n:ℝ)+F.R)) (G.initial m)
        (radius_initial_inside F.radius_gt F.initial_inside n)).2.1
      have he := global_versions_stopped_eq hB hBm hBc (F.c n) (G.c m) x₀
        (F.bound n) (G.bound m) (F.strong n) (G.strong m) (F.adapted n) (G.adapted m)
        (F.continuous n) (G.continuous m) (F.initial n) (G.initial m) (F.version n) (G.version m)
        (gauge ((n:ℝ)+F.R)) (gauge_continuous _) (radius_initial_inside F.radius_gt F.initial_inside n)
        (fun t x hx => ⟨(F.agrees n t x hx).1.trans (G.agrees m t x (hsub x hx).le).1.symm,
          (F.agrees n t x hx).2.trans (G.agrees m t x (hsub x hx).le).2.symm⟩)
      filter_upwards [he] with ω hω _
      have horder := (GaugeExit.strict_mono (G.continuous m) (gauge_continuous _)
        (gauge_continuous _) hp hsub ω).1
      refine ⟨by change F.exit n ω ≤ G.exit m ω; exact hω.1.trans_le horder,?_⟩
      intro t ht
      change (t:WithTop ℝ≥0) ≤ gaugeExit (F.X n) (gauge ((n:ℝ)+F.R)) ω at ht
      have ht' := hω.1 ▸ ht
      simpa only [stoppedProcess_eq_of_le ht,stoppedProcess_eq_of_le ht'] using hω.2 t
    · exact ae_of_all _ (fun _ h => (hrad h).elim)
  exact ae_all_iff.mpr (fun n => ae_all_iff.mpr (hpair n))

/-- The maximal lifetime and the path before it are independent of the
initial radius, all coefficient extensions, and all chosen solution versions. -/
theorem Family.maximal_unique (F G : Family (μ:=μ) hBm a p x₀)
    (hB : IsPreBrownianReal B μ) (hBc : ∀ ω, Continuous (fun t => B t ω)) :
    ∀ᵐ ω ∂μ, F.lifetime ω = G.lifetime ω ∧
      ∀ t : ℝ≥0, (t:WithTop ℝ≥0) < F.lifetime ω → F.process t ω = G.process t ω := by
  filter_upwards [F.cross_prefix G hB hBc,G.cross_prefix F hB hBc,
    F.process_eq_before_exit,G.process_eq_before_exit] with ω hFG hGF hF hG
  have hle : F.lifetime ω ≤ G.lifetime ω := by
    apply iSup_le
    intro n
    obtain ⟨m,hm⟩ := exists_nat_gt ((n:ℝ)+F.R-G.R)
    exact (hFG n m (by linarith)).1.trans (le_iSup (fun m => G.exit m ω) m)
  have hge : G.lifetime ω ≤ F.lifetime ω := by
    apply iSup_le
    intro m
    obtain ⟨n,hn⟩ := exists_nat_gt ((m:ℝ)+G.R-F.R)
    exact (hGF m n (by linarith)).1.trans (le_iSup (fun n => F.exit n ω) n)
  refine ⟨le_antisymm hle hge,?_⟩
  intro t ht
  obtain ⟨n,hn⟩ := (lt_iSup_iff.mp ht : ∃ n, (t:WithTop ℝ≥0) < F.exit n ω)
  obtain ⟨m,hm⟩ := exists_nat_gt ((n:ℝ)+F.R-G.R)
  have hc := hFG n m (by linarith)
  exact (hF n t hn.le).1.trans ((hc.2 t hn.le).trans (hG m t (hn.le.trans hc.1)).1.symm)

/-- End-to-end existence for the original singular mechanical fields on
positive height. The family, process, stopping lifetime, local equations and
explosion alternative are all constructed from the model and initial data. -/
theorem exists_maximal_mechanical_solution
    (hB : IsPreBrownianReal B μ) (hBm : ∀ t, Measurable (B t))
    (hBc : ∀ ω, Continuous (fun t => B t ω))
    (a : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi : State) (hpmem : ∀ t, p t ∈ Icc plo phi)
    (x₀ : State) (hh : 0 < x₀ 0) :
    ∃ F : Family (μ:=μ) hBm a p x₀,
      IsStronglyPredictable (natFiltration hBm) F.process ∧
      (∀ ω, F.process 0 ω = x₀) ∧
      IsStoppingTime (augFiltration (μ:=μ) hBm) F.lifetime ∧
      (∀ ω, ⊥ < F.lifetime ω) ∧
      (∀ᵐ ω ∂μ, ContinuousOn (fun t => F.process t ω) {t | (t:WithTop ℝ≥0) < F.lifetime ω} ∧
        ∀ t : ℝ≥0, (t:WithTop ℝ≥0) < F.lifetime ω → 0 < F.process t ω 0) ∧
      (∀ᵐ ω ∂μ, F.lifetime ω ≠ ⊤ → ∀ K : Set State, IsCompact K →
        (∀ x ∈ K, 0 < x 0) → ∀ t : ℝ≥0, (t:WithTop ℝ≥0) < F.lifetime ω →
        ∃ s : ℝ≥0, t ≤ s ∧ (s:WithTop ℝ≥0) < F.lifetime ω ∧ F.process s ω ∉ K) ∧
      (∀ᵐ ω ∂μ, ∀ n N : ℕ, ∀ t ∈ Icc 0 (N:ℝ≥0), (t:WithTop ℝ≥0) ≤ F.exit n ω → ∀ i : Fin 3,
        F.process t ω i = x₀ i + (∫ s in Ioc (0:ℝ≥0) t,
          a.drift (p s,F.process s ω) i ∂timeMeasure) +
          MathFin.ItoIntegralLocalised.predItoIntegral (μ:=μ) N hBm
            (LocalIntegralBridge.diffusion_predictable hBm (F.c n) (F.strong n N).predictable i) t ω) ∧
      ∀ G : Family (μ:=μ) hBm a p x₀, ∀ᵐ ω ∂μ, F.lifetime ω = G.lifetime ω ∧
        ∀ t : ℝ≥0, (t:WithTop ℝ≥0) < F.lifetime ω → F.process t ω = G.process t ω := by
  obtain ⟨F⟩ := exists_family hB hBm hBc a p hp plo phi hpmem x₀ hh
  exact ⟨F,F.process_predictable,F.process_initial,F.lifetime_stopping,F.lifetime_positive,
    F.process_regular,F.explosion_alternative,F.local_mechanical_equation hB hBc,
    fun G => F.maximal_unique G hB hBc⟩

end
end ChainFountainStochastic.CutoffExhaustion
