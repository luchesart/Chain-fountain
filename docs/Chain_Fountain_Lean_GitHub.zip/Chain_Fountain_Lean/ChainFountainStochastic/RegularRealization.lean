module

public import ChainFountainStochastic.CutoffExhaustion
public import ChainFountainStochastic.ConullBrownian
public import ChainFountainStochastic.MechanicalIto

@[expose] public section
namespace ChainFountainStochastic.RegularRealization
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralLocalised MathFin.ItoFormulaAdapted MathFin.AdaptedDrift
open VectorSDE GlobalCutoffSDE MechanicalCutoff CutoffExhaustion LocalIntegralBridge ConullBrownian
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1000000
variable {Ω Ω' : Type*} {mΩ : MeasurableSpace Ω} {mΩ' : MeasurableSpace Ω'}
  {μ : Measure Ω} {ν : Measure Ω'} [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
  {B : ℝ≥0 → Ω → ℝ}

/-- The actual cutoff diffusion vanishes identically in the height and
fall-speed coordinates, including outside the region where the cutoff is inactive. -/
theorem cutoff_zero_diffusion {hBm : ∀ t, Measurable (B t)}
    {a : Parameters} {p : ℝ≥0 → State} {x₀ : State}
    (F : Family (μ:=μ) hBm a p x₀) (n : ℕ) (t : ℝ≥0) (x : State) :
    (F.c n).diffusion t x 0 = 0 ∧ (F.c n).diffusion t x 2 = 0 := by
  rw [F.clamped_diffusion]
  simp [Parameters.diffusion]

/-- The two non-diffusive coordinates of the constructed cutoff satisfy
ordinary integral equations globally on one event of probability one. -/
theorem finite_variation_equations {hBm : ∀ t, Measurable (B t)}
    (hB : IsPreBrownianReal B μ) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {a : Parameters} {p : ℝ≥0 → State} {x₀ : State}
    (F : Family (μ:=μ) hBm a p x₀) :
    ∀ᵐ ω ∂μ, ∀ n : ℕ, ∀ t : ℝ≥0,
      F.Y n t ω 0 = x₀ 0 + driftPath (fun s ω => (F.c n).drift s (F.Y n s ω) 0) t ω ∧
      F.Y n t ω 2 = x₀ 2 + driftPath (fun s ω => (F.c n).drift s (F.Y n s ω) 2) t ω := by
  have he (n N : ℕ) : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 (N:ℝ≥0),
      F.Y n t ω 0 = x₀ 0 + driftPath (fun s ω => (F.c n).drift s (F.Y n s ω) 0) t ω ∧
      F.Y n t ω 2 = x₀ 2 + driftPath (fun s ω => (F.c n).drift s (F.Y n s ω) 2) t ω := by
    filter_upwards [strong_solution_finite_variation_coordinate hB N hBm hBc (F.c n) x₀
      (F.strong n N) (F.bound n) 0,
      strong_solution_finite_variation_coordinate hB N hBm hBc (F.c n) x₀
      (F.strong n N) (F.bound n) 2] with ω h0 h2
    intro t ht
    exact ⟨h0 t ht (fun s _ => (cutoff_zero_diffusion F n s _).1),
      h2 t ht (fun s _ => (cutoff_zero_diffusion F n s _).2)⟩
  filter_upwards [ae_all_iff.mpr (fun n => ae_all_iff.mpr (he n))] with ω hω
  intro n t
  obtain ⟨N,hN⟩ := exists_nat_ge t
  exact hω n N t ⟨zero_le,hN⟩

/-- A conull realization makes all cutoff state paths continuous and the two
finite-variation equations true on every sample path. This uses no new path
regularity assumption and leaves all probability laws unchanged. -/
theorem exists_regular_realization {hBm : ∀ t, Measurable (B t)}
    (hB : IsPreBrownianReal B μ) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {a : Parameters} {p : ℝ≥0 → State} {x₀ : State}
    (F : Family (μ:=μ) hBm a p x₀) :
    ∃ G : Set Ω, MeasurableSet G ∧ (∀ᵐ ω ∂μ, ω ∈ G) ∧
      ∀ ω ∈ G, ∀ n : ℕ, Continuous (fun t => F.Y n t ω) ∧
        ∀ t : ℝ≥0,
          F.Y n t ω 0 = x₀ 0 + driftPath (fun s ω => (F.c n).drift s (F.Y n s ω) 0) t ω ∧
          F.Y n t ω 2 = x₀ 2 + driftPath (fun s ω => (F.c n).drift s (F.Y n s ω) 2) t ω := by
  apply exists_measurable_conull
  filter_upwards [finite_variation_equations hB hBc F,
    ae_all_iff.mpr (fun n => global_strong_solution_continuous hBm (F.c n) x₀ (F.strong n))]
    with ω hFV hcont
  exact fun n => ⟨hcont n,hFV n⟩

/-- The constructed strong solution becomes exactly the continuous-adapted
Itô-process interface on a measure-preserving conull realization. The stochastic
integral identification is proved by common Riemann sums. -/
theorem strong_solution_pullback_equation
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients (Fin 3)) (x₀ : State) {Y : ℝ≥0 → Ω → State}
    (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    {f : Ω' → Ω} (hf : MeasurableEmbedding f) (hm : MeasurePreserving f ν μ)
    (hYf : ∀ ω, Continuous (fun t => Y t (f ω))) (i : Fin 3) :
    ∃ (ham : ∀ t, StronglyMeasurable[natFiltration (fun s => (hBm s).comp hf.measurable) t]
          (fun ω => c.diffusion t (Y t (f ω)) i))
      (hac : ∀ ω, Continuous (fun t => c.diffusion t (Y t (f ω)) i)),
      ∀ᵐ ω ∂ν, ∀ t ∈ Icc 0 T,
        Y t (f ω) i = localItoProcess (μ:=ν) T (fun s => (hBm s).comp hf.measurable)
          ham hac (x₀ i) (fun s ω => c.drift s (Y s (f ω)) i) t ω := by
  have ha := diffusion_predictable hBm c (hY T).predictable i
  have ham := adapted_pullback hBm hf.measurable ha.stronglyAdapted
  have hac : ∀ ω, Continuous (fun t => c.diffusion t (Y t (f ω)) i) := fun ω =>
    (continuous_apply i).comp (c.diffusion_continuous.comp (continuous_id.prodMk (hYf ω)))
  have hAc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => c.diffusion t (Y t ω) i) (Icc 0 T) := by
    filter_upwards [(hY T).continuous] with ω hω
    exact (continuous_apply i).comp_continuousOn
      (c.diffusion_continuous.comp_continuousOn (continuousOn_id.prodMk hω))
  refine ⟨ham,hac,?_⟩
  filter_upwards [hm.quasiMeasurePreserving.tendsto_ae.eventually
      (strong_solution_predIto_equation hB T hBm hBc c x₀ (hY T) hb),
    predIto_pullback hB T hBm hBc hf hm ha hAc hac] with ω he hi
  intro t ht
  simpa only [hi t ht,localItoProcess,driftPath] using he t ht i

end
end ChainFountainStochastic.RegularRealization
