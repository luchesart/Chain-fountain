module

public import MathFin.Foundations.GirsanovAdaptedTheta
public import MathFin.Foundations.ItoIntegralLocalised
public import BrownianMotion.StochasticIntegral.DoobLp

@[expose] public section

namespace ChainFountainStochastic.ItoExponential
noncomputable section
open MeasureTheory ProbabilityTheory MathFin Filter Set Real
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM MathFin.ItoIntegralLocalised
open scoped NNReal ENNReal Topology
set_option maxHeartbeats 1000000
set_option backward.isDefEq.respectTransparency false
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
  {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ)
  (hBm : ∀ t, Measurable (B t))
  {a : ℝ≥0 → Ω → ℝ}
  (ha : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
  (hc : ∀ ω, Continuous (a · ω)) {C : ℝ} (hb : ∀ t ω, |a t ω| ≤ C)

include hc hb in
/-- The actual accumulated squared coefficient is bounded by its uniform bound. -/
theorem square_integral_le (T : ℝ≥0) (ω : Ω) :
    (∫ s in Ioc 0 T, (a s ω)^2 ∂timeMeasure) ≤ C^2*(T:ℝ) := by
  have hi : IntegrableOn (fun s => (a s ω)^2) (Ioc 0 T) timeMeasure :=
    ((hc ω).pow 2 |>.continuousOn.integrableOn_compact isCompact_Icc).mono_set Ioc_subset_Icc_self
  calc
    _ ≤ ∫ s in Ioc (0:ℝ≥0) T, C^2 ∂timeMeasure := by
      apply setIntegral_mono_on hi (integrableOn_const (by simp [timeMeasure_Ioc])) measurableSet_Ioc
      intro s hs
      simpa only [sq_abs] using pow_le_pow_left₀ (abs_nonneg (a s ω)) (hb s ω) 2
    _ = _ := by simp [Measure.real_def, timeMeasure_Ioc, mul_comm]

include hb in
theorem scaled_bound (q : ℝ) : ∀ t ω, |q * a t ω| ≤ |q| * C := by
  intro t ω
  rw [abs_mul]
  exact mul_le_mul_of_nonneg_left (hb t ω) (abs_nonneg q)

/-- Scalar multiplication commutes with the genuine terminal Ito integral. -/
theorem terminal_smul (q : ℝ) (T : ℝ≥0) :
    itoIntCont hB hBm (fun t => (ha t).const_mul q) (fun ω => (hc ω).const_mul q)
      (C:=|q| * C) (scaled_bound hb q) T =ᵐ[μ]
      fun ω => q * itoIntCont hB hBm ha hc hb T ω := by
  have he : processToLp (μ:=μ) T hBm (fun t => (ha t).const_mul q)
      (fun ω => (hc ω).const_mul q)
      (C:=|q| * C) (scaled_bound hb q) =
      q • processToLp (μ:=μ) T hBm ha hc hb := by
    apply Lp.ext
    filter_upwards [processToLp_coeFn (μ:=μ) T hBm (fun t => (ha t).const_mul q)
      (fun ω => (hc ω).const_mul q) (C:=|q| * C)
      (scaled_bound hb q),
      Lp.coeFn_smul q (processToLp (μ:=μ) T hBm ha hc hb),
      processToLp_coeFn (μ:=μ) T hBm ha hc hb] with z h₁ h₂ h₃
    simp only [Pi.smul_apply, smul_eq_mul, h₃] at h₂
    exact h₁.trans h₂.symm
  simp only [itoIntCont,he,map_smul]
  exact Lp.coeFn_smul q _

/-- A bounded continuous adapted coefficient has an integrable Doleans
exponential of mean one, derived from the proved predictable approximation. -/
theorem density_mean_one (T : ℝ≥0) :
    Integrable (contDoleansExp (itoIntCont hB hBm ha hc hb T) a T) μ ∧
      (∫ ω, contDoleansExp (itoIntCont hB hBm ha hc hb T) a T ω ∂μ) = 1 := by
  let hp := isStronglyPredictable_of_bdd_adapted_cont hBm ha hc
  obtain ⟨V,hV⟩ := exists_approxSeq (μ:=μ) hBm T hp hb
  have he := ZTpred_ae_eq_contDoleansExp hB hBm ha hc hb T
  exact ⟨((memLp_ZTpred_one hB hBm T hp hb V hV).integrable le_rfl).congr he,
    (integral_congr_ae he).symm.trans (integral_ZTpred_eq_one hB hBm T hp hb V hV)⟩

/-- Gaussian exponential moment bound for the genuine Ito integral of a
bounded, continuous adapted coefficient. -/
theorem terminal_mgf (q : ℝ) (T : ℝ≥0) :
    Integrable (fun ω => exp (q * itoIntCont hB hBm ha hc hb T ω)) μ ∧
    (∫ ω, exp (q * itoIntCont hB hBm ha hc hb T ω) ∂μ) ≤
      exp (q^2*C^2*(T:ℝ)/2) := by
  let θ := fun t ω => -q * a t ω
  let haθ := fun t => (ha t).const_mul (-q)
  let hcθ := fun ω => (hc ω).const_mul (-q)
  let hbθ := scaled_bound hb (-q)
  let Z := contDoleansExp (itoIntCont hB hBm haθ hcθ hbθ T) θ T
  obtain ⟨hZi,hZ1⟩ := density_mean_one hB hBm haθ hcθ hbθ T
  have hdom : ∀ᵐ ω ∂μ, exp (q * itoIntCont hB hBm ha hc hb T ω) ≤
      exp (q^2*C^2*(T:ℝ)/2) * Z ω := by
    filter_upwards [terminal_smul hB hBm ha hc hb (-q) T] with ω hω
    dsimp [Z,contDoleansExp]
    rw [hω,← exp_add]
    apply exp_le_exp.mpr
    have hs := square_integral_le hcθ hbθ T ω
    dsimp [θ] at *
    rw [abs_neg,mul_pow,sq_abs] at hs
    nlinarith
  have hi : Integrable (fun ω => exp (q * itoIntCont hB hBm ha hc hb T ω)) μ := by
    apply (hZi.const_mul (exp (q^2*C^2*(T:ℝ)/2))).mono'
    · exact Real.continuous_exp.comp_aestronglyMeasurable ((Lp.stronglyMeasurable _).aestronglyMeasurable.const_mul q)
    · simpa only [Real.norm_eq_abs,abs_of_pos (exp_pos _)] using hdom
  refine ⟨hi, (integral_mono_ae hi (hZi.const_mul _) hdom).trans_eq ?_⟩
  rw [integral_const_mul,hZ1,mul_one]

end
end ChainFountainStochastic.ItoExponential
