module

public import ChainFountainStochastic.LocalIntegralBridge

@[expose] public section

namespace ChainFountainStochastic.PrefixLimits
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM
open VectorSDE
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 600000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}

/-- Lebesgue measure on the nonnegative time axis has full topological support. -/
theorem timeMeasure_open_pos : Measure.IsOpenPosMeasure timeMeasure := by
  constructor
  intro U hU hne
  obtain ⟨x,hx⟩ := hne
  obtain ⟨ε,hε,hεU⟩ := Metric.isOpen_iff.mp hU x hx
  let δ : ℝ≥0 := ⟨ε/2,le_of_lt (half_pos hε)⟩
  have hsub : Ioc x (x+δ) ⊆ U := by
    intro t ht
    apply hεU
    have hxt : (x:ℝ) ≤ (t:ℝ) := ht.1.le
    rw [Metric.mem_ball,NNReal.dist_eq,abs_of_nonneg (sub_nonneg.mpr hxt)]
    have hupper : (t:ℝ) ≤ (x:ℝ)+ε/2 := ht.2
    linarith
  have hpos : 0 < timeMeasure (Ioc x (x+δ)) := by
    rw [timeMeasure_Ioc]
    apply ENNReal.ofReal_pos.mpr
    simp only [NNReal.coe_add]
    change 0 < (x:ℝ)+ε/2-x
    linarith
  exact ne_of_gt (hpos.trans_le (measure_mono hsub))

/-- A trimmed product almost-everywhere statement holds on almost every
sample path for almost every time. No measurability of the predicate is needed. -/
theorem ae_path_of_trim (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    {P : ℝ≥0 × Ω → Prop}
    (h : ∀ᵐ z ∂trimMeasure_T (μ:=μ) T hBm, P z) :
    ∀ᵐ ω ∂μ, ∀ᵐ t ∂timeMeasure_T T, P (t,ω) := by
  have hp : ∀ᵐ z ∂(timeMeasure_T T).prod μ, P z :=
    ae_of_ae_trim (natFiltration hBm).predictable_le_prod h
  exact Measure.ae_ae_of_ae_prod
    (Measure.measurePreserving_swap.quasiMeasurePreserving.ae hp)

/-- Agreement on an arbitrary random prefix survives an L2 limit whenever
the limit and comparison paths are continuous. The time-zero value is explicit,
because product Lebesgue measure alone cannot determine it. -/
theorem prefix_agreement_of_tendsto_Lp
    {ι : Type*} [Fintype ι] [DecidableEq ι]
    (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (Xn : ℕ → ProcessLp (μ:=μ) (ι:=ι) T hBm)
    (X : ProcessLp (μ:=μ) (ι:=ι) T hBm)
    (hlim : Tendsto Xn atTop (𝓝 X))
    {Yn : ℕ → ℝ≥0 → Ω → (ι → ℝ)} {Y Z : ℝ≥0 → Ω → (ι → ℝ)}
    (hn : ∀ n, ⇑(Xn n) =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry (Yn n))
    (hX : ⇑X =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry Y)
    (hYc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => Y t ω) (Icc 0 T))
    (hZc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => Z t ω) (Icc 0 T))
    (hzero : ∀ ω, Y 0 ω = Z 0 ω)
    (τ : Ω → ℝ≥0)
    (he : ∀ n, ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω → Yn n t ω = Z t ω) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, t ≤ τ ω → Y t ω = Z t ω := by
  letI : Measure.IsOpenPosMeasure timeMeasure := timeMeasure_open_pos
  obtain ⟨ns,_,hns⟩ := (tendstoInMeasure_of_tendsto_Lp hlim).exists_seq_tendsto_ae
  have hpath : ∀ᵐ ω ∂μ, ∀ᵐ t ∂timeMeasure_T T,
      Tendsto (fun k => Yn (ns k) t ω) atTop (𝓝 (Y t ω)) := by
    refine ae_path_of_trim (μ:=μ) T hBm
      (P := fun z => Tendsto (fun k => Yn (ns k) z.1 z.2) atTop (𝓝 (Y z.1 z.2))) ?_
    filter_upwards [hns,ae_all_iff.mpr hn,hX] with z hz hn hX
    simpa only [hn,hX,Function.uncurry] using hz
  filter_upwards [hpath,hYc,hZc,ae_all_iff.mpr he] with ω hp hY hZ he
  intro t ht hτ
  rcases eq_zero_or_pos t with rfl | htp
  · exact hzero ω
  have hp' : ∀ᵐ s ∂timeMeasure.restrict (Ioc 0 t),
      Tendsto (fun k => Yn (ns k) s ω) atTop (𝓝 (Y s ω)) :=
    ae_restrict_of_ae_restrict_of_subset (Ioc_subset_Ioc_right ht.2) hp
  have heq : (fun s => Y s ω) =ᵐ[timeMeasure.restrict (Ioc 0 t)] (fun s => Z s ω) := by
    filter_upwards [hp',ae_restrict_mem measurableSet_Ioc] with s hs hsI
    have he' : ∀ k, Yn (ns k) s ω = Z s ω :=
      fun k => he (ns k) s ⟨zero_le,hsI.2.trans ht.2⟩ (hsI.2.trans hτ)
    exact tendsto_nhds_unique hs (by simpa only [he'] using
      (tendsto_const_nhds : Tendsto (fun _ : ℕ => Z s ω) atTop (𝓝 (Z s ω))))
  exact Measure.eqOn_Ioc_of_ae_eq timeMeasure heq
    (hY.mono (Ioc_subset_Icc_self.trans (Icc_subset_Icc_right ht.2)))
    (hZ.mono (Ioc_subset_Icc_self.trans (Icc_subset_Icc_right ht.2))) ⟨htp,le_rfl⟩

end
end ChainFountainStochastic.PrefixLimits
