module

public import ChainFountainStochastic.EnergyIto

@[expose] public section
namespace ChainFountainStochastic
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory MathFin
open MathFin.ItoIntegralL2 MathFin.ItoFormulaAdapted
open MathFin.ItoIntegralProcessLocalMartingaleGeneral
open scoped NNReal Topology

/-- Quadratic energy decomposition for a general scalar Itô coordinate and a
finite-variation coordinate. Mechanical drift cancellation is applied only
inside the localization region, so no global physical equations are assumed. -/
theorem general_energy_ito
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {a b z : ℝ≥0 → Ω → ℝ} {e e' : ℝ → Ω → ℝ} {k₀ z₀ : ℝ}
    (ham : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hac : ∀ ω, Continuous (fun t => a t ω))
    (hbm : ∀ t, StronglyMeasurable[natFiltration hBm t] (b t))
    (hbc : ∀ ω, Continuous (fun t => b t ω))
    (hzc : ∀ ω, Continuous (fun t => z t ω))
    (he : ∀ ω t, 0 ≤ t → HasDerivAt (fun s => e s ω) (e' t ω) t)
    (hec : ∀ ω, Continuous (fun t : ℝ≥0 => e' t ω))
    (hSDE : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      z t ω = localItoProcess (μ:=μ) T hBm ham hac z₀ b t ω) :
    ∃ M : ℝ≥0 → Ω → ℝ,
      (∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
        trackingEnergy k₀ (e t ω) (z t ω) = trackingEnergy k₀ (e 0 ω) z₀ +
          (∫ s in Ioc 0 t, k₀*e s ω*e' s ω + z s ω*b s ω/4 + (a s ω)^2/8 ∂timeMeasure) + M t ω) ∧
      (∀ ω, Continuous (fun t => M t ω)) ∧
      IsLocalMartingale M (augFiltration (μ:=μ) hBm) μ := by
  obtain ⟨M,hM,hMc,hMl⟩ := quadratic_ito_localMartingale hB T hBm hBc ham hac hbm hbc z₀
  refine ⟨M,?_,hMc,hMl⟩
  filter_upwards [hM,hSDE] with ω hMω hZω t ht
  have hecn : Continuous (fun s : ℝ≥0 => e s ω) :=
    (show ContinuousOn (fun s : ℝ => e s ω) (Ici 0) from
      fun s hs => (he ω s hs).continuousAt.continuousWithinAt).comp_continuous
        NNReal.continuous_coe (fun s => s.coe_nonneg)
  have he'c : ContinuousOn (fun s : ℝ => e' s ω) (Icc 0 (t:ℝ)) := by
    apply ((hec ω).comp continuous_real_toNNReal).continuousOn.congr
    intro s hs
    simp only [Function.comp_apply, Real.coe_toNNReal s hs.1]
  have hE := finite_variation_energy (k:=k₀) (fun s hs => he ω s hs.1) he'c
  have hZ := hMω t ht
  rw [←hZω t ht] at hZ
  have hconv : (∫ s in Ioc 0 t, (localItoProcess (μ:=μ) T hBm ham hac z₀ b s ω)*b s ω/4 +
      (a s ω)^2/8 ∂timeMeasure) = ∫ s in Ioc 0 t, z s ω*b s ω/4 + (a s ω)^2/8 ∂timeMeasure := by
    apply setIntegral_congr_fun measurableSet_Ioc
    intro s hs
    dsimp only
    rw [←hZω s ⟨zero_le,hs.2.trans ht.2⟩]
  rw [hconv] at hZ
  have hi₁ : IntegrableOn (fun s : ℝ≥0 => k₀*e s ω*e' s ω) (Ioc 0 t) timeMeasure :=
    (((hecn.const_mul k₀).mul (hec ω)).continuousOn.integrableOn_compact isCompact_Icc).mono_set Ioc_subset_Icc_self
  have hi₂ : IntegrableOn (fun s : ℝ≥0 => z s ω*b s ω/4+(a s ω)^2/8) (Ioc 0 t) timeMeasure := by
    exact (((hzc ω).mul (hbc ω)).div_const 4 |>.add ((hac ω).pow 2 |>.div_const 8)).continuousOn.integrableOn_compact
      isCompact_Icc |>.mono_set Ioc_subset_Icc_self
  have hsum : (∫ s in Ioc 0 t, k₀*e s ω*e' s ω+z s ω*b s ω/4+(a s ω)^2/8 ∂timeMeasure) =
      (∫ s in Ioc 0 t, k₀*e s ω*e' s ω ∂timeMeasure)+
        ∫ s in Ioc 0 t, z s ω*b s ω/4+(a s ω)^2/8 ∂timeMeasure := by
    rw [←integral_add hi₁ hi₂]
    apply integral_congr_ae
    exact ae_of_all _ (fun _ => by ring)
  rw [hsum]
  dsimp [trackingEnergy]
  linarith

end
end ChainFountainStochastic
