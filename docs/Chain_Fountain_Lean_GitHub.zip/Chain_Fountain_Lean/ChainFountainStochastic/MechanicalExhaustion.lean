module

public import ChainFountainStochastic.GlobalLocalization

@[expose] public section

namespace ChainFountainStochastic.MechanicalExhaustion
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MechanicalCutoff GlobalLocalization
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 800000

/-- A continuous gauge whose unit sublevel is a compact positive-height box
intersected with a norm ball. The lower height bound decreases as the radius grows. -/
def gauge (r : ℝ) (x : State) : ℝ := max (‖x‖ / r) (2-r*x 0)

theorem gauge_continuous (r : ℝ) : Continuous (gauge r) := by
  unfold gauge
  fun_prop

theorem gauge_nonneg {r : ℝ} (hr : 0 < r) (x : State) : 0 ≤ gauge r x :=
  (div_nonneg (norm_nonneg x) hr.le).trans (le_max_left _ _)

theorem gauge_le_iff {r : ℝ} (hr : 0 < r) (x : State) :
    |gauge r x| ≤ 1 ↔ ‖x‖ ≤ r ∧ 1 ≤ r*x 0 := by
  rw [abs_of_nonneg (gauge_nonneg hr x),gauge,max_le_iff,div_le_iff₀ hr]
  constructor <;> rintro ⟨h₁,h₂⟩ <;> constructor <;> linarith

theorem gauge_lt_iff {r : ℝ} (hr : 0 < r) (x : State) :
    |gauge r x| < 1 ↔ ‖x‖ < r ∧ 1 < r*x 0 := by
  rw [abs_of_nonneg (gauge_nonneg hr x),gauge,max_lt_iff,div_lt_iff₀ hr]
  constructor <;> rintro ⟨h₁,h₂⟩ <;> constructor <;> linarith

theorem height_pos_of_gauge_le {r : ℝ} (hr : 0 < r) {x : State}
    (hx : |gauge r x| ≤ 1) : 0 < x 0 := by
  have h := (gauge_le_iff hr x).mp hx
  nlinarith

theorem gauge_strict_nesting {r s : ℝ} (hr : 0 < r) (hrs : r < s)
    {x : State} (hx : |gauge r x| ≤ 1) : |gauge s x| < 1 := by
  have h := (gauge_le_iff hr x).mp hx
  have hp := height_pos_of_gauge_le hr hx
  apply (gauge_lt_iff (hr.trans hrs) x).mpr
  constructor
  · exact h.1.trans_lt hrs
  · nlinarith

/-- Explicit cutoff box for each gauge sublevel. -/
def lower (r : ℝ) : State := ![1/r,-r,-r]
def upper (r : ℝ) : State := fun _ => r

theorem gauge_sublevel_box {r : ℝ} (hr : 0 < r) {x : State}
    (hx : |gauge r x| ≤ 1) : x ∈ Icc (lower r) (upper r) := by
  obtain ⟨hn,hh⟩ := (gauge_le_iff hr x).mp hx
  have hc (i : Fin 3) : |x i| ≤ r := (norm_le_pi_norm x i).trans hn
  refine ⟨?_,fun i => (le_abs_self _).trans (hc i)⟩
  intro i
  fin_cases i
  · change 1/r ≤ x 0
    exact (div_le_iff₀ hr).mpr (by nlinarith)
  · exact (abs_le.mp (hc 1)).1
  · exact (abs_le.mp (hc 2)).1

theorem gauge_sublevel_compact {r : ℝ} (hr : 0 < r) :
    IsCompact {x : State | |gauge r x| ≤ 1} := by
  apply (isCompact_closedBall (0:State) r).of_isClosed_subset
  · exact isClosed_le (gauge_continuous r).abs continuous_const
  · intro x hx
    simpa only [Metric.mem_closedBall,dist_zero_right] using ((gauge_le_iff hr x).mp hx).1

/-- Every admissible initial state lies strictly inside a first gauge region. -/
theorem exists_initial_radius (x₀ : State) (hh : 0 < x₀ 0) :
    ∃ R : ℝ, 1 < R ∧ |gauge R x₀| < 1 := by
  obtain ⟨R,hR⟩ := exists_gt (max 1 (max ‖x₀‖ (1/(x₀ 0))))
  have h1 : 1 < R := (le_max_left _ _).trans_lt hR
  have hn : ‖x₀‖ < R := (le_max_left _ _).trans (le_max_right _ _) |>.trans_lt hR
  have hi : 1/(x₀ 0) < R := (le_max_right _ _).trans (le_max_right _ _) |>.trans_lt hR
  refine ⟨R,h1,(gauge_lt_iff (by linarith) x₀).mpr ⟨hn,?_⟩⟩
  exact (div_lt_iff₀ hh).mp hi

/-- Every compact subset of positive height lies strictly inside one member
of the explicitly constructed exhaustion. -/
theorem compact_subset_gauge (R : ℝ) {K : Set State} (hK : IsCompact K)
    (hpos : ∀ x ∈ K, 0 < x 0) :
    ∃ n : ℕ, ∀ x ∈ K, |gauge ((n:ℝ)+R) x| < 1 := by
  by_cases he : K.Nonempty
  · obtain ⟨x,hx,hmin⟩ := hK.exists_isMinOn he (continuous_apply 0).continuousOn
    obtain ⟨C,hC⟩ := hK.bddAbove_image continuous_norm.continuousOn
    obtain ⟨n,hn⟩ := exists_nat_gt (max 0 (max C (1/(x 0))) - R)
    have hr : 0 < (n:ℝ)+R := by have := le_max_left 0 (max C (1/(x 0))); linarith
    have hc : C < (n:ℝ)+R := by have := (le_max_left C (1/(x 0))).trans (le_max_right 0 _); linarith
    have hh : 1/(x 0) < (n:ℝ)+R := by have := (le_max_right C (1/(x 0))).trans (le_max_right 0 _); linarith
    have hh' := (div_lt_iff₀ (hpos x hx)).mp hh
    refine ⟨n,fun y hy => (gauge_lt_iff hr y).mpr ⟨(hC (mem_image_of_mem _ hy)).trans_lt hc,?_⟩⟩
    have hm : x 0 ≤ y 0 := hmin hy
    nlinarith
  · exact ⟨0,fun x hx => False.elim (he ⟨x,hx⟩)⟩

/-- The gauge cutoff boxes are nonempty, separated from height zero, and
nested; these hypotheses are proved from the radius rather than supplied. -/
theorem cutoff_box_valid {r : ℝ} (hr : 1 < r) :
    lower r ≤ upper r ∧ 0 < lower r 0 := by
  have hpos : 0 < r := by linarith
  refine ⟨?_,by change 0 < 1/r; positivity⟩
  intro i
  fin_cases i
  · change 1/r ≤ r
    apply (div_le_iff₀ hpos).mpr
    nlinarith
  · change -r ≤ r; linarith
  · change -r ≤ r; linarith

end
end ChainFountainStochastic.MechanicalExhaustion
