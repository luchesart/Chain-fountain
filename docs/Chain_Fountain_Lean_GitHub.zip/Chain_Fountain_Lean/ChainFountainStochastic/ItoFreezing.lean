module

public import ChainFountainStochastic.ItoSmallTimeBound
public import ChainFountainStochastic.ItoLinearity

@[expose] public section

namespace ChainFountainStochastic.ItoFreezing
noncomputable section
open MeasureTheory ProbabilityTheory Real Filter Set MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM MathFin.ItoIntegralPredictable
open MathFin.ItoIntegralBrownian
open MathFin.ItoIntegralLocalised MathFin.LocalisationInMeasure
open scoped NNReal ENNReal Topology
set_option maxHeartbeats 1000000
set_option backward.isDefEq.respectTransparency true
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
  (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hT : 0 < T)
  (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
  {a : ℝ≥0 → Ω → ℝ}
  (ha : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
  (hc : ∀ ω, Continuous (a · ω))
  (hp : IsStronglyPredictable (natFiltration hBm) a)

/-- Continuity at zero controls a whole sufficiently short prefix. -/
theorem small_prefix {f : ℝ≥0 → ℝ} (hf : ContinuousAt f 0) (hz : f 0 = 0)
    {ε : ℝ} (hε : 0 < ε) :
    ∀ᶠ t in 𝓝[>] (0:ℝ≥0), ∀ s ∈ Icc 0 t, |f s| ≤ ε := by
  have hh : ∀ᶠ s in 𝓝 (0:ℝ≥0), |f s| < ε := by
    have h := hf.abs.tendsto.eventually (gt_mem_nhds (by simpa [hz] using hε))
    exact h
  obtain ⟨δ,hδ,hd⟩ := exists_Ico_subset_of_mem_nhds hh (show ∃ δ : ℝ≥0, 0 < δ from ⟨1,by norm_num⟩)
  filter_upwards [((eventually_lt_nhds hδ).filter_mono nhdsWithin_le_nhds)] with t ht s hs
  exact (hd ⟨hs.1,hs.2.trans_lt ht⟩).le

include hB hT hBc ha hc in
/-- A continuous adapted coefficient vanishing at zero contributes o(LIL scale)
to its actual stochastic integral. No random time-change representation is assumed. -/
theorem zero_coefficient (hz : ∀ᵐ ω ∂μ, a 0 ω = 0) :
    ∀ᵐ ω ∂μ, Tendsto
      (fun t => predItoIntegral (μ:=μ) T hBm hp t ω / BrownianSmallTime.scale t)
      (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
  let e := fun n : ℕ => 1 / ((n:ℝ)+1)
  have ep : ∀ n, 0 < e n := fun n => by dsimp [e]; positivity
  let b := fun n t ω => clampM (e n) (a t ω)
  have bac : ∀ n ω, Continuous (b n · ω) := fun n ω => (continuous_clampM (e n)).comp (hc ω)
  have baa : ∀ n t, StronglyMeasurable[natFiltration hBm t] (b n t) :=
    fun n t => (continuous_clampM (e n)).comp_stronglyMeasurable (ha t)
  have bap : ∀ n, IsStronglyPredictable (natFiltration hBm) (b n) :=
    fun n => (continuous_clampM (e n)).comp_stronglyMeasurable hp
  have hab (n : ℕ) := ItoSmallTimeBound.pred_integral hB T hT hBm hBc
    (baa n) (bac n) (bap n) (ep n) (fun t ω => clampM_abs_le (ep n).le (a t ω))
  have hel (n : ℕ) := LocalIntegralBridge.predIto_prefix_locality hB T hBm hBc hp (bap n)
    (ae_of_all _ fun ω => (hc ω).continuousOn) (ae_of_all _ fun ω => (bac n ω).continuousOn)
  filter_upwards [ae_all_iff.mpr hab,ae_all_iff.mpr hel,hz] with ω hbound hlocal hz
  apply Metric.tendsto_nhds.mpr
  intro ε hε
  obtain ⟨n,hn⟩ := exists_nat_one_div_lt (show 0 < ε/4 by positivity)
  have hen : 4*e n < ε := by dsimp [e]; linarith
  filter_upwards [hbound n,small_prefix (hc ω).continuousAt hz (ep n),
    ((eventually_lt_nhds hT).filter_mono nhdsWithin_le_nhds)] with t ht hs htime
  have he := hlocal n t ⟨bot_le,htime.le⟩ (fun s hs' => (clampM_eq_self (hs s hs')).symm)
  simpa only [Real.dist_eq,sub_zero,he] using ht.trans_lt hen

include hB hT hBc ha hc in
/-- Freezing the actual bounded adapted coefficient at its deterministic
initial value is valid at the sharp small-time LIL scale. -/
theorem bounded_coefficient {C q : ℝ} (hb : ∀ t ω, |a t ω| ≤ C)
    (hz : ∀ᵐ ω ∂μ, a 0 ω = q) :
    ∀ᵐ ω ∂μ, Tendsto
      (fun t => (predItoIntegral (μ:=μ) T hBm hp t ω-q*B t ω) / BrownianSmallTime.scale t)
      (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
  have hpq : IsStronglyPredictable (natFiltration hBm) (fun t ω => a t ω-q) :=
    hp.sub (show IsStronglyPredictable (natFiltration hBm) (fun _ _ => q) from stronglyMeasurable_const)
  have hzero : ∀ᵐ ω ∂μ, a 0 ω-q = 0 := hz.mono fun ω hω => sub_eq_zero.mpr hω
  filter_upwards [zero_coefficient hB T hT hBm hBc (fun t => (ha t).sub stronglyMeasurable_const)
    (fun ω => (hc ω).sub continuous_const) hpq hzero,
    ItoLinearity.pred_sub_const hB T hBm hBc ha hc hp hb q] with ω hz he
  apply hz.congr'
  filter_upwards [((eventually_lt_nhds hT).filter_mono nhdsWithin_le_nhds)] with t ht
  rw [he t ⟨bot_le,ht.le⟩]

include hB hT hBc in
/-- The same freezing theorem for the localized continuous-adapted integral
used in the pulled-back strong SDE equation. -/
theorem local_bounded {C q : ℝ} (hb : ∀ t ω, |a t ω| ≤ C)
    (hz : ∀ᵐ ω ∂μ, a 0 ω = q) :
    ∀ᵐ ω ∂μ, Tendsto
      (fun t => (localItoIntegral (μ:=μ) T hBm ha hc t ω-q*B t ω) / BrownianSmallTime.scale t)
      (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
  let hp := isStronglyPredictable_of_bdd_adapted_cont hBm ha hc
  filter_upwards [bounded_coefficient hB T hT hBm hBc ha hc hp hb hz,
    ae_localItoIntegral_eq_itoContinuousMod hB T hBm hBc ha hc hb,
    LocalIntegralBridge.continuousMod_eq_predIto hB T hBm hBc hp
      (ae_of_all _ fun ω => (hc ω).continuousOn) hb _ (processToLp_coeFn T hBm ha hc hb)] with ω hr hl hp
  apply hr.congr'
  filter_upwards [((eventually_lt_nhds hT).filter_mono nhdsWithin_le_nhds)] with t ht
  rw [hl t ⟨bot_le,ht.le⟩,hp t ⟨bot_le,ht.le⟩]

end
end ChainFountainStochastic.ItoFreezing
