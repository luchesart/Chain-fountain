module

public import ChainFountainStochastic.FiniteHorizon
public import ChainFountainStochastic.ConstructedExit

@[expose] public section

namespace ChainFountainStochastic.MechanicalFiniteHorizon
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoLocalMartingale
  MathFin.ItoIntegralProcessLocalMartingaleGeneral
open VectorSDE MechanicalCutoff LocalIntegralBridge ConstructedExit FiniteHorizon
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 900000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}

/-- One actual mechanical cutoff field admits a unique strong solution on
every finite deterministic horizon. No supplied trajectory is assumed. -/
theorem exists_unique_mechanical_cutoff_all_horizons
    {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω} [IsProbabilityMeasure μ]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (d : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi lo hi : State) (hlo : lo ≤ hi) (hh : 0 < lo 0)
    (hpmem : ∀ t, p t ∈ Icc plo phi) (x₀ : State) :
    ∃ c : Coefficients (Fin 3),
      (∀ t x, x ∈ Icc lo hi → c.drift t x = d.drift (p t,x)) ∧
      (∀ t x, x ∈ Icc lo hi → c.diffusion t x = d.diffusion (p t,x)) ∧
      (∀ t x, ‖c.drift t x‖ ≤ c.bound ∧ ‖c.diffusion t x‖ ≤ c.bound) ∧
      ∀ T : ℝ≥0, ∃ Y, StrongSolution (μ:=μ) T hBm c x₀ Y ∧
        ∀ Z, StrongSolution (μ:=μ) T hBm c x₀ Z →
          ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = Z t ω := by
  obtain ⟨c,_,_,hb,hσ,hbound⟩ := d.exists_cutoff p hp plo phi lo hi hlo hh hpmem
  refine ⟨c,hb,hσ,hbound,?_⟩
  intro T
  obtain ⟨Y,hY⟩ := exists_strong_solution_all_horizons hB T hBm hBc c x₀
  exact ⟨Y,hY,fun Z hZ => strong_solution_unique_all_horizons hB T hBm hBc c x₀ hY hZ⟩

/-- On any prescribed positive finite horizon, construct the mechanical cutoff
solution, its continuous adapted version and genuine positive capped exit.
The original mechanical equation holds before that exit. -/
theorem exists_constructed_mechanical_exit_all_horizons
    [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
    (T : ℝ≥0) (hT : 0 < T)
    (hB : IsPreBrownianReal B μ) (hBm : ∀ t, Measurable (B t))
    (hBc : ∀ ω, Continuous (fun t => B t ω))
    (d : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi lo hi : State) (hlo : lo ≤ hi) (hh : 0 < lo 0)
    (hpmem : ∀ t, p t ∈ Icc plo phi) (x₀ : State) (R : ℝ) (hR : 0 < R)
    (hball : Metric.closedBall x₀ R ⊆ Icc lo hi) :
    ∃ c : Coefficients (Fin 3),
      ∃ Y X : ℝ≥0 → Ω → State,
        StrongSolution (μ:=μ) T hBm c x₀ Y ∧
        StronglyAdapted (augFiltration (μ:=μ) hBm) X ∧
        (∀ ω, Continuous (fun t => X t ω)) ∧
        (∀ ω, X 0 ω = x₀) ∧
        (∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, X t ω = Y t ω) ∧
        IsStoppingTime (augFiltration (μ:=μ) hBm) (normExit X x₀ R T) ∧
        (∀ ω, ⊥ < normExit X x₀ R T ω) ∧
        (∀ ω, normExit X x₀ R T ω ≤ T) ∧
        (∀ t ω, stoppedProcess X (normExit X x₀ R T) t ω ∈ Icc lo hi) ∧
        (∀ᵐ ω ∂μ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ normExit X x₀ R T ω →
          c.drift t (Y t ω) = d.drift (p t,Y t ω) ∧
          c.diffusion t (Y t ω) = d.diffusion (p t,Y t ω)) ∧
        (∃ hpred : IsStronglyPredictable (natFiltration hBm) Y,
          ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ normExit X x₀ R T ω → ∀ i : Fin 3,
          Y t ω i = x₀ i + (∫ s in Ioc (0:ℝ≥0) t, d.drift (p s,Y s ω) i ∂timeMeasure) +
            MathFin.ItoIntegralLocalised.predItoIntegral (μ:=μ) T hBm
              (diffusion_predictable hBm c hpred i) t ω) := by
  obtain ⟨c,_,_,hb,hσ,hbound⟩ := d.exists_cutoff p hp plo phi lo hi hlo hh hpmem
  obtain ⟨Y,hY⟩ := exists_strong_solution_all_horizons hB T hBm hBc c x₀
  obtain ⟨X,hXm,hXc,hX₀,hXY⟩ := exists_continuous_adapted_version
    hY.predictable.stronglyAdapted hY.continuous hY.initial
  obtain ⟨hτ,hpos,hcap,hstop⟩ := normExit_properties hXm hXc hX₀ hR hT
  refine ⟨c,Y,X,hY,hXm,hXc,hX₀,hXY,hτ,hpos,hcap,
    (fun t ω => hball (hstop t ω)),?_,?_⟩
  · filter_upwards [original_state_mem_before_exit hcap hstop hXY] with ω hω
    intro t ht
    exact ⟨hb t (Y t ω) (hball (hω t ht)),hσ t (Y t ω) (hball (hω t ht))⟩
  · refine ⟨hY.predictable,?_⟩
    filter_upwards [strong_solution_predIto_equation hB T hBm hBc c x₀ hY
      (fun t x => (hbound t x).2), original_state_mem_before_exit hcap hstop hXY]
      with ω he hm
    intro t ht i
    have htT : t ≤ T := WithTop.coe_le_coe.mp (ht.trans (hcap ω))
    have hi : (∫ s in Ioc (0:ℝ≥0) t, c.drift s (Y s ω) i ∂timeMeasure) =
        ∫ s in Ioc (0:ℝ≥0) t, d.drift (p s,Y s ω) i ∂timeMeasure := by
      apply setIntegral_congr_fun measurableSet_Ioc
      intro s hs
      exact congrFun (hb s (Y s ω) (hball (hm s ((WithTop.coe_le_coe.mpr hs.2).trans ht)))) i
    simpa only [hi] using he t ⟨zero_le,htT⟩ i

end
end ChainFountainStochastic.MechanicalFiniteHorizon
