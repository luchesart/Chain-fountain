module

public import ChainFountainStochastic.CausalFixedPoint
public import Mathlib.Analysis.SpecificLimits.Basic

@[expose] public section

namespace ChainFountainStochastic.CausalConvergence
noncomputable section
open Filter Topology
open scoped NNReal
set_option maxHeartbeats 900000

/-- A nonnegative sequence with a strict contraction and a vanishing additive
error converges to zero. No boundedness of the sequence is assumed. -/
theorem tendsto_zero_of_contracting_error {u v : ℕ → ℝ} {q : ℝ}
    (hu : ∀ n, 0 ≤ u n) (hq0 : 0 ≤ q) (hq : q < 1)
    (hv : Tendsto v atTop (𝓝 0))
    (hstep : ∀ n, u (n+1) ≤ q*u n + v n) : Tendsto u atTop (𝓝 0) := by
  apply tendsto_order.2
  constructor
  · intro a ha
    exact Filter.Eventually.of_forall fun n => ha.trans_le (hu n)
  · intro ε hε
    have hb : 0 < ε/2 := half_pos hε
    have he : 0 < (1-q)*(ε/2) := mul_pos (sub_pos.mpr hq) hb
    obtain ⟨N,hN⟩ := eventually_atTop.1 (hv.eventually (gt_mem_nhds he))
    have hbound : ∀ k, u (N+k) ≤ q^k*u N + ε/2 := by
      intro k
      induction k with
      | zero => simp only [Nat.add_zero,pow_zero,one_mul]; linarith
      | succ k ih =>
        have h := hstep (N+k)
        have hvk := hN (N+k) (Nat.le_add_right _ _)
        have hm := mul_le_mul_of_nonneg_left ih hq0
        rw [pow_succ]
        simpa only [Nat.add_assoc] using (show u (N+k+1) ≤ q^k*q*u N+ε/2 by nlinarith)
    have hp : Tendsto (fun k : ℕ => q^k*u N) atTop (𝓝 0) := by
      simpa using (tendsto_pow_atTop_nhds_zero_of_lt_one hq0 hq).mul_const (u N)
    obtain ⟨K,hK⟩ := eventually_atTop.1 (hp.eventually (gt_mem_nhds hb))
    refine eventually_atTop.2 ⟨N+K,fun n hn => ?_⟩
    have hNn : N ≤ n := (Nat.le_add_right N K).trans hn
    have hKn : K ≤ n-N := by omega
    have heq : N+(n-N) = n := Nat.add_sub_of_le hNn
    have h := hbound (n-N)
    rw [heq] at h
    linarith [hK (n-N) hKn]

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- A causal short-increment contraction gives a triangular estimate: the
next-prefix error contracts, with a controlled error from the preceding prefix. -/
theorem prefix_error_bound (P Q : E →L[ℝ] E) (F : E → E)
    (hPP : ∀ x, P (P x) = P x) (hQQ : ∀ x, Q (Q x) = Q x)
    (hPQ : ∀ x, P (Q x) = P x)
    (hcausal : ∀ x y, Q x = Q y → Q (F x) = Q (F y))
    {L q : ℝ} (hL : ∀ x y, ‖F x-F y‖ ≤ L*‖x-y‖) (hq : 0 ≤ q)
    (hcontract : ∀ x y, P x = P y → ‖Q (F x)-Q (F y)‖ ≤ q*‖x-y‖)
    (x y : E) :
    ‖Q (F x)-Q (F y)‖ ≤ q*‖Q x-Q y‖ + (‖Q‖*L+q)*‖P x-P y‖ := by
  let z := Q x + P (y-x)
  have hPz : P z = P (Q y) := by
    dsimp [z]
    rw [map_add,hPP,hPQ,hPQ,map_sub]
    abel
  have hx : Q (F x) = Q (F (Q x)) := hcausal _ _ (hQQ x).symm
  have hy : Q (F y) = Q (F (Q y)) := hcausal _ _ (hQQ y).symm
  have hdiff : Q x-z = -(P (y-x)) := by dsimp [z]; abel
  have hnorm : ‖P (y-x)‖ = ‖P x-P y‖ := by rw [map_sub,norm_sub_rev]
  have hnear : ‖Q (F (Q x))-Q (F z)‖ ≤ (‖Q‖*L)*‖P x-P y‖ := by
    calc
      _ = ‖Q (F (Q x)-F z)‖ := by rw [map_sub]
      _ ≤ ‖Q‖*‖F (Q x)-F z‖ := Q.le_opNorm _
      _ ≤ ‖Q‖*(L*‖Q x-z‖) := mul_le_mul_of_nonneg_left (hL _ _) (norm_nonneg _)
      _ = _ := by rw [hdiff,norm_neg,hnorm]; ring
  have hz : ‖z-Q y‖ ≤ ‖Q x-Q y‖+‖P x-P y‖ := by
    calc
      _ = ‖(Q x-Q y)+P (y-x)‖ := by congr 1; dsimp [z]; abel
      _ ≤ _ := norm_add_le _ _
      _ = _ := by rw [hnorm]
  rw [hx,hy]
  calc
    _ ≤ ‖Q (F (Q x))-Q (F z)‖+‖Q (F z)-Q (F (Q y))‖ := norm_sub_le_norm_sub_add_norm_sub _ _ _
    _ ≤ (‖Q‖*L)*‖P x-P y‖+q*‖z-Q y‖ := add_le_add hnear (hcontract z (Q y) hPz)
    _ ≤ (‖Q‖*L)*‖P x-P y‖+q*(‖Q x-Q y‖+‖P x-P y‖) :=
      add_le_add_right (mul_le_mul_of_nonneg_left hz hq) _
    _ = _ := by ring

/-- Picard iterates of a globally Lipschitz causal map converge to its fixed
point whenever a finite partition has contracting increments. The map itself
need not contract on the full horizon. -/
theorem tendsto_iterate_of_causal_partition (N : ℕ) (P : ℕ → E →L[ℝ] E)
    (F : E → E) (hzero : ∀ x, P 0 x = 0) (hfull : ∀ x, P N x = x)
    (habsorb : ∀ m n, m ≤ n → ∀ x, P m (P n x) = P m x)
    (hcausal : ∀ n, n ≤ N → ∀ x y, P n x = P n y → P n (F x) = P n (F y))
    (L : ℝ) (hL : ∀ x y, ‖F x-F y‖ ≤ L*‖x-y‖)
    (q : ℝ≥0) (hq : q < 1)
    (hcontract : ∀ n, n < N → ∀ x y, P n x = P n y →
      ‖P (n+1) (F x)-P (n+1) (F y)‖ ≤ q*‖x-y‖)
    (x y : E) (hy : F y = y) : Tendsto (fun k => F^[k] x) atTop (𝓝 y) := by
  have hp : ∀ n, n ≤ N → Tendsto (fun k => ‖P n (F^[k] x)-P n y‖) atTop (𝓝 0) := by
    intro n
    induction n with
    | zero => intro _; simpa only [hzero,sub_self,norm_zero] using tendsto_const_nhds
    | succ n ih =>
      intro hn
      have hv := (ih (Nat.le_of_succ_le hn)).const_mul (‖P (n+1)‖*L+(q:ℝ))
      apply tendsto_zero_of_contracting_error (fun _ => norm_nonneg _) q.coe_nonneg hq
        (by simpa using hv)
      intro k
      have h := prefix_error_bound (P n) (P (n+1)) F
        (habsorb n n le_rfl) (habsorb (n+1) (n+1) le_rfl)
        (habsorb n (n+1) (Nat.le_succ _)) (hcausal (n+1) hn) hL q.coe_nonneg
        (hcontract n (Nat.lt_of_succ_le hn)) (F^[k] x) y
      simpa only [Function.iterate_succ_apply',hy] using h
  have h := hp N le_rfl
  simpa only [hfull] using (tendsto_iff_norm_sub_tendsto_zero).2 h

end
end ChainFountainStochastic.CausalConvergence
