module

public import ChainFountainStochastic.ActualIntegralLIL

@[expose] public section

/-!
# Local freezing without a global coefficient bound

The integral is the actual localized stochastic integral.  Continuity supplies
a path-dependent initial interval on which one deterministic clipping level is
inactive.  Prefix locality transports the bounded-coefficient theorem to that
interval.  No deterministic bound on the original coefficient is assumed.

The filtration is the Brownian natural filtration, as in the existing integral
construction.  This module does not assert an arbitrary-filtration extension.
-/

namespace ChainFountainStochastic.LocalFreezingCompletion
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Real MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralLocalised MathFin.LocalisationInMeasure
open MathFin.ItoIntegralBrownian
open BrownianSmallTime LILDriftStability
open scoped NNReal ENNReal Topology
set_option maxHeartbeats 1000000
set_option backward.isDefEq.respectTransparency true

variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
  {B : ℝ≥0 → Ω → ℝ}

/-- Small-time freezing of a continuous adapted predictable coefficient.  The
coefficient need not have any global deterministic bound. -/
theorem predictable_freezing
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hT : 0 < T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
    {a : ℝ≥0 → Ω → ℝ}
    (ha : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hc : ∀ ω, Continuous (a · ω))
    (hp : IsStronglyPredictable (natFiltration hBm) a)
    {q : ℝ} (hz : ∀ᵐ ω ∂μ, a 0 ω = q) :
    ∀ᵐ ω ∂μ, Tendsto
      (fun t => (predItoIntegral (μ:=μ) T hBm hp t ω-q*B t ω)/scale t)
      (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
  let C : ℝ := |q|+1
  have hC : 0 ≤ C := by dsimp [C]; positivity
  let b : ℝ≥0 → Ω → ℝ := fun t ω => clampM C (a t ω)
  have hb : ∀ t ω, |b t ω| ≤ C := fun t ω => clampM_abs_le hC (a t ω)
  have hba : ∀ t, StronglyMeasurable[natFiltration hBm t] (b t) :=
    fun t => (continuous_clampM C).comp_stronglyMeasurable (ha t)
  have hbc : ∀ ω, Continuous (b · ω) :=
    fun ω => (continuous_clampM C).comp (hc ω)
  have hbp : IsStronglyPredictable (natFiltration hBm) b :=
    (continuous_clampM C).comp_stronglyMeasurable hp
  have hbz : ∀ᵐ ω ∂μ, b 0 ω = q := hz.mono fun ω hω => by
    dsimp [b]
    rw [hω]
    exact clampM_eq_self (by dsimp [C]; linarith)
  filter_upwards [ItoFreezing.bounded_coefficient hB T hT hBm hBc hba hbc hbp hb hbz,
    LocalIntegralBridge.predIto_prefix_locality hB T hBm hBc hp hbp
      (ae_of_all _ fun ω => (hc ω).continuousOn)
      (ae_of_all _ fun ω => (hbc ω).continuousOn),hz] with ω hf he hz
  apply hf.congr'
  have hsmall := ItoFreezing.small_prefix
    (((hc ω).sub continuous_const).continuousAt) (show a 0 ω-q = 0 by rw [hz]; ring)
    (show (0:ℝ) < 1 by norm_num)
  filter_upwards [hsmall,((eventually_lt_nhds hT).filter_mono nhdsWithin_le_nhds)] with t ht htime
  have hab : ∀ s ∈ Icc 0 t, a s ω = b s ω := by
    intro s hs
    dsimp [b]
    apply (clampM_eq_self ?_).symm
    have hsmall' : |a s ω-q| ≤ 1 := ht s hs
    calc
      |a s ω| = |(a s ω-q)+q| := by congr 1; ring
      _ ≤ |a s ω-q|+|q| := abs_add_le _ _
      _ ≤ 1+|q| := by linarith
      _ = C := by dsimp [C]; ring
  rw [he t ⟨bot_le,htime.le⟩ hab]

/-- The continuous-adapted localized integral and the predictable localized
integral agree simultaneously in time, without a global bound. -/
theorem local_eq_predictable
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
    {a : ℝ≥0 → Ω → ℝ}
    (ha : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hc : ∀ ω, Continuous (a · ω))
    (hp : IsStronglyPredictable (natFiltration hBm) a) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      localItoIntegral (μ:=μ) T hBm ha hc t ω = predItoIntegral (μ:=μ) T hBm hp t ω := by
  exact ae_forall_eq_of_tendstoInMeasure
    (ae_continuousOn_localItoIntegral hB T hBm hBc ha hc)
    (ae_continuousOn_predItoIntegral hB T hBm hBc hp
      (ae_of_all _ fun ω => (hc ω).continuousOn))
    (fun t ht => tendstoInMeasure_riemannσ_localItoIntegral hB T hBm hBc ha hc ht.2)
    (fun t ht => tendstoInMeasure_riemannσ_predItoIntegral hB T hBm hBc hp
      (ae_of_all _ fun ω => (hc ω).continuousOn) ht.2)

/-- The paper's localized freezing conclusion for the actual continuous-adapted
integral.  Only continuity, adaptedness and a deterministic initial value are
required of the coefficient. -/
theorem local_freezing
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hT : 0 < T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
    {a : ℝ≥0 → Ω → ℝ}
    (ha : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hc : ∀ ω, Continuous (a · ω))
    {q : ℝ} (hz : ∀ᵐ ω ∂μ, a 0 ω = q) :
    ∀ᵐ ω ∂μ, Tendsto
      (fun t => (localItoIntegral (μ:=μ) T hBm ha hc t ω-q*B t ω)/scale t)
      (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
  let hp := isStronglyPredictable_of_bdd_adapted_cont hBm ha hc
  filter_upwards [predictable_freezing hB T hT hBm hBc ha hc hp hz,
    local_eq_predictable hB T hBm hBc ha hc hp] with ω hf he
  apply hf.congr'
  filter_upwards [((eventually_lt_nhds hT).filter_mono nhdsWithin_le_nhds)] with t ht
  rw [he t ⟨bot_le,ht.le⟩]

/-- Both sharp small-time LIL limits for an unbounded continuous adapted
coefficient, allowing every path-dependent drift which is locally O(t). -/
theorem local_integral_lil
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hT : 0 < T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
    {a : ℝ≥0 → Ω → ℝ}
    (ha : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hc : ∀ ω, Continuous (a · ω))
    {q : ℝ} (hz : ∀ᵐ ω ∂μ, a 0 ω = q) :
    ∀ᵐ ω ∂μ, ∀ A : ℝ≥0 → ℝ, ∀ K : ℝ,
      (∀ᶠ t in 𝓝[>] (0:ℝ≥0), |A t| ≤ K*(t:ℝ)) →
      limsup (fun t => ((localItoIntegral (μ:=μ) T hBm ha hc t ω+A t)/scale t).toEReal)
        (𝓝[>] (0:ℝ≥0)) = |q| ∧
      liminf (fun t => ((localItoIntegral (μ:=μ) T hBm ha hc t ω+A t)/scale t).toEReal)
        (𝓝[>] (0:ℝ≥0)) = -|q| := by
  filter_upwards [ActualIntegralLIL.transfer (show IsBrownianReal B μ from ⟨hB,ae_of_all _ hBc⟩),
    local_freezing hB T hT hBm hBc ha hc hz] with ω ht hr
  intro A K hA
  apply ht q
  convert hr.add (bounded_drift_negligible hA) using 1
  · ext t
    ring
  · simp

/-- Stopping on any almost-surely positive initial interval leaves the freezing
limit unchanged.  No stopping-time hypothesis is needed for this germ fact:
for each path, `min t (τ ω) = t` eventually as `t` decreases to zero. -/
theorem local_freezing_stopped
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hT : 0 < T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
    {a : ℝ≥0 → Ω → ℝ}
    (ha : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hc : ∀ ω, Continuous (a · ω))
    {q : ℝ} (hz : ∀ᵐ ω ∂μ, a 0 ω = q)
    {τ : Ω → ℝ≥0} (hτ : ∀ᵐ ω ∂μ, 0 < τ ω) :
    ∀ᵐ ω ∂μ, Tendsto
      (fun t => (localItoIntegral (μ:=μ) T hBm ha hc (min t (τ ω)) ω-q*B t ω)/scale t)
      (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
  filter_upwards [local_freezing hB T hT hBm hBc ha hc hz,hτ] with ω hf htau
  apply hf.congr'
  filter_upwards [((eventually_lt_nhds htau).filter_mono nhdsWithin_le_nhds)] with t ht
  rw [min_eq_left ht.le]

/-- The same germ statement for the standard stopped process, allowing an
infinite stopping time.  Positivity is the only property of the random time
used here; stochastic optional-stopping assertions are not being invoked. -/
theorem local_freezing_stoppedProcess
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hT : 0 < T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
    {a : ℝ≥0 → Ω → ℝ}
    (ha : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hc : ∀ ω, Continuous (a · ω))
    {q : ℝ} (hz : ∀ᵐ ω ∂μ, a 0 ω = q)
    {τ : Ω → WithTop ℝ≥0} (hτ : ∀ᵐ ω ∂μ, 0 < τ ω) :
    ∀ᵐ ω ∂μ, Tendsto
      (fun t => (stoppedProcess (localItoIntegral (μ:=μ) T hBm ha hc) τ t ω-q*B t ω)/scale t)
      (𝓝[>] (0:ℝ≥0)) (𝓝 0) := by
  filter_upwards [local_freezing hB T hT hBm hBc ha hc hz,hτ] with ω hf htau
  apply hf.congr'
  have he : ∀ᶠ t : ℝ≥0 in 𝓝[>] (0:ℝ≥0), (t:WithTop ℝ≥0) ≤ τ ω := by
    by_cases htop : τ ω = ⊤
    · exact Eventually.of_forall (fun _ => by rw [htop]; exact le_top)
    · have hu : ((τ ω).untopA:WithTop ℝ≥0) = τ ω := by
        rw [WithTop.untopA_eq_untop htop]
        exact WithTop.coe_untop _ _
      have hp : (0:ℝ≥0) < (τ ω).untopA := WithTop.coe_lt_coe.mp (by
        simpa only [hu,WithTop.coe_zero] using htau)
      filter_upwards [((eventually_lt_nhds hp).filter_mono nhdsWithin_le_nhds)] with t ht
      exact hu ▸ WithTop.coe_le_coe.mpr ht.le
  filter_upwards [he] with t ht
  rw [stoppedProcess_eq_of_le ht]

end
end ChainFountainStochastic.LocalFreezingCompletion
