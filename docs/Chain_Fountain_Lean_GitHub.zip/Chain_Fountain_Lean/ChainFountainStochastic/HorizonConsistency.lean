module

public import ChainFountainStochastic.FiniteStoppedUniqueness

@[expose] public section

namespace ChainFountainStochastic.HorizonConsistency
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM MathFin.ItoIntegralLocalised
open MathFin.LocalisationInMeasure
open VectorSDE VectorLp LocalIntegralBridge TimeProjection FiniteHorizon
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1000000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The localized predictable integral is consistent between horizons on one
conull event, because both versions are limits of the same Riemann sums. -/
theorem predIto_horizon_consistency
    (hB : IsPreBrownianReal B μ) (S T : ℝ≥0) (hST : S ≤ T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {a : ℝ≥0 → Ω → ℝ} (hp : IsStronglyPredictable (natFiltration hBm) a)
    (hc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => a t ω) (Icc 0 T)) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 S,
      predItoIntegral (μ:=μ) S hBm hp t ω = predItoIntegral (μ:=μ) T hBm hp t ω := by
  have hcS := hc.mono fun _ h => h.mono (Icc_subset_Icc_right hST)
  exact ae_forall_eq_of_tendstoInMeasure
    (ae_continuousOn_predItoIntegral hB S hBm hBc hp hcS)
    ((ae_continuousOn_predItoIntegral hB T hBm hBc hp hc).mono
      fun _ h => h.mono (Icc_subset_Icc_right hST))
    (fun _ ht => tendstoInMeasure_riemannσ_predItoIntegral hB S hBm hBc hp hcS ht.2)
    (fun _ ht => tendstoInMeasure_riemannσ_predItoIntegral hB T hBm hBc hp hc (ht.2.trans hST))

/-- A bounded-diffusion strong solution restricts to every smaller horizon.
The stochastic-integral consistency is proved, not assumed. -/
theorem strong_solution_restrict
    (hB : IsPreBrownianReal B μ) (S T : ℝ≥0) (hST : S ≤ T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    {Y : ℝ≥0 → Ω → (ι → ℝ)} (hY : StrongSolution (μ:=μ) T hBm c x₀ Y) :
    StrongSolution (μ:=μ) S hBm c x₀ Y := by
  have hm : trimMeasure_T (μ:=μ) S hBm ≤ trimMeasure_T (μ:=μ) T hBm := by
    rw [←trim_restrict_eq T S hBm hST]
    exact Measure.restrict_le_self
  have hψ := hY.diffusion_memLp.mono_measure hm
  have he (i : ι) : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 S,
      vectorIto S hBm (hψ.toLp (fun z => c.diffusion z.1 (Y z.1 z.2))) t ω i =
        predItoIntegral (μ:=μ) T hBm (diffusion_predictable hBm c hY.predictable i) t ω := by
    have hc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => c.diffusion t (Y t ω) i) (Icc 0 T) :=
      hY.continuous.mono fun _ h => (continuous_apply i).comp_continuousOn
        (c.diffusion_continuous.comp_continuousOn (continuousOn_id.prodMk h))
    have hi := continuousMod_eq_predIto hB S hBm hBc
      (diffusion_predictable hBm c hY.predictable i)
      (hc.mono fun _ h => h.mono (Icc_subset_Icc_right hST))
      (fun t ω => (norm_le_pi_norm (c.diffusion t (Y t ω)) i).trans (hb t (Y t ω)))
      (evalLp (mα := (natFiltration hBm).predictable) (trimMeasure_T (μ:=μ) S hBm) i
        (hψ.toLp (fun z => c.diffusion z.1 (Y z.1 z.2)))) (by
        filter_upwards [evalLp_coe (mα := (natFiltration hBm).predictable)
          (trimMeasure_T (μ:=μ) S hBm) i (hψ.toLp _),hψ.coeFn_toLp] with z hz hψ
        exact hz.trans (congrFun hψ i))
    filter_upwards [hi,predIto_horizon_consistency hB S T hST hBm hBc
      (diffusion_predictable hBm c hY.predictable i) hc] with ω hi he
    exact fun t ht => (hi t ht).trans (he t ht)
  refine ⟨hY.predictable,hY.continuous.mono (fun _ h => h.mono (Icc_subset_Icc_right hST)),
    hY.initial,hY.state_memLp.mono_measure hm,hY.drift_memLp.mono_measure hm,hψ,?_⟩
  filter_upwards [strong_solution_predIto_equation hB T hBm hBc c x₀ hY hb,
    ae_all_iff.mpr he] with ω hω he
  intro t ht i
  rw [he i t ⟨zero_le,ht⟩]
  exact hω t ⟨zero_le,ht.trans hST⟩ i

/-- All-times equality of predictable paths on a finite interval implies
 equality in its predictable L2 measure. -/
theorem predictable_ae_eq_of_path_eq (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    {Y Z : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : IsStronglyPredictable (natFiltration hBm) Y)
    (hZ : IsStronglyPredictable (natFiltration hBm) Z)
    (he : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, Y t ω = Z t ω) :
    Function.uncurry Y =ᵐ[trimMeasure_T (μ:=μ) T hBm] Function.uncurry Z := by
  apply StronglyMeasurable.ae_eq_trim_of_stronglyMeasurable
    (natFiltration hBm).predictable_le_prod hY hZ
  apply (Measure.ae_prod_iff_ae_ae ((hY.mono (natFiltration hBm).predictable_le_prod).measurableSet_eq_fun
    (hZ.mono (natFiltration hBm).predictable_le_prod))).2
  filter_upwards [ae_restrict_mem measurableSet_Ioc] with t ht
  filter_upwards [he] with ω hω
  exact hω t ⟨ht.1.le,ht.2⟩

/-- Strong-solution properties transfer to an indistinguishable predictable
version with the same pathwise initial value. -/
theorem strong_solution_congr (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    (c : Coefficients ι) (x₀ : ι → ℝ)
    {Y Z : ℝ≥0 → Ω → (ι → ℝ)} (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hp : IsStronglyPredictable (natFiltration hBm) Z) (h₀ : ∀ ω, Z 0 ω = x₀)
    (he : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, Y t ω = Z t ω) :
    StrongSolution (μ:=μ) T hBm c x₀ Z := by
  have hLp := predictable_ae_eq_of_path_eq T hBm hY.predictable hp he
  have hd : (fun z : ℝ≥0 × Ω => c.drift z.1 (Y z.1 z.2)) =ᵐ[trimMeasure_T (μ:=μ) T hBm]
      (fun z => c.drift z.1 (Z z.1 z.2)) := hLp.mono fun z hz => congrArg (c.drift z.1) hz
  have hs : (fun z : ℝ≥0 × Ω => c.diffusion z.1 (Y z.1 z.2)) =ᵐ[trimMeasure_T (μ:=μ) T hBm]
      (fun z => c.diffusion z.1 (Z z.1 z.2)) := hLp.mono fun z hz => congrArg (c.diffusion z.1) hz
  have hψ := hY.diffusion_memLp.ae_eq hs
  have hclass := MemLp.toLp_congr hY.diffusion_memLp hψ hs
  refine ⟨hp,?_,h₀,hY.state_memLp.ae_eq hLp,hY.drift_memLp.ae_eq hd,hψ,?_⟩
  · filter_upwards [hY.continuous,he] with ω hc he
    exact hc.congr (fun t ht => (he t ht).symm)
  · filter_upwards [hY.equation,he] with ω hω he
    intro t ht i
    rw [←hclass,←he t ⟨zero_le,ht⟩,hω t ht i]
    congr 2
    apply setIntegral_congr_fun measurableSet_Ioc
    intro s hs
    change c.drift s (Y s ω) i = c.drift s (Z s ω) i
    rw [he s ⟨hs.1.le,hs.2.trans ht⟩]

end
end ChainFountainStochastic.HorizonConsistency
