module

public import ChainFountainStochastic.GlobalCutoffSDE
public import ChainFountainStochastic.FiniteCutoffCompatibility

@[expose] public section

namespace ChainFountainStochastic.GlobalLocalization
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralProcessLocalMartingaleGeneral
open VectorSDE GlobalCutoffSDE FiniteStoppedUniqueness ConstructedExit MechanicalCutoff
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1000000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Global prefix uniqueness allows an infinite-valued random prefix. All
finite-horizon null sets are combined countably before choosing the time. -/
theorem global_prefix_unique
    (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c d : Coefficients ι) (x₀ : ι → ℝ)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖d.diffusion t x‖ ≤ d.bound)
    {Y Z : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y)
    (hZ : GlobalStrongSolution (μ:=μ) hBm d x₀ Z)
    (τ : Ω → WithTop ℝ≥0)
    (hcoeff : ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ τ ω →
      c.drift t (Z t ω) = d.drift t (Z t ω) ∧
      c.diffusion t (Z t ω) = d.diffusion t (Z t ω)) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ τ ω → Y t ω = Z t ω := by
  have he (N : ℕ) : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 (N:ℝ≥0), (t:WithTop ℝ≥0) ≤ τ ω →
      Y t ω = Z t ω := by
    let τN := fun ω => (min ((N:ℝ≥0):WithTop ℝ≥0) (τ ω)).untopA
    have hτN (ω : Ω) : (τN ω:WithTop ℝ≥0) = min ((N:ℝ≥0):WithTop ℝ≥0) (τ ω) :=
      coe_untopA_min _ _
    have hc : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 (N:ℝ≥0), t ≤ τN ω →
        c.drift t (Z t ω) = d.drift t (Z t ω) ∧
        c.diffusion t (Z t ω) = d.diffusion t (Z t ω) := by
      filter_upwards [hcoeff] with ω hω
      intro t _ ht
      exact hω t ((WithTop.coe_le_coe.mpr ht).trans (by rw [hτN]; exact min_le_right _ _))
    filter_upwards [strong_solution_prefix_unique_all_horizons hB N hBm hBc c d x₀ hb hd
      (hY N) (hZ N) τN hc] with ω hω
    intro t ht hτ
    apply hω t ht
    apply WithTop.coe_le_coe.mp
    rw [hτN]
    exact le_min (WithTop.coe_le_coe.mpr ht.2) hτ
  filter_upwards [ae_all_iff.mpr he] with ω hω
  intro t ht
  obtain ⟨N,hN⟩ := exists_nat_ge t
  exact hω N t ⟨zero_le,hN⟩ ht

/-- The uncapped first exit from a continuous gauge sublevel. The value top
means the path never reaches the boundary. -/
def gaugeExit {E : Type*} (X : ℝ≥0 → Ω → E) (g : E → ℝ) : Ω → WithTop ℝ≥0 :=
  exitTime (fun t ω => g (X t ω)) 1

/-- A genuine positive stopping time without a deterministic cap; its stopped
path remains in the closed gauge sublevel. -/
theorem gaugeExit_properties
    {E : Type*} [NormedAddCommGroup E] [MeasurableSpace E] [BorelSpace E]
    {ℱ : Filtration ℝ≥0 mΩ} {X : ℝ≥0 → Ω → E} {g : E → ℝ} {x₀ : E}
    (hX : StronglyAdapted ℱ X) (hXc : ∀ ω, Continuous (fun t => X t ω))
    (hg : Continuous g) (h₀ : ∀ ω, X 0 ω = x₀) (hi : |g x₀| < 1) :
    IsStoppingTime ℱ (gaugeExit X g) ∧ (∀ ω, ⊥ < gaugeExit X g ω) ∧
      (∀ t ω, |g (stoppedProcess X (gaugeExit X g) t ω)| ≤ 1) := by
  have hc : ∀ ω, Continuous (fun t => g (X t ω)) := fun ω => hg.comp (hXc ω)
  have hm : ∀ t, Measurable[ℱ t] (fun ω => g (X t ω)) :=
    fun t => (hg.comp_stronglyMeasurable (hX t)).measurable
  have hpos (ω : Ω) : ⊥ < gaugeExit X g ω := by
    apply lt_of_not_ge
    intro hn
    obtain ⟨s,hs,hg⟩ := (exitTime_le_iff hc 1 0 ω).mp hn
    have hs0 : s = 0 := le_antisymm hs.2 zero_le
    have hg' : 1 ≤ |g x₀| := by simpa only [hs0,h₀,Nat.cast_one] using hg
    exact not_le.mpr hi hg'
  refine ⟨isStoppingTime_exitTime_of_measurable hm hc 1,hpos,?_⟩
  intro t ω
  simpa only [stoppedProcess,Nat.cast_one] using abs_le_of_le_exitTime hc (hpos ω)
    (s := (min (t:WithTop ℝ≥0) (gaugeExit X g ω)).untopA)
    (by rw [coe_untopA_min]; exact min_le_right _ _)

/-- Equality before the smaller genuine gauge exit forces equality of the
uncapped exit times, including the case of infinite exits. -/
theorem gaugeExit_eq_of_prefix_eq
    {E : Type*} [TopologicalSpace E] {X Z : ℝ≥0 → Ω → E} {g : E → ℝ}
    (hXc : ∀ ω, Continuous (fun t => X t ω))
    (hZc : ∀ ω, Continuous (fun t => Z t ω)) (hg : Continuous g)
    (ω : Ω)
    (he : ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ min (gaugeExit X g ω) (gaugeExit Z g ω) → X t ω = Z t ω) :
    gaugeExit X g ω = gaugeExit Z g ω := by
  have hn (A C : ℝ≥0 → Ω → E)
      (hA : ∀ ω, Continuous (fun t => A t ω))
      (hC : ∀ ω, Continuous (fun t => C t ω))
      (heq : ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ min (gaugeExit A g ω) (gaugeExit C g ω) → A t ω = C t ω) :
      ¬ gaugeExit A g ω < gaugeExit C g ω := by
    intro hlt
    have hfinite : gaugeExit A g ω ≠ ⊤ := ne_of_lt (hlt.trans_le le_top)
    let u := (gaugeExit A g ω).untopA
    have hu : (u:WithTop ℝ≥0) = gaugeExit A g ω := by
      dsimp [u]
      rw [WithTop.untopA_eq_untop hfinite]
      exact WithTop.coe_untop _ _
    obtain ⟨s,hs,hb⟩ := (exitTime_le_iff (fun ω => hg.comp (hA ω)) 1 u ω).mp hu.ge
    have hsA : (s:WithTop ℝ≥0) ≤ gaugeExit A g ω := hu ▸ WithTop.coe_le_coe.mpr hs.2
    have hsame := heq s (le_min hsA (hsA.trans hlt.le))
    have hCle : gaugeExit C g ω ≤ (u:WithTop ℝ≥0) :=
      (exitTime_le_iff (fun ω => hg.comp (hC ω)) 1 u ω).mpr ⟨s,hs,by simpa only [Function.comp_apply,hsame] using hb⟩
    exact not_le.mpr hlt (hu ▸ hCle)
  exact le_antisymm (not_lt.mp (hn Z X hZc hXc (fun t ht =>
    (he t (by simpa only [min_comm] using ht)).symm))) (not_lt.mp (hn X Z hXc hZc he))

/-- Global cutoff compatibility up to the actual uncapped exit of any common
continuous gauge region. The exits and stopped paths are indistinguishable. -/
theorem global_versions_stopped_eq
    (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c d : Coefficients ι) (x₀ : ι → ℝ)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖d.diffusion t x‖ ≤ d.bound)
    {Y Z XY XZ : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y)
    (hZ : GlobalStrongSolution (μ:=μ) hBm d x₀ Z)
    (hXYa : StronglyAdapted (augFiltration (μ:=μ) hBm) XY)
    (hXZa : StronglyAdapted (augFiltration (μ:=μ) hBm) XZ)
    (hXYc : ∀ ω, Continuous (fun t => XY t ω))
    (hXZc : ∀ ω, Continuous (fun t => XZ t ω))
    (hXY₀ : ∀ ω, XY 0 ω = x₀) (hXZ₀ : ∀ ω, XZ 0 ω = x₀)
    (hXY : ∀ᵐ ω ∂μ, ∀ t, XY t ω = Y t ω)
    (hXZ : ∀ᵐ ω ∂μ, ∀ t, XZ t ω = Z t ω)
    (g : (ι → ℝ) → ℝ) (hg : Continuous g) (hi : |g x₀| < 1)
    (hcoeff : ∀ t x, |g x| ≤ 1 → c.drift t x = d.drift t x ∧ c.diffusion t x = d.diffusion t x) :
    ∀ᵐ ω ∂μ, gaugeExit XY g ω = gaugeExit XZ g ω ∧
      ∀ t, stoppedProcess XY (gaugeExit XY g) t ω = stoppedProcess XZ (gaugeExit XZ g) t ω := by
  have hs := (gaugeExit_properties hXZa hXZc hg hXZ₀ hi).2.2
  have hc : ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ gaugeExit XZ g ω →
      c.drift t (Z t ω) = d.drift t (Z t ω) ∧ c.diffusion t (Z t ω) = d.diffusion t (Z t ω) := by
    filter_upwards [hXZ] with ω hω
    intro t ht
    apply hcoeff
    rw [←hω t]
    simpa only [stoppedProcess_eq_of_le ht] using hs t ω
  filter_upwards [global_prefix_unique hB hBm hBc c d x₀ hb hd hY hZ (gaugeExit XZ g) hc,
    hXY,hXZ] with ω he hXY hXZ
  have hsame (t : ℝ≥0) (ht : (t:WithTop ℝ≥0) ≤ gaugeExit XZ g ω) : XY t ω = XZ t ω :=
    (hXY t).trans ((he t ht).trans (hXZ t).symm)
  have hτ := gaugeExit_eq_of_prefix_eq hXYc hXZc hg ω
    (fun t ht => hsame t (ht.trans (min_le_right _ _)))
  refine ⟨hτ,fun t => ?_⟩
  change XY (min (t:WithTop ℝ≥0) (gaugeExit XY g ω)).untopA ω =
    XZ (min (t:WithTop ℝ≥0) (gaugeExit XZ g ω)).untopA ω
  rw [hτ]
  apply hsame
  rw [coe_untopA_min]
  exact min_le_right _ _

/-- Two actual mechanical cutoffs have globally constructed strong solutions
with identical uncapped exits and stopped paths in any common gauge region.
All trajectories, continuous versions and stopping times are conclusions. -/
theorem exists_compatible_global_mechanical_cutoffs
    (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (a : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi lo₁ hi₁ lo₂ hi₂ : State)
    (hlo₁ : lo₁ ≤ hi₁) (hh₁ : 0 < lo₁ 0) (hlo₂ : lo₂ ≤ hi₂) (hh₂ : 0 < lo₂ 0)
    (hpmem : ∀ t, p t ∈ Icc plo phi) (x₀ : State)
    (g : State → ℝ) (hg : Continuous g) (hi : |g x₀| < 1)
    (hbox₁ : ∀ x, |g x| ≤ 1 → x ∈ Icc lo₁ hi₁)
    (hbox₂ : ∀ x, |g x| ≤ 1 → x ∈ Icc lo₂ hi₂) :
    ∃ c d : Coefficients (Fin 3),
      (∀ t x, x ∈ Icc lo₁ hi₁ → c.drift t x = a.drift (p t,x) ∧ c.diffusion t x = a.diffusion (p t,x)) ∧
      (∀ t x, x ∈ Icc lo₂ hi₂ → d.drift t x = a.drift (p t,x) ∧ d.diffusion t x = a.diffusion (p t,x)) ∧
      ∃ Y Z XY XZ : ℝ≥0 → Ω → State,
        GlobalStrongSolution (μ:=μ) hBm c x₀ Y ∧ GlobalStrongSolution (μ:=μ) hBm d x₀ Z ∧
        StronglyAdapted (augFiltration (μ:=μ) hBm) XY ∧ StronglyAdapted (augFiltration (μ:=μ) hBm) XZ ∧
        (∀ ω, Continuous (fun t => XY t ω)) ∧ (∀ ω, Continuous (fun t => XZ t ω)) ∧
        (∀ ω, XY 0 ω = x₀ ∧ XZ 0 ω = x₀) ∧
        (∀ᵐ ω ∂μ, ∀ t, XY t ω = Y t ω ∧ XZ t ω = Z t ω) ∧
        IsStoppingTime (augFiltration (μ:=μ) hBm) (gaugeExit XY g) ∧
        IsStoppingTime (augFiltration (μ:=μ) hBm) (gaugeExit XZ g) ∧
        (∀ ω, ⊥ < gaugeExit XY g ω ∧ ⊥ < gaugeExit XZ g ω) ∧
        (∀ᵐ ω ∂μ, gaugeExit XY g ω = gaugeExit XZ g ω ∧
          ∀ t, stoppedProcess XY (gaugeExit XY g) t ω = stoppedProcess XZ (gaugeExit XZ g) t ω) := by
  obtain ⟨c,_,_,hcb,hcσ,hcbound⟩ := a.exists_cutoff p hp plo phi lo₁ hi₁ hlo₁ hh₁ hpmem
  obtain ⟨d,_,_,hdb,hdσ,hdbound⟩ := a.exists_cutoff p hp plo phi lo₂ hi₂ hlo₂ hh₂ hpmem
  obtain ⟨Y,hY⟩ := exists_global_strong_solution hB hBm hBc c x₀ (fun t x => (hcbound t x).2)
  obtain ⟨Z,hZ⟩ := exists_global_strong_solution hB hBm hBc d x₀ (fun t x => (hdbound t x).2)
  obtain ⟨XY,hXYa,hXYc,hXY₀,hXY⟩ := exists_global_continuous_adapted_version hBm c x₀ hY
  obtain ⟨XZ,hXZa,hXZc,hXZ₀,hXZ⟩ := exists_global_continuous_adapted_version hBm d x₀ hZ
  obtain ⟨hτY,hposY,_⟩ := gaugeExit_properties hXYa hXYc hg hXY₀ hi
  obtain ⟨hτZ,hposZ,_⟩ := gaugeExit_properties hXZa hXZc hg hXZ₀ hi
  refine ⟨c,d,(fun t x hx => ⟨hcb t x hx,hcσ t x hx⟩),(fun t x hx => ⟨hdb t x hx,hdσ t x hx⟩),
    Y,Z,XY,XZ,hY,hZ,hXYa,hXZa,hXYc,hXZc,(fun ω => ⟨hXY₀ ω,hXZ₀ ω⟩),?_,hτY,hτZ,
    (fun ω => ⟨hposY ω,hposZ ω⟩),?_⟩
  · filter_upwards [hXY,hXZ] with ω hXY hXZ
    exact fun t => ⟨hXY t,hXZ t⟩
  · apply global_versions_stopped_eq hB hBm hBc c d x₀
      (fun t x => (hcbound t x).2) (fun t x => (hdbound t x).2)
      hY hZ hXYa hXZa hXYc hXZc hXY₀ hXZ₀ hXY hXZ g hg hi
    intro t x hx
    exact ⟨(hcb t x (hbox₁ x hx)).trans (hdb t x (hbox₂ x hx)).symm,
      (hcσ t x (hbox₁ x hx)).trans (hdσ t x (hbox₂ x hx)).symm⟩

end
end ChainFountainStochastic.GlobalLocalization
