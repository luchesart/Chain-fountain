module

public import Mathlib.MeasureTheory.Function.LpSpace.Complete
public import Mathlib.MeasureTheory.SpecificCodomains.Pi
public import Mathlib.Tactic

@[expose] public section
namespace ChainFountainStochastic.VectorLp
noncomputable section
open MeasureTheory Filter Set
open scoped ENNReal NNReal
set_option backward.isDefEq.respectTransparency true
variable {α : Type*} [mα : MeasurableSpace α] (μ : Measure α)
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Coordinate projection on predictable or ordinary vector L2 spaces. -/
def evalLp (i : ι) : Lp (ι → ℝ) 2 μ →L[ℝ] Lp ℝ 2 μ :=
  (ContinuousLinearMap.proj i : (ι → ℝ) →L[ℝ] ℝ).compLpL 2 μ

/-- Coordinate injection on vector L2 spaces. -/
def singleLp (i : ι) : Lp ℝ 2 μ →L[ℝ] Lp (ι → ℝ) 2 μ :=
  (ContinuousLinearMap.single ℝ (fun _ : ι => ℝ) i).compLpL 2 μ

theorem evalLp_coe (i : ι) (X : Lp (ι → ℝ) 2 μ) :
    ⇑(evalLp μ i X) =ᵐ[μ] fun a => X a i :=
  (ContinuousLinearMap.proj i : (ι → ℝ) →L[ℝ] ℝ).coeFn_compLpL X

theorem singleLp_coe (i : ι) (X : Lp ℝ 2 μ) :
    ⇑(singleLp μ i X) =ᵐ[μ] fun a => Pi.single i (X a) :=
  (ContinuousLinearMap.single ℝ (fun _ : ι => ℝ) i).coeFn_compLpL X

theorem evalLp_norm_le (i : ι) (X : Lp (ι → ℝ) 2 μ) : ‖evalLp μ i X‖ ≤ ‖X‖ := by
  apply Lp.norm_le_norm_of_ae_le
  filter_upwards [evalLp_coe μ i X] with a ha
  rw [ha]
  exact norm_le_pi_norm (X a) i

theorem singleLp_norm_le (i : ι) (X : Lp ℝ 2 μ) : ‖singleLp μ i X‖ ≤ ‖X‖ := by
  apply Lp.norm_le_norm_of_ae_le
  filter_upwards [singleLp_coe μ i X] with a ha
  rw [ha,Pi.norm_single]

/-- Assemble scalar L2 coordinates without identifying arbitrary representatives. -/
def assembleLp (X : ι → Lp ℝ 2 μ) : Lp (ι → ℝ) 2 μ := ∑ i, singleLp μ i (X i)

theorem assembleLp_coe (X : ι → Lp ℝ 2 μ) :
    ⇑(assembleLp μ X) =ᵐ[μ] fun a i => X i a := by
  have hc : ∀ᵐ a ∂μ, ∀ i, singleLp μ i (X i) a = Pi.single i (X i a) :=
    ae_all_iff.mpr (fun i => singleLp_coe μ i (X i))
  filter_upwards [Lp.coeFn_fun_finsetSum Finset.univ (fun i => singleLp μ i (X i)),hc] with a ha hc
  change (∑ i, singleLp μ i (X i) : Lp (ι → ℝ) 2 μ) a = _
  rw [ha]
  simp_rw [hc]
  ext i
  simp

theorem assembleLp_sub (X Y : ι → Lp ℝ 2 μ) :
    assembleLp μ (fun i => X i-Y i) = assembleLp μ X-assembleLp μ Y := by
  simp [assembleLp,map_sub,Finset.sum_sub_distrib]

theorem assembleLp_norm_le (X : ι → Lp ℝ 2 μ) :
    ‖assembleLp μ X‖ ≤ ∑ i, ‖X i‖ := by
  exact (norm_sum_le _ _).trans (Finset.sum_le_sum fun i _ => singleLp_norm_le μ i (X i))

/-- Lifting one scalar operator to a coupled finite-dimensional L2 state costs
only the dimension in this sup-norm estimate. No coordinate independence is used. -/
def liftOperator (A : Lp ℝ 2 μ → Lp ℝ 2 μ) (X : Lp (ι → ℝ) 2 μ) : Lp (ι → ℝ) 2 μ :=
  assembleLp μ (fun i => A (evalLp μ i X))

theorem liftOperator_sub_norm_le {q : ℝ} (hq : 0 ≤ q)
    {A : Lp ℝ 2 μ → Lp ℝ 2 μ}
    (hA : ∀ X Y, ‖A X-A Y‖ ≤ q*‖X-Y‖) (X Y : Lp (ι → ℝ) 2 μ) :
    ‖liftOperator μ A X-liftOperator μ A Y‖ ≤ (Fintype.card ι : ℝ)*q*‖X-Y‖ := by
  rw [liftOperator,liftOperator,←assembleLp_sub]
  calc
    _ ≤ ∑ i, ‖A (evalLp μ i X)-A (evalLp μ i Y)‖ := assembleLp_norm_le μ _
    _ ≤ ∑ i : ι, q*‖X-Y‖ := Finset.sum_le_sum fun i _ =>
      (hA _ _).trans (mul_le_mul_of_nonneg_left
        (by rw [←map_sub]; exact evalLp_norm_le μ i (X-Y)) hq)
    _ = _ := by simp; ring

section Coefficients
variable {E : Type*} [NormedAddCommGroup E]
variable [IsFiniteMeasure μ]
variable {clock : α → ℝ≥0} (hm : StronglyMeasurable clock)
variable {f : ℝ≥0 → E → E} (hf : Continuous (Function.uncurry f))
variable {L : ℝ≥0} (hL : ∀ t, LipschitzWith L (f t))
variable {M : ℝ} (hM : ∀ a, ‖f (clock a) 0‖ ≤ M)

include hm hf hL hM

/-- Time-dependent Lipschitz composition preserves L2. -/
theorem coefficient_memLp (X : Lp E 2 μ) : MemLp (fun a => f (clock a) (X a)) 2 μ := by
  have hzero : MemLp (fun a => f (clock a) 0) 2 μ :=
    MemLp.of_bound (hf.comp_stronglyMeasurable (hm.prodMk stronglyMeasurable_const)).aestronglyMeasurable
      M (ae_of_all _ hM)
  have hdiff : MemLp (fun a => f (clock a) (X a)-f (clock a) 0) 2 μ := by
    refine (Lp.memLp X).of_le_mul (c := (L:ℝ))
      ((hf.comp_stronglyMeasurable (hm.prodMk (Lp.stronglyMeasurable X))).sub
        (hf.comp_stronglyMeasurable (hm.prodMk stronglyMeasurable_const))).aestronglyMeasurable ?_
    exact ae_of_all _ (fun a => by simpa using (hL (clock a)).norm_sub_le (X a) 0)
  simpa only [Pi.add_def,sub_add_cancel] using hdiff.add hzero

/-- The Nemytskii operator for the actual time-dependent coefficient. -/
def coefficientLp (X : Lp E 2 μ) : Lp E 2 μ :=
  (coefficient_memLp μ hm hf hL hM X).toLp (fun a => f (clock a) (X a))

theorem coefficientLp_coe (X : Lp E 2 μ) :
    ⇑(coefficientLp μ hm hf hL hM X) =ᵐ[μ] fun a => f (clock a) (X a) :=
  (coefficient_memLp μ hm hf hL hM X).coeFn_toLp

theorem coefficientLp_sub_norm_le (X Y : Lp E 2 μ) :
    ‖coefficientLp μ hm hf hL hM X-coefficientLp μ hm hf hL hM Y‖ ≤ L*‖X-Y‖ := by
  apply Lp.norm_le_mul_norm_of_ae_le_mul
  filter_upwards [coefficientLp_coe μ hm hf hL hM X,coefficientLp_coe μ hm hf hL hM Y,
    Lp.coeFn_sub (coefficientLp μ hm hf hL hM X) (coefficientLp μ hm hf hL hM Y),
    Lp.coeFn_sub X Y] with a hx hy hsub hxy
  simp only [hsub,Pi.sub_apply,hx,hy,hxy]
  exact (hL (clock a)).norm_sub_le (X a) (Y a)
end Coefficients
end
end ChainFountainStochastic.VectorLp
