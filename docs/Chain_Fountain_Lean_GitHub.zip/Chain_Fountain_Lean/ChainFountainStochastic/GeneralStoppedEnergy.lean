module

public import ChainFountainStochastic.StoppedGenerator

@[expose] public section
namespace ChainFountainStochastic
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory MathFin
open MathFin.ItoIntegralL2 MathFin.AdaptedDrift
open scoped NNReal Topology

/-- A continuous adapted energy with a local-martingale decomposition obeys
Dynkin's dissipation estimate at any bounded positive stopping time. Only
bounds on the stopped prefix are needed. -/
theorem stopped_generator_expectation
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {ℱ : Filtration ℝ≥0 ‹MeasurableSpace Ω›} {T : ℝ≥0}
    {τ : Ω → WithTop ℝ≥0} (hτ : IsStoppingTime ℱ τ)
    (hτpos : ∀ ω, 0 < τ ω) (hτT : ∀ ω, τ ω ≤ (T:WithTop ℝ≥0))
    {V J M : ℝ≥0 → Ω → ℝ} {V₀ κ C CV CJ : ℝ}
    (hV : StronglyAdapted ℱ V) (hVc : ∀ ω, Continuous (fun t => V t ω))
    (hJ : StronglyAdapted ℱ J) (hJc : ∀ ω, Continuous (fun t => J t ω))
    (hV₀ : ∀ ω, V 0 ω=V₀) (hCV : 0≤ CV) (hCJ : 0≤ CJ)
    (hVB : ∀ t∈Icc 0 T, ∀ ω, (t:WithTop ℝ≥0)≤τ ω → ‖V t ω‖≤ CV)
    (hJB : ∀ t∈Icc 0 T, ∀ ω, (t:WithTop ℝ≥0)≤τ ω → ‖J t ω‖≤ CJ)
    (hgen : ∀ t∈Icc 0 T, ∀ ω, (t:WithTop ℝ≥0)≤τ ω → J t ω≤ -2*κ*V t ω+C)
    (hM : IsLocalMartingale M ℱ μ)
    (hIto : ∀ᵐ ω ∂μ, ∀ t∈Icc 0 T, V t ω=V₀+driftPath J t ω+M t ω)
    (t : ℝ≥0) :
    (∫ ω, stoppedProcess V τ t ω ∂μ)+
        2*κ*(∫ ω, stoppedProcess (driftPath V) τ t ω ∂μ)≤
      V₀+C*(∫ ω, stoppedProcess (fun (s:ℝ≥0) (_:Ω) => (s:ℝ)) τ t ω ∂μ) := by
  let residual := fun s ω => V s ω-V₀-driftPath J s ω
  have hRa : StronglyAdapted ℱ residual := fun s =>
    ((hV s).sub stronglyMeasurable_const).sub (continuous_drift_adapted hJ hJc s)
  have hRc : ∀ ω, Continuous (fun s => residual s ω) := fun ω =>
    ((hVc ω).sub continuous_const).sub (continuous_drift_paths hJc ω)
  have htime (s : ℝ≥0) (ω : Ω) :
      (min (s:WithTop ℝ≥0) (τ ω)).untopA≤ T ∧
      (((min (s:WithTop ℝ≥0) (τ ω)).untopA:ℝ≥0):WithTop ℝ≥0)≤τ ω := by
    exact ⟨WithTop.untopA_le ((min_le_right _ _).trans (hτT ω)),
      by rw [coe_untopA_min]; exact min_le_right _ _⟩
  have hJint (u : ℝ≥0) (ω : Ω) (huT : u≤ T) (hu : (u:WithTop ℝ≥0)≤τ ω) :
      |driftPath J u ω|≤ CJ*T := by
    apply (drift_prefix_bound u ω (fun s hs => ?_)).trans
      (mul_le_mul_of_nonneg_left (by exact_mod_cast huT) hCJ)
    exact (Real.norm_eq_abs _).symm.trans_le
      (hJB s ⟨zero_le,hs.2.trans huT⟩ ω ((WithTop.coe_le_coe.mpr hs.2).trans hu))
  have hVstop : ∀ s ω, ‖stoppedProcess V τ s ω‖≤ CV := by
    intro s ω
    exact hVB _ ⟨zero_le,(htime s ω).1⟩ ω
      (htime s ω).2
  have hIstop : ∀ s ω, ‖stoppedProcess (driftPath V) τ s ω‖≤ CV*T := by
    intro s ω
    rw [Real.norm_eq_abs]
    apply (drift_prefix_bound _ ω (fun q hq => ?_)).trans
      (mul_le_mul_of_nonneg_left (by exact_mod_cast (htime s ω).1) hCV)
    exact (Real.norm_eq_abs _).symm.trans_le
      (hVB q ⟨zero_le,hq.2.trans (htime s ω).1⟩ ω
        ((WithTop.coe_le_coe.mpr hq.2).trans (htime s ω).2))
  have hSstop : ∀ s ω, ‖stoppedProcess (fun (q:ℝ≥0) (_:Ω) => (q:ℝ)) τ s ω‖≤(T:ℝ) := by
    intro s ω
    simpa only [stoppedProcess,Real.norm_eq_abs,abs_of_nonneg (NNReal.coe_nonneg _)] using
      (show ((min (s:WithTop ℝ≥0) (τ ω)).untopA:ℝ)≤ T by exact_mod_cast (htime s ω).1)
  have hRstop : ∀ s ω, ‖stoppedProcess residual τ s ω‖≤ CV+|V₀|+CJ*T := by
    intro s ω
    let u := (min (s:WithTop ℝ≥0) (τ ω)).untopA
    have hvi := hVstop s ω
    have hji := hJint u ω (htime s ω).1 (htime s ω).2
    change ‖V u ω-V₀-driftPath J u ω‖≤ CV+|V₀|+CJ*T
    have hn₁ := norm_sub_le (V u ω-V₀) (driftPath J u ω)
    have hn₂ := norm_sub_le (V u ω) V₀
    simp only [Real.norm_eq_abs] at hn₁ hn₂ hvi ⊢
    change |V u ω|≤ CV at hvi
    linarith
  have heq : ∀ᵐ ω ∂μ, ∀ s∈Icc 0 T, M s ω=residual s ω := by
    filter_upwards [hIto] with ω hω s hs
    dsimp [residual]
    linarith [hω s hs]
  have hmart := bounded_stopped_residual_martingale hM hRa hRc heq hτ hτpos hτT hRstop
  have hR₀ (ω : Ω) : residual 0 ω=0 := by simp [residual,driftPath,hV₀]
  have hineq : ∀ᵐ ω ∂μ, ∀ s,
      stoppedProcess V τ s ω+2*κ*stoppedProcess (driftPath V) τ s ω≤
        V₀+C*stoppedProcess (fun (q:ℝ≥0) (_:Ω) => (q:ℝ)) τ s ω+stoppedProcess residual τ s ω := by
    apply Eventually.of_forall
    intro ω s
    have hi := drift_dissipation_prefix hVc hJc _ ω (fun q hq =>
      hgen q ⟨zero_le,hq.2.trans (htime s ω).1⟩ ω ((WithTop.coe_le_coe.mpr hq.2).trans (htime s ω).2))
    dsimp only [stoppedProcess,residual]
    linarith
  exact stopped_dissipation_expectation hτ hτpos hV hVc
    (continuous_drift_adapted hV hVc) (continuous_drift_paths hVc)
    (fun _ => stronglyMeasurable_const) (fun _ => NNReal.continuous_coe)
    hVstop hIstop hSstop hmart hR₀ hineq t

end
end ChainFountainStochastic
