module

public import ChainFountainStochastic.LocalIntegralBridge

@[expose] public section
namespace ChainFountainStochastic.ConullBrownian
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralLocalised MathFin.LocalisationInMeasure
open MathFin.ItoIntegralRiemannBridge
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 800000
variable {Ω Ω' : Type*} {mΩ : MeasurableSpace Ω} {mΩ' : MeasurableSpace Ω'}
  {μ : Measure Ω} {ν : Measure Ω'}

/-- Extract an actual measurable conull subset of an almost-sure property.
No completeness of the ambient probability space is assumed. -/
theorem exists_measurable_conull {P : Ω → Prop} (hP : ∀ᵐ ω ∂μ, P ω) :
    ∃ G : Set Ω, MeasurableSet G ∧ (∀ᵐ ω ∂μ, ω ∈ G) ∧ ∀ ω ∈ G, P ω := by
  let N := toMeasurable μ {ω | ¬ P ω}
  have hN : μ N = 0 := by
    dsimp [N]
    rw [measure_toMeasurable]
    exact ae_iff.mp hP
  refine ⟨Nᶜ,(measurableSet_toMeasurable _ _).compl,?_,?_⟩
  · rw [ae_iff]
    change μ {a | ¬ a ∈ Nᶜ} = 0
    simpa only [mem_compl_iff,not_not,Set.setOf_mem_eq] using hN
  · intro ω hω
    by_contra hn
    exact hω (subset_toMeasurable μ {ω | ¬ P ω} hn)

/-- Restricting to a measurable conull subtype preserves the entire measure. -/
theorem conull_subtype_preserving {G : Set Ω} (hG : MeasurableSet G)
    (hGa : ∀ᵐ ω ∂μ, ω ∈ G) :
    MeasurePreserving ((↑) : G → Ω) (μ.comap ((↑) : G → Ω)) μ := by
  refine ⟨measurable_subtype_coe,?_⟩
  rw [map_comap_subtype_coe hG,Measure.restrict_eq_self_of_ae_mem hGa]

/-- Brownian finite-dimensional laws are preserved on a conull realization. -/
theorem preBrownian_pullback {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ)
    {f : Ω' → Ω} (hf : MeasurePreserving f ν μ) :
    IsPreBrownianReal (fun t ω => B t (f ω)) ν where
  hasLaw I := (hB.hasLaw I).comp hf.hasLaw

/-- Natural filtrations commute exactly with sample-space pullback. -/
theorem natFiltration_pullback {B : ℝ≥0 → Ω → ℝ} (hBm : ∀ t, Measurable (B t))
    {f : Ω' → Ω} (hf : Measurable f) (t : ℝ≥0) :
    natFiltration (fun s => (hBm s).comp hf) t = (natFiltration hBm t).comap f := by
  simp only [natFiltration,Filtration.natural,MeasurableSpace.comap_iSup,MeasurableSpace.comap_comp]

theorem adapted_pullback {E : Type*} [TopologicalSpace E]
    {B : ℝ≥0 → Ω → ℝ} (hBm : ∀ t, Measurable (B t)) {f : Ω' → Ω} (hf : Measurable f)
    {A : ℝ≥0 → Ω → E} (hA : StronglyAdapted (natFiltration hBm) A) :
    StronglyAdapted (natFiltration (fun s => (hBm s).comp hf)) (fun t ω => A t (f ω)) := by
  intro t
  have hfm : @Measurable Ω' Ω (natFiltration (fun s => (hBm s).comp hf) t) (natFiltration hBm t) f := by
    rw [measurable_iff_comap_le,natFiltration_pullback hBm hf t]
  exact (hA t).comp_measurable hfm

/-- Convergence in probability is unchanged by a measure-preserving embedding,
including restriction to a measurable conull subtype. -/
theorem tendstoInMeasure_pullback {f : Ω' → Ω} (hf : MeasurableEmbedding f)
    (hm : MeasurePreserving f ν μ) {E : Type*} [EDist E] {u : ℕ → Ω → E} {v : Ω → E}
    (hu : TendstoInMeasure μ u atTop v) :
    TendstoInMeasure ν (fun n ω => u n (f ω)) atTop (fun ω => v (f ω)) := by
  intro ε hε
  simpa only [←hm.map_eq,hf.map_apply,preimage_setOf_eq] using hu ε hε

/-- The localized predictable integral pulls back to the continuous-adapted
Itô integral once all paths of the integrand are continuous on the conull
realization. Equality holds simultaneously for all times on the horizon. -/
theorem predIto_pullback [IsProbabilityMeasure μ] [IsProbabilityMeasure ν]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {f : Ω' → Ω} (hf : MeasurableEmbedding f) (hm : MeasurePreserving f ν μ)
    {A : ℝ≥0 → Ω → ℝ} (hA : IsStronglyPredictable (natFiltration hBm) A)
    (hAc : ∀ᵐ ω ∂μ, ContinuousOn (fun t => A t ω) (Icc 0 T))
    (hAf : ∀ ω, Continuous (fun t => A t (f ω))) :
    ∀ᵐ ω ∂ν, ∀ t ∈ Icc 0 T,
      predItoIntegral (μ:=μ) T hBm hA t (f ω) =
        localItoIntegral (μ:=ν) T (fun s => (hBm s).comp hf.measurable)
          (adapted_pullback hBm hf.measurable hA.stronglyAdapted) hAf t ω := by
  have hB' := preBrownian_pullback hB hm
  have hBm' := fun s => (hBm s).comp hf.measurable
  have hBc' : ∀ ω, Continuous (fun t => B t (f ω)) := fun ω => hBc (f ω)
  have hA' := adapted_pullback hBm hf.measurable hA.stronglyAdapted
  apply ae_forall_eq_of_tendstoInMeasure
    (hm.quasiMeasurePreserving.tendsto_ae.eventually (ae_continuousOn_predItoIntegral hB T hBm hBc hA hAc))
    (ae_continuousOn_localItoIntegral hB' T hBm' hBc' hA' hAf)
    (fun t ht => tendstoInMeasure_pullback hf hm
      (tendstoInMeasure_riemannσ_predItoIntegral hB T hBm hBc hA hAc ht.2))
  intro t ht
  exact tendstoInMeasure_riemannσ_localItoIntegral hB' T hBm' hBc' hA' hAf ht.2

end
end ChainFountainStochastic.ConullBrownian
