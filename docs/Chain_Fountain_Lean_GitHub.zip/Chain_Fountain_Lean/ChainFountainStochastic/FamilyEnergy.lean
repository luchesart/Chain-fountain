module

public import ChainFountainStochastic.ConstructedStoppedEnergy
public import ChainFountainStochastic.MaximalUniqueness

@[expose] public section
namespace ChainFountainStochastic.CutoffExhaustion
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory MathFin ChainFountain
open MathFin.ItoIntegralL2 MathFin.ItoFormulaAdapted MathFin.AdaptedDrift
open VectorSDE GlobalCutoffSDE MechanicalCutoff ConullBrownian RegularRealization
open ConstructedEnergy GlobalLocalization MechanicalExhaustion
open scoped NNReal Topology
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1500000
variable {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
  {B : ℝ≥0 → Ω → ℝ}

/-- The energy estimate holds on the ORIGINAL probability space for every
member of the constructed compact exhaustion. Its continuous realization,
Itô decomposition and martingale expectation are all proved, not assumed. -/
theorem Family.stopped_energy_expectation
    {hBm : ∀ t, Measurable (B t)}
    (hB : IsPreBrownianReal B μ) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {a : Parameters} {r : ℝ → State} {x₀ : State}
    (F : Family (μ:=μ) hBm a (fun t => r t) x₀)
    (hp : Continuous (fun t : ℝ≥0 => r t))
    (dr : ∀ t, 0 ≤ t → HasDerivAt (fun s => r s 0) (r t 1) t)
    (dr₁ : ∀ t, 0 ≤ t → HasDerivAt (fun s => r s 1) (r t 2) t)
    {κ : ℝ} (hk₀ : 0 ≤ a.k₀) (hk₁ : 0 ≤ a.k₁) (hk₂ : 0 ≤ a.k₂) (hκd : 0 ≤ a.κd)
    (hκ₁ : κ ≤ a.k₁) (hκ₂ : κ ≤ a.k₂)
    (n : ℕ) (T : ℝ≥0) (hT : 0 < T) (t : ℝ≥0) :
    let V := fun (s : ℝ≥0) ω => energy a (r s) (F.X n s ω)
    let τ := fun ω => min (F.exit n ω) (T:WithTop ℝ≥0)
    (∫ ω, stoppedProcess V τ t ω ∂μ)+
      2*κ*(∫ ω, stoppedProcess (driftPath V) τ t ω ∂μ) ≤
      energy a (r 0) x₀+(a.noise^2*(((n:ℝ)+F.R)^3)^2/8)*
        (∫ ω, stoppedProcess (fun (s:ℝ≥0) (_:Ω) => (s:ℝ)) τ t ω ∂μ) := by
  obtain ⟨G,hG,hGa,hgood⟩ := exists_measurable_conull (by
    filter_upwards [finite_variation_equations hB hBc F,
      ae_all_iff.mpr (fun n => global_strong_solution_continuous hBm (F.c n) x₀ (F.strong n)),
      ae_all_iff.mpr F.version] with ω hfv hcont hver
    exact show ∀ n : ℕ, Continuous (fun t => F.Y n t ω) ∧
      (∀ t, F.Y n t ω 0 = x₀ 0+driftPath (fun s ω => (F.c n).drift s (F.Y n s ω) 0) t ω ∧
        F.Y n t ω 2 = x₀ 2+driftPath (fun s ω => (F.c n).drift s (F.Y n s ω) 2) t ω) ∧
      (∀ t, F.X n t ω = F.Y n t ω) from fun n => ⟨hcont n,hfv n,hver n⟩)
  let ν := μ.comap ((↑) : G → Ω)
  have hm : MeasurePreserving ((↑) : G → Ω) ν μ := conull_subtype_preserving hG hGa
  letI : IsProbabilityMeasure ν := hm.hasLaw.isProbabilityMeasure
  have hf : MeasurableEmbedding ((↑) : G → Ω) := MeasurableEmbedding.subtype_coe hG
  have hcont (ω : G) : Continuous (fun s => F.Y n s ω.val) := (hgood ω.val ω.property n).1
  have hfv (ω : G) (s : ℝ≥0) := (hgood ω.val ω.property n).2.1 s
  have hv (ω : G) (s : ℝ≥0) : F.Y n s ω.val = F.X n s ω.val :=
    ((hgood ω.val ω.property n).2.2 s).symm
  have hρ : 0 < (n:ℝ)+F.R := by have := F.radius_gt; positivity
  have hi := radius_initial_inside F.radius_gt F.initial_inside n
  have he := cutoff_energy_expectation hB T hT hBm hBc a r hp dr dr₁ (F.c n) x₀
    (F.strong n) (F.bound n) hf hm hcont hfv hρ hi (F.agrees n)
    hk₀ hk₁ hk₂ hκd hκ₁ hκ₂ t
  have hX : (fun s (ω : G) => F.Y n s ω.val) = (fun s (ω : G) => F.X n s ω.val) :=
    funext (fun s => funext (fun ω => hv ω s))
  dsimp only at he ⊢
  rw [hX] at he
  have hex (ω : G) : gaugeExit (fun s (ω : G) => F.X n s ω.val)
      (gauge ((n:ℝ)+F.R)) ω = F.exit n ω.val := rfl
  simp_rw [hex] at he
  simp only [stoppedProcess,driftPath] at he ⊢
  simp_rw [hv] at he
  let u := fun (ω : Ω) => (min (t:WithTop ℝ≥0) (min (F.exit n ω) (T:WithTop ℝ≥0))).untopA
  have h₁ := hm.integral_comp hf (fun ω => energy a (r (u ω)) (F.X n (u ω) ω))
  have h₂ := hm.integral_comp hf (fun ω => ∫ s in Ioc 0 (u ω), energy a (r s) (F.X n s ω) ∂timeMeasure)
  have h₃ := hm.integral_comp hf (fun ω => (u ω:ℝ))
  dsimp only [u] at h₁ h₂ h₃
  rw [h₁,h₂,h₃] at he
  exact he

/-- The same estimate applies to the maximal process stopped at each
constructed exhaustion exit. No extension beyond its random lifetime enters
the estimate. -/
theorem Family.maximal_stopped_energy_expectation
    {hBm : ∀ t, Measurable (B t)}
    (hB : IsPreBrownianReal B μ) (hBc : ∀ ω, Continuous (fun t => B t ω))
    {a : Parameters} {r : ℝ → State} {x₀ : State}
    (F : Family (μ:=μ) hBm a (fun t => r t) x₀)
    (hp : Continuous (fun t : ℝ≥0 => r t))
    (dr : ∀ t, 0 ≤ t → HasDerivAt (fun s => r s 0) (r t 1) t)
    (dr₁ : ∀ t, 0 ≤ t → HasDerivAt (fun s => r s 1) (r t 2) t)
    {κ : ℝ} (hk₀ : 0 ≤ a.k₀) (hk₁ : 0 ≤ a.k₁) (hk₂ : 0 ≤ a.k₂) (hκd : 0 ≤ a.κd)
    (hκ₁ : κ ≤ a.k₁) (hκ₂ : κ ≤ a.k₂)
    (n : ℕ) (T : ℝ≥0) (hT : 0 < T) (t : ℝ≥0) :
    let V := fun (s : ℝ≥0) ω => energy a (r s) (F.process s ω)
    let τ := fun ω => min (F.exit n ω) (T:WithTop ℝ≥0)
    (∫ ω, stoppedProcess V τ t ω ∂μ)+
      2*κ*(∫ ω, stoppedProcess (driftPath V) τ t ω ∂μ) ≤
      energy a (r 0) x₀+(a.noise^2*(((n:ℝ)+F.R)^3)^2/8)*
        (∫ ω, stoppedProcess (fun (s:ℝ≥0) (_:Ω) => (s:ℝ)) τ t ω ∂μ) := by
  have he := F.stopped_energy_expectation hB hBc hp dr dr₁ hk₀ hk₁ hk₂ hκd hκ₁ hκ₂ n T hT t
  let τ := fun ω => min (F.exit n ω) (T:WithTop ℝ≥0)
  have htime ω : (((min (t:WithTop ℝ≥0) (τ ω)).untopA:ℝ≥0):WithTop ℝ≥0) ≤ F.exit n ω := by
    rw [coe_untopA_min]
    exact (min_le_right _ _).trans (min_le_left _ _)
  have hV : (∫ ω, stoppedProcess (fun (s:ℝ≥0) ω => energy a (r s) (F.process s ω)) τ t ω ∂μ) =
      ∫ ω, stoppedProcess (fun (s:ℝ≥0) ω => energy a (r s) (F.X n s ω)) τ t ω ∂μ := by
    apply integral_congr_ae
    filter_upwards [F.process_eq_before_exit] with ω hω
    dsimp only [stoppedProcess]
    rw [(hω n _ (htime ω)).1]
  have hI : (∫ ω, stoppedProcess (driftPath (fun (s:ℝ≥0) ω => energy a (r s) (F.process s ω))) τ t ω ∂μ) =
      ∫ ω, stoppedProcess (driftPath (fun (s:ℝ≥0) ω => energy a (r s) (F.X n s ω))) τ t ω ∂μ := by
    apply integral_congr_ae
    filter_upwards [F.process_eq_before_exit] with ω hω
    dsimp only [stoppedProcess,driftPath]
    apply setIntegral_congr_fun measurableSet_Ioc
    intro s hs
    dsimp only
    rw [(hω n s ((WithTop.coe_le_coe.mpr hs.2).trans (htime ω))).1]
  dsimp only at he ⊢
  rw [hV,hI]
  exact he

/-- End-to-end construction from model data: a predictable maximal local
solution with positive stopping lifetime, explosion alternative, and the
stopped energy estimate for every compact-exhaustion level and horizon. -/
theorem exists_maximal_solution_with_stopped_energy
    (hB : IsPreBrownianReal B μ) (hBm : ∀ t, Measurable (B t))
    (hBc : ∀ ω, Continuous (fun t => B t ω))
    (a : Parameters) (r : ℝ → State)
    (hp : Continuous (fun t : ℝ≥0 => r t))
    (dr : ∀ t, 0 ≤ t → HasDerivAt (fun s => r s 0) (r t 1) t)
    (dr₁ : ∀ t, 0 ≤ t → HasDerivAt (fun s => r s 1) (r t 2) t)
    (plo phi : State) (hpmem : ∀ t : ℝ≥0, r t ∈ Icc plo phi)
    (x₀ : State) (hh : 0 < x₀ 0)
    {κ : ℝ} (hk₀ : 0 ≤ a.k₀) (hk₁ : 0 ≤ a.k₁) (hk₂ : 0 ≤ a.k₂) (hκd : 0 ≤ a.κd)
    (hκ₁ : κ ≤ a.k₁) (hκ₂ : κ ≤ a.k₂) :
    ∃ F : Family (μ:=μ) hBm a (fun t => r t) x₀,
      IsStronglyPredictable (natFiltration hBm) F.process ∧
      IsStoppingTime (MathFin.ItoIntegralProcessLocalMartingaleGeneral.augFiltration (μ:=μ) hBm) F.lifetime ∧
      (∀ ω, 0 < F.lifetime ω) ∧
      (∀ᵐ ω ∂μ, F.lifetime ω ≠ ⊤ → ∀ K : Set State, IsCompact K →
        (∀ x ∈ K, 0 < x 0) → ∀ t : ℝ≥0, (t:WithTop ℝ≥0) < F.lifetime ω →
        ∃ s : ℝ≥0, t ≤ s ∧ (s:WithTop ℝ≥0) < F.lifetime ω ∧ F.process s ω ∉ K) ∧
      ∀ (n : ℕ) (T : ℝ≥0), 0 < T → ∀ t : ℝ≥0,
        let V := fun (s : ℝ≥0) ω => energy a (r s) (F.process s ω)
        let τ := fun ω => min (F.exit n ω) (T:WithTop ℝ≥0)
        (∫ ω, stoppedProcess V τ t ω ∂μ)+
          2*κ*(∫ ω, stoppedProcess (driftPath V) τ t ω ∂μ) ≤
          energy a (r 0) x₀+(a.noise^2*(((n:ℝ)+F.R)^3)^2/8)*
            (∫ ω, stoppedProcess (fun (s:ℝ≥0) (_:Ω) => (s:ℝ)) τ t ω ∂μ) := by
  obtain ⟨F⟩ := exists_family hB hBm hBc a (fun t => r t) hp plo phi hpmem x₀ hh
  exact ⟨F,F.process_predictable,F.lifetime_stopping,F.lifetime_positive,F.explosion_alternative,
    fun n T hT t => F.maximal_stopped_energy_expectation hB hBc hp dr dr₁
      hk₀ hk₁ hk₂ hκd hκ₁ hκ₂ n T hT t⟩

end
end ChainFountainStochastic.CutoffExhaustion
