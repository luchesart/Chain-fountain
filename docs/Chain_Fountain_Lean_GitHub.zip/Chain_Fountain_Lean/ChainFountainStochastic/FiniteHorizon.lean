module

public import ChainFountainStochastic.FinitePicard

@[expose] public section

namespace ChainFountainStochastic.FiniteHorizon
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM MathFin.SDEExistence
open TimeProjection FinitePicard VectorSDE SDEContinuous
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1000000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- Construct a finite time partition whose individual Picard steps contract.
The full deterministic horizon is arbitrary. -/
theorem exists_contracting_partition (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ u, Measurable (B u)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) :
    ∃ (N : ℕ) (P : ℕ → ProcessLp (μ:=μ) (ι:=ι) T hBm →L[ℝ] ProcessLp (μ:=μ) (ι:=ι) T hBm)
      (q : ℝ≥0), q < 1 ∧
      (∀ X, P 0 X = 0) ∧ (∀ X, P N X = X) ∧
      (∀ m n, m ≤ n → ∀ X, P m (P n X) = P m X) ∧
      (∀ n, n ≤ N → ∀ X Y, P n X = P n Y →
        P n (picard hB T hBm hBc c x₀ X) = P n (picard hB T hBm hBc c x₀ Y)) ∧
      (∀ n, n < N → ∀ X Y, P n X = P n Y →
        ‖P (n+1) (picard hB T hBm hBc c x₀ X) - P (n+1) (picard hB T hBm hBc c x₀ Y)‖ ≤ q*‖X-Y‖) := by
  let K : ℝ := (Fintype.card ι:ℝ)*(Real.sqrt (T:ℝ)*c.Lb+c.Lσ)
  have hK : 0 ≤ K := by dsimp [K]; positivity
  obtain ⟨δ,hδ,hq⟩ := exists_positive_contraction_horizon (0:ℝ≥0) (⟨K,hK⟩:ℝ≥0)
  have hq' : Real.sqrt (δ:ℝ)*K < 1 := by
    change (δ:ℝ)*0 + Real.sqrt (δ:ℝ)*K < 1 at hq
    simpa only [mul_zero,zero_add] using hq
  have hq0 : 0 ≤ Real.sqrt (δ:ℝ)*K := mul_nonneg (Real.sqrt_nonneg _) hK
  let q := Real.toNNReal (Real.sqrt (δ:ℝ)*K)
  have hqcoe : (q:ℝ) = Real.sqrt (δ:ℝ)*K := Real.coe_toNNReal _ hq0
  obtain ⟨N,hN⟩ := exists_nat_ge ((T:ℝ)/(δ:ℝ))
  have hNδ : T ≤ (N:ℝ≥0)*δ := by
    exact_mod_cast (div_le_iff₀ (show (0:ℝ) < δ from hδ)).mp hN
  let τ : ℕ → ℝ≥0 := fun n => min T ((n:ℝ≥0)*δ)
  have hτ0 : τ 0 = 0 := by simp [τ]
  have hτN : τ N = T := min_eq_left hNδ
  have hτT (n : ℕ) : τ n ≤ T := min_le_left _ _
  have hmono {m n : ℕ} (h : m ≤ n) : τ m ≤ τ n :=
    min_le_min_left T (mul_le_mul_of_nonneg_right (Nat.cast_le.mpr h) (show (0:ℝ≥0) ≤ δ from zero_le))
  have hstep (n : ℕ) : (τ (n+1):ℝ)-(τ n:ℝ) ≤ (δ:ℝ) := by
    simp only [τ,NNReal.coe_min,NNReal.coe_mul,NNReal.coe_natCast,Nat.cast_add,Nat.cast_one,NNReal.coe_add,NNReal.coe_one]
    simp only [min_def]
    split_ifs <;> nlinarith [δ.coe_nonneg]
  let P := fun n => cut (E:=ι → ℝ) (μ:=μ) T (τ n) hBm
  refine ⟨N,P,q,?_,?_,?_,?_,?_,?_⟩
  · change (q:ℝ) < 1
    rw [hqcoe]
    exact hq'
  · intro X; dsimp [P]; rw [hτ0,cut_zero]
  · intro X; dsimp [P]; rw [hτN,cut_full]
  · intro m n h X; exact cut_absorb T (τ m) (τ n) hBm (hmono h) X
  · intro n _ X Y he
    exact picard_causal hB T (τ n) hBm hBc c x₀ (hτT n) X Y he
  · intro n _ X Y he
    have hb := picard_interval_norm_le hB T (τ n) (τ (n+1)) hBm hBc c x₀
      (hmono (Nat.le_succ _)) (hτT _) X Y he
    apply hb.trans
    apply mul_le_mul_of_nonneg_right _ (norm_nonneg _)
    rw [hqcoe]
    have hs := mul_le_mul_of_nonneg_right (Real.sqrt_le_sqrt (hstep n)) hK
    convert hs using 1 <;> dsimp [K] <;> ring

/-- Existence and uniqueness of the coupled predictable-L2 Picard fixed point
on every finite deterministic horizon. There is no full-horizon smallness assumption. -/
theorem picard_exists_unique_all_horizons (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ u, Measurable (B u)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) :
    ∃! X, picard hB T hBm hBc c x₀ X = X := by
  obtain ⟨N,P,q,hq,hzero,hfull,hab,hca,hco⟩ := exists_contracting_partition hB T hBm hBc c x₀
  obtain ⟨X,hX⟩ := CausalFixedPoint.exists_fixed_point N P _ hzero hfull hab hca q hq hco
  exact ⟨X,hX,fun Y hY => CausalFixedPoint.fixed_point_unique N P _ hzero hfull hab hca q hq hco hY hX⟩

/-- Actual continuous predictable strong solutions exist on every finite
horizon, with the coefficients evaluated along the constructed trajectory. -/
theorem exists_strong_solution_all_horizons (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ u, Measurable (B u)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ) :
    ∃ Y, StrongSolution (μ:=μ) T hBm c x₀ Y := by
  obtain ⟨X,hX,_⟩ := picard_exists_unique_all_horizons hB T hBm hBc c x₀
  obtain ⟨Y,hY,_⟩ := realize_fixed_point hB T hBm hBc c x₀ X hX
  exact ⟨Y,hY⟩

/-- All-times pathwise uniqueness in the predictable L2 class, on every finite horizon. -/
theorem strong_solution_unique_all_horizons (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ u, Measurable (B u)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ)
    {Y Z : ℝ≥0 → Ω → (ι → ℝ)} (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hZ : StrongSolution (μ:=μ) T hBm c x₀ Z) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ T → Y t ω = Z t ω := by
  obtain ⟨_,_,hu⟩ := picard_exists_unique_all_horizons hB T hBm hBc c x₀
  have he : hY.state_memLp.toLp (Function.uncurry Y) = hZ.state_memLp.toLp (Function.uncurry Z) :=
    (hu _ (hY.fixed_point hB T hBm hBc c x₀)).trans (hu _ (hZ.fixed_point hB T hBm hBc c x₀)).symm
  filter_upwards [hY.canonical_equation T hBm c x₀,hZ.canonical_equation T hBm c x₀] with ω hy hz
  intro t ht
  rw [hy t ht,hz t ht,he]

end
end ChainFountainStochastic.FiniteHorizon
