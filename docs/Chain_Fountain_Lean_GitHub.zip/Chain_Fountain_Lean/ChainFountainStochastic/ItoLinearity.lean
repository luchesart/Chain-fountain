module

public import ChainFountainStochastic.ItoExponential
public import ChainFountainStochastic.LocalIntegralBridge

@[expose] public section

namespace ChainFountainStochastic.ItoLinearity
noncomputable section
open MeasureTheory ProbabilityTheory Real Filter Set MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM MathFin.ItoIntegralPredictable
open MathFin.ItoIntegralLocalised MathFin.LocalisationInMeasure
open MathFin.ItoIntegralProcessContinuousModification MathFin.ItoIntegralProcessGeneral
open MathFin.ItoIntegralRiemannBridge MathFin.QuadraticVariationL2
open scoped NNReal ENNReal Topology
set_option maxHeartbeats 1000000
set_option backward.isDefEq.respectTransparency true
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
  (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
  (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (B · ω))
  {a : ℝ≥0 → Ω → ℝ}
  (ha : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
  (hc : ∀ ω, Continuous (a · ω))
  (hp : IsStronglyPredictable (natFiltration hBm) a)
  {C : ℝ} (hb : ∀ t ω, |a t ω| ≤ C)

include hBc in
/-- Agreement of the localized predictable integral with the genuine terminal
L2 integral at an intermediate time. -/
theorem pred_terminal {t : ℝ≥0} (ht : t ≤ T) :
    predItoIntegral (μ:=μ) T hBm hp t =ᵐ[μ] itoIntCont hB hBm ha hc hb t := by
  have he := LocalIntegralBridge.continuousMod_eq_predIto hB T hBm hBc hp
    (ae_of_all _ fun ω => (hc ω).continuousOn) hb _ (processToLp_coeFn T hBm ha hc hb)
  have h := itoContinuousMod_modification hB T hBm hBc (processToLp (μ:=μ) T hBm ha hc hb) ht
  rw [itoProcessCLM_consist hB hBm le_rfl ht ha hc hb,itoProcessCLM_terminal_eq] at h
  filter_upwards [he,h] with ω he h
  exact (he t ⟨bot_le,ht⟩).symm.trans h

include hB hBc in
/-- Constant integrands integrate to the corresponding multiple of Brownian motion. -/
theorem pred_const (q : ℝ) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      predItoIntegral (μ:=μ) T hBm
        (show IsStronglyPredictable (natFiltration hBm) (fun _ _ => q) from stronglyMeasurable_const)
        t ω = q*B t ω := by
  have hsum (t : ℝ≥0) {n : ℕ} (hn : n ≠ 0) (ω : Ω) :
      riemannσ (B:=B) (fun _ _ => q) t n ω = q*(B t ω-B 0 ω) := by
    simp only [riemannσ,← Finset.mul_sum]
    rw [Finset.sum_range_sub (fun k => B (unifPart t n k) ω),unifPart_self t hn,unifPart_zero]
  have hconv (t : ℝ≥0) : TendstoInMeasure μ
      (fun n ω => riemannσ (B:=B) (fun _ _ => q) t n ω) atTop (fun ω => q*(B t ω-B 0 ω)) :=
    tendstoInMeasure_of_tendsto_ae
      (fun n => (Finset.measurable_sum _ fun k _ =>
        measurable_const.mul ((hBm _).sub (hBm _))).aestronglyMeasurable)
      (ae_of_all _ fun ω => tendsto_const_nhds.congr'
        ((eventually_ne_atTop 0).mono fun n hn => (hsum t hn ω).symm))
  filter_upwards [ae_forall_eq_of_tendstoInMeasure (T:=T)
    (Y':=fun t ω => q*(B t ω-B 0 ω))
    (ae_continuousOn_predItoIntegral hB T hBm hBc (show IsStronglyPredictable (natFiltration hBm) (fun _ _ => q) from stronglyMeasurable_const)
      (ae_of_all _ fun _ => continuousOn_const))
    (ae_of_all _ fun ω => (((hBc ω).sub continuous_const).const_mul q).continuousOn)
    (fun t ht => tendstoInMeasure_riemannσ_predItoIntegral hB T hBm hBc
      (show IsStronglyPredictable (natFiltration hBm) (fun _ _ => q) from stronglyMeasurable_const) (ae_of_all _ fun _ => continuousOn_const) ht.2)
    (fun t _ => hconv t), MathFin.ItoIntegralBrownian.eval_zero_ae hB hBm] with ω he hz t ht
  rw [he t ht,hz,Pi.zero_apply,sub_zero]

include hb in
/-- Uniform bound for the centered coefficient. -/
theorem centered_bound (q : ℝ) : ∀ t ω, |a t ω-q| ≤ C+|q| :=
  fun t ω => (abs_sub (a t ω) q).trans (add_le_add (hb t ω) le_rfl)

/-- Centering a bounded coefficient commutes with the genuine terminal integral. -/
theorem terminal_sub_const (q : ℝ) :
    itoIntCont hB hBm (fun t => (ha t).sub stronglyMeasurable_const)
      (fun ω => (hc ω).sub continuous_const) (centered_bound hb q) T =ᵐ[μ]
      fun ω => itoIntCont hB hBm ha hc hb T ω -
        itoIntCont hB hBm (fun _ => stronglyMeasurable_const) (fun _ => continuous_const)
          (θ:=fun _ _ => q) (C:=|q|) (fun _ _ => le_rfl) T ω := by
  have he : processToLp (μ:=μ) T hBm (fun t => (ha t).sub stronglyMeasurable_const)
      (fun ω => (hc ω).sub continuous_const) (centered_bound hb q) =
      processToLp (μ:=μ) T hBm ha hc hb - processToLp (μ:=μ) T hBm
        (fun _ => stronglyMeasurable_const) (fun _ => continuous_const)
        (σ:=fun _ _ => q) (C:=|q|) (fun _ _ => le_rfl) := by
    apply Lp.ext
    filter_upwards [processToLp_coeFn (μ:=μ) T hBm
      (fun t => (ha t).sub stronglyMeasurable_const) (fun ω => (hc ω).sub continuous_const)
      (centered_bound hb q), Lp.coeFn_sub (processToLp (μ:=μ) T hBm ha hc hb)
        (processToLp (μ:=μ) T hBm (fun _ => stronglyMeasurable_const) (fun _ => continuous_const)
          (σ:=fun _ _ => q) (C:=|q|) (fun _ _ => le_rfl)),
      processToLp_coeFn (μ:=μ) T hBm ha hc hb,
      processToLp_coeFn (μ:=μ) T hBm (fun _ => stronglyMeasurable_const) (fun _ => continuous_const)
        (σ:=fun _ _ => q) (C:=|q|) (fun _ _ => le_rfl)] with z h1 h2 h3 h4
    simp only [Pi.sub_apply,h3,h4] at h2
    exact h1.trans h2.symm
  simp only [itoIntCont,he,map_sub]
  exact Lp.coeFn_sub _ _

include hB hBc ha hc hb in
/-- The actual centered predictable integral, simultaneously at every time. -/
theorem pred_sub_const (q : ℝ) :
    ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T,
      predItoIntegral (μ:=μ) T hBm (hp.sub (show IsStronglyPredictable (natFiltration hBm) (fun _ _ => q) from stronglyMeasurable_const)) t ω =
        predItoIntegral (μ:=μ) T hBm hp t ω-q*B t ω := by
  have hres := ae_continuousOn_predItoIntegral hB T hBm hBc (hp.sub (show IsStronglyPredictable (natFiltration hBm) (fun _ _ => q) from stronglyMeasurable_const))
    (ae_of_all _ fun ω => ((hc ω).sub continuous_const).continuousOn)
  have hcont := ae_continuousOn_predItoIntegral hB T hBm hBc hp
    (ae_of_all _ fun ω => (hc ω).continuousOn)
  apply ae_forall_eq_of_continuousOn hres
    (hcont.mono fun ω hω => hω.sub ((hBc ω).const_mul q).continuousOn)
  intro t ht
  filter_upwards [pred_terminal hB T hBm hBc ha hc hp hb ht.2,
    pred_terminal hB T hBm hBc (fun t => (ha t).sub stronglyMeasurable_const)
      (fun ω => (hc ω).sub continuous_const) (hp.sub (show IsStronglyPredictable (natFiltration hBm) (fun _ _ => q) from stronglyMeasurable_const)) (centered_bound hb q) ht.2,
    terminal_sub_const hB t hBm ha hc hb q,
    pred_terminal hB T hBm hBc (a:=fun _ _ => q)
      (fun _ => stronglyMeasurable_const) (fun _ => continuous_const) stronglyMeasurable_const
      (C:=|q|) (fun _ _ => le_rfl) ht.2,
    pred_const hB T hBm hBc q] with ω ha hr hs hc hq
  rw [hr,hs,← ha,← hc,hq t ht]
  rfl

end
end ChainFountainStochastic.ItoLinearity
