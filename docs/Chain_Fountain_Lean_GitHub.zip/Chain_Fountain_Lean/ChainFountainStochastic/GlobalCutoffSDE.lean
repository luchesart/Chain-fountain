module

public import ChainFountainStochastic.HorizonConsistency
public import ChainFountainStochastic.MechanicalFiniteHorizon
public import Mathlib.MeasureTheory.Constructions.Polish.StronglyMeasurable

@[expose] public section

namespace ChainFountainStochastic.GlobalCutoffSDE
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralCLM MathFin.ItoLocalMartingale
open VectorSDE FiniteHorizon HorizonConsistency ConstructedExit MechanicalCutoff
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 1000000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}
  [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- One predictable process solves the SDE on every finite interval. Unlike
separate finite-horizon existences, the witness is chosen before the horizon. -/
def GlobalStrongSolution (hBm : ∀ t, Measurable (B t)) (c : Coefficients ι)
    (x₀ : ι → ℝ) (Y : ℝ≥0 → Ω → (ι → ℝ)) : Prop :=
  ∀ T : ℝ≥0, StrongSolution (μ:=μ) T hBm c x₀ Y

/-- Glue the actual finite-horizon strong solutions into a single global
predictable process. Consistency and the measurable limit are both proved. -/
theorem exists_global_strong_solution
    (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound) :
    ∃ Y, GlobalStrongSolution (μ:=μ) hBm c x₀ Y := by
  have hex (n : ℕ) := exists_strong_solution_all_horizons hB (n:ℝ≥0) hBm hBc c x₀
  choose U hU using hex
  have hco (n m : ℕ) : ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, t ≤ min (n:ℝ≥0) (m:ℝ≥0) →
      U n t ω = U m t ω :=
    strong_solution_unique_all_horizons hB _ hBm hBc c x₀
      (strong_solution_restrict hB _ _ (min_le_left _ _) hBm hBc c x₀ hb (hU n))
      (strong_solution_restrict hB _ _ (min_le_right _ _) hBm hBc c x₀ hb (hU m))
  let Y : ℝ≥0 → Ω → (ι → ℝ) := fun t ω => limUnder atTop (fun n => U n t ω)
  have hp : IsStronglyPredictable (natFiltration hBm) Y :=
    by
      letI : MeasurableSpace (ℝ≥0 × Ω) := (natFiltration hBm).predictable
      exact StronglyMeasurable.limUnder (fun n => (hU n).predictable)
  have he : ∀ᵐ ω ∂μ, ∀ n : ℕ, ∀ t ∈ Icc 0 (n:ℝ≥0), Y t ω = U n t ω := by
    filter_upwards [ae_all_iff.mpr (fun n => ae_all_iff.mpr (hco n))] with ω hω
    intro n t ht
    apply Tendsto.limUnder_eq
    apply tendsto_const_nhds.congr'
    refine eventually_atTop.2 ⟨n,fun m hm => ?_⟩
    exact hω n m t (le_min ht.2 (ht.2.trans (Nat.cast_le.mpr hm)))
  have h₀ (ω : Ω) : Y 0 ω = x₀ := by
    apply Tendsto.limUnder_eq
    simpa only [(hU _).initial ω] using
      (tendsto_const_nhds : Tendsto (fun _ : ℕ => x₀) atTop (𝓝 x₀))
  refine ⟨Y,fun T => ?_⟩
  obtain ⟨N,hN⟩ := exists_nat_ge T
  exact strong_solution_congr T hBm c x₀
    (strong_solution_restrict hB T N hN hBm hBc c x₀ hb (hU N)) hp h₀
    (he.mono fun ω hω t ht => (hω N t ⟨ht.1,ht.2.trans hN⟩).symm)

/-- Global uniqueness holds on one event of probability one simultaneously
for all nonnegative times. -/
theorem global_strong_solution_unique
    (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c : Coefficients ι) (x₀ : ι → ℝ)
    {Y Z : ℝ≥0 → Ω → (ι → ℝ)}
    (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y)
    (hZ : GlobalStrongSolution (μ:=μ) hBm c x₀ Z) :
    ∀ᵐ ω ∂μ, ∀ t, Y t ω = Z t ω := by
  filter_upwards [ae_all_iff.mpr (fun n : ℕ =>
    strong_solution_unique_all_horizons hB n hBm hBc c x₀ (hY n) (hZ n))] with ω hω
  intro t
  obtain ⟨N,hN⟩ := exists_nat_ge t
  exact hω N t hN

/-- Global path continuity follows from the countable family of finite
interval statements; there is no uncountable intersection of conull events. -/
theorem global_strong_solution_continuous
    (hBm : ∀ t, Measurable (B t)) (c : Coefficients ι) (x₀ : ι → ℝ)
    {Y : ℝ≥0 → Ω → (ι → ℝ)} (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y) :
    ∀ᵐ ω ∂μ, Continuous (fun t => Y t ω) := by
  filter_upwards [ae_all_iff.mpr (fun n : ℕ => (hY n).continuous)] with ω hω
  rw [continuous_iff_continuousAt]
  intro t
  obtain ⟨N,hN⟩ := exists_nat_gt t
  apply (hω N t ⟨zero_le,hN.le⟩).continuousAt
  have he : Icc (0:ℝ≥0) (N:ℝ≥0) = Iic (N:ℝ≥0) := by ext s; simp
  rw [he]
  exact Iic_mem_nhds hN

/-- A global strong solution has an everywhere-continuous adapted version
under the null-augmented filtration, equal at every time almost surely. -/
theorem exists_global_continuous_adapted_version
    (hBm : ∀ t, Measurable (B t)) (c : Coefficients ι) (x₀ : ι → ℝ)
    {Y : ℝ≥0 → Ω → (ι → ℝ)} (hY : GlobalStrongSolution (μ:=μ) hBm c x₀ Y) :
    ∃ X : ℝ≥0 → Ω → (ι → ℝ),
      StronglyAdapted (MathFin.ItoIntegralProcessLocalMartingaleGeneral.augFiltration (μ:=μ) hBm) X ∧
      (∀ ω, Continuous (fun t => X t ω)) ∧ (∀ ω, X 0 ω = x₀) ∧
      (∀ᵐ ω ∂μ, ∀ t, X t ω = Y t ω) := by
  classical
  obtain ⟨G,hG,hGc,hGood⟩ := MathFin.ItoLocalMartingale.exists_nullsAlg_of_ae
    (global_strong_solution_continuous hBm c x₀ hY)
  let X : ℝ≥0 → Ω → (ι → ℝ) := fun t ω => if ω ∈ G then Y t ω else x₀
  let ℱ := natFiltration hBm
  refine ⟨X,?_,?_,?_,?_⟩
  · intro t
    letI : MeasurableSpace Ω := nullAugmentation ℱ μ t
    have hGt : MeasurableSet[nullAugmentation ℱ μ t] G :=
      (le_sup_right : nullsAlg mΩ μ ≤ ℱ t ⊔ nullsAlg mΩ μ) G hG
    have hYm : StronglyMeasurable[nullAugmentation ℱ μ t] (Y t) :=
      ((hY 0).predictable.stronglyAdapted t).mono le_sup_left
    exact StronglyMeasurable.ite hGt hYm stronglyMeasurable_const
  · intro ω
    by_cases hω : ω ∈ G
    · simpa only [X,if_pos hω] using hGood ω hω
    · simpa only [X,if_neg hω] using (continuous_const : Continuous (fun _ : ℝ≥0 => x₀))
  · intro ω
    simp [X,(hY 0).initial ω]
  · have hGae : ∀ᵐ ω ∂μ, ω ∈ G := by rw [ae_iff]; exact hGc
    filter_upwards [hGae] with ω hω
    exact fun t => if_pos hω

/-- Every actual mechanical cutoff has one globally defined strong solution,
pathwise unique among processes solving its equation on every finite interval. -/
theorem exists_unique_global_mechanical_cutoff
    (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (a : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi lo hi : State) (hlo : lo ≤ hi) (hh : 0 < lo 0)
    (hpmem : ∀ t, p t ∈ Icc plo phi) (x₀ : State) :
    ∃ c : Coefficients (Fin 3),
      (∀ t x, x ∈ Icc lo hi → c.drift t x = a.drift (p t,x) ∧
        c.diffusion t x = a.diffusion (p t,x)) ∧
      ∃ Y, GlobalStrongSolution (μ:=μ) hBm c x₀ Y ∧
        (∀ Z, GlobalStrongSolution (μ:=μ) hBm c x₀ Z → ∀ᵐ ω ∂μ, ∀ t, Y t ω = Z t ω) ∧
        ∃ X, StronglyAdapted (MathFin.ItoIntegralProcessLocalMartingaleGeneral.augFiltration (μ:=μ) hBm) X ∧
          (∀ ω, Continuous (fun t => X t ω)) ∧ (∀ ω, X 0 ω = x₀) ∧
          (∀ᵐ ω ∂μ, ∀ t, X t ω = Y t ω) := by
  obtain ⟨c,_,_,hb,hσ,hbound⟩ := a.exists_cutoff p hp plo phi lo hi hlo hh hpmem
  obtain ⟨Y,hY⟩ := exists_global_strong_solution hB hBm hBc c x₀ (fun t x => (hbound t x).2)
  refine ⟨c,(fun t x hx => ⟨hb t x hx,hσ t x hx⟩),Y,hY,
    fun Z hZ => global_strong_solution_unique hB hBm hBc c x₀ hY hZ,?_⟩
  exact exists_global_continuous_adapted_version hBm c x₀ hY

end
end ChainFountainStochastic.GlobalCutoffSDE
