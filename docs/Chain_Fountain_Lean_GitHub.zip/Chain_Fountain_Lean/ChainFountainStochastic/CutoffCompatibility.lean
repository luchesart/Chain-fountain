module

public import ChainFountainStochastic.ConstructedExit
public import ChainFountainStochastic.StoppedUniqueness

@[expose] public section

namespace ChainFountainStochastic.CutoffCompatibility
noncomputable section
open MeasureTheory ProbabilityTheory Filter Set Topology MathFin
open MathFin.ItoIntegralL2 MathFin.ItoIntegralProcessLocalMartingaleGeneral
open VectorSDE MechanicalCutoff ConstructedExit StoppedUniqueness
open scoped NNReal ENNReal
set_option backward.isDefEq.respectTransparency true
set_option maxHeartbeats 900000
variable {Ω : Type*} {mΩ : MeasurableSpace Ω} {μ : Measure Ω}

/-- Two globally Lipschitz coefficient fields admit a common positive
contraction horizon. The time is constructed from their continuity at zero. -/
theorem exists_common_contraction_horizon
    {ι : Type*} [Fintype ι] (c d : Coefficients ι) :
    ∃ T : ℝ≥0, 0 < T ∧ contractionFactor c T < 1 ∧ contractionFactor d T < 1 := by
  have hcont (a : Coefficients ι) : Continuous (contractionFactor a) := by
    change Continuous (fun T : ℝ≥0 => (Fintype.card ι : ℝ) *
      ((T:ℝ)*a.Lb + Real.sqrt (T:ℝ)*a.Lσ))
    fun_prop
  have hnear (a : Coefficients ι) : ∀ᶠ t : ℝ≥0 in 𝓝 0, contractionFactor a t < 1 :=
    (hcont a).tendsto 0 |>.eventually (by
      simpa [contractionFactor] using (gt_mem_nhds (by norm_num : (0:ℝ) < 1)))
  obtain ⟨ε,hε,he⟩ := Metric.eventually_nhds_iff.mp ((hnear c).and (hnear d))
  let T : ℝ≥0 := ⟨ε/2,(half_pos hε).le⟩
  have hT : 0 < T := half_pos hε
  have hd : dist T 0 < ε := by
    rw [NNReal.dist_eq,NNReal.coe_zero,sub_zero,abs_of_nonneg T.coe_nonneg]
    change ε/2 < ε
    linarith
  exact ⟨T,hT,(he hd).1,(he hd).2⟩

/-- Equality before the smaller of two genuine exits forces the exits to
coincide. This uses first hitting, rather than only a stopping-time label. -/
theorem normExit_eq_of_prefix_eq
    {E : Type*} [NormedAddCommGroup E]
    {X Z : ℝ≥0 → Ω → E} {x₀ : E} {R : ℝ} {T : ℝ≥0}
    (hX : ∀ ω, Continuous (fun t => X t ω))
    (hZ : ∀ ω, Continuous (fun t => Z t ω)) (hR : 0 < R)
    (ω : Ω)
    (he : ∀ t ∈ Icc 0 T,
      (t:WithTop ℝ≥0) ≤ min (normExit X x₀ R T ω) (normExit Z x₀ R T ω) → X t ω = Z t ω) :
    normExit X x₀ R T ω = normExit Z x₀ R T ω := by
  have hn (A C : ℝ≥0 → Ω → E)
      (hA : ∀ ω, Continuous (fun t => A t ω))
      (hC : ∀ ω, Continuous (fun t => C t ω))
      (heq : ∀ t ∈ Icc 0 T,
        (t:WithTop ℝ≥0) ≤ min (normExit A x₀ R T ω) (normExit C x₀ R T ω) → A t ω = C t ω) :
      ¬ normExit A x₀ R T ω < normExit C x₀ R T ω := by
    intro hlt
    have hcap : normExit C x₀ R T ω ≤ T := min_le_right _ _
    have hAt : normExit A x₀ R T ω < T := hlt.trans_le hcap
    have hfinite : normExit A x₀ R T ω ≠ ⊤ := ne_of_lt (hAt.trans (WithTop.coe_lt_top T))
    let u := (normExit A x₀ R T ω).untopA
    have hu : (u:WithTop ℝ≥0) = normExit A x₀ R T ω := by
      dsimp [u]
      rw [WithTop.untopA_eq_untop hfinite]
      exact WithTop.coe_untop _ _
    have huT : u < T := WithTop.coe_lt_coe.mp (hu.symm ▸ hAt)
    have hle : normExit A x₀ R T ω ≤ (u:WithTop ℝ≥0) := hu.ge
    obtain ⟨s,hs,hb⟩ := (normExit_le_iff hA hR huT ω).mp hle
    have hsA : (s:WithTop ℝ≥0) ≤ normExit A x₀ R T ω := hu ▸ WithTop.coe_le_coe.mpr hs.2
    have heq' := heq s ⟨hs.1,hs.2.trans huT.le⟩ (le_min hsA (hsA.trans hlt.le))
    have hCle : normExit C x₀ R T ω ≤ (u:WithTop ℝ≥0) :=
      (normExit_le_iff hC hR huT ω).mpr ⟨s,hs,by rwa [←heq']⟩
    exact not_le.mpr hlt (hu ▸ hCle)
  exact le_antisymm (not_lt.mp (hn Z X hZ hX (fun t ht hs =>
    (he t ht (by simpa only [min_comm] using hs)).symm))) (not_lt.mp (hn X Z hX hZ he))

/-- Before the norm-ball exit of a continuous version, two bounded-diffusion
strong solutions agree whenever their fields agree on that ball. -/
theorem strong_solutions_agree_before_normExit
    [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c d : Coefficients (Fin 3)) (x₀ : State) (hc : contractionFactor c T < 1)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖d.diffusion t x‖ ≤ d.bound)
    {Y Z XZ : ℝ≥0 → Ω → State}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hZ : StrongSolution (μ:=μ) T hBm d x₀ Z)
    {R : ℝ}
    (hstop : ∀ t ω, stoppedProcess XZ (normExit XZ x₀ R T) t ω ∈ Metric.closedBall x₀ R)
    (hXZ : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, XZ t ω = Z t ω)
    (hcoeff : ∀ t x, x ∈ Metric.closedBall x₀ R →
      c.drift t x = d.drift t x ∧ c.diffusion t x = d.diffusion t x) :
    ∀ᵐ ω ∂μ, ∀ t : ℝ≥0, (t:WithTop ℝ≥0) ≤ normExit XZ x₀ R T ω → Y t ω = Z t ω := by
  have hcap (ω : Ω) : normExit XZ x₀ R T ω ≤ T := min_le_right _ _
  have hfin (ω : Ω) : normExit XZ x₀ R T ω ≠ ⊤ :=
    ne_of_lt ((hcap ω).trans_lt (WithTop.coe_lt_top T))
  let τ := fun ω => (normExit XZ x₀ R T ω).untopA
  have hτ (ω : Ω) : (τ ω:WithTop ℝ≥0) = normExit XZ x₀ R T ω := by
    dsimp [τ]
    rw [WithTop.untopA_eq_untop (hfin ω)]
    exact WithTop.coe_untop _ _
  have hm := original_state_mem_before_exit hcap hstop hXZ
  have he := strong_solution_prefix_unique hB T hBm hBc c d x₀ hc hb hd hY hZ τ
    (by
      filter_upwards [hm] with ω hω
      intro t ht hle
      exact hcoeff t (Z t ω) (hω t (hτ ω ▸ WithTop.coe_le_coe.mpr hle)))
  filter_upwards [he] with ω hω
  intro t ht
  exact hω t ⟨zero_le,WithTop.coe_le_coe.mp (ht.trans (hcap ω))⟩
    (WithTop.coe_le_coe.mp ((hτ ω).symm ▸ ht))

/-- Local cutoff compatibility includes equality of the actual random exits
and indistinguishability of the stopped continuous versions. -/
theorem continuous_versions_stopped_eq
    [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
    (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hT : 0 < T)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (c d : Coefficients (Fin 3)) (x₀ : State) (hc : contractionFactor c T < 1)
    (hb : ∀ t x, ‖c.diffusion t x‖ ≤ c.bound)
    (hd : ∀ t x, ‖d.diffusion t x‖ ≤ d.bound)
    {Y Z XY XZ : ℝ≥0 → Ω → State}
    (hY : StrongSolution (μ:=μ) T hBm c x₀ Y)
    (hZ : StrongSolution (μ:=μ) T hBm d x₀ Z)
    (hXYa : StronglyAdapted (augFiltration (μ:=μ) hBm) XY)
    (hXZa : StronglyAdapted (augFiltration (μ:=μ) hBm) XZ)
    (hXYc : ∀ ω, Continuous (fun t => XY t ω))
    (hXZc : ∀ ω, Continuous (fun t => XZ t ω))
    (hXY₀ : ∀ ω, XY 0 ω = x₀) (hXZ₀ : ∀ ω, XZ 0 ω = x₀)
    (hXY : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, XY t ω = Y t ω)
    (hXZ : ∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, XZ t ω = Z t ω)
    (R : ℝ) (hR : 0 < R)
    (hcoeff : ∀ t x, x ∈ Metric.closedBall x₀ R →
      c.drift t x = d.drift t x ∧ c.diffusion t x = d.diffusion t x) :
    ∀ᵐ ω ∂μ, normExit XY x₀ R T ω = normExit XZ x₀ R T ω ∧
      ∀ t, stoppedProcess XY (normExit XY x₀ R T) t ω =
        stoppedProcess XZ (normExit XZ x₀ R T) t ω := by
  obtain ⟨_,_,hcapZ,hstopZ⟩ := normExit_properties hXZa hXZc hXZ₀ hR hT
  have he := strong_solutions_agree_before_normExit hB T hBm hBc c d x₀ hc hb hd
    hY hZ hstopZ hXZ hcoeff
  filter_upwards [he,hXY,hXZ] with ω he hXY hXZ
  have heXZ (t : ℝ≥0) (ht : (t:WithTop ℝ≥0) ≤ normExit XZ x₀ R T ω) : XY t ω = XZ t ω := by
    have htT : t ∈ Icc 0 T := ⟨zero_le,WithTop.coe_le_coe.mp (ht.trans (hcapZ ω))⟩
    exact (hXY t htT).trans ((he t ht).trans (hXZ t htT).symm)
  have hτ := normExit_eq_of_prefix_eq hXYc hXZc hR ω
    (fun t _ ht => heXZ t (ht.trans (min_le_right _ _)))
  refine ⟨hτ,?_⟩
  intro t
  change XY (min (t:WithTop ℝ≥0) (normExit XY x₀ R T ω)).untopA ω =
    XZ (min (t:WithTop ℝ≥0) (normExit XZ x₀ R T ω)).untopA ω
  rw [hτ]
  apply heXZ
  rw [coe_untopA_min]
  exact min_le_right _ _

/-- Two actual mechanical cutoff constructions on different positive-height
boxes give the same stopped trajectory in every common ball, on a constructed
common positive horizon. All solutions and stopping times are conclusions. -/
theorem exists_compatible_mechanical_cutoff_solutions
    [IsProbabilityMeasure μ] {B : ℝ≥0 → Ω → ℝ}
    (hB : IsPreBrownianReal B μ)
    (hBm : ∀ t, Measurable (B t)) (hBc : ∀ ω, Continuous (fun t => B t ω))
    (a : Parameters) (p : ℝ≥0 → State) (hp : Continuous p)
    (plo phi lo₁ hi₁ lo₂ hi₂ : State)
    (hlo₁ : lo₁ ≤ hi₁) (hh₁ : 0 < lo₁ 0)
    (hlo₂ : lo₂ ≤ hi₂) (hh₂ : 0 < lo₂ 0)
    (hpmem : ∀ t, p t ∈ Icc plo phi) (x₀ : State)
    (R : ℝ) (hR : 0 < R)
    (hball₁ : Metric.closedBall x₀ R ⊆ Icc lo₁ hi₁)
    (hball₂ : Metric.closedBall x₀ R ⊆ Icc lo₂ hi₂) :
    ∃ c d : Coefficients (Fin 3),
      (∀ t x, x ∈ Icc lo₁ hi₁ → c.drift t x = a.drift (p t,x) ∧
        c.diffusion t x = a.diffusion (p t,x)) ∧
      (∀ t x, x ∈ Icc lo₂ hi₂ → d.drift t x = a.drift (p t,x) ∧
        d.diffusion t x = a.diffusion (p t,x)) ∧
      ∃ T : ℝ≥0, 0 < T ∧ ∃ Y Z XY XZ : ℝ≥0 → Ω → State,
        StrongSolution (μ:=μ) T hBm c x₀ Y ∧
        StrongSolution (μ:=μ) T hBm d x₀ Z ∧
        StronglyAdapted (augFiltration (μ:=μ) hBm) XY ∧
        StronglyAdapted (augFiltration (μ:=μ) hBm) XZ ∧
        (∀ ω, Continuous (fun t => XY t ω)) ∧
        (∀ ω, Continuous (fun t => XZ t ω)) ∧
        (∀ ω, XY 0 ω = x₀ ∧ XZ 0 ω = x₀) ∧
        (∀ᵐ ω ∂μ, ∀ t ∈ Icc 0 T, XY t ω = Y t ω ∧ XZ t ω = Z t ω) ∧
        IsStoppingTime (augFiltration (μ:=μ) hBm) (normExit XY x₀ R T) ∧
        IsStoppingTime (augFiltration (μ:=μ) hBm) (normExit XZ x₀ R T) ∧
        (∀ ω, ⊥ < normExit XY x₀ R T ω ∧ ⊥ < normExit XZ x₀ R T ω) ∧
        (∀ᵐ ω ∂μ, normExit XY x₀ R T ω = normExit XZ x₀ R T ω ∧
          ∀ t, stoppedProcess XY (normExit XY x₀ R T) t ω =
            stoppedProcess XZ (normExit XZ x₀ R T) t ω) := by
  obtain ⟨c,_,_,hcb,hcσ,hcbd⟩ := a.exists_cutoff p hp plo phi lo₁ hi₁ hlo₁ hh₁ hpmem
  obtain ⟨d,_,_,hdb,hdσ,hdbd⟩ := a.exists_cutoff p hp plo phi lo₂ hi₂ hlo₂ hh₂ hpmem
  obtain ⟨T,hT,hc,hd⟩ := exists_common_contraction_horizon c d
  obtain ⟨Y,hY⟩ := exists_strong_solution hB T hBm hBc c x₀ hc
  obtain ⟨Z,hZ⟩ := exists_strong_solution hB T hBm hBc d x₀ hd
  obtain ⟨XY,hXYa,hXYc,hXY₀,hXY⟩ := exists_continuous_adapted_version
    hY.predictable.stronglyAdapted hY.continuous hY.initial
  obtain ⟨XZ,hXZa,hXZc,hXZ₀,hXZ⟩ := exists_continuous_adapted_version
    hZ.predictable.stronglyAdapted hZ.continuous hZ.initial
  obtain ⟨hτY,hposY,_,_⟩ := normExit_properties hXYa hXYc hXY₀ hR hT
  obtain ⟨hτZ,hposZ,_,_⟩ := normExit_properties hXZa hXZc hXZ₀ hR hT
  refine ⟨c,d,(fun t x hx => ⟨hcb t x hx,hcσ t x hx⟩),
    (fun t x hx => ⟨hdb t x hx,hdσ t x hx⟩),T,hT,Y,Z,XY,XZ,hY,hZ,
    hXYa,hXZa,hXYc,hXZc,(fun ω => ⟨hXY₀ ω,hXZ₀ ω⟩),?_,hτY,hτZ,
    (fun ω => ⟨hposY ω,hposZ ω⟩),?_⟩
  · filter_upwards [hXY,hXZ] with ω hy hz
    exact fun t ht => ⟨hy t ht,hz t ht⟩
  · apply continuous_versions_stopped_eq hB T hT hBm hBc c d x₀ hc
      (fun t x => (hcbd t x).2) (fun t x => (hdbd t x).2)
      hY hZ hXYa hXZa hXYc hXZc hXY₀ hXZ₀ hXY hXZ R hR
    intro t x hx
    exact ⟨(hcb t x (hball₁ hx)).trans (hdb t x (hball₂ hx)).symm,
      (hcσ t x (hball₁ hx)).trans (hdσ t x (hball₂ hx)).symm⟩

end
end ChainFountainStochastic.CutoffCompatibility
