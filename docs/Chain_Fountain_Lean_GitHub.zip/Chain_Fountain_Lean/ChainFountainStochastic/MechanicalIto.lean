module

public import ChainFountainStochastic.EnergyIto
public import ChainFountainStochastic.StoppedGenerator
public import ChainFountain.Tracking

@[expose] public section
namespace ChainFountainStochastic
noncomputable section
open Set Filter MeasureTheory ProbabilityTheory MathFin ChainFountain
open MathFin.ItoIntegralL2 MathFin.ItoFormulaAdapted MathFin.AdaptedDrift
open MathFin.ItoIntegralProcessLocalMartingaleGeneral
open scoped NNReal Topology

/-- Addition of a genuinely differentiable finite-variation coordinate to an
Itô process. The stochastic integral is unchanged; its new drift is derived by
ordinary FTC and linearity of the time integral. -/
theorem ito_add_finite_variation
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {B : ℝ≥0 → Ω → ℝ} (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    {a b : ℝ≥0 → Ω → ℝ}
    (ham : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hac : ∀ ω, Continuous (fun t => a t ω))
    (hbc : ∀ ω, Continuous (fun t => b t ω))
    {c c' : ℝ → Ω → ℝ} {v : ℝ≥0 → Ω → ℝ} {v₀ c₀ : ℝ}
    (hc₀ : ∀ ω, c 0 ω=c₀)
    (hcd : ∀ ω, ∀ t∈Icc (0:ℝ) T, HasDerivAt (fun s => c s ω) (c' t ω) t)
    (hcc : ∀ ω, ContinuousOn (fun t => c' t ω) (Icc (0:ℝ) T))
    (hSDE : ∀ᵐ ω ∂μ, ∀ t∈Icc 0 T,
      v t ω=localItoProcess (μ:=μ) T hBm ham hac v₀ b t ω) :
    ∀ᵐ ω ∂μ, ∀ t∈Icc 0 T,
      v t ω+c t ω=localItoProcess (μ:=μ) T hBm ham hac (v₀+c₀)
        (fun s ω => b s ω+c' s ω) t ω := by
  filter_upwards [hSDE] with ω hω t ht
  have hsub : Icc (0:ℝ) t ⊆ Icc (0:ℝ) T :=
    Icc_subset_Icc le_rfl (by exact_mod_cast ht.2)
  have hci : IntervalIntegrable (fun s => c' s ω) volume 0 t :=
    ((hcc ω).mono hsub).intervalIntegrable_of_Icc t.coe_nonneg
  have hFTC := intervalIntegral.integral_eq_sub_of_hasDerivAt
    (fun s hs => hcd ω s (hsub (by simpa [uIcc_of_le t.coe_nonneg] using hs))) hci
  have hi : (∫ s in Ioc (0:ℝ≥0) t, c' s ω ∂timeMeasure)=c t ω-c₀ := by
    rw [timeMeasure_Ioc_eq_interval]
    have heq : (∫ s in (0:ℝ)..(t:ℝ), c' (Real.toNNReal s) ω)=
        ∫ s in (0:ℝ)..(t:ℝ), c' s ω := by
      apply intervalIntegral.integral_congr
      intro s hs
      rw [uIcc_of_le t.coe_nonneg] at hs
      simp only [Real.coe_toNNReal s hs.1]
    rw [heq,hFTC,hc₀]
  have hib : IntegrableOn (fun s => b s ω) (Ioc 0 t) timeMeasure :=
    ((hbc ω).continuousOn.integrableOn_compact isCompact_Icc).mono_set Ioc_subset_Icc_self
  have hic : IntegrableOn (fun s : ℝ≥0 => c' s ω) (Ioc 0 t) timeMeasure := by
    have hcNN : ContinuousOn (fun s : ℝ≥0 => c' s ω) (Icc 0 t) :=
      ((hcc ω).mono hsub).comp NNReal.continuous_coe.continuousOn
        (fun s hs => ⟨s.coe_nonneg,by exact_mod_cast hs.2⟩)
    exact (hcNN.integrableOn_compact isCompact_Icc).mono_set Ioc_subset_Icc_self
  rw [hω t ht]
  simp only [localItoProcess,driftPath]
  rw [integral_add hib hic,hi]
  ring

/-- The mechanical feedback cancels the drift after the actual coordinate
change. The noise coefficient is unchanged because only v is diffusive. -/
theorem mechanical_error_drift (H g α β k₀ k₁ k₂ κd h v w r r₁ r₂ : ℝ)
    (hh : h≠0) (hH : H+h≠0) :
    rise g α h v w
      (robustInput H g α β h v w (acceleration k₀ k₁ k₂ (h-r) (heightRate v w) r₁ r₂)
        κd (v-w-2*r₁+2*k₁*(h-r))) -
      fall H g β h v w-2*r₂+2*k₁*(heightRate v w-r₁) =
    -2*k₀*(h-r)-k₂*(v-w-2*r₁+2*k₁*(h-r))-
      κd*(v^2/h)^2*(v-w-2*r₁+2*k₁*(h-r)) := by
  have ha := robust_acceleration H g α β h v w
    (acceleration k₀ k₁ k₂ (h-r) (heightRate v w) r₁ r₂)
    κd (v-w-2*r₁+2*k₁*(h-r)) 0 hh hH
  have hz := transformed_z_rate k₀ k₁ k₂ (h-r) (heightRate v w) r₁ r₂ κd (v^2/h) 0
    (v-w-2*r₁+2*k₁*(h-r)) (by unfold heightRate; ring)
  simp only [add_zero,mul_zero,zRate] at ha hz
  linarith


def mechanicalCorrection {Ω : Type*} (k₁ : ℝ) (h w : ℝ → Ω → ℝ)
    (r r₁ : ℝ → ℝ) (t : ℝ) (ω : Ω) := -w t ω-2*r₁ t+2*k₁*(h t ω-r t)

def mechanicalCorrectionRate {Ω : Type*} (H g β k₁ : ℝ) (h w : ℝ → Ω → ℝ)
    (v : ℝ≥0 → Ω → ℝ) (r₁ r₂ : ℝ → ℝ) (t : ℝ) (ω : Ω) :=
  -fall H g β (h t ω) (v (Real.toNNReal t) ω) (w t ω)-2*r₂ t+
    2*k₁*(heightRate (v (Real.toNNReal t) ω) (w t ω)-r₁ t)

def mechanicalZ {Ω : Type*} (k₁ : ℝ) (h w : ℝ → Ω → ℝ)
    (v : ℝ≥0 → Ω → ℝ) (r r₁ : ℝ → ℝ) (t : ℝ≥0) (ω : Ω) :=
  v t ω+mechanicalCorrection k₁ h w r r₁ t ω

/-- Actual mechanical SDE to error SDE. The v-equation is a Brownian stochastic
integral equation, while h and w satisfy the mechanical finite-variation ODEs.
Neither the transformed SDE nor its drift cancellation is assumed. -/
theorem mechanical_sde_error_coordinates
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {B : ℝ≥0 → Ω → ℝ} (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    {a b v : ℝ≥0 → Ω → ℝ} {h w : ℝ → Ω → ℝ} {r r₁ r₂ : ℝ → ℝ}
    {H g α β k₀ k₁ k₂ κd v₀ c₀ : ℝ}
    (ham : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hac : ∀ ω, Continuous (fun t => a t ω))
    (hbc : ∀ ω, Continuous (fun t => b t ω))
    (hc₀ : ∀ ω, mechanicalCorrection k₁ h w r r₁ 0 ω=c₀)
    (dh : ∀ ω t, 0≤ t → HasDerivAt (fun s => h s ω)
      (heightRate (v (Real.toNNReal t) ω) (w t ω)) t)
    (dw : ∀ ω t, 0≤ t → HasDerivAt (fun s => w s ω)
      (fall H g β (h t ω) (v (Real.toNNReal t) ω) (w t ω)) t)
    (dr : ∀ t, 0≤ t → HasDerivAt r (r₁ t) t)
    (dr₁ : ∀ t, 0≤ t → HasDerivAt r₁ (r₂ t) t)
    (hcc : ∀ ω, ContinuousOn (fun t => mechanicalCorrectionRate H g β k₁ h w v r₁ r₂ t ω)
      (Icc (0:ℝ) T))
    (hh : ∀ t∈Icc 0 T, ∀ ω, h t ω≠0)
    (hH : ∀ t∈Icc 0 T, ∀ ω, H+h t ω≠0)
    (hb : ∀ t∈Icc 0 T, ∀ ω, b t ω=rise g α (h t ω) (v t ω) (w t ω)
      (robustInput H g α β (h t ω) (v t ω) (w t ω)
        (acceleration k₀ k₁ k₂ (h t ω-r t) (heightRate (v t ω) (w t ω)) (r₁ t) (r₂ t))
        κd (mechanicalZ k₁ h w v r r₁ t ω)))
    (hv : ∀ᵐ ω ∂μ, ∀ t∈Icc 0 T,
      v t ω=localItoProcess (μ:=μ) T hBm ham hac v₀ b t ω) :
    (∀ ω t, 0≤ t → HasDerivAt (fun s => h s ω-r s)
      (-k₁*(h t ω-r t)+mechanicalZ k₁ h w v r r₁ (Real.toNNReal t) ω/2) t) ∧
    (∀ᵐ ω ∂μ, ∀ t∈Icc 0 T,
      mechanicalZ k₁ h w v r r₁ t ω=
        localItoProcess (μ:=μ) T hBm ham hac (v₀+c₀)
          (fun s ω => b s ω+mechanicalCorrectionRate H g β k₁ h w v r₁ r₂ s ω) t ω) ∧
    (∀ t∈Icc 0 T, ∀ ω,
      b t ω+mechanicalCorrectionRate H g β k₁ h w v r₁ r₂ t ω=
        -2*k₀*(h t ω-r t)-k₂*mechanicalZ k₁ h w v r r₁ t ω-
          κd*((v t ω)^2/h t ω)^2*mechanicalZ k₁ h w v r r₁ t ω) := by
  have hcd (ω : Ω) (t : ℝ) (ht : 0≤ t) :
      HasDerivAt (fun s => mechanicalCorrection k₁ h w r r₁ s ω)
        (mechanicalCorrectionRate H g β k₁ h w v r₁ r₂ t ω) t := by
    exact (((dw ω t ht).neg.sub ((dr₁ t ht).const_mul 2)).add
      (((dh ω t ht).sub (dr t ht)).const_mul (2*k₁)))
  refine ⟨?_,ito_add_finite_variation T hBm ham hac hbc hc₀
    (fun ω t ht => hcd ω t ht.1) hcc hv,?_⟩
  · intro ω t ht
    convert! (dh ω t ht).sub (dr t ht) using 1
    simp only [mechanicalZ,mechanicalCorrection,Real.coe_toNNReal t ht,heightRate]
    ring
  · intro t ht ω
    rw [hb t ht ω]
    dsimp only [mechanicalCorrectionRate,mechanicalZ,mechanicalCorrection]
    simp only [Real.toNNReal_coe]
    have hid := mechanical_error_drift H g α β k₀ k₁ k₂ κd (h t ω) (v t ω) (w t ω)
      (r t) (r₁ t) (r₂ t) (hh t ht ω) (hH t ht ω)
    convert! hid using 1 <;> ring_nf

/-- Energy Itô decomposition starting from the original mechanical SDE.
The coordinate transformation and the Itô formula are both derived. -/
theorem mechanical_tracking_energy_ito
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    {a b v : ℝ≥0 → Ω → ℝ} {h w : ℝ → Ω → ℝ} {r r₁ r₂ : ℝ → ℝ}
    {H g α β k₀ k₁ k₂ κd σ v₀ c₀ : ℝ}
    (ham : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hac : ∀ ω, Continuous (fun t => a t ω))
    (hbc : ∀ ω, Continuous (fun t => b t ω))
    (hc₀ : ∀ ω, mechanicalCorrection k₁ h w r r₁ 0 ω=c₀)
    (dh : ∀ ω t, 0≤ t → HasDerivAt (fun s => h s ω)
      (heightRate (v (Real.toNNReal t) ω) (w t ω)) t)
    (dw : ∀ ω t, 0≤ t → HasDerivAt (fun s => w s ω)
      (fall H g β (h t ω) (v (Real.toNNReal t) ω) (w t ω)) t)
    (dr : ∀ t, 0≤ t → HasDerivAt r (r₁ t) t)
    (dr₁ : ∀ t, 0≤ t → HasDerivAt r₁ (r₂ t) t)
    (hcc : ∀ ω, ContinuousOn (fun t => mechanicalCorrectionRate H g β k₁ h w v r₁ r₂ t ω)
      (Icc (0:ℝ) T))
    (hh : ∀ t∈Icc 0 T, ∀ ω, h t ω≠0)
    (hH : ∀ t∈Icc 0 T, ∀ ω, H+h t ω≠0)
    (hb : ∀ t∈Icc 0 T, ∀ ω, b t ω=rise g α (h t ω) (v t ω) (w t ω)
      (robustInput H g α β (h t ω) (v t ω) (w t ω)
        (acceleration k₀ k₁ k₂ (h t ω-r t) (heightRate (v t ω) (w t ω)) (r₁ t) (r₂ t))
        κd (mechanicalZ k₁ h w v r r₁ t ω)))
    (hv : ∀ᵐ ω ∂μ, ∀ t∈Icc 0 T,
      v t ω=localItoProcess (μ:=μ) T hBm ham hac v₀ b t ω)
    (hBc : ∀ ω, Continuous (fun t => B t ω))
    (hbnewm : ∀ t, StronglyMeasurable[natFiltration hBm t]
      (fun ω => b t ω+mechanicalCorrectionRate H g β k₁ h w v r₁ r₂ t ω))
    (hbnewc : ∀ ω, Continuous
      (fun t : ℝ≥0 => b t ω+mechanicalCorrectionRate H g β k₁ h w v r₁ r₂ t ω))
    (hzc : ∀ ω, Continuous (fun t => mechanicalZ k₁ h w v r r₁ t ω))
    (ha : ∀ t∈Icc 0 T, ∀ ω, a t ω=σ*((v t ω)^2/h t ω)) :
    ∃ M : ℝ≥0 → Ω → ℝ,
      (∀ᵐ ω ∂μ, ∀ t∈Icc 0 T,
        trackingEnergy k₀ (h t ω-r t) (mechanicalZ k₁ h w v r r₁ t ω)=
          trackingEnergy k₀ (h 0 ω-r 0) (v₀+c₀)+
            (∫ s in Ioc 0 t,
              trackingGenerator k₀ k₁ k₂ κd σ (h s ω-r s)
                (mechanicalZ k₁ h w v r r₁ s ω) ((v s ω)^2/h s ω) ∂timeMeasure)+M t ω) ∧
      (∀ ω, Continuous (fun t => M t ω)) ∧
      IsLocalMartingale M (augFiltration (μ:=μ) hBm) μ := by
  obtain ⟨he,hz,hdrift⟩ := mechanical_sde_error_coordinates T hBm ham hac hbc hc₀
    dh dw dr dr₁ hcc hh hH hb hv
  exact tracking_energy_ito (e:=fun t ω => h t ω-r t)
    (z:=mechanicalZ k₁ h w v r r₁) (G:=fun t ω => (v t ω)^2/h t ω)
    (k₀:=k₀) (k₁:=k₁) (k₂:=k₂) (κd:=κd) (σ:=σ) (z₀:=v₀+c₀)
    hB T hBm hBc ham hac hbnewm hbnewc hzc he
    (fun t ht ω => ⟨ha t ht ω,hdrift t ht ω⟩) hz

/-- The localized generator inequality, derived from the mechanical gains. -/
theorem tracking_generator_le {k₀ k₁ k₂ κd σ κ e z G CG : ℝ}
    (hk₀ : 0≤ k₀) (hκ₁ : κ≤ k₁) (hκ₂ : κ≤ k₂) (hκd : 0≤κd)
    (hG : |G|≤ CG) :
    trackingGenerator k₀ k₁ k₂ κd σ e z G≤ -2*κ*trackingEnergy k₀ e z+σ^2*CG^2/8 := by
  have hsq : G^2≤ CG^2 := by nlinarith [sq_nonneg (CG-|G|),sq_abs G,abs_nonneg G]
  have hn := ChainFountain.nominal_decay (e:=e) (z:=z) hk₀ hκ₁ hκ₂
  have hnoise := mul_le_mul_of_nonneg_left hsq (sq_nonneg σ)
  have hd : 0≤κd*G^2*z^2 := by positivity
  dsimp [trackingGenerator,trackingEnergy,ChainFountain.errorEnergy] at *
  nlinarith

/-- An explicit absolute generator bound follows from energy and diffusion
bounds on the localization region; it need not be added as an assumption. -/
theorem tracking_generator_abs_le {k₀ k₁ k₂ κd σ e z G CV CG : ℝ}
    (hk₀ : 0≤ k₀) (hk₁ : 0≤ k₁) (hk₂ : 0≤ k₂) (hκd : 0≤κd)
    (hV : trackingEnergy k₀ e z≤ CV) (hG : |G|≤ CG) :
    |trackingGenerator k₀ k₁ k₂ κd σ e z G|≤
      2*(k₁+k₂+κd*CG^2)*CV+σ^2*CG^2/8 := by
  have hsq : G^2≤ CG^2 := by nlinarith [sq_nonneg (CG-|G|),sq_abs G,abs_nonneg G]
  have he : k₀*e^2≤2*CV := by dsimp [trackingEnergy] at hV; nlinarith [sq_nonneg z]
  have hz : z^2≤8*CV := by dsimp [trackingEnergy] at hV; nlinarith [mul_nonneg hk₀ (sq_nonneg e)]
  have h₁ := mul_le_mul_of_nonneg_left he hk₁
  have h₂ := mul_le_mul_of_nonneg_left hz hk₂
  have h₃a := mul_le_mul_of_nonneg_left hsq (sq_nonneg z)
  have h₃b := mul_le_mul_of_nonneg_left hz (sq_nonneg CG)
  have h₃ := mul_le_mul_of_nonneg_left (show G^2*z^2≤ CG^2*(8*CV) by nlinarith) hκd
  have hσ := mul_le_mul_of_nonneg_left hsq (sq_nonneg σ)
  have hcv : 0≤ CV := (by dsimp [trackingEnergy]; positivity : 0≤ trackingEnergy k₀ e z).trans hV
  have hpos : 0≤2*(k₁+k₂+κd*CG^2)*CV := by positivity
  have hD : 0≤ k₀*k₁*e^2+k₂*z^2/4+κd*G^2*z^2/4 := by positivity
  rw [abs_le]
  dsimp [trackingGenerator]
  constructor <;> nlinarith [sq_nonneg σ,mul_nonneg (sq_nonneg σ) (sq_nonneg G),
    mul_nonneg (sq_nonneg σ) (sq_nonneg CG)]

/-- The stopped energy estimate from the original mechanical Brownian SDE,
with the actual first physical exit, explicit generator bounds, and derived
martingale/integrability obligations. -/
theorem mechanical_stopped_energy_estimate
    {Ω : Type*} [MeasurableSpace Ω] {μ : Measure Ω} [IsProbabilityMeasure μ]
    {B : ℝ≥0 → Ω → ℝ} (hB : IsPreBrownianReal B μ) (T : ℝ≥0) (hBm : ∀ t, Measurable (B t))
    {a b v : ℝ≥0 → Ω → ℝ} {h w : ℝ → Ω → ℝ} {r r₁ r₂ : ℝ → ℝ}
    {H g α β k₀ k₁ k₂ κd σ v₀ c₀ : ℝ}
    (ham : ∀ t, StronglyMeasurable[natFiltration hBm t] (a t))
    (hac : ∀ ω, Continuous (fun t => a t ω))
    (hbc : ∀ ω, Continuous (fun t => b t ω))
    (hc₀ : ∀ ω, mechanicalCorrection k₁ h w r r₁ 0 ω=c₀)
    (dh : ∀ ω t, 0≤ t → HasDerivAt (fun s => h s ω)
      (heightRate (v (Real.toNNReal t) ω) (w t ω)) t)
    (dw : ∀ ω t, 0≤ t → HasDerivAt (fun s => w s ω)
      (fall H g β (h t ω) (v (Real.toNNReal t) ω) (w t ω)) t)
    (dr : ∀ t, 0≤ t → HasDerivAt r (r₁ t) t)
    (dr₁ : ∀ t, 0≤ t → HasDerivAt r₁ (r₂ t) t)
    (hcc : ∀ ω, ContinuousOn (fun t => mechanicalCorrectionRate H g β k₁ h w v r₁ r₂ t ω)
      (Icc (0:ℝ) T))
    (hh : ∀ t∈Icc 0 T, ∀ ω, h t ω≠0)
    (hH : ∀ t∈Icc 0 T, ∀ ω, H+h t ω≠0)
    (hb : ∀ t∈Icc 0 T, ∀ ω, b t ω=rise g α (h t ω) (v t ω) (w t ω)
      (robustInput H g α β (h t ω) (v t ω) (w t ω)
        (acceleration k₀ k₁ k₂ (h t ω-r t) (heightRate (v t ω) (w t ω)) (r₁ t) (r₂ t))
        κd (mechanicalZ k₁ h w v r r₁ t ω)))
    (hv : ∀ᵐ ω ∂μ, ∀ t∈Icc 0 T,
      v t ω=localItoProcess (μ:=μ) T hBm ham hac v₀ b t ω)
    (hBc : ∀ ω, Continuous (fun t => B t ω))
    (hbnewm : ∀ t, StronglyMeasurable[natFiltration hBm t]
      (fun ω => b t ω+mechanicalCorrectionRate H g β k₁ h w v r₁ r₂ t ω))
    (hbnewc : ∀ ω, Continuous
      (fun t : ℝ≥0 => b t ω+mechanicalCorrectionRate H g β k₁ h w v r₁ r₂ t ω))
    (hzc : ∀ ω, Continuous (fun t => mechanicalZ k₁ h w v r r₁ t ω))
    (ha : ∀ t∈Icc 0 T, ∀ ω, a t ω=σ*((v t ω)^2/h t ω))
    {h₀ w₀ R κ CV CG : ℝ} (hT : 0<T) (hR : 0<R)
    (hk₀ : 0≤ k₀) (hκ : 0≤κ) (hκ₁ : κ≤ k₁) (hκ₂ : κ≤ k₂) (hκd : 0≤κd)
    (hCV : 0≤ CV)
    (hState : StronglyAdapted (augFiltration (μ:=μ) hBm)
      (fun t ω => (h t ω,v t ω,w t ω)))
    (hStateC : ∀ ω, Continuous (fun t : ℝ≥0 => (h t ω,v t ω,w t ω)))
    (hState₀ : ∀ ω, (h 0 ω,v 0 ω,w 0 ω)=(h₀,v₀,w₀))
    (hGc : ∀ ω, Continuous (fun t : ℝ≥0 => (v t ω)^2/h t ω))
    (hVcap : ∀ t∈Icc 0 T, ∀ ω,
      (h t ω,v t ω,w t ω)∈Metric.closedBall (h₀,v₀,w₀) R →
        trackingEnergy k₀ (h t ω-r t) (mechanicalZ k₁ h w v r r₁ t ω)≤ CV)
    (hGcap : ∀ t∈Icc 0 T, ∀ ω,
      (h t ω,v t ω,w t ω)∈Metric.closedBall (h₀,v₀,w₀) R → |(v t ω)^2/h t ω|≤ CG)
    (t : ℝ≥0) :
    let X := fun (s:ℝ≥0) ω => (h s ω,v s ω,w s ω)
    let V := fun (s:ℝ≥0) ω => trackingEnergy k₀ (h s ω-r s) (mechanicalZ k₁ h w v r r₁ s ω)
    let τ := physicalExit X (h₀,v₀,w₀) R T
    (∫ ω, stoppedProcess V τ t ω ∂μ)+2*κ*(∫ ω, stoppedProcess (driftPath V) τ t ω ∂μ)≤
      trackingEnergy k₀ (h₀-r 0) (v₀+c₀)+σ^2*CG^2/8*
        (∫ ω, stoppedProcess (fun (s:ℝ≥0) (_:Ω) => (s:ℝ)) τ t ω ∂μ) := by
  let X := fun (s:ℝ≥0) ω => (h s ω,v s ω,w s ω)
  let E := fun (s:ℝ≥0) ω => h s ω-r s
  let Z := mechanicalZ k₁ h w v r r₁
  let G := fun (s:ℝ≥0) ω => (v s ω)^2/h s ω
  let V := fun (s:ℝ≥0) ω => trackingEnergy k₀ (E s ω) (Z s ω)
  let J := fun (s:ℝ≥0) ω => trackingGenerator k₀ k₁ k₂ κd σ (E s ω) (Z s ω) (G s ω)
  let ℱ := augFiltration (μ:=μ) hBm
  have hk₁ : 0≤ k₁ := hκ.trans hκ₁
  have hk₂ : 0≤ k₂ := hκ.trans hκ₂
  have hEm (s : ℝ≥0) : StronglyMeasurable[ℱ s] (E s) :=
    (hState s).fst.sub stronglyMeasurable_const
  have hZm (s : ℝ≥0) : StronglyMeasurable[ℱ s] (Z s) :=
    (hState s).snd.fst.add (((hState s).snd.snd.neg.sub stronglyMeasurable_const).add
      ((hEm s).const_mul (2*k₁)))
  have hGm (s : ℝ≥0) : StronglyMeasurable[ℱ s] (G s) :=
    ((hState s).snd.fst.pow 2).div (hState s).fst
  have hVm : StronglyAdapted ℱ V := fun s =>
    (((hEm s).pow 2).const_mul k₀ |>.div stronglyMeasurable_const).add
      (((hZm s).pow 2).div stronglyMeasurable_const)
  have hJm : StronglyAdapted ℱ J := fun s =>
    ((((hEm s).pow 2).const_mul (-k₀*k₁)).sub
      (((hZm s).pow 2).const_mul k₂ |>.div stronglyMeasurable_const) |>.sub
      ((((hGm s).pow 2).const_mul κd |>.mul ((hZm s).pow 2)).div stronglyMeasurable_const )).add (((hGm s).pow 2).const_mul (σ^2) |>.div stronglyMeasurable_const)
  have hrC : Continuous (fun s : ℝ≥0 => r s) :=
    (show ContinuousOn r (Ici 0) from fun s hs => (dr s hs).continuousAt.continuousWithinAt).comp_continuous NNReal.continuous_coe (fun s => s.coe_nonneg)
  have hEc (ω : Ω) : Continuous (fun s => E s ω) := (hStateC ω).fst.sub hrC
  have hVc : ∀ ω, Continuous (fun s => V s ω) := fun ω =>
    (((hEc ω).pow 2).const_mul k₀ |>.div_const 2).add (((hzc ω).pow 2).div_const 8)
  have hJc : ∀ ω, Continuous (fun s => J s ω) := fun ω =>
    ((((hEc ω).pow 2).const_mul (-k₀*k₁)).sub
      (((hzc ω).pow 2).const_mul k₂ |>.div_const 4) |>.sub
      ((((hGc ω).pow 2).const_mul κd |>.mul ((hzc ω).pow 2)).div_const 4 )).add (((hGc ω).pow 2).const_mul (σ^2) |>.div_const 8)
  have hh₀ (ω : Ω) : h 0 ω=h₀ := congrArg Prod.fst (hState₀ ω)
  have hv₀ (ω : Ω) : v 0 ω=v₀ := congrArg (fun x : ℝ×(ℝ×ℝ) => x.2.1) (hState₀ ω)
  have hV₀ (ω : Ω) : V 0 ω=trackingEnergy k₀ (h₀-r 0) (v₀+c₀) := by
    change trackingEnergy k₀ (h 0 ω-r 0) (v 0 ω+mechanicalCorrection k₁ h w r r₁ 0 ω)=_
    rw [hh₀,hv₀,hc₀]
  let CJ := 2*(k₁+k₂+κd*CG^2)*CV+σ^2*CG^2/8
  have hCJ : 0≤ CJ := by dsimp [CJ]; positivity
  have hVB (s : ℝ≥0) (hs : s∈Icc 0 T) (ω : Ω)
      (hmem : X s ω∈Metric.closedBall (h₀,v₀,w₀) R) : ‖V s ω‖≤ CV := by
    have hvpos : 0≤ V s ω := by dsimp [V,trackingEnergy]; positivity
    simpa only [Real.norm_eq_abs,abs_of_nonneg hvpos] using hVcap s hs ω hmem
  have hJB (s : ℝ≥0) (hs : s∈Icc 0 T) (ω : Ω)
      (hmem : X s ω∈Metric.closedBall (h₀,v₀,w₀) R) : ‖J s ω‖≤ CJ := by
    exact (Real.norm_eq_abs _).trans_le
      (tracking_generator_abs_le hk₀ hk₁ hk₂ hκd (hVcap s hs ω hmem) (hGcap s hs ω hmem))
  have hgen (s : ℝ≥0) (hs : s∈Icc 0 T) (ω : Ω)
      (hmem : X s ω∈Metric.closedBall (h₀,v₀,w₀) R) :
      J s ω≤ -2*κ*V s ω+σ^2*CG^2/8 :=
    tracking_generator_le hk₀ hκ₁ hκ₂ hκd (hGcap s hs ω hmem)
  obtain ⟨M,hIto,hMc,hMl⟩ := mechanical_tracking_energy_ito hB T hBm ham hac hbc hc₀
    dh dw dr dr₁ hcc hh hH hb hv hBc hbnewm hbnewc hzc ha
  have hIto' : ∀ᵐ ω ∂μ, ∀ s∈Icc 0 T,
      V s ω=trackingEnergy k₀ (h₀-r 0) (v₀+c₀)+driftPath J s ω+M s ω := by
    filter_upwards [hIto] with ω hω s hs
    simpa only [hh₀ ω] using! hω s hs
  exact physical_stopped_generator_expectation hState hStateC hState₀ hR hT
    hVm hVc hJm hJc hV₀ hCV hCJ hVB hJB hgen hMl hIto' t

end
end ChainFountainStochastic
