#!/usr/bin/env python3
"""Build only imported uncached external modules, sequentially.
Run `lake exe cache get` first. Uses the dependency versions in lake-manifest.json.
"""
from pathlib import Path
import re, subprocess, os, json, sys
root=Path(__file__).resolve().parents[1]
roots=[root,*[p for p in (root/'.lake/packages').iterdir() if p.is_dir()]]
seen=set();order=[]
def visit(name):
    if name in seen:return
    seen.add(name)
    rel=Path(name.replace('.','/'))
    for package in roots:
        source=package/rel.with_suffix('.lean')
        if not source.exists():continue
        own=package==root
        output=package/'.lake/build/lib/lean'/rel.with_suffix('.olean')
        if not own and output.exists():return
        for dep in re.findall(r'^(?:public )?(?:meta )?import\s+([\w.]+)',source.read_text(encoding='utf-8'),re.M):visit(dep)
        if not own:order.append((name,package,source,output))
        return
    if name.startswith(('MathFin.','BrownianMotion.','Mathlib.')):
        raise RuntimeError('Missing pinned dependency: '+name)
visit('ChainFountainCompletion')
env = os.environ.copy()
if order:
    env.update(json.loads(subprocess.check_output(['lake','env',sys.executable,'-c',
        'import os,json; print(json.dumps({k:v for k,v in os.environ.items() if k in ("PATH","LEAN_PATH","LEAN_SRC_PATH","LD_LIBRARY_PATH")}))'],cwd=root,text=True,encoding='utf-8')))
for i,(name,package,source,output) in enumerate(order):
    print(f'{i+1}/{len(order)} {name}',flush=True)
    output.parent.mkdir(parents=True,exist_ok=True)
    subprocess.run(['lean','-j4','-R',str(package),str(source),'-o',str(output),'-i',str(output.with_suffix('.ilean'))],cwd=root,env=env,check=True)
print('Required external dependency modules are available. Continue with the source checks in verify.py.')
