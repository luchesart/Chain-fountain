#!/usr/bin/env python3
"""Guarded insertion-only Lean module-header migration; dry-run unless --apply.

Only the two authored module directories and four current root entrypoints are
eligible. Historical/browser sources and verification exporters are untouched.
Original bytes, insertion positions and hashes are retained for exact reversal.
This verifies textual preservation, not Lean kernel acceptance of the migration.
"""
import argparse
import hashlib
import importlib.util
import json
import re
from datetime import datetime, timezone
from pathlib import Path

ENTRYPOINTS = ('ChainFountain.lean', 'ChainFountainStochastic.lean',
               'ChainFountainZeroGravity.lean', 'ChainFountainCompletion.lean')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((json.dumps(value, indent=2, ensure_ascii=False)+'\n').encode('utf-8'))

def transform(source, mask_comments):
    plain = mask_comments(source)
    if re.match(r'\s*module\b', plain):
        return source, [], True
    imports = list(re.finditer(r'(?m)^[ \t]*(?P<token>import)[ \t]+[^\n]*', plain))
    if not imports:
        raise ValueError('Legacy source has no import header')
    prefix = plain[:imports[-1].end()]
    if re.sub(r'(?m)^[ \t]*import[ \t]+[^\n]*', '', prefix).strip():
        raise ValueError('Unexpected code before final import')
    if '\r' in source:
        raise ValueError('Refusing mixed/CRLF source: exact LF-only baseline expected')
    end = source.find('\n', imports[-1].end())
    end = len(source) if end == -1 else end + 1
    additions = [(0, 'module\n\n')]
    additions += [(m.start('token'), 'public ') for m in imports]
    additions += [(end, '\n@[expose] public section\n')]
    additions.sort(key=lambda p: p[0])
    chunks, last, inserted = [], 0, []
    for pos, value in additions:
        chunks.extend((source[last:pos], value))
        inserted.append({'original_character_position': pos, 'text': value})
        last = pos
    chunks.append(source[last:])
    converted = ''.join(chunks)
    # Reverse the recorded insertions, proving every original character remains.
    restored = converted
    offset = 0
    spans = []
    for pos, value in additions:
        spans.append((pos + offset, value))
        offset += len(value)
    for pos, value in reversed(spans):
        assert restored[pos:pos+len(value)] == value
        restored = restored[:pos] + restored[pos+len(value):]
    assert restored.encode('utf-8') == source.encode('utf-8')
    # All declarations are after the import block; the complete tail is unchanged.
    assert converted[end + offset:] == source[end:]
    return converted, inserted, False

def mathematical_text(source, mask_comments):
    lines = mask_comments(source).splitlines()
    lines = [line for line in lines if line.strip() and not re.fullmatch(
        r'\s*(?:module|(?:public\s+)?import\s+.*|@\[expose\]\s+public\s+section)\s*', line)]
    return '\n'.join(lines)

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root', required=True, type=Path)
    ap.add_argument('--baseline-root', required=True, type=Path)
    ap.add_argument('--apply', action='store_true')
    args = ap.parse_args()
    root = args.root.resolve()
    spec = importlib.util.spec_from_file_location('source_inventory', root/'verification/source_inventory.py')
    inventory = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(inventory)
    paths = sorted((root/'ChainFountain').glob('*.lean')) + sorted((root/'ChainFountainStochastic').glob('*.lean'))
    assert len(paths) == 116, f'Expected 116 authored modules, found {len(paths)}'
    paths += [root/name for name in ENTRYPOINTS]
    assert len(paths) == 120
    untouched_paths = set((root/'verification').rglob('*.lean')) | set((root/'browser-companion').rglob('*.lean'))
    untouched_paths |= set(root.glob('*.lean')) - set(paths)
    untouched = {p: p.read_bytes() for p in untouched_paths}
    plans, names_before, names_after = [], [], []
    for path in paths:
        original = path.read_bytes()
        source = original.decode('utf-8')
        converted, additions, modern = transform(source, inventory.mask_comments)
        output = converted.encode('utf-8')
        before = [(d['name'], d['kind']) for d in inventory.declarations(source)]
        after = [(d['name'], d['kind']) for d in inventory.declarations(converted)]
        assert before == after, f'Declaration inventory changed: {path}'
        names_before.extend(before); names_after.extend(after)
        plans.append((path, original, output, {
            'path': path.relative_to(root).as_posix(), 'already_modern': modern,
            'before_sha256': sha(original), 'after_sha256': sha(output),
            'all_original_bytes_preserved': True, 'declaration_inventory_unchanged': True,
            'insertions': additions}))
    assert names_before == names_after
    theorem_count = sum(kind == 'theorem' for _, kind in names_before)
    assert theorem_count == 722, f'Expected 722 theorems, found {theorem_count}'
    baseline_path = root/'verification/completion/baseline-preservation.json'
    previous_baseline = baseline_path.read_bytes()
    baseline = json.loads(previous_baseline.decode('utf-8'))
    assert len(baseline['files']) == 109
    by_relative = {p.relative_to(root).as_posix(): output for p, original, output, row in plans}
    for row in baseline['files']:
        before = (args.baseline_root/row['path']).read_bytes()
        after = by_relative[row['path']]
        assert sha(before) == row['before_sha256'], 'Baseline original hash changed'
        same = mathematical_text(before.decode('utf-8'), inventory.mask_comments) == mathematical_text(after.decode('utf-8'), inventory.mask_comments)
        assert same, f'Mathematical text differs from original baseline: {row["path"]}'
        row.update(identical_bytes=before == after, mathematical_text_identical=same, after_sha256=sha(after))
    baseline['method'] = ('Remove Lean comments, import directives, module/public-section visibility headers and empty lines; retain all mathematical code including indentation, statements and proof bodies. Header migration additionally has an exact reversible insertion-only byte certificate.')
    baseline['header_migration_report'] = 'verification/completion/module-header-migration.json'
    archive = root/'verification/completion/module-header-originals'
    report = {'status': 'TEXT_PRESERVATION_PASS' if args.apply else 'DRY_RUN_PASS',
        'kernel_acceptance': 'Requires a subsequent fresh full build and legacy-exporter audit.',
        'timestamp_utc': datetime.now(timezone.utc).isoformat(),
        'total_files': len(plans), 'changed_files': sum(original != output for _, original, output, _ in plans),
        'already_modern_files': sum(row['already_modern'] for _, _, _, row in plans),
        'theorem_count_before': theorem_count, 'theorem_count_after': theorem_count,
        'all_declaration_names_and_kinds_unchanged': names_before == names_after,
        'baseline_modules_mathematically_preserved': len(baseline['files']),
        'untouched_lean_sha256': {p.relative_to(root).as_posix(): sha(data) for p,data in sorted(untouched.items())},
        'files': [row for _, _, _, row in plans]}
    if args.apply:
        if archive.exists():
            raise RuntimeError('Refusing to overwrite an existing original archive')
        # Back up every eligible source before the first production source edit.
        for path, original, output, row in plans:
            saved = archive/row['path']; saved.parent.mkdir(parents=True, exist_ok=True)
            saved.write_bytes(original)
        (archive/'baseline-preservation-before.json').write_bytes(previous_baseline)
        for path, original, output, row in plans:
            assert path.read_bytes() == original, f'Concurrent source edit: {path}'
        for path, original, output, row in plans:
            if original != output:
                path.write_bytes(output)
            assert path.read_bytes() == output
        for path, data in untouched.items():
            assert path.read_bytes() == data, f'Protected file changed: {path}'
        write_json(baseline_path, baseline)
        write_json(root/'verification/completion/module-header-migration.json', report)
    else:
        write_json(Path(__file__).parent/'migration-dry-run.json', report)
    print(json.dumps({k: v for k, v in report.items() if k not in ('files','untouched_lean_sha256')}, indent=2))

if __name__ == '__main__':
    main()
