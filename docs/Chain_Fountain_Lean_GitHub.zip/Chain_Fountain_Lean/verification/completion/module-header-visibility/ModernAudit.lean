module

public import HeaderProbe
public import Lean

@[expose] public section

open Lean Elab Command
run_cmd liftTermElabM do
  let env ← getEnv
  let mut rows : Array Json := #[]
  for (name, ci) in env.constants.toList do
    let moduleName := match env.getModuleIdxFor? name with
      | some idx => env.header.moduleNames[idx.toNat]!.toString
      | none => env.mainModule.toString
    if moduleName == "HeaderProbe" then
      let kind := match ci with
        | .thmInfo _ => "theorem"
        | .defnInfo _ => "definition"
        | .axiomInfo _ => "axiom"
        | .opaqueInfo _ => "opaque"
        | .inductInfo _ => "inductive"
        | .ctorInfo _ => "constructor"
        | .recInfo _ => "recursor"
        | .quotInfo _ => "quotient"
      let axioms ← collectAxioms name
      rows := rows.push (Json.mkObj [
        ("name", toJson name.toString), ("kind", toJson kind),
        ("has_value", toJson (ci.value? true).isSome),
        ("value_refs", toJson (((ci.value? true).map fun e => e.getUsedConstants.map Name.toString).getD #[])),
        ("transitive_axioms", toJson (axioms.map Name.toString))])
  liftM <| IO.FS.writeFile "/workspace/scratch/4e82ee7f1b65/chain_completion/header_experiment/probe/modern.json" (Json.arr rows).pretty
