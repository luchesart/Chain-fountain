module

public import Init

@[expose] public section

namespace HeaderProbe
private theorem hidden : True := True.intro
theorem result : True := hidden
def identity (x : Nat) : Nat := x
structure Packet where
  value : Nat
end HeaderProbe
