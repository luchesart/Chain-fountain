/-
Adapted from mathlib's PicardLindelof.lean (pinned v4.19.0).
Copyright (c) 2021 Yury Kudryashov. All rights reserved.
Released under Apache 2.0 license as described in LICENSE.
Original authors: Yury Kudryashov, Winston Yin.
Changes: measurable time dependence; Lebesgue integral fixed points.
-/
import ChainFountain.MathlibSupport

namespace ChainFountain
open Filter Function Set Metric TopologicalSpace intervalIntegral MeasureTheory
open MeasureTheory.MeasureSpace (volume)
open scoped Filter Topology NNReal ENNReal Nat Interval
noncomputable section
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- Bounded, uniformly state-Lipschitz Caratheodory data. The measurability
condition is on every continuous test curve and contains no solution assumption. -/
structure IntegralPicard (E : Type*) [NormedAddCommGroup E] [NormedSpace ℝ E] where
  toFun : ℝ → E → E
  tMin : ℝ
  tMax : ℝ
  t₀ : Icc tMin tMax
  x₀ : E
  C : ℝ≥0
  L : ℝ≥0
  lipschitz_all : ∀ t, LipschitzWith L (toFun t)
  measurable_curve : ∀ f : ℝ → E, Continuous f →
    AEStronglyMeasurable (fun t => toFun t (f t)) volume
  bound_all : ∀ t x, ‖toFun t x‖ ≤ C

namespace IntegralPicard
variable (v : IntegralPicard E)
instance : CoeFun (IntegralPicard E) fun _ => ℝ → E → E := ⟨toFun⟩

theorem tMin_le_tMax : v.tMin ≤ v.tMax :=
  v.t₀.2.1.trans v.t₀.2.2

protected theorem nonempty_Icc : (Icc v.tMin v.tMax).Nonempty :=
  nonempty_Icc.2 v.tMin_le_tMax

/-- The maximum of distances from `t₀` to the endpoints of `[tMin, tMax]`. -/
def tDist : ℝ :=
  max (v.tMax - v.t₀) (v.t₀ - v.tMin)

theorem tDist_nonneg : 0 ≤ v.tDist :=
  le_max_iff.2 <| Or.inl <| sub_nonneg.2 v.t₀.2.2

theorem dist_t₀_le (t : Icc v.tMin v.tMax) : dist t v.t₀ ≤ v.tDist := by
  rw [Subtype.dist_eq, Real.dist_eq]
  rcases le_total t v.t₀ with ht | ht
  · rw [abs_of_nonpos (sub_nonpos.2 <| Subtype.coe_le_coe.2 ht), neg_sub]
    exact (sub_le_sub_left t.2.1 _).trans (le_max_right _ _)
  · rw [abs_of_nonneg (sub_nonneg.2 <| Subtype.coe_le_coe.2 ht)]
    exact (sub_le_sub_right t.2.2 _).trans (le_max_left _ _)

/-- Projection $ℝ → [t_{\min}, t_{\max}]$ sending $(-∞, t_{\min}]$ to $t_{\min}$ and $[t_{\max}, ∞)$
to $t_{\max}$. -/
def proj : ℝ → Icc v.tMin v.tMax :=
  projIcc v.tMin v.tMax v.tMin_le_tMax

theorem proj_coe (t : Icc v.tMin v.tMax) : v.proj t = t :=
  projIcc_val _ _

theorem proj_of_mem {t : ℝ} (ht : t ∈ Icc v.tMin v.tMax) : ↑(v.proj t) = t := by
  simp only [proj, projIcc_of_mem v.tMin_le_tMax ht]

@[continuity, fun_prop]
theorem continuous_proj : Continuous v.proj :=
  continuous_projIcc

/-- The space of curves $γ \colon [t_{\min}, t_{\max}] \to E$ such that $γ(t₀) = x₀$ and $γ$ is
Lipschitz continuous with constant $C$. The map sending $γ$ to
$\mathbf Pγ(t)=x₀ + ∫_{t₀}^{t} v(τ, γ(τ))\,dτ$ is a contracting map on this space, and its fixed
point is a solution of the ODE $\dot x=v(t, x)$. -/
structure FunSpace where
  /-- The particular curve represented by this object. -/
  toFun : Icc v.tMin v.tMax → E
  map_t₀' : toFun v.t₀ = v.x₀
  lipschitz' : LipschitzWith v.C toFun

namespace FunSpace

variable {v}
variable (f : FunSpace v)

instance : CoeFun (FunSpace v) fun _ => Icc v.tMin v.tMax → E :=
  ⟨toFun⟩

instance : Inhabited v.FunSpace :=
  ⟨⟨fun _ => v.x₀, rfl, (LipschitzWith.const _).weaken (zero_le)⟩⟩

protected theorem lipschitz : LipschitzWith v.C f :=
  f.lipschitz'

protected theorem continuous : Continuous f :=
  f.lipschitz.continuous

/-- Each curve in `IntegralPicard.FunSpace` is continuous. -/
def toContinuousMap : v.FunSpace ↪ C(Icc v.tMin v.tMax, E) :=
  ⟨fun f => ⟨f, f.continuous⟩, fun f g h => by cases f; cases g; simpa using! h⟩

instance : MetricSpace v.FunSpace :=
  MetricSpace.induced toContinuousMap toContinuousMap.injective inferInstance

theorem isUniformInducing_toContinuousMap : IsUniformInducing (@toContinuousMap _ _ _ v) :=
  ⟨rfl⟩

theorem range_toContinuousMap :
    range toContinuousMap =
      {f : C(Icc v.tMin v.tMax, E) | f v.t₀ = v.x₀ ∧ LipschitzWith v.C f} := by
  ext f; constructor
  · rintro ⟨⟨f, hf₀, hf_lip⟩, rfl⟩; exact ⟨hf₀, hf_lip⟩
  · rcases f with ⟨f, hf⟩; rintro ⟨hf₀, hf_lip⟩; exact ⟨⟨f, hf₀, hf_lip⟩, rfl⟩

theorem map_t₀ : f v.t₀ = v.x₀ :=
  f.map_t₀'

/-- Only the continuous test curve is extended by projection. Time in the
measurable vector field is left untouched. -/
def vComp (t : ℝ) : E := v t (f (v.proj t))

theorem vComp_apply_coe (t : Icc v.tMin v.tMax) : f.vComp t = v t (f t) := by
  simp only [vComp, proj_coe]

theorem measurable_vComp : AEStronglyMeasurable f.vComp volume :=
  v.measurable_curve _ (f.continuous.comp v.continuous_proj)

theorem norm_vComp_le (t : ℝ) : ‖f.vComp t‖ ≤ v.C := v.bound_all _ _

theorem dist_apply_le_dist (f₁ f₂ : FunSpace v) (t : Icc v.tMin v.tMax) :
    dist (f₁ t) (f₂ t) ≤ dist f₁ f₂ :=
  @ContinuousMap.dist_apply_le_dist _ _ _ _ _ (toContinuousMap f₁) (toContinuousMap f₂) _

theorem dist_le_of_forall {f₁ f₂ : FunSpace v} {d : ℝ} (h : ∀ t, dist (f₁ t) (f₂ t) ≤ d) :
    dist f₁ f₂ ≤ d :=
  (@ContinuousMap.dist_le_iff_of_nonempty _ _ _ _ _ (toContinuousMap f₁) (toContinuousMap f₂) _
    v.nonempty_Icc.to_subtype).2 h

instance [CompleteSpace E] : CompleteSpace v.FunSpace := by
  refine (completeSpace_iff_isComplete_range isUniformInducing_toContinuousMap).2
      (IsClosed.isComplete ?_)
  rw [range_toContinuousMap, setOf_and]
  refine (isClosed_eq (continuous_eval_const _) continuous_const).inter ?_
  have : IsClosed {f : Icc v.tMin v.tMax → E | LipschitzWith v.C f} :=
    isClosed_setOf_lipschitzWith v.C
  exact this.preimage continuous_coeFun

theorem intervalIntegrable_vComp (t₁ t₂ : ℝ) : IntervalIntegrable f.vComp volume t₁ t₂ := by
  rw [intervalIntegrable_iff]
  exact Measure.integrableOn_of_bounded measure_Ioc_lt_top.ne f.measurable_vComp
    (Filter.Eventually.of_forall f.norm_vComp_le)

/-- The Picard-Lindelöf operator. This is a contracting map on `IntegralPicard.FunSpace v` such
that the fixed point of this map is the solution of the corresponding ODE.

More precisely, some iteration of this map is a contracting map. -/
def next (f : FunSpace v) : FunSpace v where
  toFun t := v.x₀ + ∫ τ : ℝ in v.t₀..t, f.vComp τ
  map_t₀' := by simp only [integral_same, add_zero]
  lipschitz' := LipschitzWith.of_dist_le_mul fun t₁ t₂ => by
    rw [dist_add_left, dist_eq_norm,
      integral_interval_sub_left (f.intervalIntegrable_vComp _ _) (f.intervalIntegrable_vComp _ _)]
    exact norm_integral_le_of_norm_le_const fun t _ => f.norm_vComp_le _

theorem next_apply (t : Icc v.tMin v.tMax) : f.next t = v.x₀ + ∫ τ : ℝ in v.t₀..t, f.vComp τ :=
  rfl

theorem dist_next_apply_le_of_le {f₁ f₂ : FunSpace v} {n : ℕ} {d : ℝ}
    (h : ∀ t, dist (f₁ t) (f₂ t) ≤ (v.L * |t.1 - v.t₀|) ^ n / n ! * d) (t : Icc v.tMin v.tMax) :
    dist (next f₁ t) (next f₂ t) ≤ (v.L * |t.1 - v.t₀|) ^ (n + 1) / (n + 1)! * d := by
  simp only [dist_eq_norm, next_apply, add_sub_add_left_eq_sub, ←
    intervalIntegral.integral_sub (intervalIntegrable_vComp _ _ _)
      (intervalIntegrable_vComp _ _ _),
    norm_integral_eq_norm_integral_uIoc] at *
  calc
    ‖∫ τ in Ι (v.t₀ : ℝ) t, f₁.vComp τ - f₂.vComp τ‖ ≤
        ∫ τ in Ι (v.t₀ : ℝ) t, v.L * ((v.L * |τ - v.t₀|) ^ n / n ! * d) := by
      refine norm_integral_le_of_norm_le (Continuous.integrableOn_uIoc (by fun_prop)) ?_
      refine (ae_restrict_mem measurableSet_Ioc).mono fun τ hτ ↦ ?_
      refine (v.lipschitz_all τ).norm_sub_le_of_le ((h _).trans_eq ?_)
      rw [v.proj_of_mem]
      exact uIcc_subset_Icc v.t₀.2 t.2 <| Ioc_subset_Icc_self hτ
    _ = (v.L * |t.1 - v.t₀|) ^ (n + 1) / (n + 1)! * d := by
      simp_rw [mul_pow, div_eq_mul_inv, mul_assoc, MeasureTheory.integral_const_mul,
        MeasureTheory.integral_mul_const, integral_pow_abs_sub_uIoc, div_eq_mul_inv,
        pow_succ' (v.L : ℝ), Nat.factorial_succ, Nat.cast_mul, Nat.cast_succ, mul_inv, mul_assoc]

theorem dist_iterate_next_apply_le (f₁ f₂ : FunSpace v) (n : ℕ) (t : Icc v.tMin v.tMax) :
    dist (next^[n] f₁ t) (next^[n] f₂ t) ≤ (v.L * |t.1 - v.t₀|) ^ n / n ! * dist f₁ f₂ := by
  induction n generalizing t with
  | zero =>
    rw [pow_zero, Nat.factorial_zero, Nat.cast_one, div_one, one_mul]
    exact dist_apply_le_dist f₁ f₂ t
  | succ n ihn =>
    rw [iterate_succ_apply', iterate_succ_apply']
    exact dist_next_apply_le_of_le ihn _

theorem dist_iterate_next_le (f₁ f₂ : FunSpace v) (n : ℕ) :
    dist (next^[n] f₁) (next^[n] f₂) ≤ (v.L * v.tDist) ^ n / n ! * dist f₁ f₂ := by
  refine dist_le_of_forall fun t => (dist_iterate_next_apply_le _ _ _ _).trans ?_
  have : |(t - v.t₀ : ℝ)| ≤ v.tDist := v.dist_t₀_le t
  gcongr

end FunSpace

theorem exists_contracting_iterate :
    ∃ (N : ℕ) (K : _), ContractingWith K (FunSpace.next : v.FunSpace → v.FunSpace)^[N] := by
  rcases ((FloorSemiring.tendsto_pow_div_factorial_atTop (v.L * v.tDist)).eventually
    (gt_mem_nhds zero_lt_one)).exists with ⟨N, hN⟩
  have : (0 : ℝ) ≤ (v.L * v.tDist) ^ N / N ! :=
    div_nonneg (pow_nonneg (mul_nonneg v.L.2 v.tDist_nonneg) _) (Nat.cast_nonneg _)
  exact ⟨N, ⟨_, this⟩, hN, LipschitzWith.of_dist_le_mul fun f g =>
    FunSpace.dist_iterate_next_le f g N⟩

theorem exists_fixed [CompleteSpace E] : ∃ f : v.FunSpace, f.next = f :=
  let ⟨_N, _K, hK⟩ := exists_contracting_iterate v
  ⟨_, hK.isFixedPt_fixedPoint_iterate⟩


/-- A true finite-horizon construction for measurable time dependence, in
Lebesgue integral form. No existing trajectory is supplied. -/
theorem exists_integral_solution [CompleteSpace E] :
    ∃ x : ℝ → E, LipschitzWith v.C x ∧ x v.t₀=v.x₀ ∧
      ∀ t∈Icc v.tMin v.tMax, x t=v.x₀+∫ s in (v.t₀:ℝ)..t, v s (x s) := by
  obtain ⟨f,hf⟩ := v.exists_fixed
  refine ⟨fun t => f (v.proj t), ?_, ?_, ?_⟩
  · simpa only [mul_one,Function.comp_def,IntegralPicard.proj] using!
      f.lipschitz.comp (LipschitzWith.projIcc v.tMin_le_tMax)
  · simpa only [v.proj_coe] using! f.map_t₀
  · intro t ht
    have hproj : v.proj t = ⟨t,ht⟩ := by apply Subtype.ext; exact v.proj_of_mem ht
    have hn := congrArg (fun f : v.FunSpace => f ⟨t,ht⟩) hf
    simpa [FunSpace.next_apply,FunSpace.vComp,hproj] using! hn.symm

end IntegralPicard
end
end ChainFountain
