import ChainFountain.MathlibSupport
import ChainFountain.ModelCore

/-!
Compatibility entry point for the original v0.16.0 model.
All model definitions, theorem statements and proof bodies are unchanged in
`ModelCore`. Explicit imports in `MathlibSupport` replace the blanket Mathlib
re-export; the zero-gravity library imports `ModelCore` directly for a smaller
dependency closure. The pre-change entry point is preserved in
`verification/completion/import-compatibility-originals/Model.lean`.
-/
