import Mathlib.Analysis.Calculus.Deriv.Inverse
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Analysis.Calculus.ContDiff.Operations
import Mathlib.Analysis.Calculus.ContDiff.Deriv
import Mathlib.Analysis.InnerProductSpace.Calculus
import Mathlib.Topology.Instances.Real.Lemmas
import Mathlib.Topology.Order.Compact
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum

/-!
# Arclength coordinates for regular closed curves

The inverse coordinate is constructed from the integral of speed; its derivative
and the unit-speed property are conclusions, not hypotheses.  Periodicity and
regularity provide the uniform positive speed bound needed for a global inverse.
-/

namespace ChainFountain.ZeroGravity
noncomputable section
open MeasureTheory Set Filter Function
open scoped Topology ContDiff

/-- The signed accumulated length along a parametrized curve. -/
def arcCoordinate {E : Type*} [NormedAddCommGroup E] (Q1 : ℝ → E) (b : ℝ) : ℝ :=
  ∫ x in 0..b, ‖Q1 x‖

section Normed
variable {E : Type*} [NormedAddCommGroup E]

theorem arcCoordinate_hasDerivAt {Q1 : ℝ → E} (hc : Continuous Q1) (b : ℝ) :
    HasDerivAt (arcCoordinate Q1) ‖Q1 b‖ b := by
  exact intervalIntegral.integral_hasDerivAt_right
    (hc.norm.intervalIntegrable 0 b) hc.norm.stronglyMeasurable.stronglyMeasurableAtFilter
    hc.norm.continuousAt

theorem arcCoordinate_zero (Q1 : ℝ → E) : arcCoordinate Q1 0 = 0 := by
  simp [arcCoordinate]

theorem arcCoordinate_strictMono {Q1 : ℝ → E} (hc : Continuous Q1)
    (hreg : ∀ b, Q1 b ≠ 0) : StrictMono (arcCoordinate Q1) :=
  strictMono_of_hasDerivAt_pos (arcCoordinate_hasDerivAt hc)
    (fun b => norm_pos_iff.mpr (hreg b))

theorem periodic_speed_positive_lower {Q1 : ℝ → E} {P : ℝ}
    (hc : Continuous Q1) (hp : Function.Periodic Q1 P) (hP : P ≠ 0)
    (hreg : ∀ b, Q1 b ≠ 0) : ∃ m : ℝ, 0 < m ∧ ∀ b, m ≤ ‖Q1 b‖ := by
  have hcpt : IsCompact (range (fun b => ‖Q1 b‖)) :=
    ((hp.comp norm).compact_of_continuous hP hc.norm)
  obtain ⟨m, hm, hmin⟩ := hcpt.exists_isMinOn (range_nonempty _) continuous_id.continuousOn
  rcases hm with ⟨b, rfl⟩
  exact ⟨‖Q1 b‖, norm_pos_iff.mpr (hreg b),
    fun x => (isMinOn_iff.mp hmin) _ (mem_range_self x)⟩

theorem arcCoordinate_surjective {Q1 : ℝ → E} (hc : Continuous Q1)
    {m : ℝ} (hm : 0 < m) (hbound : ∀ b, m ≤ ‖Q1 b‖) :
    Function.Surjective (arcCoordinate Q1) := by
  have hd := arcCoordinate_hasDerivAt hc
  have hdiff : Differentiable ℝ (arcCoordinate Q1) := fun x => (hd x).differentiableAt
  have hderiv : ∀ b, m ≤ deriv (arcCoordinate Q1) b := by
    intro b; rw [(hd b).deriv]; exact hbound b
  have htop : Tendsto (arcCoordinate Q1) atTop atTop := by
    apply tendsto_atTop_mono' atTop _ (Tendsto.const_mul_atTop hm tendsto_id)
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with x hx
    simpa [arcCoordinate_zero] using mul_sub_le_image_sub_of_le_deriv hdiff hderiv hx
  have hbot : Tendsto (arcCoordinate Q1) atBot atBot := by
    apply tendsto_atBot_mono' atBot _ ((tendsto_const_mul_atBot_of_pos hm).2 tendsto_id)
    filter_upwards [eventually_le_atBot (0 : ℝ)] with x hx
    have h := mul_sub_le_image_sub_of_le_deriv hdiff hderiv hx
    simp only [arcCoordinate_zero, zero_sub, mul_neg] at h
    change arcCoordinate Q1 x ≤ m * x
    linarith
  exact hdiff.continuous.surjective htop hbot

/-- The actual global inverse is obtained from strict monotonicity and surjectivity. -/
def arcOrderIso {Q1 : ℝ → E} (hc : Continuous Q1) (hreg : ∀ b, Q1 b ≠ 0)
    {m : ℝ} (hm : 0 < m) (hbound : ∀ b, m ≤ ‖Q1 b‖) : ℝ ≃o ℝ :=
  (arcCoordinate_strictMono hc hreg).orderIsoOfSurjective
    (arcCoordinate Q1) (arcCoordinate_surjective hc hm hbound)

theorem arcOrderIso_apply {Q1 : ℝ → E} (hc : Continuous Q1)
    (hreg : ∀ b, Q1 b ≠ 0) {m : ℝ} (hm : 0 < m)
    (hbound : ∀ b, m ≤ ‖Q1 b‖) (b : ℝ) :
    arcOrderIso hc hreg hm hbound b = arcCoordinate Q1 b := rfl

theorem arcOrderIso_symm_hasDerivAt {Q1 : ℝ → E} (hc : Continuous Q1)
    (hreg : ∀ b, Q1 b ≠ 0) {m : ℝ} (hm : 0 < m)
    (hbound : ∀ b, m ≤ ‖Q1 b‖) (a : ℝ) :
    HasDerivAt (arcOrderIso hc hreg hm hbound).symm
      (‖Q1 ((arcOrderIso hc hreg hm hbound).symm a)‖⁻¹) a := by
  let A := arcOrderIso hc hreg hm hbound
  have hi : ∀ᶠ y in 𝓝 a, arcCoordinate Q1 (A.symm y) = y :=
    Eventually.of_forall fun y => A.apply_symm_apply y
  exact (arcCoordinate_hasDerivAt hc (A.symm a)).of_local_left_inverse
    A.symm.continuous.continuousAt (norm_ne_zero_iff.mpr (hreg _)) hi

theorem arcCoordinate_add_period {Q1 : ℝ → E} {P : ℝ}
    (hc : Continuous Q1) (hp : Function.Periodic Q1 P) (b : ℝ) :
    arcCoordinate Q1 (b + P) = arcCoordinate Q1 b + arcCoordinate Q1 P := by
  simpa [arcCoordinate] using (hp.comp norm).intervalIntegral_add_eq_add 0 b
    (fun x y => hc.norm.intervalIntegrable x y)

theorem arcOrderIso_symm_add_period {Q1 : ℝ → E} {P : ℝ}
    (hc : Continuous Q1) (hp : Function.Periodic Q1 P)
    (hreg : ∀ b, Q1 b ≠ 0) {m : ℝ} (hm : 0 < m)
    (hbound : ∀ b, m ≤ ‖Q1 b‖) (a : ℝ) :
    (arcOrderIso hc hreg hm hbound).symm (a + arcCoordinate Q1 P) =
      (arcOrderIso hc hreg hm hbound).symm a + P := by
  let A := arcOrderIso hc hreg hm hbound
  apply A.injective
  change A (A.symm (a + arcCoordinate Q1 P)) = A (A.symm a + P)
  rw [A.apply_symm_apply]
  change a + arcCoordinate Q1 P = arcCoordinate Q1 (A.symm a + P)
  rw [arcCoordinate_add_period hc hp]
  exact congrArg (fun x => x + arcCoordinate Q1 P) (A.apply_symm_apply a).symm

variable [NormedSpace ℝ E]

/-- Global arclength reparameterization preserves the geometric image and closes
after the accumulated length of one original period. -/
theorem periodic_arclength_reparameterization {Q Q1 : ℝ → E} {P : ℝ}
    (hQ : ∀ b, HasDerivAt Q (Q1 b) b) (hc : Continuous Q1)
    (hQp : Function.Periodic Q P) (hQ1p : Function.Periodic Q1 P)
    (hP : 0 < P) (hreg : ∀ b, Q1 b ≠ 0) :
    ∃ S : ℝ → ℝ, ∃ R : ℝ → E,
      Function.LeftInverse S (arcCoordinate Q1) ∧
      Function.RightInverse S (arcCoordinate Q1) ∧
      R = Q ∘ S ∧ Set.range R = Set.range Q ∧
      0 < arcCoordinate Q1 P ∧ Function.Periodic R (arcCoordinate Q1 P) ∧
      (∀ a, HasDerivAt R (‖Q1 (S a)‖⁻¹ • Q1 (S a)) a) ∧
      (∀ a, ‖deriv R a‖ = 1) := by
  obtain ⟨m, hm, hbound⟩ := periodic_speed_positive_lower hc hQ1p (ne_of_gt hP) hreg
  let A := arcOrderIso hc hreg hm hbound
  let S : ℝ → ℝ := A.symm
  let R : ℝ → E := Q ∘ S
  have hR : ∀ a, HasDerivAt R (‖Q1 (S a)‖⁻¹ • Q1 (S a)) a := by
    intro a
    exact (hQ (S a)).scomp a (arcOrderIso_symm_hasDerivAt hc hreg hm hbound a)
  refine ⟨S, R, A.symm_apply_apply, A.apply_symm_apply, rfl, ?_, ?_, ?_, hR, ?_⟩
  · exact A.symm.surjective.range_comp Q
  · have h := arcCoordinate_strictMono hc hreg hP
    simpa [arcCoordinate_zero] using h
  · intro a
    dsimp [R, Function.comp_def, S]
    rw [arcOrderIso_symm_add_period hc hQ1p hreg hm hbound]
    exact hQp _
  · intro a
    rw [(hR a).deriv, norm_smul, Real.norm_eq_abs, abs_of_nonneg (inv_nonneg.mpr (norm_nonneg _))]
    exact inv_mul_cancel₀ (norm_ne_zero_iff.mpr (hreg _))

end Normed

section Smooth
variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

theorem periodic_curve_derivative {Q Q1 : ℝ → E} {P : ℝ}
    (hQ : ∀ b, HasDerivAt Q (Q1 b) b) (hp : Function.Periodic Q P) :
    Function.Periodic Q1 P := by
  intro b
  have he : (fun x => Q (x + P)) = Q := funext hp
  have hd : HasDerivAt (fun x => Q (x + P)) (Q1 (b + P)) b := by
    simpa only [Function.comp_def, one_smul] using!
      (hQ (b + P)).scomp b ((hasDerivAt_id b).add_const P)
  rw [he] at hd
  exact hd.unique (hQ b)

theorem arcCoordinate_contDiff_two {Q1 : ℝ → E} (hc : ContDiff ℝ 1 Q1)
    (hreg : ∀ b, Q1 b ≠ 0) : ContDiff ℝ 2 (arcCoordinate Q1) := by
  have hd := arcCoordinate_hasDerivAt hc.continuous
  have he : deriv (arcCoordinate Q1) = fun b => ‖Q1 b‖ := funext fun b => (hd b).deriv
  change ContDiff ℝ ((1 : ℕ∞ω) + 1) (arcCoordinate Q1)
  apply contDiff_succ_iff_deriv.mpr
  refine ⟨fun b => (hd b).differentiableAt, ?_, ?_⟩
  · norm_num
  · rw [he]
    exact hc.norm ℝ hreg

theorem arcOrderIso_symm_contDiff_two {Q1 : ℝ → E} (hc : ContDiff ℝ 1 Q1)
    (hreg : ∀ b, Q1 b ≠ 0) {m : ℝ} (hm : 0 < m)
    (hbound : ∀ b, m ≤ ‖Q1 b‖) :
    ContDiff ℝ 2 (arcOrderIso hc.continuous hreg hm hbound).symm := by
  let A := arcOrderIso hc.continuous hreg hm hbound
  exact A.toHomeomorph.contDiff_symm_deriv
    (fun b => norm_ne_zero_iff.mpr (hreg b))
    (arcCoordinate_hasDerivAt hc.continuous) (arcCoordinate_contDiff_two hc hreg)

/-- Every `C²` regular periodic curve admits a global `C²` unit-speed
parameterization, with the same spatial image and period equal to its length.
The period need not be the minimal period, and self-intersections are allowed. -/
theorem closed_regular_curve_arclength {Q : ℝ → E} {P : ℝ}
    (hQ : ContDiff ℝ 2 Q) (hp : Function.Periodic Q P) (hP : 0 < P)
    (hreg : ∀ b, deriv Q b ≠ 0) :
    ∃ R : ℝ → E, ContDiff ℝ 2 R ∧ Set.range R = Set.range Q ∧
      0 < arcCoordinate (deriv Q) P ∧
      Function.Periodic R (arcCoordinate (deriv Q) P) ∧
      (∀ a, ‖deriv R a‖ = 1) := by
  have hd : ∀ b, HasDerivAt Q (deriv Q b) b :=
    fun b => (hQ.differentiable (by norm_num) b).hasDerivAt
  have hc : ContDiff ℝ 1 (deriv Q) :=
    (contDiff_succ_iff_deriv.mp (show ContDiff ℝ ((1 : ℕ∞ω) + 1) Q from hQ)).2.2
  have hdp := periodic_curve_derivative hd hp
  obtain ⟨m, hm, hbound⟩ := periodic_speed_positive_lower hc.continuous hdp (ne_of_gt hP) hreg
  let A := arcOrderIso hc.continuous hreg hm hbound
  let R : ℝ → E := Q ∘ A.symm
  have hR : ∀ a, HasDerivAt R
      (‖deriv Q (A.symm a)‖⁻¹ • deriv Q (A.symm a)) a := by
    intro a
    exact (hd (A.symm a)).scomp a
      (arcOrderIso_symm_hasDerivAt hc.continuous hreg hm hbound a)
  refine ⟨R, hQ.comp (arcOrderIso_symm_contDiff_two hc hreg hm hbound),
    A.symm.surjective.range_comp Q, ?_, ?_, ?_⟩
  · have h := arcCoordinate_strictMono hc.continuous hreg hP
    simpa [arcCoordinate_zero] using h
  · intro a
    dsimp [R, Function.comp_def]
    rw [arcOrderIso_symm_add_period hc.continuous hdp hreg hm hbound]
    exact hp _
  · intro a
    rw [(hR a).deriv, norm_smul, Real.norm_eq_abs, abs_of_nonneg (inv_nonneg.mpr (norm_nonneg _))]
    exact inv_mul_cancel₀ (norm_ne_zero_iff.mpr (hreg _))

end Smooth
end
end ChainFountain.ZeroGravity
