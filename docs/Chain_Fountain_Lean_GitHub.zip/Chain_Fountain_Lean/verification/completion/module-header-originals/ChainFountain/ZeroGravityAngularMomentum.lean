import ChainFountain.ZeroGravityCirculation
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic

/-!
# Spatial force and angular momentum of a circulating planar loop

All moment quantities below are genuine material-coordinate interval integrals.
Periodicity, rather than an assumption about the desired moment, removes the
circulation phase. The time derivative is subsequently obtained from the scalar
speed equation. These statements concern distributed tangential forcing on the
exact circulation family; a local drive and its reaction dynamics are separate.
-/

namespace ChainFountain.ZeroGravity
noncomputable section
open Set Real MeasureTheory

/-- The scalar normal component of the planar cross product `R × R'`. -/
def planarCrossDensity (x y dx dy : ℝ → ℝ) (a : ℝ) : ℝ :=
  x a * dy a - y a * dx a

/-- Signed area, defined by its boundary integral. -/
def planarSignedArea (L : ℝ) (x y dx dy : ℝ → ℝ) : ℝ :=
  (∫ a in (0 : ℝ)..L, planarCrossDensity x y dx dy a) / 2

/-- Moment of a uniform tangential vector field, integrated over material labels.
For velocity use `q = c`; for force per unit mass use `q = u - γ*c + d`. -/
def planarTangentialMoment (L lam : ℝ) (x y dx dy : ℝ → ℝ)
    (θ q : ℝ) : ℝ :=
  ∫ a in (0 : ℝ)..L,
    lam * (x (a + θ) * (q * dy (a + θ)) - y (a + θ) * (q * dx (a + θ)))

/-- Angular momentum computed directly from the actual material time derivatives. -/
def planarMaterialAngularMomentum (L lam : ℝ) (x y θ : ℝ → ℝ) (t : ℝ) : ℝ :=
  ∫ a in (0 : ℝ)..L,
    lam * (x (a + θ t) * deriv (fun s => y (a + θ s)) t -
      y (a + θ t) * deriv (fun s => x (a + θ s)) t)

/-- The tangent of a differentiable periodic scalar curve is periodic. -/
theorem periodic_derivative_of_hasDerivAt {x dx : ℝ → ℝ} {L : ℝ}
    (hx : Function.Periodic x L) (hd : ∀ a, HasDerivAt x (dx a) a) :
    Function.Periodic dx L := by
  intro a
  have hs := (hd (a + L)).scomp a ((hasDerivAt_id a).add_const L)
  have he : (fun b => x (b + L)) = x := funext hx
  have hs' : HasDerivAt x (dx (a + L)) a := by
    simpa only [Function.comp_def, id_eq, one_smul, he] using hs
  exact hs'.unique (hd a)

/-- `R × R'` inherits the period of the curve and its tangent. -/
theorem planarCrossDensity_periodic {x y dx dy : ℝ → ℝ} {L : ℝ}
    (hx : Function.Periodic x L) (hy : Function.Periodic y L)
    (hdx : Function.Periodic dx L) (hdy : Function.Periodic dy L) :
    Function.Periodic (planarCrossDensity x y dx dy) L := by
  intro a
  simp only [planarCrossDensity, hx a, hy a, hdx a, hdy a]

/-- For a continuously differentiable curve the area integrand is genuinely
integrable on every finite interval. -/
theorem planarCrossDensity_intervalIntegrable {x y dx dy : ℝ → ℝ}
    (hdx : ∀ a, HasDerivAt x (dx a) a) (hdy : ∀ a, HasDerivAt y (dy a) a)
    (hcx : Continuous dx) (hcy : Continuous dy) (a b : ℝ) :
    IntervalIntegrable (planarCrossDensity x y dx dy) volume a b := by
  have hx : Continuous x := continuous_iff_continuousAt.mpr (fun a => (hdx a).continuousAt)
  have hy : Continuous y := continuous_iff_continuousAt.mpr (fun a => (hdy a).continuousAt)
  exact ((hx.mul hcy).sub (hy.mul hcx)).intervalIntegrable a b

/-- An integral over one complete period is unchanged by material phase. -/
theorem periodic_material_integral {f : ℝ → ℝ} {L : ℝ}
    (hf : Function.Periodic f L) (θ : ℝ) :
    (∫ a in (0 : ℝ)..L, f (a + θ)) = ∫ a in (0 : ℝ)..L, f a := by
  rw [intervalIntegral.integral_comp_add_right]
  simpa only [zero_add, add_comm L θ] using hf.intervalIntegral_add_eq θ 0

/-- The actual moment integral equals twice signed area times density and speed.
Periodicity of the tangent is derived from the curve derivatives. -/
theorem planarTangentialMoment_eq_area {L lam θ q : ℝ} {x y dx dy : ℝ → ℝ}
    (hx : Function.Periodic x L) (hy : Function.Periodic y L)
    (hdx : ∀ a, HasDerivAt x (dx a) a) (hdy : ∀ a, HasDerivAt y (dy a) a) :
    planarTangentialMoment L lam x y dx dy θ q =
      2 * lam * planarSignedArea L x y dx dy * q := by
  have hp := planarCrossDensity_periodic hx hy
    (periodic_derivative_of_hasDerivAt hx hdx)
    (periodic_derivative_of_hasDerivAt hy hdy)
  have he : (fun a => lam * (x (a + θ) * (q * dy (a + θ)) -
      y (a + θ) * (q * dx (a + θ)))) =
      (fun a => (lam * q) * planarCrossDensity x y dx dy (a + θ)) := by
    funext a
    unfold planarCrossDensity
    ring
  unfold planarTangentialMoment
  rw [he, intervalIntegral.integral_const_mul, periodic_material_integral hp θ]
  unfold planarSignedArea
  ring

/-- The actual derivative-based angular momentum is the tangential moment. -/
theorem planarMaterialAngularMomentum_eq_moment
    {L lam t : ℝ} {x y dx dy θ c : ℝ → ℝ}
    (hdx : ∀ a, HasDerivAt x (dx a) a) (hdy : ∀ a, HasDerivAt y (dy a) a)
    (hθ : HasDerivAt θ (c t) t) :
    planarMaterialAngularMomentum L lam x y θ t =
      planarTangentialMoment L lam x y dx dy (θ t) (c t) := by
  have hvx (a : ℝ) : deriv (fun s => x (a + θ s)) t = c t * dx (a + θ t) := by
    simpa only [smul_eq_mul] using (loop_position_hasDerivAt (hdx _) hθ).deriv
  have hvy (a : ℝ) : deriv (fun s => y (a + θ s)) t = c t * dy (a + θ t) := by
    simpa only [smul_eq_mul] using (loop_position_hasDerivAt (hdy _) hθ).deriv
  unfold planarMaterialAngularMomentum planarTangentialMoment
  simp_rw [hvx, hvy]

/-- The paper's angular-momentum identity with an actual spatial integral. -/
theorem planarMaterialAngularMomentum_eq_area
    {L lam t : ℝ} {x y dx dy θ c : ℝ → ℝ}
    (hx : Function.Periodic x L) (hy : Function.Periodic y L)
    (hdx : ∀ a, HasDerivAt x (dx a) a) (hdy : ∀ a, HasDerivAt y (dy a) a)
    (hθ : HasDerivAt θ (c t) t) :
    planarMaterialAngularMomentum L lam x y θ t =
      2 * lam * planarSignedArea L x y dx dy * c t := by
  rw [planarMaterialAngularMomentum_eq_moment hdx hdy hθ]
  exact planarTangentialMoment_eq_area hx hy hdx hdy

/-- Genuine time derivative of the actual angular-momentum integral, with the
right-hand side equal to the spatial integral of the applied tangential torque. -/
theorem planarMaterialAngularMomentum_hasDerivAt
    {L lam γ u d t : ℝ} {x y dx dy θ c : ℝ → ℝ}
    (hx : Function.Periodic x L) (hy : Function.Periodic y L)
    (hdx : ∀ a, HasDerivAt x (dx a) a) (hdy : ∀ a, HasDerivAt y (dy a) a)
    (hθ : ∀ s, HasDerivAt θ (c s) s)
    (hc : HasDerivAt c (u - γ * c t + d) t) :
    HasDerivAt (planarMaterialAngularMomentum L lam x y θ)
      (planarTangentialMoment L lam x y dx dy (θ t) (u - γ * c t + d)) t := by
  have he : planarMaterialAngularMomentum L lam x y θ =
      (fun s => (2 * lam * planarSignedArea L x y dx dy) * c s) := by
    funext s
    exact planarMaterialAngularMomentum_eq_area hx hy hdx hdy (hθ s)
  rw [he, planarTangentialMoment_eq_area hx hy hdx hdy]
  exact hc.const_mul _

/-- The paper's explicit angular-momentum rate formula. -/
theorem planarMaterialAngularMomentum_rate_formula
    {L lam γ u d t : ℝ} {x y dx dy θ c : ℝ → ℝ}
    (hx : Function.Periodic x L) (hy : Function.Periodic y L)
    (hdx : ∀ a, HasDerivAt x (dx a) a) (hdy : ∀ a, HasDerivAt y (dy a) a)
    (hθ : ∀ s, HasDerivAt θ (c s) s)
    (hc : HasDerivAt c (u - γ * c t + d) t) :
    HasDerivAt (planarMaterialAngularMomentum L lam x y θ)
      (2 * lam * planarSignedArea L x y dx dy * (u - γ * c t + d)) t := by
  simpa only [planarTangentialMoment_eq_area hx hy hdx hdy] using
    planarMaterialAngularMomentum_hasDerivAt hx hy hdx hdy hθ hc

/-- The same spatial torque balance holds almost everywhere for a measurable
forcing whenever the scalar circulation equation holds almost everywhere. -/
theorem planarMaterialAngularMomentum_hasDerivAt_ae
    {L lam γ : ℝ} {x y dx dy θ c u d : ℝ → ℝ} {μ : Measure ℝ}
    (hx : Function.Periodic x L) (hy : Function.Periodic y L)
    (hdx : ∀ a, HasDerivAt x (dx a) a) (hdy : ∀ a, HasDerivAt y (dy a) a)
    (hθ : ∀ s, HasDerivAt θ (c s) s)
    (hc : ∀ᵐ t ∂μ, HasDerivAt c (u t - γ * c t + d t) t) :
    ∀ᵐ t ∂μ, HasDerivAt (planarMaterialAngularMomentum L lam x y θ)
      (planarTangentialMoment L lam x y dx dy (θ t) (u t - γ * c t + d t)) t := by
  exact hc.mono (fun _ ht => planarMaterialAngularMomentum_hasDerivAt hx hy hdx hdy hθ ht)

/-- The full-period integral of a curve's derivative is zero. -/
theorem periodic_tangent_integral_zero {x dx : ℝ → ℝ} {L : ℝ}
    (hx : Function.Periodic x L) (hdx : ∀ a, HasDerivAt x (dx a) a)
    (hc : Continuous dx) (θ : ℝ) :
    (∫ a in (0 : ℝ)..L, dx (a + θ)) = 0 := by
  have hd (a : ℝ) : HasDerivAt (fun b => x (b + θ)) (dx (a + θ)) a := by
    simpa only [Function.comp_def, id_eq, one_smul] using
      (hdx (a + θ)).scomp a ((hasDerivAt_id a).add_const θ)
  have hi := intervalIntegral.integral_eq_sub_of_hasDerivAt (a := 0) (b := L)
    (fun a _ => hd a) ((hc.comp (continuous_id.add_const θ)).intervalIntegrable 0 L)
  simpa only [zero_add, add_comm L θ, hx θ, sub_self] using hi

/-- A uniform tangential drive has zero resultant, component by component.
Its torque need not vanish: it is computed separately above. -/
theorem planar_tangential_force_resultant_zero
    {L lam q θ : ℝ} {x y dx dy : ℝ → ℝ}
    (hx : Function.Periodic x L) (hy : Function.Periodic y L)
    (hdx : ∀ a, HasDerivAt x (dx a) a) (hdy : ∀ a, HasDerivAt y (dy a) a)
    (hcx : Continuous dx) (hcy : Continuous dy) :
    (∫ a in (0 : ℝ)..L, (lam * q) * dx (a + θ)) = 0 ∧
    (∫ a in (0 : ℝ)..L, (lam * q) * dy (a + θ)) = 0 := by
  rw [intervalIntegral.integral_const_mul, intervalIntegral.integral_const_mul,
    periodic_tangent_integral_zero hx hdx hcx θ,
    periodic_tangent_integral_zero hy hdy hcy θ]
  simp

/-- For nonzero signed area and positive mass density, nonzero tangential
acceleration requires nonzero applied torque on this family. -/
theorem planar_reaction_torque_nonzero
    {L lam θ q : ℝ} {x y dx dy : ℝ → ℝ}
    (hx : Function.Periodic x L) (hy : Function.Periodic y L)
    (hdx : ∀ a, HasDerivAt x (dx a) a) (hdy : ∀ a, HasDerivAt y (dy a) a)
    (hlam : lam ≠ 0) (harea : planarSignedArea L x y dx dy ≠ 0) (hq : q ≠ 0) :
    planarTangentialMoment L lam x y dx dy θ q ≠ 0 := by
  rw [planarTangentialMoment_eq_area hx hy hdx hdy]
  exact mul_ne_zero (mul_ne_zero (mul_ne_zero (by norm_num) hlam) harea) hq

/-- On a C1 curve the spatial moment integrand is continuous, hence genuinely
Bochner integrable on the material interval. -/
theorem planarTangentialMoment_intervalIntegrable
    {L lam θ q : ℝ} {x y dx dy : ℝ → ℝ}
    (hdx : ∀ a, HasDerivAt x (dx a) a) (hdy : ∀ a, HasDerivAt y (dy a) a)
    (hcx : Continuous dx) (hcy : Continuous dy) :
    IntervalIntegrable
      (fun a => lam * (x (a + θ) * (q * dy (a + θ)) -
        y (a + θ) * (q * dx (a + θ)))) volume 0 L := by
  have hx : Continuous x := continuous_iff_continuousAt.mpr (fun a => (hdx a).continuousAt)
  have hy : Continuous y := continuous_iff_continuousAt.mpr (fun a => (hdy a).continuousAt)
  have hs : Continuous (fun a : ℝ => a + θ) := continuous_id.add_const θ
  exact (((hx.comp hs).mul (continuous_const.mul (hcy.comp hs))).sub
    ((hy.comp hs).mul (continuous_const.mul (hcx.comp hs)))).const_mul lam |>.intervalIntegrable 0 L

/-- The actual material-velocity angular-momentum integrand is integrable on a
C1 curve, by the chain rule and continuity of the tangents. -/
theorem planarMaterialAngularMomentum_intervalIntegrable
    {L lam t : ℝ} {x y dx dy θ c : ℝ → ℝ}
    (hdx : ∀ a, HasDerivAt x (dx a) a) (hdy : ∀ a, HasDerivAt y (dy a) a)
    (hcx : Continuous dx) (hcy : Continuous dy)
    (hθ : HasDerivAt θ (c t) t) :
    IntervalIntegrable
      (fun a => lam * (x (a + θ t) * deriv (fun s => y (a + θ s)) t -
        y (a + θ t) * deriv (fun s => x (a + θ s)) t)) volume 0 L := by
  have hvx (a : ℝ) : deriv (fun s => x (a + θ s)) t = c t * dx (a + θ t) := by
    simpa only [smul_eq_mul] using (loop_position_hasDerivAt (hdx _) hθ).deriv
  have hvy (a : ℝ) : deriv (fun s => y (a + θ s)) t = c t * dy (a + θ t) := by
    simpa only [smul_eq_mul] using (loop_position_hasDerivAt (hdy _) hθ).deriv
  simp_rw [hvx, hvy]
  exact planarTangentialMoment_intervalIntegrable hdx hdy hcx hcy

/-- Physical C1 endpoint: both actual spatial integrals are integrable, the
angular momentum is twice density times signed area times speed, and its true
time derivative equals the integral of the distributed applied torque. Thus
the balance does not rely on Lean's default value for a nonintegrable integral. -/
theorem planar_material_torque_balance_C1
    {L lam γ u d t : ℝ} {x y dx dy θ c : ℝ → ℝ}
    (hx : Function.Periodic x L) (hy : Function.Periodic y L)
    (hdx : ∀ a, HasDerivAt x (dx a) a) (hdy : ∀ a, HasDerivAt y (dy a) a)
    (hcx : Continuous dx) (hcy : Continuous dy)
    (hθ : ∀ s, HasDerivAt θ (c s) s)
    (hc : HasDerivAt c (u - γ * c t + d) t) :
    IntervalIntegrable
      (fun a => lam * (x (a + θ t) * deriv (fun s => y (a + θ s)) t -
        y (a + θ t) * deriv (fun s => x (a + θ s)) t)) volume 0 L ∧
    IntervalIntegrable
      (fun a => lam * (x (a + θ t) * ((u - γ * c t + d) * dy (a + θ t)) -
        y (a + θ t) * ((u - γ * c t + d) * dx (a + θ t)))) volume 0 L ∧
    planarMaterialAngularMomentum L lam x y θ t =
      2 * lam * planarSignedArea L x y dx dy * c t ∧
    HasDerivAt (planarMaterialAngularMomentum L lam x y θ)
      (planarTangentialMoment L lam x y dx dy (θ t) (u - γ * c t + d)) t := by
  exact ⟨planarMaterialAngularMomentum_intervalIntegrable hdx hdy hcx hcy (hθ t),
    planarTangentialMoment_intervalIntegrable hdx hdy hcx hcy,
    planarMaterialAngularMomentum_eq_area hx hy hdx hdy (hθ t),
    planarMaterialAngularMomentum_hasDerivAt hx hy hdx hdy hθ hc⟩

end
end ChainFountain.ZeroGravity
