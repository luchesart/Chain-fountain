#!/usr/bin/env python3
"""Build the offline v0.19 claim map from source and a real kernel export.

Run check_completion.py first. A missing/incomplete/stale audit can never yield
PASS here. --allow-pending permits a clearly marked draft before an export.
The mathematical correspondence is curated below; types, dependencies, axioms,
source locations, counts, and proof texts are read from actual project files.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "verification" / "completion"
sys.path.insert(0, str(ROOT / "verification"))
from source_inventory import declarations

ZG = "ChainFountain.ZeroGravity."
SF = "ChainFountainStochastic.LocalFreezingCompletion."
GROUPS = [
    {
        "claim_id": "CF19-SUPPLY", "title": "Краен запас и точно време на изчерпване",
        "module": "ChainFountain.ZeroGravitySupply",
        "paper_labels": ["cor:zg-depletion", "prop:zg-decay", "app:zg-math"],
        "entrypoints": [ZG + n for n in ["constant_height_finite_supply", "first_depletion",
            "decaySpeed_integral", "decaySpeed_tendsto_zero", "constant_height_passive_and_tension"]],
        "scope": "Положителни начална скорост и запас; положителна константа на затихване. "
                 "Извеждат се действителният интеграл на скоростта, първият момент на изчерпване "
                 "и механичните уравнения с положителен остатъчен запас преди него. "
                 "Отделните следствия дават пасивен вход, положителен опън и скорост, клоняща към нула.",
        "limits": "Точното движение е това с постоянна височина при нулева гравитация. "
                  "Не се моделира движението след изчерпването на източника.",
    },
    {
        "claim_id": "CF19-ENERGY", "title": "Кинетична енергия и баланс на мощността",
        "module": "ChainFountain.ZeroGravityEnergy",
        "paper_labels": ["eq:zg-loop-energy", "app:zg-math"],
        "entrypoints": [ZG + n for n in ["loop_kinetic_integral", "loop_spatial_power_balance",
            "loop_tension_power_integral", "loop_external_power_integral", "loop_power_hasDerivAt",
            "loop_power_ae", "loop_power_integral", "AECirculatingLoop.energy_balance"]],
        "scope": "Енергията се свързва с пространствения интеграл на действителната материална "
                 "скорост върху единично параметризирания контур. Действителната вътрешна сила "
                 "от опъна има нулева мощност; пространственият интеграл на мощността на външната "
                 "сила е равен на производната на енергията. Интегруемостта на тези величини е "
                 "доказана. Проверени са класическият, "
                 "почти навсякъде и интегралният баланс, включително за вече построеното AC решение.",
        "limits": "Балансът е за точното семейство на циркулиращи контури. "
                  "Той не представлява енергиен анализ на произволна пространствена деформация.",
    },
    {
        "claim_id": "CF19-TORQUE", "title": "Ъглов момент и реакционен въртящ момент",
        "module": "ChainFountain.ZeroGravityAngularMomentum",
        "paper_labels": ["app:zg-math"],
        "entrypoints": [ZG + n for n in ["planar_material_torque_balance_C1",
            "planarMaterialAngularMomentum_eq_area", "planarMaterialAngularMomentum_hasDerivAt_ae",
            "planar_tangential_force_resultant_zero", "planar_reaction_torque_nonzero"]],
        "scope": "Действителни пространствени интеграли за плосък периодичен контур: "
                 "ъглов момент, приложен момент и ориентирана площ. Фазовата инвариантност се "
                 "извежда от периодичността; C¹ крайният резултат включва интегруемостта на "
                 "физическите интегранди. Проверена е и нулевата сумарна тангенциална сила.",
        "limits": "Плосък контур и пространствено еднородно тангенциално задвижване. "
                  "Опората, реакцията на устройството и неговата ориентационна динамика остават извън модела.",
    },
    {
        "claim_id": "CF19-SHAPE", "title": "Геометрична пречка пред привличането към форма",
        "module": "ChainFountain.ZeroGravityShape",
        "paper_labels": ["prop:zg-shape-obstruction", "app:zg-math"],
        "entrypoints": [ZG + n for n in ["circulation_shape_attracted_iff",
            "two_circulation_shapes_no_common_attractor", "circulation_speed_shape_obstruction",
            "arbitrarily_close_nonattracting_circulation"]],
        "scope": "Формата е геометричният образ в неподвижна пространствена координатна система. "
                 "Използва се действителното разстояние на Хаусдорф между непразни компактни множества. "
                 "Фазата не променя образа; еднаквата скоростна динамика може да съществува при "
                 "постоянно положително геометрично разстояние. Конструирани са и произволно близки "
                 "разместени контури със запазени период и производни.",
        "limits": "Не се отъждествяват форми чрез транслации или други твърди движения. "
                  "Непривличането не е доказателство за напречна неустойчивост на общото PDE.",
    },
    {
        "claim_id": "CF19-ARCLENGTH", "title": "Препараметризация по дължина на дъгата",
        "module": "ChainFountain.ZeroGravityArclength",
        "paper_labels": ["app:zg-math"],
        "entrypoints": [ZG + n for n in ["arcCoordinate_surjective", "arcOrderIso_symm_hasDerivAt",
            "periodic_arclength_reparameterization", "closed_regular_curve_arclength"]],
        "scope": "За регулярна C² периодична крива с положителен период се построява "
                 "глобалната обратна дължинна координата. Получената C² параметризация е с единична "
                 "скорост, запазва геометричния образ и има период, равен на дължината за един изходен период.",
        "limits": "Производната на изходната крива не се анулира. Самопресичания са допустими; "
                  "не се изисква зададеният период да е минимален. Числената таблица на рендера не е формализирана.",
    },
    {
        "claim_id": "CF19-FREEZING", "title": "Локално замразяване на стохастичния коефициент",
        "module": "ChainFountainStochastic.LocalFreezingCompletion",
        "paper_labels": ["thm:freezing", "thm:mechanical-lil", "app:formal"],
        "entrypoints": [SF + n for n in ["predictable_freezing", "local_eq_predictable",
            "local_freezing", "local_integral_lil", "local_freezing_stoppedProcess"]],
        "related_entrypoints": ["ChainFountainStochastic.MechanicalSmallTime." + n for n in
            ["maximal_crown_normalized_lil", "boundary_negative", "exists_mechanical_crown_lil"]],
        "scope": "Непрекъснат адаптиран коефициент с детерминистична начална стойност; "
                 "естествената филтрация на Брауновото движение. Не се предполага глобална "
                 "детерминистична граница. Използват се действителните локализирани интеграли, "
                 "доказаното им съвпадение и локалността върху начален интервал. Следват LIL "
                 "границите и запазването на малковремевия предел преди положително случайно спиране.",
        "limits": "Това допълва общата теорема за freezing. Механичният LIL вече е доказан "
                  "в основния проект и е показан като свързан резултат. Не се твърдят произволна "
                  "филтрация, безкраен стохастичен живот или глобална стохастична безопасност.",
    },
]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_json(path: Path, default):
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else default


def build(allow_pending: bool = False) -> dict:
    summary = load_json(OUT / "summary.json", {})
    environment = load_json(OUT / "environment.json", [])
    if not environment and not allow_pending:
        raise SystemExit("No kernel export yet. Run verification/check_completion.py first.")
    kernel = {r["name"]: r for r in environment}
    source_rows = {}
    module_sources = {}
    source_hashes = {}
    for directory in ("ChainFountain", "ChainFountainStochastic"):
        for file in sorted((ROOT / directory).glob("*.lean")):
            source = file.read_text(encoding="utf-8")
            relative = file.relative_to(ROOT).as_posix()
            module = relative[:-5].replace("/", ".")
            source_hashes[relative] = sha(file)
            if module in {g["module"] for g in GROUPS}:
                module_sources[module] = {"file": relative, "source": source, "sha256": sha(file)}
            for row in declarations(source):
                source_rows[row["name"]] = {
                    **row, "module": module, "file": relative,
                    "source": source[row["start"]:row["end"]].rstrip(),
                }
    mismatches = [path for path, expected in summary.get("source_sha256", {}).items()
                  if source_hashes.get(path) != expected]
    uncovered_sources = sorted(set(source_hashes) - set(summary.get("source_sha256", {})))
    reasons = []
    if summary.get("status") != "PASS":
        reasons.append("Общият одит няма статус PASS.")
    if not summary.get("fresh_combined_build"):
        reasons.append("Липсва успешна обща компилация на тази версия.")
    if not summary.get("entrypoint_sha256") or any(
        not (ROOT / path).is_file() or sha(ROOT / path) != expected
        for path, expected in summary.get("entrypoint_sha256", {}).items()
    ):
        reasons.append("Входните файлове не съвпадат с проверената версия.")
    if not environment:
        reasons.append("Липсва действителен експорт от Lean ядрото.")
    if mismatches or uncovered_sources:
        reasons.append("Текущите източници не съвпадат изцяло с одитирания набор.")
    groups = []
    for original in GROUPS:
        group = dict(original)
        group["declarations"] = sorted(n for n, row in source_rows.items()
                                       if row["module"] == group["module"])
        group["theorems"] = [n for n in group["declarations"]
                             if source_rows[n]["kind"] == "theorem"]
        missing = [n for n in group["declarations"] if n not in kernel]
        missing += [n for n in group["entrypoints"] + group.get("related_entrypoints", []) if n not in kernel]
        group["missing_kernel_names"] = sorted(set(missing))
        if missing:
            reasons.append(f"{group['claim_id']}: липсват декларации в експорта.")
        groups.append(group)
    # Only the summary can certify a completed audit. Independently verify that
    # the exported axiom sets still satisfy its recorded allowlist.
    allowlist = set(summary.get("axiom_allowlist", ["propext", "Classical.choice", "Quot.sound"]))
    unexpected = {name: sorted(set(row.get("transitive_axioms", [])) - allowlist)
                  for name, row in kernel.items()
                  if set(row.get("transitive_axioms", [])) - allowlist}
    if unexpected:
        reasons.append("Експортът съдържа зависимости от аксиоми извън разрешения списък.")
    status = "PASS" if not reasons else "PENDING"
    rows = {}
    for name in sorted(set(kernel) | set(source_rows)):
        compiled = kernel.get(name)
        source = source_rows.get(name)
        if compiled is None and source is None:
            continue
        value_refs = sorted(set(compiled.get("value_refs", []))) if compiled else []
        type_refs = sorted(set(compiled.get("type_refs", []))) if compiled else []
        rows[name] = {
            "name": name,
            "module": compiled.get("module") if compiled else source["module"],
            "kind": compiled.get("kind") if compiled else source["kind"],
            "kernel_present": compiled is not None,
            "type": compiled.get("type", "") if compiled else "",
            "doc": compiled.get("doc", "") if compiled else "",
            "axioms": compiled.get("transitive_axioms", []) if compiled else [],
            "source_range": compiled.get("source_range") if compiled else None,
            "file": source.get("file") if source else None,
            "line": source.get("line") if source else None,
            "source": source.get("source", "") if source else "",
            "proof_dependencies": [n for n in value_refs if n in kernel],
            "type_dependencies": [n for n in type_refs if n in kernel and n not in value_refs],
            "external_proof_dependencies": [n for n in value_refs if n not in kernel],
        }
    for group in groups:
        group["status"] = status if not group["missing_kernel_names"] else "PENDING"
        deps = Counter()
        for name in group["theorems"]:
            for dep in rows[name]["proof_dependencies"]:
                depmod = rows[dep]["module"]
                if depmod != group["module"]:
                    deps[depmod] += 1
        group["proof_dependency_modules"] = dict(sorted(deps.items()))
    added_names = [name for group in groups for name in group["theorems"]]
    data = {
        "title": "Chain fountain — карта на довършената формализация",
        "version": "0.19.0",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "status": status,
        "status_reasons": list(dict.fromkeys(reasons)),
        "source_hash_mismatches": mismatches,
        "uncovered_sources": uncovered_sources,
        "unexpected_axioms": unexpected,
        "audit": {key: summary.get(key) for key in ["status", "toolchain", "finished_utc",
            "fresh_combined_build", "authored_theorem_count", "authored_public_theorem_count",
            "authored_private_theorem_count", "kernel_declaration_count", "source_module_count",
            "all_project_kernel_declarations_audited", "manifest_sha256", "axiom_allowlist"]},
        "new_module_count": len(groups),
        "new_authored_theorem_count": len(added_names),
        "new_authored_declaration_count": sum(len(g["declarations"]) for g in groups),
        "groups": groups,
        "declarations": rows,
        "module_sources": module_sources,
    }
    return data


HTML = r'''<!doctype html>
<html lang="bg"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light"><title>Chain fountain · Formalization map</title>
<style>
:root{--ink:#13283a;--muted:#526777;--line:#d7e2e8;--paper:#fff;--bg:#f1f5f7;--accent:#006f75;--soft:#e0f3f0;--warning:#824300;--warnbg:#fff0d8;--mono:ui-monospace,SFMono-Regular,Consolas,"Liberation Mono",monospace}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.6 system-ui,-apple-system,"Segoe UI",sans-serif}a{color:var(--accent)}button,input,select{font:inherit}button{cursor:pointer}header{background:#132c3c;color:#fff;padding:42px max(24px,calc((100vw - 1280px)/2));border-bottom:5px solid #38b5ac}header .eyebrow{color:#94d9d3;font-size:12px;letter-spacing:.16em;text-transform:uppercase;font-weight:700}h1{max-width:920px;font-size:clamp(27px,3vw,40px);line-height:1.18;letter-spacing:-.03em;margin:14px 0}header p{max-width:900px;color:#d8e5ec;margin:0}main{max-width:1328px;margin:auto;padding:24px;display:grid;grid-template-columns:235px minmax(0,1fr);gap:26px}.aside-inner{position:sticky;top:18px}nav{display:grid;gap:5px}nav a{padding:9px 11px;border-radius:7px;text-decoration:none;font-size:13px;color:var(--ink)}nav a:hover{background:#dfe9ee}.small{font-size:12px;color:var(--muted)}.badge{display:inline-block;border-radius:20px;padding:3px 10px;font:700 11px/1.8 system-ui;background:var(--soft);color:var(--accent);vertical-align:middle}.pending{background:var(--warnbg);color:var(--warning)}.stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin-bottom:18px}.stat{background:var(--paper);border:1px solid var(--line);border-radius:10px;padding:13px 16px}.stat strong{display:block;font-size:27px;line-height:1.2}.stat span{font-size:12px;color:var(--muted)}.notice{padding:16px 18px;border:1px solid var(--line);border-left:4px solid var(--accent);border-radius:7px;background:white;margin-bottom:18px}.notice.pending{border-left-color:#bf7600;background:var(--warnbg)}.toolbar{display:flex;gap:8px;align-items:center;background:var(--paper);border:1px solid var(--line);border-radius:9px;padding:10px;margin-bottom:18px;position:sticky;top:0;z-index:5}input{width:100%;border:1px solid var(--line);border-radius:6px;padding:9px 12px;min-width:0;background:#fafcfd}input:focus{outline:2px solid #5caaa8;outline-offset:1px}button.clear{border:0;background:var(--bg);color:var(--ink);padding:8px 10px;border-radius:5px;white-space:nowrap}.group{background:var(--paper);border:1px solid var(--line);border-radius:11px;overflow:hidden;margin-bottom:20px;scroll-margin-top:90px}.group-head{padding:22px 23px 13px}.group h2{font-size:22px;line-height:1.25;margin:8px 0 10px;letter-spacing:-.02em}.id{font:12px var(--mono);color:var(--muted)}.labels{display:flex;gap:6px;flex-wrap:wrap;margin:12px 0}.label{font:11px var(--mono);background:var(--bg);border:1px solid var(--line);padding:3px 6px;border-radius:4px}.scope{margin:10px 0;font-size:14px}.limit{background:#f4f7f9;border-left:3px solid #96aab8;padding:10px 13px;margin:13px 0;font-size:13px}.limit strong{display:block;font-size:11px;text-transform:uppercase;letter-spacing:.05em;color:var(--muted);margin-bottom:2px}.decl-table{width:100%;border-collapse:collapse;table-layout:fixed}.decl-table td{padding:9px 23px;border-top:1px solid #e7edf1;vertical-align:top}.decl-table td:last-child{width:105px;text-align:right;font-size:11px;color:var(--muted)}.decl-link{background:none;border:0;padding:0;text-align:left;color:var(--accent);font:12px/1.5 var(--mono);overflow-wrap:anywhere}.decl-link:hover{text-decoration:underline}.entry-mark{font:700 10px system-ui;background:#e7f4f1;color:#006f75;padding:2px 5px;border-radius:3px;margin-left:7px;white-space:nowrap}.module-details{padding:12px 23px;border-top:1px solid var(--line);font-size:13px}.module-details summary{cursor:pointer;color:var(--muted)}.module-details ul{padding-left:18px}code{font-family:var(--mono);font-size:.87em;overflow-wrap:anywhere}pre{font:12px/1.65 var(--mono);background:#102533;color:#e1edf3;padding:16px;border-radius:7px;white-space:pre-wrap;overflow-wrap:anywhere;max-height:620px;overflow:auto;tab-size:2}footer{padding:18px 0 38px;color:var(--muted);font-size:12px}dialog{width:min(1080px,calc(100vw - 30px));max-height:92vh;padding:0;border:1px solid var(--line);border-radius:12px;box-shadow:0 20px 90px #0005;color:var(--ink)}dialog::backdrop{background:#0820309c}.modal-head{position:sticky;top:0;background:white;border-bottom:1px solid var(--line);padding:17px 22px;z-index:1;display:flex;gap:12px;align-items:flex-start}.modal-head strong{font:13px/1.5 var(--mono);overflow-wrap:anywhere;flex:1}.close{border:1px solid var(--line);border-radius:6px;background:white;padding:3px 12px}.modal-body{padding:20px 24px}.modal-body h3{font-size:13px;text-transform:uppercase;letter-spacing:.04em;color:var(--muted);margin:22px 0 8px}.dep-list{display:flex;flex-wrap:wrap;gap:5px}.dep{padding:5px 7px;background:#eef5f6;border:1px solid #dce9eb;border-radius:4px;font:11px var(--mono);color:var(--accent);text-align:left;overflow-wrap:anywhere}.audit-table{width:100%;border-collapse:collapse;font-size:12px}.audit-table td{padding:7px 10px;border-bottom:1px solid var(--line);vertical-align:top}.audit-table td:first-child{width:37%;color:var(--muted)}.empty{padding:40px;text-align:center;color:var(--muted)}[hidden]{display:none!important}.download{display:block;padding:7px 10px;border:1px solid var(--line);border-radius:6px;text-decoration:none;margin-top:12px;font-size:12px}.source-block{padding:0 23px 18px}.minor-title{font-size:13px;color:var(--muted);margin:14px 0 6px}.related{padding:0 23px 16px}.related .dep-list{margin-top:6px}
@media(max-width:850px){main{grid-template-columns:1fr;padding:15px;gap:15px}aside{display:none}.stats{grid-template-columns:repeat(2,minmax(0,1fr))}header{padding:28px 20px}.group-head{padding:18px}.decl-table td{padding:9px 18px}.toolbar{top:0}.modal-body{padding:15px}pre{font-size:11px}.group h2{font-size:20px}}
@media print{header{background:white;color:black;padding:10px 0;border-bottom:2px solid #444}header p,header .eyebrow{color:#333}main{display:block;max-width:none;padding:0}aside,.toolbar,dialog,.download,.source-block{display:none!important}.group{break-inside:avoid;border-radius:0}.stats{margin-top:15px}.decl-link{color:black}.notice{margin-top:12px}body{background:white}.module-details:not([open]){display:none}}
</style></head><body>
<header><div class="eyebrow">CHAIN FOUNTAIN · LEAN 4 · V0.19.0</div><h1>От твърдението в статията<br>до провереното доказателство</h1><p>Карта на шестте допълнения: точни предпоставки, действителни Lean типове, зависимости на доказателствата и граници на формализацията. Работи изцяло офлайн.</p></header>
<main><aside><div class="aside-inner"><div class="small" style="margin:0 10px 10px">ТВЪРДЕНИЯ И СЪОТВЕТСТВИЕ</div><nav id="nav"></nav><a class="download" id="download">Изтегли JSON картата</a><p class="small" style="padding:0 10px">Изберете име на теорема, за да видите нейния действителен тип, доказателство и зависимости. Статусът се извежда от общия одит, а не от броя имена в кода.</p></div></aside>
<section><div class="stats" id="stats"></div><div id="audit-notice"></div><div class="toolbar"><input id="search" type="search" aria-label="Търсене" placeholder="Търси твърдение, Lean име, предпоставка или етикет…"><button class="clear" id="clear">Изчисти</button></div><div class="small" id="result-count" style="margin:0 3px 10px"></div><div id="groups"></div><div id="empty" class="empty" hidden>Няма съвпадения. Опитайте по-кратко Lean име или дума от твърдението.</div><section class="group" id="audit"><div class="group-head"><span class="id">ПРОИЗХОД НА ПРОВЕРКАТА</span><h2>Компилация, аксиоми и обхват</h2><p class="scope">Зависимостите са извлечени от реалните типове и тела на декларациите в Lean средата. Импортът на модул сам по себе си не означава, че всяка негова теорема е използвана. Стандартните основополагащи аксиоми са разграничени от предпоставките на математическите теореми.</p><table class="audit-table" id="audit-table"></table><p class="small">Физическата адекватност, експерименталната проверка, числената точност на симулатора, общата пространствена коректност и напречната устойчивост не се удостоверяват от тази карта.</p></div></section><footer>Latchezar Tomov · Chain fountain · <span id="stamp"></span><br>Картата свързва изброените математически твърдения с конкретните формални резултати; тя не обявява всяко изречение от статията за Lean теорема.</footer></section></main>
<dialog id="modal"><div class="modal-head"><strong id="modal-title"></strong><button class="close" id="close" aria-label="Затвори">✕</button></div><div class="modal-body" id="modal-body"></div></dialog>
<script id="map-data" type="application/json">__DATA__</script>
<script>
'use strict';
const D=JSON.parse(document.getElementById('map-data').textContent);
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const short=n=>n.replace(/^ChainFountain\.ZeroGravity\./,'').replace(/^ChainFountainStochastic\.LocalFreezingCompletion\./,'');
function badge(status){return '<span class="badge '+(status==='PASS'?'':'pending')+'">'+(status==='PASS'?'ПРОВЕРЕНО':'НЕПОТВЪРДЕНО')+'</span>'}
function depButton(name){return '<button class="dep" data-decl="'+esc(name)+'">'+esc(name)+'</button>'}
function showDecl(name){
 const r=D.declarations[name]; if(!r)return;
 $('#modal-title').textContent=name;
 let body='<div>'+badge(D.status==='PASS'&&r.kernel_present?'PASS':'PENDING')+' <span class="small">'+esc(r.kind)+' · '+esc(r.module)+'</span></div>';
 if(r.doc)body+='<p>'+esc(r.doc).replace(/\n/g,'<br>')+'</p>';
 body+='<h3>Точен тип от компилираната Lean среда</h3><pre>'+esc(r.type||'Няма наличен компилиран тип. Не е потвърден резултат.')+'</pre>';
 body+='<h3>Транзитивни аксиоми</h3><p><code>'+esc(r.kernel_present?(r.axioms.join(', ')||'няма'):'непроверени')+'</code></p>';
 body+='<h3>Проектни зависимости на доказателството · '+r.proof_dependencies.length+'</h3><div class="dep-list">'+(r.proof_dependencies.map(depButton).join('')||'<span class="small">Няма директни проектни зависимости в тялото.</span>')+'</div>';
 if(r.type_dependencies.length)body+='<h3>Проектни зависимости само в типа · '+r.type_dependencies.length+'</h3><div class="dep-list">'+r.type_dependencies.map(depButton).join('')+'</div>';
 if(r.external_proof_dependencies.length)body+='<details class="module-details"><summary>Библиотечни зависимости в тялото · '+r.external_proof_dependencies.length+'</summary><pre>'+esc(r.external_proof_dependencies.join('\n'))+'</pre></details>';
 if(r.source){body+='<h3>Авторски източник · '+esc(r.file)+':'+esc(r.line)+'</h3><pre>'+esc(r.source)+'</pre>'}
 else body+='<p class="small">Генерирана от Lean декларация или помощна декларация без отделен авторски блок. Точният ѝ тип и зависимости са показани по-горе.</p>';
 $('#modal-body').innerHTML=body;
 if(!$('#modal').open)$('#modal').showModal();
 $('#modal-body').scrollTop=0;$('#modal').scrollTop=0;
}
document.addEventListener('click',e=>{const b=e.target.closest('[data-decl]');if(b)showDecl(b.dataset.decl)});
$('#close').onclick=()=>$('#modal').close();
$('#modal').addEventListener('click',e=>{if(e.target===$('#modal'))$('#modal').close()});
$('#nav').innerHTML=D.groups.map(g=>'<a href="#'+g.claim_id+'">'+esc(g.title)+'</a>').join('')+'<a href="#audit">Общ одит и обхват</a>';
const stats=[[D.new_module_count,'нови модула'],[D.new_authored_theorem_count,'нови авторски теореми'],[D.audit.authored_theorem_count??'—','авторски теореми общо'],[D.audit.kernel_declaration_count??'—','декларации в общия одит']];
$('#stats').innerHTML=stats.map(([v,label])=>'<div class="stat"><strong>'+esc(v)+'</strong><span>'+esc(label)+'</span></div>').join('');
const pass=D.status==='PASS';
$('#audit-notice').innerHTML='<div class="notice '+(pass?'':'pending')+'">'+badge(D.status)+' <strong>'+(pass?'Кодът съвпада с одитирания изходен набор.':'Картата още няма потвърден завършен одит.')+'</strong><div class="small">'+(pass?'Всички показани нови декларации присъстват в компилираната среда; техните предпоставки остават част от резултатите.':D.status_reasons.map(esc).join(' '))+'</div></div>';
function renderGroups(query=''){
 const q=query.trim().toLocaleLowerCase();let visible=0,shown=0;
 $('#groups').innerHTML=D.groups.map(g=>{
  const groupMatch=[g.claim_id,g.title,g.scope,g.limits,...g.paper_labels].join(' ').toLocaleLowerCase().includes(q);
  const names=g.declarations.filter(n=>!q||groupMatch||[n,D.declarations[n].type,D.declarations[n].doc,D.declarations[n].source].join(' ').toLocaleLowerCase().includes(q));
  if(!names.length)return '';visible++;shown+=names.length;
  const source=D.module_sources[g.module];
  let rows=names.map(n=>{const r=D.declarations[n];return '<tr><td><button class="decl-link" data-decl="'+esc(n)+'">'+esc(short(n))+'</button>'+(g.entrypoints.includes(n)?'<span class="entry-mark">основен резултат</span>':'')+'</td><td>'+esc(r.kind)+'<br>'+esc(r.line?('ред '+r.line):'')+'</td></tr>'}).join('');
  let deps=Object.entries(g.proof_dependency_modules).map(([m,count])=>'<li><code>'+esc(m)+'</code> · '+count+' директни връзки</li>').join('');
  let related=(g.related_entrypoints||[]).length?'<div class="related"><div class="minor-title">Свързани резултати от основния проект</div><div class="dep-list">'+g.related_entrypoints.map(depButton).join('')+'</div></div>':'';
  return '<article class="group" id="'+g.claim_id+'"><div class="group-head"><span class="id">'+esc(g.claim_id)+'</span> '+badge(g.status)+'<h2>'+esc(g.title)+'</h2><div class="labels">'+g.paper_labels.map(l=>'<span class="label">'+esc(l)+'</span>').join('')+'</div><p class="scope">'+esc(g.scope)+'</p><div class="limit"><strong>Граница на резултата</strong>'+esc(g.limits)+'</div><div class="small">'+esc(g.module)+' · '+g.theorems.length+' теореми</div></div><table class="decl-table"><tbody>'+rows+'</tbody></table>'+related+'<details class="module-details"><summary>Връзки към други проектни модули</summary><p class="small">Брой директни препратки в доказателствата; повторно използвана зависимост се брои за всяка теорема.</p><ul>'+(deps||'<li>Няма зависимости от други проектни модули.</li>')+'</ul></details><details class="source-block"><summary class="small">Целият източник на модула</summary><p class="small">SHA256: <code>'+esc(source?.sha256)+'</code></p><pre>'+esc(source?.source)+'</pre></details></article>';
 }).join('');
 $('#empty').hidden=visible!==0;
 $('#result-count').textContent=visible+' от '+D.groups.length+' групи · '+shown+' декларации'+(q?' при текущото търсене':'');
}
$('#search').addEventListener('input',e=>renderGroups(e.target.value));
$('#clear').onclick=()=>{$('#search').value='';renderGroups();$('#search').focus()};
renderGroups();
const a=D.audit;
const auditRows=[['Статус на общия одит',a.status??'липсва'],['Нова обща компилация',a.fresh_combined_build===true?'да':'не е удостоверена от този одит'],['Проверени всички проектни декларации',a.all_project_kernel_declarations_audited===true?'да':'не е удостоверено'],['Lean среда',a.toolchain??'—'],['Завършен одит (UTC)',a.finished_utc??'—'],['Публични / частни авторски теореми',(a.authored_public_theorem_count??'—')+' / '+(a.authored_private_theorem_count??'—')],['Изходни модули',a.source_module_count??'—'],['Разрешени аксиоми',(a.axiom_allowlist||[]).join(', ')||'—'],['SHA256 на фиксирания manifest',a.manifest_sha256??'—']];
$('#audit-table').innerHTML=auditRows.map(([k,v])=>'<tr><td>'+esc(k)+'</td><td><code>'+esc(v)+'</code></td></tr>').join('');
$('#stamp').textContent='Генерирано '+D.generated_utc;
const link=$('#download');link.href=URL.createObjectURL(new Blob([JSON.stringify(D,null,2)],{type:'application/json'}));link.download='Chain_Fountain_Completion_Map.json';
</script></body></html>
'''


def main():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(errors="backslashreplace")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--allow-pending", action="store_true")
    parser.add_argument("--html", type=Path, default=ROOT / "Chain_Fountain_Completion_Map.html")
    args = parser.parse_args()
    data = build(args.allow_pending)
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / "claims.json").open("w", encoding="utf-8", newline="\n") as output:
        output.write(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    # Protect the HTML script boundary even if a source comment contains tags.
    payload = json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace("<", "\\u003c")
    args.html.parent.mkdir(parents=True, exist_ok=True)
    with args.html.open("w", encoding="utf-8", newline="\n") as output:
        output.write(HTML.replace("__DATA__", payload))
    print(json.dumps({"status": data["status"], "groups": len(data["groups"]),
        "new_theorems": data["new_authored_theorem_count"], "html": str(args.html),
        "claims": str(OUT / "claims.json"), "reasons": data["status_reasons"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
