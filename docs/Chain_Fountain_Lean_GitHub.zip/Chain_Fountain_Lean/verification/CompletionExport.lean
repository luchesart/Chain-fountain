import ChainFountainCompletion
import Lean

open Lean Elab Command

set_option maxHeartbeats 0

/-! Export every kernel declaration owned by the complete project, including
generated helpers, and its transitive axioms. No source-name heuristic is used
to decide which proved declarations to audit. -/
run_cmd liftTermElabM do
  let env ← getEnv
  let mut rows : Array Json := #[]
  for (name, ci) in env.constants.toList do
    let moduleName := match env.getModuleIdxFor? name with
      | some idx => env.header.moduleNames[idx.toNat]!.toString
      | none => env.mainModule.toString
    if moduleName.startsWith "ChainFountain" then
      let kind := match ci with
        | .thmInfo _ => "theorem"
        | .defnInfo _ => "definition"
        | .axiomInfo _ => "axiom"
        | .opaqueInfo _ => "opaque"
        | .inductInfo _ => "inductive"
        | .ctorInfo _ => "constructor"
        | .recInfo _ => "recursor"
        | .quotInfo _ => "quotient"
      let typ ← Meta.ppExpr ci.type
      let axioms ← collectAxioms name
      let valueRefs := (ci.value? true).map (fun e => e.getUsedConstants) |>.getD #[]
      let doc := (← findDocString? env name).getD ""
      let range := match ← findDeclarationRanges? name with
        | some r => Json.mkObj [("start_line", toJson r.range.pos.line),
            ("start_column", toJson r.range.pos.column),
            ("end_line", toJson r.range.endPos.line)]
        | none => Json.null
      rows := rows.push (Json.mkObj [
        ("name", toJson name.toString), ("module", toJson moduleName),
        ("kind", toJson kind), ("type", toJson typ.pretty), ("doc", toJson doc),
        ("source_range", range),
        ("type_refs", toJson (ci.type.getUsedConstants.map Name.toString)),
        ("value_refs", toJson (valueRefs.map Name.toString)),
        ("transitive_axioms", toJson (axioms.map Name.toString))])
  liftM <| IO.FS.createDirAll "verification/completion"
  liftM <| IO.FS.writeFile "verification/completion/environment.json" (Json.arr rows).pretty
