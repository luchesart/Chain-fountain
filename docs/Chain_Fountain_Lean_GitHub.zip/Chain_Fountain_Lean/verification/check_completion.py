#!/usr/bin/env python3
"""Rebuild the complete article entry point and audit all project declarations.

Dependencies must first be fetched at the pinned revisions. The script never
marks an audit as passed merely because source contains no placeholders.
"""
import argparse
import collections
import hashlib
import json
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'verification' / 'completion'
sys.path.insert(0, str(ROOT / 'verification'))
from source_inventory import declarations, mask_comments

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            stream.reconfigure(errors='backslashreplace')
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--audit-only', action='store_true',
                    help='Audit an already compiled entry point; no fresh build claim.')
    args = ap.parse_args()
    lake = shutil.which('lake')
    if lake is None:
        raise SystemExit('Lake is not on PATH; install the pinned lean-toolchain first.')
    OUT.mkdir(parents=True, exist_ok=True)
    report = {'status':'RUNNING', 'version':'0.19.0',
              'started_utc':datetime.now(timezone.utc).isoformat(),
              'fresh_combined_build':False,
              'toolchain':(ROOT/'lean-toolchain').read_text(encoding='utf-8').strip(),
              'manifest_sha256':sha(ROOT/'lake-manifest.json'),
              'entrypoint_sha256':{name:sha(ROOT/name) for name in (
                  'ChainFountain.lean','ChainFountainStochastic.lean',
                  'ChainFountainZeroGravity.lean','ChainFountainCompletion.lean')},
              'verification_sha256':{name:sha(ROOT/name) for name in (
                  'verification/check_completion.py','verification/CompletionExport.lean',
                  'verification/source_inventory.py')}}
    target = OUT/'summary.json'
    def save():
        with target.open('w', encoding='utf-8', newline='\n') as output:
            output.write(json.dumps(report, indent=2, ensure_ascii=False)+'\n')
    def run(label, command):
        print(label, flush=True)
        with (OUT/(label+'.log')).open('w', encoding='utf-8', newline='\n') as log:
            p=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
        if p.returncode:
            raise RuntimeError(f'{label} failed; see verification/completion/{label}.log')
        if sha(ROOT/'lake-manifest.json') != report['manifest_sha256']:
            raise RuntimeError('Pinned manifest changed during verification.')
    save()
    try:
        run('lean-version',[lake,'env','lean','--version'])
        report['actual_lean_version']=(OUT/'lean-version.log').read_text(encoding='utf-8').strip()
        expected=report['toolchain'].split(':v')[-1]
        if f'Lean (version {expected},' not in report['actual_lean_version']:
            raise RuntimeError('The running compiler does not match lean-toolchain.')
        if not args.audit_only:
            run('combined-build',[lake,'build','ChainFountainCompletion'])
            report['fresh_combined_build']=True
            save()
        run('kernel-export',[lake,'env','lean','verification/CompletionExport.lean'])
        rows=json.loads((OUT/'environment.json').read_text(encoding='utf-8'))
        if not rows:
            raise RuntimeError('Empty kernel export.')
        allow={'propext','Classical.choice','Quot.sound'}
        bad=[{'name':r['name'],'unexpected':sorted(set(r['transitive_axioms'])-allow)}
             for r in rows if set(r['transitive_axioms'])-allow]
        custom=[r['name'] for r in rows if r['kind']=='axiom']
        report['unexpected_axioms']=bad
        report['project_axiom_declarations']=custom
        if bad or custom:
            raise RuntimeError('Transitive axiom audit failed.')
        source_rows=[]
        hashes={}
        placeholders=[]
        for directory in ('ChainFountain','ChainFountainStochastic'):
            for file in sorted((ROOT/directory).glob('*.lean')):
                source=file.read_text(encoding='utf-8')
                relative=file.relative_to(ROOT).as_posix()
                hashes[relative]=sha(file)
                for decl in declarations(source):
                    first_line=source[decl['start']:].splitlines()[0]
                    source_rows.append({**decl,'file':relative,
                                        'private':bool(re.search(r'\bprivate\b',first_line))})
                if re.search(r'\b(?:sorry|admit|axiom)\b',mask_comments(source)):
                    placeholders.append(relative)
        report['source_placeholders']=placeholders
        if placeholders:
            raise RuntimeError('A project source contains a placeholder or axiom declaration.')
        authored=[r for r in source_rows if r['kind']=='theorem']
        exported={r['name'] for r in rows}
        # Private theorem names are mangled by Lean. Preserve their source
        # inventory but audit their elaborated declarations through the full
        # module-owned kernel export above.
        missing=[r['name'] for r in authored if r['name'] not in exported
                 and not any(x.endswith('.'+r['name']) for x in exported)]
        report.update({'kernel_declaration_count':len(rows),
                       'kernel_kinds':dict(collections.Counter(r['kind'] for r in rows)),
                       'authored_theorem_count':len(authored),
                       'authored_public_theorem_count':sum(not r['private'] for r in authored),
                       'authored_private_theorem_count':sum(r['private'] for r in authored),
                       'source_module_count':len(hashes),
                       'source_sha256':hashes,
                       'source_names_not_directly_exported':missing,
                       'axiom_allowlist':sorted(allow),
                       'all_project_kernel_declarations_audited':True})
        with (OUT/'source-inventory.json').open('w', encoding='utf-8', newline='\n') as output:
            output.write(json.dumps(source_rows,indent=2)+'\n')
        if missing:
            raise RuntimeError('Some authored theorem names are absent from the compiled entry point.')
        report['status']='PASS'
        report['finished_utc']=datetime.now(timezone.utc).isoformat()
        save()
        print(f"PASS: {len(authored)} authored theorems; {len(rows)} kernel declarations audited.")
        return 0
    except Exception as error:
        report['status']='FAIL'
        report['error']=str(error)
        save()
        print(str(error),file=sys.stderr)
        return 1

if __name__=='__main__':
    raise SystemExit(main())
